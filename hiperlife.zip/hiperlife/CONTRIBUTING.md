<div align="center">
![hiperlife logo](doc/img/logo_wtitle_white.svg "hiperlife")
</div>

<br>

# Contributing to hiperlife
There are two ways in which you can make your contribution:
1. If you have a question, want to report a bug, suggest a feature or add a new awesome feature, please [create a GitLab issue](#create-a-gitLab-issue).
2. If you want to develop hiperlife, please see [how to fix issues](#fixing-issues)

_**Thank you for contributing to hiperlife!**_


## Create a GitLab issue
If you want to create an issue, follow the next steps:

1. Go to [Gitlab issues website](https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib/issues) and register if you are not already done so.
2. Create a new issue. Please, add a title and description with as much information as you can so that developers can go through it as soon as possible. Remember that you can add screenshots and datasets and use [Markdown](https://docs.gitlab.com/ee/user/markdown.html) to style the description.
3. Developers and maintainers will tag the issue with the corresponding [_Label_](#Labels), [_Milestones_](#Milestones) and/or [_Assignee_](#Assignees). If you are a reporter, please leave these fields empty.
4. If the developers need more information than the one provided with the issue they will add a `stage:need-info` label to the issue.



## Fixing issues
hiperlife is developed by writing code to fix existing issues. Please, note that if you want to add a new feature, you should first [create a GitLab issue](#Create-a-GitLab-issue).

To fix an issue, follow the next steps:

1. Register in [hiperlife's Gitlab](https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib/) and create a clone of the library in your local machine with:
    ```
    git clone git@git.lacan.upc.edu:HPLFEgroup/hiperlifelib.git
    ```
2. Checkout to the current development branch (`dev-v4`) and create a feature branch, for instance `dev-v4-awesomeFeature`, as follows:
    ```
    git checkout dev-v4
    git pull
    git checkout -b dev-v4-awesomeFeature
    ```
    Please, do not forget to take a look at the [branching nomenclature](#git-branches) to see the naming convention of branches followed in hiperlife development.

3. Make your changes to the library to address the issue. Remember to divide your contributions in small logical commits with appropriate messages and descriptions.

    :warning: hiperlife is in continuous development and it is highly probable that new commits make it to the development branch while you are working. Make sure to keep your branch updated by merging the changes. One way to do this is:
    ```
    git checkout dev-v4
    git pull
    git checkout dev-v4-awesomeFeature
    git merge dev-v4
    ```

4. Once you have fixed the issue, push your local changes
    ```
    git push -u origin dev-v4-awesomeFeature
    ```

5. Create a merge request so that developers can review your contribution and eventually add it to the development branch. To do it so, got to [hiperlife's Gitlab](https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib/), browse the link _Merge Requests_ in the left tool bar, use the button _New merge request_ on the top right and follow the instructions. Remember to create a merge request against the corresponding development branch and to add all the necessary information to ease the review process.

6. You may receive some feedback about your contribution and some iterations between the developers and you may be required before the issue is marked as solved and your contribution is incorporated into the library.


## Useful information
In this section you can find useful information for contributing to hiperlife.

### Labels
Labels are used by **developers** and **maintainers** to tag issues. There are three types of labels:
1. `priority:...`: To set the priority of the issue
2. `stage:...`: To set the current development stage of the issue
3. `topic:...`: List of topics covered by the issue
3. `type:...`: Type of issue

The list of labels and their description are detailed [here](https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib/-/labels).

### Milestones
Milestones are used to create a road map of the library and are managed by **maintainers**.

### Assignees
Issues are assigned to developers after they have been confirmed. **Developers** and **maintainers** are responsible for assigning them.

### Git branches
There are four types of branches in the library:
1. `master`: This branch points to the current release version of the library. This branch is protected: Only maintainers can merge and push.
2. `release-<N.n>-branch`: Branches with the releases of the library. `N` and `n` stand for the major and minor version of the release, respectively. These branches are protected: Only maintainers can merge and push.
3. `dev-v<N>`: Development branches. `N` stands for the major version under development. Note that there is no minor version. These branches are protected: Only maintainers can merge and push.
4. `dev-v<N>-<???>`: Feature or bug fix branches of development version `N`. `???` stands for the name of the topic. It should be precise and concise, such that a reader can have a general idea of topic -- similar to the names given to functions; for example `dev-v4-bsplinesFix` or `dev-v4-immersedMethod`. These branches are protected: Only maintainers and developers can merge and push.

The workflow is as follows (see examples [here](https://nvie.com/posts/a-successful-git-branching-model/) and [here](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow)): The library is developed in feature/bug branches. Developers create merge requests against development branches. Maintainers actually merge the branch when the issue is fixed. Finally, and according to the roadmap/milestones, maintainers create a new release branch which is merged against the master.
