## Version 4.4.0, released on March 17, 2023
[11 issues, 9 merge requests and 3 participants]
This version features a new of working with tensors, new search elements algorithms, and the immersed method in 3D, in addition to other improvements.

### Tensor indices
The tensor class now also works with indices! This new feature simplifies the user implementation of tensors as their manipulation is closer to the mathematical formulation
```c
using index::a, index::b, index::c;
tensor<int,1> vec2 = tensor1(a,b,c) * tensor2(a,b);
```

### Search element
We have implemented a new class (ElementLocator) with 4 different search element algorithms (implemented in VTKElementLocator, QuadtreeElementLocator, OctreeElementLocator, and BVHElementLocator). They are robust, more than one order of magnitude faster, and fully parallel. The class can be set from the DistributedMesh by setting one of the element locator engines, although it can also be instantiated separately.

### Immersed method
- Solve ill-conditioning in the immersed method using the aggregated method (extended basis function approach)
- Implement the immersed method in 3D. This includes
  - 3D preprocessing
  - 3D element identification
  - 3D balance
  - 3D non-conforming cut cell cubature

### Remesher
New implementation of the remesher in parallel for two-dimensional, structured meshes with square elements that uses the functions of threeRefinement. Note that this is still work in progress and should only be used by expert users.

### Other
- Update GUI to VTK version 9
- Specify the number of derivatives when calling compute basis functions
- New function `interpolatePosition` in the distributedMesh to interpolate the position of a point given the element and reference coordinates
- New function `closestPointProjection` in the distributedMesh to find the closest point projection of a point given its physical coordinates
- New set of functions to interpolate fields in a DOFsHandler given either the element and reference coordinates or the physical coordinates
- Minor changes to the threeRefinement function of square structured meshes
- New functions in the hl_Math and hl_Geometry classes
- First implementation of a class to invert a mapping given a field structure using the element locators. It is thought to invert the mapping in a Lagrangian description. This function is under develoment and is intended for expert users



### Version 4.3.0, released on October 11, 2022

### New utilities and classes
- New model utilities with constitutive model for linear elasticity, flexoelectricity (direct and Lifshitz invariants) and piezoelectricity
- TimeIterator: New class that allows to iterate over time. This class takes as input a solver (either linear or nonlinear). It has several time stepping schemes implemented: constant, linear adaptive and generalized-alpha based (the last one is still under development). The user can print the results using different methods and select the frequency of the print. In addition, the user can create a postprocess through a lambda function and write the results to a restart file
- New multipatch mesh generator that allows joining two or more meshes. Not yet working for BSplines/NURBS
- PredefinedElementFillings: New class that implements some basic element fillings so that the user doesn't need to implement them. Examples are: Laplace, Poisson, TransientDiffusion, LinearElasticity, AllenCahn, Biharmonic, TransientBiharmonic, CahnHilliard.

### Mesh generation
- Implementation of local mesh refinement in the StructMeshGenerator: 3 refinement for linear (Lagrangian) square elements
- Implementation of periodic boundary conditions for BSplines and NURBS up to 2nd order
- StructMeshGenerator: Improved generation of nurbs circular arcs. The code can now generate arcs whose continuity is the same as that of the requested bspline order, except for full circles
- Fix StructMeshcreator bug in ruled surface and squared line
- Implementation of unclamp for surfaces and solids
- New geometry int the StructMeshcreator: SolidQuarterPlateWithCylindricalHole
- New transformation for StructMeshcreator: extrudeSurfaceLinear
- New pRefinement method for structured meshes that works with non-straight element facets

### DOFsHandler
- New function to mirror fields. This function allows to create a pointer from one DOF in a DOFsHandler to another one in a different DOFsHandler. It avoids the need to copy DOFs between DOFsHandlers. It automatically updates ghosts.

### HiPerProblem
- New consistency check to check if the Jacobian is the derivative of the rayleghian
- When saving the global integrals to the elemAux field, the global integrals are now saved using the name tags

### Integration
- New cubature for border intersection. This cubature allows the integration of border intersections, defined by lines in 3D (for instance, the edge of a cube) or by points in 2D (for instance, the corner of a square).
- New function `SubFillStructure::normalsBoundaryRef()` to get the unit normals (in addition to the already existing tangents) to the reference elements for the border cubature and the border intersection cubature

### Solvers
- New line search based on energy/rayleghian in the Newtown-Raphson solver
- Added functions to linear and nonlinear solvers to access the timer, the errors, and the linear solver

### Immersed method
- Improvements in nonconforming integration (quadtree method) of cut elements in the immersed method in 2D

### Installation
- New installation scripts
- Added instructions for bashrc paths

### Other
- Fix deprecated warning in subfillstructure
- New IO with vtk in parallel. Main function: DistributedMesh::printFileVtk, DOFsHandler::printFileVtk. One ".vtm" file is produced (equivalent to ".pvtu") and each partition is stored in a single ".vtu". This has support for BSplines and nurbs for VTK version > 9.0.0. The vtm file can include field data such as time or global integrals. In Paraview (> 5.9.0) you can choose any of these fields in "Time Array".
- Fix tangents in border integrals for triangs and tetrahs
- Add auxiliary lambda functions to the user structure
- Performance improvement in MapBalance: Get several new/old ids at the same time
- New license
- Fix issue with lbz2 overwriting cxx flags (users must update hl_BaseProject)
- Fix bug when restarting with 1 or 2D BSplines
- GlobalConstraints: Fixes issue restarting global constraints



## Version 4.2.0, released on January 13, 2021
This version features two new mesh loaders for VTK and gmsh that work both in serial and parallel, significant advances in the immersed method and a first approximation to remeshing (check the limitations below). Also, there has been other improvements, minor bug fixes and function renaming

### Mesh generation and distribution
- The *MeshLoader* can now read VTK files in parallel. Each processor will read one part of the file (Note that the distribution of the resulting mesh is far from optimal, so a load balancing will be necessary in the distributedMesh). In order to take advantage of this feature use: `loadMesh(std::string name, MeshType meshType);` or `loadlegacyVTK(std::string name, MeshType meshType);`. For instance `myLoadedMesh->loadMesh("mesh.vtk", MeshType::Parallel);`. These functions overload the existing functions, to which we have added the second argument *meshType* that can be either `MeshType::Sequential` and `MeshType::Parallel`. To maintain compatibility with previous versions, if the second argument is not specified, `MeshType::Sequential` will be used as default.
- New *MeshLoader* for meshes created externally with gmsh. It works both in serial and in parallel with *.msh* files. In the parallel version, the mesh needs to be partitioned with gmsh and written in a separate file for each partition. Note that gmsh uses a similar technology for partitioning than that in hiperlife (metis/scotch), so there is no need to balance the mesh in the distributed mesh if you use the gmsh parallel loader. Examples: `myLoadedMesh->loadMesh("mesh_"+std::to_string(myRank+1)+".msh", MeshType::Parallel);`, `myLoadedMesh->loadGmsh("mesh.msh", MeshType::Sequential);`
- Now, in addition to h-refinement, you can use p-refinement with a mesh loaded in serial, provided that the mesh is formed by linear triangular elements
- Fix bug in the geometry `genRectangularParallelepiped(...)`. The z dimension was wrong
- New check that throws an error when trying to use periodic boundary conditions with BSplines, NURBS or subdivision surfaces
- Fixed bug when postprocessing periodic meshes
- New function in the *distributedMesh* that returns the coordinates of the corners of the reference element `std::vector<std::vector<double>> referenceCoordsElemCorners();`. Useful for element searching, cubatures related to the immersed method and postprocessing
- Generalization of the existing *searchElement* algorithm in parallel to any type of linear element. The function `searchElement(...)` finds the coordinates in reference space and element ID of a point. Note that this algorithm does not work for non-interpolant and higher-order basis functions and even for interpolant basis functions it is not fully robust. A new improved version is under development. For a robust (but serial) algorithm that works for interpolant basis functions, please use `searchElementVTK(...)` (see below)
- New function `searchElementVTK(...)` to find the coordinates in reference space and element ID of a point. It uses a VTK algorithm implemented to this end. Note that this algorithm does not work for non-interpolant and higher-order basis functions. Also, note that the VTK library does not work in parallel: all the mesh is gathered into one processor before searching, which is far from optimum and slow. This function is a temporal implementation that will be replaced by a fully-parallel, robust version in next releases.
- New function to interpolate the position of a point given its coordinates in reference space and the ID of the element. Example `vector<double> x = disMesh->interpolatePosition(elementID, {0.5, -0.2});`

### DOFsHandler
- New functions to interpolate fields (DOFs or auxiliary fields) at a point given its coordinates in reference space and ID of the element. Some examples are
`double dofValue = dofHand->interpolateField(dofHand->nodeDOFs, "u", elementID, {0.5, -0.2});`, `double dofValue = dofHand->interpolateDOFs("d", elementID, {0.5, -0.2});`, `double auxValue = dofHand->interpolateAuxF("a", elementID, {0.5, -0.2});`
- New function to add a value to a field using another field with the same number of components `void addValue(Teuchos::RCP<FieldStruct> otherFieldStruct)`
- The field *nodeDOFs0* is now stored in *.hl* files to be used in restarts

### Solvers
- MUMPS may fail when the linear system is large and stiff due to a lack in size of its internal workspace. MUMPS allocates this size by default to be 20% larger than an internal estimate. We have added an option to control it using the function: `setWorkSpaceMemoryIncrease(int mem)`. For example `solver->setWorkSpaceMemoryIncrease(40)` increments the size by 40% of the initial estimate
- When MUMPS fails it now shows why it has failed using code errors (see MUMPS user guide)
- Added an interface to MUMPS to control tolerance (`setTolerance(tol)`) and convergence criteria (`setConvergenceCriteria(ConvergenceCriteria conv)`). The convergence criteria can be either `ConvergenceCriteria::Absolute` or `ConvergenceCriteria::Relative`.
- All the linear solvers now output their default values if the user calls the function `setDefaultParameters()`, so that the user is aware of them
- The nonlinear Newton-Raphson solver now stops if it diverges. By default, the algorithm checks whether the solution error and/or the residual error is greater than the maximum double precision number of the machine. Its behavior can be fine-tuned through the following functions: `setResMaximum(double resMax)` and `setSolMaximum(double solMax)` set the maximum residual and solution errors, respectively, and `setExitRelMaximum(bool rel)` sets whether the maximum is in terms of relative or absolute error.

### Remesher
New class to remesh a *DOFsHandler*. An example of how to use this class is:
```cpp
RCP<Remesher> remesher = rcp(new Remesher);
remesher->setDOFsHandler(dofHand, {"u", "v"});
remesher->setRemeshMethod(RemeshMethod::Serial, 5.E-3);
remesher->setDefaultParameters();
remesher->Update();
remesher->newDOFsHands(dofHand);
```

This is a first approximation so be aware that:
- It works mostly in serial (not efficient in terms of speed and memory)
- only works for triangles, and
- it has low accuracy/may not work both for non-interpolant and higher-order basis functions.

Regardless of its limitations, it is fully functioning and can be used.

### Immersed method
- New algorithm for element identification (interior/exterior/boundary elements) that allows to use Lagrangian and BSplines as basis functions for the background mesh in 2D using square elements
- Background and immersed meshes are balanced in the *distributedMesh* in a solidary way
- New non-conforming cut cell cubature. It is implemented in 2D using a very simple algorithm that does not cover all possible cases, but most of them. When it encounters a case that cannot handle it throws an error. The error can be overcome through mesh refinement
- New cubature called *CubatureBorderImmersed* that throws integration points from the immersed to the background mesh using a Gauss cubature
- New *userDefinedCubature* aimed for developers. This cubature works by manually setting the integration points' coordinates and weights

### Tensor library
- New hard-coded versions of identity tensors 2x2 and 3x3
- New function that computes the inverse of a 3x3 tensor
- Fixed bug in transposed matrix tensor library (this bug was not affecting current users of the library)

### Name changes
We have introduced several name changes to functions, but the old ones have been kept to maintain backward compatibility: You can still use them, but you will get a warning during compilation saying that the function is deprecated and which one replaces it
- `loadMesh(std::string name)` -> `loadMesh(std::string name, MeshType meshType)`, which allows choosing between sequential or parallel load. In the meanwhile this function will default to meshType=MeshType::Sequential to be consistent with previous versions.
- `loadLegacyVTK(std::string name)` -> `loadLegacyVTK(std::string name, MeshType meshType)`, which allows choosing between sequential or parallel load. In the meanwhile this function will default to `meshType=MeshType::Sequential` to be consistent with previous versions.
- `setIndexType(IndexType indexType)` -> `setMeshType(MeshType meshType)`
- `vtkElemType(ElemType eType, BasisFuncType bfType, int bfOrder)` -> `hlToVtkElemType(ElemType eType, BasisFuncType bfType, int bfOrder)`
- `hplfeElemType(int vtkType)` -> `vtkTohlElemType(int vtkType)`
- In the class *hiperProblem*:
  - `setElemFillings` -> `setElementFillings`
  - `setUserStruct(..)` -> `setUserStructure(..)`
  - `setGlobInteg(..)` -> `setGlobalIntegrals(..)`
  - `userStr()` -> `userStructure()`
  - `globIntegral(..)` -> `globalIntegral(..)`
  - `globIntegrals()` -> `globalIntegrals()`
  - `globIntegralNames()` -> `globalIntegralNames()`
  - `getCompHiPerIndex(..)` -> `complexHiPerIndex(..)`
- In the classes *FillStructure* and *SubFillStructure*:
  - `addContribGlobInteg(..)` -> `addToGlobalIntegral(..)`
  - `getDer(order)` -> `nborBasisFunctionsDerivatives(order)` or `nborBFsDers(order)`
  - Also, take a look below (section "Other") for specific functions to get the basis functions, its gradients and hessians
- In *AztecOOIterativeLinearSolver*
  - `setPrecond(Precond prec)` -> `setPreconditioner(Preconditioner prec)`
  - `setConvergence(Convergence conv)` -> `setConvergenceCriteria(ConvergenceCriteria conv)`
- In *BelosIterativeLinearSolver*
  - `setPrecond(Precond prec)` -> `setPreconditioner(Preconditioner prec)`
  - `setPrecondSide(PrecondSide precSide)` -> `setPreconditionerSide(PreconditionerSide precSide)`

### Other
- New functions to get derivatives of the basis functions
  - `getDer(0)` -> `nborBasisFunctions()` or `nborBFs()`
  - `getDer(1)` -> `nborBasisFunctionsGradients()` or `nborBFsGrads()`
  - `getDer(2)` -> `nborBasisFunctionsHessians()` or `nborBFsHess()`
- New function in *GlobalBasisFunctions* to compute the global third derivatives
- Fixed minor bug in the function `findSpan` of BSplines and NURBS basis functions
- New functions in the math library to solve small linear systems of 2 and 3 equations `SolveEq2x2` and `SolveEq3x3`
- New function to convert from gmsh to hiperlife element type `gmshTohlElemType(int gmshType, ElemType &eType, BasisFuncType &bfType, int &bfOrder)`
- Fixed minor but in *CMakeLists.txt* that was throwing an error when *Trilinos_TPL* was empty
- Changes in *CMakeLists.txt* that make it easier to run in MareNostrum supercomputer and new script (*cmake.hiperlife.marenostrum.sh*) to help users configuring the library there
- Fix bug in the computation of the tangents for parallelepiped elements for boundary integration
- Update INSTALL.md with the instructions to compile hiperlife with MUMPS 5.3.5


## Version 4.1.3, released on July 01, 2020
- Fix bug in MUMPs (see issue #150)


## Version 4.1.2, released on June 13, 2020
- Fix bug in UnstructVtkMeshGenerator
- Fix bug in tensor library


## Version 4.0.1, released on June 13, 2020
- Fix bug in UnstructVtkMeshGenerator
- Fix bug in tensor library


## Version 4.1.1, released on May 13, 2020
This version patches some bugs in the previous release including bugs in UnstructVtkMeshGenerator, installation and documentation.

### Mesh generation and distribution
- Fix bug in UnstructVtkMeshGenerator

### Documentation and installation
- Add configuration scripts for MUMPS, trilinos and hiperlife in the folder `scripts`
- Fix compilation fail when there are no trilinos TPLs

### Other
- Move the contents of build/.gitignore to the main .gitignore in the root so that the bulk deletion of the contents of the build folder does not remove the .gitignore
- Remove mainDoc.doc from the folder Basics


## Version 4.1.0, released on April 30, 2020
The main features of this version are a new direct linear solver, a new mesh creator and updated installation instructions with installation scripts.

### Mesh generation and distribution
- Every mesh generator has now an indexType that characterizes whether the variables are local or globlal. This helps internally in creating the distributed meshes.
- New mesh creator: _BasicMeshGenerator_. It that allows expert users to create meshes by providing all the variables of the mesh from the application, rather than using specific geometries. This mesh creator has a setter for every variable of the mesh, like the elements, nodes or connectivity.

### Solvers
- New linear solver: _MUMPSDirectLinearSolver_. This solver is an interface to the MUMPS library, but opposed the other packages from Trilinos that interface with MUMPS, it has a richer set of options:
   - It allows to use all the external ordering libraries (metis, parmetis, scotch, ptscotch) in addition to the internal ordering libraries from MUMPS
   - It works with symmetric matrices
   - It works in parallel

   An example of how to set this solver is:
   ```cpp
     RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
     solver->setHiPerProblem(hiperProbl);
     solver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General); //General, POD or Symmetric
     solver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Parallel); //Sequential or parallel
     solver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto); //Many options here
     solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
     solver->setDefaultParameters();
     solver->Update();
   ```
   The details of the solver and its options are available in the doxygen documentation.


### Documentation
- New set of installation instructions for trilinos and mumps
- New scripts for the installation of mumps, trilinos and hiperlife in the folder `scripts`


## Version 4.0.0, released on February 27, 2020
The main changes in this version are related to the hiperproblem and the solvers, but there has also been a redesign of the logo and name of the library and many additions to prepare the code for the upcoming implementation of the immersed method. Also, the _README_ and _INSTALLATION_ files have been updated and a new contributing guide has been added.

The hiperproblem has been significantly simplified by removing the integration types (they were used to specify the relationship between different DOFsHandlers within an integration) which are now deduced internally. Linear solvers have been moved from the hiperproblem to their own class and include many types of solvers and preconditioners (see documentation). Also, nonlinear solvers have been implemented.

### Mesh generation and distribution
- New geometry: _genPolygonalCurve()_
- Fixes in unclamped and revolution geometries
- The distributed mesh is prepared to handle the immersed method. There is a new mesh relation, called _Immersed_. If specified, both meshes will be balanced together and the elements and nodes will be labeled (internal, external or boundary).

### DOFsHandler
- Generalize the use of DOFs and auxiliary fields name tags in the constraints, initial and boundary conditions, such that there is no need to reference the degree of freedom (or auxiliary field) by number in these functions.
- Use _setDOFs()_ instead of _setNumDOFs()_ when strings are specified for the names of the degrees of freedom

### New cubatures
- _CubatureCutCellNonConforming_: This cubature creates integration points in an element by recurrent subdivision of the element into equal-sized subelements. The subelements are only subdivided (until a given maximum number of subdivisions) if they are cut by a geometry.
- _CubatureBorderImmersed_: Used in the immersed method to integrate the border of the background mesh using integration points from the immersed mesh.
- _CubatureBasic_: This cubature does not have any integration rules. Both the coordinates of the integration points and the weights need to be provided (as well as the element type to compute the parametric dimension).

### hiperproblem
- Added support for integration in the border along specific axes
- Change function name from _setIntegration_ElemFillings()_ to _setElemFillings()_.
- New functions to get the values of the global integrals (_globalIntegrals()_) and their names (_globalIntegralNames()_)
- _getSolValue()_ has been renamed to _solValue()_
- Global variables are now placed in the last processor. This reordering helps direct solvers such as MUMPS to reduce memory usage during solving step.

### Solvers
- Linear solvers: New class with:
  1. Iterative solvers, like conjugate gradients or GMRES (see documentation for a complete list) based on two trilinos packages (AztecOO and Belos).
  2. Direct solvers, like KLU or MUMPs (see documentation for a complete list) based on two trilinos packages (Amesos and Amesos2).
- Non-linear solvers: New class with Newton-Raphson nonlinear solver with optional use of line search

### Model utils
- Many model util functions now work with tensors
- New namespace (_GlobalBasisFunctions_) for functions that work with global basis functions. These functions take the subfill structure as the only input argument instead of the long list of arguments that was used in previous versions.
- Added support for higher-order derivatives in _OffSetParam_

### IO and postproc
- IO now supports the addition of a vector of global values that can be useful to plot with paraview, for example, to have the information of the global integrals.

### Miscellaneous
- CMakeList has been re-implemented. It has an improved output, has been prepared to work with a version of trilinos installed from the repository and finds third party libraries better. It is also more flexible as it has more flags to let the user decide what to compile.
- New repository ([hl_BaseProject](https://git.lacan.upc.edu/HPLFEusers/hl_BaseProject)) that exemplifies how to create projects that use hiperlife
- Deleted unused tutorials
- Change every occurrence of _HPLFE_ to _hl_
- Change output of the linear solvers and ability to choose between verbosity levels (none, low, medium, and high)

## Version 3.1, released on June 14, 2019
This version includes many changes throughout the library. The main contributions are:

1. New **graphical user interface** (GUI) to hiperlife, which is working for simple cases such us the Poisson problem. The GUI is not fully stable yet.
2. New **tensor library** which simplifies significantly the implementation of the element filling, as in the tutorials. The old third-party tensor library has been removed as the new one is more versatile and flexible.
3. There are two new unstructured mesh creators: one based on the **vtk** library and the other based on the **gmsh** library. Their usage is exemplified in the tutorials.
4. Implementation of a consistency check for the matrix (hessian). In brief, it checks if the implementation of the matrix is the hessian of the right-hand side using a finite difference method. It has two parameters which can be set in the hiperproblem with the functions _setConsistencyCheckDelta()_ and _setConsistencyCheckTolerance()_. See the documentation to see how to use it.
5. Major improvements in **BSpline and NURBS** basis functions, that include load balance of meshes with these basis functions and a full integration with hiperlife's input/output.

In the following we detail the remaining changes in this version.

### Mesh generation and distribution
- Mesh creators have to be declared as _rcp_ pointers, as the remaining classes of hiperlife. Consequently, the distributed mesh only accepts _rcp_s as arguments.
- New one-liner setter for the mesh creator: _setMesh(ElemType eType, BasisFuncType bfType, int bfOrder)_.
- Implemented affine and free transformations for every _MeshCreator_
- Periodic boundary conditions for Langrangian basis functions
- All meshes can now be printed on screen using the function _printMesh()_
- The _meshLoader_ now checks if the provided file exists, guesses the type of file by its extension using the function _loadMesh(filename)_ and has support for reading high-order Lagrangian elements.
- New geometries in the _structMeshGenerator_: ruled surface and square boundary
- Added option in the distributed mesh to set the master processor of a global constraint

### DOFsHandler
- The DOFsHandler has now three main variables: the degrees of freedom and the element auxiliary filed (which already existed) and the new auxiliary node field. Also, everyone of them can now be defined with a vector of names which will be used for the input/output and postprocess function, ie. they will show up in paraview.
- Remove all values by default in constraints.

### hiperproblem
- Major changes in the interface for setting different cubatures (see tutorials).
- Changed the name of the function _AddRHSToSolution()_ to _AddSolutionToDOF()_.

### IO and postproc
- Change the extension of hiperlife's output files from '.dat' to '.hl'
- Added support for auxiliary element and node fields, arbitrary-order Lagrange elements that can be visualized in paraview 5.6 or higher, and BSplines and Nurbs basis functions
- Time can now be specified for the output and is used in postproc and it is read in the input

### Miscellaneous
- doxygen appearance has been modified with hiperlife's colors and font.
- The existing documentation is now available in PDF.
- ue_nodes0 has been renamed to nborDOFs0, following the changes in version 3.0
- Added vector of booleans to the userStructure


## Version 3.0, released on December 21, 2018
Huge changes to the library that include: huge changes to the interface,
addition of tutorials, Neumann boundary conditions, mesh generation,
improvements in BSplines and Nurbs basis function, new cubatures, integration of
solvers and licenses.

### Details
- Tutorials: hiperlife has now a set of tutorials that include: Poisson2D,
  TransientHeatEquation2D, CahnHilliard, PatternFormation, HelfrichMembrane,
  PoissonSurfaceNeumann, StokesProblem_GeneralDim and
  StokesProblem_SubdivSurfaces.
- Neumann boundary conditions can be used now.
- The mesh generator is now a mesh creator that includes loading (MeshLoader)
  and generating (StructMeshGenerator) meshes. There are many new predefined
  geometries (easter egg included).
- BSplines and Nurbs basis functions have been improved.
- Cubatures: There are two new cubatures, one for subdivision surfaces
  (CubatureIrregSubdivSurf) and one for integrating at the boundary of a mesh
  (CubatureBorderGauss).
- Solvers are now integrated within the library.
- Improved documentation

### Interface
* HiPerMechanics -> HiPerProblem, Mechanics -> DOFsHandler
* mech -> dhand, mechs -> dhands
* Every DOFS/DoFs -> DOFs
* MeshGenerator -> StructMeshGenerator
* K -> Ak, rhs->Bk and the access to Bk is a function
* Enum class


## Version 2.1, released on November 26, 2018
Release that incorporates Linear Constrains, improved mesh generator and the use of tags

### Details
- Linear Constrains can be used from HiPerMechanics.
- First version of BSplines and Nurbs included, maybe presents memory scalability issues.
- Mesh Generator huge improvement with new features, nurbs generator and cleaning up.
- FieldStructs can be used with Tags that help to keep track of them.
- Added documentation
- Removed annoying warnings
- Added First version of tutorials: Laplace2D, Stokes_SubdivisionSurfaces and
  Stokes_GeneralDimension: to be improved in the next release.
- Added functions to convert from reference element coordinates to physical ones.
- New option to adjust the imbalance tolerance of the LoadBalance from DistributedMesh interface.
- Added auxiliar fields defined at elements in Mechanics.

### Interface
- Minimal changes


## Version 2.0, released on September 27, 2018
=Major release that changes completely the structure of hiperlife

### Details
- Mechanics are now only a container of Mesh and DoFS
- Different Mechanics can interact via a HiPerMechanics, that is the object that solves one Linear System
- The element integrations are performed in Integrations object, they could exists several in one HiPerMechanics
- All of the previous allows to have equations with different meshes interacting (Lagrange Multipliers and Global Constraints)
- Include MeshGenerator class to replace POD functions


### Interface
- Big change in the creations of apps since the structure of hiperlife is completely different



## Version 1.0, released on December 27, 2017
Major release that is fully working for problems in an unique grid.

### Details
- Complete restructuration of the internal structure of AdjcyStruct and FieldStruct
- Implementation of Subdivision Surfaces
- Implementation of Lagrangian FE of squares(any dim, any order) and triangles(any dim/up to order 3).
- Parallel Input/Output in HPLFE format
- Consistency Check in Mechanics
- SparseMatrix class for local/serial computations.
- Modular PostProc package for converting results to vtk, parallel and legacy.
- In PostProc vtk library is needed (also boost)
- Added for xml support the pugixml library (can be found in ThirdParty)
- MeshGenerator for elements of arbitrary order. The one generating triangles works in parallel.


### Interface
- Removed the need of creating the structure of the matrix and for the communication of the ghosts
    after creating the Mechanics object.
- The number of vertices is not longer needed for creating the DistributedMesh and it will be
    infered from the other information.
- All the headers has been updated with the prefix HPLFE_
