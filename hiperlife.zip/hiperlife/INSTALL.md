<div align="center">
![hiperlife logo](doc/img/logo_wtitle_white.svg "hiperlife")
</div>

<br>

# New Installation instructions (work in progress)
_hiperlife_ is an MPI-based parallel library that works on top of [the Trilinos Project](https://trilinos.org/): a set of packages developed in the Sandia National Laboratory (USA) for large-scale engineering and scientific problems. Thus, some of the prerequisites to install _hiperlife_ are a modern C++ MPI compiler, the Trilinos library and its dependencies and CMake to build the project. _hiperlife_ also has some extra optional dependencies that enhance some of its features, like meshing or postprocessing.

This intructions are valid for Ubuntu 22.04 as this distribution is the only one that is guaranteed to work.
Even that, hiperlife is expected to run in almost any Linux and macOS systems.

The following steps describe how to install _hiperlife_:

1. Install the requirements
2. Compile and install _hiperlife_


### Requirements

To correctly compile and install hiperlife in your system,
it needs some dependencies that are available through the distribution repositories:

**General dependencies**
```bash
sudo apt-get install git gcc g++ gfortran cmake libopenmpi-dev libboost-filesystem-dev liblapack-dev libscalapack-openmpi-dev
```
<br>

**Required by Scotch**
<br>
```bash
sudo apt-get install flex bison yacc
```
<br>

**Required by VTK**
```bash
sudo apt-get install qtbase5-dev libgl1-mesa-dev libopengl-dev libglx-dev
```


### Installation of hiperlife
In order to work properly, hiperlife required some libraries like Trilinos (mandatory), Gmsh, VTK, Scotch and MUMPS (optional).
By default, all of these dependencies are downloaded, compiled and installed directly by the hiperlife's build system.
To do that, from the hiperlife source path, create a build folder, execute cmake and compile:
```bash
mkdir build
cd build
cmake .. -DCMAKE_INSTALL_PREFIX=<path/to/install/hiperlife>
make -jX dependencies
```
Be aware that this will take some time as some dependencies are very heavy to download and compile (mainly Trilinos and VTK).

If you want to disable any of the dependencies or use the ones already installed in your computer, you can do it by adding some options to **cmake**:
```bash
cmake .. -DENABLE_XX=OFF -DXX_BASE_PATH=<path/to/XX/dependency>
```

Once all the dependencies are ready, hiperlife can be compiled and installed just with:
```bash
cmake ..
make -jX install
```

# Old Installation instructions
_hiperlife_ is an MPI-based parallel library that works on top of [the Trilinos Project](https://trilinos.org/): a set of packages developed in the Sandia National Laboratory (USA) for large-scale engineering and scientific problems. Thus, some of the prerequisites to install _hiperlife_ are a modern C++ MPI compiler, the Trilinos library and its dependencies and CMake to build the project. _hiperlife_ also has some extra optional dependencies that enhance some of its features, like meshing or postprocessing.

The following steps describe how to install _hiperlife_:

1. Install the requirements [↦](#requirements)
2. Install the optional dependencies [↦](#optional-dependencies)
3. Compile and install _hiperlife_ [↦](#hiperlife-installation)

_**Remark:** If your operative system is Ubuntu 19.04 or higher you can install all the requirements and optional dependencies using the repositories following the installation instructions [here](#installation-using-the-repositories-for-ubuntu-1904). Please, note that in this case you **will not** be able to use the parallel version of the MUMPS solver._

_**Remark 2:** Remember to tell your OS the location of the installed libraries. For UNIX systems you can add the paths of these libraries to the environment variable LD_LIBRARY_PATH. To avoid adding the paths to each terminal session, you can put these instructions in the bashrc file. As an example, the following code is an extract of the bashrc file in which we are appending the paths to the usr, gmsh, vtk, trilinos and hiperlife libraries and then exporting the environment variable LD_LIBRARY_PATH._
```bash
# Paths to libraries
LD_LIBRARY_PATH=/usr/lib:$LD_LIBRARY_PATH
LD_LIBRARY_PATH=$HOME/local/gmsh/lib:$LD_LIBRARY_PATH
LD_LIBRARY_PATH=$HOME/local/vtk/lib:$LD_LIBRARY_PATH
LD_LIBRARY_PATH=$HOME/local/trilinos/lib:$LD_LIBRARY_PATH
LD_LIBRARY_PATH=$HOME/local/hiperlife/lib:$LD_LIBRARY_PATH

export LD_LIBRARY_PATH

#Num threads                                                                                                                                   
export OMP_NUM_THREADS=1
```
_* Note that at the end we are setting the number of threads to be used by openmp to zero as an extra precaution to prevent openmp vs MPI conflicts_

After the installation you can work with the [tutorials](./Tutorials) or create a new project following the instructions in the repository [hl_BaseProject](https://git.lacan.upc.edu/HPLFEusers/hl_BaseProject).

<!--create tutorials apps-->

Requirements
------------

* **CMake** 2.8.0 or higher. Install from the repositories
* **C++ compiler** (both g++ and clang have been tested). Install from the repositories
* **Fortran compiler** (requirement of Trilinos). Install from the repositories
* **BLAS and LAPACK**. Install from the repositories
* **MPI**. Please, follow the installation instructions below
* **Trilinos** 12.14 or higher. Please, follow the installation instructions below


### Installing MPI

The simplest way of getting a distribution of MPI is to download it from the repositories. If this is not possible or the version is too old, you can get the latest version of OpenMPI from:
    https://www.open-mpi.org/software
and install it following the steps mentioned in the documentation.

**Very important**, before installing OpenMPI, make sure that the gfortran compiler is installed.


### Installing Trilinos

The following instructions install the needed packages for _hiperlife_.

1. Download the code of Trilinos directly from the [repository](https://github.com/trilinos/trilinos) or clone it using git:
`git clone https://github.com/trilinos/Trilinos.git`. We recommend version 12.18, which is the one we have tested. If you have cloned the repository, run the command `git checkout trilinos-release-12-18-branch` to compile this version.

2. Create an empty build folder in the root of the library:
    ```bash
    cd <path/to/trilinos>
    mkdir build
    cd build
    ```

3. In the build folder, configure Trilinos with CMake. We recommend to adapt one of the configuration files that we provide in `</path/to/hiperlife>/scripts/`. The basic options are:
   ```bash
   cmake \
       -D BUILD_SHARED_LIBS:BOOL=YES              \
       -D CMAKE_INSTALL_PREFIX=$INSTALL           \
       -D CMAKE_C_FLAGS="-march=native -O3"       \
       -D CMAKE_CXX_FLAGS="-march=native -O3"     \
       -D CMAKE_FORTRAN_FLAGS="-march=native -O3" \
       -D CMAKE_BUILD_TYPE:STRING=RELEASE         \
       -D CMAKE_SKIP_INSTALL_RPATH:BOOL=ON        \
       -D CMAKE_SKIP_RPATH:BOOL=ON                \
       -D TPL_ENABLE_MPI:BOOL=YES                 \
       -D MPI_C_COMPILER:FILEPATH=mpicc           \
       -D MPI_CXX_COMPILER:FILEPATH=mpicxx        \
       -D MPI_FORTRAN_COMPILER:FILEPATH=mpif90    \
       -D Trilinos_ENABLE_OpenMP:BOOL=OFF         \
       -D Trilinos_ENABLE_ALL_PACKAGES=ON         \
       -D Trilinos_ENABLE_TESTS=OFF               \
       -D TPL_ENABLE_Netcdf=OFF                   \
       -D TPL_ENABLE_Boost=OFF                    \
       ..
   ```
   Other options:
    * Disable non-used packages:
        ```bash
        -DTrilinos_ENABLE_Panzer=OFF -DTrilinos_ENABLE_Teko=OFF -DTrilinos_ENABLE_ML=OFF -DTrilinos_ENABLE_Pliris=OFF -DTrilinos_ENABLE_Komplex=OFF -DTrilinos_ENABLE_NOX=OFF -DTrilinos_ENABLE_LOCA=OFF -DTrilinos_ENABLE_ROL=OFF -DTrilinos_ENABLE_MOOCHO=OFF -DTrilinos_ENABLE_Piro=OFF -DTrilinos_ENABLE_Rythmos=OFF -DTrilinos_ENABLE_TriKota=OFF -DTrilinos_ENABLE_OptiPack=OFF -DTrilinos_ENABLE_GlobiPack=OFF -DTrilinos_ENABLE_Anasazi=OFF -DTrilinos_ENABLE_Sacado=OFF -DTrilinos_ENABLE_Stokhos=OFF -DTrilinos_ENABLE_Claps=OFF -DTrilinos_ENABLE_Moertel=OFF -DTrilinos_ENABLE_PyTrilinos=OFF -DTrilinos_ENABLE_ForTrilinos=OFF -DTrilinos_ENABLE_WebTrilinos=OFF -DTrilinos_ENABLE_Stratimikos=OFF -DTrilinos_ENABLE_FEI=OFF -DTrilinos_ENABLE_Mesquite=OFF -DTrilinos_ENABLE_PAMGEN=OFF -DTrilinos_ENABLE_Intrepid=OFF -DTrilinos_ENABLE_Intrepid2=OFF -DTrilinos_ENABLE_STK=OFF -DTrilinos_ENABLE_Galeri=OFF -DTrilinos_ENABLE_Optika=OFF -DTrilinos_ENABLE_SEACAS=OFF -DTrilinos_ENABLE_Phalanx=OFF -DTrilinos_ENABLE_Shards=OFF -DTrilinos_ENABLE_Tempus=OFF -DTrilinos_ENABLE_MueLu=OFF
        ```
    * Enable metis ordering library (if installed from repositories there is no need to specify `METIS_LIBRARY_DIRS`)
        ```bash
        -DTPL_ENABLE_METIS:BOOL=YES -DMETIS_LIBRARY_DIRS:PATH="${METIS_LIB}"
        ```
    * Enable parmetis ordering library (if installed from repositories there is no need to specify `ParMETIS_LIBRARY_DIRS`)
        ```bash
        -DTPL_ENABLE_ParMETIS:BOOL=YES -DParMETIS_LIBRARY_DIRS:PATH="${PARMETIS_LIB};${METIS_LIB}"
        ```
    * Enable scotch ordering library (if installed from repositories there is no need to specify `SCOTCH_LIBRARY_DIRS`)
        ```bash
        -DTPL_ENABLE_SCOTCH:BOOL=YES -DSCOTCH_LIBRARY_DIRS:PATH="${SCOTCH_LIB}"
        ```
    * Enable ptscotch and scotch ordering library (if installed from repositories there is no need to specify `SCOTCH_LIBRARY_DIRS`)
        ```bash
        -DTPL_ENABLE_SCOTCH:BOOL=YES -DSCOTCH_LIBRARY_DIRS:PATH="${PTSCOTCH_LIB}"
        ```
    * Enable MUMPS solver
        ```bash
        -DTPL_ENABLE_MUMPS:BOOL=YES -DAmesos2_ENABLE_MUMPS:BOOL=YES
        ```
        - On Ubuntu, if you have installed MUMPS using the repositories, you will need to add the option
           ```bash
           -DMUMPS_LIBRARY_NAMES='dmumps_ptscotch;mumps_common_ptscotch;lapack;scalapack-openmpi;metis;parmetis;ptscotch;scotch;scotcherr;ptesmumps;esmumps;pord;'
           ```
        - If MUMPS was not installed using the repositories, you need to add
           ```bash
           -D MUMPS_LIBRARY_NAMES='dmumps;mumps_common;scalapack;lapack;pord;metis;parmetis;scotch;scotcherr;ptscotch;ptscotcherr;ptesmumps' -D MUMPS_LIBRARY_DIRS="${MUMPS_LIB};${SCALAPACK_LIB};${METIS_LIB};${PARMETIS_LIB};${PTSCOTCH_LIB};${MPI_DIR}"
           ```

4. Compile Trilinos:
    ```bash
    make -j<X>
    ```

5. Install
    ```bash
    make install
    ```


Optional dependencies
------------------

* **Git**: For version control. Use the repositories for the installation
* **Boost libraries**: For postprocessing. Use the repositories for the installation
* **Scotch/Ptscotch**: Ordering library. Please, follow the installation instructions [below](#installing-scotchptscotch)
* **Metis/Parmetis**: Ordering library. Please, follow the installation instructions [below](#installing-metisparmetis)
* **MUMPS**: Direct solver. Please, follow the installation instructions [below](#installing-mumps)
* **VTK library**: For unstructured mesh creation, postprocessing and graphical user interface. Please, follow the installation instructions [below](#installing-vtk)
* **Gmsh library**: For unstructured mesh creation. Please, follow the installation instructions [below](#installing-gmsh)
* **Qt5**: For the graphical user interface. Please, follow the installation instructions [below](#installing-qt5)
* **doxygen**: For the documentation. Please, follow the installation instructions [below](#installing-doxygen)


### Installing Scotch/Ptscotch
These libraries can be installed from the repositories. For Ubuntu use `sudo apt install libscotch-dev libptscotch-dev`.

In order to use the last version you will need to install them from source following the instructions below. Note that we provide some `Makefile.inc` configuration files in `</path/to/hiperlife>/scripts/`, which may be adapted to your needs.

```bash
git clone --recursive https://gitlab.inria.fr/scotch/scotch.git
cd scotch
git submodule init
git submodule update
cd src
cp </path/to/hiperlife>/scripts/Makefile.scotch.???.inc . #Copy the appropiate configuration file and modify if needed
make clean
rm ../bin
rm ../lib
rm ../include
make ptscotch ptesmumps
make prefix=</path/to/install> install #Replace with installation path
```

### Installing Metis/Parmetis
These libraries can be installed from the repositories. For Ubuntu use `sudo apt install libmetis-dev libparmetis-dev`.

In order to use the last version you will need to install them from source. TODO.

### Installing MUMPS

The simplest way to install MUMPS is from the repositories.
- Ubuntu >= 18.04: `sudo apt install libmumps-ptscotch-dev`
- Ubuntu < 18.04:  `sudo apt install libmumps-ptscotch-dev` (not tested, and probably not working as the version of MUMPS is 4.10)
- Other OS: TODO

However, these versions of MUMPS (the ones in the repositories) are not the last ones and they do not include the ordering libraries metis and parmetis. There is a **significant** difference in parallel efficiency in the last versions, so we recommend to install them. To do so, first you will need to install the ordering libraries [scotch/ptscotch](#installing-scotchptscotch) and [metis/parmetis](#installing-mestis/parmetis) and the follow the instructions below. Note that we provide some `Makefile.inc` configuration files in `</path/to/hiperlife>/scripts/`, which may be adapted to your needs.
```bash
wget http://mumps.enseeiht.fr/MUMPS_5.3.5.tar.gz
tar zxvf MUMPS_5.3.5.tar.gz
cd MUMPS_5.3.5
cp </path/to/hiperlife>/scripts/Makefile.MUMPS.???.inc . #Copy the appropiate configuration file and modify if needed
make
cp lib/* </path/to/install/mumps>/lib #Replace </path/to/install/mumps> with appropiate path
cp include/* </path/to/install/mumps>/include #Replace </path/to/install/mumps> with appropiate path
cp Makefile.inc </path/to/install/mumps>/etc #Replace </path/to/install/mumps> with appropiate path
```

### Installing VTK

+ Standard VTK (version >= 7)
   + For Ubuntu >= 16.04: `sudo apt install libvtk7-dev`
   + For other older Ubuntu versions (and other OS?): Install from sources. Follow the instructions in https://vtk.org/Wiki/VTK/Configure_and_Build
+ VTK with qt (VTK version >= 8 and only checked for version 8.2 downloaded):
   Follow the instructions in https://vtk.org/Wiki/VTK/Configure_and_Build.
   In short: Download (https://vtk.org/download/) or clone the repository (https://gitlab.kitware.com/vtk/vtk) and

   ```bash
   cd </path/to/source>
   mkdir build
   cd build
   cmake -DCMAKE_INSTALL_PREFIX=</path/to/install/vtk> \
         -DVTK_Group_Qt=ON                             \
         -DBUILD_SHARED_LIBRARIES=ON                   \
         -DCMAKE_BUILD_TYPE=Release                    \
         ../
   make -j<X> install
   ```

### Installing Gmsh

Gmsh (http://gmsh.info/) is a three-dimensional finite element mesh generator with built-in pre- and post-processing facilities. It can be used within _hiperlife_ to generate unstructured meshes. Follow the instructions to install it:

1. Download the code of Gmsh directly from the [repository](https://gitlab.onelab.info/gmsh/gmsh) or clone it using git:
    `git clone https://gitlab.onelab.info/gmsh/gmsh.git`

2. Create an empty build folder in the root of the library:
    ```bash
    cd <path/to/gmsh>
    mkdir build
    cd build
    ```

3. In the build folder, configure Gmsh with CMake:
    ```bash
    cmake -DCMAKE_INSTALL_PREFIX=/path/to/install   \
          -DENABLE_BUILD_DYNAMIC=ON                 \
          ../
    ```
4. Compile Gmsh:
    ```bash
    make -j<X>
    ```

5. Install
    ```bash
    make install
    ```

### Installing qt5

- For Ubuntu 16.04 19.04 and Debian 10: `sudo apt install libqt5x11extras5-dev qttools5-dev`
- Other OS: TODO

### Installing doxygen
TODO

<!--
### Installing GiNaC
`sudo apt install libcln-dev libginac-dev`
-->



hiperlife installation
--------------------

1. Download the code of from the [repository](http://git.lacan.upc.edu/HPLFEgroup/hiperlifelib) or clone it using git:

    `git clone git@git.lacan.upc.edu:HPLFEgroup/hiperlifelib.git`

2. Create an empty build folder in the root of the library:
    ```bash
    cd <path/to/hiperlife>
    mkdir build
    cd build
    ```
3. In the build folder, configure _hiperlife_ with CMake. We recommend to adapt one of the configuration files that we provide in `</path/to/hiperlife>/scripts/`.
    ```bash
    cmake -DTRI_BASE_PATH=</path/to/trilinos/installation/path/>   \
          -DCMAKE_INSTALL_PREFIX=</path/to/install/hiperlife>      \
          ../
    ```
    Other options:
    * The build type can be chosen as Release (default) or Debug with
        `-DCMAKE_BUILD_TYPE=<Release/Debug>`
    * The compilation of tests can be enabled or disabled (default) with
        `-DCOMPILE_TESTS=<ON/OFF>`
    * The compilation of tutorials can be enabled (default) or disabled with:
        `-DCOMPILE_TUTORIALS=<ON/OFF>`
    * The compilation of the GUI can be enabled (default) or disabled with:
        `-DCOMPILE_GUI=<ON/OFF>`
    * If you have installed mpi from source add:
        `-DMPI_BASE_PATH=</path/to/mpi/installation/path/>`
    * If you want to use VTK add:
        `-DVTK_BASE_PATH=</path/to/vtk/installation/path/>`
    * If you want to use Gmsh add:
        `-DGMSH_BASE_PATH=</path/to/Gmsh/installation/path/>`

4. Compile _hiperlife_:
    ```bash
    make -j<X>
    ```

5. Install
    ```bash
    make install
    ```

6. Build the documentation (doxygen needs to be installed)
    ```bash
    make doc
    ```


Installation using the repositories for Ubuntu 19.04
----------------------------------------------------

<!--
### Ubuntu 14.04

There is no trilinos and vtk version = 5


### Ubuntu 16.04

Requirements: `sudo apt install git cmake libptscotch-dev trilinos-all-dev`

Optional dependencies?: `sudo apt install libmumps-dev libsuperlu-dev libhdf5-openmpi-dev libtbb-dev`

Optional for postprocess: `sudo apt install libvtk7-dev libboost-filesystem-dev`

Utils: `sudo apt install cmake-curses-gui`

**Caveats:** Load balancing and MUMPS not working


### Ubuntu 18.04

Requirements: `sudo apt install git cmake libptscotch-dev trilinos-all-dev`

Optional dependencies: `sudo apt install libvtk7-dev libboost-filesystem-dev`

Utils: `sudo apt install cmake-curses-gui`


**Caveats:** Load balancing and MUMPS not working

### Ubuntu 19.04
-->

Requirements: `sudo apt install git cmake libptscotch-dev trilinos-all-dev`

Optional dependencies: `sudo apt install libvtk7-dev libboost-filesystem-dev libqt5x11extras5-dev qttools5-dev`

Utils: `sudo apt install cmake-curses-gui`

**Caveats:** MUMPS not working
