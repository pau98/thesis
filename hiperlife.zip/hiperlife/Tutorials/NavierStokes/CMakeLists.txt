#------------------------------------------------------------
# CMakeLists for Tutorial NavierStokesProblem
#------------------------------------------------------------

get_filename_component(folder ${CMAKE_CURRENT_LIST_DIR} NAME)


file(GLOB SOURCES_CPP *.cpp)


set(exName "hl${folder}")
add_executable(${exName} ${SOURCES_CPP})
target_link_libraries(${exName} ${HPLFE_LIBRARIES})

if(VTK_FOUND)
    if(VTK_DOWNLOADING)
        include_directories(${VTK_INCLUDE_DIRS})
    endif(VTK_DOWNLOADING)
    target_link_libraries(${exName} ${VTK_LIBRARIES})
endif()


install(TARGETS ${exName} DESTINATION ${TUTORIALS_DIR_INSTALL})
