/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


////////////////////////////////////////////////////////////////////////
///                                                                  ///
///  The aim of this tutorial is to acquaint the users with          ///
///  users with the following features: (i) ternsor library,         ///
///  (ii) periodic bc, (iii) non-linear solver by solving the        ///
///  steady state Navier Stokes equation                             ///
///                                                                  ///
////////////////////////////////////////////////////////////////////////


// C++ headers
#include <iostream>

// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_Tensor.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"

#include "hl_GlobalBasisFunctions.h"

void LS(hiperlife::FillStructure& fillStr);

int main(int argc, char** argv)
{
    using namespace std;
    using namespace hiperlife;


    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    hiperlife::Init(argc, argv);

    // String data structures to store prefixes of the pressure and velocity output files
    string solname_v, solname_p;
    string oname = "NavierStokes";

    // Set test case
    //   testCase == 0 is a shear test
    //   testCase == 1 is a test with rotational flow induced by shear fluid in a confined cavity
    int testCase = 1;

    // Model parameters
    double Re    = 1.E2; // Reynold's number

    // Mesh-related parameters
    ElemType elemType           = ElemType::Triang;
    BasisFuncType basisFuncType = BasisFuncType::Lagrangian;
    int basisFuncOrderP         = 1;
    bool pRefin                 = false;
    int ne                      = 60;
    bool balanceMesh            = true;


    // **************************************************************//
    // *****                  MESH CREATION                     *****//
    // **************************************************************//

    // Declare the Meshes for Velocity and Pressure
    SmartPtr<DistributedMesh> disMeshVeloc = Create<DistributedMesh>();
    SmartPtr<DistributedMesh> disMeshPress = Create<DistributedMesh>();

    // Declare the Mesh Generator
    SmartPtr<StructMeshGenerator> meshGen = Create<StructMeshGenerator>();
    if (testCase == 0)
    {
        if (elemType == ElemType::Square or elemType == ElemType::Triang)
            meshGen->setPeriodicBoundaryCondition({Axis::Xaxis});
        else
            meshGen->setPeriodicBoundaryCondition({Axis::Xaxis,Axis::Zaxis});
    }
    // Set NDim: Always 3
    meshGen->setNDim(3);
    // Choose shape of elements
    meshGen->setElemType(elemType);
    // Choose type of Basis Functions
    meshGen->setBasisFuncType(basisFuncType);
    // Choose the order of the BF
    meshGen->setBasisFuncOrder(basisFuncOrderP);
    // Function that creates a squarefrom (0,1) to (1,1) in all directions
    meshGen->genStructMesh(ne);

    // Constructing the velocity DistributedMesh with the StructMeshGenerator
    // Set the Mesh Generator
    disMeshPress->setMesh(meshGen);
    // Enable Load Balance
    disMeshPress->setBalanceMesh(balanceMesh);
    // Create the DistributedMesh
    disMeshPress->Update();

    // Constructing the pressure DistributedMesh through the previous one
    if (pRefin)
    {
        disMeshVeloc->setMeshRelation(MeshRelation::pRefin, disMeshPress);
        disMeshVeloc->setPRefinement(1);
    }
    else
    {
        disMeshVeloc->setMeshRelation(MeshRelation::hRefin, disMeshPress);
        disMeshVeloc->setHRefinement(1);
    }
    // Enable Load Balance
    disMeshVeloc->setBalanceMesh(balanceMesh);
    // Create the DistributedMesh
    disMeshVeloc->Update();


    // **************************************************************//
    // *****              DOFsHANDLER CREATION                  *****//
    // **************************************************************//

    SmartPtr<DOFsHandler> dhandV = Create<DOFsHandler>(disMeshVeloc);
    SmartPtr<DOFsHandler> dhandP = Create<DOFsHandler>(disMeshPress);
    try
    {
        // Velocity DOFsHandler
        dhandV->setNameTag("dhandV");     // Set the tag that will be used later to identify this object
        if (disMeshVeloc->pDim() == 2)
            dhandV->setDOFs({"vx", "vy"});
        else
            dhandV->setDOFs({"vx", "vy", "vz"});
        dhandV->Update();                 // Create the object

        // Pressure DOFsHandler
        dhandP->setNameTag("dhandP");     // Set the tag that will be used later to identify this object
        dhandP->setDOFs({"p"});           // Set the number of degrees of freedom of this object
        dhandP->Update();                 // Create the object

        cout << dhandV->myRank() << ":  DOFsHandler for Velocity and Pressure successfully created. " << endl;
    }
    catch (runtime_error& err)
    {
        cout << dhandV->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;
        MPI_Abort(dhandV->comm(), 1);
    }

    // Set boundary conditions for the velocity
    if (testCase == 0)
    {
        for (int i = 0; i < dhandV->mesh->loc_nPts(); i++)
        {
            if (disMeshVeloc->isNodeInMAxis(MAxis::Ymax, i, IndexType::Local))
            {
                dhandV->nodeDOFs->setValue(0,i,IndexType::Local,Re);
                dhandV->nodeDOFs->setValue(1,i,IndexType::Local,0.E0);
                dhandV->setConstraint(0,i,IndexType::Local,0.0);
                dhandV->setConstraint(1,i,IndexType::Local,0.0);
            }
            if (disMeshVeloc->isNodeInMAxis(MAxis::Ymin, i, IndexType::Local))
            {
                dhandV->nodeDOFs->setValue(0,i,IndexType::Local,0.E0);
                dhandV->nodeDOFs->setValue(1,i,IndexType::Local,0.E0);
                dhandV->setConstraint(0,i,IndexType::Local,0.0);
                dhandV->setConstraint(1,i,IndexType::Local,0.0);
            }
        }
    }
    else
    {
        for (int i = 0; i < dhandV->mesh->loc_nPts(); i++)
        {
            if (disMeshVeloc->isNodeInMAxis(MAxis::Ymax, i, IndexType::Local))
                dhandV->nodeDOFs->setValue(0,i,IndexType::Local,Re);
        }
        dhandV->setBoundaryCondition(0.0);
    }

    // Set boundary conditions for the pressure
    if (disMeshPress->myRank() == 0)
        dhandP->setBoundaryCondition(0,0,IndexType::Local,0.0);

    // Save into nodeDOFS0
    dhandP->nodeDOFs0->setValue(dhandP->nodeDOFs);
    dhandV->nodeDOFs0->setValue(dhandV->nodeDOFs);

    // After changing node information, it is important to update the ghost nodes
    dhandV->UpdateGhosts();
    dhandP->UpdateGhosts();


    // **************************************************************//
    // *****         HIPERPROBLEM & SOLVER CREATION             *****//
    // **************************************************************//

    // Create hiperproblem
    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>("HiperObject");
    hiperProbl->setDOFsHandlers({dhandV, dhandP});
    hiperProbl->setIntegration("IntegStokes", {"dhandV", "dhandP"});
    hiperProbl->setElementFillings("IntegStokes", LS);
    if (elemType==ElemType::Square)
        hiperProbl->setCubatureGauss("IntegStokes", 4);
    else if (elemType==ElemType::Triang)
        hiperProbl->setCubatureGauss("IntegStokes", 3);
    else if (elemType==ElemType::Parallelep)
        hiperProbl->setCubatureGauss("IntegStokes", 8);
    else if (elemType==ElemType::Tetrah)
        hiperProbl->setCubatureGauss("IntegStokes", 6);
    hiperProbl->Update();

    // Create linear solver
    SmartPtr<MUMPSDirectLinearSolver> linSolver = Create<MUMPSDirectLinearSolver>();
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // Create non-linear solver
    SmartPtr<NewtonRaphsonNonlinearSolver> nonlinSolver = Create<NewtonRaphsonNonlinearSolver>();
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(25);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->Update();


    // **************************************************************//
    // *****                      SOLVE                         *****//
    // **************************************************************//

    // Output initial condition
    string solName = oname + ".0";
    dhandV->printFileLegacyVtk("velocityBC", true);
    dhandP->printFileLegacyVtk("pressureBC", true);

    // Initial guess
    dhandV->nodeDOFs->setValue(dhandV->nodeDOFs0);
    dhandP->nodeDOFs->setValue(dhandP->nodeDOFs0);
    hiperProbl->UpdateGhosts();

    // Solve
    bool converged = nonlinSolver->solve();

    // Check convergence
    if (converged)
    {
        // Save solution
        dhandV->nodeDOFs0->setValue(dhandV->nodeDOFs);
        dhandP->nodeDOFs0->setValue(dhandP->nodeDOFs);

        // Write results and update solution
        solname_v = oname + "v";
        solname_p = oname + "p";
        dhandV->printFileLegacyVtk(solname_v, true);
        dhandP->printFileLegacyVtk(solname_p, true);
    }


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    hiperlife::Finalize();
    return 0;
}

void LS(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //-----------------------------------------------------------
    // [1] INPUT DATA
    //-----------------------------------------------------------

    // [1.1] Velocity-related
    auto& subFill = fillStr["dhandV"];
    int pDim = subFill.pDim;
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;
    wrapper<double,2> nborDOFs(subFill.nborDOFs.data(),eNN,numDOFs);
    wrapper<double,1> bf(subFill.nborBFs(),eNN);
    tensor<double,2> Dbf_g(eNN,pDim);
    double jac{};
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

    // [1.2] Pressure-related
    auto& subFill_p = fillStr["dhandP"];
    int nDim_p = subFill_p.nDim;
    int eNN_p  = subFill_p.eNN;
    wrapper<double,2> nborCoords_p(subFill_p.nborCoords.data(),eNN_p,nDim_p);
    wrapper<double,1> nborDOFs_p(subFill_p.nborDOFs.data(),eNN_p);
    wrapper<double,1> bf_p(subFill_p.nborBFs(),eNN_p);

    //-----------------------------------------------------------
    // [2] OUTPUT
    //-----------------------------------------------------------

    wrapper<double,2> Bk0(fillStr.Bk(0).data(),eNN,numDOFs);
    wrapper<double,1> Bk1(fillStr.Bk(1).data(),eNN_p);
    wrapper<double,4> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    wrapper<double,3> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN_p);
    wrapper<double,3> Ak10(fillStr.Ak(1,0).data(),eNN_p,eNN,numDOFs);

    //-----------------------------------------------------------
    // [3] VARIABLES
    //-----------------------------------------------------------

    // [3.1] Velocity and pressure
    tensor<double,1> v  = bf * nborDOFs;
    double  pre = bf_p * nborDOFs_p;

    // [3.2] Velocity gradient
    tensor<double,2> Dv = product(nborDOFs,Dbf_g,{{0,0}});
    double divv = trace(Dv);

    // [3.3] Rate-of-deformation tensor
    tensor<double,2> rodt = 0.5*(Dv + Dv.transpose({1,0}));
    tensor<double,4> dvrodt = 0.5 * (outer(Dbf_g,Identity(pDim)).transpose({0,3,1,2}) + outer(Dbf_g,Identity(pDim)).transpose({0,3,2,1}));

    //-----------------------------------------------------------
    // [4] Fill right- and left-hand side
    //-----------------------------------------------------------

    // [4.1] Shear dissipation
    Bk0 += jac * product(rodt,dvrodt,{{0,2},{1,3}});
    Ak00 +=  jac  * product(dvrodt,dvrodt,{{2,2},{3,3}});

    // [4.2] Pressure as lagrange multiplier
    Bk0 += (jac * pre) * Dbf_g ;
    Bk1 += (jac * divv) * bf_p ;
    Ak01 += jac * outer(Dbf_g,bf_p) ;
    Ak10 += jac * outer(bf_p,Dbf_g) ;

    // [4.3] Advective term
    Bk0 +=  -jac * outer(bf,v*Dv.T());
    Ak00 += -jac * (outer(outer(bf,Dv),bf) + outer(outer(bf,Identity(pDim)),v*Dbf_g.T())).transpose({0,1,3,2});
}
