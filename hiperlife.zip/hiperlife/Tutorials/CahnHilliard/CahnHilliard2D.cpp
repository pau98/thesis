/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

// C headers
#include <iostream>
#include <random>
// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_GlobalBasisFunctions.h"

struct CahnHilliardParams
{
    enum RealParameters
    {
        deltat,
        mobility,
        epsilon2
    };

    HL_PARAMETER_LIST DefaultValues
    {
        {"deltat", 1.E-7},
        {"mobility", 1.0},
        {"epsilon2", 0.00005},
    };
};


void ElementFillingCahnHilliard(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::I, ttl::index::J;
    using ttl::index::n, ttl::index::i;

    // Parameters
    const double deltat   = fillStr.getRealParameter(CahnHilliardParams::deltat);
    const double mobility = fillStr.getRealParameter(CahnHilliardParams::mobility);
    const double epsilon2 = fillStr.getRealParameter(CahnHilliardParams::epsilon2);

    // Rename variables
    SubFillStructure& subFill = fillStr["dhand"];
    int DOF   = subFill.numDOFs;
    int eNN   = subFill.eNN;
    int nDim  = subFill.nDim;
    int pDim  = subFill.pDim;
    wrapper<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);
    wrapper<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, DOF);
    wrapper<double, 2> nborDOFs0(subFill.nborDOFs0.data(), eNN, DOF);

    // Shape functions and derivatives at Gauss points
    double jac;
    wrapper<double, 1> bf(subFill.nborBFs(), eNN);
    tensor<double, 2> dbf(eNN, pDim);
    tensor<double, 3> d2bf(eNN, pDim, pDim);
    tensor<double, 1> lapbf(eNN);
    GlobalBasisFunctions::hessians(dbf, jac, d2bf, lapbf, subFill);

    // Values at integration points
    tensor<double, 1> x = nborCoords(I, i) * bf(I);
    tensor<double, 1> gphi = nborDOFs(I, 0) * dbf(I, i);
    double phi = nborDOFs(I, 0) * bf(I);
    double phin= nborDOFs0(I, 0) * bf(I);
    double lapphi = nborDOFs(I, 0) * d2bf(I, i, i);

    // Double well and derivatives
    double   W = (phi*phi)*(1.0-phi)*(1.0-phi)/4.0;
    //double   dW = phi*(1.0-phi)*(1.0-2.0*phi)/2.0;
    double d2W = (1.0-6.0*phi+6.0*phi*phi)/2.0;
    double d3W = (-1.0+2.0*phi)*3.0;

    wrapper<double, 2> Bk(fillStr.Bk(0).data(), eNN, DOF);
    Bk(I, 0) = jac * (bf(I) * (phi-phin) / deltat + mobility * d2W * dbf(I, i) * gphi(i) + mobility * epsilon2 * lapbf(I) * lapphi);

    wrapper<double, 4> Ak(fillStr.Ak(0, 0).data(), eNN, DOF, eNN, DOF);
    Ak(I, 0, J, 0) = jac * (bf(I) * bf(J) / deltat + mobility * d3W * bf(J) * dbf(I, i) * gphi(i) + mobility * d2W * dbf(I, i) * dbf(J, i)
                            + mobility * epsilon2 * lapbf(I) * lapbf(J)) ;

    // Add to global integral
    fillStr.addToGlobalIntegral("ChemicalFreeEnergy", jac*W);
    fillStr.addToGlobalIntegral("SurfaceFreeEnergy", jac*0.5*epsilon2*Math::SNorm(pDim, gphi.data()));
    fillStr.addToGlobalIntegral("GinzburgLandauFreeEnergy", jac*(W + 0.5*epsilon2*Math::SNorm(pDim, gphi.data())));
    fillStr.addToGlobalIntegral("Mass", jac*phi);
}


int main(int argc, char *argv[])
{
    using namespace std;
    using namespace hiperlife;

    // Initialize MPI
    hiperlife::Init(argc, argv);
    const int myRank = hiperlife::MyRank();

    // Model parameters
    SmartPtr<ParamStructure> userStr = CreateParamStructure<CahnHilliardParams>();

    // Mesh-related parameters
    BasisFuncType bfType = BasisFuncType::BSplines;
    ElemType eType = ElemType::Square;
    int bfOrder = 2;
    int gPts = pow(bfOrder+1, computePDim(eType));
    int nEl = 50;

    // Time-related parameters
    string oname = "CahnHilliard.";
    double maxTime  = 10000000;
    double maxNStep = 10000000;
    double maxDelt  = 10000000;
    double stepFactor = 0.95;
    int nSave = 5;

    // Generate mesh
    SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();
    try
    {
        structMesh->setMesh(eType, bfType, bfOrder);
        structMesh->genStructMesh(nEl);
        structMesh->setPeriodicBoundaryCondition({Axis::Xaxis, Axis::Yaxis});
    }
    catch (runtime_error& err)
    {
        std::cout << "Error: Mesh could not be generated.";
        hiperlife::Finalize();
        return 1;
    }

    // Create distributed mesh
    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    try
    {
        disMesh->setMesh(structMesh);
        disMesh->Update();

        if(VerboseRank()) cout << disMesh->myRank() << ":   Distributed Mesh successfully created. " << endl;
    }
    catch (runtime_error& err)
    {
        if(VerboseRank()) cout << disMesh->myRank() << ":   Distributed Mesh could not be created. " << err.what() << endl;

        hiperlife::Finalize();
        return 1;
    }

    // Print mesh
    disMesh->printFileLegacyVtk("Mesh");

    // DOFsHandler
    SmartPtr<DOFsHandler> fields = Create<DOFsHandler>(disMesh);
    try
    {
        fields->setNameTag("dhand");
        fields->setDOFs({"rho"});
        fields->Update();

        if(VerboseRank()) cout << fields->myRank() << ":   DOFsHandler successfully created. " << endl;
    }
    catch (runtime_error& err)
    {
        if(VerboseRank()) cout << fields->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;

        hiperlife::Finalize();
        return 1;
    }

    // Initial and boundary conditions
    for (int i = 0; i < fields->mesh->loc_nPts(); i++)
    {
        double r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        fields->nodeDOFs0->setValue(0, i, IndexType::Local, 0.6+0.3*r);
    }

    fields->UpdateGhosts();

    // Create HiPerProblem
    SmartPtr<HiPerProblem> problem = Create<HiPerProblem>();
    try
    {
        // Set UserStructure
        problem->setParameterStructure(userStr);

        // Set DOFHandler
        problem->setDOFsHandlers({fields});

        // Set Integration
        problem->setIntegration("Integ", {"dhand"});
        problem->setCubatureGauss("Integ", gPts);
        problem->setElementFillings("Integ", ElementFillingCahnHilliard);

        // Set global integral
        problem->setGlobalIntegrals({"ChemicalFreeEnergy", "SurfaceFreeEnergy", "GinzburgLandauFreeEnergy", "Mass"});

        // Update
        problem->Update();
    }
    catch (runtime_error& err)
    {
        if(VerboseRank()) cout << myRank << ": HiPerProblem could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

    // Create linear solver
    SmartPtr<MUMPSDirectLinearSolver> linSolver = Create<MUMPSDirectLinearSolver>();
    linSolver->setHiPerProblem(problem);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // Create nonlinear solver
    SmartPtr<NewtonRaphsonNonlinearSolver> nonlinSolver = Create<NewtonRaphsonNonlinearSolver>();
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-4);
    nonlinSolver->setSolTolerance(1.E-4);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    // Print initial condition
    fields->nodeDOFs->setValue(fields->nodeDOFs0);
    fields->printFileLegacyVtk(oname + to_string(0), false);
    fields->printFile(oname + to_string(0), OutputMode::Text, true, 0.0, problem->globalIntegrals());

    // Open file to write global integrals and write headers
    ofstream gIntegFile;
    gIntegFile.open ("globalIntegrals.csv");
    gIntegFile << "TS time deltat";
    for (auto g: problem->globalIntegralNames())
        gIntegFile << " " << g;
    gIntegFile << endl;

    // Loop over time steps
    double time{0.0};
    int timeStep{0};
    double ener_prev{1.E8};
    double& deltat = userStr->getRealParameter(CahnHilliardParams::deltat);

    while ((timeStep < maxNStep) and (time < maxTime))
    {
        // Write
        if (fields->myRank() == 0)
            cout << endl << " TS: " << to_string(timeStep) << " Time " << time <<  " Delta " << deltat << endl;

        // Initial guess
        fields->nodeDOFs->setValue(fields->nodeDOFs0);
        problem->UpdateGhosts();

        // Newton-Raphson method
        nonlinSolver->solve();

        // Check convergence
        if (nonlinSolver->converged() and problem->globalIntegral("GinzburgLandauFreeEnergy") <= ener_prev)
        {
            // Save solution
            fields->nodeDOFs0->setValue(fields->nodeDOFs);

            // Update variables
            timeStep ++;
            if (deltat > maxDelt)
                deltat = maxDelt;
            deltat /= stepFactor;
            if (deltat >= maxDelt)
                deltat = maxDelt;
            time += deltat;
            ener_prev = problem->globalIntegral(2);

            // Write results
            if (timeStep % nSave == 0)
            {
                string solName = oname + to_string(timeStep);
                fields->printFileLegacyVtk(solName, false);
                fields->printFile(solName, OutputMode::Text, true, time, problem->globalIntegrals());
            }

            // Write global integrals
            if(VerboseRank())
            {
                gIntegFile << timeStep << " " << time << " " << deltat;
                for (auto g: problem->globalIntegrals())
                    gIntegFile  << " " << g;
                gIntegFile << endl;
            }
        }
        else
        {
            // Correct time-step size
            deltat *= stepFactor;
        }

        // Check steady-state
        if (deltat < 1.e-14)
            break;
    }

    // Close file
    gIntegFile.close();

    // Finalize
    hiperlife::Finalize();
    return 0;
}
