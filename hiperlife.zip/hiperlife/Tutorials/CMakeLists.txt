#------------------------------------------------------------
# Source files for HiPerLIFE Tutorials
#------------------------------------------------------------

message(STATUS "Configuring Tutorials")

include_directories(SYSTEM "${Trilinos_INCLUDE_DIRS}")
include_directories(SYSTEM "${HPLFE_INCLUDE_DIRS}")

file(GLOB SUBDIRS ${CMAKE_CURRENT_LIST_DIR}/*)

add_subdirectory(Poisson)
add_subdirectory(PoissonSurfaceNeumann)
if(VTK_FOUND AND BUILD_GREEK_INDICES)
  add_subdirectory(ViscousInextMembrane)
endif()
add_subdirectory(CahnHilliard)
add_subdirectory(NavierStokes)

add_custom_target(Tutorials)
add_dependencies(Tutorials hlPoisson)
add_dependencies(Tutorials hlPoissonSurfaceNeumann)
if(VTK_FOUND AND BUILD_GREEK_INDICES)
  add_dependencies(Tutorials hlViscousInextMembrane)
endif()
add_dependencies(Tutorials hlCahnHilliard)
add_dependencies(Tutorials hlNavierStokes)
