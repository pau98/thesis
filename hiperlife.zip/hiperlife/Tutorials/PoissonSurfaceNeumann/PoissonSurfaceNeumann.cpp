/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


////////////////////////////////////////////////////////////////////////
///                                                                  ///
/// The aim of this tutorial is to show the basic structure of       ///
///   hiperlife by solving Poisson's equation:                       ///
///   Δu = f                                                         ///
///                                                                  ///
////////////////////////////////////////////////////////////////////////



// C++ headers
#include <iostream>
#include <fstream>

// hiperlife headers
#include "hl_Core.h"
#include "hl_ParamStructure.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_MeshLoader.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_SurfLagrParam.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"

struct PoissonParams
{
    enum RealParameters
    {
        strength
    };

    enum StringParameters
    {
        filemesh
    };

    HL_PARAMETER_LIST DefaultValues{
            {"filemesh", ""},
            {"strength", 1.0},
    };
};

// Function that fills the elemental linear system of the problem. It
//   is declared here but implemented at the bottom.
void LS(hiperlife::FillStructure& fillStr);
void RHS_Border(hiperlife::FillStructure& fillStr);

// In this first tutorial everything is implemented inside the main
//   function
int main(int argc, char** argv)
{
    using namespace std;
    using namespace hiperlife;


    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize the MPI execution environment
    hiperlife::Init(argc, argv);

    // Define parameters of the model
    SmartPtr<ParamStructure> paramStr = ReadParamsFromCommandLine<PoissonParams>();


    // **************************************************************//
    // *****                  MESH CREATION                     *****//
    // **************************************************************//

    // Create structured mesh
    SmartPtr<StructMeshGenerator> mesh = Create<StructMeshGenerator>();
    mesh->setElemType(ElemType::Triang);
    mesh->setBasisFuncType(BasisFuncType::Lagrangian);
    mesh->setBasisFuncOrder(2);
    mesh->genSquare(4,1.0);

    // Distributed mesh
    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Create DOFsHandler
    SmartPtr<DOFsHandler> dofHand = Create<DOFsHandler>(disMesh);
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->setNumElemAuxF(1);
    dofHand->Update();

    // Set constraints
    if (!disMesh->hasBorder())
    {
        if (disMesh->myRank() == 0)
            dofHand->setConstraint(0, 0, IndexType::Local, 0.0);
    }
    else
    {
        for (int i = 0; i < disMesh->loc_nPts(); i++)
        {
            if (disMesh->nodeCrease(i, IndexType::Local) > 0 and
                disMesh->nodeCoord(i, 1, IndexType::Local) > 0)
                dofHand->setConstraint(0,i,IndexType::Local, 0.0);
        }
    }
    dofHand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // Create hiperproblem
    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();

    // Set parameter structure and DOFsHandler
    hiperProbl->setParameterStructure(paramStr);
    hiperProbl->setDOFsHandlers({dofHand});

    // Set integration in the bulk
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ",3);
    hiperProbl->setElementFillings("Integ", LS);

    // Set integration on the border
    hiperProbl->setIntegration("BorderInteg", {"dofHand"});
    hiperProbl->setCubatureBorderGauss("BorderInteg",2,{MAxis::Xmax,MAxis::Ymin});
    hiperProbl->setElementFillings("BorderInteg", nullptr, nullptr, RHS_Border);

    // Integrate the domain border length
    hiperProbl->setGlobalIntegrals({"BorderLength"});

    // Update
    hiperProbl->Update();


    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    // Set solver
    SmartPtr<AztecOOIterativeLinearSolver> solver = Create<AztecOOIterativeLinearSolver>();
    solver->setHiPerProblem(hiperProbl);
    solver->setTolerance(1.E-8);
    solver->setMaxNumIterations(500);
    solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::Neumann);
    solver->setDefaultParameters();
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->Update();

    // Solve
    solver->solve();
    solver->UpdateSolution();

    // Print solution
    dofHand->printFileLegacyVtk("PoissonSurface");

    // Print global integral
    if (dofHand->myRank() == 0)
        cout << std::scientific << std::setprecision(5) << "Border Length = " << hiperProbl->globalIntegral("BorderLength");

    // This is an example of how to print the solution as a txt (same is valid for the rhs and the system matrix)
    ofstream rhsFile;
    rhsFile.open(paramStr->getStringParameter(PoissonParams::filemesh)+to_string(dofHand->myRank())+".txt");
    hiperProbl->sol->Print(rhsFile);
    rhsFile.close();


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    hiperlife::Finalize();
    return 0;
}

void LS(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    // Get parameters
    double strength = fillStr.getRealParameter(PoissonParams::strength);

    // Rename variables
    SubFillStructure& subFill = fillStr["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& nborCoords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFs();                   // Local shape function
    double* dbf_l = subFill.nborBFsGrads();            // Local shape function derivatives

    // Position in Euclidean space of the Gauss point
    double x[3]={};
    for (int i = 0; i < eNN; i++)
    {
        for (int n = 0; n < nDim; n++)
        {
            x[n] += nborCoords[i*nDim+n] * bf[i];
        }
    }

    // Compute metric tensor
    double g_cc[4]={};  // Metric tensor (covariant components cc)
    double xu[3]={};    // Tangent vector 1
    double xv[3]={};    // Tangent vector 2
    SurfLagrParam::MetricTensor(g_cc, xu, xv, eNN, nborCoords.data(), dbf_l);

    // Compute inverse of the metric tensor
    double g_CC[4]={};  // Inverse of the metric tensor (contravariant components)
    Math::Invert2x2(g_CC, g_cc); // Compute the inverse

    // Compute jacobian
    double jac = sqrt(Math::DetMat2x2(g_cc));

    // Generate a source
    double source = strength * x[1]*cos(3.0*M_PI*x[0]);

    //=====================  Fill linear system =====================//
    //
    // We loop through the neighboring nodes to fill both the matrix
    //   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        // Pointer to the local gradients of the basis functions of node I
        double* dbf_lI_c = &dbf_l[pDim*i];

        // Compute g^{ab} dbf_lI_c_b
        double dbf_lI_C[2]={};
        Math::MatProduct(dbf_lI_C, 2, 2, 1, g_CC, dbf_lI_c);

        for (int j = 0; j < eNN; j++)
        {
            // Pointer to the local gradients of the basis functions of node J
            double* dbf_lJ_c = &dbf_l[pDim*j];

            // Fill matrix
            fillStr.Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * Math::Dot2D(dbf_lI_C, dbf_lJ_c);
        }

        // Fill RHS
        fillStr.Bk(0)[i*DOF] += jac * bf[i] * source;
    }

    return;
}

void RHS_Border(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    // Variables
    SubFillStructure& subFill = fillStr["dofHand"];
    int DOF  = subFill.numDOFs;                      // Number of degrees of freedom
    int eNN  = subFill.eNN;                          // Number of nodes of the neighborhood
    int nDim = subFill.nDim;                         // Dimension of the space of the problem
    vector<double>& nborCoords = subFill.nborCoords; // Vector of node coordinates
    double *bf  = subFill.nborBFs();                 // Basis functions
    double *dbf_l = subFill.nborBFsGrads();          // Local basis function derivatives

    // Position in Euclidean space of the Gauss point
    double x[3]={};
    for (int i = 0; i < eNN; i++)
    {
        for (int n = 0; n < nDim; n++)
        {
            x[n] += nborCoords[i*nDim+n] * bf[i];
        }
    }

    // Compute Tangent Map
    double Ip[4], xu[3], xv[3];
    SurfLagrParam::MetricTensor(Ip, xu, xv, eNN, nborCoords.data(), dbf_l);

    // Compute jacobian
    auto bTangentRef = subFill.tangentsBoundaryRef();
    double bTangent[3]={};
    for (int n = 0; n < nDim; n++)
        bTangent[n] = bTangentRef[0] * xu[n] + bTangentRef[1]*xv[n];
    double jac = Math::Norm3D(bTangent);

    // Fill RHS
    for (int i = 0; i < eNN; i++)
        fillStr.Bk(0)[i*DOF] += jac*bf[i];

    // Compute border length
    fillStr.addToGlobalIntegral("BorderLength", jac);
}
