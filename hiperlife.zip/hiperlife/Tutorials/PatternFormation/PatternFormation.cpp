/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


////////////////////////////////////////////////////////////////////////
///                                                                  ///
/// This tutorial shows:                                             ///
///   1) How to deal with several degrees of freedom.                ///
///   2) How to deal with transient equations.                       ///
///   3) How to take advantage of exception errors.                  ///
///   4) Post-process??????????                                      ///
///                                                                  ///
/// To this end, we are going to solve the following system of       ///
///   reaction-diffusion equations:                                  ///
///     du/dt = D_u*Δu + F(u,v) - d_u*v                              ///
///     dv/dt = D_v*Δv + G(u,v) - d_v*v                              ///
///   with                                                           ///
///     F(u,v) = a_u*u + b_u*v + c_u                                 ///
///     G(u,v) = a_v*u + b_v*v + c_v                                 ///
/// [Kondo & Miura, Science (2010) DOI:10.1126/science.1179047]      ///
///                                                                  ///
///  This tutorial has three files:                                  ///
///    - PatternFormation.cpp (this file), that contains the         ///
///        function main with the structure of the code.             ///
///    - AuxPatFor.cpp, with the implementation of the linear        ///
///        system, and some other useful functions.                  ///
///    - AuxPatFor.h, with the headers of the auxiliary functions.   ///
///                                                                  ///
////////////////////////////////////////////////////////////////////////


/// C++ headers
#include <iostream>
#include <mpi.h>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_Geometry.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"

/// Header to auxiliary functions
#include "AuxPatFor.h"

using namespace hiperlife;
using Teuchos::rcp;
using Teuchos::RCP;

int main()
{

    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    // Parameters of the model
    double D_u =  0.02;
    double d_u =  0.03;
    double a_u =  0.08;
    double b_u = -0.08;
    double c_u =  0.04;
    double D_v =  0.50;
    double d_v =  0.08;
    double a_v =  0.10;
    double b_v =  0.0;
    double c_v = -0.15;

    // Time related parameters
    double deltat  = 0.05;
    int maxNSteps  = 10000;
    double maxTime = 10000;
    int nsave      = 100;

    //Put parameters in UserStructure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(11);
    userStr->dparam[0] = D_u;
    userStr->dparam[1] = d_u;
    userStr->dparam[2] = a_u;
    userStr->dparam[3] = b_u;
    userStr->dparam[4] = c_u;
    userStr->dparam[5] = D_v;
    userStr->dparam[6] = d_v;
    userStr->dparam[7] = a_v;
    userStr->dparam[8] = b_v;
    userStr->dparam[9] = c_v;
    userStr->dparam[10] = deltat;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Mesh generator
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    try
    {
        structMesh->setNDim(3);
        structMesh->setBasisFuncType(BasisFuncType::Lagrangian);
        structMesh->setBasisFuncOrder(1);
        structMesh->setElemType(ElemType::Line);
        structMesh->genStructMesh(100);
        structMesh->scale(100.0);
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": MeshGenerator could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

    // Distribute mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    try
    {
        disMesh->setMesh(structMesh);
        disMesh->setBalanceMesh(true);
        disMesh->Update();
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": DistributedMesh could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }



    // **************************************************************//
    // *****               DOFHANDLER CREATION                  *****//  //FIXME: Change name in this section
    // **************************************************************//
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    try
    {
        dofHand->setNameTag("dofHand");
        dofHand->setNumDOFs(2);
        dofHand->Update();
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": DOFHandler could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

    //Set initial conditions
    for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    {
        double r{};
        r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        double value_u = 3.0+2.0*r;
        r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        double value_v = 3.0+2.0*r;
        // double x[2];
        // x[0] = disMesh->nodeCoord(i, 'x', IndexType::Local);
        // value_u = 5.0 + 5.0 * tanh((50.0 - Math::Norm2D(x)) / 10.0);
        // x[1] = disMesh->nodeCoord(i, 'y', IndexType::Local);
        // value_v = 0.0;
        dofHand->nodeDOFs->setValue(0, i, IndexType::Local, value_u);
        dofHand->nodeDOFs->setValue(1, i, IndexType::Local, value_v);
    }

    //Set boundary conditions
    // dofHand->setBoundaryCondition(0, 0.0);
    // dofHand->setBoundaryCondition(0, Xmax, 1.0);
    // dofHand->setBoundaryCondition(0, Ymin, [](double x){return x;});
    // dofHand->setBoundaryCondition(0, Ymax, [](double x){return x*x;});
    // dofHand->setBoundaryCondition(1, 0.0);
    // dofHand->setBoundaryCondition(1, Xmax, 1.0);
    // dofHand->setBoundaryCondition(1, Ymin, [](double x){return x;});
    // dofHand->setBoundaryCondition(1, Ymax, [](double x){return x*x;});
    dofHand->UpdateGhosts();

    //Print initial conditions
    string solName = "Pattern.0";
    dofHand->printFileLegacyVtk(solName, true);


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//  //FIXME: Change name in this section
    // **************************************************************//

    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    try
    {
        // Set UserStructure
        hiperProbl->setUserStructure(userStr);

        // Set DOFHandler
        hiperProbl->setDOFsHandlers({dofHand});

        // Set Integration
        hiperProbl->setIntegration("Integ", {"dofHand"}, {IntegType::Master});
        hiperProbl->setCubatureGauss("Integ", 4);
        hiperProbl->setIntegration_ElemFillings("Integ", LS);

        // Set solver
        hiperProbl->setSolver(PDEType::Linear, LinSolverType::AztecOO);
        hiperProbl->setSolverOptions({{"precond", "Jacobi"}});
        hiperProbl->setSolverOptions({{"solver", "gmres"}});
        hiperProbl->setSolverOptions({{"tol", "1e-8"}});
        hiperProbl->setSolverOptions({{"max_iter", "5000"}});
        hiperProbl->setSolverOptions({{"output", "none"}});

        // Update
        hiperProbl->Update();
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": HiPerProblem could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }



    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    int timeStep{};
    double time{};
    while ((timeStep < maxNSteps) && (time < maxTime))
    {
        //Print info
        if (myRank == 0)
            cout << "TS:" << timeStep + 1 << " Time " << time << " of " << maxTime << " with deltat=" << deltat << endl;

        //Initial guess
        dofHand->nodeDOFs0->setValue(dofHand->nodeDOFs);
        hiperProbl->UpdateGhosts();

        // Fill linear system
        hiperProbl->FillLinearSystem();

        // Solve
        auto status = hiperProbl->Solve();
        cout << status << endl;
        if (status.solStatus != 0)
        {
            MPI_Finalize();
            return 1;
        }

        // Update solution
        hiperProbl->UpdateSolution();
        timeStep++;
        time += deltat;

        // Output solution
        if (timeStep%nsave == 0)
        {
            string solName = "Pattern." + to_string(timeStep);
            dofHand->printFileLegacyVtk(solName);
        }

        if (myRank == 0)
            cout << endl;
    }


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
