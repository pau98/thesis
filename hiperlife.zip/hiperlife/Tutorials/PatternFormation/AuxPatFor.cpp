/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



/// Header to auxiliary functions
#include "AuxPatFor.h"

/// hiperlife headers
#include "hl_FillStructure.h"
#include "hl_Geometry.h"


void LS(RCP<FillStructure> fillStr)
{
    // Get parameters of the model
    double D_u = fillStr->userStr->dparam[0];
    double d_u = fillStr->userStr->dparam[1];
    double a_u = fillStr->userStr->dparam[2];
    double b_u = fillStr->userStr->dparam[3];
    double c_u = fillStr->userStr->dparam[4];
    double D_v = fillStr->userStr->dparam[5];
    double d_v = fillStr->userStr->dparam[6];
    double a_v = fillStr->userStr->dparam[7];
    double b_v = fillStr->userStr->dparam[8];
    double c_v = fillStr->userStr->dparam[9];
    double deltat = fillStr->userStr->dparam[10];

    // Initialize variables
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& ue_nodes0 = subFill.nborDOFs0; // Vector of node values
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFs();  // Local shape function
    double* glNa = subFill.nborBFsGrads(); // Local shape function derivatives
    double gNa[eNN*pDim], jac;
    SGeometry::globalBasisFunctionGradient(gNa, jac, subFill);

    // Evaluate quantities at integration points
    double un{}, vn{};
    for (int i = 0; i < eNN; i++)
    {
        un += ue_nodes0[i*DOF+0] * Na[i];
        vn += ue_nodes0[i*DOF+1] * Na[i];
    }

    // Fill linear system
    double N_e = DOF*eNN;
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            // Fill matrix (uu)
            fillStr->Ak(0, 0)[(DOF*i+0)*N_e + DOF*j + 0] += jac *
                (  Na[i]*Na[j]/deltat
                 + D_u * gNagNb
                 + (d_u-a_u) * Na[i]*Na[j]);

            // Fill matrix (uv)
            fillStr->Ak(0, 0)[(DOF*i+0)*N_e + DOF*j + 1] += jac *
                (- b_u * Na[i]*Na[j]);

            // Fill matrix (vu)
            fillStr->Ak(0, 0)[(DOF*i+1)*N_e + DOF*j + 0] += jac *
                (- a_v * Na[i]*Na[j]);

            // Fill matrix (vv)
            fillStr->Ak(0, 0)[(DOF*i+1)*N_e + DOF*j + 1] += jac *
                (  Na[i]*Na[j]/deltat
                 + D_v * gNagNb
                 + (d_v-b_v) * Na[i]*Na[j]);
        }

        // Fill RHS (u)
        fillStr->Bk(0)[i*DOF+0] += jac *
            Na[i] * (un/deltat + c_u);

        // Fill RHS (v)
        fillStr->Bk(0)[i*DOF+1] += jac *
            Na[i] * (vn/deltat + c_v);
    }

    return;
}
