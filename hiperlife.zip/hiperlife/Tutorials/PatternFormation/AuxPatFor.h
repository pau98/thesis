/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef AUXPATFOR_H
#define AUXPATFOR_H


#include <iostream>
#include <mpi.h>

#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_UserStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"

#include "hl_Math.h"
#include "hl_Array.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


void LS(RCP<hiperlife::FillStructure> fillStr);
int NewtonRaphson(RCP<HiPerProblem> hiperMech, RCP<UserStructure> userNum);

#endif
