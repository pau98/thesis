/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "IntegEquations.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr)
{
    ///===========          Initialize variables           ==========///
    ///
    /// First, we get the model parameters from the UserStructure
    double dt = fillStr->userStr->dparam[0];
    double diffu = fillStr->userStr->dparam[1];

    ///
    /// Then, we get the SubFillStructure for the dofHand from our
    ///   fillStr as follows
    SubFillStructure& subFill = (*fillStr)["Temp"];
    /// which we use to declare the variables:
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    vector<double>& ue_nodes0  = subFill.nborDOFs0;  // Vector of node coordinates
    double* Na  = subFill.nborBFs();  // Local shape function
    double* glNa = subFill.nborBFsGrads(); // Local shape function derivatives
    /// Finally, we compute the global values of the shape function
    ///   derivatives and the jacobian determinant of the mapping
    vector<double> gNa(eNN*pDim);
    double jac;
    SGeometry::globalBasisFunctionGradient(gNa.data(), jac, subFill);

    // Values at integration points
    double u0_k{};
    for (int i = 0; i < eNN; i++)
        u0_k += ue_nodes0[i] * Na[i];


    ///=====================  Fill linear system =====================///
    ///
    /// We loop through the neighboring nodes to fill both the matrix
    ///   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * Na[i] * Na[j] / dt;
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * u0_k / dt;
    }

}
