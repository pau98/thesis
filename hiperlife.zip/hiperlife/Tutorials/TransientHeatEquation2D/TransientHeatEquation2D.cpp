/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <mpi.h>

#include <Teuchos_RCP.hpp>
#include <Amesos_BaseSolver.h>
#include <AztecOO.h>
#include <Amesos.h>
#include <Teuchos_CommandLineProcessor.hpp>
#include <hl_MeshMap_Trivial.h>
#include <hl_Timer.h>

#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LoadMesh.h"



#include "IntegEquations.h"


using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    DistributedClass dis;
    bool verbose = dis.myRank() == 0;

    Timer timer({"MeshGenerator", "Initialization", "Filling", "Solver", "PrintLeg", "PrintParal"});



    ///===========          Command Line Arguements           ==========///
    Teuchos::CommandLineProcessor parser;
    parser.setDocString(
            "Transient Heat EquationCommandLineProcessor class "
                    "to get options from the command-line and print this help messange automatically.\n"
    );

    int nx = 10;
    parser.setOption("nx", &nx, "Points in the x direction. The total grid will be nx*nx");

    double dt = 0.001;
    parser.setOption("dt", &dt, "Delta t");

    double diffu = 1.0;
    parser.setOption("diffu", &diffu, "Diffusion coefficient");


    int maxTimeSteps = 10;
    parser.setOption("maxTimeSteps", &maxTimeSteps, "Maximum number of time steps");

    double imbTol = 0.05;
    parser.setOption("imbTol", &imbTol, "Imbalance Tolerance");

    string runName;
    runName.assign("test");
    parser.setOption("runName", &runName, "Model to solve.");

    string bf;
    bf.assign("Lagrangian");
    parser.setOption("bf", &bf, "Basis Functions: 'Lagrangian', 'SubdivSurfs', 'Nurbs', 'BSplines'");

    string elemType;
    elemType.assign("Triang");
    parser.setOption("elemType", &elemType, "Elem Type: 'Triang', 'Square' or 'Parallelep'.");

    string fMesh;
    fMesh.assign("");
    parser.setOption("filemesh", &fMesh, "File mesh.");


    Teuchos::CommandLineProcessor::EParseCommandLineReturn
            parseReturn= parser.parse( argc, argv );
    if( parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED )
        return 0;
    if( parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL   )
        return 1; // Error!





    ///===========          Parameters to Integ Equation           ==========///
    RCP<ParamStructure> userStr = rcp(new ParamStructure);
    userStr->dparam.resize(2);
    userStr->dparam[0] = dt;
    userStr->dparam[1] = diffu;


    ///===========          Set Mesh Parameters           ==========///
    BasisFuncType bfType = BasisFunction(bf);
    ElemType eType = Element(elemType);
    int bfOrder = (bfType==BasisFuncType::SubdivSurfs)?(2):(1);
    int nDim = 3;


    ///===========          Create/Load Mesh           ==========///
    RCP<DistributedMesh> disMesh;
    if (fMesh == "")
    {
        //Mesh Generator
        RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
        structMesh->setNDim(nDim);
        structMesh->setElemType(eType);
        structMesh->setBasisFuncType(bfType);
        structMesh->setBasisFuncOrder(bfOrder);
        structMesh->genStructMesh(nx);

        disMesh = rcp(new DistributedMesh);
        disMesh->setMesh(structMesh);
        disMesh->setBalanceMesh(true, imbTol);
        disMesh->Update();

        if (verbose) cout << "Distributed Mesh successfully created. " << endl;
    }
    else
    {
        RCP<MeshLoader> loadedMesh = rcp(new MeshLoader);
        loadedMesh->setNDim(nDim);
        loadedMesh->setElemType(ElemType::Triang);
        loadedMesh->setBasisFuncType(BasisFuncType::SubdivSurfs);
        loadedMesh->setBasisFuncOrder(bfOrder);
        loadedMesh->loadLegacyVtk(fMesh);

        disMesh = rcp(new DistributedMesh);
        disMesh->setMesh(loadedMesh);
        disMesh->setBalanceMesh(true, imbTol);
        disMesh->Update();

        if (verbose) cout << "Distributed Mesh successfully loaded. " << endl;
    }


    ///===========          Parameters to Integ Equation           ==========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    try
    {
        dofHand->setNameTag("Temp");
        dofHand->setNumDOFs(1);

        dofHand->Update();
        if (verbose) cout << "DOFsHandler successfully created. " << endl;
    }
    catch(runtime_error err)
    {
        if (verbose) cout << "DOFsHandler could not be created. " << err.what() << endl;

        MPI_Abort(dofHand->comm(), 1);
        return 0;
    }



    ///===========          Initial and boundary conditions - automatic way           ==========///
//    dofHand->nodeDOFs->setValue(0, 0.0);
//
//    dofHand->setBoundaryCondition(0, 0.0);
//    dofHand->setBoundaryCondition(0, MAxis::Xmax, 1.0);
//
//
//    ///===========          Initial and boundary conditions - manual way           ==========///
//    for(int i = 0; i < dofHand->mesh->loc_nPts(); i++)
//    {
//        dofHand->nodeDOFs->setValue(0, i, hiperlife::IndexType::Local, 0.0);
//
//        double x = dofHand->mesh->nodeCoord(i, 0, hiperlife::IndexType::Local);
//        double y = dofHand->mesh->nodeCoord(i, 1, hiperlife::IndexType::Local);
//
//        int crease = dofHand->mesh->nodeCrease(i, hiperlife::IndexType::Local);
//        if (crease > 0)
//        {
//            dofHand->setConstraint(0, i, hiperlife::IndexType::Local, 0.0);
//            if (x > 0.9999)
//                dofHand->setConstraint(0, i, hiperlife::IndexType::Local, 1.0);
//        }
//    }
//



    ///===========          Initial and boundary conditions - lambda           ==========///
    dofHand->setInitialCondition(0, [](double x, double y){ return x*x-1;});



    //Create
    RCP<HiPerProblem> hiperProblem = rcp(new HiPerProblem("hiperProblem"));
    hiperProblem->setUserStructure(userStr);
    hiperProblem->setDOFsHandlers({dofHand});
    hiperProblem->setIntegration("Integ", {"Temp"}, {IntegType::Master});
    hiperProblem->setCubatureGauss("Integ", compCubaturePoints(disMesh->elemType()));
    hiperProblem->setIntegration_ElemFillings("Integ", LS);

    hiperProblem->setSolver(PDEType::Linear, LinSolverType::AztecOO);
    hiperProblem->setSolverOptions({{"precond", "Jacobi"}});
    hiperProblem->setSolverOptions({{"solver", "cg"}});
    hiperProblem->setSolverOptions({{"tol", "1e-8"}});
    hiperProblem->setSolverOptions({{"max_iter", "5000"}});
    hiperProblem->setSolverOptions({{"output", "none"}});

    hiperProblem->Update();

    if (verbose) cout << "HiPerProblem successfully created. " << endl;


    //Time loop
    double time = 0.0;
    double totTime = 100;
    int timeStep = 0;



    ///===========          Print Initial Condition           ==========///
    string solname = runName + "_" + to_string(timeStep) ;

    /// The results can be printed to a file either in HiPerLiFe's own
    ///   format
    dofHand->printFile(solname);
    /// or/and as vtk
    dofHand->printFileLegacyVtk(solname);


    while ((timeStep < maxTimeSteps) && (time < totTime))
    {
        //Write
        if (verbose) cout << "-----------Time step " + to_string(timeStep) + " " << endl;

        dofHand->nodeDOFs0->setValue(dofHand->nodeDOFs);
        hiperProblem->UpdateGhosts();

        //Assemble
        timer.end("fill");
        hiperProblem->FillLinearSystem();
        timer.end("fill");


        //timer.start("solAztec");
        auto outSol = hiperProblem->Solve();

        cout << outSol;

        if (outSol.converged == false)
        {
            cout << hiperProblem->myRank() << ":   Solver failed!! " << outSol.solStatus <<  endl;
            MPI_Abort(dofHand->comm(), 1);
            return 0;
        }


        hiperProblem->UpdateSolution();
        timeStep++;
        time += dt;

        string solname = runName + "_" + to_string(timeStep) ;

        /// The results can be printed to a file either in HiPerLiFe's own
        ///   format
        dofHand->printFile(solname);
        /// or/and as vtk
        dofHand->printFileLegacyVtk(solname);
        /// for visualization purposes.
    }

    //Finalize
    MPI_Finalize();
    return 0;
}
