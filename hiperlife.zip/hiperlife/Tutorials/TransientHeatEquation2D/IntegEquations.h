/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef INTEGEQ_H
#define INTEGEQ_H



#include <iostream>
#include <mpi.h>

#include <unistd.h> //FIXME sleep function

#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"

#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_Geometry.h"

#include <Amesos_BaseSolver.h>
#include <AztecOO.h>
#include <Amesos.h>

void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr);

inline int compCubaturePoints(hiperlife::ElemType elemType)
{
    using namespace hiperlife;

    if (elemType == ElemType::Triang)
        return 3;
    if (elemType == ElemType::Square)
        return 4;
    if (elemType == ElemType::Tetrah)
        return 4;
    if (elemType == ElemType::Parallelep)
        return 8;

    return -1;
}


#endif //INTEGEQ_H
