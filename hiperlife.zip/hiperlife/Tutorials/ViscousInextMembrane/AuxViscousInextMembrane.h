/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef AUXVISC_H
#define AUXVISC_H

// C headers
#include <iostream>

// hiperlife headers
#include "hl_ParamStructure.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"

struct MembraneParams
{
    enum RealParameters
    {
        deltat,
        kappa,
        mu
    };

    HL_PARAMETER_LIST DefaultValues
    {
        {"deltat", 1e1},
        {"kappa", 1.0},
        {"mu", 1e1},
    };
};

struct GeometryParams
{
    enum IntParameters
    {
        shape
    };
};


void LS(hiperlife::FillStructure& fillStr);
void InitializeNodalValues(Teuchos::RCP<hiperlife::DOFsHandler> posDHand, int shapeType);
void PostProcess(Teuchos::RCP<hiperlife::DOFsHandler> ppDOFsHandler, Teuchos::RCP<hiperlife::HiPerProblem> hiperProbl);

#endif
