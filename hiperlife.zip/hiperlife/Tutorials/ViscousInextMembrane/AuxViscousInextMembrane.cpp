/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


// Header to auxiliary functions
#include "AuxViscousInextMembrane.h"

// hiperlife headers
#include "hl_Parser.h"
#include "hl_SurfLagrParam.h"
#include "hl_Tensor.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

void LS_GEOM(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;

    auto& subFill = fillStr[0];

    int numDOFs  = subFill.numDOFs;
    int eNN      = subFill.eNN;
    vector<double>& nborCoords  = subFill.nborCoords;

    //MAIN OUTPUT declaration
    auto& Ak  = fillStr.Ak(0, 0); // <<=== MAIN OUTPUT
    auto& Bk  = fillStr.Bk(0);    // <<=== MAIN OUTPUT

    int N_e = numDOFs*eNN;
    //------------------------------------------------------------------------------------

    // Get the value of the basis functions and derivatives at the Gauss point k
    double *bf  = subFill.nborBFs();
    double *dbf = subFill.nborBFsGrads();

    double x[3];
    double metric[4];
    double e1[3], e2[3];
    Math::MatTMult(x, 3, eNN, 1, nborCoords.data(), bf);
    SurfLagrParam::MetricTensor(metric,e1,e2,eNN,nborCoords.data(),dbf);
    double jac = sqrt(Math::DetMat2x2(metric));

    int shapeType = fillStr.getIntParameter(GeometryParams::shape);
    double z = x[2];

    double targetx[3];
    double r = Math::Norm3D(x);
    Math::AX(x, 3 , 1.0/r);

    double fr = sqrt(x[0]*x[0] + x[1]*x[1]);

    if (shapeType == 1) //Ellipsoid
        z = x[2] * 0.75;
    else if (shapeType == 2) //Red blood cell
        z = x[2] * 0.4 * (1.0-0.4*cos(1.15*M_PI*fr));
    else if (shapeType == 3) //spacecraft
        z = x[2] * 0.7 * (1.0+0.1*cos(2.0*M_PI*x[1]/r));

    targetx[0] = 100.0 * x[0];
    targetx[1] = 100.0 * x[1];
    targetx[2] = 100.0 * z;

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            //Add submatrix to elemental matrix
            for (int n = 0; n < numDOFs; n++)
                Ak[(numDOFs*i+n)*N_e + numDOFs*j + n] = jac * bf[i] * bf[j];
        }

        //Add submatrix to elemental matrix
        for (int n = 0; n < numDOFs; n++)
            Bk[numDOFs*i + n] = jac * bf[i] * targetx[n];

    }
}

void InitializeNodalValues(hiperlife::SmartPtr<hiperlife::DOFsHandler> posDHand, int shapeType)
{
    using namespace std;
    using namespace hiperlife;

    SmartPtr<ParamStructure> userStr = CreateParamStructure<GeometryParams>();      //User structure
    userStr->setIntParameter(GeometryParams::shape, shapeType);

    SmartPtr<HiPerProblem> prehp = Create<HiPerProblem>("HiPerProblem");
    prehp->setParameterStructure(userStr);

    prehp->setDOFsHandlers({posDHand});
    prehp->setGlobalIntegrals({"OrigVol", "OrigArea", "LSVol", "LSArea"});
    prehp->setIntegration("LeastSq", {"premech"});

    prehp->setCubatureGauss("LeastSq", 3);
    prehp->setElementFillings("LeastSq", LS_GEOM);

    prehp->Update();

    SmartPtr<MUMPSDirectLinearSolver> linSolver = Create<MUMPSDirectLinearSolver>();
    linSolver->setHiPerProblem(prehp);
    linSolver->setDefaultParameters();
    linSolver->Update();
    linSolver->solve();

    linSolver->UpdateSolution();
    posDHand->UpdateGhosts();

}

void LS(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //------------------------------------------------------------------
    // [1] Input variables

    // [1.1] Positions
    auto& subFill = fillStr["posDHand"];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;

    wrapper<double,2> nborDOFs0(subFill.nborDOFs0.data(),eNN,numDOFs);
    wrapper<double,2> nborDOFs(subFill.nborDOFs.data(),eNN,numDOFs);

    wrapper<double,1>   bf(subFill.nborBFs(),eNN);
    wrapper<double,2>  Dbf(subFill.nborBFsGrads(),eNN,pDim);
    wrapper<double,3> DDbf(subFill.nborBFsHess(),eNN,pDim,pDim);

    // [1.2] Tensions
    auto& t_subFill = fillStr["tenDHand"];
    int t_eNN  = t_subFill.eNN;

    wrapper<double,1> t_nborDOFs(t_subFill.nborDOFs.data(),t_eNN);
    wrapper<double,1> t_bf(t_subFill.nborBFs(),t_eNN);

    // [1.3] Global constraints
    auto& g_subFill = fillStr["gloDHand"];
    int g_numDOFs = g_subFill.numDOFs;

    wrapper<double,1> gDOFs(g_subFill.nborDOFs.data(),g_numDOFs);
    double pressure = gDOFs(0);
    tensor<double,1> F = gDOFs(range(1,3));
    tensor<double,1> L = gDOFs(range(4,6));

    // [1.4] Parameters
    const double deltat = fillStr.getRealParameter(MembraneParams::deltat);
    const double kappa  = deltat*fillStr.getRealParameter(MembraneParams::kappa);
    const double mu     = fillStr.getRealParameter(MembraneParams::mu);

    // [1.5] Outputs
    wrapper<double,2> Bp(fillStr.Bk(0).data(),eNN,numDOFs);
    wrapper<double,1> Bt(fillStr.Bk(1).data(),t_eNN);
    wrapper<double,1> Bg(fillStr.Bk(2).data(),g_numDOFs);

    wrapper<double,4> App(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    wrapper<double,3> Apt(fillStr.Ak(0,1).data(),eNN,numDOFs,t_eNN);
    wrapper<double,3> Apg(fillStr.Ak(0,2).data(),eNN,numDOFs,g_numDOFs);
    wrapper<double,3> Atp(fillStr.Ak(1,0).data(),t_eNN,eNN,numDOFs);
    wrapper<double,3> Agp(fillStr.Ak(2,0).data(),g_numDOFs,eNN,numDOFs);


    //------------------------------------------------------------------
    // [2] Compute variables

    using ttl::index::a, ttl::index::b, ttl::index::c, ttl::index::d;
    using ttl::index::α, ttl::index::β, ttl::index::γ;
    using ttl::index::I, ttl::index::J;

    tensor<double,1> x0   = bf(I) * nborDOFs0(I,α);
    tensor<double,2> Dx0  = Dbf(I,a) * nborDOFs0(I,α);
    tensor<double,3> DDx0 = DDbf(I,a,b) * nborDOFs0(I,α);
    tensor<double,2> metric0 = Dx0(a,α) * Dx0(b,α);
    double jac0 = sqrt(metric0.det());
    tensor<double,2> imetric0 = metric0.inv();
    tensor<double,1> normal0 = antisym3D(α,β,γ) * Dx0(0,β) * Dx0(1,γ);
    normal0 /= jac0;
    double x0normal0 = x0 * normal0;

    tensor<double,1> x   = bf(I) * nborDOFs(I,α);
    tensor<double,2> Dx  = Dbf(I,a) * nborDOFs(I,α);
    tensor<double,3> DDx = DDbf(I,a,b) * nborDOFs(I,α);
    tensor<double,2> metric = Dx(a,α) * Dx(b,α);
    double jac = sqrt(metric.det());
    tensor<double,2> imetric = metric.inv();
    tensor<double,1> normal = antisym3D(α,β,γ) * Dx(0,β) * Dx(1,γ);
    normal /= jac;
    tensor<double,2> curva = DDx(a,b,α) * normal(α);
    tensor<double,2> curva_CC = imetric * curva * imetric;
    double H = imetric(a,b) * curva(a,b);

    double xnormal = x * normal;

    tensor<double,2> rodt    = metric-metric0;
    tensor<double,2> rodt_C0C0 = imetric0 * rodt * imetric0;

    // [2.3] Other variables
    double tr_rodt = (jac - jac0)/jac;

    double tension = (t_nborDOFs * t_bf) * deltat;

    //------------------------------------------------------------------
    // [3] Energies and dissipations

    // [3.1] Shear dissipation
    double dissipation = jac0 * mu * rodt(a,b) * rodt_C0C0(a,b);
    // [3.2] Helfrich energy
    double helfrich    = 0.5 * jac * kappa * H * H;
    // [3.3] Rayleighian
    double rayleighian = helfrich + dissipation;

    // [3.4] Add contributions to global integrals
    fillStr.addToGlobalIntegral("Rayleighian",rayleighian);
    fillStr.addToGlobalIntegral("Helfrich",helfrich);
    fillStr.addToGlobalIntegral("Dissipation",dissipation);
    fillStr.addToGlobalIntegral("Trd",jac0 * tr_rodt);

    //------------------------------------------------------------------
    // [4] Right-hand sides
    tensor<double,4> d_metric = (Dbf(I,a) * Dx(b,α) + Dbf(I,b) * Dx(a,α))(I,α,a,b);
    tensor<double,4> d_imetric = - d_metric(I,α,c,d) * imetric(c,a) * imetric(d,b);
    tensor<double,4> d_metric_C0C0 = d_metric(I,α,c,d) * imetric0(c,a) * imetric0(d,b);
    tensor<double,2> d_jac = 0.5 * jac * d_metric(I,α,a,b) * imetric(a,b);
    tensor<double,3> d_normal = -(Dbf(I,a) * imetric(a,b) * Dx(b,β) * normal(α))(I,α,β);
    tensor<double,4> d_curva = d_normal(I,α,β) * DDx(a,b,β) + normal(α) * DDbf(I,a,b);
    tensor<double,2> d_H = d_imetric(I,α,a,b) * curva(a,b) + d_curva(I,α,a,b) * imetric(a,b);


    // [4.1] Dissipation
    Bp(I,α) = 0.5 * jac0 * mu * d_metric(I,α,a,b) * rodt_C0C0(a,b);

    // [4.2] Helfrich energy
    Bp(I,α) += 0.5 * kappa * (d_jac(I,α) * H * H + (2.0 * jac * H) * d_H(I,α));

    // [4.3] Tension
    Bp(I,α) += tension * d_jac(I,α);
    Bt(I) = (jac-jac0) * deltat * t_bf(I);

    // [4.4] Volume constraint
    Bp(I,α) += pressure/3.0 * (d_jac(I,α) * xnormal + jac * (d_normal(I,α,β) * x(β)) + jac * bf(I) * normal(α));
    Bg(0) += (jac * xnormal - jac0*x0normal0)/3.0;

    // [4.5] Rigid body
    // [4.5.1] Translations
    Bp(I,α) += jac0 * bf(I) * F(α);
    Bg(range(1,3)) += jac0 * (x-x0);

    // [4.5.2] Rotations
    Bp(I,α)        += jac0 * bf(I) * antisym3D(α,β,γ) * x0(β) * L(γ);
    Bg(range(4,6))(γ) += jac0 * antisym3D(α,β,γ) * (x-x0)(α) * x0(β);

    //------------------------------------------------------------------
    // [5] Matrix
    tensor<double,6> dd_metric = ((Dbf(I,a) * Dbf(J,b) + Dbf(I,b) * Dbf(J,a)) * Identity3(α,β))(I,α,J,β,a,b);
    tensor<double,6> dd_imetric = - dd_metric(I,α,J,β,c,d) * imetric(c,a) * imetric(d,b) - d_metric(I,α,c,d) * d_imetric(J,β,c,a) * imetric(d,b)  - d_metric(I,α,c,d) * imetric(c,a) * d_imetric(J,β,d,b);
    tensor<double,4> dd_jac = 0.5 * jac * (dd_metric(I,α,J,β,a,b) * imetric(a,b) + d_metric(I,α,a,b) * d_imetric(J,β,a,b)) + 0.5 * d_metric(I,α,a,b) * imetric(a,b) * d_jac(J,β);
    tensor<double,5> dd_normal = (-Dbf(I,a) * Dx(b,γ) * d_imetric(J,β,a,b) * normal(α))(I,α,J,β,γ) - Dbf(I,a) * imetric(a,b) * Dbf(J,b) * normal(α) * Identity3(β,γ) - Dbf(I,a) * imetric(a,b) * Dx(b,γ) * d_normal(J,β,α);
    tensor<double,6> dd_curva = dd_normal(I,α,J,β,γ) * DDx(a,b,γ) + d_normal(I,α,β) * DDbf(J,a,b) + d_normal(J,β,α) * DDbf(I,a,b);
    tensor<double,4> dd_H = dd_imetric(I,α,J,β,a,b) * curva(a,b) + d_imetric(I,α,a,b) * d_curva(J,β,a,b) + d_curva(I,α,a,b) * d_imetric(J,β,a,b)  + dd_curva(I,α,J,β,a,b) * imetric(a,b);

    // [5.1] Dissipation
    App(I,α,J,β) = 0.5 * jac0 * mu * (d_metric(I,α,a,b) * d_metric_C0C0(J,β,a,b) + dd_metric(I,α,J,β,a,b) * rodt_C0C0(a,b));

    // [5.2] Helfrich energy
    App(I,α,J,β) += 0.5 * kappa * (dd_jac(I,α,J,β) * H * H + (2.0 * jac * H) * dd_H(I,α,J,β) + (2.0 * H) * (d_jac(I,α) * d_H(J,β) + d_jac(J,β) * d_H(I,α)) + (2.0 * jac) * d_H(I,α) * d_H(J,β));

    // [5.3] Tension
    App(I,α,J,β) += tension * dd_jac(I,α,J,β);
    Apt(I,α,J) = Atp(J,I,α) = t_bf(J) * d_jac(I,α) * deltat;

    // [5.4] Volume constraint
    App(I,α,J,β) += pressure/3.0 * (dd_jac(I,α,J,β) * xnormal + d_jac(I,α) * d_normal(J,β,γ) * x(γ) + d_jac(I,α) * bf(J) * normal(β) + d_jac(J,β) * d_normal(I,α,γ) * x(γ) + d_jac(J,β) * bf(I) * normal(α) + jac * dd_normal(I,α,J,β,γ) * x(γ) + jac * d_normal(I,α,β) * bf(J) + jac * d_normal(J,β,α) * bf(I));
    Apg(I,α,0) += 1.0/3.0 * (d_jac(I,α) * xnormal + jac * (d_normal(I,α,β) * x(β)) + jac * bf(I) * normal(α));

    // [5.5] Rigid body
    // [5.5.1] Translations
    Apg(all,0,1) += jac0 * bf;
    Apg(all,1,2) += jac0 * bf;
    Apg(all,2,3) += jac0 * bf;

    // [5.5.1] Rotations
    Apg(all,all,range(4,6))(I,α,γ) += jac0 * bf(I) * antisym3D(α,β,γ) * x0(β);
    Agp = Apg.transpose({2,0,1});
}

void PostProcess(hiperlife::SmartPtr<hiperlife::DOFsHandler> ppDOFsHandler, hiperlife::SmartPtr<hiperlife::HiPerProblem> hiperProbl)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    auto pDOFsHandler = hiperProbl->_dhands[0];
    auto tDOFsHandler = hiperProbl->_dhands[1];
    auto gDOFsHandler = hiperProbl->_dhands[2];

    auto mesh = pDOFsHandler->mesh;
    auto adjcyEN = mesh->_adjcyEN;

    int numDOFs = pDOFsHandler->numDOFs();

    int loc_nPts = mesh->loc_nPts();

    double deltat = hiperProbl->userStructure()->getRealParameter(MembraneParams::deltat);

    //To post-process, we are going to compute fields on the nodes of the finer mesh
    for (int i = 0; i < loc_nPts; i++)
    {
        //Compute the position of the node
        auto x_i = mesh->nodeCoords(i,IndexType::Local);

        //Find an element of the finer mesh for which both the fine element and its parent lie in the partition of the node
        int e  = -1;
        int ee = -1;
        if (mesh->_basisFunctions->orderDers() >= 2)
        {
            for (auto ebor: mesh->_adjcyNE->getNborList(i, IndexType::Local))
            {
                ee = mesh->_mapToParent->directMap(ebor,IndexType::Global)[0];
                if (adjcyEN->isItemInPart(ebor) and tDOFsHandler->mesh->_adjcyEN->isItemInPart(ee))
                {
                    e = ebor;
                    break;
                }
            }
        }
        if (e<0 or ee<0)
            throw runtime_error("PostProcess: for node " + to_string(i) + " I could not find an element (and a parent element) in the partition " + to_string(mesh->myRank()));


        //Load all variables (as if we were in a function per element)
        int eNN = adjcyEN->getNumNbors(e,IndexType::Global);

        tensor<double,2> nborDOFs(eNN,numDOFs);
        tensor<double,2> nborDOFs0(eNN,numDOFs);
        for (int j = 0; j < eNN; j++)
        {
            int jj = adjcyEN->getNbor(e, j, IndexType::Global);
            for ( int n = 0; n < numDOFs; n++ )
            {
                nborDOFs(j,n) = pDOFsHandler->nodeDOFs->getValue(n, jj, IndexType::Global);
                nborDOFs0(j,n) = pDOFsHandler->nodeDOFs0->getValue(n, jj, IndexType::Global);
            }
        }

        //Compute the basis functions. To do that, we compute the barycentric coordinates of the node in the element (note that this is only valid for TRIANGLES)
        std::vector<double> xi_samples(2);
        int ei0 = mesh->_connec->getNbor(e, 0);
        int ei1 = mesh->_connec->getNbor(e, 1);
        int ei2 = mesh->_connec->getNbor(e, 2);
        auto xei0 = mesh->nodeCoords(ei0);
        auto xei1 = mesh->nodeCoords(ei1);
        auto xei2 = mesh->nodeCoords(ei2);
        double area_e = SGeometry::AreaTriangle3D(xei0.data(), xei1.data(), xei2.data());
        double area_0 = SGeometry::AreaTriangle3D(xei0.data(), xei2.data(), x_i.data());
        double area_1 = SGeometry::AreaTriangle3D(xei1.data(), xei0.data(), x_i.data());

        xi_samples[0] = area_0/area_e*0.9999; //This factor is just to prevent that the coordinates are outside the triangle due to numerical error
        xi_samples[1] = area_1/area_e*0.9999;

        //Compute the basis functions at those coordinates
        std::vector<std::vector<double>> BF;
        mesh->_basisFunctions->computeBasisFunctionsReference(BF, xi_samples, mesh->_basisFunctions->getTag(e,IndexType::Global));
        tensor<double,1,false>   bf(BF[0].data(),eNN);


        //Repeat the same procedure with the coarse mesh
        int t_eNN = tDOFsHandler->mesh->_adjcyEN->getNumNbors(ee,IndexType::Global);

        tensor<double,1> t_nborDOFs(t_eNN);

        for (int j = 0; j < t_eNN; j++)
        {
            int jj = tDOFsHandler->mesh->_adjcyEN->getNbor(ee, j, IndexType::Global);
            t_nborDOFs(j) = tDOFsHandler->nodeDOFs->getValue(0, jj, IndexType::Global);
        }

        ei0 = tDOFsHandler->mesh->_connec->getNbor(ee, 0);
        ei1 = tDOFsHandler->mesh->_connec->getNbor(ee, 1);
        ei2 = tDOFsHandler->mesh->_connec->getNbor(ee, 2);
        xei0 = tDOFsHandler->mesh->nodeCoords(ei0);
        xei1 = tDOFsHandler->mesh->nodeCoords(ei1);
        xei2 = tDOFsHandler->mesh->nodeCoords(ei2);
        area_e = SGeometry::AreaTriangle3D(xei0.data(), xei1.data(), xei2.data());
        area_0 = SGeometry::AreaTriangle3D(xei0.data(), xei2.data(), x_i.data());
        area_1 = SGeometry::AreaTriangle3D(xei1.data(), xei0.data(), x_i.data());

        xi_samples[0] = area_0/area_e*0.9999;
        xi_samples[1] = area_1/area_e*0.9999;


        std::vector<std::vector<double>> t_BF;
        tDOFsHandler->mesh->_basisFunctions->computeBasisFunctionsReference(t_BF, xi_samples, tDOFsHandler->mesh->_basisFunctions->getTag(ee,IndexType::Global));

        tensor<double,1,false> t_bf  (t_BF[0].data(),t_eNN);

        //Calculate the outputs by interpolation
        tensor<double,1> x  = bf * nborDOFs;
        tensor<double,1> x0 = bf * nborDOFs0;
        double tension      = t_bf * t_nborDOFs;


        //Set values in the ppDOFsHandler
        ppDOFsHandler->nodeDOFs->setValue(0, i, IndexType::Local, (x(0)-x0(0))/deltat);
        ppDOFsHandler->nodeDOFs->setValue(1, i, IndexType::Local, (x(1)-x0(1))/deltat);
        ppDOFsHandler->nodeDOFs->setValue(2, i, IndexType::Local, (x(2)-x0(2))/deltat);

        ppDOFsHandler->nodeDOFs->setValue(3, i, IndexType::Local, tension);

        ppDOFsHandler->nodeAuxF->setValue(0, i, IndexType::Local, x(0));
        ppDOFsHandler->nodeAuxF->setValue(1, i, IndexType::Local, x(1));
        ppDOFsHandler->nodeAuxF->setValue(2, i, IndexType::Local, x(2));
    }

    ppDOFsHandler->nodeDOFs->setValue(4,gDOFsHandler->nodeDOFs->getValue(0, 0));
    ppDOFsHandler->UpdateGhosts();
}
