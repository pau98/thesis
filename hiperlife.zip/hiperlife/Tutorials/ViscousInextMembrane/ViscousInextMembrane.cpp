/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

// C++ headers
#include <iostream>

// hiperlife headers
#include "hl_Core.h"
#include "hl_ParamStructure.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_ConsistencyCheck.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"

// Header to auxiliary functions
#include "AuxViscousInextMembrane.h"

int main(int argc, char** argv)
{
    using namespace hiperlife;

    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//
    hiperlife::Init(argc, argv);
    const int myRank = hiperlife::MyRank();

    // Parameters of the model
    SmartPtr<ParamStructure> userStr = CreateParamStructure<MembraneParams>();


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Mesh generator
    SmartPtr<UnstructVtkMeshGenerator> unstructMesh = Create<UnstructVtkMeshGenerator>();
    try
    {
        unstructMesh->setBasisFuncType(BasisFuncType::SubdivSurfs);
        unstructMesh->setElemType(ElemType::Triang);
        unstructMesh->genSphere([](double x[3]){return 0.05;});
    }
    catch (runtime_error& err)
    {
        cout << myRank << ": MeshGenerator could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

    // Distribute mesh
    SmartPtr<DistributedMesh> tensDisMesh  = Create<DistributedMesh>();
    tensDisMesh->setMesh(unstructMesh);
    tensDisMesh->setBalanceMesh(true);
    tensDisMesh->Update();

    SmartPtr<DistributedMesh> posDisMesh = Create<DistributedMesh>();
    posDisMesh->setHRefinement(1);
    posDisMesh->setMeshRelation(MeshRelation::hRefin, tensDisMesh);
    posDisMesh->setBalanceMesh(true);
    posDisMesh->Update();

    SmartPtr<DistributedMesh> gloDisMesh  = Create<DistributedMesh>();
    gloDisMesh->setMeshRelation(MeshRelation::GlobConstr, posDisMesh);
    gloDisMesh->setBalanceMesh(false);
    gloDisMesh->Update();


    // **************************************************************//
    // *****               DOFHANDLER CREATION                  *****//
    // **************************************************************//
    SmartPtr<DOFsHandler> posDHand = Create<DOFsHandler>(posDisMesh);
    try
    {
        posDHand->setNameTag("posDHand");
        posDHand->setNumDOFs(3);
        posDHand->Update();
    }
    catch (runtime_error& err)
    {
        cout << myRank << ": DOFHandler could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

    InitializeNodalValues(posDHand, 3);
    posDHand->nodeDOFs0->setValue(posDHand->nodeDOFs);
    posDHand->UpdateGhosts();

    SmartPtr<DOFsHandler> tenDHand = Create<DOFsHandler>(tensDisMesh);
    try
    {
        tenDHand->setNameTag("tenDHand");
        tenDHand->setNumDOFs(1);
        tenDHand->Update();
    }
    catch (runtime_error& err)
    {
        cout << myRank << ": DOFHandler could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

    tenDHand->nodeDOFs->setValue(0.0);

    SmartPtr<DOFsHandler> gloDHand = Create<DOFsHandler>(gloDisMesh);
    try
    {
        gloDHand->setNameTag("gloDHand");
        gloDHand->setNumDOFs(7);
        gloDHand->Update();
    }
    catch (runtime_error& err)
    {
        cout << myRank << ": DOFHandler could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }
    gloDHand->nodeDOFs->setValue(0.0);

    // Post-processing handler (for output and visualization)
    SmartPtr<DOFsHandler> ppHand = Create<DOFsHandler>(posDisMesh);
    ppHand->setNameTag("ppHand");
    ppHand->setDOFs({"Vx","Vy","Vz","tension", "pressure"});
    ppHand->setNodeAuxF({"x","y","z"});
    ppHand->Update();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();
    try
    {
        // Set UserStructure
        hiperProbl->setParameterStructure(userStr);
        hiperProbl->setConsistencyCheckDelta(1.E-4);
        hiperProbl->setConsistencyCheckTolerance(1.E-4);

        // Set DOFHandler
        hiperProbl->setDOFsHandlers({posDHand, tenDHand, gloDHand});

        // Set Integration
        hiperProbl->setIntegration("Integ", {"posDHand", "tenDHand", "gloDHand"});
        hiperProbl->setCubatureGauss("Integ", 3);
        hiperProbl->setElementFillings("Integ", LS);

        hiperProbl->setGlobalIntegrals({"Rayleighian", "Helfrich", "Dissipation", "Trd"});
        // Update
        hiperProbl->Update();
    }
    catch (runtime_error& err)
    {
        cout << myRank << ": HiPerProblem could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }


    // **************************************************************//
    // *****                 SOLVERS' CREATION                  *****//
    // **************************************************************//

    SmartPtr<MUMPSDirectLinearSolver> linSolver = Create<MUMPSDirectLinearSolver>();
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setDefaultParameters();
    linSolver->Update();

    SmartPtr<NewtonRaphsonNonlinearSolver> nonlinSolver = Create<NewtonRaphsonNonlinearSolver>();
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(5);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->Update();


    double tSimu = 0.0;
    double totalTime = 1.E4;
    int nSave{};

    double stepFactor = 0.9;
    double deltatMax  = 1.E2;

    string sol_prefixMesh = "sol";

    double& deltat = userStr->getRealParameter(MembraneParams::deltat);
    while (tSimu < totalTime)
    {
        // Prepare for solver
        posDHand->nodeDOFs0->setValue(posDHand->nodeDOFs);
        tenDHand->nodeDOFs0->setValue(tenDHand->nodeDOFs);
        gloDHand->nodeDOFs0->setValue(gloDHand->nodeDOFs);
        hiperProbl->UpdateGhosts();

        if (gloDHand->myRank() == 0)
        {
            cout << "Time " << tSimu << " of " << totalTime << " with deltat=" << deltat << endl;
            cout << "Starting Newton-Raphson iteration for membrane evolution" << endl;
        }

        // Solve
        bool converged = nonlinSolver->solve();
        if (gloDHand->myRank() == 0)
            cout << "Finished Newton-Raphson iteration" << endl;

        // The solutions (velocity and density) are stored in VTK files
        if (converged)
        {
            PostProcess(ppHand, hiperProbl);

            string solName;
            solName = sol_prefixMesh + to_string(nSave);
            if (posDHand->myRank() == 0)
                cout << "Printing file " <<  solName << endl;
            ppHand->printFileLegacyVtk(solName,true);

            nSave++;

            if (nonlinSolver->numberOfIterations() < 5 and deltat < deltatMax)
            {
                deltat /= stepFactor;
            }
        }
        else
        {
            if (gloDHand->myRank() == 0)
                std::cout << "ERROR::EXIT from Newton-Raphson but linear solver converged" << endl;

            // Modify time-step size
            deltat *= stepFactor;

            // Restore initial values
            posDHand->nodeDOFs->setValue(posDHand->nodeDOFs0);
            tenDHand->nodeDOFs->setValue(tenDHand->nodeDOFs0);
            gloDHand->nodeDOFs->setValue(gloDHand->nodeDOFs0);
        }
        tSimu += deltat;
    }


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    hiperlife::Finalize();
    return 0;
}
