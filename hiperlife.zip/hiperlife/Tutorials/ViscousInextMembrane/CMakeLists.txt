#------------------------------------------------------------
# CMakeLists for Tutorial StokesProblem
#------------------------------------------------------------

get_filename_component(folder ${CMAKE_CURRENT_LIST_DIR} NAME)

if(VTK_FOUND)
  file(GLOB SOURCES_CPP *.cpp)

  include_directories(SYSTEM ${VTK_INCLUDE_DIRS})

  set(exName "hl${folder}")
  add_executable(${exName} ${SOURCES_CPP})
  target_link_libraries(${exName} ${HPLFE_LIBRARIES})
  target_link_libraries(${exName} ${VTK_LIBRARIES})

  install(TARGETS ${exName} DESTINATION ${TUTORIALS_DIR_INSTALL})
endif()
