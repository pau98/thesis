/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

////////////////////////////////////////////////////////////////////////
///                                                                  ///
/// The aim of this tutorial is to show the basic structure of       ///
///   hiperlife by solving Poisson's equation:                       ///
///   Δu = f                                                         ///
///                                                                  ///
////////////////////////////////////////////////////////////////////////



// hiperlife headers
#include "hl_Core.h"
#include "hl_ParamStructure.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"             // hiperlife header that defines
                                     //   different data types used
                                     //   throughout the library
#include "hl_GlobalBasisFunctions.h" // hiperlife header that defines
                                     //   auxiliary geometric-related
                                     //   functions
#include "hl_StructMeshGenerator.h"  // hiperlife header that
                                     //   defines structured mesh
                                     //   objects
#include "hl_DistributedMesh.h"      // hiperlife header that defines
                                     //   distributed mesh objects
#include "hl_FillStructure.h"        // hiperlife header that defines
                                     //   objects to fill the matrix and
                                     //   vector of the problem
#include "hl_DOFsHandler.h"          // hiperlife header that defines
                                     //   DOFHandler objects
#include "hl_HiPerProblem.h"         // hiperlife header that defines
                                     //   HiPerProblem objects

#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

struct PoissonParams
{
    enum RealParameters
    {
        force
    };

    HL_PARAMETER_LIST DefaultValues
    {
        {"force", 0.0},
    };
};

// Function that fills the elemental linear system of the problem. It
//   is declared here but implemented at the bottom.
void ElementFillingPoisson(hiperlife::FillStructure& fillStr);

// In this first tutorial everything is implemented inside the main
//   function
int main(int argc, char** argv)
{
    using namespace std;
    using namespace hiperlife;

    // The code is structured following this pattern:
    //
    //   Basis                          Boundary conditions+--+
    // functions+--+                                          |
    //             |                                          |
    //     +-------v-------+    +-----------------+    +------v-----+
    //     |               |    |                 |    |            |
    //     |  MeshCreator  +----> DistributedMesh +---> DOFsHandler |
    //     |               |    |                 |    |            |
    //     +---------------+    +-----------------+    +------+-----+
    //                                                        |
    //                                                        |
    //                                                        |
    //               Cubature+                        +-------v------+
    //                       +---->Integration+       |              |
    //      Elemental filling+                |       |              |
    //                                        +-------> HiPerProblem |
    //                                        |       |              |
    //                                  Solver+       |              |
    //                                                +-------+------+
    //                                                        |
    //                                                        |
    //                                                   +----v----+
    //                                                   |  SOLVE  |
    //                                                   +---------+
    //

    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // In this first part of the code we initialize several objects
    //   and/or variables that will be used later on in the code. In
    //   our case we initialize the MPI and the parameters of the
    //   model. Note that the MPI code *MUST* be initialized here at
    //   the beginning. Other objects/variables like the parameters of
    //   the model could be initialized later on.


    //=========== Initialize the MPI execution environment ==========//
    //
    // This function has two input parameters which we do not need,
    //   so we pass null pointers (nullptr)
    hiperlife::Init(argc, argv);
    // Note that MPI MUST be initialized before calling any other
    //   object, so a good practice is to always do it at the beginning
    //   of the main function.


    //=============== Define parameters of the model ===============//
    //

    //
    // Now we create a new hiperlife object called ParamStructure. This
    //   is a container of user-defined parameters that can be easily
    //   accessed at different points of the code (eg. when filling the
    //   elemental matrix or vector)
    //
    // The creation of an UserStructure object is as follows (note that
    //   the creation of every object of hiperlife follows the same
    //   structure)
    //
    //                       Name of the
    //                         object
    //                           |
    //  Pointer to data          |          Pointer to new
    // type UserStructure        |       UserStructure object
    //______|_______________            __|__     __________|________
    SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();
    //\      |                   |    \       \
    // \     |                   |     \       \-> Object of type
    //  \  Object                |      \          UserStructure
    //   \  type              Pointer    \
    //    \                               \-> Operator new
    //     \-> Pointer to
    //         object
    //
    // This UserStructure allows a number of data types such as doubles
    //   or integers (see documentation for available data types). Any
    //   user variable can be stored into predefined vectors. In this
    //   case we want to store one double so we resize the
    //   UserStructure vector "dparam" (d stands for double here) to
    //   one,

    // Note that we are using the arrow operator from c++ (->) to
    //   access individual members of the object. In this case we are
    //   accessing member "dparam" from the UserStructure "userStr".
    //
    // Our userStr object will be later given to the HiPerProblem
    //   object (the object that handles all the problem; see below).


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Next, we create a mesh for our computational domain. This
    //   process has two steps: mesh generation and mesh
    //   distribution. In the first step we generate a mesh either in
    //   serial or in parallel, depending on the chosen method. In the
    //   second one we generate all the structures related to the mesh
    //   and distribute them among the processors.

    //====================== Mesh generation ======================//
    //
    // Currently, hiperlife can generate a mesh in three different
    //   ways: loading a vtk file, using vtk libraries or using
    //   HiPerLiFe own libraries for structured and unstructured meshes.
    //   In this tutorial we will show HiPerLiFe's own libraries (the two other
    //   ways are covered in other tutorials).  The first step is to
    //   declare a new "StructMeshGenerator" object which we name
    //   "structMesh".
    SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();
    //
    //
    // Once created, we have to go through three steps: (1) Set
    //   variables, (2) generate a particular geometry, and (3)
    //   transform the geometry (if needed).
    //
    // (1) Set
    //   In this step we have to set the spatial dimensions of the
    //     mesh, the type of basis function and its order (if
    //     applicable), and the type of elements. This four sets have
    //     to be done for every type of mesh created through the
    //     StructMeshGenerator object.
    //   We start by setting the number of spatial dimensions to three
    //     (even if our computational domain is two-dimensional,
    //     hiperlife works with three spatial dimensions).
    structMesh->setNDim(3);
    //   Next, we set the type of basis function that we want to use to
    //     discretize. At this moment, there are five different basis
    //     functions implemented in hiperlife: linear (LinElems),
    //     Lagrangian (LagrElems), subdivision surfaces (SubdivSurf),
    //     BSplines (BSplineElems), and Nurbs (NurbsElems). In this
    //     tutorial we are going to use Lagrange basis functions.
    structMesh->setBasisFuncType(BasisFuncType::Lagrangian);
    //   We have to set an order for the basis functions. This is not
    //     always the case as shown in other tutorials (eg. subdivision
    //     surfaces are always second order). In addition, some basis
    //     functions can have different order per direction
    //     (eg. BSplines). Here we set the order to one. Note that this
    //     is equivalent to use linear basis functions.
    structMesh->setBasisFuncOrder(1);
    //   Now we set the type of element of our mesh. Currently, there
    //     are six types of elements available: points (Point), lines
    //     (Line), triangles (Triang), squares (Square), tetrahedra
    //     (Tetrah), and parallelepipeds (Parallelep). In this tutorial
    //     we are going to use squares:
    structMesh->setElemType(ElemType::Square);
    //
    // (2) Generate
    //   Once we have performed the sets, we can proceed with the
    //     generation of the mesh. We can either use a predefined
    //     generator or a free generator. Some examples of predefined
    //     generators are lines (genLine), squares (genSquare), annular
    //     sectors (genAnnularSector), or quarter torus
    //     (genQuarterTorusSolid). You can find many more in the
    //     documentation. In general, all generators have at least n
    //     parameters (being n the spatial dimension of the geometry)
    //     that specify the number of elements per spatial
    //     dimension. Here, we are going to use the rectangle generator
    //     which has 4 arguments: the number of elements per direction
    //     and the length of the sides. The bottom-left corner of the
    //     generated rectangle will be at (0,0).
    structMesh->genRectangle(500, 500, 1.0, 0.5);
    //
    // (3) Transform
    //   Finally, we can apply transformations to the geometry. As with
    //     the generators, there are both predefined transformations
    //     and free transformations. The predefined transformation
    //     include affine transformations, order elevation, element
    //     stretch, mesh skew/shear and many others (you can find them
    //     in the documentation). In our problem we are going to
    //     translate in Y direction.
    structMesh->translateY(0.5);
    //
    // **IMPORTANT NOTE**
    //   As you will see later, all the objects of HiPerLiFe have
    //   setters followed by an update. The StructMeshGenerator
    //   object is different, as it has setters, generators and
    //   transformations, and they have to be done in this order. In
    //   any case, if the order is altered, the code will through an
    //   exception/error and will stop.

    //===========             Distribute mesh            ===========//
    //
    // This object takes a mesh and creates all the necessary
    //   structures for solving the problem, such as connectivity,
    //   graphs, adjacencies, and contains all the information of the
    //   mesh. The input mesh can be either serial or distributed, so
    //   it has a method to balance/distribute the elements between
    //   processors (see below).
    //
    // First, we create the object, which we name disMesh:
    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    // Then, we set the object with the generated mesh
    disMesh->setMesh(structMesh);
    //   and we distribute the mesh using the default algorithm
    disMesh->setBalanceMesh(true);
    // This algorithm accepts a tolerance as a second argument. By not
    //   specifying it we are using the default one, namely 0.05. The
    //   smaller the tolerance the more balanced the mesh is going to
    //   be.
    //
    // Finally, we update the DistributedMesh. This update is going
    //   to perform the actual calculation of the object and all its
    //   structures.
    disMesh->Update();

    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Now, we create a class that contains our distributed mesh and
    //   includes the degrees of freedom and auxiliary variables. We
    //   also set the boundary conditions of our problem.

    //===========           Create DOFHandler            ===========//
    //
    // The object is created using the regular procedure, but now we
    //   construct it with the distributed mesh "disMesh":
    SmartPtr<DOFsHandler> fields = Create<DOFsHandler>(disMesh);
    // Then, we set a name for the DOFHandler ("dofHand"), which will
    //   be useful later in the code,
    fields->setNameTag("field");
    //   and we set the number of degrees of freedom (fields of
    //   unknowns). In our case, as we are solving a scalar PDE, this
    //   number is one.
    fields->setNumDOFs(1);
    // Finally, we update the object (recall that the actual
    //   computation is performed through this instruction).
    fields->Update();
    // Note that a DOFHandler can contain several degrees of freedom,
    //   as in a reaction diffusion system. Also, we can have several
    //   DOFHandlers for the same problem, for instance in Stokes flow
    //   we need one DOFHandler with two degrees of freedom for the
    //   velocities and another one with just on degree of freedom for
    //   the pressure, each one of them with a different mesh (see
    //   tutorial).

    //===========          Boundary conditions          ===========//
    //
    // Boundary conditions can be added in a number of different ways
    //   in hiperlife. Here, we are going to use the function
    //   setBoundaryCondition in three different ways. Other ways of
    //   imposing BC are shown in other tutorials.

    // First, we are going to initialize all boundary condition to
    //   zero. To do this, we can use setBoundaryCondition with two
    //   arguments: the number of degree of freedom to which we are a
    //   applying the condition (in this case we only have one) and the
    //   value at the boundary:
    fields->setBoundaryCondition(0, 0.0);
    // Then, we are going to fix the value at the right-hand side of
    //   our domain to one. This may be achieved using the same
    //   function, but this time with three arguments: the number of
    //   degree of freedom, the edge and the value. To specify the edge
    //   we use the enum class MAxis. In our case, as we want to impose
    //   the BC at those nodes whose x coordinate is maximum we use
    //   Xmax:
    fields->setBoundaryCondition(0, MAxis::Xmax, 1.0);
    // A third way of imposing boundary conditions with the same
    //   function is through lambda functions. In this case we have
    //   three arguments which are the number of degree of freedom, the
    //   edge and the lambda function, respectively. To show how it
    //   works we are going to impose a linear and a quadratic boundary
    //   condition from zero to one on the bottom and top edges
    //   respectively.
    fields->setBoundaryCondition(0, MAxis::Ymin, [](double x){return x;});
    fields->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});

    // Finally, after changing the information at the nodes, we need to
    //   update the ghost nodes so that all the neighbor processors now
    //   the changes. This is done with the function:
    fields->UpdateGhosts();



    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // The last object we are going to create is the HiPerProblem
    //   object. It contains the UserStructure and the DOFHandlers (in
    //   the present case just one) and includes, among other things,
    //   the integration rules and structures for every DOFHandler and
    //   the solver.
    //
    // We initialize the object and name it "hiperProbl", give it the
    //   UserStructure and the DOFHandler. Note that the last one is
    //   given as a vector of one component, as this function can
    //   receive several DOFHandlers
    SmartPtr<HiPerProblem> problem = Create<HiPerProblem>();
    problem->setParameterStructure(paramStr);
    problem->setDOFsHandlers({fields});

    //===========            Set integration             ===========//
    //
    // The next step is to set the integrations. This includes setting
    //   the type of integration, the cubature and the elemental
    //   matrices and vectors for each integration (only one
    //   integration in our case).
    // In short, in hiperlife setting the integration type means to
    //   establish the relation between different DOFHandlers. For
    //   instance, one DOFHandler may be a "Master" and a second one
    //   its Lagrange multiplier. Their use is shown in other
    //   tutorials. Here, as we only have one DOFHandler its
    //   integration type can only be "Master". We set it through the
    //   function setIntegration, which has three arguments: a name for
    //   the integration (useful when there are more than one), a
    //   vector of DOFHandlers (one in our case) and the integration
    //   type (Master).
    problem->setIntegration("Integ", {"field"});

    // Then we set the type of cubature through the function
    //   setIntegration_CubatureStd. Again, it takes three arguments:
    //   the name of the integration, the name of the cubature and the
    //   number of integration points per element. If the number of
    //   integration points is not given, it will use a default number
    //   (see documentation). Here, we use a 4-point Gaussian cubature.
    //   We refer the user to the documentation for other cubature
    //   types.
    problem->setCubatureGauss("Integ", 4);

    // The last set of the integration is to specify the name of the
    //   function(s) for the elemental filling of the matrices and
    //   vectors. This is performed through the function
    //   setElementFillings which takes two arguments: the
    //   name of the integration and the name of a function that fills
    //   both the matrix and the vector of the linear problem (LS in
    //   this case)
    problem->setElementFillings("Integ", ElementFillingPoisson);

    // Note that the filling of the linear system can be also given
    //   through two separate functions, the matrix and the right-hand
    //   side vector. In this case the same function may be used with a
    //   null pointer in the second argument and two extra arguments
    //   with the function names, eg:
    //   setElementFillings("Integ", nullptr, M, RHS);

    //===========                 Update                ===========//
    //
    // The final step is to update the HiPerProblem
    problem->Update();

    //===========               Set solver               ===========//
    //
    // Currently, hiperlife works with all linear and non-linear
    //   solvers of Trilinos. In this case we are
    //   going to use AztecOO's linear solvers, which we set through
    //   the following instruction:

    SmartPtr<MUMPSDirectLinearSolver> solver = Create<MUMPSDirectLinearSolver>();
    solver->setHiPerProblem(problem);
    solver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::Extreme);
    solver->setDefaultParameters();
    solver->Update();

    solver->solve();

    // Finally, we can update the values of the nodes through the
    //   instruction:
    problem->UpdateSolution();

    // The results can be printed to a file either in HiPerLiFe's own
    //   format
    // dofHand->printFile("Poisson");
    //   or/and as vtk
    fields->printFileLegacyVtk("Poisson");
    // for visualization purposes.


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    hiperlife::Finalize();
    return 0;
}

void ElementFillingPoisson(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::i;
    using ttl::index::I, ttl::index::J;

    // This function fills the elemental matrix and right-hand side
    //   vector at a given integration point. All the necessary
    //   information is in the FillStructure object fillStr that we
    //   passed as argument to this function, such as the elemental
    //   matrix (K), the right-hand side vector (rhs_k), the
    //   UserStructure, and the SubFillStructures. In turn, the
    //   SubFillStructures include all the necessary variables at an
    //   integration point (eg. spatial coordinates, basis functions
    //   and derivatives).
    // Note that there are as many SubFillStructures as DOFHandlers.

    //===========          Initialize variables           ==========//
    //
    // First, we get the model parameters from the UserStructure
    double force = fillStr.getRealParameter(PoissonParams::force);

    // Then, we get the SubFillStructure for the dofHand from our
    //   fillStr as follows
    SubFillStructure& subFill = fillStr[0];
    //   which we use to declare the variables:
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int pDim = subFill.pDim;      // Number of parametric dimension

    // Coordinates of the nodes in the element. We store this data
    //   in a hiperlife tensor of order 2, i.e. a matrix. It has eNN
    //   rows and nDim columns.
    // tensor<double,2> nborCoords(subFill.nborCoords.data(),eNN,nDim);

    // Basis functions evaluated at the Gauss point. The basis functions
    //   are a vector (tensor of order 1) of size eNN.
    wrapper<double, 1> bf(subFill. nborBFs(), eNN);

    // To make the calculations, we transform the local basis functions
    //   (more precisely, their derivatives) from local coordinates to
    //   cartesian (global) coordinates. The derivatives of the basis
    //   functions in global coordinates are a tensor of size eNN*pDim
    tensor<double, 2> Dbf(eNN, pDim);
    double jac;
    // To calculate the global basis functions and the jacobian we call the
    //   function gradients from the namespace GlobalBasisFunctions
    GlobalBasisFunctions::gradients(Dbf, jac, subFill);
    // We are going to fill the matrix and the right hand side. Here, we define
    //   the matrix Ak (eNN*eNN) and the vector Bk (eNN).
    wrapper<double,2> Ak(fillStr.Ak(0, 0).data(), eNN, eNN);
    wrapper<double,1> Bk(fillStr.Bk(0).data(), eNN);
    //And now we fill our lineal system with the corresponding equation
    Bk(I) = jac * bf(I) * force;
    Ak(I, J) = jac * Dbf(I, i) * Dbf(J, i);
}