#------------------------------------------------------------
# CMakeLists for Tutorial Poisson2D
#------------------------------------------------------------

get_filename_component(folder ${CMAKE_CURRENT_LIST_DIR} NAME)


file(GLOB SOURCES_CPP *.cpp)


set(exName "hl${folder}")
add_executable(${exName} ${SOURCES_CPP})
target_link_libraries(${exName} ${HPLFE_LIBRARIES})

install(TARGETS ${exName} DESTINATION ${TUTORIALS_DIR_INSTALL})
