#============================================================
#======================== Initialize ========================
#============================================================
cmake_minimum_required(VERSION 3.17.0)

project(hiperlife VERSION 5.0)

if(CMAKE_VERSION VERSION_GREATER 3.25.0)
  cmake_policy(SET CMP0140 NEW)
endif()

#============================================================
#===================== Options and flags ====================
#============================================================
option(BUILD_DEPENDENCIES "Build hiperlife's dependencies." ON)
option(BUILD_HIPERLIFE "Build hiperlife." ON)

option(ENABLE_VTK "Compilation with the vtk dependency" ON)
option(ENABLE_QT "Compilation with the vtk dependency" ON)
option(ENABLE_GMSH "Compilation with the Gmsh dependency." ON)
option(ENABLE_SCOTCH "Compilation with the Scotch dependency." ON)
option(ENABLE_PARMETIS "Compilation with the Parmetis dependency." OFF)
option(ENABLE_MUMPS "Compilation with the Mumps dependency." ON)

option(BUILD_SHARED_LIBS "Build hiperlife with shared libraries." ON)
option(BUILD_GREEK_INDICES "Build hiperlife with support for greek indices." ON)
option(BUILD_WITH_RPATH "Link dependencies with rpath." ON)
option(BUILD_TUTORIALS "Compile hiperlife Tutorials" ON)
option(BUILD_TESTS "Compile hiperlife tests" ON)
option(BUILD_GUI "Compilation of the graphical user interface." OFF)
option(EXTRAE_PROFILING "Add directives for a better profiling in BSC's Extrae." OFF)

if(CMAKE_BUILD_TYPE STREQUAL "")
  set(CMAKE_BUILD_TYPE Release CACHE STRING "" FORCE)
  message(STATUS "Hiperlife build type not set, default build type: ${CMAKE_BUILD_TYPE}")
else()
  message(STATUS "Hiperlife build type set to: ${CMAKE_BUILD_TYPE}")
endif()

if(CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)
  set(CMAKE_INSTALL_PREFIX ${CMAKE_CURRENT_BINARY_DIR}/install CACHE PATH "Install path prefix, prepended onto install directories" FORCE)
  message(STATUS "Hiperlife will be installed by default at: ${CMAKE_INSTALL_PREFIX}. Please modify the CMAKE_INSTALL_PREFIX variable if you need to install it elsewhere.")
else()
  message(STATUS "Hiperlife will be installed at: ${CMAKE_INSTALL_PREFIX}")
endif(CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)

set(CMAKE_CXX_STANDARD 17)

set(CMAKE_SCRIPTS_PATH "${CMAKE_CURRENT_LIST_DIR}/tools/cmake" CACHE INTERNAL "")
list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}/tools/cmake")
set(HPLFE_SOURCE_BASE_PATH "${CMAKE_CURRENT_LIST_DIR}")
set(HL_DEFINITIONS "")

if(BUILD_DEPENDENCIES)
  include(${CMAKE_SCRIPTS_PATH}/BuildDependencies.cmake)
endif()

set(CMAKE_CXX_FLAGS_DEBUG "${CMAKE_CXX_FLAGS} -g -ggdb -O0 -Wall -Wextra -Wpedantic")

message(STATUS "Hiperlife build type: ${CMAKE_BUILD_TYPE}")

if(BUILD_HIPERLIFE)
  include(${CMAKE_SCRIPTS_PATH}/BuildHiperlife.cmake)

  #Compile tutorials
  if(BUILD_TUTORIALS)
    add_subdirectory(${HPLFE_SOURCE_BASE_PATH}/Tutorials)
  endif()

  ############################################################
  # Fixme: Move to where it belongs
  ############################################################

  # sudo apt install doxygen graphviz
  # sudo apt install python3-pip python3-sphinx
  # pip install sphinx-rtd-theme
  # pip install breathe
  # pip3 install sphinx-sitemap


  # Doxygen
  find_package(Doxygen QUIET)

  #Output info
  if(DOXYGEN_FOUND)
    message(STATUS "  Doxygen:\t Found version ${DOXYGEN_VERSION} at ${DOXYGEN_EXECUTABLE}")
  else()
    message(STATUS "  Doxygen:\t Not found")
  endif()

  if(DOXYGEN_FOUND)

    message(STATUS "Configuring documentation")

    set(DOC_INSTALL_DIR ${CMAKE_CURRENT_LIST_DIR}/doc/doxygen/)

    file(MAKE_DIRECTORY ${DOC_INSTALL_DIR})
    file(WRITE ${DOC_INSTALL_DIR}/html/index.html "hiperlife's documentation has not been generated. Please, compile it with 'make doc'")

    configure_file("${DOC_INSTALL_DIR}/Doxyfile" "${CMAKE_BINARY_DIR}/doc/Doxyfile" @ONLY)

    add_custom_target(doc
      ${DOXYGEN_EXECUTABLE} "${CMAKE_BINARY_DIR}/doc/Doxyfile"
      WORKING_DIRECTORY "${DOC_INSTALL_DIR}"
      COMMENT "Generating API documentation with Doxygen" VERBATIM
    )

  endif(DOXYGEN_FOUND)


endif()
