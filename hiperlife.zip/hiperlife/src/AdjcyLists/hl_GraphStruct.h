/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef GRAPHSTUCT_H
#define GRAPHSTUCT_H

#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_FEVector.h>
#include <Epetra_IntVector.h>

#include "hl_AdjcyStruct.h"
#include "hl_ConnecStruct.h"
#include "hl_TypeDefs.h"

namespace hiperlife
{
    /*!
     * \brief Class that implements an adjacency list of nodes with nodes.
    */
    class GraphStruct : public AdjcyStruct
    {

        public:
            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            GraphStruct(std::string tag ="GraphStruct", MPI_Comm comm = MPI_COMM_WORLD) : AdjcyStruct(tag, comm) {}
            GraphStruct(GraphStruct &&other) = default;
            ~GraphStruct() = default;
            GraphStruct& operator=(GraphStruct&& other) = default;

            GraphStruct& operator=(const GraphStruct& other) = delete;
            GraphStruct(const GraphStruct& other) = delete;
            /** @} */ // end of constructors

            /** @name Object Creation Management
            *  @{
            */
            /*! \brief Set the number of physical dimensions. */
            void setNDim(int ndim);
            /*! \brief Set the total number of nodes. */
            void setNPts(int npts);
            /*! \brief Set the number of local nodes in this partition. */
            void setLocNPts(int locnpts);

            /*! \brief Sets an array with the global connectiviy. */
            void setGlobConnec(int*& connec, int nElem, int nVert);
            /*! \brief Sets an array with the global connectiviy. */
            void setGlobConnec(int*& connec);
            /*! \brief Sets the number of elements of the connectiviy. */
            void setTmpNElem(int nElem);
            /*! \brief Sets the number of vertices of the connectiviy. */
            void setTmpNVert(int nVert);

            /*! \brief Sets an array with the distributed graph. */
            void setDisGraph(int*& graphData, int *& graphIdPR);

            /*! \brief Sets the connectivity through a ConnecStruct. */
            void setConnecStruct(Teuchos::RCP<ConnecStruct> connec);

            /*! \brief Sets directly the adjacency node to node with an Epetra Object. */
            void setAdjcyNodeNode(Teuchos::RCP<Epetra_CrsGraph> adjcy);

            void setIStream(std::istream &in, OutputMode mode)
                {_tmp_istream = &in; _tmp_outputmode = mode;}


            /*! \brief Method check all the parameters and creates the object. */
            void Update() override;
            /** @} */ // end of object creation

            /** @name Object Distribution
            *  @{
            */
            /*! \brief Returns the total number of points. */
            int nPts() const {return _nItem;}
            /*! \brief Returns the number of points stored in the current partition.
             *  It does not include ghost points. */
            int loc_nPts() const {return _loc_nItem;}
            /*! \brief Returns the number of points stored in a partition.
             \param part the partition to return the points, by default the calling one. */
            int proc_nPts(int part = -1) const {return proc_nItem(part);};
            /*! \brief Returns the label of the first points stored in a partition.
             \param part the partition to return the points, by default the calling one. */
            int offs_nPts(int part = -1) const {return offs_nItem(part);};
            /** @} */ // end of information getters




            /** @name Adjacency Getters
            *  @{
             */
            /*! \brief Returns the number of neighbors of a node. */
            int getNumNbors(int idx, IndexType idxtype=IndexType::Global) const override;
            /*! \brief Returns the idx-th neighbor of a node. */
            int getNbor(int idx, int nbor, IndexType idxtype=IndexType::Global) const override;
            /*! \brief Returns the list of neighbors of a node. */
            std::vector<int>& getNborList(int idx, IndexType idxtype=IndexType::Global) override;
            /** @} */ // end of information getters



            /** @name Expert Users and Developers Only
            *  @{
             */
            /*! \brief Adjacency structure for the nodes. */
                Teuchos::RCP<Epetra_CrsGraph>  _adjcyNodeNode = Teuchos::null;
            /*! \brief Adjacency structure for the ghosts. */
                Teuchos::RCP<Epetra_CrsGraph>   _ghostsGraph  = Teuchos::null;
            /** @} */


            // Output Methods
            /** @name Output Methods
            *  @{
            * */
            /*! \brief Print critical information */
            void outFullData(std::ostream& os, OutputMode mode) const;
            /** @} */ // end of I/O methods


        private:
            // Temporal Pointers
            int _tmp_nElem{};
            int _tmp_nVert{};

            int *_tmp_GlobConnec {nullptr};
            int *_tmp_DisGraphData {nullptr};
            int *_tmp_DisGraphIdPR {nullptr};
            Teuchos::RCP<Epetra_CrsGraph>  _tmp_adjcyNodeNode = Teuchos::null;
            Teuchos::RCP<ConnecStruct>  _tmp_ConnecStruct = Teuchos::null;

            std::istream* _tmp_istream{nullptr};
            OutputMode _tmp_outputmode = OutputMode::Undefined;


            // Private Updates
            void _update_globConnecPOD();
            void _update_disConnecHPLFE();
            void _update_disGraphTril();
            void _update_disGraphPOD();
            void _update_disIStream();

            int _updateGhosts();
            int _allocGhosts() override;
//             int _generateImporters() override;


            Teuchos::RCP<Epetra_CrsGraph> _createAdjcyNodeNode(int *&connec);
            Teuchos::RCP<Epetra_FECrsGraph> _createAdjcyNodeNode(Teuchos::RCP<ConnecStruct> connec);

            void _destroyTmpPtrs();
            void _computeMaxNumNbors() override;

    };
}



#endif // GRAPHSTUCT_H
