/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <stdexcept>

#include <mpi.h>

#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_FEVector.h>


#include "hl_GraphStruct.h"
#include "hl_TypeDefs.h"
#include "hl_Checks.h"


using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void GraphStruct::setNPts(int npts)
    {
        _nItem = npts;
    }

    void GraphStruct::setLocNPts(int locnpts)
    {
        _loc_nItem = locnpts;
    }

    void GraphStruct::setGlobConnec(int*& connec, int nElem, int nVert)
    {
        if (connec == nullptr)
            throw runtime_error("setGlobConnec: Invalid connec.");

        if (nElem <= 0)
            throw runtime_error("setGlobConnec: Invalid nElem.");

        _tmp_nElem = nElem;
        _tmp_nVert = nVert;
        _tmp_GlobConnec = connec;
    }

    void GraphStruct::setGlobConnec(int*& connec)
    {
        if (connec == nullptr)
            throw runtime_error("setGlobConnec: Invalid connec.");

        _tmp_GlobConnec = connec;
    }

    void GraphStruct::setDisGraph(int*& graphData, int *& graphIdPR)
    {
//        if (graphData == nullptr || graphIdPR == nullptr)
//            throw runtime_error("GraphStruct::setDisGraph: Invalid array pointers.");

        _tmp_DisGraphData = graphData;
        _tmp_DisGraphIdPR = graphIdPR;
    }

    void GraphStruct::setTmpNElem(int nElem)
    {
        if (nElem <= 0)
            throw runtime_error("GraphStruct::setTmpNElem: Invalid nElem.");

        _tmp_nElem = nElem;
    }

    void GraphStruct::setTmpNVert(int nvert)
    {
        _tmp_nVert = nvert;
    }

    void GraphStruct::setConnecStruct(RCP<ConnecStruct> connec)
    {
        _tmp_ConnecStruct = connec;
    }


    void GraphStruct::setAdjcyNodeNode(Teuchos::RCP<Epetra_CrsGraph> adjcy)
    {
        if (adjcy == null)
            throw runtime_error("setAdjcyNodeNode: Invalid pointer.");

        _tmp_adjcyNodeNode = adjcy;
    }

    void GraphStruct::Update()
    {
        bool globConnecPOD{};
        bool disConnecHPLFE{};
        bool disGraphTril{};
        bool disGraphPOD{};
        bool disIStream{};

        _classTag = "GraphStruct";
        if (_nameTag == "DistributedClass")
            _nameTag = "GraphStruct";



        if (_tmp_adjcyNodeNode != null)
            disGraphTril = true;

        if (_tmp_ConnecStruct != null)
            disConnecHPLFE = true;

        if (_tmp_GlobConnec  != nullptr)
            globConnecPOD = true;

        if (_tmp_DisGraphData != nullptr && _tmp_DisGraphData != nullptr)
            disGraphPOD = true;

        if (_tmp_istream != nullptr)
            disIStream = true;

        int check = checkUpdates({disGraphTril, disConnecHPLFE, globConnecPOD,
            disGraphPOD, disIStream});

        if (check == 2)
            throw runtime_error("GraphStruct::Update: We cannot choose between modes.");

        if (check == 0)
            throw runtime_error("GraphStruct::Update: There is no ready update method.");

        if (disGraphTril)
        {
            _update_disGraphTril();
        }
        else if(globConnecPOD)
        {
            _update_globConnecPOD();
        }
        else if(disConnecHPLFE)
        {
            _update_disConnecHPLFE();
        }
        else if(disGraphPOD)
        {
            _update_disGraphPOD();
        }
        else if(disIStream)
        {
            _update_disIStream();
        }

        UpdateDistData();

        _computeMaxNumNbors();
        _auxNborList.reserve(_maxNumNbors);

        _destroyTmpPtrs();


    }

    RCP< Epetra_FECrsGraph > GraphStruct::_createAdjcyNodeNode(Teuchos::RCP<ConnecStruct> connec)
    {

        Epetra_Map vec_map(-1, _loc_nItem, 0, *_epComm);

        RCP<Epetra_FECrsGraph> graph = rcp ( new  Epetra_FECrsGraph(Copy, vec_map, 7)); // FIXME Careful with the '7'

        int nVert = connec->nVert();


        for (int e = 0; e < connec->loc_nElem(); e++)
        {
                for (int i = 0; i < nVert; i++)
                {
                    int ii = connec->getNbor(e, i, IndexType::Local);
//                     int ii = connec[nVert * e + i];

                    for (int j = 0; j < nVert; j++)
                    {
                        int jj = connec->getNbor(e, j, IndexType::Local);
//                         int jj = connec[nVert * e + j];

                            graph->InsertGlobalIndices(1, &ii, 1, &jj);
                    }

                }

        }

        graph->GlobalAssemble();
        Barrier();

        return graph;
    }

    RCP<Epetra_CrsGraph> GraphStruct::_createAdjcyNodeNode(int*& connec)
    {

        Epetra_Map vec_map(-1, _loc_nItem, 0, *_epComm);

        RCP<Epetra_FECrsGraph> graph = rcp ( new  Epetra_FECrsGraph(Copy, vec_map, 7)); // FIXME Careful with the '7'

        if (_myRank == 0)
        {
            for (int e = 0; e < _tmp_nElem; e++)
            {
                    for (int i = 0; i < _tmp_nVert; i++)
                    {
                        int ii = connec[_tmp_nVert * e + i];

                        for (int j = 0; j < _tmp_nVert; j++)
                        {
                            int jj = connec[_tmp_nVert * e + j];
                                graph->InsertGlobalIndices(1, &ii, 1, &jj);
                        }

                    }

            }
        }

        graph->GlobalAssemble();
        Barrier();

        vector<int> ibuff;
        vector<int> rowSizes(_loc_nItem);
        for(int i = 0; i < _loc_nItem; i++)
            rowSizes[i] = graph->NumMyIndices(i);


        RCP<Epetra_CrsGraph> sGraph = rcp ( new  Epetra_CrsGraph(Copy, vec_map, rowSizes.data()));



        for(int i = 0; i < _loc_nItem; i++)
        {
            int rowS = graph->NumMyIndices(i);
            int ii = i + offs_nItem();

            ibuff.resize(rowS);
            int outS;

            graph->ExtractGlobalRowCopy(i + offs_nPts(), rowS, outS, ibuff.data());

            if (rowS != outS)
                cout << "Warning!!  rowS:" << rowS << "  " << outS << endl;

            sort(ibuff.begin(), ibuff.end());
//             cout << _myRank << "  " << i << ": ";
//             for (auto i : ibuff)
//                 cout << i << " ";
//             cout << endl;

            sGraph->InsertGlobalIndices(ii, rowS, ibuff.data());

        }
        sGraph->FillComplete();

        return sGraph;
    }


    void GraphStruct::_update_disGraphTril()
    {

        _nItem = _tmp_adjcyNodeNode->Map().NumGlobalElements();
        _loc_nItem = _tmp_adjcyNodeNode->Map().NumMyElements();

        _adjcyNodeNode = _tmp_adjcyNodeNode;

    }

    void GraphStruct::_update_globConnecPOD()
    {
        if(_nItem == 0)
            throw runtime_error("GraphStruct::Update: in globConnecPOD mode, nPts cannot be zero.");

        if(_loc_nItem == 0)
            _loc_nItem = computeTrivialDistrib();

        checkDistribution();
        UpdateDistData();

        _adjcyNodeNode = _createAdjcyNodeNode(_tmp_GlobConnec);
    }

    void GraphStruct::_update_disConnecHPLFE()
    {
        int sum_nPts;

        Barrier();
        MPI_Allreduce(&_loc_nItem, &sum_nPts, 1, MPI_INT, MPI_SUM, _comm);

        if(sum_nPts == 0)
            throw runtime_error("GraphStruct::_update_disConnecHPLFE: nPts cannot be zero.");

        if (_nItem == 0)
            _nItem = sum_nPts;

        if(sum_nPts != _nItem)
            throw runtime_error("GraphStruct::_update_disConnecHPLFE: nPts does not correspond with loc_nPts");

        _adjcyNodeNode = _createAdjcyNodeNode(_tmp_ConnecStruct);

    }

    void GraphStruct::_update_disGraphPOD()
    {

        _nItem = checkDistribution();

        UpdateDistData();

        _adjcyNodeNode = rcp(new Epetra_CrsGraph(Copy, *_map, _tmp_DisGraphIdPR));

        int n=0;
        for (int i = 0; i < _loc_nItem; i++)
        {
            int ii = i + offs_nItem();

            if (_tmp_DisGraphIdPR[i] != 0)
            {
                int *posI = &(_tmp_DisGraphData[n]);

                _adjcyNodeNode->InsertGlobalIndices(ii, _tmp_DisGraphIdPR[i], posI);
                n+=_tmp_DisGraphIdPR[i];
            }
        }

        _adjcyNodeNode->FillComplete();


    }

    void GraphStruct::_destroyTmpPtrs()
    {
        _tmp_adjcyNodeNode = null;
        _tmp_ConnecStruct  = null;
        _tmp_GlobConnec    = nullptr;
        _tmp_DisGraphData  = nullptr;
        _tmp_DisGraphIdPR  = nullptr;

        _tmp_nElem = 0;
        _tmp_nVert = 0;
    }


    void GraphStruct::_computeMaxNumNbors()
    {
        _maxNumNbors = _adjcyNodeNode->MaxNumIndices();
    }

    int GraphStruct::_allocGhosts()
    {
        _ghostsGraph = rcp (new Epetra_CrsGraph(Copy, _ghostsImporter->TargetMap(), 7));
        if(_adjcyNodeNode != null)
            _updateGhosts();

        return 0;
    }

    int GraphStruct::_updateGhosts()
    {
        _ghostsGraph->Import(*_adjcyNodeNode, *_ghostsImporter, Insert);

        return 0;
    }


    int GraphStruct::getNbor(int idx, int nbor, IndexType idxtype) const
    {

        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyNodeNode->LRID(idx);
                int locColumn = (*_adjcyNodeNode)[e_loc][nbor];
                return _adjcyNodeNode->GCID(locColumn);
            }
            else if (isItemInPartGhosts(idx))
            {
                ptrdiff_t idx_ghosts = find(_ghosts.begin(), _ghosts.end(), idx) - _ghosts.begin();
                int locColumn = (*_ghostsGraph)[idx_ghosts][nbor];
//                 return _ghostsGraph->GCID(locColumn);
                return locColumn;
            }
            else
            {
                throw runtime_error("getNbors: the node info is not in the partition.");
            }
        }
        else
        {
            int locColumn = (*_adjcyNodeNode)[idx][nbor];
            return _adjcyNodeNode->GCID(locColumn);

        }


    }

    int GraphStruct::getNumNbors(int idx, IndexType idxtype) const
    {
        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyNodeNode->LRID(idx);
                return _adjcyNodeNode->NumMyIndices(e_loc);
            }
            else if (isItemInPartGhosts(idx))
            {
//                 cout << *_ghostsGraph << endl;
//
//                 throw runtime_error("getNumNbors: The adjcy for the ghost nodes is not loaded. Rank: " + to_string(_myRank) + ".  Idx: " + to_string(idx));
                ptrdiff_t idx_ghosts = find(_ghosts.begin(), _ghosts.end(), idx) - _ghosts.begin();
                return _ghostsGraph->NumMyIndices(idx_ghosts);

            }
            else
            {
                throw runtime_error("getNumNbors: the node info is not in the partition.");
            }
        }
        else
        {
            return _adjcyNodeNode->NumMyIndices(idx);
        }
    }


    std::vector<int>& GraphStruct::getNborList(int idx, IndexType idxtype)
    {
        int numNbors = getNumNbors(idx, idxtype);

        _auxNborList.resize(numNbors);

        for (int i = 0; i < numNbors; i++)
            _auxNborList[i] = getNbor(idx, i, idxtype);

        return _auxNborList;
    }









}
