/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <fstream>
#include <stdexcept>




#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_IntSerialDenseVector.h>
#include <Epetra_FECrsMatrix.h>


#include "hl_TypeDefs.h"
#include "hl_IO_Aux.h"
#include "hl_GraphStruct.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;



namespace hiperlife
{


    void GraphStruct::outFullData(std::ostream& os, OutputMode mode) const
    {

        outDisData(os, mode);

        vector<int> ibuff(_loc_nItem+1);
        int locData{};
        for(int i = 0; i < _loc_nItem; i++)
        {
            ibuff[i] = _adjcyNodeNode->NumMyIndices(i);
            locData += ibuff[i];
        }
        ibuff[_loc_nItem] = locData;

        IO::printData(os, ibuff.data(), ibuff.size(), mode);

        ibuff.resize(locData);
        int n = 0;
        for(int i = 0; i < _loc_nItem; i++)
        {
            int rowS = _adjcyNodeNode->NumMyIndices(i);
            int outS;

            _adjcyNodeNode->ExtractGlobalRowCopy(i + offs_nPts(), rowS, outS, &ibuff[n]);

            if (rowS != outS)
                cout << "Warning!!  rowS:" << rowS << "  " << outS << endl;

            n+=rowS;
        }
            if (n != locData)
                cout << "Warning!!  rowS:" << locData << "  " << n << endl;

        IO::printData(os, ibuff.data(), locData, mode);

    }


    void GraphStruct::_update_disIStream()
    {
        istream& in = *_tmp_istream;
        OutputMode mode = _tmp_outputmode;
        UpdateDistData(in, mode);

        checkDistribution();

        int locData{_loc_nItem+1};

        vector<int> ibuff(locData);
        IO::fillData(ibuff.data(), in, locData, mode);


        int adjSize = ibuff[_loc_nItem];
        _tmp_DisGraphIdPR = ibuff.data();
        _tmp_DisGraphData = new int[adjSize];

        IO::fillData(_tmp_DisGraphData, in, adjSize, mode);

        _update_disGraphPOD();
        _updateGhosts();

        delete[] _tmp_DisGraphData;
    }




}
