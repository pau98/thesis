/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <vector>

#include <Teuchos_RCP.hpp>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_AdjcyStruct.h"


using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{


    ostream& operator<<(ostream& os, const AdjcyStruct& adjcy)
    {

        for (int p = 0; p < adjcy.numProcs(); p++)
        {

            if (p == adjcy.myRank())
            {
                os << "Rank: " << p << endl;


                for(int n=0; n < adjcy.nItem(); n++)
                {

                    if (adjcy.isItemInPart(n))
                        os << n  << " - ";
                    else if (adjcy.isItemInPartGhosts(n))
                        os << "*" << n  << " - ";

                    try
                    {
                        int nbors = adjcy.getNumNbors(n, IndexType::Global);
                        for (int i = 0; i < nbors; i++)
                            os << adjcy.getNbor(n, i, IndexType::Global) << " " ;
                        os << endl;
                    }
                    catch(runtime_error& err)
                    {

                    }
                }
                os << endl;
            }

            adjcy.Barrier();
        }

        return os;
    }

}
