/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <stdexcept>
#include <set>



#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_IntSerialDenseVector.h>
#include <Epetra_FECrsMatrix.h>


#include "hl_TypeDefs.h"
#include "hl_Checks.h"
#include "hl_ConnecStruct.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;



namespace hiperlife
{

    void ConnecStruct::setNVert(int nvert)
    {
        _nVert = nvert;
    }


    void ConnecStruct::setElemType(ElemType etype)
    {
        //FIXME check value
        _elemType = etype;
    }


    void ConnecStruct::setNElem(int nelem)
    {
        if (nelem <=0)
            throw runtime_error("ConnecStruct::setNElem: Invalid value: " + to_string(nelem));

        _nItem = nelem;
    }

    void ConnecStruct::setNElemDir(int nelemX, int nelemY, int nelemZ)
    {
        _nElemX = nelemX;
        _nElemY = nelemY;
        _nElemZ = nelemZ;
    }

    void ConnecStruct::setLocNElem(int loc_nelem)
    {
        _loc_nItem = loc_nelem;
    }


    void ConnecStruct::setGlobConnec(int*& connec)
    {
        if (connec == nullptr && _myRank == 0)
            throw runtime_error("ConnecStruct::setGlobConnec: Invalid connec.");

        _tmp_globConnec = connec;
    }

    void ConnecStruct::setAdjcyConnec(RCP<Epetra_IntVector> adjcy)
    {
        if (adjcy == null)
            throw runtime_error("setAdjcyConnec: Invalid pointer.");

        _tmp_adjcyConnec = adjcy;
    }

    void ConnecStruct::setAdjcyNE(RCP<AdjcyStruct> adjcy)
    {
        if (adjcy == null)
            throw runtime_error("setAdjcyNE: Invalid pointer.");

        _tmp_adjcyNE = adjcy;
    }




    void ConnecStruct::Update()
    {
        bool distTrilReady {};
        bool globPODReady{};
        bool distPODReady {};
        bool istreamReady{};

        _classTag = "ConnecStruct";
        if (_nameTag == "DistributedClass")
            _nameTag = "ConnecStruct";

        if (_tmp_adjcyConnec != null)
            distTrilReady = true;

        if (_tmp_globConnec != nullptr)
            globPODReady = true;

        if (_tmp_disConnec != nullptr)
            distPODReady = true;

        if (_tmp_istream != nullptr)
            istreamReady = true;

        int check = checkUpdates({distTrilReady, globPODReady, distPODReady, istreamReady});

        if (check == 2)
        {
            throw runtime_error("ConnecStruct::Update: We cannot choose between modes.");
        }

        if (check == 0)
        {
            throw runtime_error("ConnecStruct::Update: There is no ready update method.");
        }

        if (distTrilReady)
            _update_disTril();
        else if(globPODReady)
            _update_globPOD();
        else if(istreamReady)
            _update_distIStream();
        else if(distPODReady)
            _update_distPOD();

        // FIXME
        if (_elemType == ElemType::Undefined)
            throw runtime_error("Update: elemType has not been set.");

        _computeOffsets();
        _destroyTmpPtrs();

    }




    int ConnecStruct::_generateImporters()
    {
        if (_nVert == 0)
            return 1;

        // Generate Adjcy Ghosts
        Epetra_IntSerialDenseVector targetElements;

        targetElements.Size(_ghosts.size()*_nVert);

        int n = 0;
        for(auto g : _ghosts)
        {
            for (int i = 0; i < _nVert; i++)
            {
                targetElements[n] = g * _nVert + i;
                n++;
            }
        }

        Epetra_Map targetMap(-1, targetElements.Length(),
                                       targetElements.Values(), 0, *_epComm);

        _ghostsImporter = rcp(new Epetra_Import(targetMap, _adjcyConnec->Map()));

        return 0;
    }

    int ConnecStruct::_allocGhosts()
    {
        _adjcyGhostsConnec   = rcp(new Epetra_IntVector(_ghostsImporter->TargetMap()));
        if(_adjcyConnec != null)
            _updateGhosts();

        return 0;
    }

    int ConnecStruct::_updateGhosts()
    {
        _adjcyGhostsConnec->Import(*_adjcyConnec, *_ghostsImporter, Insert);
        return 0;
    }

    int ConnecStruct::getNumNbors(int idx, IndexType idxtype) const
    {
        (void)idx;
        (void)idxtype;
        return _nVert;
    }

    int ConnecStruct::getNbor(int idx, int nbor, IndexType idxtype) const
    {
        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = idx - offs_nItem();
                return (*_adjcyConnec)[_nVert*e_loc + nbor];
            }
            else if (isItemInPartGhosts(idx))
            {
                auto it = std::find(_ghosts.begin(), _ghosts.end(), idx);

                auto posGhosts = std::distance(_ghosts.begin(), it);
                return (*_adjcyGhostsConnec)[_nVert*posGhosts + nbor];
            }
            else
            {
                throw runtime_error("getNbors: the node info is not in the partition.");
            }
        }
        else
        {
            return (*_adjcyConnec)[_nVert*idx + nbor];
        }
    }

    std::vector<int>& ConnecStruct::getNborList(int idx, IndexType idxtype)
    {
        int numNbors = getNumNbors(idx, idxtype);

        _auxNborList.resize(numNbors);

        for (int i = 0; i < numNbors; i++)
            _auxNborList[i] = getNbor(idx, i, idxtype);

        return _auxNborList;
    }

    void ConnecStruct::setNborList(int idx, vector<int>& vec, IndexType idxtype)
    {
        int e_loc;

        if ((int) vec.size() != _nVert)
            throw runtime_error("setNborList: vector size different from _nVert.");

        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
                e_loc = idx - offs_nItem();
            else
                throw runtime_error("setNborList: idx is not in this partition.");
        }
        else
        {
            e_loc = idx;
        }

        for (int nbor = 0; nbor < _nVert; nbor++)
            (*_adjcyConnec)[_nVert*e_loc + nbor] = vec[nbor];


    }



    RCP<Epetra_IntVector> ConnecStruct::_createAdjcyConnec(int*& connec)
    {

        Epetra_Map vec_map(-1, _loc_nItem, 0, *_epComm);

        RCP<Epetra_FECrsMatrix>graph = rcp ( new   Epetra_FECrsMatrix(Copy, vec_map, _nVert));

        if (_myRank == 0)
        {
            vector<double> elem_connec(_nVert);
            vector<int>    indices(_nVert);

            for (int jj = 0; jj < _nVert; jj++)
                indices[jj] = jj;

            for (int e = 0; e < _nItem; e++)
            {
                for (int jj = 0; jj < _nVert; jj++)
                    elem_connec[jj] = (double)(connec[_nVert*e+jj]) + 0.1;

                graph->InsertGlobalValues(e, _nVert,
                                          elem_connec.data(), indices.data());
            }
        }

        graph->GlobalAssemble();
        Barrier();

        Epetra_Map conn_map(-1, _loc_nItem * _nVert, 0, *_epComm);
        RCP<Epetra_IntVector> adjncy = rcp (new Epetra_IntVector(conn_map));

        for (int e = 0; e < _loc_nItem; e++)
        {
            for (int j = 0; j < _nVert; j++)
            {
                int cCol = graph->GCID(j);
                (*adjncy)[_nVert*e+cCol] = (int) (*graph)[e][j];

            }
        }

        return adjncy;
    }




    void ConnecStruct::_update_disTril()
    {
        if(_loc_nItem == 0 && _nVert == 0)
            throw runtime_error("ConnecStruct::Update: _loc_nElem and _nVert are not set");

        int intVectLocSize = _tmp_adjcyConnec->MyLength();

        if(_loc_nItem != 0 && _nVert != 0)
        {
            if (intVectLocSize != _nVert * _loc_nItem)
                throw runtime_error("ConnecStruct::Update: _loc_nElem and _nVert are not compatible with adjcyConnec");
        }


        if(_loc_nItem == 0)
        {
            if ( (intVectLocSize % _nVert) != 0)
                throw runtime_error("ConnecStruct::Update: _nVert is not compatible with adjcyConnec");

            _loc_nItem = intVectLocSize / _nVert;
        }

        if(_nVert == 0)
        {
            if ( (intVectLocSize % _loc_nItem) != 0)
                throw runtime_error("ConnecStruct::Update: _loc_nElem is not compatible with adjcyConnec");

            _nVert = intVectLocSize / _loc_nItem;
        }

        int sum_nElem;

        Barrier();
        MPI_Allreduce(&_loc_nItem, &sum_nElem, 1, MPI_INT, MPI_SUM, _comm);

        if(sum_nElem*_nVert != _tmp_adjcyConnec->GlobalLength())
            throw runtime_error("ConnecStruct::Update: The global size of adjcyConnec does not correspond with loc_nElem");

        _nItem = sum_nElem;

        _adjcyConnec = _tmp_adjcyConnec;
    }

    void ConnecStruct::_update_globPOD()
    {
        if(_nItem == 0)
            throw runtime_error("ConnecStruct::Update: nElem is not set");

        if(_loc_nItem == 0)
            _loc_nItem = computeTrivialDistrib();

        checkDistribution();

        if(_nVert == 0)
            throw runtime_error("ConnecStruct::Update: nVert is not set");

        _adjcyConnec = _createAdjcyConnec(_tmp_globConnec);
    }

    void ConnecStruct::_update_distPOD()
    {
        if(_nVert == 0)
            throw runtime_error("ConnecStruct::Update: nVert is not set");
        _nItem = checkDistribution();

        Epetra_Map conn_map(-1, _loc_nItem * _nVert, 0, *_epComm);

        _adjcyConnec = rcp(new Epetra_IntVector(Copy, conn_map, _tmp_disConnec));

        UpdateDistData();

    }



    void ConnecStruct::_destroyTmpPtrs()
    {
        _tmp_adjcyConnec = null;

        _tmp_globConnec = nullptr;
        _tmp_disConnec  = nullptr;
        _tmp_istream    = nullptr;
        _tmp_outputmode = OutputMode::Undefined;
    }


    void ConnecStruct::_computeMaxNumNbors()
    {
        _maxNumNbors = _nVert;
    }







}
