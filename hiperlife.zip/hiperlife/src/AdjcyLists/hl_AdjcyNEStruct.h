/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ADJCYNESTRUCT_H
#define ADJCYNESTRUCT_H

#include <vector>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include <Epetra_FEVector.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_Import.h>

#include "hl_TypeDefs.h"

#include "hl_AdjcyStruct.h"
#include "hl_ConnecStruct.h"
#include "hl_GraphStruct.h"


namespace hiperlife
{
    /*!
     * \brief Class that implements an general adjacency list of nodes with elements.
    */
    class AdjcyNEStruct : public AdjcyStruct
    {
        public:
            AdjcyNEStruct(std::string tag ="AdjcyNEStruct", MPI_Comm comm = MPI_COMM_WORLD) : AdjcyStruct(tag, comm) {}
            AdjcyNEStruct(AdjcyNEStruct &&other) = default;
            ~AdjcyNEStruct() = default;
            AdjcyNEStruct& operator=(AdjcyNEStruct&& other) = default;

            AdjcyNEStruct& operator=(const AdjcyNEStruct& other) = delete;
            AdjcyNEStruct(const AdjcyNEStruct& other) = delete;

            void setGraph(Teuchos::RCP<GraphStruct> graph);
            void setConnec(Teuchos::RCP<AdjcyStruct> adjcyEN);
            void setNPts(int npts);
            void setLocNPts(int locnpts);

            void Update() override;


            /*! \brief Returns the total number of points. */
            int nPts() const {return _nItem;}
            /*! \brief Returns the number of points stored in the current partition.
             *  It does not include ghost points. */
            int loc_nPts() const {return _loc_nItem;}
            /*! \brief Returns the number of points stored in a partition.
             \param part the partition to return the points, by default the calling one. */
            int proc_nPts(int part = -1) const {return proc_nItem(part);};
            /*! \brief Returns the label of the first points stored in a partition.
             \param part the partition to return the points, by default the calling one. */
            int offs_nPts(int part = -1) const {return offs_nItem(part);};
            /** @} */ // end of information getters

            /*! \brief Returns the number of neighbors of a node. */
            int getNumNbors(int idx, IndexType idxtype=IndexType::Global) const override;
            /*! \brief Returns the idx-th neighbor of a node. */
            int getNbor(int idx, int nbor, IndexType idxtype=IndexType::Global) const override;
            /*! \brief Returns the list of neighbors of a node. */
            std::vector<int>& getNborList(int idx, IndexType idxtype=IndexType::Global) override;
            /** @} */ // end of information getters

            /*! \brief Adjacency structure for the nodes. */
            Teuchos::RCP<Epetra_FECrsGraph> _adjcyNodeElems = Teuchos::null;

            /*! \brief Adjacency structure for the ghosts. */
            Teuchos::RCP<Epetra_FECrsGraph> _adjcyGhostsNE = Teuchos::null;



            Teuchos::RCP<AdjcyStruct> _tmp_adjcyEN = Teuchos::null;
            Teuchos::RCP<GraphStruct> _graph = Teuchos::null;

        private:

            void _generateAdjcyNodeElems();

            int _updateGhosts();
            int _allocGhosts() override;
            int _generateImporters() override;
            void _destroyTmpPtrs();
            void _computeMaxNumNbors() override;

    };
}

#endif // ADJCYNESTRUCT_H
