/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ADJCYENSTRUCT_H
#define ADJCYENSTRUCT_H

#include <vector>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include <Epetra_FEVector.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_Import.h>

#include "hl_TypeDefs.h"
#include "hl_AdjcyStruct.h"
#include "hl_ConnecStruct.h"
#include "hl_AdjcyNEStruct.h"


namespace hiperlife
{

    /*!
     * \brief Class that implements an general adjacency list of elements with nodes.
    */
    class AdjcyENStruct : public AdjcyStruct
    {
        public:
            AdjcyENStruct(std::string tag ="AdjcyENStruct", MPI_Comm comm = MPI_COMM_WORLD) : AdjcyStruct(tag, comm) {}
            AdjcyENStruct(AdjcyENStruct &&other) = default;
            ~AdjcyENStruct() = default;
            AdjcyENStruct& operator=(AdjcyENStruct&& other) = default;

            AdjcyENStruct& operator=(const AdjcyENStruct& other) = delete;
            AdjcyENStruct(const AdjcyENStruct& other) = delete;


            void setBasisFuncType(BasisFuncType bf);
            void setBasisFuncOrder(int bfo);
            void setBasisFuncOrderDir(int bfoX, int bfoY, int bfoZ);
            void setNElemDir(int nelemX, int nelemY, int nelemZ);
            void setGlobWeights(std::vector<double>& weights);
            void setGlobKnots(std::vector<double>& uKnot, std::vector<double>& vKnot, std::vector<double>& wKnot);
            void setConnec(Teuchos::RCP<ConnecStruct> connec);
            void setAdjcyNE(Teuchos::RCP<AdjcyNEStruct> adjcyNE);

            void Update() override;

            // Getters
            int proc_nElem(int part = -1) const {return proc_nItem(part);};
            int offs_nElem(int part = -1) const {return offs_nItem(part);};
            int nElem() const {return _nItem;};
            std::tuple<int, int, int> nElemDir() const {return std::make_tuple(_nElemX, _nElemY, _nElemZ);};
            std::vector<double> weights() const {return _weights;};
            std::vector<int> vCrv() const {return _vCrv;};
            std::tuple<std::vector<double>, std::vector<double>, std::vector<double>> knots() const {return std::make_tuple(_uKnot, _vKnot, _wKnot);};
            int loc_nElem() const {return _loc_nItem;};
            ElemType elemType() const {return _elemType;}
            int basisFuncOrder() const {return _basisFuncOrder;}
            std::tuple<int, int, int> basisFuncOrderDir() const {return std::make_tuple(_basisFuncOrderX, _basisFuncOrderY, _basisFuncOrderZ);};
            BasisFuncType basisFuncType() const {return _basisFuncType;}

            Teuchos::RCP<Epetra_FECrsGraph> _adjcyElemNodes = Teuchos::null;
            Teuchos::RCP<Epetra_IntVector>  _adjcyENSortJ   = Teuchos::null;
            Teuchos::RCP<Epetra_IntVector>  _adjcyENSortI   = Teuchos::null;


            int getNumNbors(int idx, IndexType idxtype=IndexType::Global) const override;

            int getNbor(int idx, int nbor, IndexType idxtype=IndexType::Global) const override;
            std::vector<int>& getNborList(int idx, IndexType idxtype=IndexType::Global) override;


            void _computeMaxNumNbors() override;

            Teuchos::RCP<ConnecStruct> _connec   = Teuchos::null;
            Teuchos::RCP<AdjcyNEStruct> _adjcyNE = Teuchos::null;

            std::vector<int>& getSortingList(int idx, IndexType idxtype=IndexType::Global);


        private:
            BasisFuncType _basisFuncType;
            ElemType _elemType;
            int _basisFuncOrder;
            int _basisFuncOrderX, _basisFuncOrderY, _basisFuncOrderZ;
            int _nElemX{}, _nElemY{}, _nElemZ{};
            std::vector<double> _weights;
            std::vector<int> _vCrv;
            std::vector<double> _uKnot, _vKnot, _wKnot;

            int getNborIdxSorted(int idx, int nbor, IndexType idxtype=IndexType::Global) const;
            std::vector<int>& getNborListIdxSorted(int idx, IndexType idxtype=IndexType::Global);
            int getSorting(int idx, int nbor, IndexType idxtype=IndexType::Global) const;


            void _generateAdjcyElemNodes();
            void _generateAdjcyElemNodes_linear();
            void _generateAdjcyElemNodes_lagrangian();
            void _generateAdjcyElemNodes_BSpline();
            void _generateAdjcyElemNodes_Nurbs();
            void _generateAdjcyElemNodes_subdivSurf();


            int _generateImporters() override;

            int _complementNode(int &newNode, int &newElement, int nodei, int nodej,
                                std::list<int>& jn_e_i);
            std::vector<int> _nearestNodesOfElement (int e);
            int _rotateAndFindNodes (std::vector<int> &adjcyEN_E , int nodei, int nodej, int element, std::list<int> &adjcyNE_I_buff);


    };
}

#endif // ADJCYENSTRUCT_H
