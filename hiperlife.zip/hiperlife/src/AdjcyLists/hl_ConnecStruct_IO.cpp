/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <fstream>
#include <stdexcept>




#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_IntSerialDenseVector.h>
#include <Epetra_FECrsMatrix.h>


#include "hl_TypeDefs.h"
#include "hl_IO_Aux.h"
#include "hl_ConnecStruct.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;



namespace hiperlife
{


    void ConnecStruct::outFullData(std::ostream& os, OutputMode mode) const
    {
//         if(mode == OutputMode::Binary)
//             outFullData_binary(os);
//         else if (mode == OutputMode::Text)
//             outFullData_text(os);
//         else
//             throw runtime_error("ConnecStruct::outFullData: Not a valid OutputMode.");

        outDisData(os, mode);

        vector<int> ibuff;

        ibuff = {_nVert, int(_elemType),
            _nVert*_loc_nItem, _nVert*_nItem};

        IO::printData(os, ibuff.data(), ibuff.size(), mode);

        int locData = _nVert*_loc_nItem;
        IO::printData(os, _adjcyConnec->Values(), locData, mode);

    }


    void ConnecStruct::_update_distIStream()
    {
        istream& in = *_tmp_istream;
        OutputMode mode = _tmp_outputmode;
        UpdateDistData(in, mode);

        vector<int> buff(4);
        IO::fillData(buff.data(), in, 4, mode);
        _nVert = buff[0];
        _elemType = ElemType(buff[1]);

        if(_nVert * _loc_nItem != buff[2])
            throw runtime_error("ConnecStruct::Update: Read local size incompatible.");
        if(_nVert * _nItem != buff[3])
            throw runtime_error("ConnecStruct::Update: Read total size incompatible.");

        _tmp_disConnec = new int[_nVert*_loc_nItem];

        IO::fillData(_tmp_disConnec, in, _nVert*_loc_nItem, mode);

        _update_distPOD();

        // This creates the ghosts infrastructure
        UpdateGhosts(_ghosts);
        // This comunicate the relevant information
        _updateGhosts();

        delete[] _tmp_disConnec;
    }




}
