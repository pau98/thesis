/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <vector>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include <Epetra_FECrsMatrix.h>
#include <Epetra_Import.h>

#include "hl_TypeDefs.h"

#include "hl_WeightedAdjcyStruct.h"


using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{


    void WeightedAdjcyStruct::Update()
    {
        if (_loc_nItem == 0 && _nItem == 0)
            throw runtime_error("WeightedAdjcyStruct::Update: The values of nItem and loc_nItem are not valid.");

        if (_tmp_data == null)
            throw runtime_error("WeightedAdjcyStruct::Update: A valid data needs to be set.");


        int sum_nPts;
        Barrier();
        MPI_Allreduce(&_loc_nItem, &sum_nPts, 1, MPI_INT, MPI_SUM, _comm);

        if(sum_nPts != _nItem)
            throw runtime_error("AdjcyNEStruct::Update: nPts does not correspond with loc_nPts");


        UpdateDistData();

        _generateAdjcy();

        _computeMaxNumNbors();
        _auxNborList.reserve(_maxNumNbors);

        _destroyTmpPtrs();
    }

    void WeightedAdjcyStruct::_generateAdjcy()
    {

        Epetra_Map row_map(-1, _loc_nItem, 0, *_epComm);


        _adjcyData = rcp ( new  Epetra_FECrsMatrix(Copy, row_map, 7)); // FIXME Careful with the '7'


        for (auto& tupl : *_tmp_data)
        {
            if (get<1>(tupl).size() != get<2>(tupl).size())
                throw runtime_error("WeightedAdjcyStruct::_generateAdjcy: The number of nbors does not correspond with the number of weights. Check that.");

            int row = get<0>(tupl);

            for (unsigned c = 0; c < get<1>(tupl).size(); c++)
            {
                int col = get<1>(tupl)[c];
                double val = get<2>(tupl)[c];
                _adjcyData->InsertGlobalValues(row, 1, &val, &col);
            }
        }


        _adjcyData->GlobalAssemble();
        Barrier();
    }




    int WeightedAdjcyStruct::_generateImporters()
    {
        // Compute Adjcy Ghosts
        Epetra_IntSerialDenseVector targetElements;

        targetElements.Size(_ghosts.size());

        int n = 0;
        for(auto g : _ghosts)
        {
            targetElements[n] = g;
            n++;
        }

        Epetra_Map targetMap(-1, targetElements.Length(),
		                       targetElements.Values(), 0, *_epComm);

        _ghostsImporter = rcp(new Epetra_Import(targetMap, _adjcyData->Map()));

        _adjcyGhosts   = rcp(new Epetra_FECrsMatrix(Copy, targetMap, 7));
        _adjcyGhosts->Import(*_adjcyData, *_ghostsImporter, Insert);

        return 0;
    }


    int WeightedAdjcyStruct::_allocGhosts()
    {
        Epetra_IntSerialDenseVector targetElements;

        targetElements.Size(_ghosts.size());

        int n = 0;
        for(auto g : _ghosts)
        {
            targetElements[n] = g;
            n++;
        }

        Epetra_Map targetMap(-1, targetElements.Length(),
                             targetElements.Values(), 0, *_epComm);


        _adjcyGhosts = rcp(new Epetra_FECrsMatrix(Copy, targetMap, 7));
        if(_adjcyData != null)
            _updateGhosts();

        return 0;
    }

    int WeightedAdjcyStruct::_updateGhosts()
    {
        _adjcyGhosts->Import(*_adjcyData, *_ghostsImporter, Insert);
        _adjcyGhosts->GlobalAssemble();
        return 0;
    }



    void WeightedAdjcyStruct::_computeMaxNumNbors()
    {
        int locMaxNumNbors = _adjcyData->MaxNumEntries();

        MPI_Allreduce(&locMaxNumNbors, &_maxNumNbors, 1, MPI_INT, MPI_MAX, _comm);
    }


    int WeightedAdjcyStruct::getNbor(int row, int nbor, IndexType idxtype) const
    {

        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(row))
            {
                int row_loc = _adjcyData->LRID(row);
                int read_length;
                double* values;
                int* indices;
                _adjcyData->ExtractMyRowView(row_loc, read_length, values, indices);

                return _adjcyData->ColMap().GID(indices[nbor]);

            }
            else if (isItemInPartGhosts(row))
            {
                int row_loc = _adjcyGhosts->LRID(row);

                int read_length;
                double* values;
                int* indices;
                int err = _adjcyGhosts->ExtractMyRowView(row_loc,  read_length, values, indices);

                if (err != 0)
                {
                    cout << endl << "Row: " << row << " " << row_loc << "  *** " <<  read_length << "    ****  ";
                    cout << "Error Not here - err: " << err << endl;
                    return -1;
                }

                return _adjcyGhosts->ColMap().GID(indices[nbor]);
            }
            else
            {
                throw runtime_error("getNbors: the node info is not in the partition.");
            }
        }
        else
        {
            int row_loc = row;
            int read_length;
            double* values;
            int* indices;
            _adjcyData->ExtractMyRowView(row_loc, read_length, values, indices);

            return _adjcyData->ColMap().GID(indices[nbor]);
        }

    }

    double WeightedAdjcyStruct::getWeight(int idx, int nbor, IndexType idxtype) const
    {
        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyData->LRID(idx);
                return (*_adjcyData)[e_loc][nbor];

            }
            else if (isItemInPartGhosts(idx))
            {
                int e_loc = _adjcyGhosts->LRID(idx);
                return (*_adjcyGhosts)[e_loc][nbor];
            }
            else
            {
                throw runtime_error("getNbors: the node info is not in the partition.");
            }
        }
        else
        {
            return (*_adjcyData)[idx][nbor];
        }
    }




    int WeightedAdjcyStruct::getNumNbors(int idx, IndexType idxtype) const
    {
        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyData->LRID(idx);
                return _adjcyData->NumMyEntries(e_loc);
            }
            else if (isItemInPartGhosts(idx))
            {
                int e_loc = _adjcyGhosts->LRID(idx);
                return _adjcyGhosts->NumMyEntries(e_loc);
            }
            else
            {
                throw runtime_error("getNumNbors: the node info is not in the partition.");
            }
        }
        else
        {
            return _adjcyData->NumMyEntries(idx);
        }
    }


    std::vector<int>& WeightedAdjcyStruct::getNborList(int idx, IndexType idxtype)
    {
        int numNbors = getNumNbors(idx, idxtype);

        _auxNborList.resize(numNbors);

        for (int i = 0; i < numNbors; i++)
            _auxNborList[i] = getNbor(idx, i, idxtype);

        return _auxNborList;
    }

    std::vector<double>& WeightedAdjcyStruct::getWeightList(int idx, IndexType idxtype)
    {
        int numNbors = getNumNbors(idx, idxtype);

        _auxWeightList.resize(numNbors);

        for (int i = 0; i < numNbors; i++)
            _auxWeightList[i] = getNbor(idx, i, idxtype);

        return _auxWeightList;
    }


    void WeightedAdjcyStruct::_destroyTmpPtrs()
    {
        _tmp_data = null;
    }


}
