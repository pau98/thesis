/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <algorithm>
#include <vector>

#include <mpi.h>

#include <Epetra_MpiComm.h>
#include <Epetra_CrsGraph.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_MultiVector.h>
#include <Epetra_Import.h>

#include "hl_AdjcyENStruct.h"



using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


#include <unistd.h> //FIXME sleep function



namespace hiperlife
{

    // Given two nodes and a list of elements returns the element ID containing both nodes
    // and the third commplementary node forming the element *kk
    int AdjcyENStruct::_complementNode(int &newNode, int &newElement, int nodei, int nodej, std::list<int>& jn_e_i)
    {
        int eNN = jn_e_i.size();


        int e;

        auto it   = jn_e_i.begin();
        int iend = 0;
        int m = 0;

        while ( iend==0 )
        {
            if ( m == eNN)
            {
                return 1;
            }

            e = *it;//jn_e_i(m);

            vector<int>& connecE = _connec->getNborList(e);

            if (connecE[0] == nodej)
            {
                iend = 1;
                newNode  =  (connecE[1]==nodei) ? connecE[2] : connecE[1];
            }
            else if ( connecE[1]==nodej )
            {
                iend = 1;
                newNode  =  (connecE[0]==nodei) ? connecE[2] : connecE[0];
            }
            else if ( connecE[2]==nodej )
            {
                iend = 1;
                newNode  =  (connecE[0]==nodei) ? connecE[1] : connecE[0];
            }

            m++;
            it++;
        }

        newElement = e;

        return 0;
    }


    // Rotate around nodei getting complement nodes and elements to fill je_n_
    int AdjcyENStruct::_rotateAndFindNodes (std::vector<int> &adjcyEN_E , int nodei, int nodej, int element, std::list<int> &adjcyNE_I_buff)
    {

        int newNode, newElement;


        // While the size of the list is larger than 0 read complement nodes and elements
        while(adjcyNE_I_buff.size() > 0)
        {

            if (_complementNode(newNode, newElement, nodei, nodej, adjcyNE_I_buff))
            {
                return 1;
            }

            element = newElement;
            nodej = newNode;

            if (find(adjcyEN_E.begin(), adjcyEN_E.end(), nodej) == adjcyEN_E.end())
                adjcyEN_E.push_back(nodej);

            adjcyNE_I_buff.remove(element);
        }

        return 0;
    }



    // Identify the nearest vertices to any element
    //
    // Interior patch (regular or irregular):
    //
    //                   N+4 - N+1 - N+2
    //                   / \   / \   / \          *
    //                  /   \ /   \ /   \         *
    //                N+5 -- N --- 1 -- N+3
    //                  \   / \   / \   /
    //                   \ /   \ /   \ /
    //                   N-1--- 0 --- 2
    //                     \   /|\   /
    //                      \ / | \ /
    //                       5 -4- 3
    //
    // We assume that e (number of the element in connec) is NOT a ghost element
    // (containing at least a ghost node), and its number in connecAct is eAct
    vector<int> AdjcyENStruct::_nearestNodesOfElement (int e)
    {
        int nodei, nodej, element;                  // Actual nodes (nodei,nodej) in the element element

        std::list<int> adjcyNE_I_buff;             // jn_e_i List of elements neighbors to the node i
        //Load in_elements and jn_elements

        //Nodes 0,1,N
        int node0 = _connec->getNbor(e, 0);
        int node1 = _connec->getNbor(e, 1);
        int nodeN = _connec->getNbor(e, 2);

        //ROTATION AROUND NODE0
        //------------------------------------------------------------------------------------
        element = e;
        nodei = node0;
        nodej = node1;

        // Introduce the first two nodes in JeNodes
        std::vector<int> adjcyEN_E;
        adjcyEN_E.reserve(12);

        adjcyEN_E.push_back(node0);
        adjcyEN_E.push_back(node1);

        //Introduce all element neighbors of the node i in the list
        for (auto el : _adjcyNE->getNborList(nodei))
        {
            adjcyNE_I_buff.push_back(el);
        }

        adjcyNE_I_buff.remove(element);

        int err = _rotateAndFindNodes (adjcyEN_E, nodei, nodej, element, adjcyNE_I_buff);


        if(err > 0)
        {
            cout << myRank() <<":  ERROR:: NearestNodesOfElement: The nearest element neighbors to NODE0 in element:" << e << "  are incorrect (RotateAndFindNodes is not able to close the loop)." << endl;

            throw runtime_error("_nearestNodesOfElement: Error!");
        }

        // FIXME Check if empty
        adjcyNE_I_buff.clear();


        //ROTATION AROUND NODE1
        //------------------------------------------------------------------------------------
        element = e;
        nodei = node1;
        nodej = nodeN;

        //Introduce all element neighbors of the node i in the list
        for (auto el : _adjcyNE->getNborList(nodei))
            adjcyNE_I_buff.push_back(el);

        adjcyNE_I_buff.remove(element);

        err = _rotateAndFindNodes (adjcyEN_E, nodei, nodej, element, adjcyNE_I_buff);

        if(err)
        {
            element = e;
            nodej = node0;

            int err2 = _rotateAndFindNodes (adjcyEN_E, nodei, nodej, element, adjcyNE_I_buff);

            if(err2)
            {
                cout << "ERROR:: NearestNodesOfElement: The nearest element neighbors to NODE1 in element:" << e << "  are incorrect (RotateAndFindNodes is not able to close the loop)." << endl;

                throw runtime_error("_nearestNodesOfElement: Error!");
            }
        }

        // FIXME Check if empty
        adjcyNE_I_buff.clear();

        //ROTATION AROUND NODEN
        //------------------------------------------------------------------------------------
        element = e;
        nodei = nodeN;
        nodej = node1;

        //Introduce all element neighbors of the node i in the list
        for (auto el : _adjcyNE->getNborList(nodei))
            adjcyNE_I_buff.push_back(el);

        adjcyNE_I_buff.remove(element);

        err = _rotateAndFindNodes (adjcyEN_E, nodei, nodej, element, adjcyNE_I_buff);


        if(err)
        {
            element = e;
            nodej = node0;

            int err2 = _rotateAndFindNodes (adjcyEN_E, nodei, nodej, element, adjcyNE_I_buff);

            if(err2)
            {
                cout << "ERROR:: NearestNodesOfElement: The nearest element neighbors to NODEN in element:" << e << "  are incorrect (RotateAndFindNodes is not able to close the loop)." << endl;

                throw runtime_error("_nearestNodesOfElement: Error!");
            }
        }

        // FIXME Check if empty
        adjcyNE_I_buff.clear();



        return adjcyEN_E;
    }


    void AdjcyENStruct::_generateAdjcyElemNodes_subdivSurf()
    {

        vector<vector<int>> eLists(_loc_nItem);

        for (int e = 0; e < _loc_nItem; e++)
        {
            int eGL = e + offs_nItem();

            eLists[e] = _nearestNodesOfElement(eGL);

        }


        Epetra_Map graph_map(-1, _loc_nItem, 0, *_epComm);

        _adjcyElemNodes = rcp (new  Epetra_FECrsGraph(Copy, graph_map, _connec->nVert()));
        _adjcyENSortI    = rcp (new  Epetra_IntVector (graph_map));

        int sizeSort = 0;
        for (int e = 0; e < _loc_nItem; e++)
        {
            (*_adjcyENSortI)[e] = sizeSort;
            sizeSort += eLists[e].size();
        }

        Epetra_Map sort_map(-1, sizeSort, 0, *_epComm);
        _adjcyENSortJ    = rcp (new  Epetra_IntVector (sort_map));

        vector<int> auxIdx;
        vector<int> copyList;

        for (int p = 0; p < _numProcs; p++)
        {
            if (p == _myRank)
            {
                for (int e = 0; e < _loc_nItem; e++)
                {
                    int eGL = e + offs_nItem();

                    copyList = eLists[e];

                    sort(eLists[e].begin(), eLists[e].end());


                    auxIdx.resize(eLists[e].size());
                    for (unsigned i = 0; i < eLists[e].size(); i++)
                    {
                        auto it = std::find(copyList.begin(), copyList.end(), eLists[e][i]);
                        auto posIdx = std::distance(copyList.begin(), it);

                        auxIdx[posIdx] = i;
                    }


                    for (unsigned v = 0; v < eLists[e].size(); v++)
                    {
                        (*_adjcyENSortJ)[(*_adjcyENSortI)[e] + v] = auxIdx[v];
                        _adjcyElemNodes->InsertGlobalIndices(1, &eGL, 1, &eLists[e][v]);
                    }

                }
            }
            Barrier();
        }
    }



}
