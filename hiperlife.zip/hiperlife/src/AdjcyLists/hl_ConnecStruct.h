/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CONNECSTRUCT_H
#define CONNECSTRUCT_H

#include <tuple>

#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_IntSerialDenseVector.h>


#include "hl_AdjcyStruct.h"
#include "hl_TypeDefs.h"

namespace hiperlife
{

    /*!
     * \brief Class that implements an adjacency list of elements with a fixed number of nodes for defining a mesh.
    */
    class ConnecStruct : public AdjcyStruct
    {
        public:
            // Constructor Destructors
            ConnecStruct(std::string tag ="ConnecStruct", MPI_Comm comm = MPI_COMM_WORLD) : AdjcyStruct(tag, comm) {}
            ConnecStruct(ConnecStruct &&other) = default;
            ~ConnecStruct() = default;
            ConnecStruct& operator=(ConnecStruct&& other) = default;

            ConnecStruct& operator=(const ConnecStruct& other) = delete;
            ConnecStruct(const ConnecStruct& other) = delete;

            // Setters
            void setNElem(int nelem);
            void setNElemDir(int nelemX, int nelemY, int nelemZ);
            void setLocNElem(int loc_nelem);
            void setNVert(int nvert);
            void setElemType(ElemType etype);

            void setGlobConnec(int*& connec);
            void setGlobConnec(std::vector<int>& connec) {_tmp_globConnec = connec.data();}
            void setAdjcyConnec(Teuchos::RCP<Epetra_IntVector> adjcy);
            void setDistConnec(int*& connec) {_tmp_disConnec = connec;}
            void setDistConnec(std::vector<int>& connec) {_tmp_disConnec_vec = connec; _tmp_disConnec = _tmp_disConnec_vec.data();}
            void setIStream(std::istream &in, OutputMode mode)
                {_tmp_istream = &in; _tmp_outputmode = mode;}

            void setAdjcyNE(Teuchos::RCP<AdjcyStruct> adjcyNE);

            // Update
            void Update() override;

            // Getters
            int proc_nElem(int part = -1) const {return proc_nItem(part);};
            int offs_nElem(int part = -1) const {return offs_nItem(part);};
            int nElem() const {return _nItem;};
            std::tuple<int, int, int> nElemDir() const {return std::make_tuple(_nElemX, _nElemY, _nElemZ);};
            int loc_nElem() const {return _loc_nItem;};
            int nVert() const {return _nVert;};
            ElemType elemType() const {return _elemType;}


            // Output Methods
            /** @name Output Methods
            *  @{
            */
            /*! \brief Print critical information */
            void outFullData(std::ostream& os, OutputMode mode) const;
            /** @} */ // end of I/O methods

            int _generateImporters() override;
            int _allocGhosts() override;
            int _updateGhosts();
            std::vector<int>& getNborList(int idx, IndexType idxtype=IndexType::Global) override;
            int getNbor(int idx, int nbor, IndexType idxtype=IndexType::Global) const override;
            int getNumNbors(int idx, IndexType idxtype=IndexType::Global) const override;

            void setNborList(int idx, std::vector<int>& vec, IndexType idxtype=IndexType::Global);


            // Public Data - Should be used only for debug
            Teuchos::RCP<Epetra_IntVector> _adjcyConnec   = Teuchos::null;

            Teuchos::RCP<Epetra_IntVector> _adjcyGhostsConnec   = Teuchos::null;



        private:
            int _nVert{};
            ElemType _elemType{};
            int _nElemX{}, _nElemY{}, _nElemZ{};



            // Temporal Pointers
            int* _tmp_globConnec {nullptr};
            int *_tmp_disConnec {nullptr};
            std::vector<int> _tmp_disConnec_vec;
            Teuchos::RCP<Epetra_IntVector>  _tmp_adjcyConnec = Teuchos::null;
            std::istream* _tmp_istream{nullptr};
            OutputMode _tmp_outputmode = OutputMode::Undefined;


            Teuchos::RCP<AdjcyStruct>  _tmp_adjcyNE = Teuchos::null;


            // Private Updates
            void _update_disTril();
            void _update_globPOD();
            void _update_distPOD();
            void _update_distIStream();

            Teuchos::RCP<Epetra_IntVector> _createAdjcyConnec(int*& connec);

            void _destroyTmpPtrs();
            void _computeMaxNumNbors() override;


//         friend class AdjcyENStruct;

    };


}
#endif // CONNECSTRUCT_H
