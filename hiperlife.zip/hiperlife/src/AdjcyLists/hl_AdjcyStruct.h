/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ADJCYSTRUCT_H
#define ADJCYSTRUCT_H

#include <vector>

#include <Teuchos_RCP.hpp>

#include <Epetra_Import.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_DistributedSrcData.h"
#include "hl_TypeDefs.h"


namespace hiperlife
{



    /*!
     * \brief Virtual class that provides a model for all the adjacency list created in <b>hiperlife</b>.
     *
     * It is composed for items that are distributed among all the partitions and each of the items have
     * a list of neighbors. The entities describe by items or the neighbors are completely general.
     * It assumes that the items are ordered among the different partitions being the first n0 in partition 0,
     * the following n1 in partition 1 and so on.
     * As a virtual class, cannot be instanciated but it can be inherit from to create any kind of adjacency structure.
    */
    class AdjcyStruct : public DistributedSrcData
    {

        public:
            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            AdjcyStruct(std::string tag ="AdjcyStruct", MPI_Comm comm = MPI_COMM_WORLD) : DistributedSrcData(tag, comm) {}
            AdjcyStruct(AdjcyStruct &&other) = default;
            virtual ~AdjcyStruct() = default;
            AdjcyStruct& operator=(AdjcyStruct&& other) = default;

            AdjcyStruct& operator=(const AdjcyStruct& other) = delete;
            AdjcyStruct(const AdjcyStruct& other) = delete;
            /** @} */ // end of constructors


            /** @name Object Creation Management
            *  @{
            */
            /*! \brief Method check all the parameters and creates the object. */
            virtual void Update() = 0;
            /** @} */ // end of object creation


            /** @name Adjacency Getters
            *  @{
            */
            /*! \brief Returns the number of neighbors of a node. */
            virtual int getNumNbors(int idx, IndexType idxtype=IndexType::Global) const = 0;
            /*! \brief Returns the idx-th neighbor of a node. */
            virtual int getNbor(int idx, int nbor, IndexType idxtype=IndexType::Global)  const = 0;
            /*! \brief Returns the list of neighbors of a node. */
            virtual std::vector<int>& getNborList(int idx, IndexType idxtype=IndexType::Global) = 0;

            /*! \brief Returns the maximun number of neighbors in the partition or in the whole object.
             * Depends on the daughter implementation. */
            int maxNumNbors() const {return _maxNumNbors;}
            /** @} */ // end of getters


        protected:
            int _maxNumNbors{0};  //!< Maximum number of nbors.

            /*! \brief Ghost importer for communicate information. */
            std::vector<int> _auxNborList;

            /*! \brief Virtual method, computes the maximum number of neighbors. */
            virtual void _computeMaxNumNbors() = 0;


        /*! \brief DistributedMesh can access to all the protected methods. Mainly for ghosts management. */
        friend class DistributedMesh;

    };


    std::ostream& operator<<(std::ostream& os, const AdjcyStruct& adjcy);



}



#endif // ADJCYSTRUCT_H
