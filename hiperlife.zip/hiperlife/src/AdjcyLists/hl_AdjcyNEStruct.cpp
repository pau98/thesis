/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <vector>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include <Epetra_FEVector.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_Import.h>

#include "hl_TypeDefs.h"

#include "hl_AdjcyStruct.h"
#include "hl_ConnecStruct.h"
#include "hl_AdjcyNEStruct.h"


using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void AdjcyNEStruct::setConnec(RCP<AdjcyStruct> connec)
    {
        if (connec == null)
            throw runtime_error("AdjcyNEStruct::setConnec: Invalid pointer.");

        _tmp_adjcyEN = connec;
    }

    void AdjcyNEStruct::setGraph(RCP<GraphStruct> graph)
    {
        if (graph == null)
            throw runtime_error("AdjcyNEStruct::setGraph: Invalid pointer.");

        _graph = graph;
    }

    void AdjcyNEStruct::setNPts(int npts)
    {
        _nItem = npts;
    }
    void AdjcyNEStruct::setLocNPts(int locnpts)
    {
        _loc_nItem = locnpts;
    }


    void AdjcyNEStruct::Update()
    {
        if (_loc_nItem == 0 && _nItem == 0)
            throw runtime_error("AdjcyNEStruct::Update: The values of nPts and loc_nPts are not valid.");

        if (_tmp_adjcyEN == null)
            throw runtime_error("AdjcyNEStruct::Update: A valid connec needs to be set.");

        if (_graph == null)
            throw runtime_error("AdjcyNEStruct::Update: A valid graph needs to be set.");

        int sum_nPts;
        Barrier();
        MPI_Allreduce(&_loc_nItem, &sum_nPts, 1, MPI_INT, MPI_SUM, _comm);

        if(sum_nPts != _nItem)
            throw runtime_error("AdjcyNEStruct::Update: nPts does not correspond with loc_nPts");


        UpdateDistData();

        _generateAdjcyNodeElems();

        _computeMaxNumNbors();
        _auxNborList.reserve(_maxNumNbors);

        _destroyTmpPtrs();
    }


    void AdjcyNEStruct::_generateAdjcyNodeElems()
    {
        int alloc_elems;


        if (_tmp_adjcyEN->nItem() > _nItem)
        {
            if (_myRank == (_numProcs -1))
                alloc_elems = _loc_nItem + _tmp_adjcyEN->nItem() - _nItem;
            else
                alloc_elems = _loc_nItem;
        }
        else
        {
            alloc_elems = _loc_nItem;
        }


        Epetra_Map row_map(-1, alloc_elems, 0, *_epComm);


        // FIXME Very Dirty Thing
        // I have created a "virtual" squared matrix to stores the NE AdjcyNEStruct
        // The last Rank will store the "nodes" between _tmp_Connec->nElem() - _nItem
        // that are empy and they are never used. This should have a little impact in memory
        // but not in performance
//         Epetra_Map col_map(_tmp_Connec->nElem(), _tmp_Connec->nElem(), 0, *_epComm);
// //         Epetra_Map col_map(_tmp_Connec->nElem(), 0, *_epComm);

        _adjcyNodeElems = rcp ( new  Epetra_FECrsGraph(Copy, row_map, 7)); // FIXME Careful with the '7'


        for (int e = 0; e < _tmp_adjcyEN->loc_nItem(); e++)
        {
                int eGl = e + _tmp_adjcyEN->offs_nItem();

                for (int i = 0; i < _tmp_adjcyEN->getNumNbors(e, IndexType::Local); i++)
                {
                    int ii = _tmp_adjcyEN->getNbor(e ,i, IndexType::Local);

                    _adjcyNodeElems->InsertGlobalIndices(1, &ii, 1, &eGl);
                }
        }


        _adjcyNodeElems->GlobalAssemble();
        Barrier();
    }




    int AdjcyNEStruct::_generateImporters()
    {
        // Compute Adjcy Ghosts
        Epetra_IntSerialDenseVector targetElements;

        targetElements.Size(_ghosts.size());

        int n = 0;
        for(auto g : _ghosts)
        {
            targetElements[n] = g;
            n++;
        }

        Epetra_Map targetMap(-1, targetElements.Length(),
		                       targetElements.Values(), 0, *_epComm);

        _ghostsImporter = rcp(new Epetra_Import(targetMap, _adjcyNodeElems->Map()));

        _adjcyGhostsNE   = rcp(new Epetra_FECrsGraph(Copy, targetMap, 7));
        _adjcyGhostsNE->Import(*_adjcyNodeElems, *_ghostsImporter, Insert);

        return 0;
    }


    int AdjcyNEStruct::_allocGhosts()
    {

        _adjcyGhostsNE = rcp(new Epetra_FECrsGraph(Copy, _ghostsImporter->TargetMap(), 7));
        if(_adjcyNodeElems != null)
            _updateGhosts();

        return 0;
    }

    int AdjcyNEStruct::_updateGhosts()
    {
        _adjcyGhostsNE->Import(*_adjcyNodeElems, *_ghostsImporter, Insert);
        return 0;
    }






    void AdjcyNEStruct::_computeMaxNumNbors()
    {
        int locMaxNumNbors = _adjcyNodeElems->MaxNumIndices();

        MPI_Allreduce(&locMaxNumNbors, &_maxNumNbors, 1, MPI_INT, MPI_MAX, _comm);
    }

    int AdjcyNEStruct::getNbor(int idx, int nbor, IndexType idxtype) const
    {
        int locColumn;

        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyNodeElems->LRID(idx);
                locColumn = (*_adjcyNodeElems)[e_loc][nbor];
                return _adjcyNodeElems->GCID(locColumn);

            }
            else if (isItemInPartGhosts(idx))
            {
                int e_loc = _adjcyGhostsNE->LRID(idx);
                locColumn = (*_adjcyGhostsNE)[e_loc][nbor];
                return locColumn;
//                 return _adjcyGhostsNE->GCID(locColumn);
            }
            else
            {
                throw runtime_error("getNbors: the node info is not in the partition.");
            }
        }
        else
        {
            locColumn = (*_adjcyNodeElems)[idx][nbor];
            return _adjcyNodeElems->GCID(locColumn);

        }

    }

    int AdjcyNEStruct::getNumNbors(int idx, IndexType idxtype) const
    {
        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyNodeElems->LRID(idx);
                return _adjcyNodeElems->NumMyIndices(e_loc);
            }
            else if (isItemInPartGhosts(idx))
            {
                int e_loc = _adjcyGhostsNE->LRID(idx);
                return _adjcyGhostsNE->NumMyIndices(e_loc);
            }
            else
            {
                throw runtime_error("getNumNbors: the node info is not in the partition.");
            }
        }
        else
        {
            return _adjcyNodeElems->NumMyIndices(idx);
        }
    }


    std::vector<int>& AdjcyNEStruct::getNborList(int idx, IndexType idxtype)
    {
        int numNbors = getNumNbors(idx, idxtype);

        _auxNborList.resize(numNbors);

        for (int i = 0; i < numNbors; i++)
            _auxNborList[i] = getNbor(idx, i, idxtype);

        return _auxNborList;
    }


    void AdjcyNEStruct::_destroyTmpPtrs()
    {
        _tmp_adjcyEN = null;
    }


}
