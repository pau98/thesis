/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <functional>


#include "hl_TypeDefs.h"


#include "hl_AdjcyENStruct.h"



using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;

namespace hiperlife
{


    std::vector<int>& AdjcyENStruct::getSortingList(int idx, IndexType idxtype)
    {
        (void) idx; (void) idxtype;
        throw bad_function_call();
    }


    void AdjcyENStruct::setBasisFuncType(BasisFuncType bf)
    {
        _basisFuncType = bf;
    }

    void AdjcyENStruct::setBasisFuncOrder(int bfo)
    {
        _basisFuncOrder = bfo;
    }

    void AdjcyENStruct::setBasisFuncOrderDir(int bfoX, int bfoY, int bfoZ)
    {
        _basisFuncOrderX = bfoX;
        _basisFuncOrderY = bfoY;
        _basisFuncOrderZ = bfoZ;
    }

    void AdjcyENStruct::setNElemDir(int nelemX, int nelemY, int nelemZ)
    {
        _nElemX = nelemX;
        _nElemY = nelemY;
        _nElemZ = nelemZ;
    }

    void AdjcyENStruct::setGlobWeights(vector<double>& weights)
    {
        _weights = weights;
    }

    void AdjcyENStruct::setGlobKnots(vector<double>& uKnot, vector<double>& vKnot, vector<double>& wKnot)
    {
        _uKnot = uKnot;
        _vKnot = vKnot;
        _wKnot = wKnot;
        double knt0 = -100;
        int k = -7;
        _vCrv.clear();
        for (double knt : _uKnot)
        {
            if(knt < knt0)
            {
                _vCrv.push_back(k);
                k -= 7; // block of n_c+7 knots per curve: k = first element of the next curve
            }
            k++;
            knt0 = knt;
        }
    }

    void AdjcyENStruct::setConnec(RCP<ConnecStruct> connec)
    {
        if (connec == null)
            throw runtime_error("setConnec: Invalid pointer");

        _connec = connec;
    }

    void AdjcyENStruct::setAdjcyNE(RCP<AdjcyNEStruct> adjcyNE)
    {
        if (adjcyNE == null)
            throw runtime_error("setAdjcyNE: Invalid pointer");

        _adjcyNE = adjcyNE;
    }

    void AdjcyENStruct::Update()
    {

        if(_connec == null)
            throw runtime_error("AdjcyENStruct::Update: connec has not been set.");

        if(_basisFuncType == BasisFuncType::SubdivSurfs && _adjcyNE == null)
            throw runtime_error("AdjcyENStruct::Update: _adjcyNE is needed.");

        _nItem = _connec->nElem();
        _loc_nItem = _connec->loc_nElem();

        _elemType = _connec->elemType();

        UpdateDistData();

        _computeOffsets();

        _generateAdjcyElemNodes();

        _computeMaxNumNbors();


    }

    void AdjcyENStruct::_generateAdjcyElemNodes()
    {

        switch (_basisFuncType)
        {
            case BasisFuncType::GlobConstr:
                _generateAdjcyElemNodes_lagrangian();
                break;
            case BasisFuncType::Linear:
                _generateAdjcyElemNodes_linear();
                break;
            case BasisFuncType::Lagrangian:
                _generateAdjcyElemNodes_lagrangian();
                break;
            case BasisFuncType::SubdivSurfs:
                _generateAdjcyElemNodes_subdivSurf();
                break;
            case BasisFuncType::BSplines:
                _generateAdjcyElemNodes_BSpline();
                break;
            case BasisFuncType::Nurbs:
                _generateAdjcyElemNodes_Nurbs();
                break;
            default:
                throw runtime_error("_generateAdjcyElemNodes: Not implemented yet.");
                break;
        }
    }





    int AdjcyENStruct::getSorting(int idx, int nbor, IndexType idxtype) const
    {
        int eLoc;

        if (idxtype == IndexType::Global)
            eLoc = _adjcyElemNodes->LRID(idx);
        else
            eLoc = idx;

        int offset = (*_adjcyENSortI)[eLoc];
        return  (*_adjcyENSortJ)[offset + nbor];
    }



    int AdjcyENStruct::getNumNbors(int idx, IndexType idxtype) const
    {
        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyElemNodes->LRID(idx);
                return _adjcyElemNodes->NumMyIndices(e_loc);
            }
            else if (isItemInPartGhosts(idx))
            {
                throw runtime_error("getNumNbors: Not yet Implemented.");
//                 int e_loc = _adjcyGhostsNE->LRID(idx);
//                 return _adjcyGhostsNE->NumMyIndices(e_loc);
            }
            else
            {
                throw runtime_error("getNumNbors: the node info is not in the partition.");
            }
        }
        else
        {
            return _adjcyElemNodes->NumMyIndices(idx);
        }
    }

    int AdjcyENStruct::getNborIdxSorted(int idx, int nbor, IndexType idxtype) const
    {
        if (idxtype == IndexType::Global)
        {
            if (isItemInPart(idx))
            {
                int e_loc = _adjcyElemNodes->LRID(idx);
                return (*_adjcyElemNodes)[e_loc][nbor];
            }
            else if (isItemInPartGhosts(idx))
            {
                throw runtime_error("getNborIdxSorted: Not yet Implemented.");
            }
            else
            {
                throw runtime_error("getNborIdxSorted: the node info is not in the partition.");
            }
        }
        else
        {
            return (*_adjcyElemNodes)[idx][nbor];
        }
    }


    int AdjcyENStruct::getNbor(int idx, int nbor, IndexType idxtype) const
    {

        //FIXME NO GHOST SUPPORT (Don't think is needed)
        int e_loc;
        if (idxtype == IndexType::Global)
            e_loc = _adjcyElemNodes->LRID(idx);
        else
            e_loc = idx;

        int e_order = getSorting(e_loc, nbor, IndexType::Local);

        return getNborIdxSorted(e_loc, e_order, IndexType::Local);
    }

    std::vector<int>& AdjcyENStruct::getNborList(int idx, IndexType idxtype)
    {
        int numNbors = getNumNbors(idx, idxtype);

        _auxNborList.resize(numNbors);

        for (int i = 0; i < numNbors; i++)
            _auxNborList[i] = getNbor(idx, i, idxtype);

        return _auxNborList;
    }


    void AdjcyENStruct::_computeMaxNumNbors()
    {
        // This computes the global maxNumNbors
//         int locMaxNumNbors = _adjcyElemNodes->MaxNumIndices();
//         MPI_Allreduce(&locMaxNumNbors, &_maxNumNbors, 1, MPI_INT, MPI_MAX, _comm);

        // This computes the local maxNumNbors
        _maxNumNbors = _adjcyElemNodes->MaxNumIndices();

    }

    int AdjcyENStruct::_generateImporters()
    {
        // ghost not needed here!
        return 1;
    }

}
