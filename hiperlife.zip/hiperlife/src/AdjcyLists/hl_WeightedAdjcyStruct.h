/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef WEIGHTEDADJCYSTRUCT_H
#define WEIGHTEDADJCYSTRUCT_H

#include <vector>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include <Epetra_FECrsMatrix.h>
#include <Epetra_Import.h>

#include "hl_TypeDefs.h"

#include "hl_AdjcyStruct.h"


namespace hiperlife
{

    /*!
     * \brief Class that implements an general adjacency list able to stores weighted links.
    */
    class WeightedAdjcyStruct : public AdjcyStruct
    {
        public:
            WeightedAdjcyStruct(std::string tag ="AdjcyNEStruct", MPI_Comm comm = MPI_COMM_WORLD) : AdjcyStruct(tag, comm) {}
            WeightedAdjcyStruct(WeightedAdjcyStruct &&other) = default;
            ~WeightedAdjcyStruct() = default;
            WeightedAdjcyStruct& operator=(WeightedAdjcyStruct&& other) = default;

            WeightedAdjcyStruct& operator=(const WeightedAdjcyStruct& other) = delete;
            WeightedAdjcyStruct(const WeightedAdjcyStruct& other) = delete;


            void setDistData(std::vector<std::tuple<int, std::vector<int>, std::vector<double>>> &data)
            {
                _tmp_data = Teuchos::rcpFromRef(data);
            }


            void Update() override;



            /*! \brief Returns the number of neighbors of a node. */
            int getNumNbors(int idx, IndexType idxtype = IndexType::Global) const override;
            /*! \brief Returns the idx-th neighbor of a node. */
            int getNbor(int idx, int nbor, IndexType idxtype = IndexType::Global) const override;
            /*! \brief Returns the idx-th weight of a node. */
            double getWeight(int idx, int nbor, IndexType idxtype = IndexType::Global) const;
            /*! \brief Returns the list of neighbors of a node. */
            std::vector<int>& getNborList(int idx, IndexType idxtype=IndexType::Global) override;
            std::vector<double>& getWeightList(int idx, IndexType idxtype=IndexType::Global);
            /** @} */ // end of information getters

            /*! \brief Adjacency structure for the nodes. */
            Teuchos::RCP<Epetra_FECrsMatrix> _adjcyData = Teuchos::null;

            /*! \brief Adjacency structure for the ghosts. */
            Teuchos::RCP<Epetra_FECrsMatrix> _adjcyGhosts = Teuchos::null;


        private:
            std::vector<double>_auxWeightList;
            void _generateAdjcy();
            Teuchos::RCP<std::vector<std::tuple<int, std::vector<int>, std::vector<double>>>> _tmp_data;
            int _updateGhosts();
            int _allocGhosts() override;
            int _generateImporters() override;
            void _destroyTmpPtrs();
            void _computeMaxNumNbors() override;

    };
}

#endif // WEIGHTEDADJCYSTRUCT_H
