/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <algorithm>
#include <vector>

#include <mpi.h>

#include <Epetra_MpiComm.h>
#include <Epetra_CrsGraph.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_MultiVector.h>
#include <Epetra_Import.h>

#include "hl_AdjcyENStruct.h"



using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

#include <unistd.h> //FIXME sleep function



namespace hiperlife
{


    void AdjcyENStruct::_generateAdjcyElemNodes_lagrangian()
    {
        int nVert = _connec->nVert();

        Epetra_Map graph_map(-1, _loc_nItem, 0, *_epComm);
        Epetra_Map sort_map(-1, _loc_nItem * nVert, 0, *_epComm);

        _adjcyElemNodes = rcp (new  Epetra_FECrsGraph(Copy, graph_map, nVert));
        _adjcyENSortI    = rcp (new  Epetra_IntVector (graph_map));
        _adjcyENSortJ    = rcp (new  Epetra_IntVector (sort_map));

        vector<int> auxNodes(nVert);
        vector<int> auxIdx(nVert);



        vector<int> copyList(nVert);

        for (int e = 0; e < _loc_nItem; e++)
        {
            int ee = _adjcyElemNodes->Map().GID(e);

            for (int v = 0; v < nVert; v++)
                auxNodes[v] = (*_connec->_adjcyConnec)[nVert * e + v];

//             sort(auxIdx.begin(), auxIdx.end(),
//                     [&](const int& a, const int& b) {
//                     return (auxNodes[a] < auxNodes[b]);});


            copyList = auxNodes;

            sort(auxNodes.begin(), auxNodes.end());
            for (unsigned i = 0; i < auxNodes.size(); i++)
            {
                auto it = std::find(copyList.begin(), copyList.end(), auxNodes[i]);
                auto posIdx = std::distance(copyList.begin(), it);

                auxIdx[posIdx] = i;
            }



            (*_adjcyENSortI)[e] = e * nVert;
            for (int v = 0; v < nVert; v++)
            {
                (*_adjcyENSortJ)[nVert * e + v] = auxIdx[v];
                _adjcyElemNodes->InsertGlobalIndices(1, &ee, 1, &auxNodes[v]);
            }

        }

    }



}
