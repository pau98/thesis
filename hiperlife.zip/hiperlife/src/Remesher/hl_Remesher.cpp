/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#include <string>
#include <numeric>
#include <map>

#include "hl_TypeDefs.h"
#include "hl_Math.h"
#include "hl_MpiHelpers.h"
#include "hl_BasicMeshGenerator.h"
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Iterative_Belos.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_CubatureGauss.h"
#include "hl_Tensor.h"
#include "hl_SurfLagrParam.h"
#include "hl_GlobalBasisFunctions.h"

#include "hl_Remesher.h"
#include "vtkSurfaceRemeshing.h"

#ifdef HL_VTK //FIXME:: Add ifdefs for all functions that depend on VTK
#include <vtkPolyData.h>
#include <vtkDoubleArray.h>
#include <vtkPointData.h>
#include <vtkCleanPolyData.h>
#endif


using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    void Remesher::setDOFsHandler(RCP<DOFsHandler> dhand, vector<int> intDOFs, vector<int> intAuxF)
    {
        // Add DOFsHandler
        _dhands.push_back(dhand);
        int _dhandsIdx = _dhands.size()-1;

        // Add DOFs
        _projectDOFs.push_back(vector<int>());
        _dofIdx.push_back(0);                        //FIXME:: Do we really need to count them?
        for (size_t i = 0 ; i < intDOFs.size(); i++)
        {
            _projectDOFs[_dhandsIdx].push_back(intDOFs[i]);
            _dofIdx[_dhandsIdx]=_dofIdx[_dhandsIdx]+1;
        }

        //Add auxF
        _projectAuxF.push_back(vector<int>());
        _auxFIdx.push_back(0);                        //FIXME:: Do we really need to count them?
        for (size_t i = 0; i<intAuxF.size();i++)
        {
            _projectAuxF[_dhandsIdx].push_back(intAuxF[i]);
            _auxFIdx[_dhandsIdx]=_auxFIdx[_dhandsIdx]+1;
        }
    }

    void Remesher::setDOFsHandler(RCP<DOFsHandler> dhand, vector<string> dofsTags, vector<string> auxFTags)
    {
        // Get DOFs ids
        vector<int> intDOFs(dofsTags.size());
        for (size_t dofIdx = 0 ; dofIdx < dofsTags.size(); dofIdx++)
            intDOFs[dofIdx]=dhand->nodeDOFs->index(dofsTags[dofIdx]);

        // Get AuxF ids
        vector<int> intAuxF(auxFTags.size());
        for (size_t auxFIdx = 0 ; auxFIdx < auxFTags.size(); auxFIdx++)
            intAuxF[auxFIdx]= dhand->nodeAuxF->index(auxFTags[auxFIdx]);

        // SetDOFsHandlers
        setDOFsHandler(dhand, intDOFs, intAuxF);
    }

    void Remesher::setDOFsHandlers(vector<RCP<DOFsHandler>> dhands, vector<vector<int>> intDOFs, vector<vector<int>> intAuxF)
    {
        for (size_t d = 0; d < dhands.size(); d++)
            setDOFsHandler(dhands[d], intDOFs[d], intAuxF[d]);
    }

    void Remesher::setDOFsHandlers(vector<RCP<DOFsHandler>> dhands, vector<vector<string>> DOFsTags, vector<vector<string>> AuxFTags)
    {
        for (size_t d = 0; d < dhands.size(); d++)
            setDOFsHandler(dhands[d], DOFsTags[d], AuxFTags[d]);
    }

    void Remesher::setRemeshParameters(int numIter, double aspectRatio, double trianglSplitFactor, int connecOptim)
    {

        _numIter     =numIter;
        _aspectRatio = aspectRatio;
        _triangleSplitFactor=trianglSplitFactor;
        _connecOptim       = connecOptim;
    }

    void Remesher::setDefaultParameters()
    {
        // Solver type
        if (_solverType == RemeshSolver::Undefined)
        {
            _solverType = RemeshSolver::AZ_Gmres;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: RemeshSolver set to default value AZ_Gmres." << endl;
        }

        // Projection method
        if (_projMethod == ProjectionMethod::Undefined)
        {
            _projMethod = ProjectionMethod::LeastSquares;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: ProjectionMethod set to default value LeastSquares." << endl;
        }

        // Remesh method
        if (_remeshMethod == RemeshMethod::Undefined)
        {
            _remeshMethod = RemeshMethod::Serial;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: RemeshMethod set to default value Serial." << endl;
        }

        // Improve mesh method
        if (_improveRemesh == false)
        {
            _improveRemesh = false;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: Improve mesh set to default value false." << endl;
        }

        // Number of iterations
        if (_numIter == 0)
        {
            _numIter = 3;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: Number of iterations set to default value 3." << endl;
        }

        // Aspect ratio
        if (_aspectRatio == 0.0)
        {
            _aspectRatio = 1.01;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: Aspect ratio set to default value 1.01." << endl;
        }

        // Triangle split factor
        if (_triangleSplitFactor == 0.0)
        {
            _triangleSplitFactor = 10.05;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: Triangle split factor set to default value 10.05." << endl;
        }

        // VTK connectivity optimization iterations
        if (_connecOptim == 0)
        {
            _connecOptim = 200;
            if (_myRank == 0)
                cout << "Remesher::setDefaultParameters: VTK connectivity optimization iterations set to default value 200." << endl;
        }
    }


    void Remesher::Update()
    {
        // Checks
        if (_solverType != RemeshSolver::AZ_Gmres and _solverType != RemeshSolver::AZ_ConjGrad and _solverType != RemeshSolver::BE_Gmres and _solverType != RemeshSolver::BE_ConjGrad and _solverType != RemeshSolver::MUMPS)
            throw runtime_error("Remesher::Update: Set the solver type or simply call subroutine Remesher::setDefaultParameters()");
        if (_projMethod != ProjectionMethod::LeastSquares)
            throw runtime_error("Remesher::Update: Set the method for projecting fields from old to new mesh or simply call subroutine Remesher::setDefaultParameters()");

        if (_numIter == 0)
            throw runtime_error("Remesher::Update: Set number of iterations for remeshing or simply call subroutine Remesher::setDefaultParameters()");
        if (_aspectRatio < 1e-10)
            throw runtime_error("Remesher::Update: Set target aspect ration of the elements in the new mesh or simply call subroutine Remesher::setDefaultParameters()");
        if (_triangleSplitFactor < 1e-10)
            throw runtime_error("Remesher::Update: Set the parameter _triangleSplitFactor or simply call subroutine Remesher::setDefaultParameters()");
        if (_connecOptim == 0)
            throw runtime_error("Remesher::Update: Set the parameter the number of optimization iterations for remeshing  or simply call subroutine Remesher::setDefaultParameters()");
        if (_dhands[0]->mesh->_basisFuncType == BasisFuncType::BSplines or _dhands[0]->mesh->_basisFuncType == BasisFuncType::Nurbs)
            throw runtime_error("Remesher::Update: BSplines and Nurbs not implemented.");
        if (_dhands[0]->mesh->_bfOrder > 1 and _myRank == 0)
            cout << endl << "Remesher::Update:Warning!!! Remesh may give wrong results with higher-order basis functions" << endl << endl;

        // Update
        if (_remeshMethod == RemeshMethod::Serial)
            _updateSerial();
        else
            _updateParallel();
            // throw runtime_error("Remesher::Update: Remeshing can only be done serially using VTK routines at the moment.");
    }

    void Remesher::_setSolver()
    {
        // Initialize the solvers
        RCP<AztecOOIterativeLinearSolver> linsolverAztecOO;
        RCP<MUMPSDirectLinearSolver> linsolverMUMPS;
        RCP<BelosIterativeLinearSolver> linsolverBelos;
        if (_solverType == RemeshSolver::AZ_Gmres or _solverType == RemeshSolver::AZ_ConjGrad)
        {
            linsolverAztecOO = rcp(new AztecOOIterativeLinearSolver());
            linsolverAztecOO->setHiPerProblem(_hiperProbl);
            linsolverAztecOO->setTolerance(1e-10);
            linsolverAztecOO->setMaxNumIterations(500);
            if (_solverType == RemeshSolver::AZ_Gmres)
                linsolverAztecOO->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
            else if (_solverType == RemeshSolver::AZ_ConjGrad)
                linsolverAztecOO->setSolver(AztecOOIterativeLinearSolver::Solver::ConjGrad);
            linsolverAztecOO->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
            linsolverAztecOO->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
            linsolverAztecOO->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
            linsolverAztecOO->setDefaultParameters();
            linsolverAztecOO->Update();
            _linSolver = linsolverAztecOO;
        }
        else if (_solverType == RemeshSolver::MUMPS)
        {
            linsolverMUMPS = rcp(new MUMPSDirectLinearSolver());
            linsolverMUMPS->setHiPerProblem(_hiperProbl);
            linsolverMUMPS->setMatrixType(MUMPSDirectLinearSolver::MatrixType::Symmetric);
            linsolverMUMPS->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
            linsolverMUMPS->setDefaultParameters();
            linsolverMUMPS->Update();
            _linSolver = linsolverMUMPS;
        }
        else if (_solverType == RemeshSolver::BE_Gmres or _solverType == RemeshSolver::BE_ConjGrad)
        {
            linsolverBelos = rcp(new BelosIterativeLinearSolver());
            linsolverBelos->setHiPerProblem(_hiperProbl);
            linsolverBelos->setTolerance(1e-10);
            linsolverBelos->setMaxNumIterations(500);
            linsolverBelos->setKrylovSpaceMaxSize(500);
            linsolverBelos->setMaxNumRestarts(500);
            if (_solverType==RemeshSolver::BE_Gmres)
                linsolverBelos->setSolver(BelosIterativeLinearSolver::Solver::PseudoBlockGMRES);
            else if (_solverType==RemeshSolver::BE_ConjGrad)
                linsolverBelos->setSolver(BelosIterativeLinearSolver::Solver::BlockCG);
            linsolverBelos->setPreconditioner(BelosIterativeLinearSolver::Preconditioner::Ilu);
            linsolverBelos->setPreconditionerSide(BelosIterativeLinearSolver::PreconditionerSide::Right);
            linsolverBelos->setVerbosity(BelosIterativeLinearSolver::Verbosity::None);
            linsolverBelos->Update();
            _linSolver = linsolverBelos;
        }
    }

    void Remesher::newDOFsHands(RCP<DOFsHandler>& dhand)
    {
        dhand = Teuchos::null;
        dhand = _dhands[0];
    }

    void Remesher::newDOFsHands(vector<RCP<DOFsHandler>>& dhands)
    {
        for (size_t dofHandIdx=0;dofHandIdx<_dhands.size();dofHandIdx++)
        {
            dhands[dofHandIdx] = Teuchos::null;
            dhands[dofHandIdx] = _dhands[dofHandIdx];
        }
    }


    void LS(FillStructure& fillStr)
    {
        using namespace std;
        using namespace hiperlife::Tensor;

        //INPUTS
        auto &subFill_ = fillStr["interpolateDOFs"];
        int nDim_ = subFill_.nDim;
        int eNN_ = subFill_.eNN;
        int numDOFs_ = subFill_.numDOFs;
        int N_e = numDOFs_ * eNN_;
        int ll{};
        std::vector<int> _dofIdx;
        std::vector<int> _auxFIdx;
        int _dhandsIdx=fillStr.paramStr->i_aux.size()/2;

        for (size_t dhandsIdx = 0 ; dhandsIdx< fillStr.paramStr->i_aux.size()/2;dhandsIdx++)
        {
            _dofIdx.push_back(fillStr.paramStr->i_aux[2*dhandsIdx]);
            _auxFIdx.push_back(fillStr.paramStr->i_aux[2*dhandsIdx + 1]);
        }

        tensor<double, 2, false> nborCoords_(subFill_.nborCoords.data(), eNN_, nDim_);
        tensor<double, 2, false> nborDOFs0_(subFill_.nborDOFs0.data(), eNN_, numDOFs_);
        tensor<double, 2, false> nborDOFs_(subFill_.nborDOFs.data(), eNN_, numDOFs_);


        //MAIN OUTPUT declaration
        auto &Ak = fillStr.Ak(0, 0); // <<=== MAIN OUTPUT
        auto &Bk = fillStr.Bk(0);    // <<=== MAIN OUTPUT

        double *bf_ = subFill_.nborBFs();
        double *dbf_ = subFill_.nborBFsGrads();
        double x_[3];
        std::vector<double> xTarget(numDOFs_);
        double metric[4];
        double e1[3], e2[3];


        Math::MatTMult(x_, 3, eNN_, 1, nborCoords_.data(), bf_);
        SurfLagrParam::MetricTensor(metric, e1, e2, eNN_, nborCoords_.data(), dbf_);
        double jac = sqrt(Math::DetMat2x2(metric));

        if (!fillStr.paramStr->bparam[0])
        {
            fillStr.paramStr->x_aux.push_back(x_[0]);
            fillStr.paramStr->y_aux.push_back(x_[1]);
            fillStr.paramStr->z_aux.push_back(x_[2]);
        }
        else if (fillStr.paramStr->bparam[0])
        {

            for (int dhandIdx=0;dhandIdx<_dhandsIdx;dhandIdx++)
            {

                for (int dofIdx=0; dofIdx<_dofIdx[dhandIdx]; dofIdx++)
                {
                    xTarget[ll] = fillStr.paramStr->u_aux[fillStr.paramStr->iparam[0]];
                    ll++;
                    fillStr.paramStr->iparam[0]++;
                }
                for (int auxFIdx=0; auxFIdx<_auxFIdx[dhandIdx]; auxFIdx++)
                {
                    xTarget[ll] = fillStr.paramStr->u_aux[fillStr.paramStr->iparam[0]];
                    ll++;
                    fillStr.paramStr->iparam[0]++;
                }
            }
        }


        // Fill linear system
        for (int i = 0; i < eNN_; i++)
        {
            // Fill RHS
            for (int n = 0; n < numDOFs_; n++)
            {
                if (fillStr.paramStr->bparam[0])
                    Bk[numDOFs_ * i + n] += jac * bf_[i] * xTarget[n];
                else
                    Bk[numDOFs_ * i + n] += 0.0;
            }

            // Fill LHS
            for (int j = 0; j < eNN_; j++)
            {
                for (int n = 0; n < numDOFs_; n++)
                    Ak[(numDOFs_ * i + n) * N_e + numDOFs_ * j + n] += jac * bf_[i] * bf_[j];
            }
        }

        return;
    }

    void LS_L2projection(FillStructure& fillStr)
    {
        using namespace hiperlife::Tensor; // FIXME: Remove tensors
        using std::vector;

        //*************************************************************************
        // [0] Initialize
        //*************************************************************************

        // Rename variables
        SubFillStructure& subFill = fillStr[0];
        int nDOFs = subFill.numDOFs;   // Number of degrees of freedom
        int eNN   = subFill.eNN;       // Number of neighbor nodes
        int pDim  = subFill.pDim;      // Number of parametric dimension
        int niPts = subFill.cubaInfo.iPts; // Number of integration points
        int iPts  = subFill.kPt;       // Integration point id
        int loc_elem  = subFill.loc_elemID;    // Element id
        tensor<double,4, false> Ak(fillStr.Ak(0,0).data(), eNN, nDOFs, eNN, nDOFs);
        tensor<double,2, false> Bk(fillStr.Bk(0).data(), eNN, nDOFs);

        // Shape functions and derivatives at Gauss points
        double jac;
        tensor<double,1, false> bf(subFill.nborBasisFunctions(), eNN);
        tensor<double,2> gbf(eNN, pDim);
        GlobalBasisFunctions::gradients(gbf, jac, subFill);


        //*************************************************************************
        // [1] Get fields at integration points
        //*************************************************************************

        // Fields at gauss points
        vector<double>::const_iterator first = fillStr.paramStr->a_aux.begin() + (loc_elem*niPts+iPts)*nDOFs;
        vector<double> fields(first, first+nDOFs);

        //*************************************************************************
        // [2] Fill linear system
        //*************************************************************************

        // Fill
        for (int i = 0; i < nDOFs; i++)
        {
            Bk(all, i) += jac*bf*fields[i];
            Ak(all, i, all, i) += jac*outer(bf, bf);
        }

        return;
    }

    void Remesher::_remeshParallel_Triang()
    {
        //*************************************************************************
        // [0] Gather mesh
        //*************************************************************************

        // Gather mesh
        RCP<DistributedMesh> disMesh = _dhands[0]->mesh;
        disMesh->_allGatherMesh(_globConnect, _x_nodes);


        //*************************************************************************
        // [1] Remesh using vtk and create basic mesh generator
        //*************************************************************************

        // Initialize basicMesh corresponding to the new distributed mesh
        RCP<BasicMeshGenerator> basicMesh = rcp(new BasicMeshGenerator());
        basicMesh->setMesh(ElemType::Triang, disMesh->_basisFuncType, disMesh->_bfOrder);
        basicMesh->setMeshType(MeshType::Sequential);

        // Remesh in one processor using vtk
        int nPts, nElem;
        int _nDim = disMesh->_nDim;
        if (_myRank == 0)
        {
            // Create points
            vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
            for (int n = 0; n < disMesh->nPts(); n++)
                points->InsertNextPoint(_x_nodes[_nDim*n + 0], _x_nodes[_nDim*n + 1], _x_nodes[_nDim*n + 2]);

            // Create cells
            vtkSmartPointer<vtkCellArray> cells = vtkSmartPointer<vtkCellArray>::New();
            for (int e = 0; e < disMesh->nElem(); e++)
            {
                vtkSmartPointer<vtkIdList> element = vtkSmartPointer<vtkIdList>::New();
                for (int n = 0; n < disMesh->nVert(); n++)
                    element->InsertNextId(_globConnect[disMesh->nVert()*e + n]);
                cells->InsertNextCell(element);
            }

            // Initialize target area
            vtkSmartPointer<vtkDoubleArray> targetAreaArray = vtkSmartPointer<vtkDoubleArray>::New();
            targetAreaArray->SetNumberOfComponents(1);
            targetAreaArray->SetNumberOfTuples(disMesh->nPts());
            targetAreaArray->SetName("TargetArea");

            // Assign a target area to each element based on the user input
            for (int n = 0; n < disMesh->nPts(); n++)
            {
                double targetArea{};
                if (_area < 0)
                    targetArea = _areaFunc(_x_nodes[_nDim*n+0], _x_nodes[_nDim*n+1], _x_nodes[_nDim*n+2]);
                else
                    targetArea = _area;
                targetAreaArray->SetTuple(n, &targetArea);
            }

            // Create polyData
            vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
            polydata->SetPoints(points);
            polydata->SetPolys(cells);
            polydata->GetPointData()->SetScalars(targetAreaArray);

            // Remesh based on the target area
            vtkSmartPointer<vtkSurfaceRemeshing> vtkRemeshing = vtkSurfaceRemeshing::New();
            vtkRemeshing->SetInputData(polydata);
            vtkRemeshing->SetElementSizeModeToTargetAreaArray();
            vtkRemeshing->SetTargetAreaArrayName("TargetArea");
            vtkRemeshing->SetNumberOfIterations(_numIter);
            vtkRemeshing->SetAspectRatioThreshold(_aspectRatio);
            vtkRemeshing->SetTriangleSplitFactor(_triangleSplitFactor);
            vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(_connecOptim);
            vtkRemeshing->Update();

            // Clean up
            vtkSmartPointer <vtkCleanPolyData> vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData(vtkRemeshing->GetOutput());
            vtkClean->Update();

            // Get output
            auto vtkoutput = vtkClean->GetOutput();

            // Save nPts and nElem
            nPts = vtkoutput->GetNumberOfPoints();
            nElem = vtkoutput->GetNumberOfCells();

            // Set global node coordinates
            basicMesh->_glob_x_nodes.resize(nPts*_nDim, 0.0);
            for (int i = 0; i < nPts; i++)
            {
                double x[3];
                vtkoutput->GetPoint(i, x);
                basicMesh->_glob_x_nodes[_nDim*i + 0] = x[0];
                basicMesh->_glob_x_nodes[_nDim*i + 1] = x[1];
                basicMesh->_glob_x_nodes[_nDim*i + 2] = x[2];
            }

            // Set global connectivity
            basicMesh->_glob_connec.resize(nElem * disMesh->nVert(), 0);
            for (int i = 0; i < nElem; i++)
            {
                vtkSmartPointer <vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                basicMesh->_glob_connec[disMesh->nVert()*i + 0] = ptsIds->GetId(0);
                basicMesh->_glob_connec[disMesh->nVert()*i + 1] = ptsIds->GetId(1);
                basicMesh->_glob_connec[disMesh->nVert()*i + 2] = ptsIds->GetId(2);
            }

            //Temporarily setting creases and eFlags to 0
            basicMesh->_glob_creases.resize(nPts * disMesh->_nCrease, 0);
            basicMesh->_glob_eflags.resize(nElem * disMesh->_nEFlags, 0);

        }

        // Broadcast nPts and nElem to all processors
        MPI_Bcast(&nPts, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&nElem, 1, MPI_INT, 0, MPI_COMM_WORLD);
        basicMesh->setNElem(nElem);
        basicMesh->setNPts(nPts);

        // Resize vectors of the basic mesh in the remaining processors
        if (_myRank != 0)
        {
            basicMesh->_glob_x_nodes.resize(nPts * _nDim, 0.0);
            basicMesh->_glob_connec.resize(nElem * disMesh->nVert(), 0);
            basicMesh->_glob_creases.resize(nPts * disMesh->_nCrease, 0);
            basicMesh->_glob_eflags.resize(nElem * disMesh->_nEFlags, 0);
        }


        //*************************************************************************
        // [2] Distribute the mesh
        //*************************************************************************

        _disNewMesh = rcp(new DistributedMesh());
        _disNewMesh->setMesh(basicMesh);
        _disNewMesh->setElementLocatorEngine(disMesh->elementLocatorEngine());
        _disNewMesh->setBalanceMesh(true);
        _disNewMesh->Update();

        // _disNewMesh->printFileLegacyVtk("NewMesh_parallel"); // <----------------------------- Remove
    }

    void Remesher::_remeshParallel_Square()
    {
        // Checks
        if (_dhands[0]->mesh->_meshCrea->nameTag() != "StructMeshGenerator")
            throw runtime_error("Remesher::_remeshParallel_Square:: Only works for structured mesh generators");

        //*************************************************************************
        // [0] Initialize
        //*************************************************************************

        RCP<DistributedMesh> disMesh = _dhands[0]->mesh;

        //*************************************************************************
        // [1] Refine
        //*************************************************************************

        // Create struct mesh with the original elements
        RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
        mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
        mesh->genStructMesh(disMesh->_meshCrea->_nEx, disMesh->_meshCrea->_nEy); // FIXME:: Does not work with transformations

        // Loop and subdivide
        bool subdivide{true};
        for (int l = 1; subdivide; l++)
        {
            // if (_myRank == 0)
            //     cout << "subdiv " << endl;
            // Initialize
            int nDim  = mesh->_nDim;
            int nVert = mesh->_nVert;
            int nPts  = mesh->_nPts;
            int loc_nElem = mesh->_loc_nElem;
            int loc_nPts = mesh->_loc_nPts;

            // Share mesh coordinates for interpolation and rearrange them
            // if (_myRank == 0)
            //     cout << "share " << endl;
            vector<double> coords(loc_nPts*3);
            for (int i = 0; i < loc_nPts; i++)
            {
                coords[i*3+0] = mesh->_x_nodes[loc_nPts*0+i];
                coords[i*3+1] = mesh->_x_nodes[loc_nPts*1+i];
                coords[i*3+2] = mesh->_x_nodes[loc_nPts*2+i];
            }
            vector<double> gCoords = MpiHelpers::allgatherv(coords, _numProcs, _myRank);
            vector<vector<double>> gCoords_v(nPts, vector<double>(nDim));
            for (int i = 0; i < nPts; i++)
                for (int d = 0; d < nDim; d++)
                    gCoords_v[i][d] = gCoords[i*nDim + d];

            // Interpolate field with refinement levels at mesh coordinates
            // if (_myRank == 0)
            //     cout << "interpolate " << endl;
            vector<vector<double>> refLevel = _dhands[0]->interpolateField(_dhands[0]->nodeDOFs, vector<int>{0}, gCoords_v);


            // Save vector of local node subdivision levels
            // if (_myRank == 0)
            //     cout << "Levels " << endl;
            vector<int> vec_nSL;
            for (int e = 0; e < loc_nElem; e++)
            {
                // Get nodal subdivision level
                vector<int> S(nVert, 0);
                for (int i = 0; i < nVert; i++)
                {
                    // Initialize
                    int nbor = mesh->_connec[e*nVert+i];

                    double level = refLevel[nbor][0];
                    if (_fieldModifier != nullptr)
                        level = _fieldModifier(level);
                    if (level >= l)
                        S[i] = 1;
                }

                // Refine all element to assure no inter-level overlap
                if (S[0]+S[1]+S[2]+S[3] > 0)
                {
                    for (int i = 0; i < nVert; i++)
                        if (S[i] == 0)
                            S[i] = 1;
                }

                // Save to vector
                for (int i = 0; i < nVert; i++)
                {
                    int nbor = mesh->_connec[e*nVert+i];
                    if (S[i] > 0)
                        vec_nSL.push_back(nbor);
                }
            }

            // Remove repeated and share
            std::sort(vec_nSL.begin(), vec_nSL.end());
            vec_nSL.erase(std::unique(vec_nSL.begin(), vec_nSL.end()), vec_nSL.end());
            vector<int> glob_vec_nSL = MpiHelpers::allgatherv(vec_nSL, _numProcs, _myRank);

            // Stop if no more subdivisions are required
            if (glob_vec_nSL.size() == 0)
            {
                // if (_myRank == 0)
                //     cout << "End " << endl << endl;
                subdivide = false;
                break;
            }

            // Save global subdivision levels
            std::map<int,int> nodeSubdivLevels;
            for (auto c: glob_vec_nSL)
                nodeSubdivLevels[c] = 1;

            // Call refinement;
            // if (_myRank == 0)
            //     cout << "refine " << endl;
            mesh->threeRefine(nodeSubdivLevels, IndexType::Global);

            // if (_myRank == 0)
            //     cout << "End " << endl << endl;
        }

        //*************************************************************************
        // [2] Distribute the mesh
        //*************************************************************************

        _disNewMesh = rcp(new DistributedMesh());
        _disNewMesh->setMesh(mesh);
        _disNewMesh->setElementLocatorEngine(disMesh->elementLocatorEngine());
        _disNewMesh->setBalanceMesh(true);
        _disNewMesh->Update();

        // _disNewMesh->printFileLegacyVtk("NewMesh_parallel"); // <----------------------------- Remove
    }

    void Remesher::_projectFieldsParallel()
    {
        Timer timer({"Gauss", "find", "intG", "interp"});

        //*************************************************************************
        // [0] Initialize
        //*************************************************************************

        // Initialize
        ElemType eType = _disNewMesh->elemType();
        int pDim = _disNewMesh->_pDim;
        int nDim = _disNewMesh->_nDim;
        int loc_nElem = _disNewMesh->loc_nElem();
        int nElem = _disNewMesh->nElem();


        //*************************************************************************
        // [1] Create points for the interpolation based on a Gauss cubature
        //*************************************************************************

        timer.start("Gauss");
        // Create cubature
        RCP<CubatureGauss> cuba = rcp(new CubatureGauss);
        cuba->setElemType(eType);
        if (_disNewMesh->elemType() == ElemType::Triang)
            cuba->setNumIntPts(3);
        else if (_disNewMesh->elemType() == ElemType::Square)
            cuba->setNumIntPts(4);
        // cuba->setNumIntPts(1);
        // cuba->setNumIntPts(computeDefaultNumGPts(eType, _disNewMesh->_bfOrder+1));
        cuba->Update();

        // Get reference coordinates of the cubature
        int niPts = cuba->iPts();
        vector<vector<double>> xSamples(niPts, vector<double>(pDim));
        for (int i = 0; i < niPts; i++)
            for (int d = 0; d < pDim; d++)
                xSamples[i][d] = cuba->_xSamples[pDim*i+d];

        // Get local gauss points coordinates
        vector<double> loc_gCoords(loc_nElem*niPts*nDim);
        for (int e = 0; e < loc_nElem; e++)
        {
            for (int i = 0; i < niPts; i++)
            {
                vector<double> coords = _disNewMesh->interpolatePosition(e, xSamples[i], IndexType::Local);
                for (int d = 0; d < nDim; d++)
                    loc_gCoords[e*niPts*nDim + i*nDim + d] = coords[d];
            }
        }

        // Share gauss points
        vector<double> gCoords = MpiHelpers::allgatherv(loc_gCoords, _numProcs, _myRank);

        // Rearrange gauss points in a vector of vectors
        vector<vector<double>> gCoords_v(nElem*niPts, vector<double> (nDim));
        for (int e = 0; e < nElem; e++)
            for (int i = 0; i < niPts; i++)
                for (int d = 0; d < nDim; d++)
                    gCoords_v[e*niPts + i][d] = gCoords[e*niPts*nDim + i*nDim + d];
        timer.end("Gauss");


        //*************************************************************************
        // [2] Interpolate points and save to user structure
        //*************************************************************************

        // Interpolate
        timer.start("intG");
        vector<vector<double>> fields = _dhands[0]->interpolateField(_dhands[0]->nodeDOFs, vector<int>{0}, gCoords_v);

        // Save fields to user structure
        userStr->a_aux.resize(loc_nElem*niPts);
        int nFields = fields[0].size(); // FIXME
        for (int e = 0; e < nElem; e++)
        {
            if (_disNewMesh->isElemInPart(e))
            {
                int loc_e = e - _disNewMesh->_connec->offs_nElem();
                for (int i = 0; i < niPts; i++)
                {
                    for (int f = 0; f < nFields; f++)
                    {
                        userStr->a_aux[(loc_e*niPts+i)*nFields+f] = fields[e*niPts+i][f];
                    }
                }
            }
        }
        timer.end("intG");


        //*************************************************************************
        // [3] Project fields
        //*************************************************************************

        timer.start("interp");
        // Create dofs handler to perform the interpolation
        RCP<DOFsHandler> dofHandI = rcp(new DOFsHandler(_disNewMesh));
        dofHandI->setNameTag("interpolation");
        dofHandI->setNumDOFs(1); // FIXME:: Use all dofs and fields
        dofHandI->Update();

        // Create hiperproblem for the projection
        _hiperProbl = rcp(new HiPerProblem);
        _hiperProbl->setParameterStructure(userStr);
        _hiperProbl->setDOFsHandlers({dofHandI});
        _hiperProbl->setIntegration("Integ", {"interpolation"});
        _hiperProbl->setCubatureGauss("Integ", niPts);
        if (*_LS == nullptr)
        {
            if (_projMethod == ProjectionMethod::LeastSquares)
                _hiperProbl->setElementFillings("Integ", LS_L2projection);
            else
                throw runtime_error("The interpolation from gauss points to the nodes can only be done by least square fitting method at the moment.");
        }
        else
        {
            _hiperProbl->setElementFillings("Integ", _LS);
        }
        _hiperProbl->Update();


        // Set solver
        if (_linSolver == Teuchos::null)
            _setSolver();

        // Project
        _linSolver->solve();
        _linSolver->UpdateSolution();

        timer.end("interp");

        // dofHandI->printFileLegacyVtk("dhand_parallel", false); // <----------------------------- Remove

        // timer.printTiming();


        //*************************************************************************
        // [4] Save results in dofs handler
        //*************************************************************************

        // Update dofs handler // FIXME:: Use all dofs and fields
        string _tag = _dhands[0]->nameTag();
        _dhands[0] = Teuchos::null;
        _dhands[0] = rcp(new DOFsHandler(_disNewMesh));
        _dhands[0]->setNameTag(_tag);
        _dhands[0]->setDOFs({"DOF_0"});
        _dhands[0]->Update();

        for (int i = 0; i < _disNewMesh->loc_nPts(); i++)
        {
            double dof = dofHandI->nodeDOFs->getValue(0, i, IndexType::Local);
            _dhands[0]->nodeDOFs->setValue(0, i, IndexType::Local, dof);
        }
    }

    void Remesher::_updateParallel()
    {
        Timer timer({"Init", "Gath", "Rmsh", "Comb", "5", "proj", "LS", "8"});

        // Remesh
        timer.start("Rmsh");
        if (_dhands[0]->mesh->elemType() == ElemType::Triang)
            _remeshParallel_Triang();
        else if (_dhands[0]->mesh->elemType() == ElemType::Square)
            _remeshParallel_Square();
        else
            throw runtime_error("Remesher::_updateParallel: Remesher only working for Triang and Square elements mode.");
        timer.end("Rmsh");

        // Project fields from the old dhand to the gauss points of the new mesh
        timer.start("proj");
        _projectFieldsParallel();
        timer.end("proj");

        // timer.printTiming();
    }

    void Remesher::_remesh()
    {
        RCP<DistributedMesh> disMesh = _dhands[0]->mesh;

        // Total no. of nodes and elements in the new mesh
        int _nDim    =  disMesh->_nDim;
        int _nCrease =  disMesh->_nCrease;
        int _nEFlags =  disMesh->_nEFlags;
        int _bfOrder =  disMesh->_bfOrder;

        // _nElem and _nPts in the new mesh
        int _nElem, _nPts;

        // Initialize basicMesh corresponding to the new distributed mesh
        RCP<BasicMeshGenerator> basicMesh = rcp(new BasicMeshGenerator());

        // Perform remeshing in rank 0
        if (_dhands[0]->myRank()==0)
        {

            vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
            vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
            vtkSmartPointer<vtkCellArray> cells = vtkSmartPointer<vtkCellArray>::New();
            for (int node_idx = 0; node_idx < disMesh->nPts(); node_idx++)
            {
                points->InsertNextPoint(_x_nodes[_nDim * node_idx + 0], _x_nodes[_nDim * node_idx + 1], _x_nodes[_nDim * node_idx + 2]);
            }
            polydata->SetPoints(points);

            for (int i = 0; i < disMesh->nElem(); i++)
            {
                vtkSmartPointer<vtkIdList> element = vtkSmartPointer<vtkIdList>::New();
                for (int k = 0; k < disMesh->nVert(); k++)
                {
                    element->InsertNextId(_globConnect[disMesh->nVert() * i + k]);
                }
                cells->InsertNextCell(element);
            }
            polydata->SetPolys(cells);


            vtkSmartPointer<vtkDoubleArray> targetAreaArray = vtkSmartPointer<vtkDoubleArray>::New();
            targetAreaArray->SetNumberOfComponents(1);
            targetAreaArray->SetNumberOfTuples(disMesh->nPts());
            targetAreaArray->SetName("TargetArea");

            // Assigning a gradient in the size of elements
            for (int node_idx = 0; node_idx < _dhands[0]->mesh->nPts(); node_idx++)
            {
                double x1 = _x_nodes[_nDim * node_idx + 0];
                double x2 = _x_nodes[_nDim * node_idx + 1];
                double x3 = _x_nodes[_nDim * node_idx + 2];
                double targetArea{};
                if (_area<0)
                    targetArea = _areaFunc(x1,x2,x3) ;
                else
                    targetArea = _area;
                targetAreaArray->SetTuple(node_idx, &targetArea);
            }
            polydata->GetPointData()->SetScalars(targetAreaArray);

            vtkSmartPointer<vtkSurfaceRemeshing> vtkRemeshing = vtkSurfaceRemeshing::New();
            vtkRemeshing->SetInputData( polydata );
            vtkRemeshing->SetElementSizeModeToTargetAreaArray();
            vtkRemeshing->SetTargetAreaArrayName("TargetArea");
            vtkRemeshing->SetNumberOfIterations(_numIter);
            vtkRemeshing->SetAspectRatioThreshold(_aspectRatio);
            vtkRemeshing->SetTriangleSplitFactor(_triangleSplitFactor);
            vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(_connecOptim);
            vtkRemeshing->Update();


            vtkSmartPointer <vtkCleanPolyData> vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData(vtkRemeshing->GetOutput());
            vtkClean->Update();


            auto vtkoutput = vtkClean->GetOutput();
            _nPts = vtkoutput->GetNumberOfPoints();
            _nElem = vtkoutput->GetNumberOfCells();

            basicMesh->_glob_x_nodes.resize(_nPts * _nDim, 0.0);
            for (int i = 0; i < _nPts; i++)
            {
                double x[3];
                vtkoutput->GetPoint(i, x);
                basicMesh->_glob_x_nodes[_nDim * i + 0] = x[0];
                basicMesh->_glob_x_nodes[_nDim * i + 1] = x[1];
                basicMesh->_glob_x_nodes[_nDim * i + 2] = x[2];
            }


            basicMesh->_glob_connec.resize(_nElem * disMesh->nVert(), 0);
            for (int i = 0; i < _nElem; i++)
            {
                vtkSmartPointer <vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                basicMesh->_glob_connec[disMesh->nVert() * i + 0] = ptsIds->GetId(0);
                basicMesh->_glob_connec[disMesh->nVert() * i + 1] = ptsIds->GetId(1);
                basicMesh->_glob_connec[disMesh->nVert() * i + 2] = ptsIds->GetId(2);
            }

            //Temporarily setting creases and eFlags to 0
            basicMesh->_glob_creases.resize(_nPts * _nCrease, 0);
            basicMesh->_glob_eflags.resize(_nElem * _nEFlags, 0);
        }

        // Send _nPts and _nElem  from proc 0 to rest of the processors
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, MPI_COMM_WORLD);

        if (_dhands[0]->myRank() > 0)
        {
            basicMesh->_glob_x_nodes.resize(_nPts * _nDim, 0.0);
            basicMesh->_glob_connec.resize(_nElem * disMesh->nVert(), 0);
            basicMesh->_glob_creases.resize(_nPts * _nCrease, 0);
            basicMesh->_glob_eflags.resize(_nElem * _nEFlags, 0);
        }

        // Create mesh generator
        basicMesh->setNElem(_nElem);
        basicMesh->setNPts(_nPts);
        basicMesh->setMeshType(MeshType::Sequential);
        basicMesh->setBasisFuncType(_dhands[0]->mesh->_basisFuncType);
        basicMesh->setBasisFuncOrder(_bfOrder);
        basicMesh->setElemType(ElemType::Triang);

        // Distribute the mesh
        _disNewMesh = rcp(new DistributedMesh());
        _disNewMesh->setMesh(basicMesh);
        _disNewMesh->setBalanceMesh(true);
        _disNewMesh->Update();

        // _disNewMesh->printFileLegacyVtk("NewMesh_Serial"); // <----------------------------- Remove
    }

    void Remesher::_projectFields()
    {
        // Interpolate fields at Gauss points
        for (size_t array_idx = 0; array_idx < userStr->x_aux.size(); array_idx++)
        {
            // Get point
            vector<double> xx_(3);
            xx_[0] = userStr->x_aux[array_idx];
            xx_[1] = userStr->y_aux[array_idx];
            xx_[2] = userStr->z_aux[array_idx];

            // Find element and rCoords
            int idx;
            vector<double> rCoords(3);
            int flag = dofHandSerial->mesh->searchElement(idx, rCoords, xx_);
            if (flag == -1)
                throw runtime_error("Closest point projection failed.");

            if (rCoords[0] < 0) //FIXME:: WHY??!!
                rCoords[0] = 0;
            if (rCoords[1] < 0)
                rCoords[1] = 0;

            // Interpolate DOFs and AuxF
            int ll{};
            for (size_t dhandIdx = 0; dhandIdx < _dhands.size(); dhandIdx++)
            {
                // DOFs
                for (int dofIdx=0; dofIdx<_dofIdx[dhandIdx]; dofIdx++)
                {
                    double dof = dofHandSerial->interpolateDOFs(ll, idx, rCoords, IndexType::Global);
                    ll++;
                    userStr->u_aux.push_back(dof);
                }

                // AuxF
                for (int auxFIdx=0; auxFIdx<_auxFIdx[dhandIdx]; auxFIdx++)
                {
                    double auxF = dofHandSerial->interpolateAuxF(ll, idx, rCoords, IndexType::Global); //FIXME: DOFs??
                    ll++;
                    userStr->u_aux.push_back(auxF);
                }
            }
        }
    }

    void Remesher::_combineDOFs()
    {

        int myRank = _dhands[0]->myRank();
        int numProcs = _dhands[0]->numProcs();

        //Get the max size
        int recvCount[numProcs];
        int globDisp[numProcs];
        int disp_v[numProcs];

        int totalDOFIdx  = accumulate(_dofIdx.begin(), _dofIdx.end(), 0);
        int totalauxFIdx = accumulate(_auxFIdx.begin(), _auxFIdx.end(), 0);

        // Communicate the data structure
        std::vector<double> dofs_((totalDOFIdx+totalauxFIdx)*_dhands[0]->mesh->nPts());
        for (int i=0;i<_dhands[0]->mesh->loc_nPts();i++)
        {

            for (size_t dhandIdx=0;dhandIdx<_dhands.size();dhandIdx++)
            {

                for (int dofIdx=0; dofIdx<_dofIdx[dhandIdx]; dofIdx++)
                {
                    double dof = _dhands[dhandIdx]->nodeDOFs->getValue(_projectDOFs[dhandIdx][dofIdx],i,IndexType::Local);
                    userStr->v_aux.push_back(dof);
                }
                for (int auxFIdx=0; auxFIdx<_auxFIdx[dhandIdx]; auxFIdx++)
                {
                    double auxF = _dhands[dhandIdx]->nodeAuxF->getValue(_projectAuxF[dhandIdx][auxFIdx],i,IndexType::Local);
                    userStr->v_aux.push_back(auxF);
                }
            }
        }

        globDisp[myRank]=userStr->v_aux.size();

        for (int proc_idx=0;proc_idx<numProcs;proc_idx++)
        {
            recvCount[proc_idx]=1;
            disp_v[proc_idx]=proc_idx;
        }
        MPI_Allgatherv(&globDisp[myRank], 1 , MPI_INT, &globDisp[0], recvCount, disp_v, MPI_INT, MPI_COMM_WORLD);

        //Get offset for each processors
        for (int i=0;i<myRank; i++)
        {
            userStr->iparam[0]+=globDisp[i];
        }


        for (int i = 0; i < globDisp[myRank]; i++)
        {
            dofs_[userStr->iparam[0] + i] = userStr->v_aux[i];
        }

        recvCount[0]=0;
        for (int proc_idx=1; proc_idx<numProcs;proc_idx++)
        {
            recvCount[proc_idx]=0;
            for (int j=1; j<proc_idx+1;j++)
            {
                recvCount[proc_idx] += globDisp[j-1];
            }
        }

        MPI_Allgatherv(&dofs_[userStr->iparam[0]], globDisp[myRank], MPI_DOUBLE, &dofs_[0], globDisp, recvCount, MPI_DOUBLE, MPI_COMM_WORLD);

        userStr->v_aux.resize(0);
        for (int array_idx = 0; array_idx <(totalDOFIdx+totalauxFIdx)*_dhands[0]->mesh->nPts(); array_idx++)
        {
            userStr->v_aux.push_back(dofs_[array_idx]);
        }
    }

    void Remesher::_updateSerial()
    {
        // Check
        if (_dhands[0]->mesh->elemType() != ElemType::Triang)
            throw runtime_error("Remesher::_updateSerial: Remesher only working for Triang elements in serial mode.");

        Timer timer({"Init", "Gath", "Rmsh", "Comb", "5", "proj", "LS", "8"});

        timer.start("Init");
        userStr->iparam.resize(3);
        userStr->bparam.resize(3);
        userStr->x_aux.resize(0);
        userStr->y_aux.resize(0);
        userStr->z_aux.resize(0);
        userStr->iparam[0]=0;
        userStr->bparam[0]=false;
        userStr->u_aux.resize(0);
        userStr->i_aux.resize(2*_dhands.size());
        for (size_t dhandsIdx = 0 ; dhandsIdx<_dhands.size();dhandsIdx++)
        {
            userStr->i_aux[2*dhandsIdx]     = _dofIdx[dhandsIdx];
            userStr->i_aux[2*dhandsIdx + 1] = _auxFIdx[dhandsIdx];
        }
        int totalDOFIdx  = accumulate(_dofIdx.begin(), _dofIdx.end(), 0);
        int totalauxFIdx = accumulate(_auxFIdx.begin(), _auxFIdx.end(), 0);
        int ll{};
        timer.end("Init");

        // Gather mesh information
        timer.start("Gath");
        _dhands[0]->mesh->_allGatherMesh(_globConnect, _x_nodes);
        timer.end("Gath");

        // Perform remeshing
        timer.start("Rmsh");
        _remesh();
        timer.end("Rmsh");

        // Combine dofs
        timer.start("Comb");
        _combineDOFs();
        timer.end("Comb");


        // Create basic mesh generator object
        timer.start("5");
        RCP<BasicMeshGenerator> basicMesh = rcp(new BasicMeshGenerator());
        basicMesh->setMesh(_dhands[0]->mesh->elemType(), _dhands[0]->mesh->_adjcyEN->basisFuncType(), _dhands[0]->mesh->_bfOrder);
        basicMesh->setMeshType(MeshType::Sequential);
        basicMesh->_glob_creases.resize(_dhands[0]->mesh->_nCrease*_x_nodes.size()/_dhands[0]->mesh->nDim());
        basicMesh->_glob_eflags.resize(_globConnect.size()/_dhands[0]->mesh->nDim());
        basicMesh->setNElem(_globConnect.size()/_dhands[0]->mesh->nDim());
        basicMesh->setNPts(_x_nodes.size()/_dhands[0]->mesh->nDim());
        basicMesh->setGlobCoords(_x_nodes);
        basicMesh->setGlobCreases(basicMesh->_glob_creases);
        basicMesh->setGlobConnec(_globConnect);

        RCP<DistributedMesh> disMeshSerial = rcp(new DistributedMesh("DistributedMesh", MPI_COMM_SELF));
        disMeshSerial->setMesh(basicMesh);
        disMeshSerial->setBalanceMesh(false);
        disMeshSerial->Update();

        dofHandSerial = rcp(new DOFsHandler("DOFsHandler", MPI_COMM_SELF));
        dofHandSerial->mesh = disMeshSerial;
        dofHandSerial->setNameTag("dofHand");
        dofHandSerial->setNumDOFs(totalauxFIdx+totalDOFIdx);
        dofHandSerial->Update();

        // Transfer fields from user-provided dofhands to dofHandSerial.
        for (int i = 0; i < _dhands[0]->mesh->nPts(); i++)
        {
            for (size_t dhandIdx=0;dhandIdx<_dhands.size();dhandIdx++)
            {
                // DOFs
                for (int dofIdx=0; dofIdx<_dofIdx[dhandIdx]; dofIdx++)
                {
                    double dof= userStr->v_aux[(totalDOFIdx + totalauxFIdx)*i  + ll];
                    dofHandSerial->nodeDOFs->setValue(ll, i, IndexType::Local, dof);
                    ll++;
                }

                //AuxF
                for (int auxFIdx=0; auxFIdx<_auxFIdx[dhandIdx]; auxFIdx++)
                {
                    double auxF= userStr->v_aux[(totalDOFIdx + totalauxFIdx)*i + ll];
                    dofHandSerial->nodeDOFs->setValue(ll, i, IndexType::Local, auxF);
                    ll++;
                }

            }
            ll=0;
        }
        dofHandSerial->UpdateGhosts();


        RCP<DOFsHandler> dofHandLS = rcp(new DOFsHandler(_disNewMesh));
        dofHandLS->setNameTag("interpolateDOFs");
        dofHandLS->setNumDOFs(totalauxFIdx+totalDOFIdx);
        dofHandLS->Update();


        _hiperProbl = rcp(new HiPerProblem);
        _hiperProbl->setParameterStructure(userStr);
        _hiperProbl->setDOFsHandlers({dofHandLS});
        _hiperProbl->setIntegration("Integ", {"interpolateDOFs"});
        _hiperProbl->setCubatureGauss("Integ", 3);
        if (*_LS == nullptr)
        {
            if (_projMethod == ProjectionMethod::LeastSquares)
                _hiperProbl->setElementFillings("Integ", LS);
            else
                throw runtime_error("The interpolation from gauss points to the nodes can only be done by least square fitting method at the moment.");
        }
        else
        {
            _hiperProbl->setElementFillings("Integ", _LS);
        }
        _hiperProbl->Update();


        // set solver
        if (_linSolver == Teuchos::null)
            _setSolver();

        // gather gauss points
        _hiperProbl->FillLinearSystem();
        timer.end("5");


        //if (_improveRemesh)
        //  _improvRemesh();

        // Perform the field projection
        timer.start("proj");
        _projectFields();
        timer.end("proj");

        // Perform least square interpolation to project the dofs from gauss points to nodes of the new mesh
        timer.start("LS");
        userStr->iparam[0]=0;
        userStr->bparam[0]=true;
        _linSolver->solve();
        _hiperProbl->UpdateSolution();
        timer.end("LS");

        // Update dofHands
        int offset=0;
        for (size_t dhandIdx=0; dhandIdx<_dhands.size();dhandIdx++)
        {
            vector<string> _dofsTags =  _dhands[dhandIdx]->nodeDOFs->tags();
            vector<string> _auxFTags;
            int numNodeAuxF=_dhands[dhandIdx]->numNodeAuxF();

            if (numNodeAuxF>0)
                _auxFTags =  _dhands[dhandIdx]->nodeAuxF->tags();

            string _tag=_dhands[dhandIdx]->nameTag();
            _dhands[dhandIdx] = Teuchos::null;
            _dhands[dhandIdx] = rcp(new DOFsHandler(_disNewMesh));
            _dhands[dhandIdx]->setNameTag(_tag);
            _dhands[dhandIdx]->setDOFs(_dofsTags);
            if (numNodeAuxF>0)
                _dhands[dhandIdx]->setNodeAuxF(_auxFTags);
            _dhands[dhandIdx]->Update();


            for (int i=0;i<_disNewMesh->loc_nPts();i++)
            {
                for (int dofIdx=0; dofIdx<_dofIdx[dhandIdx]; dofIdx++)
                {


                    double dof= dofHandLS->nodeDOFs->getValue(offset + dofIdx,i,IndexType::Local);
                    _dhands[dhandIdx]->nodeDOFs->setValue(_projectDOFs[dhandIdx][dofIdx], i, IndexType::Local,dof);
                }

                for (int auxFIdx=0; auxFIdx<_auxFIdx[dhandIdx]; auxFIdx++)
                {
                    double auxF= dofHandLS->nodeDOFs->getValue(offset +_dofIdx[dhandIdx] + auxFIdx,i,IndexType::Local);
                    _dhands[dhandIdx]->nodeAuxF->setValue(_projectAuxF[dhandIdx][auxFIdx], i , IndexType::Local,auxF);
                }
            }
            offset = offset + _dofIdx[dhandIdx] + _auxFIdx[dhandIdx];
            // _dhands[dhandIdx]->printFileLegacyVtk("dhand_serial", false); // <----------------------------- Remove
        }

        // timer.printTiming();
    }

    void LS_RefineRemesh(hiperlife::FillStructure& fillStr)
    {
        using namespace hiperlife;
        using Teuchos::RCP;
        using namespace hiperlife::Tensor;
        auto& subFill = fillStr["refineRemeshHand"];
        int numDOFs  = subFill.numDOFs;
        int eNN      = subFill.eNN;
        std::vector<double>& nborCoords  = subFill.nborCoords;

        //MAIN OUTPUT declaration
        auto& Ak  = fillStr.Ak(0, 0); // <<=== MAIN OUTPUT
        auto& Bk  = fillStr.Bk(0);    // <<=== MAIN OUTPUT

        int N_e = numDOFs*eNN;
        //-------------------------------------------------------------------

        // Get the value of the basis functions and derivatives at the Gauss
        double *bf  = subFill.nborBFs();
        double *dbf = subFill.nborBFsGrads();

        double x[3]{};
        std::vector<double> xTarget(numDOFs);
        double metric[4];
        double e1[3], e2[3];

        Math::MatTMult(x, 3, eNN, 1, nborCoords.data(), bf);
        SurfLagrParam::MetricTensor(metric,e1,e2,eNN,nborCoords.data(),dbf);
        double jac = sqrt(Math::DetMat2x2(metric));

        xTarget[0]= fillStr.paramStr->p_aux[ 3*fillStr.paramStr->iparam[0] + 0 ];
        xTarget[1]= fillStr.paramStr->p_aux[ 3*fillStr.paramStr->iparam[0] + 1 ];
        xTarget[2]= fillStr.paramStr->p_aux[ 3*fillStr.paramStr->iparam[0] + 2 ];

        fillStr.paramStr->iparam[0]++;

        for (int i = 0; i < eNN; i++)
        {
            for (int j = 0; j < eNN; j++)
            {
                //Add submatrix to elemental matrix
                for (int n = 0; n < numDOFs; n++)
                    Ak[(numDOFs*i+n)*N_e + numDOFs*j + n] += jac * bf[i] * bf[j];
            }

            //Add submatrix to elemental matrix
            for (int n = 0; n < numDOFs; n++)
            {
                Bk[numDOFs*i + n] += jac * bf[i] * xTarget[n];
            }
        }

    }

    void Remesher::_improvRemesh()
    {

        RCP<DOFsHandler> refineRemeshHand = rcp(new DOFsHandler(_disNewMesh));
        refineRemeshHand->setNameTag("refineRemeshHand");
        refineRemeshHand->setNumDOFs(3);
        refineRemeshHand->Update();
        refineRemeshHand->UpdateGhosts();

        RCP<HiPerProblem> refineRemeshhp = rcp(new HiPerProblem("HiPerProblem"));
        refineRemeshhp->setParameterStructure(userStr);
        refineRemeshhp->setDOFsHandlers({refineRemeshHand});
        refineRemeshhp->setIntegration("LeastSq", {"refineRemeshHand"});
        refineRemeshhp->setCubatureGauss("LeastSq", 3);
        refineRemeshhp->setElementFillings("LeastSq", LS_RefineRemesh);
        refineRemeshhp->Update();


        RCP<AztecOOIterativeLinearSolver> linsolverRefineRemesh = rcp(new AztecOOIterativeLinearSolver());
        linsolverRefineRemesh->setHiPerProblem(refineRemeshhp);
        linsolverRefineRemesh->setTolerance(1e-10);
        linsolverRefineRemesh->setMaxNumIterations(500);
        linsolverRefineRemesh->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
        linsolverRefineRemesh->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
        linsolverRefineRemesh->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
        linsolverRefineRemesh->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
        linsolverRefineRemesh->setDefaultParameters();
        linsolverRefineRemesh->Update();


        for (size_t array_idx=0;array_idx<userStr->x_aux.size();array_idx++)
        {
            //if (_dhands[0]->myRank()==0) cout<<array_idx<<"/"<<userStr->x_aux.size()<<endl;
            vector<double> xx_;
            xx_.resize(3);
            vector<double> rCoords;
            rCoords.resize(3);
            int idx;
            xx_[0] = userStr->x_aux[array_idx];
            xx_[1] = userStr->y_aux[array_idx];
            xx_[2] = userStr->z_aux[array_idx];

            int flag= dofHandSerial->mesh->searchElement(idx, rCoords, xx_);
            if (flag==-1)
                throw runtime_error("Closest point projection failed.");

            if (rCoords[0]<0) rCoords[0]=0;
            if (rCoords[1]<0) rCoords[1]=0;

            auto xnew = dofHandSerial->mesh->interpolatePosition(idx, rCoords, IndexType::Global);

            userStr->p_aux.push_back(xnew[0]);
            userStr->p_aux.push_back(xnew[1]);
            userStr->p_aux.push_back(xnew[2]);

        }


        refineRemeshHand->UpdateGhosts();
        refineRemeshhp->FillLinearSystem();
        userStr->iparam[1] = 0;
        linsolverRefineRemesh->solve();
        refineRemeshHand->nodeDOFs->setValue(refineRemeshhp->linProbl->GetLHS());
        refineRemeshhp->UpdateGhosts();
//         refineRemeshHand->printFileLegacyVtk("cortexHandMeshIntermediateRefiningRemesh");
        _disNewMesh->_nodeData->setValue(refineRemeshhp->linProbl->GetLHS());
        _disNewMesh->_nodeData->UpdateGhosts();
//         remeshHand->mesh->printFileLegacyVtk("cortexHandMeshAfterRefiningRemesh");


    }

}
