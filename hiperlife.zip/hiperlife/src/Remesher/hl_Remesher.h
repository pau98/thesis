/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef REMESHER_H
#define REMESHER_H


#include <Teuchos_RCP.hpp>

#include "hl_LinearSolver.h"

namespace hiperlife
{

    /*!
     * \class Remesher
     * \brief Class that contains subroutines/functions used for geometry remeshing
     * and projecting degrees of freedom from old mesh to the new mesh
     *
     * It contains a DOFsHandler object that deals with the structures
     * needed for generate a the new mesh and project fields in distributed memory.
     *
     * The information needed for creating the object needs given via the
     * class setters and then Update function will generate the object.
     *
    */

    class Remesher : public DistributedSrcData
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            Remesher(std::string tag = "Remesher", MPI_Comm comm = MPI_COMM_WORLD) : DistributedSrcData(tag, comm) {};
            Remesher(Remesher&& other) = default;
            Remesher(const Remesher& other) = delete;
            ~Remesher() = default;

            Remesher(Teuchos::RCP<DOFsHandler>);

            Remesher& operator=(const Remesher& other) = delete;
            Remesher& operator=(Remesher&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a Remesher object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets all the DOFsHandlers
             *dhand is the DOFsHandler
             *DOFsTags is the vector of dofs that need to be projected for old mesh to the new mesh
             *AuxFTags is the vector of auxF that need to be projected from the old mesh to the new mesh */
            void setDOFsHandler(Teuchos::RCP<DOFsHandler> dhand, std::vector<int> DOFs={}, std::vector<int> AuxF={});
            void setDOFsHandler(Teuchos::RCP<DOFsHandler> dhand, std::vector<std::string> DOFsTags={}, std::vector<std::string> AuxFTags={});
            void setDOFsHandlers(std::vector<Teuchos::RCP<DOFsHandler>> dhands, std::vector<std::vector<int>> DOFs={{}}, std::vector<std::vector<int>> AuxF={{}});
            void setDOFsHandlers(std::vector<Teuchos::RCP<DOFsHandler>> dhands, std::vector<std::vector<std::string>> DOFsTags={{}}, std::vector<std::vector<std::string>> AuxFTags={{}}  );

            /*! \brief Sets the method/type for remeshing and the input arguments required for remeshing
             * RemeshMethod specifies whether the remeshing is done serially or in parallel
             * This routine sets all the parameters required for remeshing using the VTK library.
             * numiter: Number of iterations of remeshing. The optimum is 3
             * elemTargetArea   : Target area of the elements in the new mesh
             * aspectRatio: Target aspect ration of elements in the new mesh
             * connecOptim is no. of iterations of connectivity for remesher to perform.
             * */
            void setRemeshMethod(RemeshMethod remeshMethod, double elemTargetArea)
            {
                _remeshMethod = remeshMethod;
                _area = elemTargetArea;
            }
            void setRemeshParameters(int numIter, double aspectRatio=1.01, double trianglSplitFactor=10.05, int connecOptim=200);
            void setRemeshMethod(RemeshMethod remeshMethod, std::function<double(double, double, double)> f)
            {
                _remeshMethod = remeshMethod;
                _areaFunc = f;
            }
            void setRemeshMethod(RemeshMethod remeshMethod, std::function<double(double)> f) // FIXME:: Unify with area
            {
                _remeshMethod=remeshMethod;
                _fieldModifier = f;
            }

            /*! \brief Sets the solver for projecting dofs from the old mesh to the new mesh*/
            void setSolver(RemeshSolver solverType){_solverType = solverType;}
            void setSolver(Teuchos::RCP<LinearSolver> linSolver){_linSolver = linSolver;}
            /*! \brief Sets the method for projecting degrees of freedom from the old mesh to the new mesh*/
            void setProjectionMethod(ProjectionMethod projMethod){_projMethod = projMethod;}
            /*! \brief Sets the element function for performing the least square interpolation.*/
            void setProjectionMethod(void (*LS)(FillStructure&)){_LS = LS;}
            /*! \brief Sets the  user defined HiperProblem */
            //void setHiperProblem(Teuchos::RCP<HiPerProblem> hiperProbl){_hiperProbl=hiperProbl;};
            /*! \brief This subroutine contains algorithm that performs remeshing and projection of fields from old to the new mesh */
            void Update();
            /*! \brief Get the updated DOFsHandlers with projected fields */
            void newDOFsHands(std::vector<Teuchos::RCP<DOFsHandler>> &dhands);
            void newDOFsHands(Teuchos::RCP<DOFsHandler> &dhand);
            /*! \brief The following routine sets default parameters*/
            void setDefaultParameters();

        private:

            /*! \brief The following updates the mesh and project the fields using the VTK linrary*/
            void _updateSerial();
            /*! \brief This subroutine combines nodal dofs and auxF in the provided dofHandlers*/
            void _combineDOFs();
            /*! \brief This subroutine performs closest point projection from the gauss points of the new mesh to the old mesh*/
            void _projectFields();
            /*! \brief This initializes and updates the solver*/
            void _setSolver();
            /*! \brief Following subroutine utilizes the VTK library to remesh the distributed mesh object stored in the provided DOFsHandler and stores the new
            * distributed mesh in object disMeshNew                */
            void _remesh();
            /*!\brief Following routine improves the quality of the new mesh by projecting the gauss point of new mesh to the old mesh
             * and performing the least square fitting. */
            void _improvRemesh();

            void _updateParallel();
            void _remeshParallel_Triang();
            void _remeshParallel_Square();
            void _projectFieldsParallel();


            /* \brief Member variables of the class*/
            void (*_LS)(FillStructure&) = nullptr;
            Teuchos::RCP<HiPerProblem> _hiperProbl;
            std::vector<Teuchos::RCP<DOFsHandler>> _dhands;

            //Main options
            RemeshSolver _solverType = RemeshSolver::Undefined;
            ProjectionMethod _projMethod = ProjectionMethod::Undefined;
            RemeshMethod _remeshMethod = RemeshMethod::Undefined;
            int _numIter{};
            double _aspectRatio{};
            double _triangleSplitFactor{};
            int _connecOptim{};
            bool _improveRemesh{};

            std::vector<std::vector<int>> _projectDOFs;
            std::vector<int> _dofIdx{};
            std::vector<int> _auxFIdx{};

            /* \brief lambda function for setting the size of target area*/
            std::function<double(double, double, double)> _areaFunc=NULL;
            std::function<double(double)> _fieldModifier;
            double _area{-1};
            std::vector<std::vector<int>> _projectAuxF ;

            /* brief Stores the distributed mesh in serial in _x_nodes and _globConnect data structure*/
            std::vector<double> _x_nodes;
            std::vector<int> _globConnect;

            Teuchos::RCP<DOFsHandler> dofHandSerial;
            Teuchos::RCP<ParamStructure> userStr = Teuchos::rcp(new ParamStructure);
            Teuchos::RCP<DistributedMesh> _disNewMesh = Teuchos::rcp(new DistributedMesh);
            Teuchos::RCP<LinearSolver> _linSolver = Teuchos::null;
    } ;
}

#endif // REMESHER_H
