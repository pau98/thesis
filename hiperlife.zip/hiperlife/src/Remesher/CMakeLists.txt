
#============================================================
# hiperlife's Remesher Shared library
#============================================================

#------------------------------------------------------------
# Get source files
#------------------------------------------------------------
file(GLOB SOURCES_H   *.h)
file(GLOB SOURCES_CPP *.cpp)
set(SOURCE_FILES ${SOURCES_H} ${SOURCES_CPP})
set(LIBNAME hlRemesher)

if(VTK_FOUND)
  #Include directories
  include_directories(SYSTEM ${VTK_INCLUDE_DIRS})
else()
  message(STATUS "Warning!! VTK module is disabled. Remesher not compiled")
  return()
endif()

#------------------------------------------------------------
# Build the library
#------------------------------------------------------------
add_library(${LIBNAME} ${SOURCE_FILES})

target_link_libraries(${LIBNAME} ${MPI_LIB})
target_link_libraries(${LIBNAME} ${Trilinos_LIBRARIES})
target_link_libraries(${LIBNAME} ${HPLFE_LIBRARIES})
if(VTK_FOUND)
  target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
endif()

install(TARGETS ${LIBNAME} DESTINATION lib EXPORT hiperlifeTargets)
install(FILES ${SOURCES_H} DESTINATION include)


#------------------------------------------------------------
# Store the Library
#------------------------------------------------------------
set(HPLFE_LIBRARIES ${HPLFE_LIBRARIES} ${LIBNAME} CACHE INTERNAL "HPLFE_LIBRARIES")
