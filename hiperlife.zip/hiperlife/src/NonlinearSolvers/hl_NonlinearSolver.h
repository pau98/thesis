/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef NONLINEARSOLVER_H
#define NONLINEARSOLVER_H

#include <Teuchos_RCP.hpp>

#include <hl_Timer.h>
#include <hl_LinearSolver.h>
#include <hl_HiPerProblem.h>

namespace hiperlife
{
    /*!
    * \class NonlinearSolver
    * \brief Model virtual class for linear solvers
    *
    * Every other Linear Solver inherits from this class.
    *
   */
    class NonlinearSolver : public DistributedClass
    {
        public:
            /** @name Constructor / Destructor / Operator
            *  @{ */

            NonlinearSolver() = default;
            NonlinearSolver(NonlinearSolver &&other) = default;
            NonlinearSolver& operator=(NonlinearSolver&& other) = default;

            NonlinearSolver& operator=(const NonlinearSolver& other) = delete;
            NonlinearSolver(const NonlinearSolver& other) = delete;
            /** @} */ // end of constructors

            /** \name Solve Method
             * \brief return \ref boolean indicating convergence
             *
            *  @{ */
            virtual bool solve() = 0;
            /** @} */ // end solve

            /** \name Output Method
             * \brief return \ref print on screen the status of the solver
             *
            *  @{ */
            virtual void output(std::ostream& out) = 0;
            /** @} */ // end solve

            virtual void Update() = 0;

            void setLinearSolver(Teuchos::RCP<LinearSolver> linearSolver){_linearSolver = linearSolver;}
            void setMaxNumIterations(int maxIter){_maxIter = maxIter;}
            void setResTolerance(double resTol){_resTol = resTol;}
            void setSolTolerance(double solTol){_solTol = solTol;}
            void setConvRelTolerance(bool rel){_reltol = rel;}

            void setResMaximum(double resMax){_resMax = resMax;}
            void setSolMaximum(double solMax){_solMax = solMax;}
            void setExitRelMaximum(bool rel){_relmax = rel;}

            void setPrintSummary(bool summary){_summary = summary;}
            void setPrintIntermInfo(bool verbose){_verbose = verbose;}

            bool converged(){return _converged;}
            int numberOfIterations(){return _numIter;}
            double residualError(){return _resErr;};
            double solutionError(){return _solErr;};
            double time(){return _timer->printAccumTime("full");};


            /** @name Information access methods
            *  @{
            */
            Teuchos::RCP<HiPerProblem> hiperProblem(){return _hiperProbl;};
            Teuchos::RCP<LinearSolver> linearSolver(){return _linearSolver;};
            Teuchos::RCP<Timer> timer(){return _timer;};
            /** @} */ // end of information access methods

        protected:
            Teuchos::RCP<LinearSolver> _linearSolver = Teuchos::null;
            Teuchos::RCP<Timer> _timer;

            int   _maxIter{};
            double _resTol{};
            double _solTol{};
            double _resMax{std::numeric_limits<double>::max()/10.0};
            double _solMax{std::numeric_limits<double>::max()/10.0};
            int _numIter{};
            bool _converged{};

            bool _summary{};
            bool _verbose{};
            bool _reltol{};
            bool _relmax{};

            double _resErr{};
            double _solErr{};

            Teuchos::RCP<HiPerProblem> _hiperProbl = Teuchos::null;

            double _computeNormRHS()
            {
                double resERR{};
                _linearSolver->_linearProblem->GetRHS()->Norm2(&resERR);
                return resERR;
            }

            double _computeNormLHS()
            {
                double solERR{};
                _linearSolver->_linearProblem->GetLHS()->Norm2(&solERR);
                return solERR;
            }

            void _setHiPerProblem()
            {
                _hiperProbl = _linearSolver->_hiperProbl;
            }
    };
}


#endif //NONLINEARSOLVER_H
