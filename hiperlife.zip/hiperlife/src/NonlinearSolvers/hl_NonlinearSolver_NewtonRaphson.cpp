/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Sohan Kale and Pau Blanco
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <string>

#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>
#include <AztecOO.h>
#include <Amesos_BaseSolver.h>
#include <Amesos.h>
#include <Epetra_MultiVector.h>

#include "hl_NonlinearSolver_NewtonRaphson.h"


namespace hiperlife
{
    void NewtonRaphsonNonlinearSolver::Update()
    {
        // Set hiperProblem
        _setHiPerProblem();

        // Initialize timer
        _timer = Teuchos::rcp(new Timer({"full"}));

        // Check that the global integral for the energy linesearch exists
        if (_lineSearch == true and _lineSearchResidual == false)
        {
            if (_hiperProbl->_globIntegTagIdx.count(_gIntegral) == 0)
                throw runtime_error("NewtonRaphsonNonlinearSolver::Update: The global integral for the line search does not exist in the hiperproblem.");
        }
    }

    bool NewtonRaphsonNonlinearSolver::solve()
    {
        //FIXME: implement restart in timer (Jordi, it is a good time to learn how timers work :-))
        _timer = Teuchos::rcp(new Timer({"full"}));

        _timer->start("full");
        //Initialize
        int ierr{};
        double resERR0{}, solERR0{};
        double resERR{}, solERR{};

        cout << std::scientific << std::setprecision(8);

        _numIter = 0;

        //Iterate
        bool iterate = true;
        if (myRank() == 0 and _verbose)
        {

            cout << "    Iter | " << "L2 SolERR      |" << " (relative)     |" << " L2 ResERR      |" << " (relative)    ";
            if (_lineSearch)
                cout << " | LS iterations  |" << " alphaValue    ";
            cout  << endl;

        }

        while (iterate)
        {
            //Write
            if (myRank() == 0 and _verbose)
                cout << "    " << setfill(' ') << setw(4) <<_numIter << " | ";

            bool lsConv = _linearSolver->solve();

            //Check convergence of the linear system
            if (!lsConv)
            {
                if (myRank() == 0 and _verbose)
                    cout << endl << "ERROR::Newton-Raphson: Linear system solver failed" << endl;
                ierr = 1;
                break;
            }


            //L2 Norm of the residue |RES| and L_inf error: that is the maximum absolute value
            resERR = _computeNormRHS();
            solERR = _computeNormLHS();

            //Compute relative errors
            if (_numIter == 0)
            {
                solERR0 = solERR;
                resERR0 = resERR;
            }

            // Store status
            if ( _reltol)
            {
                if (solERR/solERR0 <= _solTol and resERR/resERR0 <= _resTol)
                    iterate = false;
            }
            else
            {
                if (solERR <= _solTol and resERR <= _resTol)
                    iterate = false;
            }

            _numIter++;

            //Perform line search or update solution
            int LSIter;
            double alpha_ev;
            if (_lineSearch)
            {
                tuple<int,int,double> tup = _linesearch_backtracking();
                ierr  = std::get<0>(tup);
                LSIter  = std::get<1>(tup);
                alpha_ev = std::get<2>(tup);
                if (ierr == 1)
                    break;
            }
            else
            {
                _hiperProbl->AddSolutionToDOFs(-1.0);
            }

            //Output info
            if (myRank() == 0 and _verbose)
            {
                cout <<  solERR << " | " << solERR/solERR0 << " | " << resERR << " | " << resERR/resERR0;
                if (_lineSearch)
                    cout << " | " << setfill(' ') << setw(2) << LSIter << "             | " << alpha_ev;
                cout << endl;
            }


            if(_relmax)
            {
                if(solERR/solERR0 > _solMax)
                {
                    if (myRank() == 0 and _verbose)
                        cout << "   ERROR::Newton-Raphson: Maximum norm of the solution reached" << endl;
                    ierr = 1;
                    break;
                }
                if(resERR/resERR0 >_resMax)
                {
                    if (myRank() == 0 and _verbose)
                        cout << "   ERROR::Newton-Raphson: Maximum norm of the residue reached" << endl;
                    ierr = 1;
                    break;
                }
            }
            else
            {
                if(solERR > _solMax)
                {
                    if (myRank() == 0 and _verbose)
                        cout << "   ERROR::Newton-Raphson: Maximum norm of the solution reached" << endl;
                    ierr = 1;
                    break;
                }
                if(resERR >_resMax)
                {
                    if (myRank() == 0 and _verbose)
                        cout << "   ERROR::Newton-Raphson: Maximum norm of the residue reached" << endl;
                    ierr = 1;
                    break;
                }
            }

            //Check maximum steps
            if(iterate and (_numIter+1 > _maxIter))
            {
                if (myRank() == 0 and _verbose)
                    cout << "   ERROR::Newton-Raphson: NO convergence reached after " << _maxIter << " iterations" << endl;
                ierr  = 1;
                break;
            }

        }

        if ( _reltol)
        {
            _resErr = resERR/resERR0;
            _solErr = solERR/solERR0;
        }
        else
        {
            _resErr = resERR;
            _solErr = solERR;
        }

        _timer->end("full");

        _converged = ierr == 0;

        if(_summary)
            output();


        return _converged;
    }

    void NewtonRaphsonNonlinearSolver::output( std::ostream& out )
    {
        if ( _myRank == 0 )
        {
            out << "================================================" << endl;
            out << "NewtonRaphsonNonlinearSolver" << endl;
            out << "Converged                   = " << boolalpha << _converged << endl;
            out << "Residual                    = " << _resErr << endl;
            out << "Solution error (last step)  = " << _solErr << endl;
            out << "Number of iterations        = " << _numIter << endl;
            out << "Timer                       = " <<  _timer->printAccumTime("full") << endl;
            out << "================================================" << endl;
        }
    }

    std::tuple<int, int, double> NewtonRaphsonNonlinearSolver::_linesearch_backtracking()
    {
        if (_lineSearchResidual)
            return _linesearch_backtracking_residual();
        else
            return _linesearch_backtracking_energy();
    }

    std::tuple<int, int, double> NewtonRaphsonNonlinearSolver::_linesearch_backtracking_residual()
    {
        // Initialize
        auto RHS = Teuchos::rcpFromRef(*_hiperProbl->linProbl->GetRHS());

        // Calculate: phi(0) = 1/2 * || Residual(U)||^2
        int ierr{0};
        double phi0{};
        RHS->Dot(*RHS, &phi0);
        phi0 = 0.5 * phi0;

        // Calculate: s0 = phi'(0) = -phi(0)
        double s0 = - phi0;

        // Abort if s0 is positive
        if (s0 > 0.0)
        {
            if (_myRank == 0)
                cout << "************Line-search: positive s0, aborting search" << endl;
            ierr = 1;
        }

        // Search direction using backtracking
        int l{};
        double alpha{1.}, alpha_prev{};
        if (ierr == 0)
        {
            // Backtracking line-search loop
            for (l = 0; l < _LSmaxIter; l++)
            {
                // Change in alpha
                double Delalpha = alpha - alpha_prev;

                // Store last step alpha
                alpha_prev = alpha;

                // Update DOFs using increment in alpha
                _hiperProbl->AddSolutionToDOFs(-Delalpha);
                _hiperProbl->UpdateGhosts();

                // Evaluate the residual for the updated DOFs
                _hiperProbl->FillLinearSystem();
                
                // Get energy function at alpha, phi(alpha)
                double phin;
                RHS->Dot(*RHS, &phin); // Energy is half the norm of the residual
                phin = 0.5 * phin;
                // cout << _hiperProbl->globalIntegral("Ray") << " " << phin << endl;

                // Check for convergence
                double lalpha = phi0 + _c * alpha * s0;
                if (phin <= lalpha || abs(s0) < 1.0E-10)
                    break;

                // Check if alpha becomes less than the minimum allowed
                if (alpha < _alpha_MIN)
                {
                    if (_myRank == 0)
                        cout << "**ERROR:Line-search:alpha less than alpha_MIN:" << alpha << endl;
                    ierr = 1;
                    break;
                }

                if (std::isnan(alpha) || std::isnan(s0))
                {
                    if (_myRank == 0)
                        cout << "**ERROR:Line-search:Error computing alpha, Getting NAN" << endl;
                    ierr = 1;
                    break;
                }

                // Update alpha
                alpha *= _step;
            }
        }

        if (l == _LSmaxIter)
        {
            ierr = 1;
            if (_myRank == 0)
                cout << "**ERROR: Line search maximum iterations reached without convergence" << endl;
        }

        return make_tuple(ierr, l, alpha_prev);
    }

    std::tuple<int, int, double> NewtonRaphsonNonlinearSolver::_linesearch_backtracking_energy()
    {
        // Compute grad(f(x^k))*p^k
        auto RHS = Teuchos::rcpFromRef(*_hiperProbl->linProbl->GetRHS());
        double s0{};
        RHS->Dot(*_hiperProbl->sol, &s0);
        s0 *= -1.0;

        // Check that we do not get NANs
        int ierr{0};
        if (std::isnan(s0))
        {
            if (_myRank == 0)
                cout << "**ERROR:Line-search:Error computing s0: NAN" << endl;
            ierr = 1;
        }
        cout << "Energy: " << _hiperProbl->globalIntegral("Ray") <<" " <<  s0 << endl;

        // Save energy at alpha = 0
        double phi0 = _hiperProbl->globalIntegral(_gIntegral);

        // Initialize alpha
        double alpha{1.0}, alpha_prev{};

        // If s0 is not a descent direction, reverse direction
        if (s0 > 0)
            alpha = -1.0;

        // Search direction using backtracking
        int l{0};
        if (ierr == 0)
        {
            // Backtracking line-search loop
            for (l = 0; l < _LSmaxIter; l++)
            {
                // Change in alpha
                double Delalpha = alpha - alpha_prev;

                // Store last step alpha
                alpha_prev = alpha;

                // Update DOFs using increment in alpha
                _hiperProbl->AddSolutionToDOFs(-Delalpha);
                _hiperProbl->UpdateGhosts();

                // Evaluate the residual for the updated DOFs
                _hiperProbl->FillLinearSystem();

                // Get energy function at alpha, phi(alpha)
                double phin = _hiperProbl->globalIntegral(_gIntegral);
                cout << "Energy: "<< _hiperProbl->globalIntegral("Ray") << "   Alpha: " << alpha<< endl;

                // Check that we do not get NANs
                if (std::isnan(phin))
                {
                    if (_myRank == 0)
                        cout << "**ERROR:Line-search:Error computing energy: NAN" << endl;
                    // ierr = 1;
                    // break;
                    // Update alpha
                    alpha *= _step;
                    continue;
                }

                // Check for convergence
                double lalpha = phi0 + _c * alpha * s0;
                if (phin <= lalpha || abs(s0) < 1.0E-10)
                    break;

                // Check if alpha becomes less than the minimum allowed
                if (abs(alpha) < abs(_alpha_MIN))
                {
                    if (_myRank == 0)
                        cout << "**ERROR:Line-search:alpha less than alpha_MIN:" << alpha << endl;
                    ierr = 1;
                    break;
                }

                // Update alpha
                alpha *= _step;
            }
        }

        if (l == _LSmaxIter)
        {
            ierr = 1;
            if (_myRank == 0)
                cout << "**ERROR: Line search maximum iterations reached without convergence" << endl;
        }

        return make_tuple(ierr, l, alpha_prev);
    }

}
