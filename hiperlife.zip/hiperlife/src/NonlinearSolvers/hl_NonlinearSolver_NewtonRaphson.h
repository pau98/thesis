/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Sohan Kale and Pau Blanco
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef NONLINEAR_NEWTONRAPHSON_H
#define NONLINEAR_NEWTONRAPHSON_H

#include <mpi.h>
#include <string>

#include "hl_NonlinearSolver.h"

namespace hiperlife
{
    /*!
    * \class NewtonRaphsonNonlinearSolver
    * \brief Newton-Raphson nonlinear solver
   */
    class NewtonRaphsonNonlinearSolver : public NonlinearSolver
    {
        public:

            /** @name Constructor / Destructor / Operator
            *  @{ */
            NewtonRaphsonNonlinearSolver(){};
            NewtonRaphsonNonlinearSolver(NewtonRaphsonNonlinearSolver &&other) = default;
            ~NewtonRaphsonNonlinearSolver() = default;
            NewtonRaphsonNonlinearSolver& operator=(NewtonRaphsonNonlinearSolver&& other) = default;

            NewtonRaphsonNonlinearSolver& operator=(const NewtonRaphsonNonlinearSolver& other) = delete;
            NewtonRaphsonNonlinearSolver(const NewtonRaphsonNonlinearSolver& other) = delete;
            /** @} */ // end of constructors

            bool solve() override;
            void Update() override;
            void output(std::ostream& out = std::cout) override;

            void setLineSearch(bool lineSearch){_lineSearch = lineSearch;}
            void setLineSearchEnergyMethod(std::string globIntegral)
            {
                _lineSearch = true;
                _lineSearchResidual = false;
                _gIntegral = globIntegral;
            }
            void setLineSearch_maxIter(int LSmaxIter){_LSmaxIter = LSmaxIter;}
            void setLineSearch_MaxIter(double alpha_MIN){_alpha_MIN = alpha_MIN;}
            void setLineSearch_step(double step){_step = step;}
            void setLineSearch_minDecrease(double c){_c = c;}

        private:

            //Line search
            bool _lineSearch{};
            bool _lineSearchResidual{true};
            std::string _gIntegral;
            int _LSmaxIter{40};
            double _alpha_MIN{1E-5};    // Smallest allowed step size
            double _c{1e-2};
            double _step{0.5};
            std::tuple<int, int, double> _linesearch_backtracking();
            std::tuple<int, int, double> _linesearch_backtracking_energy();
            std::tuple<int, int, double> _linesearch_backtracking_residual();

    };
}

#endif //NONLINEAR_NEWTONRAPHSON_H
