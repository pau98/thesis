
/// C++ headers

#include <vector>


#include <iostream>        // C++ header that defines the standard
// input/output stream objects
#include <mpi.h>           // C++ header that defines MPI objects

/// Trilinos headers
#include <Teuchos_RCP.hpp> // Trilinos header that defines RCP objects
//   (Smart reference counting pointer class
//   for automatic garbage collection)

/// hiperlife headers
#include "hl_TypeDefs.h"        // hiperlife header that defines
//   different data types used
//   throughout the library
#include "hl_Geometry.h"        // hiperlife header that defines
//   auxiliary geometric-related

#include "hl_StructMeshGenerator.h"

#include "hl_DistributedMesh.h" // hiperlife header that defines
//   distributed mesh objects
#include "hl_FillStructure.h"   // hiperlife header that defines
//   objects to fill the matrix and
//   vector of the problem
#include "hl_DOFsHandler.h"       // hiperlife header that defines
//   DOFHandler objects
#include "hl_HiPerProblem.h"  // hiperlife header that defines
#include "hl_UnstructGmshMeshGenerator.h"
#include "hl_SurfLagrParam.h"

void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void LS2(Teuchos::RCP<hiperlife::FillStructure> fillStr);

using namespace std;
int main()
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;
    MPI_Init(nullptr, nullptr);
    ///=============== Define parameters of the model ===============///
    ///
    double force = 1.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;

    ///====================== Mesh generation ======================///

    //Parameters
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Triang;
    int bfOrder = 1;
    int gpts = 6;

    RCP<StructMeshGenerator> Mesh = rcp(new StructMeshGenerator);
    Mesh->setMesh(eType, bfType, bfOrder);
    Mesh->genRectangle(5, 5, 1.0, 2.0);
    // Mesh->rotate2D(M_PI/2.0, {0.5, 0.5, 1.0});

    RCP<UnstructGmshMeshGenerator> Gmsh = rcp(new UnstructGmshMeshGenerator);
    Gmsh->setMesh(eType, bfType, bfOrder);
    Gmsh->genRectangle(1, 2, 0.05);
    // Gmsh->genCircle(1, 0.5);
    // Gmsh->genBSpline("points.txt", 0.2);
    // Gmsh->genRegularPoly(5, 1, 0.5);
    // Gmsh->genSphere(1, 0.01);
    // Gmsh->genPoly("points.txt", 0.2);
    Gmsh->translate(1.0);
    // Gmsh->_printMesh("After");


    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(Gmsh);
    // disMesh->setMesh(Mesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    disMesh->printFileLegacyVtk("Meshg");

    // RCP<DistributedMesh> disMesh2 = rcp(new DistributedMesh);
    // disMesh2->setMeshRelation(MeshRelation::pRefin, disMesh);
    // disMesh2->setBalanceMesh(false);
    // disMesh2->Update();


    ///===========           Create DOFHandler            ===========///
    ///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    dofHand->setBoundaryCondition(0, 0.0);
    dofHand->setBoundaryCondition(0, MAxis::Xmin, 1.0);
    // for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    // {
    //     double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
    //     int crease = dofHand->mesh->nodeCrease(i, IndexType::Local);
    //     if (crease > 0)
    //     {
    //         if (x > 0.9999)
    //             dofHand->setBoundaryCondition(0, i, IndexType::Local, 1.0);
    //         else
    //             dofHand->setBoundaryCondition(0, i, IndexType::Local, 0.0);
    //     }
    // }
    dofHand->UpdateGhosts();


    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStruct(userStr);
    hiperProbl->setDOFsHandlers({dofHand});

    hiperProbl->setIntegration("Integ", {"dofHand"}, {IntegType::Master});
    hiperProbl->setIntegration_CubatureStd("Integ", "CubatureGauss", gpts);
    hiperProbl->setIntegration_ElemFillings("Integ", LS2);

    hiperProbl->setSolver(PDEType::Linear, LinSolverType::AztecOO);
    hiperProbl->setSolverOptions({{"precond", "ls"}});
    hiperProbl->setSolverOptions({{"solver", "cg"}});
    hiperProbl->setSolverOptions({{"tol", "1e-8"}});
    hiperProbl->setSolverOptions({{"max_iter", "5000"}});
    hiperProbl->setSolverOptions({{"output", "all"}});

    hiperProbl->Update();


    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//

    hiperProbl->FillLinearSystem();
    auto status = hiperProbl->Solve();
    cout << status << endl;

    hiperProbl->UpdateSolution();

    dofHand->printFile("Poisson");
    dofHand->printFileLegacyVtk("Poisson");


    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}

void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    ///===========          Initialize variables           ==========///
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.getDer(0);  // Local shape function
    double* glNa = subFill.getDer(1); // Local shape function derivatives

    vector<double> gNa(eNN*pDim);
    double jac;
    SGeometry::globalBasisFunctionGradient(gNa.data(), jac, eNN, pDim, nDim, xe_nodes.data(), glNa);
    // jac *= -1.0;

    double x[3]={};
    for ( int i = 0; i < eNN; i++ )
    {
        for ( int n = 0; n < 3; n++ )
        {
            x[n] += xe_nodes[nDim*i+n] * Na[i];
        }
    }

    // cout << x[0] << " " << x[1] << endl;
    // cout << subFill.x_sample[0] << " " << subFill.x_sample[1] << " " << subFill.wk_sample << endl << endl;



    double strength = fillStr->userStr->dparam[0];
    double force = strength * exp(-(x[0]*x[0]+x[1]*x[1])/0.1);

    ///=====================  Fill linear system =====================///
    ///
    /// We loop through the neighboring nodes to fill both the matrix
    ///   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}

void LS2(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;


    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& nborCoords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.getDer(0);  // Local shape function
    double* dbf_l = subFill.getDer(1); // Local shape function derivatives


    double* glNa = subFill.getDer(1); // Local shape function derivatives
    vector<double> gNa(eNN*pDim);
    double jac2;
    SGeometry::globalBasisFunctionGradient(gNa.data(), jac2, eNN, pDim, nDim, nborCoords.data(), glNa);

    double x[3]={}; //Position in Euclidean space of the Gauss point
    for (int i = 0; i < eNN; i++)
    {
        for ( int n = 0; n < nDim; n++ )
        {
            x[n] += nborCoords[i*nDim+n] * bf[i];
        }
    }

    double g_cc[4]={};  //Metric tensor (covariant components cc)
    double xu[3]={};    //Tangent vector 1
    double xv[3]={};    //Tangent vector 2
    SurfLagrParam::MetricTensor(g_cc, xu, xv, eNN, nborCoords.data(),dbf_l);

    double g_CC[4]={};  //Inverse of the metric tensor (contravariant components)
    Math::Invert2x2(g_CC, g_cc); //Compute the inverse

    double jac = sqrt(Math::DetMat2x2(g_cc)); //Calculate the jacobian

    // cout << jac << " " << jac2 << endl;

    // double source = strength * x[1]*cos(3.0*M_PI*x[0]); //Generate a source
    double strength = fillStr->userStr->dparam[0];
    double source = strength * exp(-(x[0]*x[0]+x[1]*x[1])/0.1); //Generate a source

    ///=====================  Fill linear system =====================///
    ///
    /// We loop through the neighboring nodes to fill both the matrix
    ///   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        double* dbf_lI_c = &dbf_l[pDim*i]; //Pointer to the local gradients of the basis functions of node I

        double dbf_lI_C[2]={}; //Compute g^{ab} dbf_lI_c_b
        Math::MatProduct(dbf_lI_C, 2, 2, 1, g_CC, dbf_lI_c);

        for (int j = 0; j < eNN; j++)
        {
            double* dbf_lJ_c = &dbf_l[pDim*j]; //Pointer to the local gradients of the basis functions of node I

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * Math::Dot2D(dbf_lI_C, dbf_lJ_c);
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * bf[i] * source; //Add source
    }

    return;
}
