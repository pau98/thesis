#include <array>
#include <iostream>
#include <cmath>

#include "ttl.h"


int main()
{
    using namespace std;
    using namespace ttl;
    using ttl::vector;

    for(int N=2; N < 20; N++)
    {
        tensor<double,3> tensor1(N,N,N);
        matrix<double> tensor2(N,N);
        matrix<double> tensor3(N,N);

        for(int n = 0; n<N; n++)
        {
            for(int m = 0; m<N; m++)
            {
                for(int l =0; l<N; l++)
                    tensor1(n,m,l) = n+m+l;
                tensor2(n,m) = n-2*m;
                tensor3(m,n) = n+m;
            }
        }

        //Check resize and moving assignment
        matrix<double> tensor4;
        tensor4.resize(N,N);
        tensor4 = tensor3+tensor2;

        if((tensor4-tensor3-tensor2).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 1)" << endl;
            cout << tensor4 << endl;
            cout << "should be equal to" << endl;
            cout << tensor3+tensor2 << endl;

            return 1;
        }

        //Check asignment, negative and transpose
        tensor4 = tensor2.T();
        tensor3 = -tensor2.T();

        if((tensor4+tensor3).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 2)" << endl;
            cout << tensor4 << endl;
            cout << "should be equal to" << endl;
            cout << tensor3 << endl;
            return 1;
        }

        double scalar=N;
        vector<double> vec0(N);
        vector<double> vec1(N);
        tensor<double,5> out(N,N,N,N,N);
        for(int p = 0; p < N; p++)
        {
            vec0(p) = 0.0;
            vec1(p) = 0.0;
            for(int n = 0; n<N; n++)
            {
                vec0(p) += tensor1(n,p,n);
                for(int m = 0; m<N; m++)
                {
                    vec1(p) += tensor1(p,n,m) * tensor2(n,m);
                    for(int l=0; l<N; l++)
                    {
                        for(int j=0; j< N; j++)
                        {
                            out(p,n,m,l,j) = tensor1(p,l,j) * tensor2(n,m);
                        }
                    }
                }
            }
            vec1(p) *= scalar;
        }
        vector<double> vec2 = product(tensor1,scalar*tensor2,{{1,0},{2,1}});
        if((vec2-vec1).norm()>1.E-8 )
        {
            cout << "Tensors not working properly (" << N << ", 3)" << endl;
            cout << vec2 << endl;
            cout << "should be equal to" << endl;
            cout << vec1 << endl;
            return 1;
        }
        vec2 = contract(tensor1,{{0,2}});
        if((vec2-vec0).norm()>1.E-8 )
        {
            cout << "Tensors not working properly (" << N << ", 4)" << endl;
            cout << vec2 << endl;
            cout << "should be equal to" << endl;
            cout << vec0 << endl;
            return 1;
        }
        tensor<double,5> out2 = outer(tensor1,tensor2).transpose({0,3,4,1,2});
        if((out-out2).norm()>1.E-8 )
        {
            cout << "Tensors not working properly (" << N << ", 5)" << endl;
            cout << out2 << endl;
            cout << "should be equal to" << endl;
            cout << out << endl;
            return 1;
        }

        for(int n=0; n < N; n++)
        {
            vec2(n) = vec1(n) * vec0(n);
        }
        vector<double> vec3 = eproduct(vec0,vec1);
        if((vec2-vec3).norm()>1.E-8 )
        {
            cout << "Tensors not working properly (" << N << ", 6)" << endl;
            cout << vec2 << endl;
            cout << "should be equal to" << endl;
            cout << vec3 << endl;
            return 1;
        }

#if __cplusplus >= 201402L
        using index::a, index::b, index::c;

        vec3 = tensor1(a,b,c) * (scalar * tensor2(b,c));
        if((vec3-vec1).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 7)" << endl;
            cout << vec3 << endl;
            cout << "should be equal to" << endl;
            cout << vec1 << endl;
            return 1;
        }

        vec3 = tensor1(a,b,a);
        if((vec3-vec0).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 8)" << endl;
            cout << vec3 << endl;
            cout << "should be equal to" << endl;
            cout << vec0 << endl;
            return 1;
        }
        using index::d, index::e;

        tensor<double,5> out3(N,N,N,N,N);
        out3(a,b,c,d,e) = tensor1(a,d,e) * tensor2(b,c);
        if((out3-out).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 9)" << endl;
            cout << out3 << endl;
            cout << "should be equal to" << endl;
            cout << out << endl;
            return 1;
        }

        vector<double> vec4;
        vec4.resize(N);
        vec4 = tensor1(a,b,c) * (tensor2(b,c) * scalar);
        if((vec4-vec1).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 10)" << endl;
            cout << vec4 << endl;
            cout << "should be equal to" << endl;
            cout << vec1 << endl;
            return 1;
        }

        vector<double> vec5 = (5.0+trace(tensor1)(b))-(3.0+tensor1(a,b,a))-2.0;
        if(vec5.norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 11)" << endl;
            cout << vec5 << endl;
            cout << "should be equal to" << endl;
            cout << 0 << endl;
            return 1;
        }

        vector<double> vec6 = out3(a,b,c,b,a);
        vector<double> vec7 = tensor1(a,b,a) * tensor2(b,c);
        vector<double> vec8 = product(contract(tensor1,{{0,2}}), tensor2,{{0,0}});
        if((vec6-vec7).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 12)" << endl;
            cout << vec6 << endl;
            cout << "should be equal to" << endl;
            cout << vec7 << endl;
            return 1;
        }
        if((vec6-vec8).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 13)" << endl;
            cout << vec6 << endl;
            cout << "should be equal to" << endl;
            cout << vec8 << endl;
            return 1;
        }
#endif
    }

#if __cplusplus >= 201402L
    for(int N=2; N < 10; N++)
    {
        tensor<int,3> tensor1(N,N,N*2);
        matrix<int> tensor2(N,N*2);
        matrix<int> tensor3(N,N);

        for(int n = 0; n<N; n++)
        {
            for(int l =0; l<N; l++)
            {
                for(int m = 0; m<N*2; m++)
                {
                    tensor1(n,l,m) = n+m-3*l;
                    tensor2(n,m) = 5*n-m;
                }
                tensor3(n,l) = l-2*n;
            }
        }

        using index::a, index::b, index::c;

        vector<double> vec1 = product(tensor1,tensor3,{{0,0},{1,1}});
        vector<int> vec2 = tensor1(a,b,c) * tensor3(a,b);
        vector<int> vec3 = vec1;

        if((vec2/3.0-vec1/3.0).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 13)" << endl;
            cout << vec2/3.0 << endl;
            cout << "should be equal to" << endl;
            cout << vec1/3.0 << endl;
            return 1;
        }
        if((vec2/13-vec3/13).norm()>1.E-8)
        {
            cout << "Tensors not working properly (" << N << ", 14)" << endl;
            cout << vec2/13 << endl;
            cout << "should be equal to" << endl;
            cout << vec1/13 << endl;
            return 1;
        }
    }
#endif

    std::vector<double> vec = {1.0,2.0,-1.0,3.0,4.0,5.0,0.0,6.0,-1.0};
    tensor<double,2,false,false> mytensor(vec.data(),{3,3},{1,3});
#if __cplusplus >= 201402L
    using index::a;
    
    if(abs(mytensor(a,a))-4>1.E-8)
    {
        cout << "Tensors not working properly (end, 15)" << endl;
        cout << mytensor(a,a) << endl;
        cout << "should be equal to" << endl;
        cout << 4 << endl;
        return 1;
    }
#endif
    cout << "Tensor tests ok!" << endl;

    return 0;

}
