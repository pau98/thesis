
/// C++ headers
#include <iostream>
#include <mpi.h>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_Geometry.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_Tensor.h"
#include "hl_Timer.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);
void LS_Tensor(RCP<hiperlife::FillStructure> fillStr);

/// In this first tutorial everything is implemented inside the main
///   function
int main()
{


    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);


    ///=============== Define parameters of the model ===============///
    double force = 0.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;


    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//

    ///====================== Mesh generation ======================///
    ///
    ElemType eType = ElemType::Triang;
    int bfOrder = 1;
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setElemType(eType);
    structMesh->setBasisFuncType(BasisFuncType::Linear);
    structMesh->setBasisFuncOrder(bfOrder);

    structMesh->genStructMesh(100);


    int gPts{};
    {
        if (eType == ElemType::Line)
            gPts = bfOrder+1;
        else if (eType == ElemType::Square)
            gPts = int(pow(bfOrder+1, 2));
        else if (eType == ElemType::Triang)
            gPts = 4;
        else if (eType == ElemType::Parallelep)
            gPts = int(pow(bfOrder+1, 3));
    }
    // gPts = 27;

    ///===========             Distribute mesh            ===========///
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    disMesh->printFileLegacyVtk("Mesh");
    disMesh->printFileLegacyCSV("Mesh");

    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//
    /// **************************************************************//

    ///===========           Create DOFHandler            ===========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    ///===========          Boundary conditions          ===========///
    dofHand->setBoundaryCondition(0, MAxis::Xmin, -1.0);
    dofHand->setBoundaryCondition(0, MAxis::Xmax, 1.0);

    dofHand->UpdateGhosts();

    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStruct(userStr);
    hiperProbl->setDOFsHandlers({dofHand});

    ///===========            Set integration             ===========///
    hiperProbl->setIntegration("Integ", {"dofHand"}, {IntegType::Master});
    hiperProbl->setCubatureGauss("Integ", gPts);
    hiperProbl->setIntegration_ElemFillings("Integ", LS);

    ///===========               Set solver               ===========///
    hiperProbl->setSolver(PDEType::Linear, LinSolverType::AztecOO);
    hiperProbl->setSolverOptions({{"precond", "Jacobi"}});
    hiperProbl->setSolverOptions({{"solver", "cg"}});
    hiperProbl->setSolverOptions({{"tol", "1e-8"}});
    hiperProbl->setSolverOptions({{"max_iter", "5000"}});
    hiperProbl->setSolverOptions({{"output", "none"}});

    ///===========                 Update                ===========///
    hiperProbl->Update();



    // /// **************************************************************//
    // /// *****                SOLVE HIPERPROBLEM                  *****//
    // /// **************************************************************//


    Timer timer({"Usual", "Tensor"});

    for ( int i = 0; i < 100; i++ )
    {
        timer.start("Usual");
        hiperProbl->FillLinearSystem();
        timer.end("Usual");
    }

//    RCP<HiPerProblem>
    hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStruct(userStr);
    hiperProbl->setDOFsHandlers({dofHand});

    ///===========            Set integration             ===========///
    hiperProbl->setIntegration("Integ", {"dofHand"}, {IntegType::Master});
    hiperProbl->setCubatureGauss("Integ", gPts);
    hiperProbl->setIntegration_ElemFillings("Integ", LS_Tensor);

    ///===========               Set solver               ===========///
    hiperProbl->setSolver(PDEType::Linear, LinSolverType::AztecOO);
    hiperProbl->setSolverOptions({{"precond", "Jacobi"}});
    hiperProbl->setSolverOptions({{"solver", "cg"}});
    hiperProbl->setSolverOptions({{"tol", "1e-8"}});
    hiperProbl->setSolverOptions({{"max_iter", "5000"}});
    hiperProbl->setSolverOptions({{"output", "none"}});

    ///===========                 Update                ===========///
    hiperProbl->Update();

    for ( int i = 0; i < 100; i++ )
    {
            timer.start("Tensor");
            hiperProbl->FillLinearSystem();
            timer.end("Tensor");
    }

    // timer.printTesting("Timing:  ");
    timer.printTiming();

    std::cout << std::fixed;
    std::cout << std::setprecision(1);
    cout << "Overload of: " << timer.printAccumTime("Tensor") / timer.printAccumTime("Usual") * 100.0-100.0 << "%"<< endl;

    auto status = hiperProbl->Solve();
    cout << status << endl;

    hiperProbl->UpdateSolution();

    dofHand->printFile("Poisson");
    dofHand->printFileLegacyVtk("Poisson");


    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}

void LS(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.getDer(0);  // Local shape function
    double* glNa = subFill.getDer(1); // Local shape function derivatives
    double gNa[eNN*pDim], jac;
    SGeometry::globalBasisFunctionGradient(gNa, jac, eNN, pDim, nDim, xe_nodes.data(), glNa);

    vector<double> x(pDim);
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d]  * Na[i];
    }

    // if (x[0] < 0.9)
        // force *= x[0];

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}


void LS_Tensor(RCP<FillStructure> fillStr)
{
    using namespace hiperlife::Tensor;

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension

    tensor<double,2> xe_nodes(subFill.nborCoords.data(),eNN,nDim);
    tensor<double,1>  bf(subFill.getDer(0),eNN);
    tensor<double,2> dbf(subFill.getDer(1),eNN,pDim);

    tensor<double,2> A_k(fillStr->Ak(0,0).data(),eNN,eNN);
    tensor<double,1> B_k(fillStr->Bk(0).data(),eNN);

    tensor<double,1>  x =  bf * xe_nodes;
    tensor<double,2> Dx = dbf.T() * xe_nodes;
    tensor<double,2>  g = Dx * Dx.T();

    double jac = sqrt(g.det());

    A_k = jac * (dbf * g.inv() * dbf.T());
    B_k = (jac * force) * bf;

    return;
}
