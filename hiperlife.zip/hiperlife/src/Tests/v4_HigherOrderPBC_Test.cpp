
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_PredefinedElementFillings.h"
#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_ConsistencyCheck.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_TimeIterator.h"

#include "hl_FillStructure.h"
#include "hl_GlobalBasisFunctions.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    MPI_Init(nullptr, nullptr);

    // Put parameters in the user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->CahnHilliard.epsilon2 = 0.00025;
    userStr->CahnHilliard.constantMobility = 1.0;
    userStr->CahnHilliard.doubleWell = [](double c)->vector<double>
    {
        return {(c*c)*(1.0-c)*(1.0-c)/4.0,
                c*(1.0-c)*(1.0-2.0*c)/2.0,
                (1.0-6.0*c+6.0*c*c)/2.0,
                (-1.0+2.0*c)*3.0};
    };

    userStr->AllenCahn.epsilon2 = 0.00025;
    userStr->AllenCahn.constantMobility = 1.0;
    userStr->AllenCahn.doubleWell = [](double c)->vector<double>
    {
        return {(c*c)*(1.0-c)*(1.0-c)/4.0,
                c*(1.0-c)*(1.0-2.0*c)/2.0,
                (1.0-6.0*c+6.0*c*c)/2.0};
    };

    userStr->TransientDiffusion.diffusionCoefficient = 1.0;
    userStr->TransientDiffusion.constantSource = 0.0;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create a line structured mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(ElemType::Line, BasisFuncType::BSplines, 2);
    structMesh->setPeriodicBoundaryCondition({Axis::Xaxis});
    // structMesh->setPeriodicBoundaryCondition({Axis::Xaxis, Axis::Yaxis});
    structMesh->genStructMesh(100);
    // structMesh->unclamp(Axis::Xaxis);
    // structMesh->printMesh("after");

    // Distribute the mesh among all the processors
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();
    disMesh->printFileLegacyVtk("mesh");
    disMesh->printFile("mesh");

    // Read mesh
    RCP<DistributedMesh> r_disMesh = rcp(new DistributedMesh);
    r_disMesh->setFilePrefix("mesh");
    r_disMesh->Update();


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Create a DOFsHandler with one degree of freedom (c)
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(r_disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"u"});
    dhand->Update();

    // Set initial and boundary conditions for the DOF
    srand(time(NULL));
    // dhand->setInitialCondition("u",
    //                              [](double x)
    //                              {
    //                                  double r = sqrt(x*x);
    //                                  double d = sqrt((r-0.6)*(r-0.6));
    //                                  double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*0.001)));
    //                                  if (x < 0.1 or x > 0.9)
    //                                      return 0.0;

    //                                  return u;
    //                              });
    // dhand->setInitialCondition("u",
    //                              [](double x, double y)
    //                              {
    //                                  double r = sqrt(x*x + y*y);
    //                                  double d = sqrt((r-0.6)*(r-0.6));
    //                                  double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*0.001)));
    //                                  if (x < 0.1 or x > 0.9)
    //                                      return 0.0;
    //                                  if (y < 0.1 or y > 0.9)
    //                                      return 0.0;
    //                                  return u;
    //                              });
    dhand->setInitialCondition("u", [=](double x){
                                        double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
                                        if (x < 0.1 or x > 0.9)
                                            return 0.63;
                                        return 0.63+0.05*r;
                                    });
    // dhand->setInitialCondition("u", [=](double x, double y){
    //                                     double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
    //                                     if (x < 0.1 or x > 0.9)
    //                                         return 0.63;
    //                                     if (y < 0.1 or y > 0.9)
    //                                         return 0.63;
    //                                     return 0.63+0.05*r;
    //                                     // double u = 0.5-0.5*tanh((sqrt((x-0.5)*(x-0.5))-0.25)/(sqrt(2*0.001)));
    //                                     // return u*(0.63+0.05*r);
    //                                 });
    dhand->UpdateGhosts();

    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // hiperproblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    // hiperProbl->setElementFillings("Integ", PredefinedElementFillings::TransientDiffusion);
    // hiperProbl->setElementFillings("Integ", PredefinedElementFillings::AllenCahn);
    hiperProbl->setElementFillings("Integ", PredefinedElementFillings::CahnHilliard);
    hiperProbl->setCubatureGauss("Integ", computeDefaultNumGPts(disMesh->elemType(), disMesh->_bfOrder+1));
    hiperProbl->Update();

    // Linear solver
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp (new NewtonRaphsonNonlinearSolver());
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    // Time iterator
    RCP<TimeIterator> tIterator = rcp(new TimeIterator);
    // tIterator->setLinearSolver(linSolver);
    tIterator->setNonlinearSolver(nonlinSolver);
    tIterator->setTimeStepSize(1e-7);
    tIterator->setStopCriteria(4000, 1e3, 1e-12);
    tIterator->setTimeSteppingScheme(TimeSteppingScheme::AdaptiveLinear);
    tIterator->setLinearStepFactor(1.01, 0.5);
    tIterator->setMaximumTimeStepSize(0.1);
    tIterator->setPrintToFile(PrintToFileMethod::LegacyVtk, 1, "higherOrderPBC");
    // tIterator->setPrintRestart(10, "restart");
    // tIterator->setPostprocess(
    //     1, [dhand, fid, lid, sid, pid](){
    //            double f = dhand->nodeDOFs->getValue(0, fid, IndexType::Local);
    //            double l = dhand->nodeDOFs->getValue(0, lid, IndexType::Local);
    //            double s = dhand->nodeDOFs->getValue(0, sid, IndexType::Local);
    //            double p = dhand->nodeDOFs->getValue(0, pid, IndexType::Local);
    //            cout << setprecision(8) << endl;
    //            if (f != l)
    //                cout << "First and last are different" << endl;
    //            if (abs(f - (s+p)/2.0) > 1e-12)
    //                cout << "Not in plane " << f << " " << l << " " << s << " " << p << " " << (s+p)/2.0 << endl;
    //            // dhand->interpolateDOFs()
    //        });
    tIterator->Update();


    // **************************************************************//
    // *****                       SOLVE                        *****//
    // **************************************************************//

    tIterator->Iterate();

    // **************************************************************//
    // *****                      FINALIZE                      *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
