/*
    **************************************************************************************************
    hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Copyright (c) 2018 Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
    **************************************************************************************************
    hiperlife is under GNU General Public License ("GPL").
    GNU General Public License ("GPL") copyright permissions statement:
    This file is part of hiperlife, hiperlife is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by the Free Software Foundation,
    either version 3 of the License, or (at your option) any later version.
    hiperlife is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along with this program.
    If not, see <http://www.gnu.org/licenses/>.
    **************************************************************************************************
*/

//C++ headers
#include <iostream>
#include <mpi.h>

//Trilinos headers
#include <Teuchos_CommandLineProcessor.hpp>

//hiperlife headers
#include "hl_Math.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_GlobalBasisFunctions.h"

//Extrae headers
#ifdef EXTRAE_PROFILING
    #include "extrae_user_events.h"
#endif

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<FillStructure> fillStr)
{
    //Parameters
    double deltat   = fillStr->userStr->dparam[0];
    double mobility = fillStr->userStr->dparam[1];
    double epsilon2 = fillStr->userStr->dparam[2];

    //Rename variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int DOF   = subFill.numDOFs;
    int eNN   = subFill.eNN;
    int nDim  = subFill.nDim;
    int pDim  = subFill.pDim;
    double *xe_nodes  = subFill.nborCoords.data();
    double *ue_nodes  = subFill.nborDOFs.data();
    double *ue_nodes0 = subFill.nborDOFs0.data();

    //Shape functions and derivatives at Gauss points
    double* Na   = subFill.nborBFsDers(0);
    double* glNa = subFill.nborBFsDers(1);
    double* hlNa = subFill.nborBFsDers(2);
    double jac;
    vector<double> gNa(eNN*pDim), hNa(eNN*pDim*pDim), lapNa(eNN);
    GlobalBasisFunctions::hessians(gNa.data(), jac, hNa.data(), lapNa.data(), subFill);

    //Values at integration points
    vector<double> x(pDim), gphi(pDim);
    double phi{}, phin{}, lapphi{};
    Array::Fill(x.data(), pDim, 0.0);
    Array::Fill(gphi.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d] * Na[i];
        phi  += ue_nodes[DOF*i+0]  * Na[i];
        phin += ue_nodes0[DOF*i+0] * Na[i];

        //Gradients
        for (int d = 0; d < pDim; d++)
            gphi[d] += ue_nodes[DOF*i+0] * gNa[pDim*i+d];

        //Hessians
        for (int d = 0; d < pDim; d++)
            lapphi += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+d];
    }

    //Double well and derivatives
    double    W = (phi*phi)*(1.0-phi)*(1.0-phi)/4.0;
    // double   dW = phi*(1.0-phi)*(1.0-2.0*phi)/2.0;
    double  ddW = (1.0-6.0*phi+6.0*phi*phi)/2.0;
    double dddW = (-1.0+2.0*phi)*3.0;

    //Fill
    for (int i = 0; i < eNN; i++)
    {
        //Gradient of basis function times gradient of phase-field variable
        double gNagphi{};
        for (int d = 0; d < pDim; d++)
            gNagphi += gNa[pDim*i+d]*gphi[d];

        for (int j = 0; j < eNN; j++)
        {
            //Product of the gradient of basis functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            //Fill Ak
            fillStr->Ak(0, 0)[i*eNN+j] += jac * Na[i] * Na[j] / deltat;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * dddW * Na[j] * gNagphi;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * ddW * gNagNb;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * epsilon2 * lapNa[i] * lapNa[j];
        }

        //Fill RHS
        fillStr->Bk(0)[i] += jac * Na[i] * (phi-phin) / deltat;
        fillStr->Bk(0)[i] += jac * mobility * ddW * gNagphi;
        fillStr->Bk(0)[i] += jac * mobility * epsilon2 * lapNa[i] * lapphi;
    }

    //Add to global integral
    fillStr->addToGlobalIntegral("ChemicalFreeEnergy", jac*W);
    fillStr->addToGlobalIntegral("SurfaceFreeEnergy", jac*0.5*epsilon2*Math::SNorm(pDim, gphi.data()));
    fillStr->addToGlobalIntegral("GinzburgLandauFreeEnergy", jac*(W + 0.5*epsilon2*Math::SNorm(pDim, gphi.data())));
    fillStr->addToGlobalIntegral("Mass", jac*phi);

    return;
}


int main(int argc, char *argv[])
{
    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//
    #ifdef EXTRAE_PROFILING
        Extrae_shutdown();
    #endif

    //Initialize MPI
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    //Command-line parameters
    Teuchos::CommandLineProcessor parser;
    parser.setDocString("Get options from the command-line and print this help message automatically.\n");
    int nElem = 24;
    parser.setOption("nElem", &nElem, "nElem.");
    int maxNSteps = 1000;
    parser.setOption("maxNSteps", &maxNSteps, "maxNSteps.");
    Teuchos::CommandLineProcessor::EParseCommandLineReturn
        parseReturn= parser.parse(argc, argv);
    if (parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED)
        return 0;
    if (parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL)
        return 1;

    //Mesh parameters
    BasisFuncType bfType = BasisFuncType::BSplines;
    ElemType eType = ElemType::Parallelep;
    int bfOrder = 2;
    int gPts = pow(bfOrder+1, computePDim(eType));

    //Model parameters
    double deltat   = 1.E-7;
    double mobility = 1.0;
    double epsilon2 = 0.0005;

    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(3);
    userStr->dparam[0] = deltat;
    userStr->dparam[1] = mobility;
    userStr->dparam[2] = epsilon2;

    //Time parameters
    double maxTime  = 10000000;
    double maxDelt  = 10000000;
    double stepFactor = 0.95;

    //Print parameters
    int nSave = 100000000;
    bool printVtk = false;
    string oname = "CahnHilliard.";


    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//

    //Generate mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genStructMesh(nElem);

    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//
    /// **************************************************************//

    //DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"rho"});
    dhand->Update();

    //Initial and boundary conditions
    for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
    {
        double r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        double x = disMesh->nodeCoord(i, 'x', IndexType::Local);
        double y = disMesh->nodeCoord(i, 'y', IndexType::Local);
        double z = disMesh->nodeCoord(i, 'z', IndexType::Local);
        if (sqrt((x-0.5)*(x-0.5) + (y-0.5)*(y-0.5) + (z-0.5)*(z-0.5)) < 0.4)
            dhand->nodeDOFs0->setValue(0, i, IndexType::Local, 0.6+0.3*r);
    }
    dhand->UpdateGhosts();


    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//

    //Create HiPerProblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setCubatureGauss("Integ", gPts);
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->setGlobalIntegrals({"ChemicalFreeEnergy", "SurfaceFreeEnergy", "GinzburgLandauFreeEnergy", "Mass"});
    hiperProbl->Update();


    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    // linSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::SPD);
    linSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Parallel);
    linSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Parmetis);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
    linSolver->setDefaultParameters();
    linSolver->Update();


    RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp(new NewtonRaphsonNonlinearSolver());
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    //Print initial condition
    dhand->nodeDOFs->setValue(dhand->nodeDOFs0);
    if (printVtk)
        dhand->printFileLegacyVtk(oname + to_string(0), false);
    dhand->printFile(oname + to_string(0), OutputMode::Text, true, 0.0, hiperProbl->globalIntegrals());



    /// **************************************************************//
    /// *****                     TIME LOOP                      *****//
    /// **************************************************************//

    #ifdef EXTRAE_PROFILING
        Extrae_restart();
    #endif

    //Loop over time steps
    double time{0.0};
    int timeStep{0};
    double ener_prev{1.E8};
    while ((timeStep < maxNSteps) && (time < maxTime))
    {
        //Write
        if (dhand->myRank() == 0)
            cout << endl << " TS: " << to_string(timeStep) << " Time " << time <<  " Delta " << deltat << endl;

        //Initial guess
        dhand->nodeDOFs->setValue(dhand->nodeDOFs0);
        hiperProbl->UpdateGhosts();

        //Newton-Raphson method
        int ierr = nonlinSolver->solve();

        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 100);
        #endif
        //Check convergence
        if (ierr != 0 and hiperProbl->globalIntegral("GinzburgLandauFreeEnergy") <= ener_prev)
        {
            //Save solution
            dhand->nodeDOFs0->setValue(dhand->nodeDOFs);

            //Update variables
            timeStep ++;
            if (deltat > maxDelt)
                deltat = maxDelt;
            deltat /= stepFactor;
            if (deltat >= maxDelt)
                deltat = maxDelt;
            time += deltat;
            ener_prev = hiperProbl->globalIntegral(2);

            //Write results
            if (timeStep % nSave == 0)
            {
                string solName = oname + to_string(timeStep);
                if (printVtk)
                    dhand->printFileLegacyVtk(solName, false);
                dhand->printFile(solName, OutputMode::Text, true, time, hiperProbl->globalIntegrals());
            }

        }
        else
        {
            //Correct time-step size
            deltat *= stepFactor;
        }
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif

        //Save value of delta
        userStr->dparam[0] = deltat;

        //Check steady-state
        if (deltat < 1.e-14)
            break;
    }

    //Finalize
    MPI_Finalize();
    return 0;
}
