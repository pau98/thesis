// C++ includes
#include <iostream>
#include <vector>

// hiperlife include
#include "ad.h"
#include "hl_Tensor.h"

using namespace autodiff;

class Foo
{
    public:
        Foo() {}
        ~Foo() {}

        // Foo(const Foo&) = delete;
        // Foo& operator=(const Foo&) = delete;

        int a{3};
};

// The single-variable function for which derivatives are needed
dual f0(dual x)
{
    return 1 + x + x*x + 1/x + log(x);
}

// A type defining parameters for a function of interest
struct Params
{
    dual a;
    dual b;
    dual c;
};

// The function that depends on parameters for which derivatives are needed
dual f1(dual x, const Params& params)
{
    return params.a * sin(x) + params.b * cos(x) + params.c * sin(x)*cos(x);
}

// The single-variable function for which derivatives are needed with parameter
dual f11(dual x, double a)
{
    return 1 + x + x*x + 1/x + log(x)*a;
}

// The single-variable function for which derivatives are needed with class
dual f12(dual x, Foo & foo)
{
    return x*foo.a;
}


int main()
{
    using std::cout;
    using std::endl;
    using std::vector;

    // Real-valued function of a real (1st-order ders)
    if (false)
    {
        // Simple
        if (true)
        {
            dual x = 2.0;                                 // the input variable x
            dual u = f0(x);                                // the output variable u

            double dudx = derivative(f0, wrt(x), at(x));   // evaluate the derivative du/dx
            cout << endl;
            cout << "u = " << u << endl;        // print the evaluated output u
            cout << "du/dx = " << dudx << endl; // print the evaluated derivative du/dx
        }

        // Params with ders wrt params
        if (true)
        {
            Params params;   // initialize the parameter variables
            params.a = 1.0;  // the parameter a of type dual, not double!
            params.b = 2.0;  // the parameter b of type dual, not double!
            params.c = 3.0;  // the parameter c of type dual, not double!

            dual x = 0.5;  // the input variable x
            dual u = f1(x, params);  // the output variable u

            // double dudx = derivative(f, wrt(x), at(x, params));        // evaluate the derivative du/dx
            // double duda = derivative(f, wrt(params.a), at(x, params)); // evaluate the derivative du/da
            // double dudb = derivative(f, wrt(params.b), at(x, params)); // evaluate the derivative du/db
            // double dudc = derivative(f, wrt(params.c), at(x, params)); // evaluate the derivative du/dc

            cout << endl;
            cout << "u = " << u << endl;         // print the evaluated output u
            // cout << "du/dx = " << dudx << endl;  // print the evaluated derivative du/dx
            // cout << "du/da = " << duda << endl;  // print the evaluated derivative du/da
            // cout << "du/db = " << dudb << endl;  // print the evaluated derivative du/db
            // cout << "du/dc = " << dudc << endl;  // print the evaluated derivative du/dc
        }

        // Params
        if (true)
        {
            double a = 3;
            dual x = 2.0;                                 // the input variable x
            dual u = f11(x,a);                                // the output variable u

            double dudx = derivative(f11, wrt(x), at(x,a));   // evaluate the derivative du/dx

            cout << endl;
            cout << "u = " << u << endl;        // print the evaluated output u
            cout << "du/dx = " << dudx << endl; // print the evaluated derivative du/dx
        }

        // Class
        if (true)
        {
            Foo foo;
            dual x = 2.0;                                 // the input variable x

            dual u = f12(x, foo);                         // the output variable u
            cout << endl;
            cout << "u = " << u << endl;        // print the evaluated output u

            double dudx = derivative(f12, wrt(x), at(x, foo));   // evaluate the derivative du/dx
            cout << "du/dx = " << dudx << endl;        // print the evaluated derivative du/dx
        }
    }

    // Real-valued function of a real (2nd-order ders)
    if (false)
    {
        auto f = [](dual2nd x) -> dual2nd {return x*x+x+1;};

        dual2nd x = 2.0;                                 // the input variable x
        dual2nd u = f(x);                                // the output variable u
        cout << endl;
        cout << "u = " << u << endl;        // print the evaluated output u

        double dudx = derivative(f, wrt(x), at(x));   // evaluate the derivative du/dx
        cout << "du/dx = " << dudx << endl; // print the evaluated derivative du/dx

        double du2dxdx = derivative<2>(f, wrt(x), at(x));   // evaluate the derivative du/dx
        cout << "du^2/dx/dx = " << du2dxdx << endl; // print the evaluated derivative du/dx
    }

    // Real-valued function of a vector (1s-order ders, grad)
    if (false)
    {
        // Multi-variable function
        if (true)
        {
            auto f = [](dual x, dual y, dual z) -> dual {return 1 + x + y + z + x*y + y*z + x*z + x*y*z + exp(x/y + y/z);};
            dual x = 1.0;
            dual y = 2.0;
            dual z = 3.0;

            dual u = f(x, y, z);

            double dudx = derivative(f, wrt(x), at(x, y, z));
            double dudy = derivative(f, wrt(y), at(x, y, z));
            double dudz = derivative(f, wrt(z), at(x, y, z));

            vector<double> g = gradient(f, wrt(x,y,z), at(x,y,z), u);

            cout << endl;
            cout << "u = " << u << endl;         // print the evaluated output u = f(x, y, z)
            cout << "du/dx = " << dudx << endl;  // print the evaluated derivative du/dx
            cout << "du/dy = " << dudy << endl;  // print the evaluated derivative du/dy
            cout << "du/dz = " << dudz << endl;  // print the evaluated derivative du/dz
            cout << "g = [ ";                    // print the evaluated gradient
            for (auto gi : g)
                cout << gi << " ";
            cout << "]" << endl;
        }

        // std::vector
        if (true)
        {
            auto f = [](vector<dual> x) -> dual {return x[0]+x[1] + x[0]*x[0];};

            vector<dual> x = {1.0, 2.0};                  // the input variable x
            dual u; // = f(x);                                // the output variable u

            double dudx = derivative(f, wrt(x[0]), at(x));   // evaluate the derivative du/dx
            double dudy = derivative(f, wrt(x[1]), at(x));   // evaluate the derivative du/dy
            vector<double> g = gradient(f, wrt(x), at(x), u);

            cout << endl;
            cout << "u = " << u << endl;         // print the evaluated output u
            cout << "du/dx = " << dudx << endl;  // print the evaluated derivative du/dx
            cout << "du/dy = " << dudy << endl;  // print the evaluated derivative du/dy
            cout << "g = [ ";                    // print the evaluated gradient
            for (auto gi : g)
                cout << gi << " ";
            cout << "]" << endl;
        }
    }

    // Real-valued function of a vector (2nd-order ders)
    if (false)
    {
        // Multivariate function
        if (true)
        {
            auto f = [](dual2nd x, dual2nd y) -> dual2nd {return x*x+x+x*y+1;};

            dual2nd x = 2.0;                                 // the input variable x
            dual2nd y = 3.0;                                 // the input variable x
            dual2nd u = f(x,y);                                // the output variable u
            cout << endl;
            cout << "u = " << u << endl;        // print the evaluated output u

            double dudx = derivative(f, wrt(x), at(x,y));   // evaluate the derivative du/dx
            double dudy = derivative(f, wrt(y), at(x,y));   // evaluate the derivative du/dx
            cout << "du/dx = " << dudx << endl; // print the evaluated derivative du/dx
            cout << "du/dy = " << dudy << endl; // print the evaluated derivative du/dx

            double du2dxdx = derivative<2>(f, wrt(x,x), at(x,y));   // evaluate the derivative du/dx
            double du2dxdy = derivative<2>(f, wrt(x,y), at(x,y));   // evaluate the derivative du/dx
            double du2dydx = derivative<2>(f, wrt(y,x), at(x,y));   // evaluate the derivative du/dx
            double du2dydy = derivative<2>(f, wrt(y,y), at(x,y));   // evaluate the derivative du/dx
            cout << "du^2/dx/dx = " << du2dxdx << endl; // print the evaluated derivative du/dx
            cout << "du^2/dx/dy = " << du2dxdy << endl; // print the evaluated derivative du/dx
            cout << "du^2/dy/dx = " << du2dydx << endl; // print the evaluated derivative du/dx
            cout << "du^2/dy/dy = " << du2dydy << endl; // print the evaluated derivative du/dx
        }

        // std::vector 2nd order -> ders, grad, hessian
        if (true)
        {
            double a = 3;
            auto f = [&a](vector<dual2nd> x) -> dual2nd {return x[0]*x[0]+x[0]+x[0]*x[1]*x[1]+a;};

            vector<dual2nd> x = {2.0, 3.0};                  // the input variable x
            dual2nd u = f(x);                                // the output variable u
            cout << "u = " << u << endl;        // print the evaluated output u

            double dudx = derivative(f, wrt(x[0]), at(x));   // evaluate the derivative du/dx
            double dudy = derivative(f, wrt(x[1]), at(x));   // evaluate the derivative du/dx
            cout << "du/dx = " << dudx << endl; // print the evaluated derivative du/dx
            cout << "du/dy = " << dudy << endl; // print the evaluated derivative du/dx

            // tensor<double,1> g = gradient(f, wrt(x), at(x), u);
            // cout << "g = " << g << endl; // print the evaluated derivative du/dx

            double du2dxdx = derivative<2>(f, wrt(x[0],x[0]), at(x));   // evaluate the derivative du/dx
            double du2dxdy = derivative<2>(f, wrt(x[0],x[1]), at(x));   // evaluate the derivative du/dx
            double du2dydx = derivative<2>(f, wrt(x[1],x[0]), at(x));   // evaluate the derivative du/dx
            double du2dydy = derivative<2>(f, wrt(x[1],x[1]), at(x));   // evaluate the derivative du/dx
            cout << "du^2/dx/dx = " << du2dxdx << endl; // print the evaluated derivative du/dx
            cout << "du^2/dx/dy = " << du2dxdy << endl; // print the evaluated derivative du/dx
            cout << "du^2/dy/dx = " << du2dydx << endl; // print the evaluated derivative du/dx
            cout << "du^2/dy/dy = " << du2dydy << endl; // print the evaluated derivative du/dx

            // tensor<double,1> g0;
            // tensor<double,2> h;
            // hessian(f, wrt(x), at(x), u, g0, h);
            // cout << "g0 = " << g0 << endl; // print the evaluated derivative du/dx
            // cout << "h  = " << h << endl; // print the evaluated derivative du/dx
        }
    }

    // Real-valued function of a second-order tensor (2nd-order ders, hessians)
    if (true)
    {
        // Using tensors inside the function
        if (true)
        {
            using hiperlife::Tensor::tensor;

            // Dimensions
            const int n = 2;
            const int m = 3;

            // Function
            auto f = [n,m](vector<dual2nd> xv) -> dual2nd
            {
                using ttl::index::i;
                using ttl::index::j;
                using ttl::index::k;

                tensor<dual2nd,2,false> x(xv.data(),n,m);

                return x(i,j)*x(i,j)*sin(x(i,k)*x(i,k));
            };

            // for (int a = 0; a < 100000; a++)
            {
                // Values
                vector<dual2nd> x = {1.0,2.0,3.0,4.0,5.0,6.0};

                // Hessian
                dual2nd u;
                vector<double> j(n*m);
                vector<double> h(n*m*n*m);
                hessian(f, wrt(x), at(x), u, j, h);

                // cout << endl;
                // cout << "u = " << u << endl;
                // std::cout << "j = " << j << std::endl;
                // std::cout << "h  = " << h << std::endl;
            }
        }
    }

    return 0;
}
