/*******************************************************************************
 * Copyright (c) 2017-2023 Team hiperlife
 * Authors: Mohammad Reza Bayat
 *******************************************************************************
 * This file is part of hiperlife - High Performance Library for Finite Elements
 * Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
 * Distributed under the MIT software license, see the accompanying
 * file LICENSE or http://www.opensource.org/licenses/mit-license.php.
 ******************************************************************************
 *
 * This test solves Poisson problem with weakly imposed Dirichlet boundary conditions.
 * The Nitsche's method is used to impose boundary condition. The problem can be solved
 * in 1D, 2D, or 3D, one just need to change the element type. The app is implemented
 * inside a loop with number of element in each direction as the input argument. The
 * L2 norm of the error is written in a file to check the convergence rate.
 * Computation of jacobian and normal vectors on the boundary is tricky and it is
 * different in 1D, 2D, and 3D.
 *
 */
/// C++ headers
#include <iostream>
#include <fstream>
#include <mpi.h>
#include <cmath>
#include <unistd.h>
#include <chrono>

/// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_MultiPatchMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"

void Domain(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void Nitsche(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void computeL2Error(int numElements);
double analyticalSolution(double x, double y, double z, int dim);
double bodyForce(double x, double y, double z, int dim);

int main()
{
    // Get starting timepoint
    auto start = std::chrono::high_resolution_clock::now();

    MPI_Init(nullptr, nullptr);

    int myRank{};
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    for (int i = 2; i < 6; ++i)
    {
        computeL2Error(pow(2, i));
    }

    MPI_Finalize();

    // Get ending timepoint
    auto stop = std::chrono::high_resolution_clock::now();

    // Get duration. Substart timepoints to
    // get duration. To cast it to proper unit
    // use duration cast method
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(stop - start);

    cout << "Time taken by function: "
         << duration.count() << " seconds" << endl;
    return 0;
}

void computeL2Error(int numElements)
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;

    int i = 1;
    while (0 == i)
        sleep(5);

    /// **************************************************************//
    /// *****                 Parameters                         *****//
    /// **************************************************************//
    double h = 1. / static_cast<double>(numElements);
    ElemType elemType = ElemType::Parallelep;
    BasisFuncType bfType = BasisFuncType::BSplines;
    int bfOrder{3};
    double lambda{1000. / h};                          // Nitsche's parameter
    RCP<UserStructure> userStr = rcp(new UserStructure); // New user structure
    userStr->a_aux.resize(1);
    userStr->a_aux[0] = lambda;

    ///====================== Mesh generation ======================///
    // RCP<StructMeshGenerator> dummyMesh = rcp(new StructMeshGenerator);
    // dummyMesh->setMesh(elemType, bfType, 1);
    // dummyMesh->genCube(numElements, 1.0);

    // RCP<DistributedMesh> disDummyMesh = rcp(new DistributedMesh);
    // disDummyMesh->setMesh(dummyMesh);
    // disDummyMesh->setBalanceMesh(true);
    // disDummyMesh->Update();
    // disDummyMesh->printFileLegacyVtk("paramSp");

    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(elemType, bfType, bfOrder);
    int nGaussPts{};
    int nGaussPtsBorder{};
    switch (elemType)
    {
    case ElemType::Line:
        structMesh->genLine(numElements);
        nGaussPts = ceil(static_cast<double>(2 * bfOrder + 1) / 2.);
        nGaussPtsBorder = 1;
        break;

    case ElemType::Square:
        structMesh->genSquare(numElements, 1.0);
        nGaussPts = pow(ceil(static_cast<double>(2 * bfOrder + 1) / 2.), 2);
        nGaussPtsBorder = ceil(static_cast<double>(2 * bfOrder + 1) / 2.);
        break;
    case ElemType::Parallelep:
        structMesh->genCube(numElements);
        nGaussPts = pow(ceil(static_cast<double>(2 * bfOrder + 1) / 2.), 3);
        nGaussPtsBorder = pow(ceil(static_cast<double>(2 * bfOrder + 1) / 2.), 2);
        break;

    default:
        break;
    }

    // Distributed mesh
    RCP<DistributedMesh> disBackMesh = rcp(new DistributedMesh);
    disBackMesh->setMesh(structMesh);
    disBackMesh->setBalanceMesh(true);
    disBackMesh->Update();
    disBackMesh->printFileLegacyVtk("backMesh");

    /// **************************************************************//
    /// *****               DOFsHANDLER CREATION                 *****//
    /// **************************************************************//
    RCP<DOFsHandler> dofHandBack = rcp(new DOFsHandler(disBackMesh));
    dofHandBack->setNameTag("dofHandBack");
    dofHandBack->setNumDOFs(1);
    dofHandBack->Update();

    dofHandBack->UpdateGhosts();
    dofHandBack->printFileLegacyVtk("dofHand", true);

    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHandBack});

    hiperProbl->setIntegration("Integ", {"dofHandBack"});
    hiperProbl->setCubatureGauss("Integ", nGaussPts);
    hiperProbl->setElementFillings("Integ", Domain);

    hiperProbl->setIntegration("BorderInteg", {"dofHand"});
    hiperProbl->setCubatureBorderGauss("BorderInteg", nGaussPtsBorder);
    hiperProbl->setElementFillings("BorderInteg", Nitsche);

    hiperProbl->setGlobalIntegrals({"L2E", "Volume", "BoundaryArea"});

    hiperProbl->Update();

    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//

    //===========               Set solver               ===========//
    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->setDefaultParameters();
    solver->Update();

    // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setTolerance(1.E-8);
    // solver->setMaxNumIterations(500);
    // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver->setDefaultParameters();
    // solver->Update();

    ofstream myfile;
    myfile.open("cubature_" + to_string(hiperProbl->myRank()) + ".csv", std::ofstream::out | std::ofstream::trunc);
    myfile.close();

    solver->solve();
    solver->UpdateSolution();

    dofHandBack->printFileLegacyVtk("solBack", true);

    hiperProbl->FillLinearSystem();

    double error = sqrt(hiperProbl->globalIntegral("L2E"));

    if (hiperProbl->myRank() == 0)
    {
        cout.precision(15);
        cout << "L2 error      = \t" << error << endl;

        std::ofstream writeOut("L2Errors.csv", std::ios::app);
        assert(writeOut.is_open());
        writeOut.precision(12);
        writeOut << numElements << "\t"
                 << log10(h) << "\t"
                 << hiperProbl->globalIntegral("Volume") << "\t"
                 << lambda << "\t"
                 << hiperProbl->globalIntegral("BoundaryArea") << "\t"
                 << log10(error) << endl;
    }

    // Export stiffness matrix
    // string matName = "A" + to_string(epsilon) + ".mm";
    // EpetraExt::RowMatrixToMatrixMarketFile(matName.c_str(), *hiperProbl->A_new, "LHS", "Left hand side matrix");
}

//===============================================================================

void Domain(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;                                              // Number of neighbor nodes
    int nDim = subFill.nDim;                                            // Number of spatial dimensions
    int pDim = subFill.pDim;                                            // Number of parametric dimension
    int numDOFs = subFill.numDOFs;                                      // Number of degrees of freedom per node
    tensor<double, 1, false> bf(subFill.nborBasisFunctions(), eNN);            // Basis functions
    tensor<double, 2> Dbf_g(eNN, pDim);                                 // Derivatives of basis functions wrt x and y global coordinates
    tensor<double, 2, false> nborCoords(subFill.nborCoords.data(), eNN, nDim); // Coordinates for each node
    tensor<double, 2, false> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);  // DOF values at the nodes
    double jac;                                                         // Jacobian (differential of line/area/volume)
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}}); // Global coordinates (x,y,z)

    //===========              Finding Force              ==========//
    double force = bodyForce(coords(0), coords(1), coords(2), pDim);

    // Writing coordinates of Gaussian points to file
    ofstream myFile;
    myFile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    myFile << std::setprecision(16)
           << coords(0) << " "
           << coords(1) << " "
           << coords(2) << " "
           << 0 << " " << 0 << " " << 0 << " " << 0 << endl;

    //===================   Filling Ak and Bk  =====================//
    tensor<double, 2, false> Ak(fillStr->Ak(0, 0).data(), eNN, eNN);
    tensor<double, 1, false> Bk(fillStr->Bk(0).data(), eNN);
    Ak += product(Dbf_g, Dbf_g, {{1, 1}}) * jac;
    Bk += bf * force * jac;

    ///============          Calculate Errors         ===================///
    double uExact = analyticalSolution(coords(0), coords(1), coords(2), pDim);
    tensor<double, 1> uFEM = product(nborDOFs, bf, {{0, 0}});
    double L2error = (uExact - uFEM(0)) * (uExact - uFEM(0)) * jac;
    fillStr->addToGlobalIntegral("L2E", L2error);
    fillStr->addToGlobalIntegral("Volume", jac);
}

//===============================================================================

void Nitsche(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;                                                        // Number of neighbor nodes
    int nDim = subFill.nDim;                                                      // Number of spatial dimensions
    int pDim = subFill.pDim;                                                      // Number of parametric dimension
    int numDOFs = subFill.numDOFs;                                                // Number of degrees of freedom per node
    tensor<double, 1, false> bf(subFill.nborBasisFunctions(), eNN);                      // Basis functions
    tensor<double, 2, false> Dbf_l(subFill.nborBasisFunctionsDerivatives(1), eNN, pDim); // Local derivatives of the bf
    tensor<double, 2> Dbf_g(eNN, pDim);                                           // Derivatives of basis functions wrt x and y global coordinates
    tensor<double, 2, false> nborCoords(subFill.nborCoords.data(), eNN, nDim);           // Coordinates for each node
    tensor<double, 2, false> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);            // DOF values at the nodes
    double jac;                                                                   // Jacobian (differential of line/area/volume)
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}}); // Global coordinates (x,y,z)
    double lambda{fillStr->userStr->a_aux[0]};

    //===========              Finding Force              ==========//
    double u0 = analyticalSolution(coords(0), coords(1), coords(2), pDim);

    //===========               Jacobian                  ==========//
    std::vector<double> NormalRef(3);
    if (pDim == 1)
    {
        jac = 1.;
        NormalRef = subFill.normalsBoundaryRef();
    }
    else if (pDim == 2)
    {
        // Computing Tangent Map
        double Ip[4], xu[3], xv[3];
        SurfLagrParam::MetricTensor(Ip, xu, xv, eNN, nborCoords.data(), Dbf_l.data());

        std::vector<double> bTangentRef = subFill.tangentsBoundaryRef();
        double bTangent[3] = {};

        for (int n = 0; n < nDim; n++)
            bTangent[n] = bTangentRef[0] * xu[n] + bTangentRef[1] * xv[n];

        jac = Math::Norm3D(bTangent);
        NormalRef = subFill.normalsBoundaryRef();
    }
    else if (pDim == 3)
    {
        // Position in Euclidean space of the Gauss point
        double *xe_nodes = subFill.nborCoords.data(); // position of the nodes (global)
        double *dp_k = subFill.nborBFsDers(1);

        std::vector<double> bTangentRef(3);
        bTangentRef = subFill.tangentsBoundaryRef();

        // Computing Tangent Map
        double phi0_1[3], phi0_2[3], phi0_3[3];
        phi0_1[0] = 0.0;
        phi0_1[1] = 0.0;
        phi0_1[2] = 0.0;
        phi0_2[0] = 0.0;
        phi0_2[1] = 0.0;
        phi0_2[2] = 0.0;
        phi0_3[0] = 0.0;
        phi0_3[1] = 0.0;
        phi0_3[2] = 0.0;
        for (int i = 0; i < eNN; i++)
        {
            phi0_1[0] += xe_nodes[nDim * i + 0] * dp_k[3 * i + 0];
            phi0_1[1] += xe_nodes[nDim * i + 1] * dp_k[3 * i + 0];
            phi0_1[2] += xe_nodes[nDim * i + 2] * dp_k[3 * i + 0];

            phi0_2[0] += xe_nodes[nDim * i + 0] * dp_k[3 * i + 1];
            phi0_2[1] += xe_nodes[nDim * i + 1] * dp_k[3 * i + 1];
            phi0_2[2] += xe_nodes[nDim * i + 2] * dp_k[3 * i + 1];

            phi0_3[0] += xe_nodes[nDim * i + 0] * dp_k[3 * i + 2];
            phi0_3[1] += xe_nodes[nDim * i + 1] * dp_k[3 * i + 2];
            phi0_3[2] += xe_nodes[nDim * i + 2] * dp_k[3 * i + 2];
        }
        double bTangent1[3] = {};
        double bTangent2[3] = {};

        bTangent1[0] = bTangentRef[0] * phi0_1[0] + bTangentRef[1] * phi0_2[0] + bTangentRef[2] * phi0_3[0];
        bTangent1[1] = bTangentRef[0] * phi0_1[1] + bTangentRef[1] * phi0_2[1] + bTangentRef[2] * phi0_3[1];
        bTangent1[2] = bTangentRef[0] * phi0_1[2] + bTangentRef[1] * phi0_2[2] + bTangentRef[2] * phi0_3[2];

        bTangent2[0] = bTangentRef[3] * phi0_1[0] + bTangentRef[4] * phi0_2[0] + bTangentRef[5] * phi0_3[0];
        bTangent2[1] = bTangentRef[3] * phi0_1[1] + bTangentRef[4] * phi0_2[1] + bTangentRef[5] * phi0_3[1];
        bTangent2[2] = bTangentRef[3] * phi0_1[2] + bTangentRef[4] * phi0_2[2] + bTangentRef[5] * phi0_3[2];

        Math::Cross(NormalRef.data(), bTangent1, bTangent2);
        jac = Math::Norm3D(NormalRef.data());
        NormalRef = subFill.normalsBoundaryRef();
    }

    tensor<double, 1> NDbf_g(eNN); // Normal derivative
    NDbf_g(all) = NormalRef[0] * Dbf_g(all, 0) + NormalRef[1] * Dbf_g(all, 1) + NormalRef[2] * Dbf_g(all, 2);

    // Writing Gaussian point coordinates and normal unit vectors in the reference configuration to the file
    ofstream myFile;
    myFile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    myFile << std::setprecision(16)
           << coords(0) << " "
           << coords(1) << " "
           << coords(2) << " "
           << 1 << " "
           << NormalRef[0] << " "
           << NormalRef[1] << " "
           << NormalRef[2] << endl;
    myFile.close();

    //======================   Output  =============================//
    tensor<double, 2, false> Ak(fillStr->Ak(0, 0).data(), eNN, eNN);
    tensor<double, 1, false> Bk(fillStr->Bk(0).data(), eNN);
    Ak -= outer(NDbf_g, bf) * jac;
    Ak -= outer(bf, NDbf_g) * jac;
    Ak += lambda * outer(bf, bf) * jac;
    Bk -= u0 * NDbf_g * jac;
    Bk += lambda * u0 * bf * jac;

    ///============          Calculate Errors         ===================///
    tensor<double, 1> uFEM = product(nborDOFs, bf, {{0, 0}});
    double L2error = (u0 - uFEM(0)) * (u0 - uFEM(0)) * jac;
    fillStr->addToGlobalIntegral("L2E", L2error);
    fillStr->addToGlobalIntegral("BoundaryArea", jac);
}

double analyticalSolution(double x, double y, double z, int dim)
{
    double f{1};
    if (dim == 1)
        return (x + sin(M_PI * f * x));
    if (dim == 2)
        return (x * y + sin(M_PI * f * x) * sin(M_PI * f * y));
    return (x * y * z + sin(M_PI * f * x) * sin(M_PI * f * y) * sin(M_PI * f * z));
}

double bodyForce(double x, double y, double z, int dim)
{
    double f{1};
    if (dim == 1)
        return (f * f * M_PI * M_PI * sin(M_PI * f * x));
    else if (dim == 2)
        return (2 * f * f * M_PI * M_PI * sin(M_PI * f * x) * sin(M_PI * f * y));
    return (3 * f * f * M_PI * M_PI * sin(M_PI * f * x) * sin(M_PI * f * y) * sin(M_PI * f * z));
}
