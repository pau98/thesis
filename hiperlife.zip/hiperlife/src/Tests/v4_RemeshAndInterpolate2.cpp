
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>
#include "hl_Timer.h"
/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_BasicMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_PostProc.h"
#include "hl_VtkGrid.h"
#include <vtkPolyData.h>
#include <vtkPolyDataWriter.h>
#include <vtkPolyData.h>
// #include <vtkPolyDataRemeshing.h>
#include <vtkPolyDataWriter.h>
#include <vtkCleanPolyData.h>
#include <vtkPolyDataWriter.h>
#include "hl_MeshLoader.h"
#include "hl_SurfLagrParam.h"
#include "hl_Remesher.h"
#include <fstream>
#include <string>
#include <iostream>



using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);
void combineGaussPts(RCP<UserStructure> userStr, RCP <DOFsHandler> dofHand);
void combineDOFs(RCP<UserStructure> userStr, RCP <DOFsHandler> dofHand);

double f(double x1,double x2, double x3)
{
    if (x3>5 and x3<6)
    {
         return 1.E-3;
    }
    else
        return 1E-2;
}

int main()
{


    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);
    int myRank, numProcs;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    MPI_Comm_size(MPI_COMM_WORLD, &numProcs);
    Timer timer({"1", "2", "3", "4"});
    ///=============== Define parameters of the model ===============///
    /// Save the parameters into double data type variables
    RCP <UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(2);
    userStr->iparam.resize(5);
    userStr->iparam[1] = 0;
    userStr->iparam[3] = 0;
    userStr->u_aux.resize(0);
    userStr->bparam.resize(1);
    userStr->bparam[0]=false;
    int numIterRemesh = 3;
    double h = 0.01;
    string meshFile="../meshes/cell.vtk";

    if (myRank==0) cout<<"Genrate mesh"<<endl;
    ///====================== Mesh generation ======================///
    ///


    RCP<MeshLoader> loadmesh = rcp(new MeshLoader("MeshLoader",MPI_COMM_WORLD));

    loadmesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);

    loadmesh->loadMesh(meshFile, MeshType::Sequential);

    ///===========             Distribute mesh            ===========///

    if (myRank==0) cout<<"Generate distributed  mesh"<<endl;

    RCP <DistributedMesh> disMesh     = rcp(new DistributedMesh);
    RCP <DistributedMesh> disMesh_;
    disMesh->setMesh(loadmesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();
    disMesh->printFileLegacyVtk("cell");


    RCP <DOFsHandler> dofHand0 = rcp(new DOFsHandler(disMesh));
    dofHand0->setNameTag("dofHand0");
    dofHand0->setDOFs({"partition","x"});
    dofHand0->setNodeAuxF({"y","z"});
    dofHand0->Update();


    RCP <DOFsHandler> dofHand1 = rcp(new DOFsHandler(disMesh));
    dofHand1->setNameTag("dofHand1");
    dofHand1->setDOFs({"x+y"});
    dofHand1->setNodeAuxF({"y+z"});
    dofHand1->Update();



    RCP <DOFsHandler> dofHand2 = rcp(new DOFsHandler(disMesh));
    dofHand2->setNameTag("dofHand2");
    dofHand2->setDOFs({"y+z"});
    dofHand2->Update();



    // Impose initial conditions
    for (int i=0;i<disMesh->loc_nPts();i++)
    {
        auto x_ = disMesh->nodeCoords(i,IndexType::Local);
        double x = x_[0];
        double y = x_[1];
        double z = x_[2];
        double partition = disMesh->nodePartition(disMesh->_adjcyNE->globIdx(i)) ;

        dofHand0->nodeDOFs->setValue("partition", i, IndexType::Local,partition);
        dofHand0->nodeDOFs->setValue("x", i, IndexType::Local,x);
        dofHand0->nodeAuxF->setValue("y", i, IndexType::Local,y);
        dofHand0->nodeAuxF->setValue("z", i, IndexType::Local,z);

        dofHand1->nodeDOFs->setValue("x+y", i, IndexType::Local,x+y);
        dofHand1->nodeAuxF->setValue("y+z", i, IndexType::Local,y+z);

        dofHand2->nodeDOFs->setValue("y+z", i, IndexType::Local,y+z);

    }

    dofHand0->UpdateGhosts();
    dofHand0->printFileLegacyVtk("oldMesh0", true);

    dofHand1->UpdateGhosts();
    dofHand1->printFileLegacyVtk("oldMesh1", true);

    dofHand2->UpdateGhosts();
    dofHand2->printFileLegacyVtk("oldMesh2", true);


    std::vector<string> dofs0, dofs1, dofs2, nodeAuxF0, nodeAuxF1;

    dofs0.resize(0);dofs0.push_back("partition"); dofs0.push_back("x");
    nodeAuxF0.resize(0); nodeAuxF0.push_back("y");  nodeAuxF0.push_back("z");


    dofs1.resize(0);dofs1.push_back("x+y");;
    nodeAuxF1.resize(0); nodeAuxF1.push_back("y+z");

    dofs2.resize(0);dofs2.push_back("y+z");;

    RCP <Remesher> remesher = rcp(new Remesher);
    remesher->setDOFsHandler(dofHand0,dofs0,nodeAuxF0);
    remesher->setDOFsHandler(dofHand1,dofs1,nodeAuxF1);
    remesher->setDOFsHandler(dofHand2,dofs2);
//    remesher->setRemeshMethod(RemeshMethod::Serial,5.E-7 ) ;
    remesher->setRemeshMethod(RemeshMethod::Serial,f);
    remesher->setDefaultParameters();
    remesher->Update();

    std::vector<RCP <DOFsHandler>> newDOFHands = {dofHand0, dofHand1, dofHand2};

    remesher->newDOFsHands(newDOFHands);




    newDOFHands[0]->printFileLegacyVtk("newMesh0",true);
    newDOFHands[1]->printFileLegacyVtk("newMesh1",true);
    newDOFHands[2]->printFileLegacyVtk("newMesh2",true);

    return 0;

}
