#include <iostream>
#include <mpi.h>

#include <Teuchos_RCP.hpp>

#include "hl_StructMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_Array.h"
#include "hl_Geometry.h"
#include "hl_MeshMap.h"
#include "hl_MeshMap_Trivial.h"
#include "hl_MeshMap_Boundary.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_Timer.h"


using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;



int main(int argc, char **argv)
{
    //Initialize
    MPI_Init(nullptr, nullptr);
    int myRank;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    //Parameters
    BasisFuncType bfType = BasisFuncType::SubdivSurfs;
    ElemType eType = ElemType::Triang;
    int bfOrder = 2;

    //###################################################################//
    //                             MAIN MESH                             //
    //###################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "MESH" << endl;

    //Generate mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    // structMesh->genStructMesh(20);
    // structMesh->genRuledSurface(20, 20, {0,0,0}, {0,1,0.5}, {1,1,-0.2}, {1,0,0.3});
    // structMesh->genRuledSurface(20, 20, {0,0,0}, {0,100,50}, {100,100,0}, {100,0,50});
    // structMesh->genDisk_Polar(60, 60, 1.0);
    // structMesh->genDisk_Squared(20, 20, 1.0);
    // structMesh->genAnnularSector(27, 27, 0.2, 1.0, 2.5*M_PI/2.0);
    // structMesh->genTorusSurfacePatchSector(40, 40, 0.1, 2.5*M_PI/4.0, 0.2, 2.5*M_PI/2.0);
    structMesh->genTorusSurface(10, 10, 0.1, 0.2);
    // structMesh->genTorusSolidSector(20, 20, 20, 0.1, 0.2, 2.5*M_PI/2.0);
    // structMesh->genTorusSolid(40, 40, 40, 0.2, 0.5);
    // structMesh->genCircularArc(4, 1.0, M_PI/2.0);
    // structMesh->genCircle(20, 1.0);
    // structMesh->translate(-1.0, -1.0, 0.0);
    // structMesh->scale(2.0);
    // structMesh->stretchElemsAsymmetric(2.5);

    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    //Print mesh
    disMesh->printFileLegacyVtk("MeshGenerated");

    // MPI_Finalize();
    // return 0;



    //###################################################################//
    //                         LOAD GENERATED MESH                       //
    //###################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "LOAD GEN MESH" << endl;

    //Generate mesh
    RCP<MeshLoader> loadedGenMesh = rcp(new MeshLoader);
    loadedGenMesh->setMesh(eType, bfType, bfOrder);
    loadedGenMesh->loadMesh("./MeshGenerated.vtk", MeshType::Sequential);
    loadedGenMesh->rotate2D(M_PI/4.0);
    loadedGenMesh->translateX(1.0);
    loadedGenMesh->rotateX(M_PI/6);

    //Create distributed mesh
    RCP<DistributedMesh> disMeshGL = rcp(new DistributedMesh);
    disMeshGL->setMesh(loadedGenMesh);
    disMeshGL->setBalanceMesh(true);
    disMeshGL->Update();

    //Print mesh
    disMeshGL->printFileLegacyVtk("MeshLoadedGen");


    //######################################################################//
    //                       GLOBAL CONSTRAINT MESH                         //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "GLOBAL CONSTRAINT MESH" << endl;

    //Create global constraint distributed mesh
    RCP<DistributedMesh> gDisMesh = rcp(new DistributedMesh);
    gDisMesh->setMeshRelation(MeshRelation::GlobConstr, disMesh);
    gDisMesh->setBalanceMesh(true);
    gDisMesh->Update();

    // MPI_Finalize();
    // return 0;


    //######################################################################//
    //                           P-REFINED MESH                             //
    //######################################################################//

    // //Output info
    // MPI_Barrier(MPI_COMM_WORLD);
    // if (myRank == 0)
    //     cout << endl << "P-REFINED MESH" << endl << " ";

    // //p-refined mesh
    // RCP<DistributedMesh> pDisMesh = rcp(new DistributedMesh);
    // pDisMesh->setMeshRelation(MeshRelation::pRefin, disMeshGL);
    // pDisMesh->setPRefinement(1);
    // pDisMesh->setBalanceMesh(false);
    // pDisMesh->Update();

    // //Print mesh
    // pDisMesh->printFileLegacyVtk("pMesh");

    // // MPI_Finalize();
    // // return 0;



    //######################################################################//
    //                           H-REFINED MESH                             //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "H-REFINED MESH" << endl << "  ";

    //Create h-refined mesh
    RCP<DistributedMesh> hDisMesh = rcp(new DistributedMesh);
    hDisMesh->setMeshRelation(MeshRelation::hRefin, disMeshGL);
    hDisMesh->setHRefinement(1);
    hDisMesh->setBalanceMesh(false);
    hDisMesh->Update();

    //Print mesh
    hDisMesh->printFileLegacyVtk("hMesh");


    //###################################################################//
    //                             LOAD MESH                             //
    //###################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "LOADER" << endl;

    //Generate mesh
    RCP<MeshLoader> loadedMesh = rcp(new MeshLoader);
    loadedMesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
    loadedMesh->loadLegacyVtk("../meshes/circle_n3.vtk", MeshType::Sequential);
    // loadedMesh->scaleY(0.2);
    loadedMesh->shearX(2.0);

    //Create distributed mesh
    RCP<DistributedMesh> disMeshL = rcp(new DistributedMesh);
    disMeshL->setMesh(loadedMesh);
    disMeshL->setBalanceMesh(true);
    disMeshL->Update();

    //Print mesh
    disMeshL->printFileLegacyVtk("MeshLoaded");

    //Finalize
    MPI_Finalize();

    return 0;
}
