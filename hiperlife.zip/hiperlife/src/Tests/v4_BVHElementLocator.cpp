
// C++ headers
#include <mpi.h>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_Timer.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_TypeDefs.h"
#include "hl_vtkElementLocator.h"
#include "hl_QuadtreeElementLocator.h"
#include "hl_OctreeElementLocator.h"
#include "hl_BVHElementLocator.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

using namespace std;


int main()
{

    //*************************************************************************
    // [0] Initialize
    //*************************************************************************

    // Initialize MPI
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    if (myRank == 0)
        cout << endl;

    // Create timer
    Timer t_build({"build_vtk", "build_oct", "build_qua", "build_bvh"});
    Timer t({"vtk", "oct", "qua", "bvh"});

    // Parameters
    bool searchVtk = true;
    bool searchOct = true;
    bool searchQua = false;
    bool searchBvh = true;
    bool interpolate = true;
    bool print = true;
    bool check = true;


    //*************************************************************************
    // [1] Create mesh
    //*************************************************************************

    // Create mesh
    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    mesh->genStructMesh(41,23);
    // mesh->rotate2D(M_PI/6.0);
    // mesh->genRuledSurface(4, 4, {0,0,0}, {0,1,0.5}, {1,1,-0.2}, {-1,0,0.3});
    // mesh->genTorusSurfacePatchSector(12*4*2, 12*2*4, 0.2, M_PI/2.0, 1.0, M_PI/2.0);

    // Distribute the mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->setElementLocatorEngine(ElementLocatorEngine::None);
    disMesh->setVerbosity(hiperlife::Verbosity::None);
    disMesh->Update();
    disMesh->printFileLegacyVtk("mesh");
    // disMesh->printFileVtk("mesh");

    // DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setDOFs({"u"});
    dhand->setElemAuxF({"nId"});
    dhand->Update();

    if (false)
    {
        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        RCP<BVHElementLocator> elLoc = rcp(new BVHElementLocator);
        elLoc->setDistributedMesh(disMesh.getRawPtr());
        elLoc->Update();

        // Initialize
        int elem;
        vector<double> rCoords(disMesh->pDim());
        vector<double> gCoords(3, -1.0);

        // Find point
        if (myRank == 0)
            cout << " Searching" << endl;
        double dist = elLoc->searchElementInPartition(elem, rCoords, gCoords);

        cout << dist << " " << elem << endl;

        // Finalize
        MPI_Finalize();
        return 0;

    }



    //*************************************************************************
    // [2] Create points
    //*************************************************************************

    // Create mesh
    RCP<StructMeshGenerator> p_mesh = rcp(new StructMeshGenerator);
    p_mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    p_mesh->genStructMesh(511);//511*0+81*3+1);
    // p_mesh->genTorusSurfacePatchSector(32*4*2*3, 41*4*2*3, 0.2, M_PI/2.0, 1.0, M_PI/2.0);
    // p_mesh->genTorusSurfacePatchSector(32*4*3, 41*4*3, 0.2, M_PI/2.0, 1.0, M_PI/2.0);
    p_mesh->scale(1.05);

    // Distribute the mesh
    RCP<DistributedMesh> p_disMesh = rcp(new DistributedMesh);
    p_disMesh->setMesh(p_mesh);
    p_disMesh->setBalanceMesh(true);
    p_disMesh->setElementLocatorEngine(ElementLocatorEngine::None);
    p_disMesh->Update();
    p_disMesh->printFileLegacyVtk("meshToInterpolate");

    // Save and distribute the points
    int nPts = p_disMesh->nPts();
    vector<vector<double>> gCoords(nPts, vector<double>(3));
    for (int i = 0; i < nPts; i++)
    {
        int p_new = p_disMesh->nodePartition(i);
        if (p_disMesh->isNodeInPart(i))
            gCoords[i] = p_disMesh->nodeCoords(i);
        MPI_Bcast(gCoords[i].data(), 3, MPI_DOUBLE, p_new, p_disMesh->comm());
    }

    // // Keep one point only
    // int keep = 21284;
    // gCoords.erase(gCoords.begin()+keep+1,gCoords.end());
    // gCoords.erase(gCoords.begin(),gCoords.begin()+keep);
    // nPts = gCoords.size();

    // // Keep range
    // int keep0 = 0;
    // int keep1 = 3;
    // gCoords.erase(gCoords.begin()+keep1+1,gCoords.end());
    // gCoords.erase(gCoords.begin(),gCoords.begin()+keep0);
    // nPts = gCoords.size();

    // // Set point by hand
    // nPts = 1;
    // gCoords.clear();
    // gCoords.resize(1, vector<double>(3, 0.0));
    // gCoords[0][0] = 0.5;
    // gCoords[0][1] = -0.1;

    // Output points
    if (myRank == 0)
    {
        cout << endl << "Searching for " << nPts << " points within a " << disMesh->nElem() << " element mesh" << endl;
        cout << endl << "Printing points" << endl;
        ofstream myfile;
        myfile.open("point.csv", std::ofstream::out | std::ofstream::trunc);
        for (int i = 0; i < nPts; i++)
            myfile << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
        myfile.close();
    }


    //*************************************************************************
    // [3] Find
    //*************************************************************************

    // Find points vtk
    vector<vector<double>> cPP_vtk(nPts, vector<double>(3));
    if (searchVtk)
    {
        if (myRank == 0)
            cout << endl << "Finding points vtk" << endl;

        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        t_build.start("build_vtk");
        RCP<vtkElementLocator> elLoc = rcp(new vtkElementLocator);
        elLoc->setDistributedMesh(&*disMesh);
        // elLoc->_dhand = dhand;
        elLoc->Update();
        t_build.end("build_vtk");

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find
        MPI_Barrier(elLoc->comm());
        t.start("vtk");
        if (myRank == 0)
            cout << " Searching" << endl;
        elLoc->searchElement(elems, rCoords, gCoords);
        t.end("vtk");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_vtk[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_vtk[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_vtk.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << endl;
            myfile.close();
        }
    }

    // Find points octree
    vector<vector<double>> cPP_oct(nPts, vector<double>(3));
    if (searchOct)
    {
        if (myRank == 0)
            cout << endl << "Finding points octree" << endl;

        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        t_build.start("build_oct");
        RCP<OctreeElementLocator> elLoc = rcp(new OctreeElementLocator);
        elLoc->setDistributedMesh(disMesh.getRawPtr());
        elLoc->Update();
        t_build.end("build_oct");

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find points
        MPI_Barrier(elLoc->comm());
        t.start("oct");
        if (myRank == 0)
            cout << " Searching" << endl;
        elLoc->searchElement(elems, rCoords, gCoords);
        t.end("oct");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                // cout << i << " : " << elems[i] << endl;
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_oct[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_oct[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_oct.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << endl;
            myfile.close();
        }

        // Check
        if (myRank == 0 and interpolate and check)
        {
            cout << " Checking" << endl;
            ofstream myfile, myfile2, myfile3;
            if (true)
            {
                myfile.open("not_found_vtk.csv", std::ofstream::out | std::ofstream::trunc);
                myfile2.open("not_found_oct.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                        dist2 += (cPP_oct[i][d]-cPP_vtk[i][d])*(cPP_oct[i][d]-cPP_vtk[i][d]);
                    if (dist2 > 1e-8)
                    {
                        // Compute dists
                        double dist_vtk{}, dist_oct{};
                        for (int d = 0; d < 3; d++)
                        {
                            dist_vtk += (gCoords[i][d]-cPP_vtk[i][d])*(gCoords[i][d]-cPP_vtk[i][d]);
                            dist_oct += (gCoords[i][d]-cPP_oct[i][d])*(gCoords[i][d]-cPP_oct[i][d]);
                        }
                        dist_vtk = sqrt(dist_vtk);
                        dist_oct = sqrt(dist_oct);

                        // Output
                        if (dist_vtk < dist_oct)
                        {
                            cout << std::setprecision(12) << "Octree failed: " << i << ": "
                                 << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << " <-> "
                                 << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << " | "
                                 << dist_vtk << " " << dist_oct << endl;
                            myfile << std::setprecision(16) << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << endl;
                            myfile2 << std::setprecision(16) << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << endl;
                            myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                        }
                    }
                }
                myfile.close();
                myfile2.close();
                myfile3.close();
            }
            else
            {
                myfile2.open("not_found_oct.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                    {
                        dist2 += (gCoords[i][d]-cPP_oct[i][d])*(gCoords[i][d]-cPP_oct[i][d]);
                    }
                    dist2 = sqrt(dist2);
                    if (dist2 > 1e-2)
                    {
                        // Output
                        cout << std::setprecision(12) << "Octree failed: " << i << " " << elems[i] << ": "
                             << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << " <-> "
                             << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << " | "
                             << dist2 << endl;
                        myfile2 << std::setprecision(16) << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << endl;
                        myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                    }
                }
                myfile2.close();
                myfile3.close();
            }
        }
    }

    // Find points quadtree
    vector<vector<double>> cPP_qua(nPts, vector<double>(3));
    if (searchQua)
    {
        if (myRank == 0)
            cout << endl << "Finding points quadree" << endl;

        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        t_build.start("build_qua");
        RCP<QuadtreeElementLocator> elLoc = rcp(new QuadtreeElementLocator);
        elLoc->setDistributedMesh(disMesh.getRawPtr());
        elLoc->Update();
        t_build.end("build_qua");

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find points
        MPI_Barrier(elLoc->comm());
        t.start("qua");
        if (myRank == 0)
            cout << " Searching" << endl;
        elLoc->searchElement(elems, rCoords, gCoords);
        t.end("qua");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                // cout << i << " : " << elems[i] << endl;
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_qua[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_qua[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_qua.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << endl;
            myfile.close();
        }

        // Check
        if (myRank == 0 and interpolate and check)
        {
            cout << " Checking" << endl;
            ofstream myfile, myfile2, myfile3;
            if (true)
            {
                myfile.open("not_found_vtk.csv", std::ofstream::out | std::ofstream::trunc);
                myfile2.open("not_found_qua.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                        dist2 += (cPP_qua[i][d]-cPP_vtk[i][d])*(cPP_qua[i][d]-cPP_vtk[i][d]);
                    if (dist2 > 1e-8)
                    {
                        // Compute dists
                        double dist_vtk{}, dist_qua{};
                        for (int d = 0; d < 3; d++)
                        {
                            dist_vtk += (gCoords[i][d]-cPP_vtk[i][d])*(gCoords[i][d]-cPP_vtk[i][d]);
                            dist_qua += (gCoords[i][d]-cPP_qua[i][d])*(gCoords[i][d]-cPP_qua[i][d]);
                        }
                        dist_vtk = sqrt(dist_vtk);
                        dist_qua = sqrt(dist_qua);

                        // Output
                        if (dist_vtk < dist_qua)
                        {
                            cout << std::setprecision(12) << "Quadree failed: " << i << ": "
                                 << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << " <-> "
                                 << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << " | "
                                 << dist_vtk << " " << dist_qua << endl;
                            myfile << std::setprecision(16) << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << endl;
                            myfile2 << std::setprecision(16) << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << endl;
                            myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                        }
                    }
                }
                myfile.close();
                myfile2.close();
                myfile3.close();
            }
            else
            {
                myfile2.open("not_found_qua.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                    {
                        dist2 += (gCoords[i][d]-cPP_qua[i][d])*(gCoords[i][d]-cPP_qua[i][d]);
                    }
                    dist2 = sqrt(dist2);
                    if (dist2 > 1e-2)
                    {
                        // Output
                        cout << std::setprecision(12) << "Quadree failed: " << i << " " << elems[i] << ": "
                             << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << " <-> "
                             << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << " | "
                             << dist2 << endl;
                        myfile2 << std::setprecision(16) << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << endl;
                        myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                    }
                }
                myfile2.close();
                myfile3.close();
            }
        }
    }

    // Find points bvh
    vector<vector<double>> cPP_bvh(nPts, vector<double>(3));
    if (searchBvh)
    {
        if (myRank == 0)
            cout << endl << "Finding points bvh" << endl;

        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        t_build.start("build_bvh");
        RCP<BVHElementLocator> elLoc = rcp(new BVHElementLocator);
        elLoc->setDistributedMesh(disMesh.getRawPtr());
        elLoc->Update();
        t_build.end("build_bvh");

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find points
        MPI_Barrier(elLoc->comm());
        t.start("bvh");
        if (myRank == 0)
            cout << " Searching" << endl;
        vector<double> dists = elLoc->searchElement(elems, rCoords, gCoords);
        // if (disMesh->isElemInPart(elems[0]))
        //     cout << endl << "Finally " << elems[0] << " " << dists[0] << " in part " << disMesh->myRank() << endl;
        t.end("bvh");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_bvh[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_bvh[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_bvh.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_bvh[i][0] << " " << cPP_bvh[i][1] << " " << cPP_bvh[i][2] << endl;
            myfile.close();
        }

        // Check
        if (myRank == 0 and interpolate and check)
        {
            cout << " Checking" << endl;
            ofstream myfile, myfile2, myfile3;
            if (true)
            {
                myfile.open("not_found_vtk.csv", std::ofstream::out | std::ofstream::trunc);
                myfile2.open("not_found_bvh.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                        dist2 += (cPP_bvh[i][d]-cPP_vtk[i][d])*(cPP_bvh[i][d]-cPP_vtk[i][d]);
                    if (dist2 > 1e-8)
                    {
                        // Compute dists
                        double dist_vtk{}, dist_bvh{};
                        for (int d = 0; d < 3; d++)
                        {
                            dist_vtk += (gCoords[i][d]-cPP_vtk[i][d])*(gCoords[i][d]-cPP_vtk[i][d]);
                            dist_bvh += (gCoords[i][d]-cPP_bvh[i][d])*(gCoords[i][d]-cPP_bvh[i][d]);
                        }
                        dist_vtk = sqrt(dist_vtk);
                        dist_bvh = sqrt(dist_bvh);

                        // Output
                        if (dist_vtk < dist_bvh)
                        {
                            cout << std::setprecision(12) << "Bvh failed: " << i << ": "
                                 << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << " <-> "
                                 << cPP_bvh[i][0] << " " << cPP_bvh[i][1] << " " << cPP_bvh[i][2] << " | "
                                 << dist_vtk << " " << dist_bvh << endl;
                            myfile << std::setprecision(16) << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << endl;
                            myfile2 << std::setprecision(16) << cPP_bvh[i][0] << " " << cPP_bvh[i][1] << " " << cPP_bvh[i][2] << endl;
                            myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                        }
                    }
                }
                myfile.close();
                myfile2.close();
                myfile3.close();
            }
            else
            {
                myfile2.open("not_found_bvh.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                    {
                        dist2 += (gCoords[i][d]-cPP_bvh[i][d])*(gCoords[i][d]-cPP_bvh[i][d]);
                    }
                    dist2 = sqrt(dist2);
                    if (dist2 > 1e-2)
                    {
                        // Output
                        cout << std::setprecision(12) << "Bvh failed: " << i << " " << elems[i] << ": "
                             << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << " <-> "
                             << cPP_bvh[i][0] << " " << cPP_bvh[i][1] << " " << cPP_bvh[i][2] << " | "
                             << dist2 << endl;
                        myfile2 << std::setprecision(16) << cPP_bvh[i][0] << " " << cPP_bvh[i][1] << " " << cPP_bvh[i][2] << endl;
                        myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                    }
                }
                myfile2.close();
                myfile3.close();
            }
        }
    }


    //*************************************************************************
    // [4] Print
    //*************************************************************************

    // Print dhand
    dhand->printFileLegacyVtk("sol", true);

    // Print times
    t.printTiming(true);
    double t_vtk = t.printAccumTime("vtk");
    MPI_Allreduce(&t_vtk, &t_vtk, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_oct = t.printAccumTime("oct");
    MPI_Allreduce(&t_oct, &t_oct, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_qua = t.printAccumTime("qua");
    MPI_Allreduce(&t_qua, &t_qua, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_bvh = t.printAccumTime("bvh");
    MPI_Allreduce(&t_bvh, &t_bvh, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_build_vtk = t_build.printAccumTime("build_vtk");
    MPI_Allreduce(&t_build_vtk, &t_build_vtk, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_build_oct = t_build.printAccumTime("build_oct");
    MPI_Allreduce(&t_build_oct, &t_build_oct, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_build_qua = t_build.printAccumTime("build_qua");
    MPI_Allreduce(&t_build_qua, &t_build_qua, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_build_bvh = t_build.printAccumTime("build_bvh");
    MPI_Allreduce(&t_build_bvh, &t_build_bvh, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    if (myRank == 0)
    {
        cout << endl << endl << "Max build times" << endl;
        cout << "VTK:       " << t_build_vtk << endl;
        cout << "oct:       " << t_build_oct << endl;
        cout << "qua:       " << t_build_qua << endl;
        cout << "bvh:       " << t_build_bvh << endl;

        cout << endl << "Max times" << endl;
        cout << "VTK:       " << t_vtk << endl;
        cout << "oct:       " << t_oct << endl;
        cout << "qua:       " << t_qua << endl;
        cout << "bvh:       " << t_bvh << endl;
        cout << std::fixed << endl << t_vtk << " " << t_oct << " " << t_qua << " " << t_bvh << " | " << t_vtk/t_bvh << endl;
    }


    //*************************************************************************
    // [5] Finalize
    //*************************************************************************

    // Finalize
    MPI_Finalize();
    return 0;
}
