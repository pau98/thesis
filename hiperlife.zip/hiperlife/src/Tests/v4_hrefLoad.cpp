
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

int main()
{

    MPI_Init(nullptr, nullptr);


    //Load mesh
    RCP<MeshLoader> mesh = rcp(new MeshLoader);
    mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
    mesh->loadMesh("circle_n3.vtk", MeshType::Sequential);


    // Distribute meshes
    RCP<DistributedMesh> tensDisMesh = rcp(new DistributedMesh);
    tensDisMesh->setMesh(mesh);
    tensDisMesh->setBalanceMesh(true);
    tensDisMesh->Update();

    RCP<DistributedMesh> posDisMesh = rcp(new DistributedMesh);
    posDisMesh->setMeshRelation(MeshRelation::hRefin, tensDisMesh);
    posDisMesh->setHRefinement(1);
    posDisMesh->setBalanceMesh(true);
    posDisMesh->Update();

    posDisMesh->printFileLegacyVtk("test");

    MPI_Finalize();
}
