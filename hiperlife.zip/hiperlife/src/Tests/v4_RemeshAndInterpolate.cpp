
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>
#include "hl_Timer.h"
/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_BasicMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_PostProc.h"
#include "hl_VtkGrid.h"
#include <vtkPolyData.h>
#include <vtkPolyDataWriter.h>
#include <vtkPolyData.h>
#include <vtkPolyDataWriter.h>
#include <vtkCleanPolyData.h>
#include <vtkPolyDataWriter.h>
#include "hl_MeshLoader.h"
#include "hl_SurfLagrParam.h"
#include "hl_Remesher.h"
#include <fstream>
#include <string>
#include <iostream>



using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);
void combineGaussPts(RCP<UserStructure> userStr, RCP <DOFsHandler> dofHand);
void combineDOFs(RCP<UserStructure> userStr, RCP <DOFsHandler> dofHand);

double f(double x1,double x2, double x3)
{
    if (x3>0.0360 and x2>0.045)
         return 1.5E-7;
    else
        return 1E-6;
}

int main()
{

    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);
    int myRank, numProcs;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    MPI_Comm_size(MPI_COMM_WORLD, &numProcs);

    // Save the parameters into double data type variables
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(2);
    userStr->iparam.resize(5);
    userStr->iparam[1] = 0;
    userStr->iparam[3] = 0;
    userStr->u_aux.resize(0);
    userStr->bparam.resize(1);
    userStr->bparam[0]=false;
    int numIterRemesh = 3;
    double h = 0.01;
    string meshFile="../meshes/cell.vtk";


    // Generate mesh
    RCP<MeshLoader> mesh = rcp(new MeshLoader);
    mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    mesh->loadMesh(meshFile, MeshType::Parallel);

    // RCP<UnstructVtkMeshGenerator> mesh = rcp(new UnstructVtkMeshGenerator);
    // mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // mesh->genSphere([](double x[3]){return 0.005;});

    // Distribute mesh
    if (myRank==0) cout<<"Generate distributed  mesh"<<endl;
    RCP <DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    // Create DOFsHandler
    RCP <DOFsHandler> dofHand0 = rcp(new DOFsHandler(disMesh));
    dofHand0->setNameTag("dofHand");
    dofHand0->setDOFs({"partition"});
    dofHand0->Update();

    // Impose initial conditions
    for (int i=0; i < disMesh->loc_nPts(); i++)
    {
        double partition = disMesh->nodePartition(disMesh->_adjcyNE->globIdx(i));
        dofHand0->nodeDOFs->setValue("partition", i, IndexType::Local, partition);
    }
    dofHand0->UpdateGhosts();
    dofHand0->printFileLegacyVtk("oldMesh");


    // MPI_Finalize();
    // return 0;

    // Remesh
    RCP<Remesher> remesher = rcp(new Remesher);
    remesher->setDOFsHandler(dofHand0, {"partition"});
    remesher->setRemeshMethod(RemeshMethod::Serial, 1.E-1);
    // remesher->setRemeshMethod(RemeshMethod::Serial, f);
    remesher->setDefaultParameters();
    remesher->Update();
    remesher->newDOFsHands(dofHand0);
    dofHand0->printFileLegacyVtk("newMesh");

    MPI_Finalize();
    return 0;
}
