// C++ headers
#include <iostream>
#include <gmsh.h>

// hiperlife headers
#include "hl_Core.h"
#include "hl_TypeDefs.h"
#include "hl_UnstructGmshMeshGenerator.h"
#include "hl_DistributedMesh.h"

using namespace hiperlife;

void genEllipse()
{
    // Initialize
    namespace factory = gmsh::model::geo;
    gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

    // Parameters
    double a = 1;
    double b = 0.5;
    double lc = 0.05;

    // Add points
    factory::addPoint(-a, 0, 0, lc, 1); // 1 - left
    factory::addPoint(0, -b, 0, lc, 2); // 2 - bottom
    factory::addPoint(a, 0, 0, lc, 3);  // 3 - right
    factory::addPoint(0, b, 0, lc, 4);  // 4 - top
    factory::addPoint(0, 0, 0, lc, 5);  // 5 - center

    // Add arcs
    factory::addEllipseArc(1, 5, 1, 2, 1);
    factory::addEllipseArc(2, 5, 3, 3, 2);
    factory::addEllipseArc(3, 5, 3, 4, 3);
    factory::addEllipseArc(4, 5, 1, 1, 4);

    // Add curve
    factory::addCurveLoop({1,2,3,4}, 1);

    // Add surface
    factory::addPlaneSurface({1}, 1);
}

void gen2Circles()
{
    // Initialize
    namespace factory = gmsh::model::geo;
    // gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

    // Parameters
    double r = 0.1;
    double cx0 = 0.3;
    double cx1 = 0.7;
    double lc = 0.02;

    // Add points
    factory::addPoint(cx0-r, 0.5, 0, lc, 1);
    factory::addPoint(cx0, 0.5-r, 0, lc, 2);
    factory::addPoint(cx0+r, 0.5, 0, lc, 3);
    factory::addPoint(cx0, 0.5+r, 0, lc, 4);
    factory::addPoint(cx0, 0.5, 0, lc, 5);

    factory::addPoint(cx1-r, 0.5, 0, lc, 6);
    factory::addPoint(cx1, 0.5-r, 0, lc, 7);
    factory::addPoint(cx1+r, 0.5, 0, lc, 8);
    factory::addPoint(cx1, 0.5+r, 0, lc, 9);
    factory::addPoint(cx1, 0.5, 0, lc, 10);

    // Add arcs
    factory::addCircleArc(1, 5, 2, 1);
    factory::addCircleArc(2, 5, 3, 2);
    factory::addCircleArc(3, 5, 4, 3);
    factory::addCircleArc(4, 5, 1, 4);

    factory::addCircleArc(1+5, 5+5, 2+5, 5);
    factory::addCircleArc(2+5, 5+5, 3+5, 6);
    factory::addCircleArc(3+5, 5+5, 4+5, 7);
    factory::addCircleArc(4+5, 5+5, 1+5, 8);

    // Add curve
    factory::addCurveLoop({1,2,3,4}, 1);
    factory::addCurveLoop({5,6,7,8}, 2);

    // Add surface
    factory::addPlaneSurface({1}, 1);
    factory::addPlaneSurface({2}, 2);
}

int main(int argc, char **argv)
{
    hiperlife::Init(argc, argv);

    // genPoly given points
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genPoly given points." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        std::vector<double> x = {0.0, 1.0, 1.0, 0.0};
        std::vector<double> y = {0.0, 0.0, 1.0, 1.0};
        mesh->genPoly(x, y, 0.2);
        mesh->hRefine(1);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genPoly given file
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genPoly given file." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genPoly("../meshes/fish.csv", 0.2);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genRegularPoly
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genRegularPoly." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genRegularPoly(5, 2, 0.2);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genRectangle
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genRectangle." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genRectangle(1, 2, 0.1);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genCircle
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genCircle." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genCircle(1.5, 0.2);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genBSpline given points
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genBSpline given points." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        std::vector<double> x = {0.0, 1.0, 1.0, 0.0};
        std::vector<double> y = {0.0, 0.0, 1.0, 1.0};
        mesh->genBSpline(x, y, 0.2);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genBSpline given file
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genBSpline given file." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genBSpline("../meshes/fish.csv", 0.2);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genSphereTri
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genSphereTri." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genSphereTri(1.0, 0.1);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genSphereQua
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genSphereQua." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genSphereQua(1.0, 0.1);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genFreemesh
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genFreeMesh." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genFreeMesh(gen2Circles);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

    // genFreemesh with lambda
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genFreeMesh with lambda and parameters." << std::endl;


        // Define mesh as lambda function
        double a = 1;
        double b = 0.5;
        double lc = 0.05;

        auto genEllipseParams = [&a, &b, &lc]()
        {
            // Initialize
            namespace factory = gmsh::model::geo;
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Add points
            factory::addPoint(-a, 0, 0, lc, 1); // 1 - left
            factory::addPoint(0, -b, 0, lc, 2); // 2 - bottom
            factory::addPoint(a, 0, 0, lc, 3);  // 3 - right
            factory::addPoint(0, b, 0, lc, 4);  // 4 - top
            factory::addPoint(0, 0, 0, lc, 5);  // 5 - center

            // Add arcs
            factory::addEllipseArc(1, 5, 1, 2, 1);
            factory::addEllipseArc(2, 5, 3, 3, 2);
            factory::addEllipseArc(3, 5, 3, 4, 3);
            factory::addEllipseArc(4, 5, 1, 1, 4);

            // Add curve
            factory::addCurveLoop({1,2,3,4}, 1);

            // Add surface
            factory::addPlaneSurface({1}, 1);
        };

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genFreeMesh(genEllipseParams);
        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }

#ifdef HL_VTK
    // genRectangle with hrefinement
    try
    {
        if (VerboseRank())
            std::cout << "Testing UnstructGmshMeshGenerator: genRectangle and hRefine." << std::endl;

        SmartPtr<UnstructGmshMeshGenerator> mesh = Create<UnstructGmshMeshGenerator>();
        mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        mesh->genRectangle(1, 2, 0.1);
        mesh->hRefine(1);

        if (VerboseRank())
            std::cout << "   ** Test passed **" << std::endl;
    }
    catch (const std::exception& e)
    {
        if (VerboseRank())
            std::cout << "   ** Test failed **" << std::endl;
        hiperlife::Finalize();
        return 1;
    }
#endif

    hiperlife::Finalize();
    return 0;
}
