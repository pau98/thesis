
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_PredefinedElementFillings.h"
#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_TimeIterator.h"

#include "hl_FillStructure.h"
#include "hl_GlobalBasisFunctions.h"

using namespace std;
using Teuchos::rcp;
using Teuchos::RCP;
using namespace hiperlife;
using namespace hiperlife::Tensor;

int main()
{

    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//
    MPI_Init(nullptr, nullptr);

    // Put parameters in the user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->TransientDiffusion.source = [](double x, double y, double z){return x*x*10.0;};
    userStr->TransientDiffusion.diffusionCoefficient = 1.0;
    userStr->time.deltat = 1e-2;

    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    mesh->genStructMesh(5);

    // Distribute the mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // First one
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setDOFs({"u"});
    dofHand->setNodeAuxF({"b", "c"});
    dofHand->Update();

    // Second one
    RCP<DOFsHandler> dofHand2 = rcp(new DOFsHandler(disMesh));
    dofHand2->setNameTag("dofHand2");
    dofHand2->setDOFs({"a"});
    dofHand2->setNodeAuxF({"u"});
    dofHand2->Update();

    // Mirror fields
    dofHand2->nodeAuxF->mirrorField("u", dofHand->nodeDOFs);
    // dofHand2->nodeAuxF->mirrorFieldStructure(dofHand->nodeDOFs);

    // Boundary conditions
    dofHand->setInitialCondition("u", [](double x, double y){return x*x;});
    dofHand->setBoundaryCondition("u", MAxis::Xmin, 0.0);
    dofHand->setBoundaryCondition("u", MAxis::Xmax, 1.0);
    dofHand->UpdateGhosts();
    // dofHand2->UpdateGhosts();

    cout << *dofHand->nodeDOFs->_ghostsData << endl;
    cout << *dofHand2->nodeAuxF->_ghostsData << endl;
    dofHand->printFileVtk("dhand.0", true);
    dofHand2->printFileVtk("dhand2.0", true);

    // Boundary conditions
    dofHand->setInitialCondition("u", [](double x, double y){return x*x*x;});
    dofHand->UpdateGhosts();
    // dofHand2->UpdateGhosts();

    cout << *dofHand->nodeDOFs->_ghostsData << endl;
    cout << *dofHand2->nodeAuxF->_ghostsData << endl;
    dofHand->printFileVtk("dhand.1", true);
    dofHand2->printFileVtk("dhand2.1", true);

    // cout << dofHand->nodeDOFs->_ghostsData << endl << dofHand2->nodeAuxF->_ghostsData << endl << dofHand2->nodeAuxF->_tmp_ghostsData << endl;

    // MPI_Finalize();
    // return 0;

    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // hiperproblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setElementFillings("Integ", PredefinedElementFillings::TransientDiffusion);
    hiperProbl->setCubatureGauss("Integ", 4);
    hiperProbl->Update();

    // cout << dofHand->nodeDOFs->_ghostsData << endl << dofHand2->nodeAuxF->_ghostsData << endl << dofHand2->nodeAuxF->_tmp_ghostsData << endl;

    // dofHand2->nodeAuxF->mirrorField("u", dofHand->nodeDOFs);
    cout << *dofHand->nodeDOFs->_ghostsData << endl;
    cout << *dofHand2->nodeAuxF->_ghostsData << endl;
    dofHand->printFileVtk("dhand.2", true);
    dofHand2->printFileVtk("dhand2.2", true);


    // MPI_Finalize();
    // return 0;

    // Linear solver
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    cout << *dofHand->nodeDOFs->_ghostsData << endl;
    cout << *dofHand2->nodeAuxF->_ghostsData << endl;
    dofHand->printFileVtk("dhand.3", true);
    dofHand2->printFileVtk("dhand2.3", true);

    linSolver->solve();
    linSolver->UpdateSolution();

    cout << *dofHand->nodeDOFs->_ghostsData << endl;
    cout << *dofHand2->nodeAuxF->_ghostsData << endl;
    dofHand->printFileVtk("dhand.4", true);
    dofHand2->printFileVtk("dhand2.4", true);


    // MPI_Finalize();
    // return 0;

    // Time iterator
    RCP<TimeIterator> tIterator = rcp(new TimeIterator);
    tIterator->setLinearSolver(linSolver);
    tIterator->setTimeStepSize(1e-1);
    tIterator->setStopCriteria(20, 1e3, 1e-12);
    tIterator->setTimeSteppingScheme(TimeSteppingScheme::AdaptiveLinear);
    tIterator->setLinearStepFactor(1.01, 0.5);
    tIterator->setMaximumTimeStepSize(0.1);
    // tIterator->setPrintToFile(PrintToFileMethod::Vtk, 1, "predElemFill");
    // tIterator->setPrintRestart(10, "restart");
    tIterator->setPostprocess(1, [=](){
                                     cout << *dofHand->nodeDOFs0->_ghostsData << endl;
                                     cout << *dofHand2->nodeAuxF->_ghostsData << endl;
                                     dofHand->printFileVtk("dhand." + to_string(tIterator->timeStep()+5), true);
                                     dofHand2->printFileVtk("dhand2." + to_string(tIterator->timeStep()+5), true);
                                 });
    tIterator->Update();


    // **************************************************************//
    // *****                       SOLVE                        *****//
    // **************************************************************//

    tIterator->Iterate();

    // **************************************************************//
    // *****                      FINALIZE                      *****//
    // **************************************************************//


    MPI_Finalize();
    return 0;
}
