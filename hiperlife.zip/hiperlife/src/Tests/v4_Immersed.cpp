/// C++ headers
#include <iostream>
#include <mpi.h>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// HiPerLiFE headers
#include "hl_TypeDefs.h"
#include "hl_DistributedData.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_MeshMap.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


void immLS_backBulk(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void immLS_backBorder(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void immLS_backBorder2(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void immLS_imm(Teuchos::RCP<hiperlife::FillStructure> fillStr);

void bfitLS(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void bfitBorder(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void bounLS(Teuchos::RCP<hiperlife::FillStructure> fillStr);

void postproces(Teuchos::RCP<hiperlife::DOFsHandler> dhand, int nx, int ny);


int main()
{

    MPI_Init(nullptr, nullptr);

    //========================== User Structure ==========================//
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = 0.0;

    //============================ Parameters ============================//
    int nx = 10;
    int ny = 10;

    // *******************************************************************//
    // *****                      MESH CREATION                      *****//
    // *******************************************************************//

    //-------------------------- Background mesh -------------------------//
    //Mesh generator
    RCP<StructMeshGenerator> back = rcp(new StructMeshGenerator);
    back->setMesh(ElemType::Square, BasisFuncType::BSplines, 1);
    back->genStructMesh(nx, ny);
    // back.translate(-0.5, -0.5, 0.0);
    // back->genRectangle(nx, ny/2, 1.0, 0.5);

    //Distributed mesh
    RCP<DistributedMesh> backMesh = rcp(new DistributedMesh);
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->Update();
    // backMesh->printFileLegacyVtk("meshBack");

    //--------------------------- Immersed mesh --------------------------//
    //Mesh generator
    RCP<StructMeshGenerator> imm = rcp(new StructMeshGenerator);
    imm->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    // imm->genLine(nx, {0.0, 0.7, 0.0}, {1.0, 0.7, 0.0});
    imm->genCircle(nx*4, 0.38);
    imm->translate(0.5, 0.5, 0.0);
    // imm->genPolygonalCurve("../meshes/fish.csv", true);
    // imm->scale(0.4);
    // imm->translate(0.5, 0.51, 0.0);
    // imm->genPolygonalCurve("../meshes/violin.csv", true);
    // imm->scale(0.91);
    // imm->translate(0.5, 0.5, 0.0);
    // imm->genCircularArc(nx*4, 0.38, 1.999*M_PI);
    // imm->scaleY(0.8);
    // imm->translate(0.5, 0.5, 0.0);
    // imm->genCircle(nx, 1.0);
    // imm->transformFree([](double x, double z){
    //         double a = 0.7;
    //         double c = sqrt(1.0-a*a);
    //         double t = sqrt(c*c*c*c + 4.0*a*a*x*x) - a*a - x*x;
    //         if (t < 0)
    //             t = -t;
    //         double zz;
    //         if (z > 0)
    //             zz = sqrt(t);
    //         else
    //             zz = - sqrt(t);
    //         return std::make_tuple(x, zz);
    //     });
    // imm->scale(0.3925);
    // imm->translate(0.5, 0.5, 0.0);

    //Distributed mesh
    RCP<DistributedMesh> immMesh = rcp(new DistributedMesh);
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::Immersed, backMesh);
    immMesh->setImmersedInteriorPoints({{0.5, 0.5, 0.0}});
    immMesh->setBalanceMesh(true);
    immMesh->Update();
    immMesh->printFileLegacyVtk("meshImm");

    backMesh->printFileLegacyVtk("meshBack");




    // cout << *immMesh->_mapToParent << endl;
    // cout << *backMesh->_mapToChild << endl;
    // MPI_Finalize();
    // return 0;

    //------------------------- Body-fitted mesh -------------------------//
    //Mesh generator
    RCP<StructMeshGenerator> bfit = rcp(new StructMeshGenerator);
    bfit->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    bfit->genStructMesh(nx, ny);
    DistributedData disPts;
    disPts.setLocNItem(0);
    disPts.setNItem(bfit->_nPts);
    disPts.Update();
    for (int i = 0; i < bfit->_nEx*bfit->_bfOrder+2; i++)
    {
        int ii = (bfit->_nEx*bfit->_bfOrder+1)*(bfit->_nEy*bfit->_bfOrder+1) - i;
        if (disPts.isItemInPart(ii))
        {
            int iiloc = disPts.locIdx(ii);
            bfit->_x_nodes[bfit->_loc_nPts * 1 + iiloc] = 0.975;
        }
    }

    //Distributed mesh
    RCP<DistributedMesh> bfitMesh = rcp(new DistributedMesh);
    bfitMesh->setMesh(bfit);
    bfitMesh->setBalanceMesh(true);
    bfitMesh->Update();
    bfitMesh->printFileLegacyVtk("meshBfit");


    // *******************************************************************//
    // *****                   DOFsHandler CREATION                  *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    RCP<DOFsHandler> backDHand = rcp(new DOFsHandler(backMesh));
    backDHand->setNameTag("backDHand");
    backDHand->setNumDOFs(1);
    backDHand->setNumNodeAuxF(1);
    backDHand->setNumElemAuxF(1);
    backDHand->Update();
    backDHand->setConstraint(0, 0.0);
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
        if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local) != 0)
        {
            vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
            for (auto n: nbors)
            {
                if (backDHand->mesh->isNodeInPart(n))
                {
                    // double x = backDHand->mesh->nodeCoord(n, 0, IndexType::Local);
                    // double y = backDHand->mesh->nodeCoord(n, 1, IndexType::Local);
                    // if (y < 0.01)
                    //     backDHand->setConstraint(0, n, IndexType::Local, 2.0);
                    // else
                        backDHand->removeConstraint(0, n, IndexType::Global);
                        backDHand->nodeAuxF->setValue(0, n, IndexType::Global, 1.0);
                }
            }
        }
    }
    // for (int i = 0; i < backDHand->mesh->loc_nPts(); i++)
    // {
    //      backDHand->nodeAuxF->setValue(0, i, IndexType::Local, backDHand->mesh->_nodeFlags->getValue(2, i, IndexType::Local));
    // }
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
         backDHand->elemAuxF->setValue(0, e, IndexType::Local, backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local));
    }
    backDHand->UpdateGhosts();
    backDHand->printFileLegacyVtk("dofBack", true);

    //------------------------ Immersed DOFsHandler ----------------------//
    RCP<DOFsHandler> immDHand = rcp(new DOFsHandler(immMesh));
    immDHand->setNameTag("immDHand");
    immDHand->setNumDOFs(1);
    immDHand->Update();
    for (int i = 0; i < immDHand->mesh->loc_nPts(); i++)
    {
        double x = immDHand->mesh->nodeCoord(i, 0, IndexType::Local);
        double y = immDHand->mesh->nodeCoord(i, 1, IndexType::Local);
        immDHand->nodeDOFs->setValue(0, i, IndexType::Local, sqrt(x*x+y*y));
    }
    // immDHand->setBoundaryCondition(0, MAxis::Xmin, 0.0);
    // immDHand->setBoundaryCondition(0, MAxis::Xmax, 0.0);
    // immDHand->UpdateGhosts();
    immDHand->printFileLegacyVtk("dofImm");

    //---------------------- Body-fitted DOFsHandler ---------------------//
    RCP<DOFsHandler> bfitDHand = rcp(new DOFsHandler(bfitMesh));
    bfitDHand->setNameTag("bfitDHand");
    bfitDHand->setNumDOFs(1);
    bfitDHand->Update();
    // bfitDHand->setBoundaryCondition(0, MAxis::Xmin, [](double y){return (y-0.5)*(y-0.5);});
    // bfitDHand->setBoundaryCondition(0, MAxis::Xmax, 0.0);
    bfitDHand->setBoundaryCondition(0, MAxis::Ymin, 1.0);
    // bfitDHand->setBoundaryCondition(0, MAxis::Ymax, [](double x, double y){return sqrt(x*x+y*y);});
    bfitDHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});
    bfitDHand->UpdateGhosts();
    bfitDHand->printFileLegacyVtk("dofBfit");

    // postproces(backDHand);


    // MPI_Finalize();
    // return 0;


    // *******************************************************************//
    // *****                    IMMERSED2 PROBLEM                    *****//
    // *******************************************************************//
    if (false)
    {
        //------------------------ Immersed2 HiPerProblem --------------------//
        // Immersed HiPerProblem
        RCP<HiPerProblem> immHP2 = rcp(new HiPerProblem);
        //General setters
        immHP2->setUserStructure(userStr);
        immHP2->setGlobalIntegrals({"Area", "BorderLength"});

        //Set DOFsHandlers
        immHP2->setDOFsHandlers({backDHand, immDHand});

        //Set integration for the background mesh
        immHP2->setIntegration("Integ", {"backDHand"});
        immHP2->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
        immHP2->setElementFillings("Integ", immLS_backBulk);

        //Set integration for the immersed mesh
        immHP2->setIntegration("IntegImmersedMesh", {"immDHand"});
        immHP2->setCubatureGauss("IntegImmersedMesh", 3);
        immHP2->setElementFillings("IntegImmersedMesh", immLS_imm);

        //Set integration for the border
        immHP2->setIntegration("IntegBorder", {"backDHand", "immDHand"});
        immHP2->setCubatureBorderImmersed("IntegBorder", 3);
        immHP2->setElementFillings("IntegBorder", immLS_backBorder2);

        //Update
        immHP2->Update();

        //Clear file
        ofstream myfile;
        myfile.open("cubature."+to_string(immHP2->myRank())+".csv", std::ofstream::out | std::ofstream::trunc);
        myfile.close();

        // immHP2->FillLinearSystem();
        // ofstream ofiletxt2("matrix2." + to_string(immHP2->myRank()) + ".txt");
        // ofiletxt2 << *immHP2->A << endl;
        // ofiletxt2.close();

        //-------------------------- Immersed solver -------------------------//
        RCP<Amesos2DirectLinearSolver> immSOL2 = rcp(new Amesos2DirectLinearSolver());
        immSOL2->setHiPerProblem(immHP2);
        immSOL2->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
        immSOL2->setNumericFactorization(true);
        immSOL2->setSymbolicFactorization(true);
        immSOL2->Update();

        //---------------------------- Solve immersed ------------------------//
        immHP2->FillLinearSystem();
        myfile.open("cubature."+to_string(immHP2->myRank())+".csv", std::ofstream::out | std::ofstream::trunc);
        myfile.close();
        immSOL2->solve();
        //immSOL2->output();
        immSOL2->UpdateSolution();
        backDHand->printFileLegacyVtk("solBack2", true);
        immDHand->printFileLegacyVtk("solImm2", true);

        if (immDHand->myRank() == 0)
        {
            cout << std::setprecision(16) << "Area = " << immHP2->globalIntegral("Area") << endl;
            cout << std::setprecision(16) << "BorderLength = " << immHP2->globalIntegral("BorderLength") << endl;
        }
    }

    // *******************************************************************//
    // *****                    IMMERSED PROBLEM                     *****//
    // *******************************************************************//
    if (true)
    {
        // Immersed HiPerProblem
        RCP<HiPerProblem> immHP = rcp(new HiPerProblem);
        //Set userStr
        immHP->setUserStructure(userStr);
        //Set dofhandlers
        immHP->setDOFsHandlers({backDHand});
        //Set integration for the background mesh
        immHP->setIntegration("Integ", {"backDHand"});
        immHP->setCubatureCutCellNonConforming("Integ", 9, 1, 5);
        immHP->setElementFillings("Integ", immLS_backBulk);
        //Set integration for the border only
        immHP->setIntegration("IntegBorder", {"backDHand"});
        immHP->setCubatureBorderImmersed("IntegBorder", 7);
        immHP->setElementFillings("IntegBorder", immLS_backBorder);
        //Global integrals
        immHP->setGlobalIntegrals({"Area", "BorderLength"});
        //Update
        immHP->Update();

        // immHP->FillLinearSystem();
        // ofstream ofiletxt("matrix." + to_string(immHP->myRank()) + ".txt");
        // ofiletxt << *immHP->A << endl;
        // ofiletxt.close();


        // //Fill system to write cubature
        // immHP->FillLinearSystem();
        // MPI_Finalize();
        // return 0;

        //-------------------------- Immersed solver -------------------------//
        // RCP<Amesos2DirectLinearSolver> immSOL = rcp(new Amesos2DirectLinearSolver());
        // immSOL->setHiPerProblem(immHP);
        // immSOL->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
        // immSOL->setNumericFactorization(true);
        // immSOL->setSymbolicFactorization(true);
        // immSOL->Update();

        RCP<MUMPSDirectLinearSolver> immSOL = rcp(new MUMPSDirectLinearSolver());
        immSOL->setHiPerProblem(immHP);
        // solver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
        // solver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Parallel);
        // solver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
        immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
        immSOL->setDefaultParameters();
        immSOL->Update();

        //---------------------------- Solve immersed ------------------------//
        // immHP->FillLinearSystem();
        ofstream myfile;
        myfile.open("cubature."+to_string(immHP->myRank())+".csv", std::ofstream::out | std::ofstream::trunc);
        myfile.close();
        immSOL->solve();
        //immSOL->output();
        immSOL->UpdateSolution();
        backDHand->printFileLegacyVtk("solBack", true);
        immDHand->printFileLegacyVtk("solImm", true);

        if (immDHand->myRank() == 0)
        {
            cout << std::setprecision(16) << "Area = " << immHP->globalIntegral("Area") << endl;
            cout << std::setprecision(16) << "BorderLength = " << immHP->globalIntegral("BorderLength") << endl;
        }

        // postproces(backDHand, nx, ny);
    }

    // *******************************************************************//
    // *****                   BODY-FITTED PROBLEM                   *****//
    // *******************************************************************//
    if (false)
    {
        //---------------------- Body-fitted HiPerProblem --------------------//
        RCP<HiPerProblem> bfitHP = rcp(new HiPerProblem);
        //Set userStr
        bfitHP->setUserStructure(userStr);
        //Set dofhandler
        bfitHP->setDOFsHandlers({bfitDHand});
        //Set integrations
        bfitHP->setIntegration("Integ", {"bfitDHand"});
        bfitHP->setCubatureGauss("Integ", 4);
        bfitHP->setElementFillings("Integ", bfitLS);
        // bfitHP->setIntegration("BorderInteg", {"bfitDHand"});
        // bfitHP->setCubatureBorderGauss("BorderInteg", 4);
        // bfitHP->setElementFillings("BorderInteg", nullptr, nullptr, bfitBorder);
        //Set global integrals
        bfitHP->setGlobalIntegrals({"Area", "BorderLength"});
        //Update
        bfitHP->Update();

        // //Fill system to write cubature
        // bfitHP->FillLinearSystem();


        // MPI_Finalize();
        // return 0;

        //------------------------- Body-fitted Solver -----------------------//
        RCP<Amesos2DirectLinearSolver> bfitSOL = rcp(new Amesos2DirectLinearSolver());
        bfitSOL->setHiPerProblem(bfitHP);
        bfitSOL->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
        bfitSOL->setNumericFactorization(true);
        bfitSOL->setSymbolicFactorization(true);
        bfitSOL->Update();

        //-------------------------- Solve body-fitted -----------------------//
        bfitHP->FillLinearSystem();
        bfitSOL->solve();
        //bfitSOL->output();
        bfitSOL->UpdateSolution();
        bfitDHand->printFileLegacyVtk("solBfit");

        if (bfitDHand->myRank() == 0)
        {
            cout << std::setprecision(16) << "Area = " << bfitHP->globalIntegral("Area") << endl;
            cout << std::setprecision(16) << "BorderLength = " << bfitHP->globalIntegral("BorderLength") << endl;
        }

    }

    // *******************************************************************//
    // *****                    BOUNDARY PROBLEM                     *****//
    // *******************************************************************//
    if (false)
    {
        //----------------------- Boundary HiPerProblem ---------------------//
        RCP<HiPerProblem> bounHP = rcp(new HiPerProblem);
        //Set userStr
        bounHP->setUserStructure(userStr);
        //Set dofhandler
        bounHP->setDOFsHandlers({immDHand});
        //Set integrations
        bounHP->setIntegration("Integ", {"immDHand"});
        bounHP->setCubatureGauss("Integ", 3);
        bounHP->setElementFillings("Integ", bounLS);
        //Set global integrals
        bounHP->setGlobalIntegrals({"Area", "BorderLength"});
        //Update
        bounHP->Update();

        //-------------------------- Boundary Solver ------------------------//
        RCP<Amesos2DirectLinearSolver> bounSOL = rcp(new Amesos2DirectLinearSolver());
        bounSOL->setHiPerProblem(bounHP);
        bounSOL->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
        bounSOL->setNumericFactorization(true);
        bounSOL->setSymbolicFactorization(true);
        bounSOL->Update();

        //--------------------------- Solve boundary ------------------------//
        bounHP->FillLinearSystem();
        bounSOL->solve();
        //bounSOL->output();
        bounSOL->UpdateSolution();
        immDHand->printFileLegacyVtk("solBoun");

        if (immDHand->myRank() == 0)
        {
            cout << std::setprecision(16) << "Area = " << bounHP->globalIntegral("Area") << endl;
            cout << std::setprecision(16) << "BorderLength = " << bounHP->globalIntegral("BorderLength") << endl;
        }
    }

    MPI_Finalize();
    return 0;
}


void immLS_backBulk(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    double diff = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        // Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * bf[i] * diff;
    }

    fillStr->addToGlobalIntegral("Area", jac);


    return;
}

void immLS_backBorder(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = (*fillStr)["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    //Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
    jac = Math::Norm3D(t.data());

    //Compute unitary normal
    vector<double> n(3, 0.0);
    n[0] = t[1]/jac;
    n[1] = -t[0]/jac;

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << " " << n[0] << " " << n[1] << endl;
    myfile.close();

    double val = sqrt(x[0]*x[0]+x[1]*x[1]); // 0.0; //x[0]*x[0]; //

    //Penalty
    if (false)
    {
        double beta = 5000.0;
        for (int i = 0; i < eNN; i++)
        {
            for (int j = 0; j < eNN; j++)
            {
                /// Fill matrix
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * beta * bf[i] * bf[j];
            }
            //Fill vector
            fillStr->Bk(0)[i*DOF] += jac * beta * bf[i] * val;
        }
    }

    //Nitsche symmetric
    if (false)
    {
        double beta = 50.0;
        for (int i = 0; i < eNN; i++)
        {
            double dbfnI{};
            for (int d = 0; d < pDim; d++)
                dbfnI += dbf[pDim*i+d]*n[d];
            for (int j = 0; j < eNN; j++)
            {
                double dbfnJ{};
                for (int d = 0; d < pDim; d++)
                    dbfnJ += dbf[pDim*j+d]*n[d];

                /// Fill matrix
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * beta * bf[i] * bf[j];
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += - jac * bf[i] * dbfnJ;
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += - jac * bf[j] * dbfnI;
            }
            //Fill vector
            fillStr->Bk(0)[i*DOF] += jac * beta * bf[i] * val;
            fillStr->Bk(0)[i*DOF] += - jac * dbfnI * val;
        }

    }

    //Nitsche non-symmetric
    if (true)
    {
        for (int i = 0; i < eNN; i++)
        {
            double dbfnI{};
            for (int d = 0; d < pDim; d++)
                dbfnI += dbf[pDim*i+d]*n[d];

            for (int j = 0; j < eNN; j++)
            {
                double dbfnJ{};
                for (int d = 0; d < pDim; d++)
                    dbfnJ += dbf[pDim*j+d]*n[d];

                /// Fill matrix
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += - jac * bf[i] * dbfnJ;
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * bf[j] * dbfnI;
            }
            //Fill vector
            fillStr->Bk(0)[i*DOF] += jac * dbfnI * val;
        }
    }

    fillStr->addToGlobalIntegral("BorderLength", jac);

    return;
}

void immLS_backBorder2(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    //Background
    SubFillStructure& subFill = (*fillStr)["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    //Immersed
    SubFillStructure& i_subFill = (*fillStr)["immDHand"];
    int i_DOF  = i_subFill.numDOFs;       // Number of neighbor nodes
    int i_eNN  = i_subFill.eNN;       // Number of neighbor nodes
    int i_nDim = i_subFill.nDim;      // Number of spatial dimensions
    int i_pDim = i_subFill.pDim;      // Number of parametric dimension
    vector<double>& i_coords   = i_subFill.nborCoords;  // Vector of node coordinates
    double* i_bf  = i_subFill.nborBFsDers(0);   // Local shape function
    double* i_dbf_l = i_subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> i_dbf(i_eNN*i_pDim);
    double i_jac;
    GlobalBasisFunctions::gradients(i_dbf.data(), i_jac, i_subFill);

    ///===================== Values at int. points ====================///
    //Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
    jac = Math::Norm3D(t.data());

    //Compute unitary normal
    vector<double> n(3, 0.0);
    n[0] = t[1]/jac;
    n[1] = -t[0]/jac;

    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    vector<double> i_x(i_nDim);
    for (int i = 0; i < i_eNN; i++)
    {
        for (int d = 0; d < i_nDim; d++)
            i_x[d] += i_coords[i_nDim*i+d] * i_bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << " " << subFill.elemID << " " << i_subFill.elemID << endl;
    myfile << std::setprecision(16) << i_x[0] << " " << i_x[1] << " " << 1 << " " << subFill.elemID << " " << i_subFill.elemID << endl;
    myfile.close();

    // cout << subFill.elemID << ", " << subFill.kPt << " -> " <<  i_subFill.elemID << " | " << subFill.idxCuba << endl;
    // cout << subFill.elemID << " " << i_subFill.elemID << endl;
    // cout << std::setprecision(16) << x[0] << " " << x[1] << " " << i_x[0] << " " << i_x[1] << " " << jac << " " << i_jac << endl;


    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        double dbfnI{};
        for (int d = 0; d < pDim; d++)
            dbfnI += dbf[pDim*i+d]*n[d];

        for (int j = 0; j < eNN; j++)
        {
            double dbfnJ{};
            for (int d = 0; d < pDim; d++)
                dbfnJ += dbf[pDim*j+d]*n[d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += - jac * bf[i] * dbfnJ;
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * bf[j] * dbfnI;
        }
    }

    for (int i = 0; i < eNN; i++)
    {
        double dbfnI{};
        for (int d = 0; d < pDim; d++)
            dbfnI += dbf[pDim*i+d]*n[d];

        for (int j = 0; j < i_eNN; j++)
        {
            /// Fill matrix
            fillStr->Ak(0, 1)[i*DOF*i_eNN+j*i_DOF] += - jac * i_bf[j] * dbfnI;
        }
    }

    fillStr->addToGlobalIntegral("BorderLength", jac);

    return;
}

void immLS_imm(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    // double diff = fillStr->userStr->dparam[0];
    double diff = 1.0;
    SubFillStructure& subFill = (*fillStr)["immDHand"];
    /// which we use to declare the variables:
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);
    if (jac < 0) //FIXME
        jac = -jac;

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            // Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        // Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * bf[i] * diff*(x[1]-0.5);
    }


    return;
}


void bfitLS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    double diff = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["bfitDHand"];
    /// which we use to declare the variables:
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);


    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            // Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        // Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * bf[i] * diff;
    }


    return;
}

void bfitBorder(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    ///===========          Initialize variables           ==========///
    // double diff = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["bfitDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimensions
    vector<double>& coords = subFill.nborCoords;  // Vector of node coordinates
    vector<double>& ue_nodes = subFill.nborDOFs;
    double *bf  = subFill.nborBFsDers(0);   // Local shape function
    double *dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives

    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    // Computing Tangent Map
    double Ip[4], xu[3], xv[3];
    SurfLagrParam::MetricTensor(Ip, xu, xv, eNN, coords.data(), dbf_l);
    auto bTangentRef = subFill.tangentsBoundaryRef();
    double bTangent[3]={};
    for (int n = 0; n < nDim; n++)
        bTangent[n] = bTangentRef[0] * xu[n] + bTangentRef[1] * xv[n];
    jac = Math::Norm3D(bTangent);

    //Outward unitary normal
    vector<double> n(3,0);
    n[0] = bTangent[1]/jac;
    n[1] = -bTangent[0]/jac;

    //Values at integration points
    double x[3]={}, u{};
    for (int i = 0; i < eNN; i++)
    {
        u += ue_nodes[DOF*i+0] * bf[i];
        for ( int n = 0; n < nDim; n++ )
            x[n] += coords[i*nDim+n] * bf[i];
    }

    //Neumann
    if (false)
    {
        for (int i = 0; i < eNN; i++)
            fillStr->Bk(0)[i*DOF] += -jac * bf[i];
    }

    //Penalty
    if (false)
    {
        double beta = 500.0;
        for (int i = 0; i < eNN; i++)
        {
            for (int j = 0; j < eNN; j++)
            {
                /// Fill matrix
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * beta * bf[i] * bf[j];
            }
            //Fill vector
            fillStr->Bk(0)[i*DOF] += jac * beta * bf[i] * 0.0;
        }
    }

    //Nitsche symmetric
    if (false)
    {
        double beta = 50.0;
        for (int i = 0; i < eNN; i++)
        {
            double dbfnI{};
            for (int d = 0; d < pDim; d++)
                dbfnI += dbf[pDim*i+d]*n[d];
            for (int j = 0; j < eNN; j++)
            {
                double dbfnJ{};
                for (int d = 0; d < pDim; d++)
                    dbfnJ += dbf[pDim*j+d]*n[d];

                /// Fill matrix
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * beta * bf[i] * bf[j];
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += - jac * bf[i] * dbfnJ;
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += - jac * bf[j] * dbfnI;
            }
            //Fill vector
            fillStr->Bk(0)[i*DOF] += jac * beta * bf[i] * 0.0;
            fillStr->Bk(0)[i*DOF] += - jac * dbfnI * 0.0;
        }

    }

    //Nitsche non-symmetric
    if (true)
    {
        for (int i = 0; i < eNN; i++)
        {
            double dbfnI{};
            for (int d = 0; d < pDim; d++)
                dbfnI += dbf[pDim*i+d]*n[d];

            for (int j = 0; j < eNN; j++)
            {
                double dbfnJ{};
                for (int d = 0; d < pDim; d++)
                    dbfnJ += dbf[pDim*j+d]*n[d];

                /// Fill matrix
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += - jac * bf[i] * dbfnJ;
                fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * bf[j] * dbfnI;
            }
            //Fill vector
            fillStr->Bk(0)[i*DOF] += jac * dbfnI * 0.0;
        }
    }

    fillStr->addToGlobalIntegral("BorderLength", jac);

    return;
}


void bounLS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{

    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    // double diff = fillStr->userStr->dparam[0];
    double diff = 1.0;
    SubFillStructure& subFill = (*fillStr)["immDHand"];
    /// which we use to declare the variables:
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);
    if (jac < 0) //FIXME
        jac = -jac;

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            // Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        // Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * bf[i] * diff*(x[1]-0.5);
    }

    fillStr->addToGlobalIntegral("BorderLength", jac);

    return;
}


void postproces(Teuchos::RCP<hiperlife::DOFsHandler> dhand, int nx, int ny)
{
    cout << "Post processing" << endl;
    auto backMesh = dhand->mesh;

    RCP<StructMeshGenerator> pBack = rcp(new StructMeshGenerator);
    pBack->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    pBack->genStructMesh(8*nx, 8*ny);

    RCP<DistributedMesh> pMesh = rcp(new DistributedMesh);
    pMesh->setMesh(pBack);
    pMesh->setBalanceMesh(true);
    pMesh->Update();
    pMesh->printFileLegacyVtk("pMesh");

    RCP<DOFsHandler> pDHand = rcp(new DOFsHandler(pMesh));
    pDHand->setNameTag("pDHand");
    pDHand->setNumDOFs(1);
    pDHand->Update();


    for (int nbor = 0; nbor < pMesh->loc_nPts(); nbor++)
    {
        //Get coordinates of the nodes
        vector<double> iC = pMesh->nodeCoords(nbor, IndexType::Local);

        //Check if node is on the right or top boundary
        bool boundX{false};
        if (pMesh->isNodeInMAxis(MAxis::Xmax, nbor, IndexType::Local))
            boundX = true;
        bool boundY{false};
        if (pMesh->isNodeInMAxis(MAxis::Ymax, nbor, IndexType::Local))
            boundY = true;

        //Get background element (super inefficient way)
        for (int elem = 0; elem < backMesh->loc_nElem(); elem++)
        {
            //Get background element corners
            vector<int> corners = backMesh->getElemCorners(elem, IndexType::Local);
            vector<vector<double>> cCoords(corners.size(), vector<double>(backMesh->nDim()));
            for (size_t c = 0; c < corners.size(); c++)
            {
                for (int d = 0; d < backMesh->nDim(); d++)
                    cCoords[c][d] += backMesh->nodeCoord(corners[c], d);
            }

            //Check if the point is in the background element
            if ((iC[0] >= cCoords[0][0] and iC[0] < cCoords[3][0] and
                 iC[1] >= cCoords[0][1] and iC[1] < cCoords[3][1]) or
                (iC[0] == cCoords[3][0] and boundX == true and
                 iC[1] >= cCoords[0][1] and iC[1] < cCoords[3][1]) or
                (iC[0] >= cCoords[0][0] and iC[0] < cCoords[3][0] and
                 iC[1] == cCoords[3][1] and boundY == true) or
                (iC[0] == cCoords[3][0] and boundX == true and
                 iC[1] == cCoords[3][1] and boundY == true)
                )
            {
                //Get coordinates in the ref element
                double sidex = cCoords[3][0] - cCoords[0][0];
                double sidey = cCoords[3][1] - cCoords[0][1];
                vector<double> xSamples;
                xSamples.push_back((iC[0]-cCoords[0][0]-sidex/2.0)/sidex*2.0);
                xSamples.push_back((iC[1]-cCoords[0][1]-sidey/2.0)/sidey*2.0);

                //Compute bf at point
                vector<vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xSamples, backMesh->_basisFunctions->getTag(elem, IndexType::Local));

                //Compute values at point
                double val{};
                int eNN = backMesh->_connec->getNumNbors(elem, IndexType::Local);
                for (int j = 0; j < eNN; j++)
                {
                    int bNbor = backMesh->_connec->getNbor(elem, j);
                    val += dhand->nodeDOFs->getValue(0, bNbor)*bf[0][j];
                }

                pDHand->nodeDOFs->setValue(0, nbor, IndexType::Local, val);


                break;
            }
        }
    }


    pDHand->printFileLegacyVtk("sol_imm_p");

}
