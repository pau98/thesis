#include <iostream>
#include <mpi.h>

#include <unistd.h> //FIXME sleep function

#include <AztecOO.h>

#include "hl_DistributedClass.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_Math.h"
#include "hl_LoadMesh.h"
#include "hl_FillStructure.h"
#include "hl_HiPerProblem.h"
#include "hl_Timer.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void SM_E (RCP<hiperlife::FillStructure> fillStr);
void RHS_B_E(RCP<hiperlife::FillStructure> fillStr);

int main(int argc, char **argv)
{

    MPI_Init(nullptr, nullptr);

    Timer timer({"meshGen", "init", "ghosts", "filling", "solver", "print", "printLeg"});

    // Creating Distributed Mesh
    int nx;
    int order = 1;
    if (argc == 1)
        nx = 5;
    else
        nx= stoi(argv[1]);
    int nDim = 3;

    timer.start("meshGen");
    RCP<StructMeshGenerator> meshGen = rcp(new StructMeshGenerator);
    meshGen->setNDim(nDim);
    meshGen->setElemType(ElemType::Parallelep);
    meshGen->setBasisFuncType(BasisFuncType::Lagrangian);
    meshGen->setBasisFuncOrder(order);
    meshGen->genStructMesh(nx, nx, nx);
    timer.end("meshGen");


    timer.start("init");
    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    try
    {
        disMesh->setMesh(meshGen);
        disMesh->setBalanceMesh(false);
        disMesh->Update();

        cout << disMesh->myRank() << ":   Distributed Mesh successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << disMesh->myRank() << ":   Distributed Mesh could not be created. " << err.what() << endl;

        MPI_Finalize();
        return 0;
    }

    disMesh->printFileLegacyVtk("mesh.vtk");

    //Create dhandanics
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    try
    {
        dhand->setDOFs({"Temp"});
        dhand->Update();

        cout << dhand->myRank() << ":   DOFsHandler succesfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << dhand->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;

        MPI_Finalize();
        return 0;
    }
    timer.end("init");


    dhand->setBoundaryCondition(0,MAxis::Xmin,1.0);
    dhand->setBoundaryCondition(0,MAxis::Xmax,1.0);
    dhand->setBoundaryCondition(0,MAxis::Ymin,1.0);
    dhand->setBoundaryCondition(0,MAxis::Ymax,1.0);
    dhand->setBoundaryCondition(0,MAxis::Zmin,1.0);


    //Create hiperdhandanics
    RCP<HiPerProblem> hiperMech = rcp(new HiPerProblem("HiperMech"));

    hiperMech->setDOFsHandlers({dhand});

    hiperMech->setIntegration("IntegHE", {"dhand"});
    hiperMech->setIntegration("Border", {"dhand"});

    hiperMech->setCubatureGauss("IntegHE",  8);
    hiperMech->setElementFillings("IntegHE", nullptr, SM_E, nullptr);

    hiperMech->setCubatureBorderGauss("Border", 1);
    hiperMech->setElementFillings("Border", nullptr, nullptr, RHS_B_E);

    hiperMech->setGlobalIntegrals({"AreaBorder"});

    hiperMech->Update();


    //Fill system
    timer.start("filling");
    hiperMech->FillLinearSystem();
    timer.end("filling");


    //Solve
    try
    {
        timer.start("solver");

        AztecOO lin_solver(*hiperMech->linProbl);
        lin_solver.SetAztecOption(AZ_precond, AZ_ls);
        lin_solver.SetAztecOption(AZ_solver, AZ_cg);
        lin_solver.SetAztecOption(AZ_output, AZ_summary);
        lin_solver.Iterate(5000, 1e-6);

        timer.end("solver");
    }
    catch(runtime_error& err)
    {

        cout << dhand->myRank() << ":   Solver failed!! " << err.what() << endl;

        MPI_Finalize();
        return 0;

    }
    catch(exception err)
    {

        cout << dhand->myRank() << ":   Solver failed!! " << endl;

        MPI_Finalize();
        return 0;

    }

    hiperMech->UpdateSolution();

    if ( disMesh->myRank() == 0 )
        cout << "Area Border: " << hiperMech->globalIntegral("AreaBorder") << endl;

    dhand->UpdateGhosts();
    timer.start("print");

    dhand->printFileLegacyVtk("serHeatEqSol", true);

    timer.end("print");


    timer.printTiming();

    MPI_Finalize();
    return 0;
}


// This function fill the elemental full stiffness matrix for the heat equation \b Amat
// ON A SURFACE
void SM_E (RCP<hiperlife::FillStructure> fillStr)
{
    // Variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int DOF  = subFill.numDOFs;                       // degrees of freedom
    int eNN  = subFill.eNN;                          // number of nodes of the neighborhood
    int nDim = subFill.nDim;                         // dimension of the space of the problem
    int pDim = subFill.pDim;                         // dimension of the parametrizied object
    double *xe_nodes = subFill.nborCoords.data();        // position of the nodes (global)
    double *dp_k = subFill.nborBFsDers(1);

    int     NNZ;        //Number of Non Zeros
    double  Ip0 [9];    //First fundamental form, or metric tensor g
    double  phi0_1[3];  //gradient of the mapping in the parametrical direction xi_1
    double  phi0_2[3];  //gradient of the mapping in the parametrical direction xi_2
    double  phi0_3[3];  //gradient of the mapping in the parametrical direction xi_3
    double  Ip0_[9];    //inverse of the metric tensor

    double aux[3];
    double auxF[3];

    double  det0;       //Determinant of the tensor metric
    double  jac0;       //Jacobian in the middle reference surface at the Gauss point xi_k

    //OUTPUT
    vector<double>& Kmat_k = fillStr->Ak(0, 0);

    //variables initialization
    NNZ  = eNN*eNN;

    //Fills matrices with 0's
    for (int i = 0; i < NNZ; i++ )
        Kmat_k[i] =  0.0;

    //Metric tensor in the reference configuration (first fundamental form)

    phi0_1[0]=0.0; phi0_1[1]=0.0; phi0_1[2]=0.0;
    phi0_2[0]=0.0; phi0_2[1]=0.0; phi0_2[2]=0.0;
    phi0_3[0]=0.0; phi0_3[1]=0.0; phi0_3[2]=0.0;
    for (int i = 0; i < eNN; i++ )
    {
        phi0_1[0] += xe_nodes[nDim*i+0] * dp_k[3*i+0];
        phi0_1[1] += xe_nodes[nDim*i+1] * dp_k[3*i+0];
        phi0_1[2] += xe_nodes[nDim*i+2] * dp_k[3*i+0];
        phi0_2[0] += xe_nodes[nDim*i+0] * dp_k[3*i+1];
        phi0_2[1] += xe_nodes[nDim*i+1] * dp_k[3*i+1];
        phi0_2[2] += xe_nodes[nDim*i+2] * dp_k[3*i+1];
        phi0_3[0] += xe_nodes[nDim*i+0] * dp_k[3*i+2];
        phi0_3[1] += xe_nodes[nDim*i+1] * dp_k[3*i+2];
        phi0_3[2] += xe_nodes[nDim*i+2] * dp_k[3*i+2];
    }

    Ip0[0] = phi0_1[0]*phi0_1[0]+phi0_1[1]*phi0_1[1]+phi0_1[2]*phi0_1[2];
    Ip0[1] = phi0_1[0]*phi0_2[0]+phi0_1[1]*phi0_2[1]+phi0_1[2]*phi0_2[2];
    Ip0[2] = phi0_1[0]*phi0_3[0]+phi0_1[1]*phi0_3[1]+phi0_1[2]*phi0_3[2];


    Ip0[3] = Ip0[1];
    Ip0[4] = phi0_2[0]*phi0_2[0]+phi0_2[1]*phi0_2[1]+phi0_2[2]*phi0_2[2];
    Ip0[5] = phi0_2[0]*phi0_3[0]+phi0_2[1]*phi0_3[1]+phi0_2[2]*phi0_3[2];

    Ip0[6] = Ip0[2];
    Ip0[7] = Ip0[5];
    Ip0[8] = phi0_3[0]*phi0_3[0]+phi0_3[1]*phi0_3[1]+phi0_3[2]*phi0_3[2];

    det0 = Math::DetMat3x3(Ip0);
    jac0  = sqrt(det0);

    //metric tensor inverse
    Math::Invert3x3(Ip0_, Ip0);

    // Dp x inv(I) x Dp^T   : G=inv(g)
    for (int i = 0; i < eNN; i++ )
    {
        for (int  j = 0; j < eNN; j++ )
        {
            Math::MatProduct(aux, 1, 3, 3, &dp_k[3*i], Ip0_);
            Math::MatProduct(auxF, 1, 3, 1, aux, &dp_k[3*j]);

            Kmat_k[i*eNN*DOF+j*DOF+0] += jac0 * auxF[0];
        }
    }

    return;
}

// Right Hand Side storing the load at the border
void RHS_B_E(RCP<hiperlife::FillStructure> fillStr)
{

    // Variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int DOF  = subFill.numDOFs;                       // degrees of freedom
    int eNN  = subFill.eNN;                          // number of nodes of the neighborhood
    int nDim = subFill.nDim;                         // dimension of the space of the problem
    int pDim = subFill.pDim;                         // dimension of the parametrizied object
    double *xe_nodes = subFill.nborCoords.data();        // position of the nodes (global)
//    double *uNodes  = subFill.nborDOFs.data();
    double *bf_k  = subFill.nborBFsDers(0);
    double *dp_k = subFill.nborBFsDers(1);

    auto bTangentRef = subFill.tangentsBoundaryRef();

    // Computing Tangent Map
    double phi0_1[3], phi0_2[3], phi0_3[3];
    phi0_1[0]=0.0; phi0_1[1]=0.0; phi0_1[2]=0.0;
    phi0_2[0]=0.0; phi0_2[1]=0.0; phi0_2[2]=0.0;
    phi0_3[0]=0.0; phi0_3[1]=0.0; phi0_3[2]=0.0;
    for (int i = 0; i < eNN; i++ )
    {
        phi0_1[0] += xe_nodes[nDim*i+0] * dp_k[3*i+0];
        phi0_1[1] += xe_nodes[nDim*i+1] * dp_k[3*i+0];
        phi0_1[2] += xe_nodes[nDim*i+2] * dp_k[3*i+0];
        phi0_2[0] += xe_nodes[nDim*i+0] * dp_k[3*i+1];
        phi0_2[1] += xe_nodes[nDim*i+1] * dp_k[3*i+1];
        phi0_2[2] += xe_nodes[nDim*i+2] * dp_k[3*i+1];
        phi0_3[0] += xe_nodes[nDim*i+0] * dp_k[3*i+2];
        phi0_3[1] += xe_nodes[nDim*i+1] * dp_k[3*i+2];
        phi0_3[2] += xe_nodes[nDim*i+2] * dp_k[3*i+2];
    }
    double bTangent1[3]={};
    double bTangent2[3]={};


    bTangent1[0] = bTangentRef[0] * phi0_1[0] + bTangentRef[1]*phi0_2[0] + bTangentRef[2]*phi0_3[0];
    bTangent1[1] = bTangentRef[0] * phi0_1[1] + bTangentRef[1]*phi0_2[1] + bTangentRef[2]*phi0_3[1];
    bTangent1[2] = bTangentRef[0] * phi0_1[2] + bTangentRef[1]*phi0_2[2] + bTangentRef[2]*phi0_3[2];

    bTangent2[0] = bTangentRef[3] * phi0_1[0] + bTangentRef[4]*phi0_2[0] + bTangentRef[5]*phi0_3[0];
    bTangent2[1] = bTangentRef[3] * phi0_1[1] + bTangentRef[4]*phi0_2[1] + bTangentRef[5]*phi0_3[1];
    bTangent2[2] = bTangentRef[3] * phi0_1[2] + bTangentRef[4]*phi0_2[2] + bTangentRef[5]*phi0_3[2];

    double cross[3]={};
    Math::Cross(cross,bTangent1,bTangent2);
    double jac = Math::Norm3D(cross);

    fillStr->addToGlobalIntegral("AreaBorder",jac);

    cout << endl;
    cout << "Elem=" << subFill.elemID << endl;
    cout << "wSample=" << subFill.cubaInfo.wSamples[subFill.kPt] << endl;
    cout << "bt1=(" << bTangent1[0] << " " <<  bTangent1[1] << " " << bTangent1[2] << ")" << endl;
    cout << "bt2=(" << bTangent2[0] << " " <<  bTangent2[1] << " " << bTangent2[2] << ")" << endl;
    cout << "cross=(" << cross[0] << " " <<  cross[1] << " " << cross[2] << ")" << endl;
    cout << endl;

    for (int i = 0; i < eNN; i++ )
        fillStr->_B_k[0][i*DOF] += jac*bf_k[i];

    return;

}
