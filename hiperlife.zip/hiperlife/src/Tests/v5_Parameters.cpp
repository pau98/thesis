#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_ParamStructure.h"

struct TestParams
{    
    enum RealParameters
    {
        defRealParam,
        manualRealParam,
        clRealParam,
        cfRealParam
    };

    enum IntParameters
    {
        defIntParam,
        manualIntParam,
        clIntParam,
        cfIntParam
    };

    enum StringParameters
    {
        defStrParam,
        manualStrParam,
        clStrParam,
        cfStrParam
    };

    enum BoolParameters
    {
        defBoolParam,
        manualBoolParam,
        clBoolParam,
        cfBoolParam
    };

    //static inline HlParameterList DefaultValues{
    HL_PARAMETER_LIST DefaultValues{
            {"defRealParam", -1.0, -10.0, 10.0},
            {"manualRealParam", -1.0, -10.0, 1000.0},
            {"clRealParam", -1.0, -10.0, 10.0},
            {"cfRealParam", -1.0, -10.0, 50.0},
            {"defIntParam", -1, -10, 10},
            {"manualIntParam", -1, -10, 1000},
            {"clIntParam", -1, -1, 1000},
            {"cfIntParam", -1, -1, 50},
            {"defStrParam", "-1"},
            {"manualStrParam", "-1", {"-1", "666"}},
            {"clStrParam", "-1", {"-1", "+0", "+1", "753"}},
            {"cfStrParam", "-1", {"-1", "+0", "+1", "42"}},
            {"defBoolParam", true},
            {"manualBoolParam", true},
            {"clBoolParam", true},
            {"cfBoolParam", true},
    };
};

bool CheckParameters(const hiperlife::SmartPtr<hiperlife::ParamStructure>& params, bool manualChanged, bool clChanged, bool cfChanged)
{
    if(params == hiperlife::null)
        return false;

    const int sizeParams = 4;
    std::vector<double> refRealValues(sizeParams, -1.0);
    std::vector<int> refIntValues(sizeParams, -1);
    std::vector<std::string> refStrValues(sizeParams, "-1");
    std::vector<bool> refBoolValues(sizeParams, true);

    if(manualChanged) {
        refRealValues[TestParams::manualRealParam] = 666.0;
        refIntValues[TestParams::manualIntParam] = 666;
        refStrValues[TestParams::manualStrParam] = "666";
        refBoolValues[TestParams::manualBoolParam] = false;
    }
    if(clChanged) {
        refRealValues[TestParams::clRealParam] = 7.53;
        refIntValues[TestParams::clIntParam] = 753;
        refStrValues[TestParams::clStrParam] = "753";
        refBoolValues[TestParams::clBoolParam] = false;
    }
    if(cfChanged) {
        refRealValues[TestParams::cfRealParam] = 42.0;
        refIntValues[TestParams::cfIntParam] = 42;
        refStrValues[TestParams::cfStrParam] = "42";
        refBoolValues[TestParams::cfBoolParam] = false;
    }

    for(int i = 0; i < sizeParams; i++) {
        if (abs(params->getRealParameter(i) - refRealValues[i]) > 1e-5)
            return false;
        if (params->getIntParameter(i) != refIntValues[i])
            return false;
        if (params->getStringParameter(i) != refStrValues[i])
            return false;
        if (params->getBoolParameter(i) != refBoolValues[i])
            return false;
    }

    return true;
}

void TestDefault()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = hiperlife::CreateParamStructure<TestParams>();
        bool checkCorrect = CheckParameters(params, false, false, false);

        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: default:                              " << testResult << std::endl;
}

void TestManual()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = hiperlife::CreateParamStructure<TestParams>();

        params->setRealParameter(TestParams::manualRealParam, 666.0);
        params->setIntParameter(TestParams::manualStrParam, 666);
        params->setStringParameter(TestParams::manualStrParam, "666");
        params->setBoolParameter(TestParams::manualBoolParam, false);

        const bool checkCorrect = CheckParameters(params, true, false, false);
        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: manual:                               " << testResult << std::endl;
}

void TestCommandLine()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = hiperlife::ReadParamsFromCommandLine<TestParams>();
        const bool checkCorrect = CheckParameters(params, false, true, false);
        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: command line:                         " << testResult << std::endl;

}

void TestConfigFile()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = ReadParamsFromConfigFile<TestParams>();
        const bool checkCorrect = CheckParameters(params, false, false, true);
        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: config file:                          " << testResult << std::endl;
}

void TestSaveParams()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    std::string filenameSavedParams{"saved_params.txt"};
    try {
        SmartPtr<ParamStructure> paramsOriginal = ReadParamsFromConfigFile<TestParams>();
        const bool checkCorrectOriginal = CheckParameters(paramsOriginal, false, false, true);

        SaveParamsToConfigFile(paramsOriginal, filenameSavedParams);
        SmartPtr<ParamStructure> paramsSaved = hiperlife::CreateParamStructure<TestParams>();
        ReadParamsFromConfigFile<TestParams>(paramsSaved, filenameSavedParams);
        const bool checkCorrectSaved = CheckParameters(paramsSaved, false, false, true);

        testResult = checkCorrectOriginal && checkCorrectSaved? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: saved params:                         " << testResult << std::endl;


}


void TestManual_and_command_line()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = hiperlife::CreateParamStructure<TestParams>();

        params->setRealParameter(TestParams::manualRealParam, 666.0);
        params->setIntParameter(TestParams::manualStrParam, 666);
        params->setStringParameter(TestParams::manualStrParam, "666");
        params->setBoolParameter(TestParams::manualBoolParam, false);

        ReadParamsFromCommandLine<TestParams>(params);
        const bool checkCorrect = CheckParameters(params, true, true, false);
        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: manual and command line:              " << testResult << std::endl;
}

void TestManualAndConfigFile()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = hiperlife::CreateParamStructure<TestParams>();

        params->setRealParameter(TestParams::manualRealParam, 666.0);
        params->setIntParameter(TestParams::manualStrParam, 666);
        params->setStringParameter(TestParams::manualStrParam, "666");
        params->setBoolParameter(TestParams::manualBoolParam, false);

        ReadParamsFromConfigFile<TestParams>(params);

        const bool checkCorrect = CheckParameters(params, true, false, true);
        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: manual and config file:               " << testResult << std::endl;
}

void TestConfigFileAndCommandLine()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = ReadParamsFromConfigFileAndCommandLine<TestParams>();

        const bool checkCorrect = CheckParameters(params, false, true, true);
        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }

    std::cout << "Test: config file and command line:         " << testResult << std::endl;
}

void TestManualConfigFileAndCommandLine()
{
    using namespace std;
    using namespace hiperlife;

    std::string testResult;
    try {
        SmartPtr<ParamStructure> params = hiperlife::CreateParamStructure<TestParams>();

        params->setRealParameter(TestParams::manualRealParam, 666.0);
        params->setIntParameter(TestParams::manualStrParam, 666);
        params->setStringParameter(TestParams::manualStrParam, "666");
        params->setBoolParameter(TestParams::manualBoolParam, false);

        ReadParamsFromConfigFileAndCommandLine<TestParams>(params);
        const bool checkCorrect = CheckParameters(params, true, true, true);
        testResult = checkCorrect ? "ok" : "failed.";
    }
    catch (std::exception& e) {
        testResult = std::string("failed -> ") + e.what();
    }
    std::cout << "Test: manual, command line and config file: " << testResult << std::endl;
}

int main(int argc, char** argv)
{
    hiperlife::Init(argc, argv);

    std::cout << "*** Testing parameter module ***" << std::endl;

    hiperlife::ShowHelp<TestParams>();
    TestDefault();
    TestManual();
    TestCommandLine();
    TestManual_and_command_line();
    TestConfigFile();
    TestSaveParams();
    TestManualAndConfigFile();
    TestConfigFileAndCommandLine();
    TestManualConfigFileAndCommandLine();

    hiperlife::Finalize();

    return 0;
}

// test with: v5_Parameters test-config.cfg --param0=3.15 --param1=100 --param2=option --param3=true  --glpar0=1e-8 --glpar1=2000 --glpar2=file --glpar3=false
