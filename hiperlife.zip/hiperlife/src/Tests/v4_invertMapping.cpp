
// C++ headers
#include <mpi.h>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_Timer.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_TypeDefs.h"
#include "hl_vtkElementLocator.h"
#include "hl_QuadtreeElementLocator.h"
#include "hl_OctreeElementLocator.h"
#include "hl_BVHElementLocator.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

using namespace std;


int main()
{

    //*************************************************************************
    // [0] Initialize
    //*************************************************************************

    // Initialize MPI
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    if (myRank == 0)
        cout << endl;


    //*************************************************************************
    // [1] Create mesh
    //*************************************************************************

    // Create mesh
    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    mesh->genStructMesh(5,5);
    // mesh->rotate2D(M_PI/6.0);
    // mesh->genRuledSurface(4, 4, {0,0,0}, {0,1,0.5}, {1,1,-0.2}, {-1,0,0.3});
    // mesh->genTorusSurfacePatchSector(12*4*2, 12*2*4, 0.2, M_PI/2.0, 1.0, M_PI/2.0);

    // Distribute the mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(false);
    disMesh->setElementLocatorEngine(ElementLocatorEngine::None);
    disMesh->setVerbosity(hiperlife::Verbosity::None);
    disMesh->Update();
    disMesh->printFileLegacyVtk("mesh");


    //*************************************************************************
    // [2] Create DOFsHandler
    //*************************************************************************

    // DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setDOFs({"x", "y"});
    dhand->setElemAuxF({"found"});
    dhand->Update();

    // Set initial conditions
    for (int i = 0; i < disMesh->loc_nPts(); i++)
    {
        for (int d = 0; d < dhand->nodeDOFs->numFlds(); d++)
        {
            double coord = disMesh->nodeCoord(i, d, IndexType::Local);
            dhand->nodeDOFs->setValue(d, i, IndexType::Local, coord);
        }
    }
    dhand->UpdateGhosts();


    //*************************************************************************
    // [3] Create points
    //*************************************************************************

    // Create mesh
    RCP<StructMeshGenerator> p_mesh = rcp(new StructMeshGenerator);
    p_mesh->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    p_mesh->genCircle(30, 0.5);
    p_mesh->scale(0.9);
    p_mesh->translate(1.0, 0.5, 0.0);
    // p_mesh->genStructMesh(11);
    // p_mesh->scale(1.1);

    // Distribute the mesh
    RCP<DistributedMesh> p_disMesh = rcp(new DistributedMesh);
    p_disMesh->setMesh(p_mesh);
    p_disMesh->setBalanceMesh(true);
    p_disMesh->setElementLocatorEngine(ElementLocatorEngine::None);
    p_disMesh->Update();

    // Save and distribute the points
    int nPts = p_disMesh->nPts();
    vector<vector<double>> gCoords(nPts, vector<double>(3));
    for (int i = 0; i < nPts; i++)
    {
        int p_new = p_disMesh->nodePartition(i);
        if (p_disMesh->isNodeInPart(i))
            gCoords[i] = p_disMesh->nodeCoords(i);
        MPI_Bcast(gCoords[i].data(), 3, MPI_DOUBLE, p_new, p_disMesh->comm());
    }

    // // Set point by hand
    // nPts = 1;
    // gCoords.clear();
    // gCoords.resize(1, vector<double>(3, 0.0));
    // gCoords[0][0] = 1.1;
    // gCoords[0][1] = 0.9;


    //*************************************************************************
    // [3] Search
    //*************************************************************************

    // Output searching point
    if (myRank == 0)
    {
        ofstream myfile;
        myfile.open("point.csv", std::ofstream::out | std::ofstream::trunc);
        for (int i = 0; i < nPts; i++)
            myfile << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
        myfile.close();
    }

    double totalTime{1.0};
    int nSteps = 50;
    for (int t = 0; t < nSteps; t++)
    {
        // Create element locator
        // RCP<QuadtreeElementLocator> elLoc = rcp(new QuadtreeElementLocator);
        // RCP<OctreeElementLocator> elLoc = rcp(new OctreeElementLocator);
        RCP<BVHElementLocator> elLoc = rcp(new BVHElementLocator);
        elLoc->setDistributedMesh(disMesh.getRawPtr());
        elLoc->setFieldsToMap(dhand->nodeDOFs, {0,1});
        elLoc->Update();

        // Find points
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));
        vector<double> dists = elLoc->searchElement(elems, rCoords, gCoords);
        // cout << endl;

        // Interpolate position and print point
        ofstream myfile;
        myfile.open("foundRef."+to_string(t)+".csv", std::ios_base::app);
        for (int i = 0; i < nPts; i++)
        {
            if (disMesh->isElemInPart(elems[i]))
            {
                // Output found point in reference domain
                vector<double> X = disMesh->interpolatePosition(elems[i], rCoords[i]);
                myfile << std::setprecision(16) << X[0] << " " << X[1] << " " << X[2] << " ";
                // cout << " Final " << dists[i] << " " << elems[i] << " " << rCoords[i][0] << " " << rCoords[i][1] << " | " << X[0] << " " << X[1] << endl;
                if (dists[i] < 1e-6)
                    myfile << 1 << endl;
                else
                    myfile << 0 << endl;
            }
        }
        myfile.close();

        // Update and print DOFsHandler
        dhand->elemAuxF->setValue("found", 0.0);
        for (int i = 0; i < nPts; i++)
        {
            if (disMesh->isElemInPart(elems[i]))
            {
                if (dists[i] < 1e-6)
                    dhand->elemAuxF->setValue("found", elems[i], IndexType::Global, 1.0);
                else
                    dhand->elemAuxF->setValue("found", elems[i], IndexType::Global, -1.0);
            }
        }
        dhand->printFileLegacyVtk("dhand."+to_string(t), true);

        // Move mesh
        for (int i = 0; i < disMesh->loc_nPts(); i++)
        {
            double x = disMesh->nodeCoord(i, 0, IndexType::Local);
            double y = disMesh->nodeCoord(i, 1, IndexType::Local);
            dhand->nodeDOFs->setValue("x", i, IndexType::Local, x+t/double(nSteps)*totalTime*x);
            dhand->nodeDOFs->setValue("y", i, IndexType::Local, y+t/double(nSteps)*totalTime*y*0.2);
        }
        dhand->UpdateGhosts();
    }



    //*************************************************************************
    // [5] Finalize
    //*************************************************************************

    // Finalize
    MPI_Finalize();
    return 0;
}
