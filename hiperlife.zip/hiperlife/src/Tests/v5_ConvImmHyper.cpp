/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>
#include <set>
#include <unordered_map>
#include <limits>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include <ad.h>



// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct HyElParams
{
  enum RealParameters
  {
    force,
    beta,
    mu0,
    lm0,
    mu1,
    lm1,
    rx,
    ry,
    wpTh,
    beta0,
    loadStep
  };

  enum IntParameters
  {
    timeStep,
  };

  enum BoolParameters
  {
    postProcess,
    approxStep
  };

  HL_PARAMETER_LIST DefaultValues
  {
    {"force", 0.0},
    {"beta", 100.0},
    {"timeStep",0},
    {"k0",10.},
    {"k1",0.01},
    {"mu0",1.},
    {"mu1",1.},
    {"lm0",1.},
    {"lm1",1.},
    {"rx",0.5},
    {"ry",0.5},
    {"wpTh",0.5},
    {"beta0",-1.},
    {"loadStep",1.},
    {"postProcess",false},
    {"approxStep",false}
  };
};

bool fileExists(const std::string& filename)
{
  struct stat buf;
  if (stat(filename.c_str(), &buf) != -1)
  {
    return true;
  }
  return false;
}

struct Params {
  double rx, ry, mu0, lm0, mu1, lm1, wpTh, beta, levels, load, nLs;
};

Params parseArgs(int argc, char* argv[]) {
  std::unordered_map<std::string, std::string> args;
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg.rfind("--", 0) == 0 && i + 1 < argc) {
      args[arg.substr(2)] = argv[++i];
    }
  }

  auto get = [&](const std::string& key,double defVal) -> double {
    auto it = args.find(key);
    if (it == args.end()) {
      cout << "Using default for --" + key<<endl;
      return defVal;
    }
    try {
      return std::stod(it->second);
    } catch (...) {
      throw std::runtime_error("Invalid value for --" + key + ": '" + it->second + "'");
    }
  };

  return Params{
    get("rx",0.5),
    get("ry",0.5),
    get("mu0",1),
    get("lm0",1),
    get("mu1",1),
    get("lm1",1),
    get("wpTh",0.5),
    get("beta",-1.),
    get("levels",5),
    get("load",0.5), // final load factor (0.5 = previous hard-coded value)
    get("nLs",3)     // number of load steps
  };
}


std::string buildFilename(const Params& p)
{
  std::ostringstream oss;
  oss << "_rx" << std::fixed << std::setprecision(3) << p.rx
    << "_ry" << std::fixed << std::setprecision(3) << p.ry
    << "_mu0" << std::fixed << std::setprecision(3) << p.mu0
    << "_lm0" << std::fixed << std::setprecision(3) << p.lm0
    << "_mu1" << std::fixed << std::setprecision(3) << p.mu1
    << "_lm1" << std::fixed << std::setprecision(3) << p.lm1
    << "_wpTh" << std::fixed << std::setprecision(3) << p.wpTh
    << "_beta" << std::fixed << std::setprecision(3) << p.beta;
  return oss.str();
}

// ─── helper: find adjacent element pairs ────────────────────────────────────

std::vector<std::pair<int,int>> findBorderAdjacentPairs(
    Teuchos::RCP<hiperlife::DOFsHandler> dhand, int p, int rInt)
{
    using namespace hiperlife;

    auto mesh = dhand->mesh;
    vector<string> rTags = mesh->_regionTags();
    // if (std::find(rTags.begin(), rTags.end(), rTag) == rTags.end())
    //     throw runtime_error("findBorderAdjacentPairs: The provided region name could not be found");
    vector<int> rPrimes = {3,5,7,11};

    // Corner local-node indices per side of a Q_p square element:
    //   Side 0 (v=-1): nodes 0      and p
    //   Side 1 (u=+1): nodes p      and p*(p+2)
    //   Side 2 (v=+1): nodes p*(p+2) and p*(p+1)
    //   Side 3 (u=-1): nodes p*(p+1) and 0
    const std::array<std::array<int,2>,4> sideCorners = {{
        {0,       p        },
        {p,       p*(p+2)  },
        {p*(p+2), p*(p+1)  },
        {p*(p+1), 0        }
    }};
    
    dhand->elemAuxF->setValue("GhP"+to_string(rInt),1);

    std::unordered_map<int, std::vector<int>> nodeToElems;
    for (int e = 0; e < mesh->loc_nElem(); e++)
    {
        int eNN = mesh->_adjcyEN->getNumNbors(e, IndexType::Local);
        for (int i = 0; i < eNN; i++)
        {
            int gn = mesh->_adjcyEN->getNbor(e, i, IndexType::Global);
            nodeToElems[gn].push_back(e);
        }
    }

    int offs = mesh->offs_nElem();
    std::set<std::pair<int,int>> seen;
    std::vector<std::pair<int,int>> result;

    for (int e1 = 0; e1 < mesh->loc_nElem(); e1++)
    {
        if((int)dhand->elemAuxF->getValue(0,e1)%2 == 0)
        {
            int sCount = 0;
            for (auto& sc : sideCorners)
            {
                int gA = mesh->_adjcyEN->getNbor(e1, sc[0], IndexType::Global);
                int gB = mesh->_adjcyEN->getNbor(e1, sc[1], IndexType::Global);

                const auto& eA = nodeToElems[gA];
                const auto& eB = nodeToElems[gB];

                for (int e2 : eA)
                {
                    if (e2 == e1) continue;
                    if (std::find(eB.begin(), eB.end(), e2) == eB.end()) continue;
                    if ((int)dhand->elemAuxF->getValue(0,e2)%rPrimes[rInt] != 0) continue;
                    int g1 = e1 + offs, g2 = e2 + offs;
                    auto key = std::make_pair(std::min(g1,g2), std::max(g1,g2));
                    if (seen.insert(key).second)
                    {
                        result.push_back(key);
                        double e1Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e1,IndexType::Global);
                        if ((int)e1Val%rPrimes[sCount] != 0)
                            dhand->elemAuxF->setValue("GhP"+to_string(rInt),e1,IndexType::Global,e1Val*rPrimes[sCount]);
                        double e2Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e2,IndexType::Global);
                        if ((int)e2Val%rPrimes[(sCount+2)%4] != 0)
                            dhand->elemAuxF->setValue("GhP"+to_string(rInt),e2,IndexType::Global,e2Val*rPrimes[(sCount+2)%4]);
                    }
                }
                sCount++;
            }
        }
    }
    return result;
}


vector<double> bodyForce(double x,double y)
{
  double sx  = sin(M_PI*x);
  double cx = cos(M_PI*x);
  double sy  = sin(M_PI*y);
  double cy = cos(M_PI*y);
  double sxy = sin(M_PI*(x + y));
  double cxy = cos(M_PI*(x + y));
  double J   = 1. + M_PI*sxy/5.;
  double lnJ = log(J);

  double denom = (M_PI*sxy + 5.)*(M_PI*sxy + 5.);
  vector<double> b(2);

  b[0] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sx*cy + 5.)*(lnJ - 1.)*cxy - (M_PI*sx*cy + 5.)*cxy - M_PI*(lnJ - 1.)*sy*cx*cxy + M_PI*sy*cx*cxy) / denom;

  b[1] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sy*cx + 5.)*(lnJ - 1.)*cxy - (M_PI*sy*cx + 5.)*cxy - M_PI*(lnJ - 1.)*sx*cy*cxy + M_PI*sx*cy*cxy) / denom;

  return b;
}

inline void tensorToVoigt(tensor<double,1>& A_v, tensor<double,2> A)
{
  int n = A.shape()[0];
  if (n == 1)
  {
    A_v(0) = A(0,0);
  }
  else if (n == 2)
  {
    A_v(0) = A(0,0);
    A_v(1) = A(1,1);
    A_v(2) = A(0,1);
  }
  else if (n == 3)
  {
    A_v(0) = A(0,0);
    A_v(1) = A(1,1);
    A_v(2) = A(2,2);
    A_v(3) = A(0,1);
    A_v(4) = A(0,2);
    A_v(5) = A(1,2);
  }
  else
  {
    throw runtime_error("tensorToVoigt: working for 1D, 2D and 3D.");
  }
}

inline void tendot4oo(tensor<double,2> bb, tensor<double,2>& aa)
{
  // *************************************************************************
  // a =  b o b (b packed)
  // []_abcd = 0.5*(C^-1_ac*C^-1_bd + C^-1_ad*C^-1_bc)
  // *************************************************************************

  int n = bb.shape()[0];
  if (n == 1)
  {
    aa(0,0) = 0.5*(bb(0,0)*bb(0,0) + bb(0,0)*bb(0,0));
  }
  else if (n == 2)
  {
    tensor<int,2> ks{{0,2}, {2,1}};
    for (int i = 0; i < 2; i++)
      for (int j = 0; j < 2; j++)
        for (int k = 0; k < 2; k++)
          for (int l = 0; l < 2; l++)
            aa(ks(i,j), ks(k,l)) = 0.5*(bb(i,k)*bb(j,l) + bb(i,l)*bb(j,k));
  }
  else if (n == 3)
  {
    tensor<int,2> ks{{0,3,4}, {3,1,5}, {4,5,2}};
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++)
        for (int k = 0; k < 3; k++)
          for (int l = 0; l < 3; l++)
            aa(ks(i,j), ks(k,l)) = 0.5*(bb(i,k)*bb(j,l) + bb(i,l)*bb(j,k));
  }
  else
  {
    throw runtime_error("tensorToVoigt: working for 1D, 2D and 3D.");
  }
}

// Constitutive models
void constitutiveModel_Coupled_NeoHookean(tensor<double,1>& S_v, tensor<double,2>& S, tensor<double,2>& D, double& W, tensor<double,2> F, map<string, double>& params)
{
  using namespace hiperlife::Tensor;

  //***********************************************************
  // [0] Initialize
  //***********************************************************

  // Parameters
  double mu = params.at("mu");
  double lm = params.at("lambda");

  // Dimensions
  int pDim = F.shape()[0];
  int nVoi{0};
  if (pDim == 1)
    nVoi = 1;
  else if (pDim == 2)
    nVoi = 3;
  else if (pDim == 3)
    nVoi = 6;


  //***********************************************************
  // [1] Compute jacobian, right Cauchy def tensor and inverse
  //***********************************************************

  // Jacobian
  double J = F.det();

  // Inverse of the right Cauchy-Green tensor (tensor and voigt notation)
  tensor<double,2> Finv = F.inv();
  tensor<double,2> Cinv = Finv*Finv.T(); //This seems to introduce less error than C.inv()
  tensor<double,1> Cinv_v(nVoi);
  tensorToVoigt(Cinv_v, Cinv);

  // Compute Cinv(x)Cinv => []_abcd=Cinv_ab*Cinv_cd
  tensor<double,2> CinvCinv = outer(Cinv_v, Cinv_v);

  // Compute Cinv(·)Cinv => []_abcd=0.5(Cinv_ac*Cinv_bd+Cinv_ad*Cinv_bc) [Eq. 6.165]
  tensor<double,2> Cinv_Cinv(nVoi,nVoi);
  tendot4oo(Cinv, Cinv_Cinv);


  //***********************************************************
  // [2] Compute 2nd Piola-Kirchhoff stress tensor
  //***********************************************************

  // Energy
  tensor<double,2> C = F.T()*F;
  W = 0.5*lm*log(J)*log(J) - mu*log(J) + 0.5*mu*(trace(C)-pDim);
  // W = 0.5*lm*(J-1.0)*(J-1.0) - mu*log(J) + 0.5*mu*(trace(C)-2.0); // Wiki

  // Stress tensor
  tensor<double,2> Id = Identity(pDim);
  S = mu*Id + (lm*log(J)-mu)*Cinv;
  // S = mu*Id + 2.0*(lm*J*(J-1.0)-mu)*Cinv; // Wiki
  tensorToVoigt(S_v, S);

  //***********************************************************
  // [3] Compute elasticity tensor
  //***********************************************************

  // Elasticity tensor
  D = lm*CinvCinv + 2.0*(mu-lm*log(J))*Cinv_Cinv;
  // D = 4.0*(2.0*lm*J*J-lm*J)*CinvCinv - 4.0*(lm*J*(J-1.0)-mu)*Cinv_Cinv; // Wiki
}

void constitutiveModel_Coupled_NeoHookean(tensor<double,1>& S_v, tensor<double,2>& S, tensor<double,2>& D,tensor<double,3>& CC, double& W, tensor<double,2> F, map<string, double>& params)
{
  using namespace hiperlife::Tensor;

  //***********************************************************
  // [0] Initialize
  //***********************************************************

  // Parameters
  double mu = params.at("mu");
  double lm = params.at("lambda");

  // Dimensions
  int pDim = F.shape()[0];
  int nVoi{0};
  if (pDim == 1)
    nVoi = 1;
  else if (pDim == 2)
    nVoi = 3;
  else if (pDim == 3)
    nVoi = 6;


  //***********************************************************
  // [1] Compute jacobian, right Cauchy def tensor and inverse
  //***********************************************************

  // Jacobian
  double J = F.det();
  double lnJ = log(J);

  // Inverse of the right Cauchy-Green tensor (tensor and voigt notation)
  tensor<double,2> Finv = F.inv();
  tensor<double,2> Cinv = Finv*Finv.T(); //This seems to introduce less error than C.inv()
  tensor<double,1> Cinv_v(nVoi);
  tensorToVoigt(Cinv_v, Cinv);

  // Compute Cinv(x)Cinv => []_abcd=Cinv_ab*Cinv_cd
  tensor<double,2> CinvCinv = outer(Cinv_v, Cinv_v);

  // Compute Cinv(·)Cinv => []_abcd=0.5(Cinv_ac*Cinv_bd+Cinv_ad*Cinv_bc) [Eq. 6.165]
  tensor<double,2> Cinv_Cinv(nVoi,nVoi);
  tendot4oo(Cinv, Cinv_Cinv);


  //***********************************************************
  // [2] Compute 2nd Piola-Kirchhoff stress tensor
  //***********************************************************

  // Energy
  tensor<double,2> C = F.T()*F;
  W = 0.5*lm*log(J)*log(J) - mu*lnJ + 0.5*mu*(trace(C)-pDim);
  // W = 0.5*lm*(J-1.0)*(J-1.0) - mu*log(J) + 0.5*mu*(trace(C)-2.0); // Wiki

  // Stress tensor
  tensor<double,2> Id = Identity(pDim);
  S = mu*Id + (lm*lnJ-mu)*Cinv;
  // S = mu*Id + 2.0*(lm*J*(J-1.0)-mu)*Cinv; // Wiki
  tensorToVoigt(S_v, S);

  //***********************************************************
  // [3] Compute elasticity tensor
  //***********************************************************

  // Elasticity tensor
  D = lm*CinvCinv + 2.0*(mu-lm*log(J))*Cinv_Cinv;
  // D = 4.0*(2.0*lm*J*J-lm*J)*CinvCinv - 4.0*(lm*J*(J-1.0)-mu)*Cinv_Cinv; // Wiki

  //***********************************************************
  // [4] Compute high order elasticity tensor
  //***********************************************************
  // From the chain rule on D = lm*(cv x cv) + 2*muhat*(Cinv_ovov_Cinv):
  //
  //   dD/dC_g = lm * d(cv x cv)/dC_g
  //           + 2 * d(muhat)/dC_g * (Cinv_ovov_Cinv)
  //           + 2 * muhat * d(Cinv_ovov_Cinv)/dC_g
  //
  // where muhat = mu - lm*lnJ,  d(muhat)/dC_g = -lm/2 * cv(g)
  //
  // Key identity: dCinv_PQ/dC_EF = -1/2*(Cinv_PE*Cinv_FQ + Cinv_PF*Cinv_EQ)

  // index map helper: voigt index -> (i,j) tensor index (1-based)
  tensor<double,2> voigt_to_ij = {{0,0}, {1,1}, {0,1}};   // row = voigt index, cols = i,j

  double muhat = mu - lm*lnJ;

  for (int a = 0; a<3; a++)
  {
    int ai = voigt_to_ij(a,0);  int aj = voigt_to_ij(a,1);
    for (int b = 0; b<3; b++)
    {
      int bi = voigt_to_ij(b,0);  int bj = voigt_to_ij(b,1);
      for (int g = 0; g<3; g++)
      {
        int gi = voigt_to_ij(g,0);  int gj = voigt_to_ij(g,1);

        // d(cv_a)/dC_g  [scalar]
        double dcva = -0.5*(Cinv(ai,gi)*Cinv(gj,aj) + Cinv(ai,gj)*Cinv(gi,aj));

        // d(cv_b)/dC_g  [scalar]
        double dcvb = -0.5*(Cinv(bi,gi)*Cinv(gj,bj) + Cinv(bi,gj)*Cinv(gi,bj));

        // d(cv_a * cv_b)/dC_g  [scalar]
        double dCvCv = dcva*Cinv_v(b) + Cinv_v(a)*dcvb;

        // d(Cinv_Cinv_ab)/dC_g  from product rule on 0.5*(Cinv_ai_bi*Cinv_aj_bj + Cinv_ai_bj*Cinv_aj_bi)
        double d1 = (-0.5*(Cinv(ai,gi)*Cinv(gj,bi) + Cinv(ai,gj)*Cinv(gi,bi)))*Cinv(aj,bj);
        d1 += Cinv(ai,bi)*(-0.5*(Cinv(aj,gi)*Cinv(gj,bj) + Cinv(aj,gj)*Cinv(gi,bj)));

        double d2 = (-0.5*(Cinv(ai,gi)*Cinv(gj,bj) + Cinv(ai,gj)*Cinv(gi,bj)))*Cinv(aj,bi);
        d2 +=  Cinv(ai,bj)*(-0.5*(Cinv(aj,gi)*Cinv(gj,bi) + Cinv(aj,gj)*Cinv(gi,bi)));

        double dCsC = 0.5*(d1 + d2);

        // d(muhat)/dC_g = -lm * 0.5 * cv_g
        double dmuhat = -lm * 0.5 * Cinv_v(g);

        // CsC_ab at current C (needed for the muhat coefficient term)
        double CsC_ab = 0.5*(Cinv(ai,bi)*Cinv(aj,bj) + Cinv(ai,bj)*Cinv(aj,bi));

        // Assemble
        CC(a,b,g) = 2.*lm * dCvCv + 2.*2.0 * dmuhat * CsC_ab + 2.*2.0 * muhat  * dCsC;
      }
    }
  }
}

// ─── previous (coarser) level, for errors between successive levels ─────────
struct CoarseLevel
{
  bool valid = false;
  SmartPtr<DOFsHandler> dh;
  SmartPtr<DistributedMesh> immMesh; // keeps dh's child mesh alive
  int n = 0;
  double x0 = 0., y0 = 0., hx = 1., hy = 1.;
  std::vector<int> cell2elem;
};
static CoarseLevel g_coarse;

void setCoarseLevel(SmartPtr<DOFsHandler> dh, SmartPtr<DistributedMesh> immMesh, int n)
{
  auto mesh = dh->mesh;
  double xMin = 1e300, yMin = 1e300, xMax = -1e300, yMax = -1e300;
  for (int i = 0; i < mesh->nPts(); i++)
  {
    xMin = std::min(xMin, mesh->nodeCoord(i,0));
    xMax = std::max(xMax, mesh->nodeCoord(i,0));
    yMin = std::min(yMin, mesh->nodeCoord(i,1));
    yMax = std::max(yMax, mesh->nodeCoord(i,1));
  }
  g_coarse.dh = dh;
  g_coarse.immMesh = immMesh;
  g_coarse.n = n;
  g_coarse.x0 = xMin;
  g_coarse.y0 = yMin;
  g_coarse.hx = (xMax-xMin)/n;
  g_coarse.hy = (yMax-yMin)/n;
  g_coarse.cell2elem.assign(n*n, -1);
  for (int e = 0; e < mesh->nElem(); e++)
  {
    int c = mesh->_connec->getNbor(e, 4); // centre node
    int ix = (int)floor((mesh->nodeCoord(c,0)-xMin)/g_coarse.hx);
    int iy = (int)floor((mesh->nodeCoord(c,1)-yMin)/g_coarse.hy);
    g_coarse.cell2elem[iy*n+ix] = e;
  }
  g_coarse.valid = true;
}

// Coarse displacement u and gradient G(i,J) = du_i/dX_J of region rInt at X.
// Returns false if the coarse element is not active in that region
// (possible only where the coarse and fine interfaces differ).
bool evalCoarse(const double* x, int rInt, double u[2], double G[2][2], int& elem)
{
  const std::vector<int> rPrime = {3,5};
  auto mesh = g_coarse.dh->mesh;
  int n = g_coarse.n;
  int ix = std::min(n-1, std::max(0, (int)floor((x[0]-g_coarse.x0)/g_coarse.hx)));
  int iy = std::min(n-1, std::max(0, (int)floor((x[1]-g_coarse.y0)/g_coarse.hy)));
  elem = g_coarse.cell2elem[iy*n+ix];
  if (elem < 0 || (int)mesh->_elemFlags->getValue(1, elem, IndexType::Local)%rPrime[rInt] != 0)
    return false;

  int eNN = 9;
  std::vector<int> nds(eNN);
  for (int a = 0; a < eNN; a++)
    nds[a] = mesh->_connec->getNbor(elem, a);
  double ex0 = mesh->nodeCoord(nds[0],0), ey0 = mesh->nodeCoord(nds[0],1);
  double ex1 = mesh->nodeCoord(nds[8],0), ey1 = mesh->nodeCoord(nds[8],1);
  std::vector<double> rC = {(2.*x[0]-ex1-ex0)/(ex1-ex0), (2.*x[1]-ey1-ey0)/(ey1-ey0)};
  std::vector<std::vector<double>>& bf = mesh->_basisFunctions->computeBasisFunctionsReference(rC, mesh->_basisFunctions->getTag(elem, IndexType::Local));

  // Jacobian dx_J/dxi_K and its inverse
  double J[2][2] = {{0.,0.},{0.,0.}};
  for (int a = 0; a < eNN; a++)
    for (int K = 0; K < 2; K++)
      for (int d = 0; d < 2; d++)
        J[d][K] += mesh->nodeCoord(nds[a],d)*bf[1][2*a+K];
  double det = J[0][0]*J[1][1]-J[0][1]*J[1][0];
  double Ji[2][2] = {{J[1][1]/det, -J[0][1]/det}, {-J[1][0]/det, J[0][0]/det}}; // dxi_K/dx_J

  for (int i = 0; i < 2; i++)
  {
    u[i] = 0.;
    G[i][0] = G[i][1] = 0.;
  }
  for (int a = 0; a < eNN; a++)
  {
    double dx = bf[1][2*a]*Ji[0][0] + bf[1][2*a+1]*Ji[1][0];
    double dy = bf[1][2*a]*Ji[0][1] + bf[1][2*a+1]*Ji[1][1];
    for (int i = 0; i < 2; i++)
    {
      double v = g_coarse.dh->nodeDOFs->getValue(2*rInt+i, nds[a], IndexType::Global);
      u[i] += bf[0][a]*v;
      G[i][0] += dx*v;
      G[i][1] += dy*v;
    }
  }
  return true;
}

// ‖u_h − u_2h‖² and ‖∇u_h − ∇u_2h‖² contributions of region rInt at the current point
void addCoarseDiff(hiperlife::FillStructure& fillStr, const double* x, int rInt,
                   double ux, double uy, double Gxux, double Gyux, double Gxuy, double Gyuy, double jac)
{
  if (!g_coarse.valid)
    return;
  double u[2], G[2][2];
  int elem;
  if (!evalCoarse(x, rInt, u, G, elem))
  {
    fillStr.addToGlobalIntegral("dMiss", jac);
    return;
  }
  fillStr.addToGlobalIntegral("dErr", jac*((ux-u[0])*(ux-u[0]) + (uy-u[1])*(uy-u[1])));
  fillStr.addToGlobalIntegral("dGerr", jac*((Gxux-G[0][0])*(Gxux-G[0][0]) + (Gyux-G[0][1])*(Gyux-G[0][1])
                                          + (Gxuy-G[1][0])*(Gxuy-G[1][0]) + (Gyuy-G[1][1])*(Gyuy-G[1][1])));
}

// Errors of region rInt at the current point: against the manufactured solution
// u_x = u_y = 0.2 sin(pi x) sin(pi y) (exact only for mu = lambda = 1 in both
// regions and full load) and against the previous level
void addSolutionErrors(hiperlife::FillStructure& fillStr, ttl::tensor<double,1> x, int rInt,
                       double ux, double uy, ttl::tensor<double,2> Gu, double jac)
{
  const double ua = 0.2*sin(M_PI*x(0))*sin(M_PI*x(1));
  const double Gxa = 0.2*M_PI*cos(M_PI*x(0))*sin(M_PI*x(1));
  const double Gya = 0.2*M_PI*sin(M_PI*x(0))*cos(M_PI*x(1));
  fillStr.addToGlobalIntegral("error", jac*((ux-ua)*(ux-ua) + (uy-ua)*(uy-ua)));
  fillStr.addToGlobalIntegral("Gerror", jac*((Gu(0,0)-Gxa)*(Gu(0,0)-Gxa) + (Gu(0,1)-Gya)*(Gu(0,1)-Gya)
                                           + (Gu(1,0)-Gxa)*(Gu(1,0)-Gxa) + (Gu(1,1)-Gya)*(Gu(1,1)-Gya)));
  addCoarseDiff(fillStr, x.data(), rInt, ux, uy, Gu(0,0), Gu(0,1), Gu(1,0), Gu(1,1), jac);
}

// Flux weight of side 0 for a fixed beta: stiffness-weighted (harmonic) average
// with the P-wave modulus k = lambda+2mu, gmm0 = k1/(k0+k1), as k1/(k0+k1) in
// the Poisson test and mu1/(mu0+mu1) in the Stokes one
double fixedBetaGmm0(double mu0, double lm0, double mu1, double lm1)
{
  double k0 = lm0 + 2.*mu0;
  double k1 = lm1 + 2.*mu1;
  return k1/(k0+k1);
}

void LSV0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;
  using namespace autodiff;
  double mu0 = fillStr.getRealParameter(HyElParams::mu0);
  double lm0 = fillStr.getRealParameter(HyElParams::lm0);
  double lStep = fillStr.getRealParameter(HyElParams::loadStep);
  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);

  double deltat = 1.;

  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  
  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  // ttl::wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2
  
  // ttl::wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofsT = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofsT(0),dofsT(1)};
  double uu = sqrt((-x(1)+0.5)*(-x(1)+0.5)+(x(0)+0.3)*(x(0)+0.3));

  ttl::tensor<double,1> f(2);
  std::vector<double> b = bodyForce(x(0),x(1));
  f(0) = lStep*b[0];
  f(1) = lStep*b[1];

  tensor<double,2> Id2 = Identity2;
    
  // auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  // {
  //   //***********************************************************
  //   // Initialize
  //   //***********************************************************

  //   // Rearrange DOFs  // FIXME: I don't think this is the fastest way
  //   tensor<dual2nd,2> nborDOFsd(eNN, numDOFs);
  //   for (int i = 0; i < eNN; i++)
  //   {
  //     for (int d = 0; d < numDOFs; d++)
  //     {
  //       nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
  //     }
  //   }
  //   tensor<dual2nd,1> dofsd = bf*nborDOFsd;
  //   tensor<dual2nd,1> u0d = dofsd(rngR0);

  //   tensor<dual2nd,2> nborx = nborDOFsd(all,rngR0)+nborCoords;
  //   tensor<dual2nd,2> Fd = product(nborx, Dbf_g, {{0,0}}); // dx/dchi
  //   dual2nd Jd = Fd.det(); // J = det(Fd)

  //   // Elastic
  //   // Right Cauchy-Green tensor and inverse (background)
  //   tensor<dual2nd,2> Cd = Fd.T()*Fd;
  //   tensor<dual2nd,2> Fd_i = Fd.inv();
  //   tensor<dual2nd,2> Cd_i = Fd_i*Fd_i.T();

  //   // Energy and 2nd Piola-Kirchhoff stress tensor (background)
  //   dual2nd W = 0.5*lm0*log(Jd)*log(Jd) - mu0*log(Jd) + 0.5*mu0*(trace(Cd)-pDim);
  //   dual2nd ray = jac*W-jac*f*u0d;
  //   return(ray);
  // };

  // // Compute nborDOFs as dual2nd type
  // std::vector<dual2nd> dofs(eNN*numDOFs);
  // for (int i = 0; i < eNN*numDOFs; i++)
  // {
  //   dofs.at(i) = subFill.nborDOFs.at(i);
  // }

  // // Compute rayleighian, jacobian, and hessian
  // dual2nd ray;
  // std::vector<double> Jac(eNN*numDOFs);
  // std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  // hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  // // Rearrange into Bk and Ak
  // int n0 = eNN*numDOFs;
  // for (int i = 0; i < n0; i++)
  // {
  //   fillStr.Bk(0).at(i) = Jac[i];
  // }

  // for (int i = 0; i < n0; i++)
  // {
  //   for (int j = 0; j < n0; j++)
  //   {
  //     fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
  //   }
  // }
  

  map<string, double> params0{{"mu",  fillStr.getRealParameter(HyElParams::mu0)},
                             {"lambda", fillStr.getRealParameter(HyElParams::lm0)}};
  // Coordinates
  auto rng0 = range(0,1);

  // Deformation gradient G = dx/dchi (from chi to x)
  tensor<double,2> F0 = product(nborDOFs(all,rng0), Dbf_g, {{0,0}})+Identity2;
  
  // Constitutive model
  double W0{};
  int nVoi = 3;
  tensor<double, 1> S0_v(nVoi);
  tensor<double, 2> S0(pDim, pDim), C0_v(nVoi, nVoi);
  constitutiveModel_Coupled_NeoHookean(S0_v, S0, C0_v, W0, F0, params0);

  // B0 tensor
  tensor<double,3> B00(nVoi, eNN, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      B00(i,a,all) = F0(all,i)*Dbf_g(a,i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      B00(2,a,all) = F0(all,1)*Dbf_g(a,0) + F0(all,0)*Dbf_g(a,1);
  }


  // if(ns == 4 & fabs(F.det()-1.)>1e-10)
  //   cout << F.det() << " " << x << endl;

  // Geometric stiffness matrix
  tensor<double, 2> kg(eNN, eNN);
  kg = Dbf_g*(S0*Dbf_g.T());

  // Geometric stiffness tensor
  tensor<double,2> Id = Identity(pDim);
  tensor<double,4> K0geo(eNN, pDim, eNN, pDim);
  tensor<double,4> K0geo2(eNN, pDim, eNN, pDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int j = 0; j < eNN; j++)
      K0geo2(i,all,j,all) = kg(i,j)*Id;
  }
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            K0geo(b,j,a,i) = kg(a,b);
          else
            K0geo(b,j,a,i) = 0.;
        }
      }
    }
  }

  //***********************************************************
  // Fill linear system
  //***********************************************************
  
  // Internal stresses
  tensor<double,2> Bk0(eNN,numDOFs);
  tensor<double,4> Ak0(eNN,numDOFs,eNN,numDOFs);

  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      for (int b = 0; b<eNN; b++)
        for (int j = 0; j<numDOFs; j++)
          Ak0(a,i,b,j) = 0;
  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      Bk0(a,i) = 0;

  double dEner = jac*W0;
  Bk0(all,rng0) += jac*(B00.transpose({1,2,0})*S0_v)-jac*outer(bf,f);
  Ak0(all,rng0,all,rng0) += jac*(B00.transpose({1,2,0})*C0_v*B00 + K0geo);

  ttl::wrapper<double,2> Bkt(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2

  ttl::wrapper<double,4> Akt(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2


  // for (int a = 0; a<eNN; a++)
  //   for (int i = 0; i<numDOFs; i++)
  //   {
  //     if (fabs(Bk0(a,i)-Bkt(a,i)) > 1e-10)
  //       cout << "BV0 error("<<a<<","<<i<<"): "<< fabs(Bk0(a,i)-Bkt(a,i))<< " " <<Bk0(a,i)<< " " << Bkt(a,i) << endl;
  //     for (int b = 0; b<eNN; b++)
  //       for (int j = 0; j<numDOFs; j++)
  //       {
  //         if (fabs(Ak0(a,i,b,j)-Akt(a,i,b,j)) > 1e-8)
  //           cout << "AV0 error("<<a<<","<<i<<","<<b<<","<<j<<"): "<<fabs(Ak0(a,i,b,j)-Akt(a,i,b,j))<<" "<< Ak0(a,i,b,j) << " "<<Akt(a,i,b,j) <<endl;
  //       }
  
  //   }
  Bkt = Bk0;
  Akt = Ak0;
 
  fillStr.addToGlobalIntegral("Ray", dEner);

  if (fillStr.getBoolParameter(HyElParams::postProcess))
    addSolutionErrors(fillStr, x, 0, dofsT(0), dofsT(1), F0-Id2, jac);

}

void LSV1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  using namespace autodiff;

  double mu1 = fillStr.getRealParameter(HyElParams::mu1);
  double lm1 = fillStr.getRealParameter(HyElParams::lm1);
  double lStep = fillStr.getRealParameter(HyElParams::loadStep);

  auto rngCoords = range(0,1);
  auto rngR1 = range(2,3);

  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  
  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  // ttl::wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2
  
  // ttl::wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofsT = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofsT(2),dofsT(3)};

  ttl::tensor<double,1> f(2);
  std::vector<double> b = bodyForce(x(0),x(1));
  f(0) = lStep*b[0];
  f(1) = lStep*b[1];

  tensor<double,2> Id2 = Identity2;
    
  //   auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  //   {
  //     //***********************************************************
  //     // Initialize
  //     //***********************************************************

  //     // Rearrange DOFs  // FIXME: I don't think this is the fastest way
  //     tensor<dual2nd,2> nborDOFsd(eNN, numDOFs);
  //     for (int i = 0; i < eNN; i++)
  //     {
  //       for (int d = 0; d < numDOFs; d++)
  //       {
  //         nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
  //       }
  //     }

  //     tensor<dual2nd,1> dofsd = bf*nborDOFsd;
  //     tensor<dual2nd,1> u1d = dofsd(rngR1);
  //     tensor<dual2nd,2> nborx = nborDOFsd(all,rngR1)+nborCoords;
  //     tensor<dual2nd,2> Fd = product(nborx, Dbf_g, {{0,0}}); // dx/dchi
  //     dual2nd Jd = Fd.det(); // J = det(Fd)

  //     // Elastic
  //     // Right Cauchy-Green tensor and inverse (background)
  //     tensor<dual2nd,2> Cd = Fd.T()*Fd;

  //     // Energy and 2nd Piola-Kirchhoff stress tensor (background)
  //     dual2nd W = 0.5*lm1*log(Jd)*log(Jd) - mu1*log(Jd) + 0.5*mu1*(trace(Cd)-pDim);
  //     dual2nd ray = jac*W-jac*f*u1d;
  //     return(ray);
  //   };
  //     // Compute nborDOFs as dual2nd type
  //   std::vector<dual2nd> dofs(eNN*numDOFs);
  //   for (int i = 0; i < eNN*numDOFs; i++)
  //   {
  //     dofs.at(i) = subFill.nborDOFs.at(i);
  //   }

  //   // Compute rayleighian, jacobian, and hessian
  //   dual2nd ray;
  //   std::vector<double> Jac(eNN*numDOFs);
  //   std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  //   hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  //   // Rearrange into Bk and Ak
  //   int n0 = eNN*numDOFs;
  //   for (int i = 0; i < n0; i++)
  //   {
  //     fillStr.Bk(0).at(i) = Jac[i];
  //   }

  //   for (int i = 0; i < n0; i++)
  //   {
  //     for (int j = 0; j < n0; j++)
  //     {
  //       fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
  //     }
  //   }


  map<string, double> params1{{"mu",  fillStr.getRealParameter(HyElParams::mu1)},
                             {"lambda", fillStr.getRealParameter(HyElParams::lm1)}};
  // Coordinates
  auto rng1 = range(2,3);

  // Deformation gradient G = dx/dchi (from chi to x)
  tensor<double,2> F1 = product(nborDOFs(all,rng1), Dbf_g, {{0,0}})+Identity2;
  
  // Constitutive model
  double W1{};
  int nVoi = 3;
  tensor<double, 1> S1_v(nVoi);
  tensor<double, 2> S1(pDim, pDim), C1_v(nVoi, nVoi);
  constitutiveModel_Coupled_NeoHookean(S1_v, S1, C1_v, W1, F1, params1);

  // B0 tensor
  tensor<double,3> B10(nVoi, eNN, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      B10(i,a,all) = F1(all,i)*Dbf_g(a,i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      B10(2,a,all) = F1(all,1)*Dbf_g(a,0) + F1(all,0)*Dbf_g(a,1);
  }

  // Geometric stiffness matrix
  tensor<double, 2> k1g(eNN, eNN);
  k1g = Dbf_g*(S1*Dbf_g.T());

  // Geometric stiffness tensor
  tensor<double,2> Id = Identity(pDim);
  tensor<double,4> K1geo(eNN, pDim, eNN, pDim);
  tensor<double,4> K1geo2(eNN, pDim, eNN, pDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int j = 0; j < eNN; j++)
      K1geo2(i,all,j,all) = k1g(i,j)*Id;
  }
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            K1geo(b,j,a,i) = k1g(a,b);
          else
            K1geo(b,j,a,i) = 0.;
        }
      }
    }
  }

  //***********************************************************
  // Fill linear system
  //***********************************************************
  
  // Internal stresses
  tensor<double,2> Bk0(eNN,numDOFs);
  tensor<double,4> Ak0(eNN,numDOFs,eNN,numDOFs);
  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      for (int b = 0; b<eNN; b++)
        for (int j = 0; j<numDOFs; j++)
          Ak0(a,i,b,j) = 0;
  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      Bk0(a,i) = 0;

  double dEner = jac*W1;
  Bk0(all,rng1) += jac*(B10.transpose({1,2,0})*S1_v)-jac*outer(bf,f);
  Ak0(all,rng1,all,rng1) += jac*(B10.transpose({1,2,0})*C1_v*B10 + K1geo);

  
  ttl::wrapper<double,2> Bkt(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2

  ttl::wrapper<double,4> Akt(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2


  // for (int a = 0; a<eNN; a++)
  //   for (int i = 0; i<numDOFs; i++)
  //   {
  //     if (fabs(Bk0(a,i)-Bkt(a,i)) > 1e-10)
  //       cout << "BV1 error("<<a<<","<<i<<"): "<< fabs(Bk0(a,i)-Bkt(a,i))<< " " <<Bk0(a,i)<< " " << Bkt(a,i) << endl;
  //     for (int b = 0; b<eNN; b++)
  //       for (int j = 0; j<numDOFs; j++)
  //       {
  //         if (fabs(Ak0(a,i,b,j)-Akt(a,i,b,j)) > 1e-8)
  //           cout << "AV1 error("<<a<<","<<i<<","<<b<<","<<j<<"): "<<fabs(Ak0(a,i,b,j)-Akt(a,i,b,j))<<" "<< Ak0(a,i,b,j) << " "<<Akt(a,i,b,j) <<endl;
  //       }
  
  //   }

  Bkt = Bk0;
  Akt = Ak0;

  // Output integration points
  ofstream myfile;
  // if (!fileExists("Cut.csv"))
  // {
  //   myfile.open("Cut.csv", std::ios_base::app);
  //   myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
  //   myfile.close();
  // }
  // myfile.open("Cut.csv", std::ios_base::app);
  // myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << jac << endl;
  // myfile.close();
  
  fillStr.addToGlobalIntegral("Ray", dEner);


  if (fillStr.getBoolParameter(HyElParams::postProcess))
    addSolutionErrors(fillStr, x, 1, dofsT(2), dofsT(3), F1-Id2, jac);

}

void LSBorder(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  using namespace autodiff;
  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);
  auto rngR1 = range(2,3);

  //============          Initialize variables           ===========//
  // Parameters
  double beta = fillStr.getRealParameter(HyElParams::beta);
  double mu0 = fillStr.getRealParameter(HyElParams::mu0);
  double mu1 = fillStr.getRealParameter(HyElParams::mu1);
  double lm0 = fillStr.getRealParameter(HyElParams::lm0);
  double lm1 = fillStr.getRealParameter(HyElParams::lm1);
  int nS = fillStr.getIntParameter(HyElParams::timeStep);
  bool pstPrcss = fillStr.getBoolParameter(HyElParams::postProcess);
  bool approxStep = fillStr.getBoolParameter(HyElParams::approxStep);

  // Background
  SubFillStructure& subFill = fillStr[0];
  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;       // Number of neighbor nodes
  int nDim = subFill.nDim;      // Number of spatial dimensions
  int pDim = subFill.pDim;      // Number of parametric dimension
  std::vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  // ===================== Values at int. points ==================== //
  // Compute jacobian
  tensor<double,2> dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf, jac, subFill);

  // Get tangent to immersed mesh at integration point
  auto immMesh = subFill.dhandDHand->mesh->_childMesh;
  std::vector<double> t(3);
  for (int ii = 0; ii < nDim; ii++)
    t[ii] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+ii];
  jac = Math::Norm3D(t.data());
  // cout << nDim << endl;
  // Compute unitary normal
  ttl::tensor<double,1> n(2);
  n(0) = t[1]/jac;
  n(1) = -t[0]/jac;
  n *= -1;

  // Compute coordinates using the back mesh
  tensor<double,1> x = bf*nborCoords;


  ttl::tensor<double,2> Id2 = Identity2;
  // Nitsche symmetric
  double gmm0 = 0.5;
  double gmm1 = 1.-gmm0;

  // Obtain Nitsche parameter from each side
  double C02 = subFill.dhandDHand->elemAuxF->getValue("l0",subFill.elemID);
  double C12 = subFill.dhandDHand->elemAuxF->getValue("l1",subFill.elemID);
  
  gmm0 = sqrt(C12)/(sqrt(C12)+sqrt(C02));
  gmm1 = 1.-gmm0;

  double C2 = gmm0*gmm0*C02;
  subFill.dhandDHand->elemAuxF->setValue("lE",subFill.elemID,IndexType::Local,C2);
  subFill.dhandDHand->elemAuxF->setValue("gmm0",subFill.elemID,IndexType::Local,gmm0);
  beta = 5*C2;


  if (fillStr.getRealParameter(HyElParams::beta)>0)
  {
    beta = fillStr.getRealParameter(HyElParams::beta);
    gmm0 = fixedBetaGmm0(mu0, lm0, mu1, lm1);
  }
  gmm1 = 1.-gmm0;

  // auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  // {
  //   //***********************************************************
  //   // Initialize
  //   //***********************************************************

  //   // Rearrange DOFs 
  //   tensor<dual2nd,2,true>   nborDOFsd(eNN, numDOFs);
  //   for (int i = 0; i < eNN; i++)
  //   {
  //     for (int d = 0; d < numDOFs; d++)
  //     {
  //       nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
  //     }
  //   }

  //   tensor<dual2nd,1> dofsd = bf*nborDOFsd;
  //   tensor<dual2nd,1> u0d = {dofsd(0),dofsd(1)};
  //   tensor<dual2nd,1> u1d = {dofsd(2),dofsd(3)};

  //   double vd = 0.00;
  //   tensor<dual2nd,1> vdiffd = (u0d-u1d-vd*n);

  //   tensor<dual2nd,2> nborxd0 = nborDOFsd(all,rngR0)+nborCoords;
  //   tensor<dual2nd,2> Fd0 = product(nborxd0, dbf, {{0,0}}); // dx/dchi
  //   dual2nd Jd0 = Fd0.det(); // J = det(Fd)

  //   // Right Cauchy-Green tensor and inverse (background)
  //   tensor<dual2nd,2> Cd0 = Fd0.T()*Fd0;
  //   tensor<dual2nd,2> Fd0_i = Fd0.inv();
  //   tensor<dual2nd,2> Cd0_i = Fd0_i*Fd0_i.T();

  //   tensor<dual2nd,2> nborxd1 = nborDOFsd(all,rngR1)+nborCoords;
  //   tensor<dual2nd,2> Fd1 = product(nborxd1, dbf, {{0,0}}); // dx/dchi
  //   dual2nd Jd1 = Fd1.det(); // J = det(Fd)

  //   // Right Cauchy-Green tensor and inverse (background)
  //   tensor<dual2nd,2> Cd1 = Fd1.T()*Fd1;
  //   tensor<dual2nd,2> Fd1_i = Fd1.inv();
  //   tensor<dual2nd,2> Cd1_i = Fd1_i*Fd1_i.T();

  //   // Energy and 2nd Piola-Kirchhoff stress tensor (background)
  //   tensor<dual2nd,2> Sd0 = mu0*Id2 + (lm0*log(Jd0)-mu0)*Cd0_i;
  //   tensor<dual2nd,2> Sd1 = mu1*Id2 + (lm1*log(Jd1)-mu1)*Cd1_i;


  //   // ttl::tensor<dual2nd,2> sd = gmm1*(d1d-p1d*Id2)+gmm1*(d1d-p1d*Id2);
  //   tensor<dual2nd,2> Pd0 = Fd0*Sd0;
  //   tensor<dual2nd,2> Pd1 = Fd1*Sd1;
  //   ttl::tensor<dual2nd,2> sd = gmm0*Pd0+gmm1*Pd1;

  //   ttl::tensor<dual2nd,1> Td = sd*n;
  //   dual2nd pen = jac*0.5*beta*vdiffd*vdiffd;
  //   dual2nd tra = -jac*vdiffd*Td;
  //   if (approxStep)
  //     tra = 0;
  //   return(pen+tra);
  // };
  
  // // Compute nborDOFs as dual2nd type
  // std::vector<dual2nd> dofsd(eNN*numDOFs);
  // for (int i = 0; i < eNN*numDOFs; i++)
  // {
  //   dofsd.at(i) = subFill.nborDOFs.at(i);
  // }

  // // Compute rayleighian, jacobian, and hessian
  // dual2nd ray;
  // std::vector<double> Jac(eNN*numDOFs);
  // std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  // hessian(rayleighian, wrt(dofsd), at(dofsd), ray, Jac, Hes);

  // // Rearrange into Bk and Ak
  // int n0 = eNN*numDOFs;
  // for (int i = 0; i < n0; i++)
  // {
  //   fillStr.Bk(0).at(i) = Jac[i];
  // }

  // for (int i = 0; i < n0; i++)
  // {
  //   for (int j = 0; j < n0; j++)
  //   {
  //     fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
  //   }
  // }

  


  map<string, double> params0{{"mu",  fillStr.getRealParameter(HyElParams::mu0)},
                             {"lambda", fillStr.getRealParameter(HyElParams::lm0)}};
  // Coordinates
  auto rng0 = range(0,1);

  // Deformation gradient G = dx/dchi (from chi to x)
  tensor<double,2> F0 = product(nborDOFs(all,rng0), dbf, {{0,0}})+Identity2;
  
  // Constitutive model
  double W0{};
  int nVoi = 3;
  tensor<double, 1> S0_v(nVoi);
  tensor<double, 2> S0(pDim, pDim), C0_v(nVoi, nVoi);
  tensor<double, 3> CC0(nVoi, nVoi,nVoi);

  constitutiveModel_Coupled_NeoHookean(S0_v, S0, C0_v, CC0, W0, F0, params0);

  // B0 tensor
  tensor<double,3> B00(nVoi, eNN, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      B00(i,a,all) = F0(all,i)*dbf(a,i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      B00(2,a,all) = F0(all,1)*dbf(a,0) + F0(all,0)*dbf(a,1);
  }

  map<string, double> params1{{"mu",  fillStr.getRealParameter(HyElParams::mu1)},
                             {"lambda", fillStr.getRealParameter(HyElParams::lm1)}};
  // Coordinates
  auto rng1 = range(2,3);

  double vd = 0.00;

  tensor<double,1> dofs = bf*nborDOFs;
  tensor<double,1> u0 = dofs(rngR0);
  tensor<double,1> u1 = dofs(rngR1);
  tensor<double,1> vdiff = (u0-u1-vd*n);

  // Deformation gradient G = dx/dchi (from chi to x)
  tensor<double,2> F1 = product(nborDOFs(all,rng1), dbf, {{0,0}})+Identity2;
  
  // Constitutive model
  double W1{};

  tensor<double, 1> S1_v(nVoi);
  tensor<double, 2> S1(pDim, pDim), C1_v(nVoi, nVoi);
  tensor<double, 3> CC1(nVoi, nVoi,nVoi);
  constitutiveModel_Coupled_NeoHookean(S1_v, S1, C1_v,CC1, W1, F1, params1);

  // B0 tensor
  tensor<double,3> B10(nVoi, eNN, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      B10(i,a,all) = F1(all,i)*dbf(a,i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      B10(2,a,all) = F1(all,1)*dbf(a,0) + F1(all,0)*dbf(a,1);
  }

  // b0 tensor (F*n)
  tensor<double,2> b00(nVoi, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      b00(i,all) = F0(all,i)*n(i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      b00(2,all) = F0(all,1)*n(0) + F0(all,0)*n(1);
  }
  
  
  // b1 tensor (F*n)
  tensor<double,2> b10(nVoi, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      b10(i,all) = F1(all,i)*n(i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      b10(2,all) = F1(all,1)*n(0) + F1(all,0)*n(1);
  }

  // nv0 tensor (dNa*n*u)
  tensor<double,3> nv(nVoi, eNN, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      nv(i,a,all) = n(i)*vdiff(all)*dbf(a,i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      nv(2,a,all) = n(1)*vdiff(all)*dbf(a,0) + n(0)*vdiff(all)*dbf(a,1);
  }

  // NN tensor (dNa*dNb)
  tensor<double,3> nn(nVoi, eNN, eNN);
  for (int a = 0; a < eNN; a++)
  {
    for (int b = 0; b < eNN; b++)
    {
      for (int i = 0; i < pDim; i++)
        nn(i,a,b) = dbf(b,i)*dbf(a,i);
    }
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      for (int b = 0; b < eNN; b++)
        nn(2,a,b) = dbf(b,1)*dbf(a,0) + dbf(b,0)*dbf(a,1);
  }


  // Border geometric stiffness matrix
  tensor<double, 2> k0g = outer(dbf*S0*n,bf); // gNa*S*n*Nb

  // Border geometric stiffness tensor
  tensor<double,4> k0geo(eNN, pDim, eNN, pDim);

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            k0geo(a,i,b,j) = k0g(a,b);
          else
            k0geo(a,i,b,j) = 0.;
        }
      }
    }
  }

  tensor<double,2> FnCC0 = (b00*vdiff)*CC0;

  tensor<double,4> k0mat = product(B00.transpose({1,2,0})*C0_v,outer(bf,b00),{{2,1}}); // gNa*C*n*Nb
  
  tensor<double,2> P0 =  F0*S0;

  tensor<double,2> dD0geo =(vdiff*b00.transpose({1,0})*C0_v)*nn;

  tensor<double,4> kdD0geo(eNN,pDim,eNN,pDim);
  // cout << "dD0geo: " << dD0geo << endl;
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            kdD0geo(a,i,b,j) = dD0geo(a,b);
          else
            kdD0geo(a,i,b,j) = 0.;
        }
      }
    }
  }

  // Border geometric stiffness matrix
  tensor<double, 2> k1g = outer(dbf*S1*n,bf); // gNa*S*n*Nb

  // Border geometric stiffness tensor
  tensor<double,4> k1geo(eNN, pDim, eNN, pDim);

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            k1geo(a,i,b,j) = k1g(a,b);
          else
            k1geo(a,i,b,j) = 0.;
        }
      }
    }
  }

  tensor<double,2> FnCC1 = (b10*vdiff)*CC1;

  tensor<double,4> k1mat = product(B10.transpose({1,2,0})*C1_v,outer(bf,b10),{{2,1}}); // gNa*C*n*Nb
  
  tensor<double,2> P1 =  F1*S1;

  tensor<double,2> dD1geo =(vdiff*b10.transpose({1,0})*C1_v)*nn;

  tensor<double,4> kdD1geo(eNN,pDim,eNN,pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            kdD1geo(a,i,b,j) = dD1geo(a,b);
          else
            kdD1geo(a,i,b,j) = 0.;
        }
      }
    }
  }


  //***********************************************************
  // Fill linear system
  //***********************************************************
  
  // Internal stresses
  tensor<double,2> Bk0(eNN,numDOFs);
  tensor<double,4> Ak0(eNN,numDOFs,eNN,numDOFs);
  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      for (int b = 0; b<eNN; b++)
        for (int j = 0; j<numDOFs; j++)
          Ak0(a,i,b,j) = 0;
  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      Bk0(a,i) = 0;

  Bk0(all,rng0) += jac * beta * outer(bf,Id2) * vdiff;
  Bk0(all,rng0) -= jac * outer(bf,Id2)*(gmm0*P0+gmm1*P1)*n;
  Bk0(all,rng0) -= jac * gmm0 * (outer(dbf *(S0 * n),Id2)*vdiff);
  Bk0(all,rng0) -= jac * gmm0 *(B00.transpose({1,2,0})*C0_v*b00*vdiff);

  // R1
  Bk0(all,rng1) -= jac * beta * outer(bf,Id2) * vdiff;
  Bk0(all,rng1) += jac * outer(bf,Id2)*(gmm0*P0+gmm1*P1)*n;
  Bk0(all,rng1) -= jac * gmm1 * (outer(dbf *(S1 * n),Id2)*vdiff);
  Bk0(all,rng1) -= jac * gmm1 *(B10.transpose({1,2,0})*C1_v*b10*vdiff);

  // K00
  Ak0(all,rng0,all,rng0) += jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});
  Ak0(all,rng0,all,rng1) -= jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});
  Ak0(all,rng1,all,rng0) -= jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});
  Ak0(all,rng1,all,rng1) += jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});

  // dbFSNa 1.1
  Ak0(all,rng0,all,rng0) += -jac*gmm0*k0geo.transpose({2,3,0,1});

  // FdbSNa 1.2
  Ak0(all,rng0,all,rng0) += -jac*gmm0*k0mat.transpose({2,3,0,1});
 
  // dDFFvdiff 2.1
  Ak0(all,rng0,all,rng0) -= jac*gmm0*B00.transpose({1,2,0})*FnCC0*B00;
  Ak0(all,rng0,all,rng0) -= jac*gmm0*kdD0geo;

  Ak0(all,rng0,all,rng0) -= jac*gmm0*B00.transpose({1,2,0})*C0_v*nv;
  Ak0(all,rng0,all,rng0) -= jac*gmm0*nv.transpose({1,2,0})*C0_v*B00;

  // daFSNb 3.1
  Ak0(all,rng0,all,rng0) += -jac*gmm0*k0geo;

  // FdaSNb 3.2
  Ak0(all,rng0,all,rng0) += -jac*gmm0*k0mat;

  // K01
  // dbFSNa 1.1
  Ak0(all,rng1,all,rng0) += jac*gmm0*k0geo.transpose({2,3,0,1});

  // FdbSNa 1.2
  Ak0(all,rng1,all,rng0) += jac*gmm0*k0mat.transpose({2,3,0,1});
  
  // daFSNb 3.1
  Ak0(all,rng1,all,rng0) -= jac*gmm1*k1geo;

  // FdaSNb 3.2
  Ak0(all,rng1,all,rng0) -= jac*gmm1*k1mat;

  // K10
  // dbFSNa 1.1
  Ak0(all,rng0,all,rng1) -= jac*gmm1*k1geo.transpose({2,3,0,1});

  // FdbSNa 1.2
  Ak0(all,rng0,all,rng1) -= jac*gmm1*k1mat.transpose({2,3,0,1});
  
  // daFSNb 3.1
  Ak0(all,rng0,all,rng1) += jac*gmm0*k0geo;

  // FdaSNb 3.2
  Ak0(all,rng0,all,rng1) += jac*gmm0*k0mat;
    
  // // K11

  // dbFSNa 1.1
  Ak0(all,rng1,all,rng1) += jac*gmm1*k1geo.transpose({2,3,0,1});

  // // FdbSNa 1.2
  Ak0(all,rng1,all,rng1) += jac*gmm1*k1mat.transpose({2,3,0,1});
 
  // dDFFvdiff 2.1
  Ak0(all,rng1,all,rng1) -= jac*gmm1*B10.transpose({1,2,0})*FnCC1*B10;
  Ak0(all,rng1,all,rng1) -= jac*gmm1*kdD1geo;

  Ak0(all,rng1,all,rng1) -= jac*gmm1*B10.transpose({1,2,0})*C1_v*nv;
  Ak0(all,rng1,all,rng1) -= jac*gmm1*nv.transpose({1,2,0})*C1_v*B10;

  // dbFSNa 1.1
  Ak0(all,rng1,all,rng1) += jac*gmm1*k1geo;

  // // FdbSNa 1.2
  Ak0(all,rng1,all,rng1) += jac*gmm1*k1mat;


  ttl::wrapper<double,2> Bkt(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2

  ttl::wrapper<double,4> Akt(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  Akt = Ak0;
  Bkt = Bk0;

  //   // ttl::tensor<dual2nd,2> sd = gmm1*(d1d-p1d*Id2)+gmm1*(d1d-p1d*Id2);
  // tensor<double,2> P0 = F0*S0;
  // tensor<double,2> P1 = F1*S1;
  tensor<double,1> t0 = P0*n;
  tensor<double,1> t1 = P1*n;

  //   ttl::tensor<dual2nd,2> sd = gmm0*Pd0+gmm1*Pd1;

  //   ttl::tensor<dual2nd,1> Td = sd*n;
  //   dual2nd pen = jac*0.5*beta*vdiffd*vdiffd;
  //   dual2nd tra = -jac*vdiffd*Td;
  //   return(pen+tra);

  Params p;
  p.rx = fillStr.getRealParameter(HyElParams::rx);
  p.ry = fillStr.getRealParameter(HyElParams::ry);
  p.mu0 = fillStr.getRealParameter(HyElParams::mu0);
  p.lm0 = fillStr.getRealParameter(HyElParams::lm0);
  p.mu1 = fillStr.getRealParameter(HyElParams::mu1);
  p.lm1 = fillStr.getRealParameter(HyElParams::lm1);
  p.wpTh = fillStr.getRealParameter(HyElParams::wpTh);
  p.beta = fillStr.getRealParameter(HyElParams::beta0);

  fillStr.addToGlobalIntegral("Ray",jac*0.5*beta*vdiff*vdiff -  jac*(gmm0*P0*n+gmm1*P1*n)*vdiff);
  string borderFileName = "Border"+buildFilename(p)+"."+to_string(nS)+".csv";
  if (pstPrcss)
  {
    // Output integration points
    ofstream myfile;
    if (!fileExists(borderFileName))
    {
      myfile.open(borderFileName, std::ios_base::app);
      myfile << "x(0)" << "," << "x(1)" << "," << "nx" <<  "," << "ny" << "," << "tx0" <<  "," << "ty0" <<  "," 
      << "tx1" <<  "," << "ty1" << endl;
      myfile.close();
    }
    myfile.open(borderFileName, std::ios_base::app);
    myfile << std::setprecision(16) << x(0) << "," << x(1) <<"," << n(0) <<"," << n(1) << "," << t0(0) <<"," << t0(1) << ","
    << t1(0) <<"," << t1(1) << endl;
    myfile.close();

    // Save local length
    fillStr.addToGlobalIntegral("uErr", jac*vdiff*vdiff);
    // fillStr.addToGlobalIntegral("pErr", jac *(p0-p1)*(p0-p1))
    fillStr.addToGlobalIntegral("duErr", jac*(P0*n-P1*n)*(P0*n-P1*n));
    fillStr.addToGlobalIntegral("tErr", jac*(gmm0*P0*n+gmm1*P1*n)*(gmm0*P0*n+gmm1*P1*n));
    fillStr.addToGlobalIntegral("Length", jac);

    // Averaged traction against the previous level, at the same point and normal
    if (g_coarse.valid)
    {
      double uc[2], Gc[2][2];
      int elc[2];
      tensor<double,1> tc(2);
      tc(0) = 0.;
      tc(1) = 0.;
      bool ok = true;
      double g0c = 0.;
      for (int r = 0; r < 2 && ok; r++)
      {
        ok = evalCoarse(x.data(), r, uc, Gc, elc[r]);
        if (!ok)
          break;
        if (r == 0)
        {
          g0c = g_coarse.dh->elemAuxF->getValue("gmm0", elc[0], IndexType::Global);
          if (fillStr.getRealParameter(HyElParams::beta) > 0)
            g0c = fixedBetaGmm0(mu0, lm0, mu1, lm1);
        }
        tensor<double,2> Fc = {{1.+Gc[0][0], Gc[0][1]}, {Gc[1][0], 1.+Gc[1][1]}};
        double Wc{};
        tensor<double,1> Sc_v(nVoi);
        tensor<double,2> Sc(pDim,pDim), Cc_v(nVoi,nVoi);
        map<string, double> paramsC{{"mu", r == 0 ? mu0 : mu1}, {"lambda", r == 0 ? lm0 : lm1}};
        constitutiveModel_Coupled_NeoHookean(Sc_v, Sc, Cc_v, Wc, Fc, paramsC);
        tc += (r == 0 ? g0c : 1.-g0c)*(Fc*Sc)*n;
      }
      if (ok)
      {
        tensor<double,1> dt = (gmm0*P0*n+gmm1*P1*n) - tc;
        fillStr.addToGlobalIntegral("dtErr", jac*dt*dt);
      }
      else
        fillStr.addToGlobalIntegral("dMiss", jac);
    }
    // fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));
  }
}

void LSPre(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using hiperlife::Tensor::tensor;
    using namespace hiperlife::Tensor;

    SubFillStructure& subFill = fillStr[0];

    int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
    int numAuxF  = subFill.numAuxF;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    ttl::wrapper<double,2> nborAuxF(subFill.nborAuxF.data(), eNN, numAuxF);

    std::vector<double> b0 = {-1};
    std::vector<std::vector<double>>& pbf0 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b0, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf1 ={pbf0[0][0],pbf0[0][1],pbf0[0][2],pbf0[0][3]}; 
    std::vector<double> b1 = {1};
    std::vector<std::vector<double>>& pbf1 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b1, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf2 ={pbf1[0][0],pbf1[0][1],pbf1[0][2],pbf1[0][3]}; 

    // Get output
    tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    Bk(1,0) = nborAuxF(1,0);
    Bk(1,1) = nborAuxF(1,1);
    Bk(2,0) = nborAuxF(2,0);
    Bk(2,1) = nborAuxF(2,1);
    for (int a = 0; a<eNN; a++)
    {
        Ak(a,0,1,0) = bf1[a];
        Ak(a,1,1,1) = bf1[a];

        Ak(a,0,2,0) = bf2[a];
        Ak(a,1,2,1) = bf2[a];
    }
}


void genCircBspline(double r, std::vector<double> &U,std::vector<std::vector<std::vector<std::vector<double>>>> &CP, double xOff, double yOff, ElemType eTypeB,BasisFuncType bTypeB,int bfOrderB,int nPtsCircOr,SmartPtr<ParamStructure> paramStr)
{
  // Compute immersed mesh CPs position
  SmartPtr<StructMeshGenerator> preBSMesh = Create<StructMeshGenerator>();

  preBSMesh->setMesh(eTypeB, bTypeB, bfOrderB);
  
  std::vector<double> preU(nPtsCircOr+1,0);
  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    preU[i] = preU[i-1]+1;
  }
  
  std::vector<std::vector<std::vector<std::vector<double>>>> preCP(nPtsCircOr, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
  for (int k = 0;  k < nPtsCircOr; k++)
  {
    double t = 2*M_PI*k/nPtsCircOr;
    preCP[k][0][0] = {std::cos(t),std::sin(t),0,0};
  }
  
  preBSMesh->genBsplinesClosedCurve(preU,preCP);
  // Distributed mesh
  SmartPtr<DistributedMesh> preDisBSMesh = Create<DistributedMesh>("preDisBSMesh");
  preDisBSMesh->setMesh(preBSMesh);
  preDisBSMesh->setBalanceMesh(true);
  preDisBSMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
  preDisBSMesh->setVerbosity(Verbosity::None);
  preDisBSMesh->Update();
  
  // Set Degree of Freedom handler
  SmartPtr<DOFsHandler> preDhand = Create<DOFsHandler>(preDisBSMesh);
  preDhand->setNameTag("preDhand");
  preDhand->setNumDOFs(2);
  preDhand->setDOFs({"pcx","pcy"});
  preDhand->setNodeAuxF({"x","y","dxdt","dydt"});
  preDhand->Update();


  std::vector<double> cw = {1};
  for (int i = 0; i<preDisBSMesh->nPts();i++)
  {
    double t = 2.*M_PI*double(i)/double(nPtsCircOr);
    double x = xOff;
    double y = yOff;
    for (int iw = 0; iw<cw.size(); iw++)
    {
      x += cw[iw]*cos((iw+1)*t)*r;
      y += cw[iw]*sin((iw+1)*t)*r;
    }
    preDhand->nodeAuxF->setValue(0,i,IndexType::Global,x);
    preDhand->nodeAuxF->setValue(1,i,IndexType::Global,y);
  }

  SmartPtr<HiPerProblem> preHiperProbl = Create<HiPerProblem>();
  preHiperProbl->setParameterStructure(paramStr);
  preHiperProbl->setDOFsHandlers({preDhand});
  
  // Interface integration
  preHiperProbl->setIntegration("IntegPre", {"preDhand"});
  preHiperProbl->setCubatureGauss("IntegPre", 1);
  preHiperProbl->setElementFillings("IntegPre", LSPre);

  preHiperProbl->Update();

  SmartPtr<MUMPSDirectLinearSolver> preSolver = Create<MUMPSDirectLinearSolver>();
  preSolver->setHiPerProblem(preHiperProbl);
  preSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
  preSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
  preSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Sequential);
  preSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
  preSolver->setConvergenceCriteria(MUMPSDirectLinearSolver::ConvergenceCriteria::Relative);
  preSolver->setTolerance(1e-8);
  preSolver->setDefaultParameters();
  preSolver->Update();

  // Solve
  preSolver->solve();
  preHiperProbl->UpdateGhosts();

  // Update Solution
  preSolver->UpdateSolution();

  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    U[i] = U[i-1]+1.;
  }

  for (int k = 0;  k < nPtsCircOr; k++)
  {  
    double x = preDhand->nodeDOFs->getValue(0,k,IndexType::Global);
    double y = preDhand->nodeDOFs->getValue(1,k,IndexType::Global);
    CP[k][0][0] = {x,y,0,0};
  }
}

// Largest lambda of A x = lambda B x (A: boundary traction term of K, B: patch
// bulk tangent stiffness), robust to the near-singular directions of B:
//  1. Jacobi scaling D = diag(B)^-1/2, so the null-space threshold below is
//     relative to each DOF's own bulk control (cut fraction / element size
//     no longer spread the spectrum of B over many orders of magnitude).
//  2. The rigid modes Rm (columns, unscaled) are projected out explicitly:
//     there both A and B vanish (0/0), which a threshold only catches by luck.
//  3. On the remaining space B is reduced to its eigenvalues > relTol*max and
//     the problem becomes the symmetric Lambda^-1/2 V^T A V Lambda^-1/2:
//     no Cholesky, deterministic, exact for the reduced problem.
// Returns 0 if B has no range left. nUncontrolled counts DOFs that A sees but
// B does not (no bulk control at all -- they are dropped, so the estimate is
// not a bound for them).
double nitscheEigenEstimate(const Eigen::MatrixXd& A, const Eigen::MatrixXd& B, const Eigen::MatrixXd& Rm,
                            int& nUncontrolled, double relTol = 1e-8)
{
  int n = B.rows();
  nUncontrolled = 0;
  if (n == 0)
    return 0.;

  double maxDiagB = B.diagonal().maxCoeff();
  double maxDiagA = A.diagonal().cwiseAbs().maxCoeff();
  if (!(maxDiagB > 0.))
    return 0.;

  Eigen::VectorXd d(n), dInv(n);
  for (int i = 0; i < n; i++)
  {
    if (B(i,i) > 1e-14*maxDiagB)
    {
      d(i) = 1./sqrt(B(i,i));
      dInv(i) = sqrt(B(i,i));
    }
    else
    {
      d(i) = 0.;
      dInv(i) = 0.;
      if (fabs(A(i,i)) > 1e-12*maxDiagA)
        nUncontrolled++;
    }
  }
  Eigen::MatrixXd As = d.asDiagonal()*A*d.asDiagonal();
  Eigen::MatrixXd Bs = d.asDiagonal()*B*d.asDiagonal();

  // Orthonormal complement of the (scaled) rigid modes
  Eigen::MatrixXd Rs = dInv.asDiagonal()*Rm;
  Eigen::ColPivHouseholderQR<Eigen::MatrixXd> qr(Rs);
  qr.setThreshold(1e-10);
  int r = qr.rank();
  Eigen::MatrixXd Q = qr.householderQ();
  Eigen::MatrixXd Cc = Q.rightCols(n - r);

  Eigen::MatrixXd Bc = Cc.transpose()*Bs*Cc;
  Eigen::MatrixXd Ac = Cc.transpose()*As*Cc;
  Bc = 0.5*(Bc + Bc.transpose());
  Ac = 0.5*(Ac + Ac.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> bes(Bc);
  const Eigen::VectorXd& bEv = bes.eigenvalues();
  double bMax = bEv.maxCoeff();
  if (!(bMax > 0.))
    return 0.;
  std::vector<int> keep;
  for (int i = 0; i < bEv.size(); i++)
    if (bEv(i) > relTol*bMax)
      keep.push_back(i);
  if (keep.empty())
    return 0.;

  Eigen::MatrixXd W(Bc.rows(), keep.size());
  for (size_t j = 0; j < keep.size(); j++)
    W.col(j) = bes.eigenvectors().col(keep[j])/sqrt(bEv(keep[j]));
  Eigen::MatrixXd S = W.transpose()*Ac*W;
  S = 0.5*(S + S.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> ses(S, Eigen::EigenvaluesOnly);
  return ses.eigenvalues().maxCoeff();
}

// Clamp of the eigen estimate around the geometric estimate
// C_geo = (lambda_i+2*mu_i)*|Gamma_K|/|Omega_patch|: lambda in [g_nitscheGeoLo, g_nitscheGeoHi]*C_geo.
// The upper cap is wide and only meant to catch garbage (too small a penalty
// loses coercivity); the per-call summary prints the actual lambda/C_geo range.
static const double g_nitscheGeoLo = 0.1;
static const double g_nitscheGeoHi = 1e5;

void localNitscheEstimation(SmartPtr<HiPerProblem> immHP, SmartPtr<DOFsHandler> backDHand, SmartPtr<ParamStructure> paramStr, SmartPtr<DistributedMesh> immMesh)
{
  using ttl::all;

  // Distributed mesh
  SmartPtr<DistributedMesh> backMesh = backDHand->mesh;

  // Get values from paraStructure
  double mu0 = paramStr->getRealParameter(HyElParams::mu0);
  double lm0 = paramStr->getRealParameter(HyElParams::lm0);
  double mu1 = paramStr->getRealParameter(HyElParams::mu1);
  double lm1 = paramStr->getRealParameter(HyElParams::lm1);
  vector<double> vmui = {mu0,mu1};
  vector<double> vlmi = {lm0,lm1};

  // Displacement DOFs of each region (ux,uy). Both operators are linearised at
  // the current displacement (tangent stiffness and traction linearisation)
  int numDOFs = 2;
  int pDim = 2;
  int eNN = 9;
  int nElem = backMesh->nElem();
  tensor<double,2> Id2 = ttl::Identity2;

  // Cubature info for the boundary integration
  std::vector<Teuchos::RCP<CubatureSet>> cubaSetsB = immHP->_integ[0]->_cubaSets;

  // Linear constraints
  std::vector<std::vector<linearConstraint>>& constrReg = backMesh->_cutBFConstrRegions;

  vector<int> rTags = {3,5};

  // Element nodes and node -> elements, from the connectivity (not _adjcyNE)
  std::vector<std::vector<int>> elNds(nElem);
  std::unordered_map<int, std::vector<int>> ndEls;
  for (int iE = 0; iE < nElem; iE++)
  {
    elNds[iE].resize(eNN);
    for (int n = 0; n < eNN; n++)
    {
      elNds[iE][n] = backMesh->_connec->getNbor(iE, n);
      ndEls[elNds[iE][n]].push_back(iE);
    }
  }

  // Patches: one per cut element K of the region, made of K plus the root
  // element(s) of K's slave nodes. The roots carry the bulk that controls
  // the DOFs K's slaves are extrapolated from. Roots are shared between
  // patches, so each element's bulk enters every patch it belongs to scaled
  // by 1/(number of such patches): the patch bulks then sum to the global one
  // and the patch constants combine into a global bound. K's boundary term
  // only enters K's own patch, so l0/l1 of K is just its patch's lambda.
  for (int rInt = 0; rInt < 2; rInt++)
  {
    double mui = vmui[rInt];
    double lmi = vlmi[rInt];
    map<string, double> params{{"mu", mui}, {"lambda", lmi}};

    // Agg field name tag (number of roots of each cut element, for inspection)
    std::string aggTag = "Agg"+to_string(rInt);
    backDHand->elemAuxF->setValue(aggTag,0);

    // Cubature info for the integration in the current region
    std::vector<Teuchos::RCP<CubatureSet>> cubaSetsR = immHP->_integ[rInt+1]->_cubaSets;

    // Slave node -> its constraint in this region
    std::unordered_map<int, const linearConstraint*> slaveOf;
    for (const linearConstraint& lCnt : constrReg[rInt])
      slaveOf[lCnt.slave] = &lCnt;

    // Bad (aggregated) cut element: its centre node is a slave. Never a root.
    auto isBad = [&](int iE) { return slaveOf.count(elNds[iE][4]) > 0; };

    std::vector<int> cutEls;
    for (int iE = 0; iE < nElem; iE++)
    {
      int eTag = backDHand->elemAuxF->getValue(0,iE);
      if (eTag%2 == 0 && eTag%rTags[rInt] == 0)
        cutEls.push_back(iE);
    }

    // Roots of each slave node of a bad K: the non-bad elements containing
    // the most of its masters (all tied ones). Constraints with best count
    // <= 3 are plain hanging-node constraints and need no root. Well-cut K
    // has no aggregation slaves: patch {K}.
    int nWeakRoots = 0, nNoRoots = 0;
    std::vector<std::vector<int>> AP(cutEls.size());
    std::vector<int> mEl(nElem, 0);
    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      std::set<int> patch = {K};
      std::set<int> roots;
      for (int nd : (isBad(K) ? elNds[K] : std::vector<int>{}))
      {
        auto it = slaveOf.find(nd);
        if (it == slaveOf.end())
          continue;
        const linearConstraint& lCnt = *it->second;
        std::unordered_map<int,int> count;
        for (size_t m = 0; m < lCnt.masters.size(); m++)
          for (int e : ndEls[lCnt.masters[m]])
            if (!isBad(e))
              count[e]++;
        int best = 0;
        for (auto& c : count)
          best = max(best, c.second);
        if (best <= 3)
          continue;
        if (best < 6)
          nWeakRoots++;
        for (auto& c : count)
          if (c.second == best)
            roots.insert(c.first);
      }
      if (isBad(K) && roots.empty())
        nNoRoots++;
      patch.insert(roots.begin(), roots.end());

      // Free nodes of a bad K outside its roots are controlled through some
      // other good element of the region: add it, otherwise their only bulk
      // control in the patch is K's sliver
      if (isBad(K))
      {
        std::set<int> rootNds;
        for (int e : roots)
          rootNds.insert(elNds[e].begin(), elNds[e].end());
        for (int nd : elNds[K])
        {
          if (slaveOf.count(nd) || rootNds.count(nd))
            continue;
          for (int e : ndEls[nd])
          {
            int eTag = backDHand->elemAuxF->getValue(0,e);
            if (e != K && eTag%rTags[rInt] == 0 && !isBad(e))
              patch.insert(e);
          }
        }
      }
      backDHand->elemAuxF->setValue(aggTag,K,IndexType::Global,(double)roots.size());
      AP[k].assign(patch.begin(), patch.end());
      for (int e : AP[k])
        mEl[e]++;
    }

    // Summary counters
    int nAgg = 0, nLo = 0, nHi = 0, nFallback = 0, nUncTot = 0, maxNM = 0;
    double rMin = 1e300, rMax = 0.;

    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      const std::vector<int>& akp = AP[k];
      if (akp.size() > 1)
        nAgg++;

      // Patch DOF nodes (masters after the constraint mapping) and, per
      // element node, its (patch node, weight) list
      std::vector<int> igNds;
      std::unordered_map<int,int> igIdx;
      auto patchIdx = [&](int nd) {
        auto it = igIdx.find(nd);
        if (it != igIdx.end())
          return it->second;
        igIdx[nd] = igNds.size();
        igNds.push_back(nd);
        return (int)igNds.size()-1;
      };
      std::unordered_map<int, std::vector<std::vector<std::pair<int,double>>>> elMap;
      for (int iE : akp)
      {
        std::vector<std::vector<std::pair<int,double>>>& mp = elMap[iE];
        mp.resize(eNN);
        for (int il = 0; il < eNN; il++)
        {
          auto it = slaveOf.find(elNds[iE][il]);
          if (it == slaveOf.end())
            mp[il].push_back({patchIdx(elNds[iE][il]), 1.});
          else
          {
            // |w|: extrapolation weights are often negative (e.g. 6, -8, 3)
            const linearConstraint& lCnt = *it->second;
            for (size_t m = 0; m < lCnt.masters.size(); m++)
              if (fabs(lCnt.weights[m]) > 1e-13)
                mp[il].push_back({patchIdx(lCnt.masters[m]), lCnt.weights[m]});
          }
        }
      }
      int nM = igNds.size();
      maxNM = max(maxNM, nM);

      // M1: patch bulk, M2: K's boundary term; DOF (node A, comp i) -> A+nM*i
      Eigen::MatrixXd M1 = Eigen::MatrixXd::Zero(nM*numDOFs, nM*numDOFs);
      Eigen::MatrixXd M2 = Eigen::MatrixXd::Zero(nM*numDOFs, nM*numDOFs);
      auto scatter = [&](Eigen::MatrixXd& M, const std::vector<std::vector<std::pair<int,double>>>& mp,
                         tensor<double,4>& Ke, double s) {
        for (int a = 0; a < eNN; a++)
          for (auto& pa : mp[a])
            for (int b = 0; b < eNN; b++)
              for (auto& pb : mp[b])
              {
                double w = s*pa.second*pb.second;
                for (int i = 0; i < numDOFs; i++)
                  for (int j = 0; j < numDOFs; j++)
                    M(pa.first+nM*i, pb.first+nM*j) += w*Ke(a,i,b,j);
              }
      };

      double APatch = 0.; // bulk measure, scaled as M1
      double LPatch = 0.; // K's boundary measure

      for (int iE : akp)
      {
        double sE = 1./mEl[iE];

        // Compute bulk integration: tangent stiffness B0^T C B0 + Kgeo
        for (auto info: cubaSetsR[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,4> Aku1(eNN,numDOFs,eNN,numDOFs);
          for (int a = 0 ; a < eNN; a++)
            for (int i = 0 ; i < numDOFs; i++)
              for (int b = 0 ; b < eNN; b++)
                for (int j = 0 ; j < numDOFs; j++)
                  Aku1(a,i,b,j) = 0;

          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int i = 0 ; i < 2; i++)
              for (int j = 0 ; j < 2; j++)
                Jac(i,j) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            tensor<double,2> nborDOFs(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                nborDOFs(n,d0) = backDHand->nodeDOFs->getValue(d0+rInt*2,nbor);
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();

            // Deformation gradient, constitutive model and B0 (as in LSV0/LSV1)
            tensor<double,2> F = product(nborDOFs, Dbf_g, {{0,0}})+Id2;
            double W{};
            int nVoi = 3;
            tensor<double,1> S_v(nVoi);
            tensor<double,2> S(pDim,pDim), C_v(nVoi,nVoi);
            constitutiveModel_Coupled_NeoHookean(S_v, S, C_v, W, F, params);
            tensor<double,3> B0(nVoi, eNN, pDim);
            for (int a = 0; a < eNN; a++)
            {
              for (int i = 0; i < pDim; i++)
                B0(i,a,all) = F(all,i)*Dbf_g(a,i);
              B0(2,a,all) = F(all,1)*Dbf_g(a,0) + F(all,0)*Dbf_g(a,1);
            }
            double jac = Jac.det();

            // Geometric stiffness
            tensor<double,2> kg = Dbf_g*(S*Dbf_g.T());
            tensor<double,4> Kgeo(eNN,pDim,eNN,pDim);
            for (int a = 0; a < eNN; a++)
              for (int i = 0; i < pDim; i++)
                for (int b = 0; b < eNN; b++)
                  for (int j = 0; j < pDim; j++)
                    Kgeo(b,j,a,i) = (i == j) ? kg(a,b) : 0.;

            Aku1 += wS[gpi]*jac*(B0.transpose({1,2,0})*C_v*B0 + Kgeo);
            APatch += sE*wS[gpi]*jac;
          }
          scatter(M1, elMap[iE], Aku1, sE);
        }

        // Boundary term of K only: |d(P n)/du v|^2
        if (iE != K)
          continue;

        for (auto info: cubaSetsB[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,4> Bku1(eNN,numDOFs,eNN,numDOFs);
          for (int a = 0 ; a < eNN; a++)
            for (int i = 0 ; i < numDOFs; i++)
              for (int b = 0 ; b < eNN; b++)
                for (int j = 0 ; j < numDOFs; j++)
                  Bku1(a,i,b,j) = 0;

          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int i = 0 ; i < 2; i++)
              for (int j = 0 ; j < 2; j++)
                Jac(i,j) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            tensor<double,2> nborDOFs(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                nborDOFs(n,d0) = backDHand->nodeDOFs->getValue(d0+rInt*2,nbor);
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();

            // Deformation gradient, constitutive model and B0 (as in LSV0/LSV1)
            tensor<double,2> F = product(nborDOFs, Dbf_g, {{0,0}})+Id2;
            double W{};
            int nVoi = 3;
            tensor<double,1> S_v(nVoi);
            tensor<double,2> S(pDim,pDim), C_v(nVoi,nVoi);
            constitutiveModel_Coupled_NeoHookean(S_v, S, C_v, W, F, params);
            tensor<double,3> B0(nVoi, eNN, pDim);
            for (int a = 0; a < eNN; a++)
            {
              for (int i = 0; i < pDim; i++)
                B0(i,a,all) = F(all,i)*Dbf_g(a,i);
              B0(2,a,all) = F(all,1)*Dbf_g(a,0) + F(all,0)*Dbf_g(a,1);
            }

            // Normal and jacobian
            int nDim = 3;
            std::vector<double> t(nDim);
            for (int n = 0; n < nDim; n++)
              t[n] = immMesh->_immTangents[iE][nDim*gpi+n];
            double jac = Math::Norm3D(t.data());

            // Compute unitary normal (sign irrelevant: the term is quadratic)
            tensor<double,1> n(2);
            n(0) = -t[1]/jac;
            n(1) = t[0]/jac;

            // Traction linearisation H(a,i,j) = d(P n)_j/du_{a,i}:
            // material part F C (F^T n)_sym and geometric part (grad N_a . S n) delta_ij
            tensor<double,2> b0(nVoi, pDim);
            for (int i = 0; i < pDim; i++)
              b0(i,all) = F(all,i)*n(i);
            b0(2,all) = F(all,1)*n(0) + F(all,0)*n(1);
            tensor<double,1> kg = Dbf_g*S*n;
            tensor<double,3> kgeo(eNN, pDim, pDim);
            for (int a = 0; a < eNN; a++)
              for (int i = 0; i < pDim; i++)
                for (int j = 0; j < pDim; j++)
                  kgeo(a,i,j) = (i == j) ? kg(a) : 0.;
            tensor<double,3> H = B0.transpose({1,2,0})*(C_v*b0) + kgeo;

            Bku1 += wS[gpi]*jac*H*H.transpose({2,0,1});
            LPatch += wS[gpi]*jac;
          }
          scatter(M2, elMap[iE], Bku1, 1.);
        }
      }

      // Rigid modes on the patch nodes, in the current configuration x = X+u
      // (about its centroid). Under stress the tangent is not exactly singular
      // for the rotation, but it carries no boundary control either
      std::vector<double> xn(nM), yn(nM);
      double xc = 0., yc = 0.;
      for (int A = 0; A < nM; A++)
      {
        xn[A] = backMesh->nodeCoord(igNds[A],0) + backDHand->nodeDOFs->getValue(2*rInt,igNds[A]);
        yn[A] = backMesh->nodeCoord(igNds[A],1) + backDHand->nodeDOFs->getValue(2*rInt+1,igNds[A]);
        xc += xn[A]/nM;
        yc += yn[A]/nM;
      }
      Eigen::MatrixXd Rm = Eigen::MatrixXd::Zero(nM*numDOFs, 3);
      for (int A = 0; A < nM; A++)
      {
        Rm(A,0) = 1.;
        Rm(A+nM,1) = 1.;
        Rm(A,2) = -(yn[A] - yc);
        Rm(A+nM,2) = xn[A] - xc;
      }

      int nUnc = 0;
      double lEig = nitscheEigenEstimate(M2, M1, Rm, nUnc);
      nUncTot += nUnc;

      if (LPatch > 0. && !(APatch > 0.))
        throw runtime_error("localNitscheEstimation: cut element " + to_string(K) + " has no bulk in region "
                            + to_string(rInt) + " (patch of " + to_string(akp.size()) + " elements)");
      double Cgeo = (APatch > 0.) ? (lmi+2.*mui)*LPatch/APatch : 0.;

      double lmax = lEig;
      if (Cgeo > 0.)
      {
        if (!(lEig > 0.) || !std::isfinite(lEig))
        {
          lmax = Cgeo;
          nFallback++;
        }
        else
        {
          rMin = min(rMin, lEig/Cgeo);
          rMax = max(rMax, lEig/Cgeo);
          if (lEig < g_nitscheGeoLo*Cgeo)
          {
            lmax = g_nitscheGeoLo*Cgeo;
            nLo++;
          }
          else if (lEig > g_nitscheGeoHi*Cgeo)
          {
            lmax = g_nitscheGeoHi*Cgeo;
            nHi++;
          }
        }
      }
      else if (!(lEig > 0.) || !std::isfinite(lEig))
        nFallback++; // no boundary points in K: lmax unused by LSBorder

      backDHand->elemAuxF->setValue("l"+to_string(rInt),K,IndexType::Global,lmax);
    }

    cout << "Nitsche r" << rInt << ": " << cutEls.size() << " patches (" << nAgg << " with roots, max "
         << maxNM << " nodes), lambda/Cgeo in [" << (rMin < 1e300 ? rMin : 0.) << ", " << rMax << "], clamped lo "
         << nLo << " hi " << nHi << ", fallback " << nFallback << ", weak roots " << nWeakRoots
         << ", bad without root " << nNoRoots << ", uncontrolled DOFs " << nUncTot << endl;
  }
}


// *******************************************************************//
// *******************************************************************//
// *******************************************************************//
// *****                      MAIN FUNCTION                      *****//
// *******************************************************************//
// *******************************************************************//
// *******************************************************************//

int main(int argc, char** argv)
{

  hiperlife::Init(argc, argv);

  Params p;
  try
  {
    p = parseArgs(argc, argv);
  } catch (const std::exception& e)
  {
    std::cerr << "Error: " << e.what() << "\n";
    std::cerr << "Usage: " << argv[0]
           << " --rx <val> --ry <val> --mu0 <val> --lm0 <val>  --mu1 <val> --lm1 <val> --wpTh <val> --beta <val>"
           << " --levels <n> --load <val> --nLs <n>\n";
    return 1;
  }

  std::cout << "rx=" << p.rx << " ry=" << p.ry
      << " mu0=" << p.mu0 << " lm0=" << p.lm0
      << " mu1=" << p.mu1 << " lm1=" << p.lm1
      << " wpTh=" << p.wpTh  << " beta=" << p.beta
      << " load=" << p.load << " nLs=" << p.nLs << "\n";

  //============================ Parameters ============================//
  int nx = 100;
  int ny = nx;
  vector<int> nxt = {8, 16, 32, 64, 128};
  nxt.resize(std::max(1, std::min((int)nxt.size(), (int)p.levels)));

  SmartPtr<ParamStructure> paramStr = CreateParamStructure<HyElParams>();


  paramStr->setRealParameter(HyElParams::mu0,p.mu0);
  paramStr->setRealParameter(HyElParams::lm0,p.lm0);
  paramStr->setRealParameter(HyElParams::mu1,p.mu1);
  paramStr->setRealParameter(HyElParams::lm1,p.lm1);
  paramStr->setRealParameter(HyElParams::rx,p.rx);
  paramStr->setRealParameter(HyElParams::ry,p.ry);
  paramStr->setRealParameter(HyElParams::wpTh,p.wpTh);
  paramStr->setRealParameter(HyElParams::beta0,p.beta);


  // *******************************************************************//
  // *****                      MESH CREATION                      *****//
  // *******************************************************************//
  int nSteps = nxt.size();
  int bfOrder = 2;
  int timeStep = 0;
  bool ghP = 0;
  double wellPosedTh = p.wpTh;

  std::vector<double> ux0Nxt;
  std::vector<double> uy0Nxt;
  std::vector<double> ux1Nxt;
  std::vector<double> uy1Nxt;

  std::vector<double> Merr;
  std::vector<double> GMerr; 
  std::vector<double> Kerr; 
  std::vector<double> Terr; 
  std::vector<double> nTerr;
  std::vector<double> dMerr, dGMerr, dTMerr, dMiss, nrFail;
  const double nan = std::numeric_limits<double>::quiet_NaN();

  paramStr->setBoolParameter(HyElParams::postProcess,false);
  double beta0 = p.beta;

  if(ghP)
  {
    wellPosedTh = 0.5;
  }

  for (int nS{}; nS < nSteps; nS++)
  {
    paramStr->setIntParameter(HyElParams::timeStep,nS);
    //-------------------------- Background mesh -------------------------//
    double beta = beta0*nxt[nS]; // beta = 100/h (from 2017Badia)
    paramStr->setRealParameter(HyElParams::beta,beta);

    // Mesh generator
    SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
    back->genStructMesh(nxt[nS], nxt[nS]);
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0001;        

    SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();

    ElemType eTypeB = ElemType::Line; // Element type
    int bfOrderB = 3;   // Basis function order
    BasisFuncType bTypeB = BasisFuncType::BSplines; // Basis function type
    double rC = 0.7/sqrt(5.); // Radius of immersed mesh
    int nPtsCirc = 5*nxt[nS]; // Number of control points
    std::vector<std::vector<std::vector<std::vector<double>>>> CP(nPtsCirc, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
    std::vector<double> U(nPtsCirc+1,0);

    imm->setMesh(eTypeB, bTypeB, bfOrderB);
    genCircBspline(rC,U,CP,p.rx,p.ry,eTypeB,bTypeB,bfOrderB,nPtsCirc,paramStr);
    imm->genBsplinesClosedCurve(U,CP);


    SmartPtr<DistributedMesh> immProva = Create<DistributedMesh>("immMeshProva");
    immProva->setMesh(imm);
    immProva->setBalanceMesh(true);
    immProva->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immProva->setVerbosity(Verbosity::None);
    immProva->Update();
    // immProva->printFileLegacyVtk("meshProva");

    // Distributed mesh
    SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->Update();


    //--------------------------- Immersed mesh --------------------------//

    // Distributed mesh
    SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setImmersedInteriorPoints({{{0.5, 0.5, 0.0}},{{0.01,0.01,0}}});
    immMesh->setRegionTags({"Interior","Exterior"});
    immMesh->setBalanceMesh(true);
    immMesh->setIllPosThreshold(wellPosedTh);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->Update();

    // // Print meshes
    // backMesh->printFileLegacyVtk("meshBack");
    // immMesh->printFileLegacyVtk("meshImm");


    // *******************************************************************//
    // *****                   DOFsHandler CREATION                  *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"ux0","uy0","ux1","uy1"});
    backDHand->setNodeAuxF({"const","ctag","stab"});
    backDHand->setElemAuxF({"tag","WI","Agg0","gmm0","l0","GhP0","Agg1","gmm1","l1","GhP1","lE","stbP"});
    backDHand->setDofTags({"Interior","Interior","Exterior","Exterior"});
    backDHand->Update();

    // Save interior/cut/exterior flags for plotting
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
      int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
      backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
      vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
      vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
      for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
      {
        if (backDHand->mesh->isNodeInPart(nbors[n]))
          backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
      }
    }
    backDHand->UpdateGhosts();
    
    // Set boundary conditions
    for (int i{}; i < backMesh->nPts(); i++)
    {
      std::vector<double> x = backMesh->nodeCoords(i,IndexType::Global);
      if (true)
      {
          backDHand->nodeDOFs->setValue(0,i,IndexType::Local, 0);
          backDHand->nodeDOFs->setValue(1,i,IndexType::Local, 0);
          backDHand->nodeDOFs->setValue(2,i,IndexType::Local, 0);
          backDHand->nodeDOFs->setValue(3,i,IndexType::Local, 0);
        // // if ((int)backDHand->nodeAuxF->getValue("ctag",i)%3 == 0)
        // {
        //   backDHand->nodeDOFs->setValue(0,i,IndexType::Local, 0.2*sin(M_PI*x[0])*sin(M_PI*x[1]));
        //   backDHand->nodeDOFs->setValue(1,i,IndexType::Local, 0.2*sin(M_PI*x[0])*sin(M_PI*x[1]));
        // }
        // // else
        // {
        //   backDHand->nodeDOFs->setValue(2,i,IndexType::Local, 0.2*sin(M_PI*x[0])*sin(M_PI*x[1]));
        //   backDHand->nodeDOFs->setValue(3,i,IndexType::Local, 0.2*sin(M_PI*x[0])*sin(M_PI*x[1]));
        // }
      }
      else
      {
        // cout << fabs(0.2*sin(M_PI*x[0])*sin(M_PI*x[1])-ux0Nxt[i]) << endl;
        // cout << fabs(0.2*sin(M_PI*x[0])*sin(M_PI*x[1])-uy0Nxt[i]) << endl;
        // cout << fabs(0.2*sin(M_PI*x[0])*sin(M_PI*x[1])-ux1Nxt[i]) << endl;
        // cout << fabs(0.2*sin(M_PI*x[0])*sin(M_PI*x[1])-uy1Nxt[i]) << endl;
        backDHand->nodeDOFs->setValue(0,i,IndexType::Global,ux0Nxt[i]);
        backDHand->nodeDOFs->setValue(1,i,IndexType::Global,uy0Nxt[i]);
        backDHand->nodeDOFs->setValue(2,i,IndexType::Global,ux1Nxt[i]);
        backDHand->nodeDOFs->setValue(3,i,IndexType::Global,uy1Nxt[i]);
      }
      // if (backMesh->nodeCrease(i,IndexType::Global) > 0)
      {
        if (x[0]>0.9999 || x[0]<0.001 || x[1]>0.9999 || x[1]<0.001)
        {
          {
            backDHand->setConstraint(2,i,IndexType::Global,0.);
            backDHand->nodeDOFs->setValue(2,i,IndexType::Global,0.);

            backDHand->setConstraint(3,i,IndexType::Global,0.);
            backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.);
          }
        }

        // if (x[1]>0.999)
        // {
        //   backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.1);
        //   backDHand->setConstraint(3,i,IndexType::Global,0.);
        // }

        
        // if (x[1]<0.001)
        // {
        //   backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.);
        //   backDHand->setConstraint(3,i,IndexType::Global,0.);
        // }
      }
    }

    // // Compute facet pairs
    // std::vector<std::pair<int,int>> borderFacetPairsR0 = findBorderAdjacentPairs(backDHand, bfOrder,0);
    // std::vector<std::pair<int,int>> borderFacetPairsR1 = findBorderAdjacentPairs(backDHand, bfOrder,1);


    // *******************************************************************//
    // *****                    IMMERSED PROBLEM                     *****//
    // *******************************************************************//
    if (true)
    {
      // Immersed HiPerProblem
      SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
      //General setters
      immHP->setParameterStructure(paramStr);
      immHP->setGlobalIntegrals({"Area","Length","error","Gerror","uErr","duErr","tErr","dErr","dGerr","dtErr","dMiss","total_edge_length","Ray"});
      immHP->setDOFsHandlers({backDHand});

      // Set integration for the border
      immHP->setIntegration("IntegBorder", {"backDHand"});
      immHP->setCubatureBorderImmersed("IntegBorder", 10);
      immHP->setElementFillings("IntegBorder", LSBorder);

      // Set integration for Region 0
      immHP->setIntegration("IntegCavityV0", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV0", 9,5,"Interior");
      immHP->setElementFillings("IntegCavityV0", LSV0);

      // Set integration for Region 1
      immHP->setIntegration("IntegCavityV1", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV1", 9,5,"Exterior");
      immHP->setElementFillings("IntegCavityV1", LSV1);

      // if (ghP)
      // {
      //   // Face stabilization
      //   // Region 0
      //   immHP->setIntegration("IntegF0",{"backDHand"});
      //   immHP->setCubatureInteriorFacet("IntegF0", /*iPts=*/5, borderFacetPairsR0);
      //   immHP->setElementFillings("IntegF0", FacetStbR0);

      //   // Region 1
      //   immHP->setIntegration("IntegF1",{"backDHand"});
      //   immHP->setCubatureInteriorFacet("IntegF1", /*iPts=*/5, borderFacetPairsR1);
      //   immHP->setElementFillings("IntegF1", FacetStbR1);
      // }

      
      immHP->Update();


      //-------------------------- Immersed solver -------------------------//
      SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
      immSOL->setHiPerProblem(immHP);
      immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
      immSOL->setDefaultParameters();
      // immSOL->setWorkSpaceMemoryIncrease(200);
      immSOL->Update();

      //------------------ Non-linear solver creation ------------------//

      SmartPtr<NewtonRaphsonNonlinearSolver> nonLinSolver = Create<NewtonRaphsonNonlinearSolver>();
      nonLinSolver->setLinearSolver(immSOL);
      nonLinSolver->setConvRelTolerance(true);
      nonLinSolver->setMaxNumIterations(10);
      nonLinSolver->setResTolerance(1e-7);
      nonLinSolver->setSolTolerance(1e-8);
      nonLinSolver->setResMaximum(1e5);
      nonLinSolver->setSolMaximum(1e5);
      nonLinSolver->setExitRelMaximum(true);
      nonLinSolver->setLineSearch(true);
      // nonLinSolver->setLineSearchEnergyMethod("Ray");
      nonLinSolver->setPrintSummary(false);
      nonLinSolver->setPrintIntermInfo(true);
      nonLinSolver->Update();

      //---------------------------- Solve immersed ------------------------//
      // Solve
      // immHP->FillLinearSystem();
      paramStr->setBoolParameter(HyElParams::approxStep,false);
      int nLs = std::max(1, (int)p.nLs); // Number of load steps, up to load factor p.load
      bool converged;
      int nFail = 0;
      for (int ls = 0; ls < nLs; ls++)
      {
        localNitscheEstimation(immHP, backDHand, paramStr, immMesh);
        paramStr->setRealParameter(HyElParams::loadStep,p.load*double(ls+1.)/double(nLs));
        converged = nonLinSolver->solve();
        immHP->UpdateGhosts();
        if (!converged)
        {
          nFail++;
          cout << "Newton not converged: 1/h = " << nxt[nS] << ", load step " << ls+1 << "/" << nLs << endl;
        }
      }

      // paramStr->setBoolParameter(HyElParams::approxStep,false);
      // converged = nonLinSolver->solve();
      // immHP->UpdateGhosts();
      string meshName = to_string(nS);

                  
      // Print
      string solName = "solBack."+buildFilename(p)+"."+to_string(nS);
      backDHand->printFileLegacyVtk(solName, true);
      string immMshName = "meshImm."+buildFilename(p)+"."+to_string(nS);
      immMesh->printFileLegacyVtk(immMshName);

      paramStr->setBoolParameter(HyElParams::postProcess,true);
      immHP->FillLinearSystem();
      paramStr->setBoolParameter(HyElParams::postProcess,false);

      double error = immHP->globalIntegral("error");
      std::cout << "error: " << sqrt(error) << std::endl;
      double Uerror = immHP->globalIntegral("uErr");
      std::cout << "U border error: " << sqrt(Uerror) << std::endl;
      double dUerror = immHP->globalIntegral("duErr");
      std::cout << "dU*n border error: " << sqrt(dUerror) << std::endl;
      double Terror = immHP->globalIntegral("tErr");
      std::cout << "dU*n border error: " << sqrt(Terror) << std::endl;
      Merr.push_back(sqrt(error));
      GMerr.push_back(sqrt(immHP->globalIntegral("Gerror")));
      Kerr.push_back(sqrt(Uerror));
      Terr.push_back(sqrt(dUerror));
      nTerr.push_back(sqrt(Terror));
      dMerr.push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dErr")) : nan);
      dGMerr.push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dGerr")) : nan);
      dTMerr.push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dtErr")) : nan);
      dMiss.push_back(g_coarse.valid ? immHP->globalIntegral("dMiss") : nan);
      nrFail.push_back(nFail);

      // This level is the reference of the next one
      setCoarseLevel(backDHand, immMesh, nxt[nS]);

      // Store solution for initial condition
      if (nS+1 < nSteps)
      {
        SmartPtr<StructMeshGenerator> backNxt = Create<StructMeshGenerator>();
        backNxt->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
        backNxt->genStructMesh(nxt[nS+1], nxt[nS+1]);
        
        // Distributed mesh
        SmartPtr<DistributedMesh> backMeshNxt = Create<DistributedMesh>("backMesh");
        backMeshNxt->setMesh(backNxt);
        backMeshNxt->setBalanceMesh(true);
        backMeshNxt->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        backMeshNxt->setVerbosity(Verbosity::None);
        backMeshNxt->Update();

        ux0Nxt.resize(backMeshNxt->nPts());
        uy0Nxt.resize(backMeshNxt->nPts());
        ux1Nxt.resize(backMeshNxt->nPts());
        uy1Nxt.resize(backMeshNxt->nPts());
        for (int i = 0; i < backMeshNxt->nPts(); i++)
        {
          vector<double> x = backMeshNxt->nodeCoords(i);
          ux0Nxt[i] = backDHand->interpolateDOFs("ux0",x);
          uy0Nxt[i] = backDHand->interpolateDOFs("uy0",x);
          ux1Nxt[i] = backDHand->interpolateDOFs("ux1",x);
          uy1Nxt[i] = backDHand->interpolateDOFs("uy1",x);
        }
      }
    }
  }
  g_coarse = CoarseLevel();

  // Column headers
    cout << left
         << setw(20) << "1/h"
         << setw(20)  << "M Err"
         << setw(20)  << "GM Err"
         << setw(20) << "K Err"
         << setw(20) << "T Err"
         << setw(20) << "nT Err"
         << setw(20) << "dM Err"
         << setw(20) << "dGM Err"
         << setw(20) << "dTM Err"
         << setw(20) << "dMiss"
         << setw(20) << "NR fail"
         << endl;

    // Separator line
    cout << string(30, '-') << endl;

  for(int nS = 0; nS < nxt.size(); nS++)
  {
    cout << left << setw(20) <<  nxt[nS] <<  setw(20) <<  Merr[nS]  << setw(20) << GMerr[nS] << setw(20) << Kerr[nS] << setw(20) << Terr[nS] << setw(20) << nTerr[nS]
         << setw(20) << dMerr[nS] << setw(20) << dGMerr[nS] << setw(20) << dTMerr[nS] << setw(20) << dMiss[nS] << setw(20) << nrFail[nS] << endl;
  }

  hiperlife::Finalize();
  return 0;
}