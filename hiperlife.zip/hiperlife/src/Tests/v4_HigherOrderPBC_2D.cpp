
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_PredefinedElementFillings.h"
#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_TimeIterator.h"

#include "hl_FillStructure.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS_Border(RCP<FillStructure> fillStr)
{
    //***********************************************************
    // Initialize
    //***********************************************************

    // Parameters
    double eps2   = fillStr->userStr->CahnHilliard.epsilon2;

    // Rename variables
    SubFillStructure& subFill = (*fillStr)[0];
    int eNN   = subFill.eNN;       // Number of neighbor nodes
    int nDim  = subFill.nDim;      // Number of spatial dimensions
    int pDim  = subFill.pDim;      // Number of parametric dimension
    vector<double>& nborCoords  = subFill.nborCoords;  // Vector of node coordinates
    double* nborDOFs  = subFill.nborDOFs.data();
    double* bf    = subFill.nborBFs(); // Local shape function
    double* gbf_l = subFill.nborBFsDers(1); // Local shape function derivatives

    //***********************************************************
    // Compute values and functions at integration points
    //***********************************************************

    // Compute tangent map
    double Ip[4], xu[3], xv[3];
    SurfLagrParam::MetricTensor(Ip, xu, xv, eNN, nborCoords.data(), gbf_l);

    // Compute normal
    double jac{}, bTangent[3]={};
    vector<double> n(3, 0.0);
    auto bTangentRef = subFill.tangentsBoundaryRef();
    if (pDim == 1)
    {
        // Compute tangent
        jac = 1.0;

        //Outward unitary normal
        n[0] = -bTangentRef[0];
    }
    else if (pDim == 2)
    {
        // Compute tangent
        for (int n = 0; n < nDim; n++)
            bTangent[n] = bTangentRef[0] * xu[n] + bTangentRef[1] * xv[n];
        jac = Math::Norm3D(bTangent);

        //Outward unitary normal
        n[0] =  bTangent[1]/jac;
        n[1] = -bTangent[0]/jac;
    }
    else
    {
        throw runtime_error("LS_Border:: pDim = 3 not implemented");
    }

    // Shape functions and derivatives at Gauss points
    double jac2;
    vector<double> gbf(eNN*pDim), hbf(eNN*pDim*pDim), lapbf(eNN);
    GlobalBasisFunctions::hessians(gbf.data(), jac2, hbf.data(), lapbf.data(), subFill);

    // Values at integration points
    double c{}, lapc{};
    vector<double> gc(pDim, 0.0);
    vector<double> ngbf(eNN, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        // Values
        c += nborDOFs[i] * bf[i];

        //Gradient
        for (int d = 0; d < pDim; d++)
        {
            gc[d] += nborDOFs[i] * gbf[pDim*i+d];
            ngbf[i] += gbf[pDim*i+d] * n[d];
        }

        //Hessians
        lapc += nborDOFs[i] * lapbf[i];
    }

    // Normal · gradient of c
    double ngc{};
    for (int d = 0; d < pDim; d++)
        ngc += gc[d]*n[d];

    // Mobility and derivatives
    double mob{}, dmob{};
    if (fillStr->userStr->CahnHilliard.mobility != nullptr)
    {
        vector<double> mobility = fillStr->userStr->CahnHilliard.mobility(c);
        mob   = mobility[0];
        dmob  = mobility[1];
    }
    else
    {
        mob = fillStr->userStr->CahnHilliard.constantMobility;
    }


    //***********************************************************
    // Fill linear system
    //***********************************************************
    for (int i = 0; i < eNN; i++)
    {
        fillStr->Bk(0)[i] -= jac * eps2 * mob * lapc     * ngbf[i];
        fillStr->Bk(0)[i] += jac * eps2 * mob * lapbf[i] * ngc;

        for (int j = 0; j < eNN; j++)
        {
            fillStr->Ak(0, 0)[i*eNN+j] -= jac * eps2 * dmob * bf[j] * lapc * ngbf[i];
            fillStr->Ak(0, 0)[i*eNN+j] -= jac * eps2 * mob * lapbf[j] * ngbf[i];
            fillStr->Ak(0, 0)[i*eNN+j] += jac * eps2 * dmob * bf[j] * lapbf[i] * ngc;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * eps2 * mob * lapbf[i] * ngbf[j];
        }
    }

    return;
}

int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    MPI_Init(nullptr, nullptr);

    // Put parameters in the user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    // userStr->Poisson.source = [](double x, double y, double z){return x*x*10.0;};
    userStr->Poisson.source = [](double x, double y, double z){
                                  if (abs(y) < 0.05  )
                                      return 0.0*x*x*x*x*10.0;
                                  else
                                      return 0.0;
                              };
    userStr->TransientDiffusion.source = userStr->Poisson.source;
    userStr->TransientDiffusion.diffusionCoefficient = 0.10;
    userStr->CahnHilliard.epsilon2 = 0.00005*4;
    userStr->CahnHilliard.constantMobility = 1.0;
    // userStr->CahnHilliard.mobility = [](double c)->vector<double>
    // {
    //     return {c*(1-c), 1-2*c};
    // };
    //userStr->CahnHilliard.doubleWell = [](double c)->vector<double>
    // {
    //     return {0, 0, 1.0/(c*(1.0-c)) - 2.0*3.0, (2.0*c-1.0)/(c*c*(1.0-c)*(1.0-c))};
    //};
    userStr->CahnHilliard.doubleWell = [](double c)->vector<double>
    {
        return {(c*c)*(1.0-c)*(1.0-c)/4.0,
                c*(1.0-c)*(1.0-2.0*c)/2.0,
                (1.0-6.0*c+6.0*c*c)/2.0,
                (-1.0+2.0*c)*3.0};
    };


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create a line structured mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(ElemType::Square, BasisFuncType::BSplines, 1);
    // structMesh->setPeriodicBoundaryCondition({Axis::Xaxis});
    structMesh->genStructMesh(10);
    // structMesh->genRectangularParallelepiped(10, 10, 6, 0.1, 0.1, 0.1);
    // structMesh->unclamp(Axis::Xaxis);
    // structMesh->printMesh("after");

    // Distribute the mesh among all the processors
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(false);
    disMesh->Update();
    disMesh->printFileLegacyVtk("mesh");


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Create a DOFsHandler with one degree of freedom (c)
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"u"});
    dhand->Update();

    // Set initial and boundary conditions for the DOF
    // srand(time(NULL));
    srand(13);
    // dhand->setInitialCondition("u",
    //                              [](double x, double y)
    //                              {
    //                                  double r = sqrt(x*x + y*y);
    //                                  double d = sqrt((r-0.6)*(r-0.6));
    //                                  return 6.25*d*d-1.0;
    //                              });
    dhand->setInitialCondition("u", [=](double x, double y, double z){
                                        if (x <= 0.2 or x >= 0.8 or y <= 0.2 or y >= 0.8)
                                        {
                                            return 0.63;
                                        }
                                        else
                                        {
                                            double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
                                            return 0.63+0.1*r;
                                        }
                                        // double u = 0.5-0.5*tanh((sqrt((x-0.5)*(x-0.5))-0.25)/(sqrt(2*0.001)));
                                        // return u*(0.63+0.05*r);
                                    });

    dhand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // number of dimensions
    int nDim = computePDim(dhand->mesh->elemType());

    int numPGauss = pow(3,nDim);

    // hiperproblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setElementFillings("Integ", PredefinedElementFillings::TransientDiffusion);
    hiperProbl->setCubatureGauss("Integ", numPGauss);
    //hiperProbl->setIntegration("Border", {"dhand"});
    // // hiperProbl->setCubatureBorderGauss("Border", 4);
    //hiperProbl->setCubatureBorderGauss("Border", 4, {MAxis::Ymax, MAxis::Ymin, MAxis::Zmax, MAxis::Zmin});
    // hiperProbl->setCubatureBorderGauss("Border", 4, {MAxis::Xmax, MAxis::Xmin});
    //hiperProbl->setElementFillings("Border", LS_Border);

    // **************************************************************//
    // *****               PERIODICITY                          *****//
    // **************************************************************//

    // number of degrees of freedom
    int numDofs = dhand->numDOFs();

    // order of the basis functions
    int order = dhand->mesh->_bfOrderX;

    // number of elements in X axis
    int nEx = dhand->mesh->_nElemX;

    // number of control points in X axis
    int nnx = nEx + dhand->mesh->_bfOrderX;

    // number of control points in Y axis
    int nny = 1;

    // number of elements in Y axis
    int nEy = 0;
    if (nDim >= 2)
    {
        nEy = dhand->mesh->_nElemY;
        nny = nEy + dhand->mesh->_bfOrderY;
    }

    // number of control points in Z axis
    int nnz = 1;

    // number of elements in Z axis
    int nEz = 0;

    if (nDim == 3)
    {
        nEz = dhand->mesh->_nElemZ;
        nnz = nEz + dhand->mesh->_bfOrderZ;
    }

    bool Xperiodic = true;
    bool Yperiodic = true;
    bool Zperiodic = false;
    
    if (nDim == 1) 
    {
        Yperiodic = false;
        Zperiodic = false;
    }

    for (int DOF = 0; DOF < numDofs; DOF++)
    {

        if (nDim == 1 and Xperiodic)
        {  
            int fid = 0;
            int sid = 1;
            int pid = nnx - 2;
            int lid = nnx - 1;

            // continuity constraint
            hiperProbl->setLinearConstraint({0, DOF, lid, IndexType::Global},
                                    {0, DOF, fid, IndexType::Global}, 1.0, 0.0);
            if (order == 2)
            {
                // second order continuity constraint
                hiperProbl->setLinearConstraint({0, DOF, pid, IndexType::Global},
                                    {{0, DOF, fid, IndexType::Global}, {0, DOF, sid, IndexType::Global}},
                                    {2.0, -1.0});
            }
        }
        else if (nDim == 2)
        {   
            // left bottom square
            int ff = 0;
            int sf = 1;
            int fs = nnx;
            int ss = fs + 1;

            // right bottom square
            int lf = nnx - 1;
            int pf = lf - 1;
            int ps = pf + nnx;
            int ls = ps + 1;

            // right top square
            int ll = nnx*nny - 1;
            int lp = ll - nnx;
            int pp = lp - 1;
            int pl = ll - 1;

            // left top square
            int fl = lp + 1;
            int sl = fl + 1;
            int fp = fl - nnx;
            int sp = fp + 1;

            if (Xperiodic and Yperiodic)
            {
                // corners periodicity constraint
                hiperProbl->setLinearConstraint({0, DOF, ff, IndexType::Global},
                                                {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                hiperProbl->setLinearConstraint({0, DOF, fl, IndexType::Global},
                                                {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                hiperProbl->setLinearConstraint({0, DOF, lf, IndexType::Global},
                                                {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                
                if (order == 2)
                {
                    // neighbors continuity
                    hiperProbl->setLinearConstraint({0, DOF, fs, IndexType::Global},
                                                    {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, fp, IndexType::Global},
                                                    {0, DOF, lp, IndexType::Global}, 1.0, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, sf, IndexType::Global},
                                                    {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, pf, IndexType::Global},
                                                    {0, DOF, pl, IndexType::Global}, 1.0, 0.0);
                
                    // neighbors second order continuity
                    hiperProbl->setLinearConstraint({0, DOF, ss, IndexType::Global},
                                                    {{0, DOF, pl, IndexType::Global}, {0, DOF, ll, IndexType::Global},
                                                    {0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                    {-2.0, 4.0, -2.0, 1.0}, 0.0);

                    hiperProbl->setLinearConstraint({0, DOF, sp, IndexType::Global},
                                                    {{0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);

                    hiperProbl->setLinearConstraint({0, DOF, ps, IndexType::Global},
                                                    {{0, DOF, pl, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                
                

                    //continuidad orden 2 esquina
                    hiperProbl->setLinearConstraint({0, DOF, sl, IndexType::Global},
                                                    {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, ls, IndexType::Global},
                                                    {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                }

                // y-axis periodic linear constraints not in corner
                for (int i = order; i < nnx-order; i++)
                {
                    int fid = i;
                    int sid = i + nnx;

                    // should create p points at each side

                    int lid = fid + nnx*(nny-1);
                    int pid = lid - nnx;

                    hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                    {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                    if (order == 2)
                    {
                        hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                    {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                    }    
                }

                // x-axis periodic linear constraints linear constraints not in corner
                for (int j = order; j < nny-order; j++)
                {
                    int fid = nnx*j;
                    int sid = fid + 1;

                    // should create p points at each side

                    int lid = fid + nnx - 1;
                    int pid = lid - 1;

                    hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                    {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                    if (order == 2)
                    {
                        hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                    {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                    }
                    
                }
            }
            else if (Yperiodic)
            {
                for (int i = 0; i < nnx; i++)
                {
                    int fid = i;
                    int sid = i + nnx;

                    // should create p points at each side

                    int lid = fid + nnx*(nny-1);
                    int pid = lid - nnx;

                    hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                    {0, DOF, lid, IndexType::Global}, 1.0, 0.0);
                    
                    if (order == 2)
                    {
                        hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                    {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                    }
                    
                }
            }
            else if (Xperiodic)
            {
                for (int j = 0; j < nny; j++)
                {
                    int fid = nnx*j;
                    int sid = fid + 1;

                    // should create p points at each side

                    int lid = fid + nnx - 1;
                    int pid = lid - 1;

                    hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                    {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                    if (order == 2) 
                    {
                        hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                    {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                    {2.0, -1.0}, 0.0);
                    }
                }
            }
        }
        else if (nDim == 3)
        {
            if (Xperiodic and Yperiodic and Zperiodic)
            {

            } else if (Xperiodic and Yperiodic)
            {
                for (int i = 0; i < nnz; i++) {
                    // left bottom square
                    int ff = i*nnx*nny;
                    int sf = ff + 1;
                    int fs = ff + nnx;
                    int ss = fs + 1;

                    // right bottom square
                    int lf = ff + nnx - 1;
                    int pf = lf - 1;
                    int ps = pf + nnx;
                    int ls = ps + 1;

                    // right top square
                    int ll = ff + nnx*nny - 1;
                    int lp = ll - nnx;
                    int pp = lp - 1;
                    int pl = ll - 1;

                    // left top square
                    int fl = lp + 1;
                    int sl = fl + 1;
                    int fp = fl - nnx;
                    int sp = fp + 1;

                    // corners periodicity constraint
                    hiperProbl->setLinearConstraint({0, DOF, ff, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, fl, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, lf, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    
                    if (order == 1) 
                    {
                        // neighbors continuity
                        hiperProbl->setLinearConstraint({0, DOF, fs, IndexType::Global},
                                                        {0, DOF, ls, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, fp, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, sf, IndexType::Global},
                                                        {0, DOF, sl, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, pf, IndexType::Global},
                                                        {0, DOF, pl, IndexType::Global}, 1.0, 0.0);
                    } else if (order == 2)
                    {
                        // neighbors continuity
                        hiperProbl->setLinearConstraint({0, DOF, fs, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, fp, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, sf, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, pf, IndexType::Global},
                                                        {0, DOF, pl, IndexType::Global}, 1.0, 0.0);
                    
                        // neighbors second order continuity
                        hiperProbl->setLinearConstraint({0, DOF, ss, IndexType::Global},
                                                        {{0, DOF, pl, IndexType::Global}, {0, DOF, ll, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {-2.0, 4.0, -2.0, 1.0}, 0.0);

                        hiperProbl->setLinearConstraint({0, DOF, sp, IndexType::Global},
                                                        {{0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);

                        hiperProbl->setLinearConstraint({0, DOF, ps, IndexType::Global},
                                                        {{0, DOF, pl, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                    
                    

                        //continuidad orden 2 esquina
                        hiperProbl->setLinearConstraint({0, DOF, sl, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, ls, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                    }

                        // y-axis periodic linear constraints not in corner
                        for (int j = order; j < nnx-order; j++)
                        {
                            int fid = j + ff;
                            int sid = fid + nnx;

                            // should create p points at each side

                            int lid = fid + nnx*(nny-1);
                            int pid = lid - nnx;

                            hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                            {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                            if (order == 2)
                            {
                                hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                            {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                            {2.0, -1.0}, 0.0);
                            }    
                        }

                        // x-axis periodic linear constraints linear constraints not in corner
                        for (int j = order; j < nny-order; j++)
                        {
                            int fid = ff + nnx*j;
                            int sid = fid + 1;

                            // should create p points at each side

                            int lid = fid + nnx - 1;
                            int pid = lid - 1;

                            hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                            {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                            if (order == 2)
                            {
                                hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                            {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                            {2.0, -1.0}, 0.0);
                            }
                            
                        }
                }
            } else if (Xperiodic and Zperiodic)
            {
                for (int i = 0; i < nny; i++) {
                    // left bottom square
                    int ff = i*nnx;
                    int sf = ff + 1;
                    int fs = ff + nnx*nny;
                    int ss = fs + 1;

                    // right bottom square
                    int lf = ff + nnx - 1;
                    int pf = lf - 1;
                    int ps = pf + nnx*nny;
                    int ls = ps + 1;

                    // right top square
                    int ll = ff + nnx*nny*(nnz - 1) + nnx - 1;
                    int lp = ll - nnx*nny;
                    int pp = lp - 1;
                    int pl = ll - 1;

                    // left top square
                    int fl = ff + nnx*nny*(nnz - 1);
                    int sl = fl + 1;
                    int fp = fl - nnx*nny;
                    int sp = fp + 1;

                    // corners periodicity constraint
                    hiperProbl->setLinearConstraint({0, DOF, ff, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, fl, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, lf, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    
                    if (order == 1) 
                    {
                        // neighbors continuity
                        hiperProbl->setLinearConstraint({0, DOF, fs, IndexType::Global},
                                                        {0, DOF, ls, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, fp, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, sf, IndexType::Global},
                                                        {0, DOF, sl, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, pf, IndexType::Global},
                                                        {0, DOF, pl, IndexType::Global}, 1.0, 0.0);
                    } else if (order == 2)
                    {
                        // neighbors continuity
                        hiperProbl->setLinearConstraint({0, DOF, fs, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, fp, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, sf, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, pf, IndexType::Global},
                                                        {0, DOF, pl, IndexType::Global}, 1.0, 0.0);
                    
                        // neighbors second order continuity
                        hiperProbl->setLinearConstraint({0, DOF, ss, IndexType::Global},
                                                        {{0, DOF, pl, IndexType::Global}, {0, DOF, ll, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {-2.0, 4.0, -2.0, 1.0}, 0.0);

                        hiperProbl->setLinearConstraint({0, DOF, sp, IndexType::Global},
                                                        {{0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);

                        hiperProbl->setLinearConstraint({0, DOF, ps, IndexType::Global},
                                                        {{0, DOF, pl, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                    
                    

                        //continuidad orden 2 esquina
                        hiperProbl->setLinearConstraint({0, DOF, sl, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, ls, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                    }

                        // z-axis periodic linear constraints not in corner
                        for (int j = order; j < nnx-order; j++)
                        {
                            int fid = j + ff;
                            int sid = fid + nnx*nny;

                            // should create p points at each side

                            int lid = fid + nnx*nny*(nnz - 1);
                            int pid = lid - nnx*nny;

                            hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                            {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                            if (order == 2)
                            {
                                hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                            {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                            {2.0, -1.0}, 0.0);
                            }    
                        }

                        // x-axis periodic linear constraints linear constraints not in corner
                        for (int j = order; j < nnz-order; j++)
                        {
                            int fid = ff + nnx*nny*j;
                            int sid = fid + 1;

                            // should create p points at each side

                            int lid = fid + nnx - 1;
                            int pid = lid - 1;

                            hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                            {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                            if (order == 2)
                            {
                                hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                            {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                            {2.0, -1.0}, 0.0);
                            }
                            
                        }
                }

            } else if (Yperiodic and Zperiodic)
            {
                for (int i = 0; i < nnx; i++) {
                    // left bottom square
                    int ff = i;
                    int sf = ff + nnx;
                    int fs = ff + nnx*nny;
                    int ss = fs + nnx;

                    // right bottom square
                    int lf = ff + nnx*(nny - 1);
                    int pf = lf - nnx;
                    int ps = pf + nnx*nny;
                    int ls = ps + nnx;

                    // left top square
                    int fl = ff + nnx*nny*(nnz - 1);
                    int sl = fl + nnx;
                    int fp = fl - nnx*nny;
                    int sp = fp + nnx;

                    // right top square
                    int ll = fl + nnx*(nny - 1);
                    int lp = ll - nnx*nny;
                    int pp = lp - nnx;
                    int pl = ll - nnx;

                    // corners periodicity constraint
                    hiperProbl->setLinearConstraint({0, DOF, ff, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, fl, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    hiperProbl->setLinearConstraint({0, DOF, lf, IndexType::Global},
                                                    {0, DOF, ll, IndexType::Global}, 1.0, 0.0);
                    
                    if (order == 1) 
                    {
                        // neighbors continuity
                        hiperProbl->setLinearConstraint({0, DOF, fs, IndexType::Global},
                                                        {0, DOF, ls, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, fp, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, sf, IndexType::Global},
                                                        {0, DOF, sl, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, pf, IndexType::Global},
                                                        {0, DOF, pl, IndexType::Global}, 1.0, 0.0);
                    } else if (order == 2)
                    {
                        // neighbors continuity
                        hiperProbl->setLinearConstraint({0, DOF, fs, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, fp, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, 1.0, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, sf, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, pf, IndexType::Global},
                                                        {0, DOF, pl, IndexType::Global}, 1.0, 0.0);
                    
                        // neighbors second order continuity
                        hiperProbl->setLinearConstraint({0, DOF, ss, IndexType::Global},
                                                        {{0, DOF, pl, IndexType::Global}, {0, DOF, ll, IndexType::Global},
                                                        {0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {-2.0, 4.0, -2.0, 1.0}, 0.0);

                        hiperProbl->setLinearConstraint({0, DOF, sp, IndexType::Global},
                                                        {{0, DOF, lp, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);

                        hiperProbl->setLinearConstraint({0, DOF, ps, IndexType::Global},
                                                        {{0, DOF, pl, IndexType::Global}, {0, DOF, pp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                    
                    

                        //continuidad orden 2 esquina
                        hiperProbl->setLinearConstraint({0, DOF, sl, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, pl, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        hiperProbl->setLinearConstraint({0, DOF, ls, IndexType::Global},
                                                        {{0, DOF, ll, IndexType::Global}, {0, DOF, lp, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                    }

                        // y-axis periodic linear constraints not in corner
                        for (int j = order; j < nnz-order; j++)
                        {
                            int fid = j*nnx*nny + ff;
                            int sid = fid + nnx;

                            // should create p points at each side

                            int lid = fid + nnx*(nny-1);
                            int pid = lid - nnx;

                            hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                            {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                            if (order == 2)
                            {
                                hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                            {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                            {2.0, -1.0}, 0.0);
                            }    
                        }

                        // z-axis periodic linear constraints linear constraints not in corner
                        for (int j = order; j < nny-order; j++)
                        {
                            int fid = ff + nnx*j;
                            int sid = fid + nnx*nny;

                            // should create p points at each side

                            int lid = fid + nnx*nny*(nnz - 1);
                            int pid = lid - nnx*nny;

                            hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                            {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                            if (order == 2)
                            {
                                hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                            {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                            {2.0, -1.0}, 0.0);
                            }
                            
                        }
                }

            } else if (Xperiodic)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnz; i++)
                    {                    
                        int fid = nnx*j + (nnx*nny)*i;
                        int sid = fid + 1;

                        // should create p points at each side

                        int lid = fid + nnx - 1;
                        int pid = lid - 1;

                        hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                        {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                        if (order == 2) 
                        {
                            hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                        {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        }
                    }
                }
            } else if (Yperiodic)
            {
                for (int j = 0; j < nnx; j++)
                {
                    for (int i = 0; i < nnz; i++)
                    {                    
                        int fid = j + i*(nnx*nny);
                        int sid = fid + nnx;

                        // should create p points at each side

                        int lid = fid + nnx*(nny-1);
                        int pid = lid - nnx;

                        hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                        {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                        if (order == 2) 
                        {
                            hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                        {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        }
                    }
                }
            } else if (Zperiodic)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {                    
                        int fid = i + j*(nnx);
                        int sid = fid + nnx*nny;

                        // should create p points at each side

                        int lid = fid + nnx*nny*(nnz-1);
                        int pid = lid - nnx*nny;

                        hiperProbl->setLinearConstraint({0, DOF, fid, IndexType::Global},
                                                        {0, DOF, lid, IndexType::Global}, 1.0, 0.0);

                        if (order == 2) 
                        {
                            hiperProbl->setLinearConstraint({0, DOF, sid, IndexType::Global},
                                                        {{0, DOF, lid, IndexType::Global}, {0, DOF, pid, IndexType::Global}},
                                                        {2.0, -1.0}, 0.0);
                        }
                    }
                }
            }


        }
    }

    hiperProbl->Update();

    // Linear solver
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // RCP<AztecOOIterativeLinearSolver> linSolver = rcp(new AztecOOIterativeLinearSolver());
    // linSolver->setHiPerProblem(hiperProbl);
    // linSolver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // linSolver->setPrecond(AztecOOIterativeLinearSolver::Precond::DomainDecomp);
    // linSolver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
    // linSolver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
    // linSolver->setDefaultParameters();
    // linSolver->Update();

    // linSolver->solve();
    // linSolver->UpdateSolution();
    // dhand->printFileLegacyVtk("sol");
    // MPI_Finalize();
    // return 0;

    // RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp (new NewtonRaphsonNonlinearSolver());
    // nonlinSolver->setLinearSolver(linSolver);
    // nonlinSolver->setMaxNumIterations(10);
    // nonlinSolver->setResTolerance(1.E-5);
    // nonlinSolver->setSolTolerance(1.E-5);
    // nonlinSolver->setLineSearch(false);
    // nonlinSolver->setConvRelTolerance(true);
    // nonlinSolver->setPrintIntermInfo(true);
    // nonlinSolver->setPrintSummary(false);
    // nonlinSolver->Update();

    auto post = [dhand, nnx, nny, nnz, Xperiodic, Yperiodic, Zperiodic, order](){
        // Check in x-direction
        if (Xperiodic)
        {
            for (int j = 0; j < nny; j++)
            {   
                int fid = nnx*j;
                int sid = fid + 1;

                // should create p points at each side

                int lid = fid + nnx - 1;
                int pid = lid - 1;

                // Get values
                double f = dhand->nodeDOFs->getValue(0, fid, IndexType::Local);
                double l = dhand->nodeDOFs->getValue(0, lid, IndexType::Local);
                double s = dhand->nodeDOFs->getValue(0, sid, IndexType::Local);
                double p = dhand->nodeDOFs->getValue(0, pid, IndexType::Local);

                // Check differences
                cout << setprecision(8);
                if (f != l)
                    cout << "First and last are different in X (" << j << "): " << fid << "=" << f << "; " << lid << "=" << l << endl;
                if (abs(f - (s+p)/2.0) > 1e-12 and order == 2)
                    cout << "Not in plane in X (" << j << "): " << f << " " << l << " " << s << " " << p << " " << (s+p)/2.0 << endl;

            }
        }

        // Check in y direction
        if (Yperiodic)
        {
            for (int i = 0; i < nnx; ++i)
            {
                int fid = i;
                int sid = i + nnx;
                int lid = fid + nnx*(nny-1);
                int pid = lid - nnx;

                // Get values
                double f = dhand->nodeDOFs->getValue(0, fid, IndexType::Local);
                double l = dhand->nodeDOFs->getValue(0, lid, IndexType::Local);
                double s = dhand->nodeDOFs->getValue(0, sid, IndexType::Local);
                double p = dhand->nodeDOFs->getValue(0, pid, IndexType::Local);

                // Check differences
                cout << setprecision(8);
                if (f != l)
                    cout << "First and last are different in Y (" << i << "): " << fid << "=" << f << "; " << lid << "=" << l << endl;
                if (abs(f - (s+p)/2.0) > 1e-12 and order == 2)
                    cout << "Not in plane in Y (" << i << "): " << f << " " << l << " " << s << " " << p << " " << (s+p)/2.0 << endl;
            }
        }
    };

    // Time iterator
    RCP<TimeIterator> tIterator = rcp(new TimeIterator);
    tIterator->setLinearSolver(linSolver);
    // tIterator->setNonlinearSolver(nonlinSolver);
    tIterator->setTimeStepSize(1e-4);
    tIterator->setStopCriteria(4000, 1e8, 1e-12);
    tIterator->setTimeSteppingScheme(TimeSteppingScheme::AdaptiveLinear);
    tIterator->setLinearStepFactor(1.05, 0.9);
    tIterator->setMaximumTimeStepSize(0.1*10);
    tIterator->setPrintToFile(PrintToFileMethod::LegacyVtk, 2, "higherOrderPBC");
    // tIterator->setPrintRestart(10, "restart");
    tIterator->setPostprocess(
        1, post);
    tIterator->Update();


    // **************************************************************//
    // *****                       SOLVE                        *****//
    // **************************************************************//

    post();
    tIterator->Iterate();

    // **************************************************************//
    // *****                      FINALIZE                      *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
