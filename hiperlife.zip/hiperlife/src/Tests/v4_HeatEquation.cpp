
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_TimeIterator.h"

#include "hl_FillStructure.h"
#include "hl_GlobalBasisFunctions.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<FillStructure> fillStr);

int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    MPI_Init(nullptr, nullptr);

    // Model parameters
    double source = 10.0;

    // Time parameters
    int maxSteps   = 5000;
    double maxTime = 1000.0;

    // Put parameters in the user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(2);
    userStr->dparam[1] = source;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create a line structured mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    structMesh->genAnnularSector(100, 100, 0.2, 1.0, M_PI/2.0);

    // Distribute the mesh among all the processors
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Create a DOFsHandler with one degree of freedom (c)
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"u"});
    dhand->Update();

    // Set initial and boundary conditions for the DOF
    dhand->setInitialCondition("u",
                                 [](double x, double y)
                                 {
                                     double r = sqrt(x*x + y*y);
                                     double d = sqrt((r-0.6)*(r-0.6));
                                     return 6.25*d*d-1.0;
                                 });
    dhand->setBoundaryCondition("u", MAxis::Xmin, 0.0);
    dhand->setBoundaryCondition("u", MAxis::Xmax, 0.0);
    dhand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->Update();


    // **************************************************************//
    // *****                  SOLVER CREATION                   *****//
    // **************************************************************//

    // Linear solver
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    RCP<TimeIterator> tIterator = rcp(new TimeIterator);
    tIterator->setLinearSolver(linSolver);
    tIterator->setTimeStepSize(1e-3);
    tIterator->setStopCriteria(20000, 1e-2, 1e-3);
    tIterator->setTimeSteppingScheme(TimeSteppingScheme::AdaptiveLinear);
    tIterator->setLinearStepFactor(1.2);
    tIterator->setMaximumTimeStepSize(0.1);
    tIterator->setPrintToFile(PrintToFileMethod::Vtk, 1, "HeatEq");
    tIterator->setPrintRestart(10, "restart");
    // tIterator->setPostprocess(1, [=](){dhand->printFileLegacyVtk("HeatEq" + to_string(tIterator->timeStep()));});
    tIterator->Update();

    tIterator->Iterate();

    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}

void LS(RCP<FillStructure> fillStr)
{
    // Get parameters
    double deltat = fillStr->userStr->time.deltat;
    double source = fillStr->userStr->dparam[1];

    // Rename variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int nDOFs = subFill.numDOFs;   // Number of degrees of freedom
    int eNN   = subFill.eNN;       // Number of neighbor nodes
    int nDim  = subFill.nDim;      // Number of spatial dimensions
    int pDim  = subFill.pDim;      // Number of parametric dimension
    double* nborDOFs0 = subFill.nborDOFs0.data();

    // Shape functions and derivatives at Gauss points
    double* bf = subFill.nborBFs();
    double gbf[eNN*pDim], jac;
    GlobalBasisFunctions::gradients(gbf, jac, subFill);

    // Values at integration points
    double c0{};
    for (int i = 0; i < eNN; i++)
        c0 += nborDOFs0[i] * bf[i];

    // Fill linear system
    for (int i = 0; i < eNN; i++)
    {
        // Fill RHS
        fillStr->Bk(0)[i] += jac * bf[i]*(c0/deltat + source);

        for (int j = 0; j < eNN; j++)
        {
            double gbfgbf{};
            for (int d = 0; d < pDim; d++)
                gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

            // Fill matrix
            fillStr->Ak(0, 0)[i*eNN+j] += jac * bf[i]*bf[j]/deltat;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * gbfgbf;
        }
    }

    return;
}
