
// C++ headers
#include <mpi.h>

// hiperlife headers
#include <hl_Core.h>
#include <hl_TypeDefs.h>
#include <hl_StructMeshGenerator.h>
#include <hl_DistributedMesh.h>
#include <hl_ParamStructure.h>
#include <hl_DOFsHandler.h>
#include <hl_HiPerProblem.h>
#include <hl_LinearSolver_Direct_MUMPS.h>
#include <hl_LinearSolver_Iterative_AztecOO.h>
#include <hl_NonlinearSolver_NewtonRaphson.h>
#include <hl_ConsistencyCheck.h>
#include <hl_SubFillStructure.h>
#include <hl_GlobalBasisFunctions.h>
#include <ttl.h>
#include <ad.h>


void constitutiveModel_Coupled_NeoHookean(double& W, hiperlife::Tensor::tensor<double,2>& S, hiperlife::Tensor::tensor<double,4>& D, hiperlife::Tensor::tensor<double,2> F, map<string, double>& params)
{
    using namespace hiperlife::Tensor;
    using namespace ttl;
    using index::a; using index::b; using index::c; using index::d;

    //***********************************************************
    // [0] Initialize
    //***********************************************************

    // Parameters
    double mu = params.at("mu");
    double lm = params.at("lambda");

    //***********************************************************
    // [1] Compute jacobian, right Cauchy def tensor and inverse
    //***********************************************************

    // Dimensions
    int pDim = F.shape()[0];

    // Identity
    tensor<double,2> Id = Identity(pDim);

    // Jacobian
    double J = F.det();

    // Right Cauchy-Green tensor and inverse
    tensor<double,2> Finv = F.inv();
    tensor<double,2> Cinv = Finv*Finv.T(); //This seems to introduce less error than C.inv()
    tensor<double,2> C = F.T()*F;

    // Compute Cinv(x)Cinv => []_abcd=Cinv_ab*Cinv_cd
    tensor<double,4> CinvCinv = Cinv(a,b)*Cinv(c,d);

    // Compute Cinv(·)Cinv => []_abcd=-0.5*(Cinv_ac*Cinv_bd+Cinv_ad*Cinv_bc) [Eq. 6.165]
    tensor<double,4> Cinv_Cinv(pDim,pDim,pDim,pDim);
    Cinv_Cinv(a,b,c,d) = 0.5*(Cinv(a,c)*Cinv(b,d) + Cinv(a,d)*Cinv(b,c));

    // tensor<double,6> Cinv_CinvxCinv(pDim,pDim,pDim,pDim,pDim,pDim);
    // Cinv_CinvxCinv(a,b,c,d,k,l) = Cinv_Cinv(a,b,c,d)*Cinv(k,l);
    // tensor<double,6> CinvxCinv_Cinv(pDim,pDim,pDim,pDim,pDim,pDim);
    // CinvxCinv_Cinv(a,b,c,d,k,l) = Cinv(a,b)*Cinv_Cinv(c,d,k,l);

    // tensor<double,6> dCinv_Cinv(pDim,pDim,pDim,pDim,pDim,pDim);
    // dCinv_Cinv(a,b,c,d,i,j) = 0.5*(Cinv_Cinv(a,c,i,j)*Cinv(b,d) +
    //                                Cinv(a,c)*Cinv_Cinv(b,d,i,j) +
    //                                Cinv_Cinv(a,d,i,j)*Cinv(b,c) +
    //                                Cinv(a,d)*Cinv_Cinv(b,c,i,j));

    //***********************************************************
    // [2] Compute 2nd Piola-Kirchhoff stress tensor
    //***********************************************************

    // dI1/dC = Id [Eq. 6.30]
    // dCinv/dC = -Cinv_Cinv  [Eq. 6.165]
    // d(logJ)/dC = J*Cinv/2 [Eq. 6.82]

    // dWdC =  0.5*lm*2*log(J)*J*Cinv/2/J - mu*J*Cinv/2/J + 0.5*mu*Id
    // dWdC =  lm*log(J)*Cinv/2 - mu*Cinv/2 + 0.5*mu*Id
    // dWdC =  0.5*((lm*log(J)-mu)*Cinv + mu*Id)
    // S = 2*dWdC = (lm*log(J)-mu)*Cinv + mu*Id

    // Energy
    W = 0.5*lm*log(J)*log(J) - mu*log(J) + 0.5*mu*(trace(C)-3.0);

    // Stress tensor
    S = mu*Id + (lm*log(J)-mu)*Cinv;

    //***********************************************************
    // [3] Compute elasticity tensor
    //***********************************************************

    // dSdC = lm*J*Cinv/2/J*Cinv - (lm*log(J)-mu)*Cinv_Cinv
    // dSdC = lm/2*Cinv*Cinv - (lm*log(J)-mu)*Cinv_Cinv
    // D = 2*dSdC = lm*Cinv*Cinv - 2*(lm*log(J)-mu)*Cinv_Cinv
    // D = lm*Cinv*Cinv + 2*(mu-lm*log(J))*Cinv_Cinv

    // Elasticity tensor (D = 2dS/dC)
    D = lm*CinvCinv + 2.0*(mu-lm*log(J))*Cinv_Cinv;

}

void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //***********************************************************
    // Initialize
    //***********************************************************

    // Parameters
    map<string, double> params{{"mu", fillStr->paramStr->dparam[2]},
                               {"lambda", fillStr->paramStr->dparam[3]}};

    // Rename variables for the main dofsHandler
    SubFillStructure& subFill = (*fillStr)[0];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;
    tensor<double,2,false> nborCoords(subFill.nborCoords.data(), eNN, nDim);
    tensor<double,2,false> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
    tensor<double,1,false> bf(subFill.nborBFs(), eNN);

    // Get output
    tensor<double,2,false> Bk(fillStr->Bk(0).data(),eNN,numDOFs);
    tensor<double,4,false> Ak(fillStr->Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);


    //***********************************************************
    // Compute values and functions at integration points
    //***********************************************************

    // Derivatives of the basis functions
    double jac;
    tensor<double,2> gbf(eNN, pDim);
    GlobalBasisFunctions::gradients(gbf, jac, subFill);

    // Gradient of x
    tensor<double,2> grad_x = product(nborDOFs, gbf, {{0,0}});

    // Deformation gradient F = I + u_{i,j}
    tensor<double,2> F = grad_x;

    // Constitutive model
    double W{};
    tensor<double,2> S(pDim, pDim);
    tensor<double,4> C(pDim,pDim,pDim,pDim);
    constitutiveModel_Coupled_NeoHookean(W, S, C, F, params);

    // Coords
    tensor<double,1> X = bf*nborCoords;
    tensor<double,1> x = bf*nborDOFs;

    // Identity tensor
    tensor<double,2> Id = Identity(pDim);

    // Body force
    tensor<double,1> f(pDim);
    for (int d = 0; d < pDim; d++)
        f(d) = 0.0;
    f(1) = 0.1;


    //***********************************************************
    // Fill linear system
    //***********************************************************

    using namespace ttl;
    using index::I; using index::J;
    using index::a; using index::b; using index::c; using index::d;
    using index::i; using index::j;

    tensor<double,4> Kmat(eNN,pDim,eNN,pDim);
    Kmat(I,i,J,j) = gbf(I,a)*F(i,b)*C(a,b,c,d)*gbf(J,c)*F(j,d);

    tensor<double,4> Kgeo2(eNN,pDim,eNN,pDim);
    Kgeo2(I,i,J,j) = gbf(I,a)*S(a,b)*gbf(J,b)*Id(i,j);

    // Internal stresses
    Bk(I,i) += jac*(gbf(I,a)*F(i,b)*S(a,b));
    Ak += jac*(Kmat + Kgeo2);

    // Body force -> w*b
    Bk += jac*outer(bf, f);

    // Global integrals
    fillStr->addToGlobalIntegral("Ray", jac*(W+(x-X)*f));

    return;
}

void LS_autodiff(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;
    using namespace autodiff;

    // Define Rayleighian = dEnergy(Neohookean) + dEnergy(body force)
    auto rayleighian = [&fillStr](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
    {
        // Parameters
        double mu = fillStr.paramStr->dparam[2];
        double lm = fillStr.paramStr->dparam[3];

        // Rename variables for the main dofsHandler
        SubFillStructure& subFill = fillStr["dhand"];
        int numDOFs = subFill.numDOFs;
        int nDim = subFill.nDim;
        int pDim = subFill.pDim;
        int eNN  = subFill.eNN;
        tensor<dual2nd,2,false> nborDOFs(nborDOFs_vec.data(), eNN, numDOFs);
        tensor<double,2,false> nborCoords(subFill.nborCoords.data(), eNN, nDim);
        tensor<double,1,false> bf(subFill.nborBFs(), eNN);

        // Gradients of BFs
        double jac;
        tensor<double,2> gbf(eNN, pDim);
        GlobalBasisFunctions::gradients(gbf, jac, subFill);

        // Energy rate (Neo-Hookean hyperelastic material)
        tensor<dual2nd,2> F = product(nborDOFs, gbf, {{0,0}}); // Deformation gradient
        dual2nd J = F.det();                                   // Jacobian of the deformation
        tensor<dual2nd,2> C = F.T()*F;                         // Right Cauchy–Green deformation tensor
        auto dE = 0.5*lm*log(J)*log(J) - mu*log(J) + 0.5*mu*(trace(C)-3.0);

        // Energy external forces (Vertical body force)
        tensor<double,1>  X = bf*nborCoords(all, range(0,1));  // Coordinates in reference configuration
        tensor<dual2nd,1> x = bf*nborDOFs;                     // Coordinates in current configuration
        tensor<double,1>  b = {0.0, 0.1};                      // Body borce
        auto P = (x-X)*b;

        return jac*(dE+P);
    };

    // Compute nborDOFs as dual2nd type
    SubFillStructure& subFill = fillStr["dhand"];
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;
    std::vector<dual2nd> dofs(eNN*numDOFs);
    for (int i = 0; i < eNN*numDOFs; i++)
        dofs[i] = subFill.nborDOFs[i];

    // Compute rayleighian, jacobian, and hessian
    dual2nd ray;
    hessian(rayleighian, wrt(dofs), at(dofs), ray, fillStr.Bk(0), fillStr.Ak(0,0));

    fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));
}

int main()
{
    using std::cout;
    using std::endl;
    using namespace hiperlife;
    using Teuchos::rcp;
    using Teuchos::RCP;

    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    int myRank;
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    // Model material parameters
    double E      = 10.0;   // Young modulus
    double nu     = 0.4;  // Poisson ratio
    double mu     = E / (2.0*(1.0+nu));
    double lambda = E*nu / ((1.0+nu)*(1.0-2.0*nu));

    // Write parameters
    if (myRank == 0)
    {
        cout << endl << endl << "Parameters: " << endl;
        cout << "  E      = " << E << endl;
        cout << "  nu     = " << nu << endl;
        cout << "  mu     = " << mu << endl;
        cout << "  lambda = " << lambda << endl;
        cout << endl;
    }

    // Load-related parameters
    double maxLoad = 1.0;
    int maxSteps   = 1;
    double deltal  = 0.05;
    double adaptiveFactor = 1.0; //0.975;

    // Other
    string solNamePrefix = "Viscoelasticity";
    bool printVtk    = true;
    bool printLeg    = false;
    int nSave        = 1;

    // Put parameters in the user structure
    SmartPtr<ParamStructure> userStr = Create<ParamStructure>();
    userStr->dparam.resize(20);
    userStr->dparam[0]  = E;
    userStr->dparam[1]  = nu;
    userStr->dparam[2]  = mu;
    userStr->dparam[3]  = lambda;
    userStr->dparam[16] = deltal;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create structured mesh
    SmartPtr<StructMeshGenerator> mesh = Create<StructMeshGenerator>();
    mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    mesh->genStructMesh(30);
    // mesh->genQuarterPlateWithCircularHole(30, 30, 1.0, 0.2);

    // Distribute the mesh
    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();
    disMesh->printFileLegacyVtk("mesh");


    // **************************************************************//
    // *****              DOFsHANDLER CREATION                  *****//
    // **************************************************************//

    // Main degree of freedom handler
    SmartPtr<DOFsHandler> dhand = Create<DOFsHandler>(disMesh);
    dhand->setNameTag("dhand");
    dhand->setDOFs({"x", "y"});
    dhand->Update();

    // Initial conditions
    for (int i = 0; i < disMesh->loc_nPts(); i++)
    {
        // Get node coordinates
        std::vector<double> x = disMesh->nodeCoords(i, IndexType::Local);

        // Initial conditions
        for (int d = 0; d < dhand->numDOFs(); d++)
            dhand->nodeDOFs->setValue(d, i, IndexType::Local, x[d]);
    }

    // Boundary conditions (Fix left)
    dhand->setBoundaryCondition("x", MAxis::Xmin, 0.0);
    dhand->setBoundaryCondition("y", MAxis::Xmin, 0.0);

    // Update ghosts
    dhand->nodeDOFs0->setValue(dhand->nodeDOFs);
    dhand->UpdateGhosts();


    // **************************************************************//
    // *****                    HIPERPROBLEM                    *****//
    // **************************************************************//

    // Main hiperproblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setParameterStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setGlobalIntegrals({"Ray", "dEner", "Pow_body", "Pow_load", "Area", "Length"});
    hiperProbl->setConsistencyDOFs("dhand", {"x", "y"});
    hiperProbl->setConsistencyCheckType(ConsistencyCheckType::Both, "Ray");

    // Bulk
    hiperProbl->setIntegration("integ", {"dhand"});
    // hiperProbl->setElementFillings("integ", ConsistencyCheck<LS_autodiff>);
    hiperProbl->setElementFillings("integ", LS_autodiff);
    // hiperProbl->setElementFillings("integ", ConsistencyCheck<LS>);
    // hiperProbl->setElementFillings("integ", LS);
    // hiperProbl->setElementFillings("integ", LS_check);
    hiperProbl->setCubatureGauss("integ", computeDefaultNumGPts(disMesh->elemType(), 3));

    // Update
    hiperProbl->Update();


    for (int n = 0; n < 100; n++)
        hiperProbl->FillLinearSystem();

    // Finalize
    MPI_Finalize();
    return 0;


    // **************************************************************//
    // *****                  SOLVER CREATION                   *****//
    // **************************************************************//

    // // Linear solver (MUMPS)
    // RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    // // solver->setWorkSpaceMemoryIncrease(200);
    // solver->setDefaultParameters();
    // solver->Update();

    // Linear solver (GMRES)
    SmartPtr<AztecOOIterativeLinearSolver> solver = Create<AztecOOIterativeLinearSolver>();
    solver->setHiPerProblem(hiperProbl);
    solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
    solver->setDefaultParameters();
    solver->Update();

    // Non-linear solver
    SmartPtr<NewtonRaphsonNonlinearSolver> nonLinSolver = Create<NewtonRaphsonNonlinearSolver>();
    nonLinSolver->setLinearSolver(solver);
    nonLinSolver->setConvRelTolerance(true);
    nonLinSolver->setMaxNumIterations(50);
    nonLinSolver->setResTolerance(1e-7);
    nonLinSolver->setSolTolerance(1e-7);
    nonLinSolver->setResMaximum(1e5);
    nonLinSolver->setSolMaximum(1e5);
    nonLinSolver->setExitRelMaximum(true);
    nonLinSolver->setLineSearch(false);
    nonLinSolver->setPrintSummary(true);
    nonLinSolver->setPrintIntermInfo(true);
    nonLinSolver->Update();



    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    // Open file to write global integrals and write headers
    hiperProbl->FillLinearSystem();
    ofstream gIntegFile;
    gIntegFile.open ("globalIntegrals.csv");
    if (hiperProbl->myRank() == 0)
    {
        //Write data
        gIntegFile << "LS load deltal";
        for (auto g: hiperProbl->globalIntegralNames())
            gIntegFile << " " << g;
        gIntegFile << endl;

        // Write time data and global integrals
        gIntegFile << 0 << " " << 0 << " " << deltal;
        for (auto g: hiperProbl->globalIntegrals())
            gIntegFile  << " " << g;
        gIntegFile << endl;
    }

    // Print initial condition
    string solName = solNamePrefix + ".0";
    if (printVtk)
        dhand->printFileVtk(solName, true, 0.0);
    if (printLeg)
        dhand->printFileLegacyVtk(solName, true);

    // Load loop
    int loadStep{1};
    double load{deltal};
    while (loadStep <= maxSteps and load <= maxLoad)
    {
        // Print info
        if (hiperProbl->myRank() == 0)
            cout << endl << endl << "Load step: " << loadStep << "/" << maxSteps << " deltal " << deltal << " load " << load << "/" << maxLoad << endl;
        userStr->dparam[15] = loadStep;
        userStr->dparam[16] = load;

        // Initial guess
        dhand->nodeDOFs->setValue(dhand->nodeDOFs0);
        hiperProbl->UpdateGhosts();

        // Solve
        bool converged = nonLinSolver->solve();

        // Check convergence
        if (converged)
        {
            // Save solution
            dhand->nodeDOFs0->setValue(dhand->nodeDOFs);
            dhand->nodeDOFs0->UpdateGhosts();

            // Save results each nSave time steps
            if (loadStep%nSave == 0)
            {
                solName = solNamePrefix + "." + to_string(loadStep);
                if (printVtk)
                    dhand->printFileVtk(solName, true, load);
                if (printLeg)
                    dhand->printFileLegacyVtk(solName, true);
            }

            // Write time data and global integrals
            if (hiperProbl->myRank() == 0)
            {
                gIntegFile << loadStep << " " << load << " " << deltal;
                for (auto g: hiperProbl->globalIntegrals())
                    gIntegFile  << " " << g;
                gIntegFile << endl;
            }

            // Update load variables
            loadStep++;
            // int iter = nonLinSolver->numberOfIterations();
            // if (iter < 4)
                deltal /= adaptiveFactor;
            // else if (iter == 5)
            //     deltal *= adaptiveFactor;
            if (load < maxLoad && load + deltal >= maxLoad)
                deltal = maxLoad - load;
            load += deltal;
        }
        else
        {
            // End if no adaptivity
            if (adaptiveFactor == 1.0)
            {
                cout << endl << endl<< "Not converged" << endl;
                break;
            }

            // Steady state or non-convergence
            if (deltal < 1e-8)
            {
                cout << endl << endl<< "Steady state or non-convergence" << endl;
                break;
            }

            load -=deltal;
            // deltal *= adaptiveFactor;
            deltal *= 0.5;
            load += deltal;
        }

    }

    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    // Close file
    gIntegFile.close();

    // Last print
    solName = solNamePrefix + "." + to_string(loadStep);
    if (printVtk)
        dhand->printFileVtk(solName, true, load);
    if (printLeg)
        dhand->printFileLegacyVtk(solName, true);


    // Finalize
    MPI_Finalize();
    return 0;
}
