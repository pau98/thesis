#include <array>
#include <iostream>
#include <math.h>
#include <chrono>

#include "ttl.h"

struct FillStr
{
    static constexpr int eNN{12}; //SS

    ttl::tensor<double,2> nborFields={{8.77213851e-02,9.60236669e-01,-2.63142794e-01,8.77213851e-03,9.60236669e-02,-2.63142794e-02},{-1.12438492e-01,9.16148543e-01,-3.84433627e-01,-1.12438492e-02,9.16148543e-02,-3.84433627e-02},{1.09889299e-01,8.49577129e-01,-5.15524864e-01,1.09889299e-02,8.49577129e-02,-5.15524864e-02},{3.30949962e-01,8.85094643e-01,-3.26034218e-01,3.30949962e-02,8.85094643e-02,-3.26034218e-02},{2.73201734e-01,9.56784844e-01,-9.33692828e-02,2.73201734e-02,9.56784844e-02,-9.33692828e-03},{3.82018350e-02,9.98673558e-01,-1.50261009e-02,3.82018350e-03,9.98673558e-02,-1.50261009e-03},{-1.40112549e-01,9.75406706e-01,-1.67430073e-01,-1.40112549e-02,9.75406706e-02,-1.67430073e-02},{-2.75693625e-01,9.15175378e-01,-2.92415380e-01,-2.75693625e-02,9.15175378e-02,-2.92415380e-02},{-2.77026772e-01,8.54863346e-01,-4.38483566e-01,-2.77026772e-02,8.54863346e-02,-4.38483566e-02},{-1.51196897e-01,8.07917297e-01,-5.69231808e-01,-1.51196897e-02,8.07917297e-02,-5.69231808e-02},{-3.93305242e-01,9.11441147e-01,-1.16078183e-01,-3.93305242e-02,9.11441147e-02,-1.16078183e-02},{-1.91954941e-01,9.79420781e-01,5.80924451e-02,-1.91954941e-02,9.79420781e-02,5.80924451e-03}};
    ttl::tensor<double,2> nborFields0={{8.77213851e-02,9.60236669e-01,-2.63142794e-01,8.77213851e-03,9.60236669e-02,-2.63142794e-02},{-1.12438492e-01,9.16148543e-01,-3.84433627e-01,-1.12438492e-02,9.16148543e-02,-3.84433627e-02},{1.09889299e-01,8.49577129e-01,-5.15524864e-01,1.09889299e-02,8.49577129e-02,-5.15524864e-02},{3.30949962e-01,8.85094643e-01,-3.26034218e-01,3.30949962e-02,8.85094643e-02,-3.26034218e-02},{2.73201734e-01,9.56784844e-01,-9.33692828e-02,2.73201734e-02,9.56784844e-02,-9.33692828e-03},{3.82018350e-02,9.98673558e-01,-1.50261009e-02,3.82018350e-03,9.98673558e-02,-1.50261009e-03},{-1.40112549e-01,9.75406706e-01,-1.67430073e-01,-1.40112549e-02,9.75406706e-02,-1.67430073e-02},{-2.75693625e-01,9.15175378e-01,-2.92415380e-01,-2.75693625e-02,9.15175378e-02,-2.92415380e-02},{-2.77026772e-01,8.54863346e-01,-4.38483566e-01,-2.77026772e-02,8.54863346e-02,-4.38483566e-02},{-1.51196897e-01,8.07917297e-01,-5.69231808e-01,-1.51196897e-02,8.07917297e-02,-5.69231808e-02},{-3.93305242e-01,9.11441147e-01,-1.16078183e-01,-3.93305242e-02,9.11441147e-02,-1.16078183e-02},{-1.91954941e-01,9.79420781e-01,5.80924451e-02,-1.91954941e-02,9.79420781e-02,5.80924451e-03}};
    ttl::tensor<double,1> globFields={1.0};
    ttl::tensor<double,1> globFields0={1.0};

    std::array<double,eNN> bfs = {4.31712963e-01,1.84606481e-01,7.11805556e-02,2.46913580e-02,2.46913580e-02,7.11805556e-02,1.84606481e-01,5.78703704e-03,1.92901235e-04,5.78703704e-04,1.92901235e-04,5.78703704e-04};
    std::array<double,eNN*2> Dbfs = {-3.65740741e-01,-3.65740741e-01,4.97685185e-01,1.59722222e-01,7.63888889e-02,-2.10648148e-01,-8.64197531e-02,-1.35802469e-01,-1.35802469e-01,-8.64197531e-02,-2.10648148e-01,7.63888889e-02,1.59722222e-01,4.97685185e-01,5.09259259e-02,5.09259259e-02,3.85802469e-03,7.71604938e-04,1.00308642e-02,-7.71604938e-04,7.71604938e-04,3.85802469e-03,-7.71604938e-04,1.00308642e-02};

    ttl::tensor<double,4> mat_nn=ttl::tensor<double,4>(eNN,3,eNN,3);
    ttl::tensor<double,3> mat_ng=ttl::tensor<double,3>(eNN,3,1);
    ttl::tensor<double,3> mat_gn=ttl::tensor<double,3>(1,eNN,3);
    ttl::tensor<double,2> mat_gg=ttl::tensor<double,2>(1,1);

    ttl::tensor<double,2> vec_n=ttl::tensor<double,2>(eNN,3);
    ttl::tensor<double,1> vec_g=ttl::tensor<double,1>(1);

    double w_sample = 1.0;
};

void test_notensor(FillStr& fill)
{
    using namespace std;

    //[1] INPUT
    int eNN    = fill.eNN;

    double* nborFields   = fill.nborFields.data();
    double* nborFields0  = fill.nborFields0.data();
    double* globFields   = fill.globFields.data();

    double pressure = globFields[0];

    double* bfs = fill.bfs.data();
    double* Dbfs = fill.Dbfs.data();

    double deltat    = 0.1;
    double tension   = 1.0 * deltat;
    double viscosity = 1.0;
    double frictiont = 1.0;
    double frictionn = 1.0;


    // Previous time-step
    // Compute position and tangent vectors
   double x0[3]={};
   double Dx0[2*3]={};
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            x0[I] += bfs[a] * nborFields0[a*6+I];
            for(int j = 0; j < 2; j++)
                Dx0[j*3+I] += Dbfs[a*2+j] * nborFields0[a*6+I];
        }
    }


    // Compute metric tensor
    double metric0[4]={};
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            for(int K = 0; K < 3; K++)
                metric0[2*i+j] += Dx0[i*3+K] * Dx0[j*3+K];


    double det = metric0[0] * metric0[3] - metric0[1] * metric0[2];
    // Inverse of the metric tensor
    double imetric0[4] = {metric0[3]/det,-metric0[1]/det,-metric0[2]/det,metric0[0]/det};

    // Normal
   double cross0[3] = {Dx0[3*0+1] * Dx0[3*1+2] - Dx0[3*0+2] * Dx0[3*1+1], Dx0[3*0+2] * Dx0[3*1+0] - Dx0[3*0+0] * Dx0[3*1+2], Dx0[3*0+0] * Dx0[3*1+1] - Dx0[3*0+1] * Dx0[3*1+0]  };
    double jac0 = sqrt(cross0[0]*cross0[0]+cross0[1]*cross0[1]+cross0[2]*cross0[2]);
   double n0[3] = {cross0[0]/jac0, cross0[1]/jac0, cross0[2]/jac0};

   double proj0[9] = {1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0};
   double n0n0[9]={};
    for(int I = 0; I < 3; I++)
        for(int J = 0; J < 3; J++)
            n0n0[I*3+J] = n0[I] * n0[J];
    for(int l = 0; l < 9; l++)
        proj0[l] -= n0n0[l];

    // Current time-step
    // Compute position and tangent vectors
    double v[3]={};
    double Dx[2*3]={};
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            v[I] += bfs[a] * nborFields[a*6+I+3];
            for(int j = 0; j < 2; j++)
                Dx[j*3+I] += Dbfs[a*2+j] * (nborFields0[a*6+I]+nborFields[a*6+I+3]);
        }
    }
   double x[3];
    for(int I = 0; I < 3; I++)
        x[I] = x0[I] + v[I];

    // Compute metric tensor
   double metric[4]={};
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            for(int K = 0; K < 3; K++)
                metric[2*i+j] += Dx[i*3+K] * Dx[j*3+K];

    double proj0v[3] = {};
    for(int I = 0; I < 3; I++)
        for(int J = 0; J < 3; J++)
            proj0v[I] += proj0[3*I+J] * v[J];

    double vn = v[0] * n0[0] + v[1] * n0[1] + v[2] * n0[2];

    double rodt[4];
    for(int l = 0; l < 4; l++)
        rodt[l] = metric[l] - metric0[l];

    double rodt_Cc[4]={};
    for(int i = 0; i < 2; i++)
        for(int j = 0; j<2; j++)
            for(int k = 0; k<2; k++)
                rodt_Cc[i*2+j] += imetric0[i*2+k] * rodt[2*k+j];

    double rodt_CC[4]={};
    for(int i = 0; i < 2; i++)
        for(int j = 0; j<2; j++)
            for(int k = 0; k<2; k++)
                rodt_CC[i*2+j] += rodt_Cc[2*i+k] * imetric0[2*k+j];

    vector<double> dmetric(eNN*3*2*2,0.0);
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            for(int j = 0; j < 2; j++)
            {
                for(int k = 0; k < 2; k++)
                {
                    dmetric[a*12+I*4+j*2+k] += Dx[j*3+I] * Dbfs[a*2+k] + Dbfs[a*2+j] * Dx[k*3+I];
                }
            }
        }
    }

    vector<double> dmetric_CC(eNN*3*2*2,0.0);
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            for(int j = 0; j < 2; j++)
           {
               for(int k = 0; k < 2; k++)
               {
                   for(int l = 0; l < 2; l++)
                       for(int m = 0; m < 2; m++)
                           dmetric_CC[a*12+I*4+j*2+k] += imetric0[j*2+l] * dmetric[a*12+I*4+l*2+m] * imetric0[2*m+k];
               }
           }
        }
    }

    //[3] OUTPUT
    double* rhs_n = fill.vec_n.data();
    double* rhs_g = fill.vec_g.data();
    double* A_nn  = fill.mat_nn.data();
    double* A_ng  = fill.mat_ng.data();
    double* A_gn  = fill.mat_gn.data();


    double wfrict = fill.w_sample * frictiont * jac0;
    double wfricn = fill.w_sample * frictionn * jac0;
    double wvisco = 4.0 * fill.w_sample * viscosity * jac0;
    double wactiv = 2.0 * fill.w_sample * tension * jac0;
    double wpress = fill.w_sample * deltat * jac0;


    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            rhs_n[a*3+I] = wfrict * bfs[a] * proj0v[I];
            rhs_n[a*3+I] += wfricn * bfs[a] * vn * n0[I];
            rhs_n[a*3+I] += wpress * pressure * bfs[a] * n0[I];

            for(int k = 0; k < 2; k++)
            {
                for(int l = 0; l < 2; l++)
                {
                    rhs_n[a*3+I] += wvisco * dmetric[a*12+I*4+k*2+l] * rodt_CC[2*k+l];
                    rhs_n[a*3+I] += wactiv * dmetric[a*12+I*4+k*2+l] * imetric0[2*k+l];
                }
            }

            for(int b = 0; b < eNN; b++)
            {
                for(int J = 0; J < 3; J++)
                {
                    A_nn[((a*3+I)*eNN+b)*3+J] = wfrict * bfs[a] * bfs[b] * proj0[3*I+J];
                    A_nn[((a*3+I)*eNN+b)*3+J] += wfricn * bfs[a] * bfs[b] * n0[I] * n0[J];

                    for(int k = 0; k < 2; k++)
                        for(int l = 0; l < 2; l++)
                            A_nn[((a*3+I)*eNN+b)*3+J] += wvisco * dmetric[a*12+I*4+k*2+l] * dmetric_CC[b*12+J*4+k*2+l] ;
                }

                for(int k = 0; k < 2; k++)
                {
                    for(int l = 0; l < 2; l++)
                    {
                        double ddmetric_abkl = Dbfs[a*2+k] * Dbfs[b*2+l] +  Dbfs[a*2+l] * Dbfs[b*2+k];
                        A_nn[((a*3+I)*eNN+b)*3+I] += wvisco * ddmetric_abkl * rodt_CC[2*k+l];
                        A_nn[((a*3+I)*eNN+b)*3+I] += wactiv * ddmetric_abkl * imetric0[2*k+l];
                    }
                }
            }

            double aux = wpress * bfs[a] * n0[I];
            A_ng[a*3+I] = aux;
            A_gn[a*3+I] = aux;
        }
    }

    rhs_g[0] = wpress * vn;
}

void test_for(FillStr& fill)
{
    using namespace std;
    using namespace ttl;

    //[1] INPUT
    int eNN    = fill.eNN;

    tensor<double,2>& nborFields   = fill.nborFields;
    tensor<double,2>& nborFields0  = fill.nborFields0;

    tensor<double,1>&  globFields = fill.globFields;

    double pressure = globFields(0);

    tensor<double,1,false>  bfs(fill.bfs.data(),eNN);
    tensor<double,2,false>  Dbfs(fill.Dbfs.data(),eNN,2);

    double deltat    = 0.1;
    double tension   = 1.0 * deltat;
    double viscosity = 1.0;
    double frictiont = 1.0;
    double frictionn = 1.0;


    // Previous time-step
    // Compute position and tangent vectors
    tensor<double,1> x0(3);
    tensor<double,2> Dx0(2,3);
    x0 = 0.0;
    Dx0 = 0.0;
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            x0(I) += bfs(a) * nborFields0(a,I);
            for(int j = 0; j < 2; j++)
                Dx0(j,I) += Dbfs(a,j) * nborFields0(a,I);
        }
    }

    // Compute metric tensor
    tensor<double,2> metric0(2,2);
    metric0 = 0.0;
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            for(int K = 0; K < 3; K++)
                metric0(i,j) += Dx0(i,K) * Dx0(j,K);

    // Inverse of the metric tensor
    tensor<double,2> imetric0 = metric0.inv();

    // Normal
    tensor<double,1> cross0 = {Dx0(0,1) * Dx0(1,2) - Dx0(0,2) * Dx0(1,1), Dx0(0,2) * Dx0(1,0) - Dx0(0,0) * Dx0(1,2), Dx0(0,0) * Dx0(1,1) - Dx0(0,1) * Dx0(1,0)  };
    double jac0 = sqrt(cross0*cross0);
    tensor<double,1> n0 = cross0/jac0;

    tensor<double,2> proj0 = Identity(3);
    tensor<double,2> n0n0 = outer(n0,n0);
    proj0 = proj0 - n0n0;

    // Current time-step
    // Compute position and tangent vectors
    tensor<double,1> v(3);
    tensor<double,2> Dx(2,3);
   v = 0.0; Dx=0.0;
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            v(I) += bfs(a) * nborFields(a,I+3);
            for(int j = 0; j < 2; j++)
                Dx(j,I) += Dbfs(a,j) * (nborFields0(a,I) + nborFields(a,I+3));
        }
    }
    tensor<double,1> x = x0 + v;


    // Compute metric tensor
    tensor<double,2> metric(2,2);
   metric = 0.0;
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
            for(int K = 0; K < 3; K++)
                metric(i,j) += Dx(i,K) * Dx(j,K);

    tensor<double,1> proj0v = proj0*v;
    double vn = v * n0;

    tensor<double,2> rodt = metric-metric0;
    tensor<double,2> rodt_Cc = imetric0 * rodt;
    tensor<double,2> rodt_CC = rodt_Cc * imetric0;

    tensor<double,4> dmetric(eNN,3,2,2);
    dmetric = 0.0;
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            for(int j = 0; j < 2; j++)
            {
                for(int k = 0; k < 2; k++)
                {
                    dmetric(a,I,j,k) += Dx(j,I) * Dbfs(a,k) + Dbfs(a,j) * Dx(k,I);
                }
            }
        }
    }

    tensor<double,4> dmetric_CC(eNN,3,2,2);
    dmetric_CC = 0.0;
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            for(int j = 0; j < 2; j++)
           {
               for(int k = 0; k < 2; k++)
               {
                   for(int l = 0; l < 2; l++)
                       for(int m = 0; m < 2; m++)
                           dmetric_CC(a,I,j,k) += imetric0(j,l) * dmetric(a,I,l,m) * imetric0(m,k);
               }
           }
        }
    }

    //[3] OUTPUT
    tensor<double,2>& rhs_n = fill.vec_n;
    tensor<double,1>& rhs_g = fill.vec_g;
    tensor<double,4>& A_nn  = fill.mat_nn;
    tensor<double,3>& A_ng  = fill.mat_ng;
    tensor<double,3>& A_gn  = fill.mat_gn;

    double wfrict = fill.w_sample * frictiont * jac0;
    double wfricn = fill.w_sample * frictionn * jac0;
    double wvisco = 4.0 * fill.w_sample * viscosity * jac0;
    double wactiv = 2.0 * fill.w_sample * tension * jac0;
    double wpress = fill.w_sample * deltat * jac0;
    for(int a = 0; a < eNN; a++)
    {
        for(int I = 0; I < 3; I++)
        {
            rhs_n(a,I) = wfrict * bfs(a) * proj0v(I);
            rhs_n(a,I) += wfricn * bfs(a) * vn * n0(I);
            rhs_n(a,I) += wpress * pressure * bfs(a) * n0(I);

            for(int k = 0; k < 2; k++)
            {
                for(int l = 0; l < 2; l++)
                {
                    rhs_n(a,I) += wvisco * dmetric(a,I,k,l) * rodt_CC(k,l);
                    rhs_n(a,I) += wactiv * dmetric(a,I,k,l) * imetric0(k,l);
                }
            }

            for(int b = 0; b < eNN; b++)
            {
                for(int J = 0; J < 3; J++)
                {
                    A_nn(a,I,b,J) = wfrict * bfs(a) * bfs(b) * proj0(I,J);
                    A_nn(a,I,b,J) += wfricn * bfs(a) * bfs(b) * n0(I) * n0(J);

                    for(int k = 0; k < 2; k++)
                        for(int l = 0; l < 2; l++)
                            A_nn(a,I,b,J) += wvisco * dmetric(a,I,k,l) * dmetric_CC(b,J,k,l);
                }

                for(int k = 0; k < 2; k++)
                {
                    for(int l = 0; l < 2; l++)
                    {
                        double ddmetric_abkl = Dbfs(a,k) * Dbfs(b,l) +  Dbfs(a,l) * Dbfs(b,k);
                        A_nn(a,I,b,I) += wvisco * ddmetric_abkl * rodt_CC(k,l);
                        A_nn(a,I,b,I) += wactiv * ddmetric_abkl * imetric0(k,l);
                    }
                }
            }

            double aux = wpress * bfs(a) * n0(I);
            A_ng(a,I,0) = aux;
            A_gn(0,a,I) = aux;
        }
    }

    rhs_g(0) = wpress * vn;
}

#if __cplusplus >= 201402L
void test_idx(FillStr& fill)
{
    using namespace std;
    using namespace ttl;

    //[1] INPUT
    int eNN    = fill.eNN;

    tensor<double,2>& nborFields   = fill.nborFields;
    tensor<double,2>& nborFields0  = fill.nborFields0;

    tensor<double,1>&  globFields = fill.globFields;

    double pressure = globFields(0);

    tensor<double,1,false>  bfs(fill.bfs.data(),eNN);
    tensor<double,2,false>  Dbfs(fill.Dbfs.data(),eNN,2);

    double deltat    = 0.1;
    double tension   = 1.0 * deltat;
    double viscosity = 1.0;
    double frictiont = 1.0;
    double frictionn = 1.0;

    using index::a, index::b;
    using index::I, index::J, index::K;
    using index::i, index::j, index::k, index::l, index::m;

    tensor<double,2,false,false> nborx0 = nborFields0(all,range(0,2));
    tensor<double,2,false,false> nborv = nborFields(all,range(3,5));

    // Previous time-step
    // Compute position and tangent vectors
    tensor<double,1> x0 = bfs(a) * nborx0(a,I);
    tensor<double,2> Dx0 =  Dbfs(a,j) * nborx0(a,I);

    // Compute metric tensor
    tensor<double,2> metric0 = Dx0(i,K) * Dx0(j,K);
    tensor<double,2> imetric0 = metric0.inv();

    // Normal
    tensor<double,1> cross0 = (antisym3D(I,J,K) * Dx0(0,J)) * Dx0(1,K);
    double jac0 = sqrt(cross0*cross0);
    tensor<double,1> n0 = cross0/jac0;

    tensor<double,2> proj0 = Identity(3)(a,b)-n0(a) * n0(b);
    // Current time-step
    // Compute position and tangent vectors
    tensor<double,1> v = bfs(a) * nborv(a,I);
    tensor<double,2> Dx = Dx0(j,I) + Dbfs(a,j) * nborv(a,I);

    tensor<double,1> x = x0 + v;

    // Compute metric tensor
    tensor<double,2> metric = Dx(i,K) * Dx(j,K);

    double vn = v * n0;

    tensor<double,2> rodt = metric-metric0;
    tensor<double,2> rodt_Cc = imetric0 * rodt;
    tensor<double,2> rodt_CC = rodt_Cc * imetric0;

    tensor<double,4> dmetric = (Dbfs(a,k) * Dx(j,I))(a,I,j,k) + Dbfs(a,j) * Dx(k,I);
    tensor<double,4> dmetric_CC = (dmetric(a,I,l,m) * imetric0(m,j)) * imetric0(l,k);
    tensor<double,4> ddmetric = (Dbfs(a,k) * Dbfs(b,l))(a,b,k,l) +  Dbfs(a,l) * Dbfs(b,k);

    //[3] OUTPUT
    tensor<double,2>& rhs_n = fill.vec_n;
    tensor<double,1>& rhs_g = fill.vec_g;
    tensor<double,4>& A_nn  = fill.mat_nn;
    tensor<double,3>& A_ng  = fill.mat_ng;
    tensor<double,3>& A_gn  = fill.mat_gn;

    double wjac = fill.w_sample * jac0;
    double wfrict = wjac * frictiont;
    double wfricn = wjac * frictionn;
    double wvisco = 4.0 * wjac * viscosity;
    double wactiv = 2.0 * wjac * tension;
    double wpress = wjac * deltat;

    tensor<double,2> aux0 = wvisco * rodt_CC + wactiv * imetric0;
    tensor<double,3> aux1 = bfs(a) * (wfrict * proj0(I,J) + wfricn * n0(I) * n0(J));

    rhs_n = aux1 * v;
    rhs_n(a,I) += bfs(a) * ((wpress * pressure) * n0(I));
    rhs_n(a,I) += dmetric(a,I,k,l) * aux0(k,l);

    A_nn(a,I,b,J) = aux1(a,I,J) * bfs(b);
    A_nn(a,I,b,J) += (wvisco * dmetric(a,I,k,l)) * dmetric_CC(b,J,k,l);

    tensor<double,2> aux2 = bfs(a) * (wpress * n0(I));
    A_ng(a,I,0) += aux2(a,I);
    A_gn(0,a,I) += aux2(a,I);

    tensor<double,2> aux3 = ddmetric(a,b,k,l) * aux0(k,l);
    A_nn(a,0,b,0) += aux3(a,b);
    A_nn(a,1,b,1) += aux3(a,b);
    A_nn(a,2,b,2) += aux3(a,b);

    rhs_g(0) += wpress * vn;
}
#endif

void test_tensor(FillStr& fill)
{

    using namespace std;
    using namespace ttl;

    //[1] INPUT
    int eNN    = fill.eNN;

    tensor<double,2>& nborFields   = fill.nborFields;
    tensor<double,2>& nborFields0  = fill.nborFields0;

    tensor<double,1>&  globFields = fill.globFields;

    double pressure = globFields(0);

    tensor<double,1,false>  bfs(fill.bfs.data(),eNN);
    tensor<double,2,false>  Dbfs(fill.Dbfs.data(),eNN,2);

    double deltat    = 0.1;
    double tension   = 1.0 * deltat;
    double viscosity = 1.0;
    double frictiont = 1.0;
    double frictionn = 1.0;

    // Previous time-step
    // Compute position and tangent vectors
    tensor<double,1> x0 = bfs * nborFields0(all,range(0,2));
    tensor<double,2> Dx0 =  Dbfs.T() * nborFields0(all,range(0,2));

    // Compute metric tensor
    tensor<double,2> metric0 = Dx0 * Dx0.T();
    tensor<double,2> imetric0 = metric0.inv();

    // Normal
    tensor<double,1> cross0 = {Dx0(0,1) * Dx0(1,2) - Dx0(0,2) * Dx0(1,1), Dx0(0,2) * Dx0(1,0) - Dx0(0,0) * Dx0(1,2), Dx0(0,0) * Dx0(1,1) - Dx0(0,1) * Dx0(1,0)  };
    double jac0 = sqrt(cross0*cross0);
    tensor<double,1> n0 = cross0/jac0;

    tensor<double,2> proj0 = Identity(3);
    tensor<double,2> n0n0 = outer(n0,n0);
    proj0 = proj0 - n0n0;

    // Current time-step
    // Compute position and tangent vectors
    tensor<double,1> v = bfs * nborFields0(all,range(3,5));
    tensor<double,2> Dx = Dbfs.T() * (nborFields0(all,range(0,2))+nborFields(all,range(3,5)));

    tensor<double,1> x = x0 + v;

    // Compute metric tensor
    tensor<double,2> metric = Dx * Dx.T();

    tensor<double,1> proj0v = proj0*v;
    double vn = v * n0;

    tensor<double,2> rodt = metric-metric0;
    tensor<double,2> rodt_Cc = imetric0 * rodt;
    tensor<double,2> rodt_CC = rodt_Cc * imetric0;

    tensor<double,4> dmetric = outer(Dbfs,Dx).transpose({0,3,2,1}) + outer(Dbfs,Dx).transpose({0,3,1,2});

    tensor<double,4> dmetric_CC =  product(product(dmetric,imetric0,{{2,0}}),imetric0,{{2,0}});

    tensor<double,4> ddmetric = outer(Dbfs,Dbfs).transpose({0,2,1,3}) + outer(Dbfs,Dbfs).transpose({0,2,3,1});
    //[3] OUTPUT
    tensor<double,2>& rhs_n = fill.vec_n;
    tensor<double,1>& rhs_g = fill.vec_g;
    tensor<double,4>& A_nn  = fill.mat_nn;
    tensor<double,3>& A_ng  = fill.mat_ng;
    tensor<double,3>& A_gn  = fill.mat_gn;


    double wjac = fill.w_sample * jac0;
    double wfrict = wjac * frictiont;
    double wfricn = wjac * frictionn;
    double wvisco = 4.0 * wjac * viscosity;
    double wactiv = 2.0 * wjac * tension;
    double wpress = wjac * deltat;

    tensor<double,2> aux0 = wvisco * rodt_CC + wactiv * imetric0;
    tensor<double,3> aux1 = outer(bfs, wfrict * proj0 + wfricn * n0n0);

    rhs_n = aux1 * v;
    rhs_n += wpress * pressure * outer(bfs, n0);
    rhs_n += product(dmetric, aux0,{{2,0},{3,1}});

    A_nn = outer(bfs,aux1.transpose({2,0,1}));
    A_nn += wvisco * product(dmetric,dmetric_CC,{{2,2},{3,3}});

    tensor<double,2> aux2 = wpress * outer(bfs, n0);
    A_ng(all,all,0) += aux2;
    A_gn(0,all,all) += aux2;

    tensor<double,2> aux3 = product(ddmetric, wvisco * rodt_CC,{{2,0},{3,1}})+ product(ddmetric, wactiv * imetric0,{{2,0},{3,1}});
    A_nn(all,0,all,0) += aux3;
    A_nn(all,1,all,1) += aux3;
    A_nn(all,2,all,2) += aux3;

    rhs_g(0) += wpress * vn;
}

int main()
{
    using namespace std;
    using namespace ttl;
    // using ttl::vector;
    FillStr str;

    int N = 1000000;

    int eNN = 12;
    str.vec_n = 0.0;
    str.mat_nn = 0.0;

    auto start0 = std::chrono::high_resolution_clock::now();
    for(int i = 0; i < N; i++)
        test_notensor(str);
    auto finish0 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed0 = finish0 - start0;

    tensor<double,2> B0(eNN,3);
    B0 = str.vec_n;
    tensor<double,4> A0(eNN,3,eNN,3);
    A0 = str.mat_nn;

    str.vec_n = 0.0;
    str.mat_nn = 0.0;

    auto start1 = std::chrono::high_resolution_clock::now();
    for(int i = 0; i < N; i++)
        test_for(str);
    auto finish1 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed1 = finish1 - start1;

    tensor<double,2> B1(eNN,3);
    B1 = str.vec_n;
    tensor<double,4> A1(eNN,3,eNN,3);
    A1 = str.mat_nn;

#if __cplusplus >= 201402L
    str.vec_n = 0.0;
    str.mat_nn = 0.0;
    auto start2 = std::chrono::high_resolution_clock::now();
    for(int i = 0; i < N; i++)
        test_idx(str);
    auto finish2 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed2 = finish2 - start2;

    tensor<double,2> B2(eNN,3);
    B2 = str.vec_n;
    tensor<double,4> A2(eNN,3,eNN,3);
    A2 = str.mat_nn;
#endif

    str.vec_n = 0.0;
    str.mat_nn = 0.0;
    auto start3 = std::chrono::high_resolution_clock::now();
    for(int i = 0; i < N; i++)
        test_tensor(str);
    auto finish3 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed3 = finish3 - start3;

    tensor<double,2> B3(eNN,3);
    B3 = str.vec_n;
    tensor<double,4> A3(eNN,3,eNN,3);
    A3 = str.mat_nn;

    double difB_1 = (B1-B0).norm();
    double difA_1 = (A1-A0).norm();
    if(difB_1>1.E-10 and difA_1>1.E-10)
    {
        cout << "ERROR: loops (for - tensor for) give different results" << endl;
        return 1;
    }
#if __cplusplus >= 201402L
    double difB_2 = (B2-B0).norm();
    double difA_2 = (A2-A0).norm();
    if(difB_2>1.E-10 and difA_2>1.E-10)
    {
        cout << "ERROR: loops (for - tensor indices) give different results" << endl;
        return 1;
    }
#endif
    double difB_3 = (B3-B0).norm();
    double difA_3 = (A3-A0).norm();
    if(difB_3>1.E-10 and difA_3>1.E-10)
    {
        cout << "ERROR: loops (for - tensor product) give different results" << endl;
        return 1;
    }

    cout << "Time for: " << elapsed0.count() << endl;
    cout << "Time tensor for: " << elapsed1.count() << " (" << elapsed1.count()/elapsed0.count()  << " times more)" << endl;
#if __cplusplus >= 201402L
    cout << "Time tensor indices: " << elapsed2.count() << " (" << elapsed2.count()/elapsed0.count()  << " times more)" << endl;
#endif
    cout << "Time tensor product: " << elapsed3.count() << " (" << elapsed3.count()/elapsed0.count()  << " times more)" << endl;

    return 0;
}
