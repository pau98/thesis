
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_ConsistencyCheck.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);

/// In this first tutorial everything is implemented inside the main
///   function
int main()
{
    MPI_Init(nullptr, nullptr);


    BasisFuncType bfType = BasisFuncType::SubdivSurfs;
    ElemType eType = ElemType::Triang;
    int bfOrder = 2;

    double spacing_coarse  = 0.05;
    int refin = 10;
    double spacing_refined = spacing_coarse/refin;

    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
//    structMesh->setPeriodicBoundaryCondition({Axis::Xaxis,Axis::Yaxis});
    structMesh->genStructMesh(int(1./spacing_refined+0.5));

    ///===========             Distribute mesh            ===========///
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    ///===========           Create DOFHandler            ===========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setDOFs({"z"});
    dofHand->setNodeAuxF({"f"});
    dofHand->Update();

    for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    {
        auto x = dofHand->mesh->nodeCoords(i,IndexType::Local);

        if ( int(x[0]/spacing_refined+0.5)%refin == 0 and int(x[1]/spacing_refined+0.5)%refin == 0)
        {
//            if ( sqrt((x[0]-0.5)*(x[0]-0.5)+(x[1]-0.5)*(x[1]-0.5)) > 0.2499999)
            if ( abs(x[0]-0.5) > 0.25 or abs(x[1]-0.5) > 0.25)
            {
                dofHand->setConstraint(0,i,IndexType::Local,0.0);
            }
        }
    }
    dofHand->UpdateGhosts();


//    for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
//    {
//        auto x = dofHand->mesh->nodeCoords(i, IndexType::Local);
//        dofHand->nodeDOFs->setValue(0,i,IndexType::Local,sqrt(x[0]*x[0]+x[1]*x[1]));
//    }

    RCP<UserStructure> userStr = rcp ( new UserStructure);
    userStr->dparam.resize(3);

    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setUserStructure(userStr);

    ///===========            Set integration             ===========///
    hiperProbl->setIntegration("Integ", {"dofHand"});
//    hiperProbl->setElementFillings("Integ", ConsistencyCheck<LS>);
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->setCubatureGauss("Integ", 3);

//    hiperProbl->setConsistencyCheckTolerance(1.E-5);
//    hiperProbl->setConsistencyCheckDelta(1.E-5);
    ///===========                 Update                ===========///
    hiperProbl->Update();

    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
//    RCP<AztecOOIterativeLinearSolver> solver = rcp ( new AztecOOIterativeLinearSolver());
//    solver->setHiPerProblem(hiperProbl);
//    solver->setTolerance(1.E-8);
//    solver->setMaxNumIterations(500);
//    solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
//    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
//    solver->Update();


    RCP<AmesosDirectLinearSolver> solver = rcp ( new AmesosDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setDefaultParameters();
    solver->Update();

    RCP<NewtonRaphsonNonlinearSolver> nonlinsolver = rcp ( new NewtonRaphsonNonlinearSolver());
    nonlinsolver->setLinearSolver(solver);
    nonlinsolver->setLineSearch(false);
    nonlinsolver->setResTolerance(1.E-8);
    nonlinsolver->setSolTolerance(1.E-8);
    nonlinsolver->setMaxNumIterations(10);
    nonlinsolver->setPrintIntermInfo(true);
    nonlinsolver->Update();


    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    hiperProbl->FillLinearSystem();

    ofstream ofiletxt("matrix."+ to_string(hiperProbl->myRank())+".txt");
    ofiletxt << *hiperProbl->A << endl;
    ofiletxt.close();

    int nSteps = 1;
    for(int i = 0; i < nSteps; i++)
    {
        userStr->dparam[0] = 12;
        userStr->dparam[1] = (i+1) * 4.0/nSteps;
        userStr->dparam[2] = 1.5E-3;

        cout << "Tension=" << userStr->dparam[0] << ", Pressure=" << userStr->dparam[1] <<", Curvature=" <<userStr->dparam[1]/userStr->dparam[0] << endl;
        bool status = nonlinsolver->solve();
        nonlinsolver->output();
        dofHand->printFileLegacyVtk("dome"+to_string(i), true);

    }


    dofHand->removeConstraint(0);
    hiperProbl->FillLinearSystem();

    dofHand->nodeAuxF->setValue(hiperProbl->linProbl->GetRHS());


    dofHand->printFile("dome");
    dofHand->printFileLegacyVtk("dome", true);
    dofHand->printFileLegacyCSV("dome", true);


    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}

void LS(RCP<FillStructure> fillStr)
{


    double tension  = fillStr->userStr->dparam[0];
    double pressure = fillStr->userStr->dparam[1];
    double kappa    = fillStr->userStr->dparam[2];

    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    ///===========          Initialize variables           ==========///
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension

    tensor<double,2,false> nborCoords(subFill.nborCoords.data(),eNN,nDim);  // Vector of node coordinates
    tensor<double,1,false> nborDOFs(subFill.nborDOFs.data(),eNN);  // Vector of node coordinates
    tensor<double,1,false> bf(subFill.nborBFsDers(0),eNN);        // Local shape function
    tensor<double,2,false> Dbf(subFill.nborBFsDers(1),eNN,pDim); // Local shape function derivatives
    tensor<double,3,false> DDbf(subFill.nborBFsDers(2),eNN,pDim,pDim); // Local shape function derivatives


    tensor<double,2,false> Ak(fillStr->Ak(0,0).data(),eNN,eNN);
    tensor<double,1,false> Bk(fillStr->Bk(0).data(),eNN);


    tensor<double,2> Dbf_g(eNN,pDim);
    tensor<double,3> DDbf_g(eNN,pDim,pDim);
    tensor<double,1> lapbf(eNN);
    double jac0{};
    GlobalBasisFunctions::hessians(Dbf_g,jac0,DDbf_g,lapbf,subFill);


    double z = bf * nborDOFs;

    tensor<double,1> Dz_g  = nborDOFs * Dbf_g;
    tensor<double,2> DDz_g = nborDOFs * DDbf_g;

    double sq = sqrt(1.+Dz_g*Dz_g);
    double jac = jac0 * sq;

    tensor<double,1>  djac = jac0/sq * Dbf_g * Dz_g;
    tensor<double,2> ddjac = jac0/sq * (Dbf_g * Dbf_g.T()) - jac0/(sq*sq*sq) * outer(Dbf_g * Dz_g,Dbf_g * Dz_g);

    double energy{};
    energy -= jac0 * pressure * z;
    Bk     -= jac0 * pressure * bf;

    energy += jac * tension;
    Bk += tension *  djac;
    Ak += tension * ddjac;

    double num = DDz_g(0,0) * (1+Dz_g(1)*Dz_g(1)) + DDz_g(1,1) * (1+Dz_g(0)*Dz_g(0)) - 2.0 * DDz_g(0,1) * Dz_g(0) * Dz_g(1);
    double den = sq*sq*sq;
    double meanCurv = num/den;

    tensor<double,1> dnum = DDbf_g(all,0,0) * (1+Dz_g(1)*Dz_g(1)) +
                            2.0 * DDz_g(0,0) *  Dz_g(1) * Dbf_g(all,1) +
                            DDbf_g(all,1,1) * (1 + Dz_g(0)* Dz_g(0)) +
                            2.0 * DDz_g(1,1) * Dz_g(0) * Dbf_g(all,0) -
                            2.0 * DDbf_g(all,0,1) * Dz_g(0) * Dz_g(1) -
                            2.0 * DDz_g(0,1) * Dbf_g(all,0) * Dz_g(1)-
                            2.0 * DDz_g(0,1) * Dz_g(0) * Dbf_g(all,1);

    tensor<double,2> ddnum = 2.0 * Dz_g(1)    * outer(DDbf_g(all,0,0), Dbf_g(all,1)) +
                             2.0 * Dz_g(1)    * outer(Dbf_g(all,1),    DDbf_g(all,0,0)) +
                             2.0 * DDz_g(0,0) * outer(Dbf_g(all,1),    Dbf_g(all,1)) +
                             2.0 * Dz_g(0)    * outer(DDbf_g(all,1,1), Dbf_g(all,0)) +
                             2.0 * Dz_g(0)    * outer(Dbf_g(all,0),    DDbf_g(all,1,1)) +
                             2.0 * DDz_g(1,1) * outer(Dbf_g(all,0),    Dbf_g(all,0)) -
                             2.0  * Dz_g(1)   * outer(DDbf_g(all,0,1), Dbf_g(all,0)) -
                             2.0  * Dz_g(1)   * outer(Dbf_g(all,0),    DDbf_g(all,0,1)) -
                             2.0 * Dz_g(0)    * outer(DDbf_g(all,0,1), Dbf_g(all,1)) -
                             2.0 * Dz_g(0)    * outer(Dbf_g(all,1),    DDbf_g(all,0,1)) -
                             2.0 * DDz_g(0,1) * outer(Dbf_g(all,0),    Dbf_g(all,1)) -
                             2.0 * DDz_g(0,1) * outer(Dbf_g(all,1),    Dbf_g(all,0));

    tensor<double,1> dden  = 3.0 * sq * Dbf_g * Dz_g;
    tensor<double,2> ddden = 3.0 * sq * Dbf_g * Dbf_g.T() + 3.0/sq * outer(Dbf_g * Dz_g,Dbf_g * Dz_g);

    tensor<double,1> dmeanCurv  = (dnum * den - dden * num)/(den * den);
    tensor<double,2> ddmeanCurv = (((ddnum * den + outer(dnum,dden) - ddden * num - outer(dden,dnum))*den)- 2.0 * outer((dnum * den - dden * num),dden))/(den * den * den);

    energy += 0.5 * jac * kappa * meanCurv * meanCurv;
    Bk += jac * kappa * meanCurv * dmeanCurv + 0.5 * kappa * meanCurv * meanCurv * djac;
    Ak += jac * kappa * meanCurv * ddmeanCurv + jac * kappa * outer(dmeanCurv,dmeanCurv) + kappa * meanCurv * outer(djac,dmeanCurv) + kappa * meanCurv * outer(dmeanCurv,djac) + 0.5 * kappa * meanCurv * meanCurv * ddjac;

    return;
}
