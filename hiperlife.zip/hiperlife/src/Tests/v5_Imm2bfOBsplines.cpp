/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"


// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct PoissonParams
{
    enum RealParameters
    {
        force,
        beta
    };

    enum IntParameters
    {
        timeStep,
    };

    HL_PARAMETER_LIST DefaultValues
    {
        {"force", 0.0},
        {"beta", 100.0},
        {"timeStep",0}
    };
};

bool fileExists(const std::string& filename)
{
    struct stat buf;
    if (stat(filename.c_str(), &buf) != -1)
    {
        return true;
    }
    return false;
}

// ─── helper: find adjacent element pairs ────────────────────────────────────

std::vector<std::pair<int,int>> findBorderAdjacentPairs(
    Teuchos::RCP<hiperlife::DOFsHandler> dhand, int p, int rInt)
{
    using namespace hiperlife;

    auto mesh = dhand->mesh;
    vector<string> rTags = mesh->_regionTags();
    // if (std::find(rTags.begin(), rTags.end(), rTag) == rTags.end())
    //     throw runtime_error("findBorderAdjacentPairs: The provided region name could not be found");
    vector<int> rPrimes = {3,5,7,11};

    // Corner local-node indices per side of a Q_p square element:
    //   Side 0 (v=-1): nodes 0      and p
    //   Side 1 (u=+1): nodes p      and p*(p+2)
    //   Side 2 (v=+1): nodes p*(p+2) and p*(p+1)
    //   Side 3 (u=-1): nodes p*(p+1) and 0
    const std::array<std::array<int,2>,4> sideCorners = {{
        {0,       p        },
        {p,       p*(p+2)  },
        {p*(p+2), p*(p+1)  },
        {p*(p+1), 0        }
    }};
    
    dhand->elemAuxF->setValue("GhP"+to_string(rInt),0);

    std::unordered_map<int, std::vector<int>> nodeToElems;
    for (int e = 0; e < mesh->loc_nElem(); e++)
    {
        int eNN = mesh->_adjcyEN->getNumNbors(e, IndexType::Local);
        for (int i = 0; i < eNN; i++)
        {
            int gn = mesh->_adjcyEN->getNbor(e, i, IndexType::Global);
            nodeToElems[gn].push_back(e);
        }
    }

    int offs = mesh->offs_nElem();
    std::set<std::pair<int,int>> seen;
    std::vector<std::pair<int,int>> result;

    for (int e1 = 0; e1 < mesh->loc_nElem(); e1++)
    {
        if((int)dhand->elemAuxF->getValue(0,e1)%2 == 0)
        {
            for (auto& sc : sideCorners)
            {
                int gA = mesh->_adjcyEN->getNbor(e1, sc[0], IndexType::Global);
                int gB = mesh->_adjcyEN->getNbor(e1, sc[1], IndexType::Global);

                const auto& eA = nodeToElems[gA];
                const auto& eB = nodeToElems[gB];

                for (int e2 : eA)
                {
                    if (e2 == e1) continue;
                    if (std::find(eB.begin(), eB.end(), e2) == eB.end()) continue;
                    if ((int)dhand->elemAuxF->getValue(0,e2)%rPrimes[rInt] != 0) continue;
                    int g1 = e1 + offs, g2 = e2 + offs;
                    auto key = std::make_pair(std::min(g1,g2), std::max(g1,g2));
                    if (seen.insert(key).second)
                    {
                        result.push_back(key);
                        dhand->elemAuxF->setValue("GhP"+to_string(rInt),e1,IndexType::Global,1);
                        dhand->elemAuxF->setValue("GhP"+to_string(rInt),e2,IndexType::Global,1);
                    }
                }
            }
        }
    }
    return result;
}

void LS_backBulk1(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            Ak(i,0,j,0) += jac * gNagNb;
        }
    }

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);
    // Output integration points
    if (subFill.dhandDHand->nameTag() == "backDHand")
    {
        ofstream myfile;
        if (!fileExists("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv"))
        {
            myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
            myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
            myfile.close();
        }
        myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
        myfile << std::setprecision(16) << x[0] << "," << x[1] << "," << jac << endl;
        myfile.close();
    }
    return;
}

void LS_backBulk2(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    ttl::tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            Ak(i,1,j,1) += jac * gNagNb;
        }
    }

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);
    return;
}

void LS_backBorder(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    // Parameters
    double beta = fillStr.getRealParameter(PoissonParams::beta);

    // Background
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives

    // ===================== Values at int. points ==================== //
    // Compute jacobian
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
    jac = Math::Norm3D(t.data());

    // Compute unitary normal
    vector<double> n(3, 0.0);
    n[0] = -t[1]/jac;
    n[1] = -(-t[0])/jac;

    // Compute coordinates using the back mesh
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }


    ofstream myfile;
    myfile.open("cubatureImm2."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    // myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    // myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
    myfile << std::setprecision(16) << std::setprecision(16) << x[0] << " " << x[1] << " " << " " << n[0] << " " << n[1] << " " << t[0] << " " << t[1] << endl;
    myfile.close();

    // Obtain Nitsche parameter from each side
    // beta = 10.*subFill.dhandDHand->elemAuxF->getValue("lE",subFill.elemID);
    double k0 = subFill.dhandDHand->elemAuxF->getValue("k0",subFill.elemID);
    double k1 = 1.-k0;
    // double k0 = 0.5;
    // double k1 = 0.5;
    // =====================  Fill linear system ===================== //
    double gD = x[0]*x[1];

    tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    // Nitsche symmetric
    if (true)
    {
        for (int i = 0; i < eNN; i++)
        {
            double dbfnI{};
            for (int d = 0; d < pDim; d++)
                dbfnI += dbf[pDim*i+d]*n[d];
            
            // Bk(i,0) += jac * beta * bf[i]* gD;
            // Bk(i,0) += jac * gD * dbfnI;
            // Bk(i,1) += jac * beta * bf[i]* gD;
            // Bk(i,1) += jac * gD * dbfnI;
            // fillStr.Bk(0)[i*DOF*eNN] += jac * gD * gD;

            for (int j = 0; j < eNN; j++)
            {
                double dbfnJ{};
                for (int d = 0; d < pDim; d++)
                    dbfnJ += dbf[pDim*j+d]*n[d];

                // Fill matrix
                Ak(i,0,j,0) += jac * beta * bf[i] * bf[j];
                Ak(i,0,j,0) -= jac * k0 * bf[i] * dbfnJ;
                Ak(i,0,j,0) -= jac * k0 * dbfnI * bf[j];

                Ak(i,0,j,1) -= jac * beta * bf[i] * bf[j];
                Ak(i,0,j,1) -= jac * k1 * bf[i] * dbfnJ;
                Ak(i,0,j,1) += jac * k0 * dbfnI * bf[j];

                Ak(i,1,j,0) -= jac * beta * bf[j] * bf[i];
                Ak(i,1,j,0) += jac * k0 * bf[i] * dbfnJ;
                Ak(i,1,j,0) -= jac * k1 * dbfnI * bf[j];


                Ak(i,1,j,1) += jac * beta * bf[i] * bf[j];
                Ak(i,1,j,1) += jac * k1 * bf[i] * dbfnJ;
                Ak(i,1,j,1) += jac * k1 * dbfnI * bf[j];
            }
        }
    }
    // Save local length
    fillStr.addToGlobalIntegral("Length", jac);

    return;
}

void CheckSolution0(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::N, ttl::index::i;

    SubFillStructure &subFill = fillStr[0];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN = subFill.eNN;

    tensor<double, 2> Dbf(eNN, pDim);
    double jac;
    GlobalBasisFunctions::gradients(Dbf, jac, subFill);

    wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,2);
    wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
    wrapper<double, 1> bf(subFill.nborBFs(), eNN);
    tensor<double, 1> x(nDim);
    x = coordsI(N, i) * bf(N);

    const double u_numeric = dofsI(N,0) * bf(N);
    const double u_analytial = sin(M_PI*x(0))*sinh(M_PI*x(1)) / sinh(M_PI);
    const double error = jac * abs(u_numeric-u_analytial);
    fillStr.addToGlobalIntegral("error", error);
}

void CheckSolution1(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::N, ttl::index::i;

    SubFillStructure &subFill = fillStr[0];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN = subFill.eNN;

    tensor<double, 2> Dbf(eNN, pDim);
    double jac;
    GlobalBasisFunctions::gradients(Dbf, jac, subFill);

    wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,2);
    wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
    wrapper<double, 1> bf(subFill.nborBFs(), eNN);
    tensor<double, 1> x(nDim);
    x = coordsI(N, i) * bf(N);

    const double u_numeric = dofsI(N,1) * bf(N);
    const double u_analytial = sin(M_PI*x(0))*sinh(M_PI*x(1)) / sinh(M_PI);
    const double error = jac * abs(u_numeric-u_analytial);
    fillStr.addToGlobalIntegral("error", error);
}

void CheckNitsche(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::N, ttl::index::i;

    //============          Initialize variables           ===========//
    // Parameters
    double beta = fillStr.getRealParameter(PoissonParams::beta);

    // Background
    SubFillStructure &subFill = fillStr[0];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    ttl::wrapper<double, 1> bft(subFill.nborBFs(), eNN);

    // ===================== Values at int. points ==================== //
    // Compute jacobian
    tensor<double,2> dbf(eNN,pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf, jac, subFill);

    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
    jac = Math::Norm3D(t.data());

    // Compute unitary normal
    tensor<double,1> n(2);
    n(0) = -t[1]/jac;
    n(1) = -(-t[0])/jac;

    // Compute coordinates using the back mesh
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }
    ttl::wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,2);
    const double u0 = dofsI(N,0) * bft(N);
    const double u1 = dofsI(N,1) * bft(N);
    tensor<double,1> du1 = dofsI(N,0) * dbf(N,i);
    tensor<double,1> du0 = dofsI(N,1) * dbf(N,i);

    // Save local length
    fillStr.addToGlobalIntegral("uErr", jac*(u0-u1)*(u0-u1));
    fillStr.addToGlobalIntegral("duErr", jac*(du0*n-du1*n)*(du0*n-du1*n));

    return;
}


void LSPre(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using hiperlife::Tensor::tensor;
    using namespace hiperlife::Tensor;

    SubFillStructure& subFill = fillStr["preDhand"];

    int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
    int numAuxF  = subFill.numAuxF;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    ttl::wrapper<double,2> nborAuxF(subFill.nborAuxF.data(), eNN, numAuxF);

    std::vector<double> b0 = {-1};
    std::vector<std::vector<double>>& pbf0 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b0, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf1 ={pbf0[0][0],pbf0[0][1],pbf0[0][2],pbf0[0][3]}; 
    std::vector<double> b1 = {1};
    std::vector<std::vector<double>>& pbf1 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b1, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf2 ={pbf1[0][0],pbf1[0][1],pbf1[0][2],pbf1[0][3]}; 

    // Get output
    tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    Bk(1,0) = nborAuxF(1,0);
    Bk(1,1) = nborAuxF(1,1);
    Bk(2,0) = nborAuxF(2,0);
    Bk(2,1) = nborAuxF(2,1);
    for (int a = 0; a<eNN; a++)
    {
        Ak(a,0,1,0) = bf1[a];
        Ak(a,1,1,1) = bf1[a];

        Ak(a,0,2,0) = bf2[a];
        Ak(a,1,2,1) = bf2[a];
    }
}


void genCircBspline(double r, std::vector<double> &U,std::vector<std::vector<std::vector<std::vector<double>>>> &CP, double xOff, double yOff, ElemType eTypeB,BasisFuncType bTypeB,int bfOrderB,int nPtsCircOr,SmartPtr<ParamStructure> paramStr)
{
  // Compute immersed mesh CPs position
  SmartPtr<StructMeshGenerator> preBSMesh = Create<StructMeshGenerator>();

  preBSMesh->setMesh(eTypeB, bTypeB, bfOrderB);
  
  std::vector<double> preU(nPtsCircOr+1,0);
  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    preU[i] = preU[i-1]+1;
  }
  
  std::vector<std::vector<std::vector<std::vector<double>>>> preCP(nPtsCircOr, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
  for (int k = 0;  k < nPtsCircOr; k++)
  {
    double t = 2*M_PI*k/nPtsCircOr;
    preCP[k][0][0] = {std::cos(t),std::sin(t),0,0};
  }
  
  preBSMesh->genBsplinesClosedCurve(preU,preCP);
  // Distributed mesh
  SmartPtr<DistributedMesh> preDisBSMesh = Create<DistributedMesh>("preDisBSMesh");
  preDisBSMesh->setMesh(preBSMesh);
  preDisBSMesh->setBalanceMesh(true);
  preDisBSMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
  preDisBSMesh->setVerbosity(Verbosity::None);
  preDisBSMesh->Update();
  
  // Set Degree of Freedom handler
  SmartPtr<DOFsHandler> preDhand = Create<DOFsHandler>(preDisBSMesh);
  preDhand->setNameTag("preDhand");
  preDhand->setNumDOFs(2);
  preDhand->setDOFs({"pcx","pcy"});
  preDhand->setNodeAuxF({"x","y","dxdt","dydt"});
  preDhand->Update();


  std::vector<double> cw = {1};
  for (int i = 0; i<preDisBSMesh->nPts();i++)
  {
    double t = 2.*M_PI*double(i)/double(nPtsCircOr);
    double x = xOff;
    double y = yOff;
    for (int iw = 0; iw<cw.size(); iw++)
    {
      x += cw[iw]*cos((iw+1)*t)*r;
      y += cw[iw]*sin((iw+1)*t)*r;
    }
    preDhand->nodeAuxF->setValue(0,i,IndexType::Global,x);
    preDhand->nodeAuxF->setValue(1,i,IndexType::Global,y);
  }

  SmartPtr<HiPerProblem> preHiperProbl = Create<HiPerProblem>();
  preHiperProbl->setParameterStructure(paramStr);
  preHiperProbl->setDOFsHandlers({preDhand});
  
  // Interface integration
  preHiperProbl->setIntegration("IntegPre", {"preDhand"});
  preHiperProbl->setCubatureGauss("IntegPre", 1);
  preHiperProbl->setElementFillings("IntegPre", LSPre);

  preHiperProbl->Update();

  SmartPtr<MUMPSDirectLinearSolver> preSolver = Create<MUMPSDirectLinearSolver>();
  preSolver->setHiPerProblem(preHiperProbl);
  preSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
  preSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
  preSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Sequential);
  preSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
  preSolver->setConvergenceCriteria(MUMPSDirectLinearSolver::ConvergenceCriteria::Relative);
  preSolver->setTolerance(1e-8);
  preSolver->setDefaultParameters();
  preSolver->Update();

  // Solve
  preSolver->solve();
  preHiperProbl->UpdateGhosts();

  // Update Solution
  preSolver->UpdateSolution();

  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    U[i] = U[i-1]+1.;
  }

  for (int k = 0;  k < nPtsCircOr; k++)
  {  
    double x = preDhand->nodeDOFs->getValue(0,k,IndexType::Global);
    double y = preDhand->nodeDOFs->getValue(1,k,IndexType::Global);
    CP[k][0][0] = {x,y,0,0};
  }
}


Eigen::VectorXd solveGeneralizedEigen(
    const Eigen::MatrixXd& M1,
    const Eigen::MatrixXd& M2,
    Eigen::MatrixXd& vecs,
    double reg = 1e-12)   // small regularization if M2 is near-singular
{
    int n = M1.rows();

    // Optionally regularize M2 to ensure positive definiteness
    Eigen::MatrixXd M2_reg = M2 + reg * Eigen::MatrixXd::Identity(n, n);

    // Cholesky decomposition of M2: M2 = L * L^T
    Eigen::LLT<Eigen::MatrixXd> llt(M2_reg);
    if (llt.info() != Eigen::Success)
        throw std::runtime_error("Cholesky failed: M2 is not positive definite.");

    Eigen::MatrixXd L = llt.matrixL();

    // Reduce to standard problem: A = L^{-1} * M1 * L^{-T}
    Eigen::MatrixXd Linv_M1 = L.triangularView<Eigen::Lower>().solve(M1);
    Eigen::MatrixXd A = L.triangularView<Eigen::Lower>().solve(Linv_M1.transpose()).transpose();

    // Symmetrize to kill floating-point asymmetry
    A = 0.5 * (A + A.transpose());

    // Standard symmetric eigenproblem on A
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> solver(A);
    if (solver.info() != Eigen::Success)
        throw std::runtime_error("Eigendecomposition failed.");

    // Back-transform eigenvectors: v = L^{-T} * w
    Eigen::MatrixXd W = solver.eigenvectors();
    vecs = L.transpose().triangularView<Eigen::Upper>().solve(W);

    return solver.eigenvalues();  // ascending order
}

void FacetStbR0(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;

    SubFillStructure& e0 = fillStr[0];
    SubFillStructure& e1 = fillStr[1];
    int eNN  = e0.eNN;
    int nDim = e0.nDim;
    int pDim = e0.pDim;
    int numDOFs = e0.numDOFs;
    double gmm = 0.05;
    double h = 0.01;
    double* Dbf    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
    double* bf    = e0.nborBFs();      // local BF: [eNN]
    double* coords = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]

    // Reference tangent vector along the boundary side (length pDim)
    std::vector<double> tangRef = e0.tangentsBoundaryRef();

    // Push tangRef through the Jacobian to obtain the physical tangent
    //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
    //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
    std::vector<double> tangPhys(nDim, 0.0);
    for (int a = 0; a < nDim; a++)
    {
        for (int b = 0; b < pDim; b++)
        {
            double Jab = 0.0;
            for (int i = 0; i < eNN; i++)
                Jab += Dbf[i*pDim + b] * coords[i*nDim + a];
            tangPhys[a] += Jab * tangRef[b];
        }
    }
    tensor<double,1> x(2);
    x *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int i = 0; i < pDim; i++)
        {
            x(i) += bf[a]*coords[a*nDim + i];
        }
    }

    double edge_jac = 0.0;
    for (double t : tangPhys) edge_jac += t * t;
    edge_jac = std::sqrt(edge_jac);

    // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
    tensor<double,1> n(2);
    n(0) = -tangPhys[1]/edge_jac;
    n(1) = tangPhys[0]/edge_jac;
    // cout << "N: " << n<<endl;

    tensor<double,2> gDbf0(eNN,pDim);
    tensor<double,3> gHbf0(eNN,pDim,pDim);
    tensor<double,1> gLbf0(eNN);
    double jac0;
    // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);
    tensor<double,1> DbfN0 = gDbf0*n;

    tensor<double,1> HbfN0(eNN);
    GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);

    tensor<double,2> gDbf1(eNN,pDim);
    tensor<double,3> gHbf1(eNN,pDim,pDim);
    tensor<double,1> gLbf1(eNN);
    double jac1;
    // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);
    tensor<double,1> DbfN1 = gDbf1*n;

    tensor<double,1> HbfN1(eNN);
    GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);

    for (int a = 0; a < eNN; a++)
    {
        if (fabs(n(0))>fabs(n(1))) // Vertical face
        {
            HbfN0(a) = gHbf0(a,0,0);
            HbfN1(a) = gHbf1(a,0,0);
        }
        else // Horizontal face
        {
            HbfN0(a) = gHbf0(a,1,1);
            HbfN1(a) = gHbf1(a,1,1);
        }
    }

    tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
    Ak00 *=0;
    Ak01 *=0;
    Ak10 *=0;
    Ak11 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int b = 0; b < eNN; b++)
        {
            // Ak00(a,0,b,0) += edge_jac*h*gmm*(DbfN0(a)*DbfN0(b));
            // Ak01(a,0,b,0) += -edge_jac*h*gmm*(DbfN0(a)*DbfN1(b));
            // Ak10(a,0,b,0) += -edge_jac*h*gmm*(DbfN1(a)*DbfN0(b));
            // Ak11(a,0,b,0) += edge_jac*h*gmm*(DbfN1(a)*DbfN1(b));

            if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
            {
                Ak00(a,0,b,0) += edge_jac*h*h*h*gmm*(HbfN0(a)*HbfN0(b));
                Ak01(a,0,b,0) += -edge_jac*h*h*h*gmm*(HbfN0(a)*HbfN1(b));
                Ak10(a,0,b,0) += -edge_jac*h*h*h*gmm*(HbfN1(a)*HbfN0(b));
                Ak11(a,0,b,0) += edge_jac*h*h*h*gmm*(HbfN1(a)*HbfN1(b));
            }
        }
        
    }
    // Ak00 *=-1;
    // Ak01 *=-1;
    // Ak10 *=-1;
    // Ak11 *=-1;
    fillStr.addToGlobalIntegral("total_edge_length", edge_jac);

    ofstream myfile;
    myfile.open("fStb0.csv", std::ios_base::app);
    myfile << std::setprecision(16) << x(0) << " " << x(1) << " " << 1 << endl;
    myfile.close();

}

void FacetStbR1(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;

    SubFillStructure& e0 = fillStr[0];
    SubFillStructure& e1 = fillStr[1];
    int eNN  = e0.eNN;
    int nDim = e0.nDim;
    int pDim = e0.pDim;
    int numDOFs = e0.numDOFs;
    double gmm = 0.05;
    double h = 0.01;
    double* Dbf    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
    double* bf    = e0.nborBFs();      // local BF: [eNN]
    double* coords = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]
    vector<double> Ecoords = {-1.,-1.,0.,-1.,1.,-1.,-1.,0.,0.,0.,1.,0.,-1.,1.,0.,1.,1.,1.};   // node coordinates:     [eNN × nDim]

    // Reference tangent vector along the boundary side (length pDim)
    std::vector<double> tangRef = e0.tangentsBoundaryRef();

    // Push tangRef through the Jacobian to obtain the physical tangent
    //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
    //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
    std::vector<double> tangPhys(nDim, 0.0);
    for (int i = 0; i < nDim; i++)
    {
        for (int j = 0; j < pDim; j++)
        {
            double Jab = 0.0;
            for (int a = 0; a < eNN; a++)
                Jab += Dbf[a*pDim + j] * coords[a*nDim + i];
            tangPhys[i] += Jab * tangRef[j];
        }
    }
    tensor<double,1> x(2);
    x *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int i = 0; i < pDim; i++)
        {
            x(i) += bf[a]*coords[a*nDim + i];
        }
    }
    

    double edge_jac = 0.0;
    for (double t : tangPhys) edge_jac += t * t;
    edge_jac = std::sqrt(edge_jac);

    // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
    tensor<double,1> n(2);
    n(0) = -tangPhys[1]/edge_jac;
    n(1) = tangPhys[0]/edge_jac;
    // cout << "N: " << n<<endl;

    tensor<double,2> gDbf0(eNN,pDim);
    tensor<double,3> gHbf0(eNN,pDim,pDim);
    tensor<double,1> gLbf0(eNN);
    double jac0;
    // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);
    tensor<double,1> DbfN0 = gDbf0*n;

    tensor<double,1> HbfN0(eNN);
    GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);

    tensor<double,2> gDbf1(eNN,pDim);
    tensor<double,3> gHbf1(eNN,pDim,pDim);
    tensor<double,1> gLbf1(eNN);
    double jac1;
    // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);
    tensor<double,1> DbfN1 = gDbf1*n;

    tensor<double,1> HbfN1(eNN);
    GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);

    for (int a = 0; a < eNN; a++)
    {
        if (fabs(n(0))>fabs(n(1))) // Vertical face
        {
            HbfN0(a) = gHbf0(a,0,0);
            HbfN1(a) = gHbf1(a,0,0);
        }
        else // Horizontal face
        {
            HbfN0(a) = gHbf0(a,1,1);
            HbfN1(a) = gHbf1(a,1,1);
        }
    }

    // cout << "X: "<< x << ": " << HbfN0 << " "<< HbfN1 << endl;
    tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
    Ak00 *=0;
    Ak01 *=0;
    Ak10 *=0;
    Ak11 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int b = 0; b < eNN; b++)
        {
            // Ak00(a,1,b,1) += edge_jac*h*gmm*(DbfN0(a)*DbfN0(b));
            // Ak01(a,1,b,1) += -edge_jac*h*gmm*(DbfN0(a)*DbfN1(b));
            // Ak10(a,1,b,1) += -edge_jac*h*gmm*(DbfN1(a)*DbfN0(b));
            // Ak11(a,1,b,1) += edge_jac*h*gmm*(DbfN1(a)*DbfN1(b));

            if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
            {
                Ak00(a,1,b,1) += edge_jac*h*h*h*gmm*(HbfN0(a)*HbfN0(b));
                Ak01(a,1,b,1) += -edge_jac*h*h*h*gmm*(HbfN0(a)*HbfN1(b));
                Ak10(a,1,b,1) += -edge_jac*h*h*h*gmm*(HbfN1(a)*HbfN0(b));
                Ak11(a,1,b,1) += edge_jac*h*h*h*gmm*(HbfN1(a)*HbfN1(b));
            }
        }
    }
    // Ak00 *=-1;
    // Ak01 *=-1;
    // Ak10 *=-1;
    // Ak11 *=-1;
    fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
    ofstream myfile;
    myfile.open("fStb1.csv", std::ios_base::app);
    myfile << std::setprecision(16) << x(0) << " " << x(1) << " " << 1 << endl;
    myfile.close();
}

int main(int argc, char** argv)
{

    hiperlife::Init(argc, argv);

    //============================ Parameters ============================//
    int nx = 100;
    int ny = nx;
    // cout << "Type number of elements per side: " << endl;
    // cin >> nx;
    SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();
    // userStr->dparam.resize(1);
    double beta = 100*nx; // beta = 100*h (from 2017Badia)
    paramStr->setRealParameter(PoissonParams::beta,beta);



    // *******************************************************************//
    // *****                      MESH CREATION                      *****//
    // *******************************************************************//
    int nSteps = 9;
    int bfOrder = 2;
    int timeStep = 0;
    bool ghP = 0;
    double wellPosedTh = 0.5;
    if(ghP)
    {
        wellPosedTh = 0;
    }
    for (int nS{}; nS < nSteps; nS++)
    {
        timeStep++;
        paramStr->setIntParameter(PoissonParams::timeStep,timeStep);
        //-------------------------- Background mesh -------------------------//

        // Mesh generator
        SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
        back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
        back->genStructMesh(nx, ny);
        // Mesh refinement
        double c0 = 0.5;
        double r0 = 0.3;
        double eps = 0.0001;
        vector<int> phmodes = {5};
        
        int refmax = 3;
        double theta = (double)nS/(double)nSteps*2*M_PI+0.5;

        double xC1 = 0.8; double yC1 = 0.2; double xC2 = 0.2; double yC2 = 0.8; 
        if (nS < nSteps/2)
        {
            yC1 += (double)nS/(double)nSteps*0.6*2.;
            yC2 -= (double)nS/(double)nSteps*0.6*2.;
        }
        else
        {
            yC1 = 0.8;
            yC2 = 0.2;
            xC1 -= (double)(nS-nSteps/2)/(double)nSteps*0.6*2.;
            xC2 += (double)(nS-nSteps/2)/(double)nSteps*0.6*2.;
        }

        SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();

        ElemType eTypeB = ElemType::Line; // Element type
        int bfOrderB = 3;   // Basis function order
        BasisFuncType bTypeB = BasisFuncType::BSplines; // Basis function type
        double r = 0.103; // Radius of immersed mesh
        int nPtsCirc = 100; // Number of control points
        std::vector<std::vector<std::vector<std::vector<double>>>> CP(nPtsCirc, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
        std::vector<double> U(nPtsCirc+1,0);

        imm->setMesh(eTypeB, bTypeB, bfOrderB);
        genCircBspline(r,U,CP,xC1,yC1,eTypeB,bTypeB,bfOrderB,nPtsCirc,paramStr);
        imm->genBsplinesClosedCurve(U,CP);

    
        SmartPtr<DistributedMesh> immProva = Create<DistributedMesh>("immMeshProva");
        immProva->setMesh(imm);
        immProva->setBalanceMesh(true);
        immProva->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        immProva->setVerbosity(Verbosity::None);
        immProva->Update();
        immProva->printFileLegacyVtk("meshProva");

        // Distributed mesh
        SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
        backMesh->setMesh(back);
        backMesh->setBalanceMesh(true);
        backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        backMesh->setVerbosity(Verbosity::None);
        backMesh->Update();


        //--------------------------- Immersed mesh --------------------------//

        // Distributed mesh
        SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
        immMesh->setMesh(imm);
        immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
        immMesh->setImmersedInteriorPoints({{{xC1, yC1, 0.0}},{{0.01,0.01,0}}});
        immMesh->setRegionTags({"Interior","Exterior"});
        immMesh->setBalanceMesh(true);
        immMesh->setIllPosThreshold(wellPosedTh);
        immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        immMesh->setVerbosity(Verbosity::None);
        immMesh->Update();

        // Print meshes
        backMesh->printFileLegacyVtk("meshBack");
        immMesh->printFileLegacyVtk("meshImm");


        // *******************************************************************//
        // *****                   DOFsHandler CREATION                  *****//
        // *******************************************************************//

        //----------------------- Background DOFsHandler ---------------------//
        SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
        backDHand->setNameTag("backDHand");
        backDHand->setDOFs({"u1","u2"});
        backDHand->setNodeAuxF({"const","ctag","stab"});
        backDHand->setElemAuxF({"tag","WI","Agg0","lE","k0","l0","l1","Agg1","GhP0","GhP1"});
        backDHand->setDofTags({"Interior","Exterior"});
        backDHand->Update();

        // Save interior/cut/exterior flags for plotting
        for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
        {
            int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
            backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
            vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
            vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
            for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
            {
                if (backDHand->mesh->isNodeInPart(nbors[n]))
                    backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
            }
        }
        backDHand->UpdateGhosts();

        // Set boundary conditions
        backDHand->setBoundaryCondition("u2", MAxis::Xmin, 0.0);
        backDHand->setBoundaryCondition("u2", MAxis::Xmax, 0.0);
        backDHand->setBoundaryCondition("u2", MAxis::Ymin, 0.0);
        backDHand->setBoundaryCondition("u2", MAxis::Ymax, [](double x){return sin(M_PI*x);});
        // // Set boundary conditions
        // backDHand->setBoundaryCondition("u2", MAxis::Xmin, 1.0);
        // backDHand->setBoundaryCondition("u2", MAxis::Xmax, 1.0);
        // backDHand->setBoundaryCondition("u2", MAxis::Ymin, 1.0);
        // backDHand->setBoundaryCondition("u2", MAxis::Ymax, 1.);
        // backDHand->UpdateGhosts();

        backDHand->printFileLegacyVtk("dofBack", true);

        // Compute facet pairs
        std::vector<std::pair<int,int>> borderFacetPairsR0 = findBorderAdjacentPairs(backDHand, bfOrder,0);
        std::vector<std::pair<int,int>> borderFacetPairsR1 = findBorderAdjacentPairs(backDHand, bfOrder,1);


        // *******************************************************************//
        // *****                    IMMERSED PROBLEM                     *****//
        // *******************************************************************//
        if (true)
        {
            // Immersed HiPerProblem
            SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
            //General setters
            immHP->setParameterStructure(paramStr);
            immHP->setGlobalIntegrals({"Area","Length","uError","duError","total_edge_length"});
            immHP->setDOFsHandlers({backDHand});

            // Set integration for the border
            immHP->setIntegration("IntegBorder", {"backDHand"});
            immHP->setCubatureBorderImmersed("IntegBorder", 5);
            immHP->setElementFillings("IntegBorder", LS_backBorder);

            // Set integration for the background mesh
            immHP->setIntegration("Integ1", {"backDHand"});
            // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
            immHP->setCubatureCutCellConforming("Integ1", 9, 4,"Interior");
            immHP->setElementFillings("Integ1", LS_backBulk1);

            // Set integration for the background mesh
            immHP->setIntegration("Integ2", {"backDHand"});
            // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
            immHP->setCubatureCutCellConforming("Integ2", 9, 4,"Exterior");
            immHP->setElementFillings("Integ2", LS_backBulk2);

            if (ghP)
            {
                // Face stabilization
                // Region 0
                immHP->setIntegration("IntegF0",{"backDHand"});
                immHP->setCubatureInteriorFacet("IntegF0", /*iPts=*/5, borderFacetPairsR0);
                immHP->setElementFillings("IntegF0", FacetStbR0);

                // Region 1
                immHP->setIntegration("IntegF1",{"backDHand"});
                immHP->setCubatureInteriorFacet("IntegF1", /*iPts=*/5, borderFacetPairsR1);
                immHP->setElementFillings("IntegF1", FacetStbR1);
            }
            immHP->Update();

            // hiperlife::Finalize();
            // return 0;

            //-------------------- Nitsche parameter estimation ------------------//
            
            // Cubature info for the boundary integration
            std::vector<Teuchos::RCP<CubatureSet>> cubaSetsB = immHP->_integ[0]->_cubaSets;

            // Linear constraints
            std::vector<std::vector<linearConstraint>> constrReg = backMesh->_cutBFConstrRegions;

            vector<int> rTags = {3,5,7,11};
            vector<vector<double>> lE(2,vector<double>(backMesh->nElem(),0.)); // Store for each element the highest eigenvalue for each region

            // For each region compute the nitsche parameter
            for (int rr = 0; rr < 2; rr++)
            {
                //Agg name tag
                std::string aggTag = "Agg"+to_string(rr);

                // Preset elem Aux Field for storing Aggragtes
                backDHand->elemAuxF->setValue(aggTag,0);

                // Cubature info for the integration in the current region
                std::vector<Teuchos::RCP<CubatureSet>> cubaSets1 = immHP->_integ[1+rr]->_cubaSets;

                // Save the different aggregagtes as element tags 
                for (int iE = 0; iE < backMesh->nElem(); iE++)
                {
                    int eTag = backDHand->elemAuxF->getValue(0,iE); // Get element tag
                    if (eTag%2 == 0 & eTag%rTags[rr] == 0) // If element in boundary
                    {
                        std::vector<int> NborNdsEi = backMesh->elemNodeNbors(iE);
                        int kP = 0;
                        for(linearConstraint lCnt : constrReg[rr])
                        {
                            int mE = -1;
                            if (NborNdsEi[4] == lCnt.slave) // If node is constrained
                            {
                                mE = backMesh->_adjcyNE->getNbor(lCnt.masters[4],0);

                                if (backDHand->elemAuxF->getValue(aggTag,mE) != 0)
                                {
                                    backDHand->elemAuxF->setValue(aggTag,iE,IndexType::Global,backDHand->elemAuxF->getValue(aggTag,mE));
                                }
                                else
                                {
                                    std::vector<int> FAdjIE = backMesh->_findFacetAdjacentElements(iE,IndexType::Global);
                                    std::vector<int> FAdjME = backMesh->_findFacetAdjacentElements(mE,IndexType::Global);
                                    int k = 0;

                                    for (int faie : FAdjIE)
                                    {
                                        while (backDHand->elemAuxF->getValue(aggTag,faie) >= k)
                                            k +=1;
                                    }
                                    for (int fame : FAdjME)
                                    {
                                        while (backDHand->elemAuxF->getValue(aggTag,fame) >= k)
                                            k +=1;
                                    }
                                    backDHand->elemAuxF->setValue(aggTag,iE,IndexType::Global,k);
                                    backDHand->elemAuxF->setValue(aggTag,mE,IndexType::Global,k);
                                }
                                break;
                            }
                        }
                    }
                }
                
                // Store patches in AP vector
                std::vector<std::vector<int>> AP{};
                std::vector<bool> elTchd(backMesh->nElem(),false);
                for (int iE = 0; iE < backMesh->nElem(); iE++)
                {
                    int eTag = backDHand->elemAuxF->getValue(0,iE);
                    if (eTag%2 == 0 & !elTchd[iE]  & eTag%rTags[rr] == 0)
                    {
                        std::vector<int> NborNdsEi = backMesh->elemNodeNbors(iE);
                        int kP = 0;
                        elTchd[iE] = true;
                        if (backDHand->elemAuxF->getValue(aggTag,iE) != 0)
                        {
                            int AggV = backDHand->elemAuxF->getValue(aggTag,iE);
                            std::vector<int> AkP = {iE};
                            std::vector<int> FAdjIE = backMesh->_findFacetAdjacentElements(iE,IndexType::Global);
                            for (int faie : FAdjIE)
                            {
                                if(backDHand->elemAuxF->getValue(aggTag,faie) == AggV & !elTchd[faie])
                                {
                                    std::vector<int> FAdjIE2 = backMesh->_findFacetAdjacentElements(faie,IndexType::Global);
                                    AkP.push_back(faie);
                                    elTchd[faie] = true;

                                    for (int faie2 : FAdjIE2)
                                    {
                                        if(backDHand->elemAuxF->getValue(aggTag,faie2) == AggV & !elTchd[faie2])
                                        {
                                            AkP.push_back(faie2);
                                            elTchd[faie2] = true;
                                        }
                                    }
                                }

                            }
                            AP.push_back(AkP);
                        }
                        else
                        {
                            std::vector<int> AkP = {iE};
                            AP.push_back(AkP);
                        }
                    }
                }

                backDHand->printFileLegacyVtk("testPatch."+to_string(nS),true);
                // // Print patches
                // for(auto akp : AP)
                // {
                //     cout << "Patch: ";
                //     for(int ep : akp)
                //         cout << ep << ", ";
                //     cout << endl;
                // }

                double Ltot = 0;
                // For each patch, solve the generalized eignevalue problem
                int ii = 0;
                for(auto akp : AP)
                {
                    ii++;
                    std::vector<int> igNds{};
                    tensor<double,2> AkG((int)akp.size()*(9),(int)akp.size()*(9));
                    AkG *= 0;
                    tensor<double,2> BkG((int)akp.size()*(9),(int)akp.size()*(9));
                    BkG *= 0;
                    double APatch = 0;
                    double LPatch = 0;
                    // cout << "Patch " << ii <<endl;
                    for (int iE : akp)
                    {
                        // cout << "Element: "<< iE << endl;
                        // Initialize local to global matrix (largest size prossible)
                        tensor<double,2> Mlg(9,(int)akp.size()*9);
                        Mlg *= 0;

                        // Get element nodes
                        std::vector<int> nNds = backMesh->elemNodeNbors(iE);

                        for (int il = 0; il < nNds.size(); il++)
                        {
                            std::vector<int> mNds = {nNds[il]}; // Initialitze master nodes vector (itsef if not constrainted)
                            std::vector<double> mWs{1.};// Initialize weights vector (1 if not constrained)
                            for(linearConstraint lCnt : constrReg[rr])
                            {
                                if (nNds[il] == lCnt.slave) // If node is constrained
                                {
                                    mNds = lCnt.masters;
                                    mWs = lCnt.weights;
                                }
                            }

                            for (int k = 0; k < mNds.size(); k++)
                            {
                                if (mWs[k] > 1e-13)
                                {
                                    auto it = find(igNds.begin(), igNds.end(), mNds[k]);
                                    int ig = std::distance(igNds.begin(), it);

                                    if (it!=igNds.end()) // Found
                                        Mlg(il,ig) += mWs[k];
                                    else // Not found
                                    {
                                        igNds.push_back(mNds[k]);
                                        Mlg(il,ig) += mWs[k];
                                    }
                                }
                                
                            }
                        }

                        // Fill Ak and Bk
                        int pDim = 2;
                        int eNN = 9; 
                        tensor<double,2> Id2 = ttl::Identity2;

                        // Compute u1 bulk integration
                        for (auto info: cubaSets1[0]->cubaInfo(iE, IndexType::Local))
                        {
                            std::vector<double> xS = info.xSamples;
                            std::vector<double> wS = info.wSamples;
                            // tensor<double,2> Aku1(18,18);
                            tensor<double,2> Aku1(9,9);
                            Aku1 *=0;

                            for (int gpi{}; gpi < wS.size(); gpi++)
                            {
                                std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
                                std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
                                tensor<double,1> bf1 = {1.,0.5*(xS[gpi*2]+1.),0.5*(xS[gpi*2+1]+1.)};
                                tensor<double,2> Jac(2,2);
                                Jac *=0;
                                tensor<double,2> Dbf(9,2);
                                tensor<double,1> bf_g(9);
                                for (int n = 0; n < 9; n++)
                                {
                                    int nbor = backMesh->_connec->getNbor(iE, n);
                                    for (int d0 = 0; d0 < 2; d0++)
                                    {
                                        // Store as tensor
                                        Dbf(n,d0) = bf[1][2*n+d0];
                                        bf_g(n) = bf[0][n];
                                        for (int d1 = 0; d1 < 2; d1++)
                                            Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
                                    }
                                }
                                tensor<double,2> Dbf_g = Dbf*Jac.inv();
                                double jac = Jac.det();
                                // if (iE == 4464 or iE == 4467)
                                //     cout << xGpi[0] <<", "<< xGpi[1] << " " << product(Dbf,Dbf,{{1,1}}) << endl;
                                // Construct submatrix 18x18 for velocity for patch

                                tensor<double,2> dede = product(Dbf_g,Dbf_g,{{1,1}});
                                //tensor<double,2> dede = product(Dbf,Dbf,{{1,1}});

                                Aku1 += wS[gpi]*0.5*jac*dede;
                                APatch += wS[gpi]*jac;
                                // if (iE == 4464 or iE == 4467)
                                // {
                                //     cout << xGpi[0] <<","<<xGpi[1] <<","<<  wS[gpi] <<endl;
                                // }
                            }
                            // if (iE == 4464 or iE == 4467)
                            // {
                            // cout << "MLG: " << Mlg << endl;
                            // cout <<"Ak: " << Aku1 << endl;
                            // }
                            AkG += Mlg.T()*Aku1*Mlg;
                        }

                        for (auto info: cubaSetsB[0]->cubaInfo(iE, IndexType::Local))
                        {

                            std::vector<double> xS = info.xSamples;
                            std::vector<double> wS = info.wSamples;
                            tensor<double,2> Bku1(9,9);
                            Bku1 *=0;

                            for (int gpi{}; gpi < wS.size(); gpi++)
                            {
                                std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
                                std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
                                tensor<double,2> Jac(2,2);
                                Jac *=0;
                                tensor<double,2> Dbf(9,2);
                                for (int n = 0; n < 9; n++)
                                {
                                    int nbor = backMesh->_connec->getNbor(iE, n);
                                    for (int d0 = 0; d0 < 2; d0++)
                                    {
                                        // Store as tensor
                                        Dbf(n,d0) = bf[1][2*n+d0];
                                        for (int d1 = 0; d1 < 2; d1++)
                                            Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
                                    }
                                }
                                tensor<double,2> Dbf_g = Dbf*Jac.inv();
                                // Construct submatrix 18x18 for velocity for interface
                                tensor<double,4> de(eNN,2,2,2);
                                int nDim = 3;
                                std::vector<double> t(nDim);
                                for (int n = 0; n < nDim; n++)
                                    t[n] = immMesh->_immTangents[iE][nDim*gpi+n];
                                double jac = Math::Norm3D(t.data());

                                // Compute unitary normal
                                ttl::tensor<double,1> nB(2);
                                nB(0) = t[1]/jac;
                                nB(1) = -t[0]/jac;
                                tensor<double,1> Dbf_gN = Dbf_g*nB;
                                for (int a{}; a< eNN; a++)
                                    for (int b{}; b< eNN; b++)
                                        Bku1(a,b) += 0.5*wS[gpi]*jac*Dbf_gN(a)*Dbf_gN(b);
                                LPatch += wS[gpi]*jac*0.5;
                            }

                            BkG += Mlg.T()*Bku1*Mlg;
                        }

                    }
                    
                    const int nM = igNds.size();

                    Ltot += LPatch;
                    // Build random SPD matrices for testing
                    Eigen::MatrixXd M1 = Eigen::MatrixXd::Zero(nM, nM);
                    Eigen::MatrixXd M2 = Eigen::MatrixXd::Zero(nM, nM);
                    tensor<double,2> AkgR(nM,nM);
                    AkgR *=0;
                    tensor<double,2> BkgR(nM,nM);
                    BkgR *=0;

                    for (int a = 0; a < igNds.size(); a++)
                    {
                        for (int b = 0; b < igNds.size(); b++)
                        {
                            // Fill M1
                            M1(a,b) = AkG(a,b);
                        
                            M2(a,b) = BkG(a,b);
                        }
                    }
                    
                    for (int a = 0; a < igNds.size(); a++)
                    {
                        for (int b = 0; b < igNds.size(); b++)
                        {
                            // Fill M1
                            AkgR(a,b) = AkG(a,b);

                            BkgR(a,b) = BkG(a,b);
                        }
                    }

                    // cout << AkgR << endl;
                    // cout << BkgR << endl;
                    Eigen::MatrixXd vecs;
                    Eigen::VectorXd vals;
                    if(true)
                    {
                        vals = solveGeneralizedEigen(M2, M1, vecs);
                    }
                    else
                    {
                        Eigen::GeneralizedEigenSolver<Eigen::MatrixXd> ges(M2, M1);

                        vals = ges.eigenvalues().real();
                        vecs = ges.eigenvectors().real();
                    }
                    std::cout << " Eigenvalues:\n" << vals.transpose() << "\n\n";

                    for (int iE : akp)
                    {
                        lE[rr][iE] = vals.array().isInf().select(0, vals).maxCoeff();
                        std::cout<< iE << " Eigenvalues:\n" << vals.transpose() << "\n\n";
                        cout <<  rr <<"; "<< iE <<": " <<lE[rr][iE] << endl;

                    }
                }
                // cout << "LTOT = " << Ltot << endl;
            }
            // Compute total lambda and weights
            
            for(int iE = 0; iE < backMesh->nElem(); iE++)
            {
                int eTag = backDHand->elemAuxF->getValue(0,iE);
                if (eTag%2 == 0) // If element in boundary
                {
                    double lmbd = lE[0][iE]*lE[1][iE]/(lE[0][iE]+lE[1][iE]);
                    double k0 = lE[1][iE]/(lE[0][iE]+lE[1][iE]);
                    
                    backDHand->elemAuxF->setValue("lE",iE,IndexType::Global,lmbd);
                    backDHand->elemAuxF->setValue("l0",iE,IndexType::Global,lE[0][iE]);
                    backDHand->elemAuxF->setValue("l1",iE,IndexType::Global,lE[1][iE]);
                    backDHand->elemAuxF->setValue("k0",iE,IndexType::Global,k0);
                }
            }

            //-------------------------- Immersed solver -------------------------//
            SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
            immSOL->setHiPerProblem(immHP);
            immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
            immSOL->setDefaultParameters();
            immSOL->Update();
            //---------------------------- Solve immersed ------------------------//
            // Solve
            // immHP->FillLinearSystem();
            immSOL->solve();
            immSOL->UpdateSolution();
            string meshName = to_string(nS);
            if(false) // Print matrix and rhs
            {
                string LHSName = "LHS." + meshName +".mm";
                string SolName = "Sol." + meshName +".mm";
                string RHSName = "RHS." + meshName +".mm";
                const char *CLHSName = LHSName.c_str();
                const char *CSolName = SolName.c_str();
                const char *CRHSName = RHSName.c_str();
                EpetraExt::RowMatrixToMatrixMarketFile(CLHSName, *immHP->A, "LHS", "Left hand side matrix");
                EpetraExt::MultiVectorToMatrixMarketFile(CSolName, *immHP->sol, "Sol", "Solution vector");
                EpetraExt::MultiVectorToMatrixMarketFile(CRHSName, *immHP->rhs, "RHS", "Right hand side vector");

                ofstream CoordsFile;
                CoordsFile.open ("Coords." + meshName +".csv");
                for (int d = 0; d < backMesh->loc_nPts(); d++)
                {
                    // Get node coordinates
                    std::vector<double> x = backMesh->nodeCoords(d, IndexType::Local);
                    CoordsFile << x[0] << "," << x[1] << endl;
                }
                for (int d = 0; d < immMesh->loc_nPts(); d++)
                {
                    // Get node coordinates
                    std::vector<double> x = immMesh->nodeCoords(d, IndexType::Local);
                    CoordsFile << x[0] << "," << x[1] << endl;
                }
                CoordsFile.close(); 
            }

            
            // Print
            string solName = "solBack."+to_string(nS);
            backDHand->printFileLegacyVtk(solName, true);
            string immMshName = "meshImm."+to_string(nS);
            immMesh->printFileLegacyVtk(immMshName);

            double L = immHP->globalIntegral("Length");
            double A = immHP->globalIntegral("Area");
            cout <<"Theta: " <<theta<< "Area: " << A << " Lenght: " << L << endl;

            SmartPtr<HiPerProblem> checkSolution = Create<HiPerProblem>();
            checkSolution->setDOFsHandlers({backDHand});

            // Set integration for the border
            checkSolution->setIntegration("IntegBorder", {"backDHand"});
            checkSolution->setCubatureBorderImmersed("IntegBorder", 5);
            checkSolution->setElementFillings("IntegBorder", CheckNitsche);

            // Set integration for the background mesh
            checkSolution->setIntegration("Integ0", {"backDHand"});
            checkSolution->setCubatureCutCellConforming("Integ0", 9, 4,"Interior");
            checkSolution->setElementFillings("Integ0", CheckSolution0);

            // Set integration for the background mesh
            checkSolution->setIntegration("Integ1", {"backDHand"});
            checkSolution->setCubatureCutCellConforming("Integ1", 9, 4,"Exterior");
            checkSolution->setElementFillings("Integ1", CheckSolution1);

            checkSolution->setGlobalIntegrals({"error","uErr","duErr"});
            checkSolution->Update();

            checkSolution->FillLinearSystem();
            double error = checkSolution->globalIntegral("error");
            std::cout << "error: " << error << std::endl;
            double Uerror = checkSolution->globalIntegral("uErr");
            std::cout << "U border error: " << sqrt(Uerror) << std::endl;
            double dUerror = checkSolution->globalIntegral("duErr");
            std::cout << "dU*n border error: " << sqrt(dUerror) << std::endl;
        }
    }

    hiperlife::Finalize();
    return 0;
}