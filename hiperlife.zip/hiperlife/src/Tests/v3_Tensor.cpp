
#include <iostream>
#include <mpi.h>

#include "hl_Tensor.h"


int main()
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;


    // Tensor<int,2> tensor1(1,2);

    int dim1 = 3;
    int dim2 = 3;
    
    tensor<double,2> mytensor(dim1,dim2);
    for(int i = 0; i < dim1; i++)
    {
        for ( int j = 0; j < dim2; j++ )
        {
            mytensor(i,j)=i+dim2*j/10.0;
        }
    }

    cout << mytensor << endl;

    cout << "My trace is = " << trace(mytensor) << endl;

    tensor<double,2> mytensor2(3,4);
    for ( int i = 0; i < 3; i++ )
        for (int j = 0; j < 4; j++ )
            mytensor2(i,j) = 2*i+j;
    tensor<double,3> mytensor3(3,3,4);
    mytensor3(0,all,all) = mytensor2;
    mytensor3(1,all,all) = 2*mytensor2;
    mytensor3(2,all,all) = 3*mytensor2;
    cout << "mytensor2 is : " << mytensor2 << endl;
    cout << "mytensor3 is : " << mytensor3 << endl;
    
    
    tensor<double,2> subtensor = mytensor3(all,range(0,1),2);
    cout << "my subtensor is: " << subtensor << endl;
    cout << "my subtensor transposed is: " << subtensor.T() << endl;
    
    tensor<double,3> sometensor(2,3,2);
    sometensor = {{{0.0,1.0},{2.0,3.0},{4.0,5.0}},{{6.0,7.0},{8.0,9.0},{10.0,11.0}}};
    cout << "sometensor_abc: " << sometensor << endl;
    cout << "sometensor_acb: " << sometensor.transpose({0,2,1}) << endl;
    cout << "sometensor_cba: " << sometensor.transpose({2,1,0}) << endl;
    cout << "sometensor_cba: " << sometensor.transpose() << endl;

    cout << "-sometensor_abc" << -sometensor << endl;
    
    tensor<double,3> sometensor2 = {{{0.0,1.0},{2.0,3.0},{4.0,5.0}},{{6.0,7.0},{8.0,9.0},{10.0,11.0}}};
    cout << "sometensor_abc: " << sometensor2 << endl;

    
    tensor<double,1> vec1(3);
    vec1 = {2.0,4.0,1.0};
    tensor<double,1> vec2(3);
    vec2 = {1.0,3.0,2.0};
    cout << vec1 << endl;
    cout << vec2 << endl;
    cout << outer(vec1,vec2) << endl;

//    tensor<int,2> sometensor(2,2);
//    sometensor = {0,1,2,3};
//    cout << "sometensor: " << sometensor << endl;
//    tensor<int,2> sometensort = sometensor.transpose({1,0},false);
//    cout << "sometensort: " << sometensort << endl;
//    sometensort(1,0) *= -1;
//    cout << "sometensor: " << sometensor << endl;
//    cout << "sometensort: " << sometensort << endl;

    tensor<double,1> myvec1(2);
    myvec1 = {1.0,2.0};
    
    tensor<double,1> myvec2(2);
    myvec2 = {1.0,2.0};
    
    cout << "myvec1=" << myvec1 << endl;
    cout << "myvec2=" << myvec2 << endl;
    cout << "prod12=" << myvec1*myvec2 << endl;



    auto transposed = mytensor.transpose({1,0});

    for(int i = 0; i < 2; i++)
    {
        for ( int j = 0; j < 2; j++ )
            cout << transposed(i,j) << " ";
        cout << endl;
    }

    cout << endl;


    tensor<double,3> thirdtensor(dim1,dim2,dim1);

    for(int i = 0; i < dim1; i++)
        for ( int j = 0; j < dim2; j++ )
            for ( int k = 0; k < dim1; k++ )
                thirdtensor(i,j,k) = i+2*j/10.0+3*k/20.0;

   cout << thirdtensor << endl;

    cout << "My trace is = " << trace(thirdtensor) << endl;


    auto contracted4 = product(thirdtensor, mytensor, {{2, 0}, {1, 1}} );
    cout << contracted4 << endl;


    for(int i = 0; i < dim1; i++)
    {
        contracted4(i) = 0.0;
        for ( int j = 0; j < dim2; j++ )
        {
            for ( int k = 0; k < dim2; k++ )
            {
            contracted4(i) += thirdtensor(i,j,k)* mytensor(k,j);
            }
        }
    }
    cout << contracted4 << endl;

    auto contracted5 = contract(thirdtensor, {{0, 2}} );



    cout << contracted5;
    cout << endl;


    auto sum = mytensor + mytensor;
    cout << "mytensor+mytensor=" <<sum << endl;

    auto sum2 = sum * 2.0;
    cout <<"2*sum=" << sum2 << endl;

//    auto matsum = mytensor + mytensor.T().T();
//    cout << matsum << endl;
//
//
//    auto matprod = mytensor * mytensor.T();
//    cout << matprod << endl;
//
//    auto fancy = mytensor - 3 * mytensor * mytensor;
//    cout << fancy << endl;
//
//
    tensor<int,2> fancy2(dim1,dim2);
    for(int i = 0; i < dim1; i++)
        for ( int j = 0; j < dim2; j++ )
                fancy2(i,j) = i+2*j;
    cout << fancy2 << endl;
//
//
    auto fancy3 = fancy2 * 1.1;
    cout << fancy3 << endl;

//    fancy2 *= 2.2;
//    cout << fancy2 << endl;
//
    fancy3 /= 2.2;
    cout << fancy3 << endl;
//
//    fancy3 += 3*fancy3;
//    cout << fancy3 << endl;
//
//    fancy2 -= fancy3;
//    cout << fancy2 << endl;
    
//    index<'a'> a;
//    index<'b'> b;
//    index<'c'> c;
    
//    auto ttt = mytensor(a,b) * mytensor(b,c);
    
}
