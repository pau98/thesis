
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>
#include <ostream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_Timer.h"
#include "hl_TypeDefs.h"
#include "hl_BasicMeshGenerator.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_Math.h"
#include "hl_OctreeElementLocator.h"
#include "hl_QuadtreeElementLocator.h"

#include "hl_HiPerProblem.h"
#include <hl_LinearSolver_Direct_MUMPS.h>
#include <tuple>
#include "hl_Geometry.h"
#include "hl_SurfLagrParam.h"
#include "hl_Tensor.h"
#include "hl_vtkElementLocator.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

using namespace std;

struct AllocationMetrics
{
        uint32_t TotalAllocated = 0;
        uint32_t TotalFreed = 0;
        uint32_t CurrentUsage()
            {
                return TotalAllocated-TotalFreed;
            }
};

static AllocationMetrics s_AllocationMetrics;

void* operator new(size_t size)
{
    s_AllocationMetrics.TotalAllocated += size;
    return malloc(size);
}

void operator delete(void* memory, size_t size)
{
    s_AllocationMetrics.TotalFreed += size;
    free(memory);
}

static void printMemoryUsage()
{
    cout << "Mem = " << s_AllocationMetrics.CurrentUsage()*1e-6 << endl;
}


int main()
{

    //*************************************************************************
    // [0] Initialize
    //*************************************************************************

    // Initialize MPI
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    if (myRank == 0)
        cout << endl;

    // Parameters
    bool searchVtk = true;
    bool searchSer = false;
    bool searchOct = false;
    bool searchQua = true;
    bool searchNew = false;
    bool searchOld = false;
    bool interpolate = true;
    bool print = true;
    bool check = true;
    bool octantMesh = false;
    bool quadMesh   = false;


    //*************************************************************************
    // [0] Create mesh
    //*************************************************************************


    // Create mesh
    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    mesh->genStructMesh(81);
    // mesh->transformFree([](double x, double y, double z){return make_tuple(x, y, x*x);});
    // mesh->transformFree([](double x, double y, double z){return make_tuple(x, y, x*y);});
    // mesh->translate(-0.5, -0.5, -0.5);
    // mesh->translateXY(-0.5, -0.5);
    // mesh->scale(2.0);
    // mesh->rotate2D(M_PI/4.0, {0.5,0.5,0.0});
    // mesh->rotateY(M_PI/6.0, {0.0,0.0,0.0});
    // mesh->degreeElevateNurbs(1);
    // mesh->scale(1.0);
    // // mesh->translate(-1.0,-1.0,0.0);
    // mesh->genRuledSurface(4, 4, {0,0,0}, {0,1,0.5}, {1,1,-0.2}, {-1,0,0.3});
    // mesh->genRuledSurface(42, 31, {0,0,0}, {0,1,0.5}, {1,1,-0.2}, {-1,0,0.3});
    // mesh->genTorusSurfacePatchSector(12*4*2, 12*2*4, 0.2, M_PI/2.0, 1.0, M_PI/2.0);
    // mesh->genTorusSurfacePatchSector(12, 12, 0.2, M_PI/2.0, 1.0, M_PI/2.0);
    // mesh->genLine(10, {0.0,1.0,0.0}, {1.0,0.0,0.0});
    // mesh->genCircularArc(1, 1.0, M_PI/2.0);
    // mesh->genDisk_Squared(1,1,1.0);
    // mesh->printMesh("a");

    // RCP<UnstructVtkMeshGenerator> mesh = rcp(new UnstructVtkMeshGenerator);
    // mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // mesh->genSphere([](double x[3]){return 0.01;});

    // RCP<MeshLoader> mesh = rcp(new MeshLoader);
    // mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // mesh->loadMesh("../meshes/horse.vtk", MeshType::Parallel);

    // Distribute the mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->setElementLocatorEngine(ElementLocatorEngine::None);
    disMesh->Update();
    disMesh->printFileLegacyVtk("mesh");
    disMesh->printFileVtk("mesh");

    // vector<int> elems;
    // vector<vector<double>> rCoords;
    // vector<vector<double>> xCoords(1, vector<double>(3, 0.0));
    // // vector<double> dists = disMesh->elementLocator()->searchElementInPartition(elems, rCoords, xCoords);
    // disMesh->elementLocator()->searchElement(elems, rCoords, xCoords);

    // Timer timer2({"a"});

    // int el = 1;
    // vector<double> rC(3, 0.0);
    // vector<double> rC0(3, 0.5);
    // vector<double> x = {0.1,0.1,0.0};
    // // disMesh->_invertElementMapping_LinearTriangle(rC, el, x, IndexType::Global);
    // timer2.start("a");
    // vector<vector<double>> bfDers;
    // for (int i = 0; i < 1000000*0+1; i++)
    //     disMesh->_basisFunctions->computeBasisFunctionsReference(rC0, 0);
    //     // disMesh->_invertElementMapping_LinearSquare(rC, el, x, rC0, IndexType::Global);
    // // vector<double> xp(3);
    // // xp = disMesh->interpolatePosition(el, rC);
    // timer2.end("a");

    // cout <<  timer2.printAccumTime("a") << endl;
    // // for (auto a: rC)
    // //     cout << a << " ";
    // // cout << endl;
    // // for (auto a: xp)
    // //     cout << a << " ";
    // // cout << endl;

    // // Finalize
    // MPI_Finalize();
    // return 0;


    // Create DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setDOFs({"u"});
    dhand->setElemAuxF({"octant", "octant2", "visited", "inverted"});
    dhand->Update();

    // disMesh->minus(3);


    //*************************************************************************
    // [3] Create points
    //*************************************************************************

    // Create mesh
    RCP<StructMeshGenerator> p_mesh = rcp(new StructMeshGenerator);
    p_mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    p_mesh->genStructMesh(512);//511*0+81*3+1);
    // p_mesh->translateXY(-0.5, -0.5);
    // p_mesh->translate(-0.5, -0.5, -0.5);
    // p_mesh->scale(3.0);
    // p_mesh->scale(1.2);
    // p_mesh->rotate2D(M_PI/4.0, {0.5,0.5,0.0});
    // p_mesh->translateXY(-1.3/2.0, (sqrt(2.0)-1.3)/2.0);
    // p_mesh->genRuledSurface(302, 401, {0,0,0}, {0,1,0.5}, {1,1,-0.2}, {-1,0,0.3});
    // p_mesh->genTorusSurfacePatchSector(12, 11, 0.2, M_PI/2.0, 1.0, M_PI/2.0);
    // p_mesh->genTorusSurfacePatchSector(32*4*2, 41*4*2, 0.2, M_PI/2.0, 1.0, M_PI/2.0);
    // p_mesh->genTorusSurfacePatchSector(7, 5, 0.2, M_PI/2.0, 1.0, M_PI/2.0);
    // p_mesh->genLine(32, {0.0,0.0,0.0}, {1.0,1.0,0.0});
    // p_mesh->genCircularArc(33, 1.0, M_PI/3.0);

    // RCP<UnstructVtkMeshGenerator> p_mesh = rcp(new UnstructVtkMeshGenerator);
    // p_mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // p_mesh->genSphere([](double x[3]){return 0.001;});

    // RCP<MeshLoader> p_mesh = rcp(new MeshLoader);
    // p_mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // p_mesh->loadMesh("../meshes/horse2.vtk", MeshType::Parallel);

    // Distribute the mesh
    RCP<DistributedMesh> p_disMesh = rcp(new DistributedMesh);
    p_disMesh->setMesh(p_mesh);
    p_disMesh->setBalanceMesh(true);
    p_disMesh->setElementLocatorEngine(ElementLocatorEngine::None);
    p_disMesh->Update();
    p_disMesh->printFileLegacyVtk("meshToInterpolate");

    int nPts = p_disMesh->nPts();
    vector<vector<double>> gCoords(nPts, vector<double>(3));
    for (int i = 0; i < nPts; i++)
    {
        // Get node coordinates in new mesh
        int p_new = p_disMesh->nodePartition(i);
        if (p_disMesh->isNodeInPart(i))
            gCoords[i] = p_disMesh->nodeCoords(i);
        MPI_Bcast(gCoords[i].data(), 3, MPI_DOUBLE, p_new, p_disMesh->comm());
    }

    // // Define point to find
    // // vector<double> pt = {0.0,0.0,0.05};
    // // vector<double> pt = {0.65,0.25,0.0};
    // // vector<double> pt = {0.65,0.1,1.1};
    // // vector<double> pt = {0.1,0.15,0.0};
    // // vector<double> pt = {0.1,0.1,0.0};
    // vector<double> pt = {-0.149706457751, -0.368884540059, 0.0};

    // // Duplicate point
    // int nPts = 1;
    // vector<vector<double>> gCoords(nPts, vector<double>(3));
    // for (int i = 0; i < nPts; i++)
    // {
    //     for (int d = 0; d < 3; d++)
    //         gCoords[i][d] = pt[d];
    // }

    // int keep = 81;
    // gCoords.erase(gCoords.begin()+keep+1,gCoords.end());
    // gCoords.erase(gCoords.begin(),gCoords.begin()+keep);
    // nPts = gCoords.size();

    // Output points
    if (myRank == 0)
    {
        cout << endl << "Searching for " << nPts << " points within a " << disMesh->nElem() << " element mesh" << endl;
        cout << endl << "Printing points" << endl;
        ofstream myfile;
        myfile.open("point.csv", std::ofstream::out | std::ofstream::trunc);
        for (int i = 0; i < nPts; i++)
            myfile << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
        myfile.close();
    }


    // int el = 3661;
    // vector<double> rC(3, 0.0);
    // vector<double> rC0(3, 0.0);
    // disMesh->_invertElementMapping_LinearTriangle(rC, el, gCoords[0], rC0, IndexType::Global);

    // dhand->interpolateField2(dhand->nodeDOFs, 0, gCoords);
    // vector<vector<double>> x = disMesh->closestPointProjection(gCoords);

    // int el = 0;
    // vector<double> rC(3, 0.0);
    // vector<double> rC0(3, 0);
    // vector<double> x = gCoords[0];
    // // disMesh->_invertElementMapping_LinearTriangle(rC, el, x, IndexType::Global);
    // // disMesh->_invertElementMapping_LinearSquare(rC, el, x, rC0, IndexType::Global, true);
    // disMesh->_invertElementMapping2(rC, el, x, rC0, IndexType::Global, true);
    // // disMesh->_invertElementMapping(rC, el, x, rC0, IndexType::Global);
    // vector<double> xp(3);
    // xp = disMesh->interpolatePosition(el, rC);

    // cout << "rC = ";
    // for (auto a: rC)
    //     cout << a << " ";
    // cout << endl;
    // cout << "xp = ";
    // for (auto a: xp)
    //     cout << a << " ";
    // cout << endl;
    // cout << "x  = ";
    // for (auto a: x)
    //     cout << a << " ";
    // cout << endl;

    // // ofstream myfile;
    // // myfile.open("test.csv", std::ofstream::out | std::ofstream::trunc);
    // // int el = 7;
    // // for (double rc0 = -1.0; rc0 <= 1.0; rc0 +=0.01)
    // // {
    // //     for (double rc1 = -1.0; rc1 <= 1.0; rc1 +=0.01)
    // //     {
    // //         vector<double> rC = {rc0,rc1};
    // //         vector<double> xp(3);
    // //         xp = disMesh->interpolatePosition(el, rC);
    // //         double dist = Math::Dist3D(xp.data(), gCoords[0].data());
    // //         myfile << std::setprecision(16) << xp[0] << " " << xp[1] << " " << xp[2] << " " << dist << endl;
    // //     }
    // // }
    // // myfile.close();

    // // Finalize
    // dhand->printFileVtk("dhand", true);
    // dhand->printFileLegacyVtk("dhand", true);
    // MPI_Finalize();
    // return 0;


    //*************************************************************************
    // [4] Find
    //*************************************************************************

    Timer t_build({"build_vtk", "build_oct", "build_qua"});
    Timer t({"vtk", "ser", "oct", "qua", "new", "old"});

    // Find points vtk
    vector<vector<double>> cPP_vtk(nPts, vector<double>(3));
    if (searchVtk)
    {
        if (myRank == 0)
            cout << endl << "Finding points vtk" << endl;

        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        t_build.start("build_vtk");
        RCP<vtkElementLocator> elLoc = rcp(new vtkElementLocator);
        // elLoc->setDistributedMesh(disMesh.getRawPtr());
        elLoc->setDistributedMesh(&*disMesh);
        // elLoc->_dhand = dhand;
        elLoc->Update();
        t_build.end("build_vtk");

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find
        t.start("vtk");
        if (myRank == 0)
            cout << " Searching" << endl;
        elLoc->searchElement(elems, rCoords, gCoords);
        // auto vtkLoc = elLoc->_myCellLocator;
        // auto vtkCell = elLoc->_myGenericCell;
        // auto vtkMesh = elLoc->mesh;
        // for (int n = 0; n < nPts; n++)
        // {
        //     for (int e = 0; e < disMesh->loc_nElem(); e++)
        //     {
        //         vtkMesh->GetCell(e, vtkCell);
        //         int subId{};
        //         double point[3]{};
        //         double dist2;
        //         double weights[disMesh->nVert()];
        //         vtkCell->EvaluatePosition(gCoords[n].data(), point, subId, rCoords[n].data(), dist2, weights);
        //     }
        // }
        t.end("vtk");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_vtk[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_vtk[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_vtk.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << endl;
            myfile.close();
        }
    }

    // Find points serial vtk
    vector<vector<double>> cPP_ser(nPts, vector<double>(3));
    if (searchSer)
    {
        if (myRank == 0)
            cout << endl << "Finding points serial vtk" << endl;

        // Gather mesh information form the mesh
        if (myRank == 0)
            cout << " Gathering mesh info" << endl;
        vector<int> glob_connec;
        vector<double> glob_x_nodes;
        disMesh->_allGatherMesh(glob_connec, glob_x_nodes);

        RCP<BasicMeshGenerator> basicMesh = rcp(new BasicMeshGenerator());
        basicMesh->setMesh(disMesh->elemType(), disMesh->_adjcyEN->basisFuncType(), disMesh->_bfOrder);
        basicMesh->setMeshType(MeshType::Sequential);
        basicMesh->_glob_creases.resize(disMesh->_nCrease*glob_x_nodes.size()/disMesh->nDim());
        basicMesh->_glob_eflags.resize(glob_connec.size()/disMesh->nDim());
        basicMesh->setNElem(glob_connec.size()/disMesh->nDim());
        basicMesh->setNPts(glob_x_nodes.size()/disMesh->nDim());
        basicMesh->setGlobCoords(glob_x_nodes);
        basicMesh->setGlobCreases(basicMesh->_glob_creases);
        basicMesh->setGlobConnec(glob_connec);

        RCP<DistributedMesh> disMeshSerial = rcp(new DistributedMesh("DistributedMesh", MPI_COMM_SELF));
        disMeshSerial->setMesh(basicMesh);
        disMeshSerial->setBalanceMesh(false);
        disMeshSerial->setElementLocatorEngine(ElementLocatorEngine::None);
        disMeshSerial->Update();

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find
        t.start("ser");
        if (myRank == 0)
            cout << " Searching" << endl;
        // for (int i = 0; i < nPts; i++)
        //     disMeshSerial->searchElementVTK(elems[i], rCoords[i], gCoords[i], glob_connec, glob_x_nodes);
        t.end("ser");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_ser[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_ser[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_ser.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_ser[i][0] << " " << cPP_ser[i][1] << " " << cPP_ser[i][2] << endl;
            myfile.close();
        }
    }

    // Find points octree
    vector<vector<double>> cPP_oct(nPts, vector<double>(3));
    if (searchOct)
    {
        if (myRank == 0)
            cout << endl << "Finding points octree" << endl;

        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        t_build.start("build_oct");
        RCP<OctreeElementLocator> elLoc = rcp(new OctreeElementLocator);
        elLoc->setDistributedMesh(disMesh.getRawPtr());
        // elLoc->setNumberOfTreeSubdivisionLevels(0);
        // elLoc->setNumberOfElementsPerOctant(1);
        // elLoc->_dhand = dhand;
        elLoc->Update();
        t_build.end("build_oct");

        // Create octant DOFsHandler
        RCP<DOFsHandler> octdhand;
        if (octantMesh)
        {
            // Get data
            int nLevels = elLoc->numberOfTreeSubdivisionLevels();
            vector<double> maxMesh = elLoc->meshMaximum();
            vector<double> minMesh = elLoc->meshMinimum();
            vector<double> scale(3);
            for (int i = 0; i < 3; i++)
                scale[i] = maxMesh[i]- minMesh[i];
            vector<double> trans(3);
            for (int i = 0; i < 3; i++)
                trans[i] = minMesh[i];

            // Create octant mesh
            RCP<StructMeshGenerator> octmesh = rcp(new StructMeshGenerator);
            octmesh->setMesh(ElemType::Parallelep, BasisFuncType::Lagrangian, 1);
            octmesh->genStructMesh(pow(2,nLevels));
            octmesh->scale(scale[0],scale[1],scale[2]);
            octmesh->translate(trans[0],trans[1],trans[2]);

            // Distribute the mesh
            RCP<DistributedMesh> octdisMesh = rcp(new DistributedMesh);
            octdisMesh->setMesh(octmesh);
            octdisMesh->setBalanceMesh(false);
            octdisMesh->setElementLocatorEngine(ElementLocatorEngine::None);
            octdisMesh->Update();

            octdhand = rcp(new DOFsHandler(octdisMesh));
            octdhand->setDOFs({"u"});
            octdhand->setElemAuxF({"octant", "loop", "visited"});
            octdhand->Update();
            // elLoc->_octdhand = octdhand;

            for (int e = 0; e < octdisMesh->loc_nElem(); e++)
                octdhand->elemAuxF->setValue(0, e, IndexType::Local, e);
        }

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find points
        t.start("oct");
        if (myRank == 0)
            cout << " Searching" << endl;
        elLoc->searchElement(elems, rCoords, gCoords);
        // for (int n = 0; n < nPts; n++)
        // {
        //     for (int e = 0; e < disMesh->loc_nElem(); e++)
        //     {
        //         vector<double> rCoords0 = {0.0, 0.0, 0.0};
        //         disMesh->invertElementMapping(rCoords[n], e, gCoords[n], rCoords0, IndexType::Local);
        //     }
        // }
        t.end("oct");

        // for (int i = 0; i < nPts; i++)
        // {
        //     cout << i << " : " << elems[i] << endl;
        // }

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                // cout << i << " : " << elems[i] << endl;
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_oct[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_oct[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (octantMesh)
        {
            octdhand->printFileLegacyVtk("octdhand", true);
            octdhand->printFileVtk("octdhand", true);
        }
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_oct.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << endl;
            myfile.close();
        }

        // Check
        if (myRank == 0 and interpolate and check)
        {
            cout << " Checking" << endl;
            ofstream myfile, myfile2, myfile3;
            if (false)
            {
                myfile.open("not_found_vtk.csv", std::ofstream::out | std::ofstream::trunc);
                myfile2.open("not_found_oct.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                        dist2 += (cPP_oct[i][d]-cPP_vtk[i][d])*(cPP_oct[i][d]-cPP_vtk[i][d]);
                    if (dist2 > 1e-8)
                    {
                        // Compute dists
                        double dist_vtk{}, dist_oct{};
                        for (int d = 0; d < 3; d++)
                        {
                            dist_vtk += (gCoords[i][d]-cPP_vtk[i][d])*(gCoords[i][d]-cPP_vtk[i][d]);
                            dist_oct += (gCoords[i][d]-cPP_oct[i][d])*(gCoords[i][d]-cPP_oct[i][d]);
                        }
                        dist_vtk = sqrt(dist_vtk);
                        dist_oct = sqrt(dist_oct);

                        // Output
                        if (dist_vtk < dist_oct)
                        {
                            cout << std::setprecision(12) << "Octree failed: " << i << ": "
                                 << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << " <-> "
                                 << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << " | "
                                 << dist_vtk << " " << dist_oct << endl;
                            myfile << std::setprecision(16) << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << endl;
                            myfile2 << std::setprecision(16) << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << endl;
                            myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                        }
                    }
                }
                myfile.close();
                myfile2.close();
                myfile3.close();
            }
            else
            {
                myfile2.open("not_found_oct.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                    {
                        dist2 += (gCoords[i][d]-cPP_oct[i][d])*(gCoords[i][d]-cPP_oct[i][d]);
                    }
                    dist2 = sqrt(dist2);
                    if (dist2 > 1e-2)
                    {
                        // Output
                        // if (dist_vtk < dist_oct)
                        {
                            cout << std::setprecision(12) << "Octree failed: " << i << " " << elems[i] << ": "
                                 << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << " <-> "
                                 << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << " | "
                                 << dist2 << endl;
                            myfile2 << std::setprecision(16) << cPP_oct[i][0] << " " << cPP_oct[i][1] << " " << cPP_oct[i][2] << endl;
                            myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                        }
                    }
                }
                myfile2.close();
                myfile3.close();
            }
        }
    }

    // Find points quadtree
    vector<vector<double>> cPP_qua(nPts, vector<double>(3));
    if (searchQua)
    {
        if (myRank == 0)
            cout << endl << "Finding points quadree" << endl;

        // Create element locator
        if (myRank == 0)
            cout << " Creating locator" << endl;
        t_build.start("build_qua");
        RCP<QuadtreeElementLocator> elLoc = rcp(new QuadtreeElementLocator);
        elLoc->setDistributedMesh(disMesh.getRawPtr());
        // elLoc->setNumberOfTreeSubdivisionLevels(0);
        // elLoc->setNumberOfElementsPerOctant(1);
        // elLoc->_dhand = dhand;
        elLoc->Update();
        t_build.end("build_qua");

        // Create quad DOFsHandler
        RCP<DOFsHandler> quaddhand;
        if (quadMesh)
        {
            // Get data
            int nLevels = elLoc->numberOfTreeSubdivisionLevels();
            vector<double> maxMesh = elLoc->meshMaximum();
            vector<double> minMesh = elLoc->meshMinimum();
            vector<double> scale(2);
            for (int i = 0; i < 2; i++)
                scale[i] = maxMesh[i]- minMesh[i];
            vector<double> trans(2);
            for (int i = 0; i < 2; i++)
                trans[i] = minMesh[i];

            // Create quad mesh
            RCP<StructMeshGenerator> quadmesh = rcp(new StructMeshGenerator);
            quadmesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
            quadmesh->genStructMesh(pow(2,nLevels));
            // quadmesh->scaleXY(scale[0],scale[1]);
            // quadmesh->translateXY(trans[0],trans[1]);

            // Distribute the mesh
            RCP<DistributedMesh> quaddisMesh = rcp(new DistributedMesh);
            quaddisMesh->setMesh(quadmesh);
            quaddisMesh->setBalanceMesh(false);
            quaddisMesh->setElementLocatorEngine(ElementLocatorEngine::None);
            quaddisMesh->Update();

            quaddhand = rcp(new DOFsHandler(quaddisMesh));
            quaddhand->setDOFs({"u"});
            quaddhand->setElemAuxF({"quad", "loop", "visited"});
            quaddhand->Update();
            // elLoc->_quaddhand = quaddhand;

            for (int e = 0; e < quaddisMesh->loc_nElem(); e++)
                quaddhand->elemAuxF->setValue(0, e, IndexType::Local, e);
        }

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find points
        t.start("qua");
        if (myRank == 0)
            cout << " Searching" << endl;
        elLoc->searchElement(elems, rCoords, gCoords);
        // for (int n = 0; n < nPts; n++)
        // {
        //     for (int e = 0; e < disMesh->loc_nElem(); e++)
        //     {
        //         vector<double> rCoords0 = {0.0, 0.0, 0.0};
        //         disMesh->invertElementMapping(rCoords[n], e, gCoords[n], rCoords0, IndexType::Local);
        //     }
        // }
        t.end("qua");

        // for (int i = 0; i < nPts; i++)
        // {
        //     cout << i << " : " << elems[i] << endl;
        // }

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                // cout << i << " : " << elems[i] << endl;
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_qua[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_qua[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (quadMesh)
        {
            quaddhand->printFileLegacyVtk("quaddhand", true);
            quaddhand->printFileVtk("quaddhand", true);
        }
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_qua.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << endl;
            myfile.close();
        }

        // Check
        if (myRank == 0 and interpolate and check)
        {
            cout << " Checking" << endl;
            ofstream myfile, myfile2, myfile3;
            if (false)
            {
                myfile.open("not_found_vtk.csv", std::ofstream::out | std::ofstream::trunc);
                myfile2.open("not_found_qua.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                        dist2 += (cPP_qua[i][d]-cPP_vtk[i][d])*(cPP_qua[i][d]-cPP_vtk[i][d]);
                    if (dist2 > 1e-8)
                    {
                        // Compute dists
                        double dist_vtk{}, dist_qua{};
                        for (int d = 0; d < 3; d++)
                        {
                            dist_vtk += (gCoords[i][d]-cPP_vtk[i][d])*(gCoords[i][d]-cPP_vtk[i][d]);
                            dist_qua += (gCoords[i][d]-cPP_qua[i][d])*(gCoords[i][d]-cPP_qua[i][d]);
                        }
                        dist_vtk = sqrt(dist_vtk);
                        dist_qua = sqrt(dist_qua);

                        // Output
                        // if (dist_vtk < dist_qua)
                        {
                            cout << std::setprecision(12) << "Quadree failed: " << i << ": "
                                 << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << " <-> "
                                 << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << " | "
                                 << dist_vtk << " " << dist_qua << endl;
                            myfile << std::setprecision(16) << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << endl;
                            myfile2 << std::setprecision(16) << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << endl;
                            myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                        }
                    }
                }
                myfile.close();
                myfile2.close();
                myfile3.close();
            }
            else
            {
                myfile2.open("not_found_qua.csv", std::ofstream::out | std::ofstream::trunc);
                myfile3.open("not_found_pnt.csv", std::ofstream::out | std::ofstream::trunc);
                for (int i = 0; i < nPts; i++)
                {
                    double dist2{};
                    for (int d = 0; d < 3; d++)
                    {
                        dist2 += (gCoords[i][d]-cPP_qua[i][d])*(gCoords[i][d]-cPP_qua[i][d]);
                    }
                    dist2 = sqrt(dist2);
                    if (dist2 > 1e-2)
                    {
                        // Output
                        // if (dist_vtk < dist_qua)
                        {
                            cout << std::setprecision(12) << "Quadree failed: " << i << " " << elems[i] << ": "
                                 << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << " <-> "
                                 << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << " | "
                                 << dist2 << endl;
                            myfile2 << std::setprecision(16) << cPP_qua[i][0] << " " << cPP_qua[i][1] << " " << cPP_qua[i][2] << endl;
                            myfile3 << std::setprecision(16) << gCoords[i][0] << " " << gCoords[i][1] << " " << gCoords[i][2] << endl;
                        }
                    }
                }
                myfile2.close();
                myfile3.close();
            }
        }
    }

    // Find points new
    vector<vector<double>> cPP_new(nPts, vector<double>(3));
    if (searchNew)
    {
        if (myRank == 0)
            cout << endl << "Finding points new" << endl;

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find
        t.start("new");
        if (myRank == 0)
            cout << " Searching" << endl;
        // disMesh->searchElement_new(elems, rCoords, gCoords);
        t.end("new");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_new[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_new[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_new.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_new[i][0] << " " << cPP_new[i][1] << " " << cPP_new[i][2] << endl;
            myfile.close();
        }


        // Check
        if (myRank == 0 and interpolate and check)
        {
            if (myRank == 0)
                cout << " Checking" << endl;
            for (int i = 0; i < nPts; i++)
            {
                double dist2{};
                for (int d = 0; d < 3; d++)
                {
                    dist2 += (cPP_new[i][d]-cPP_vtk[i][d])*(cPP_new[i][d]-cPP_vtk[i][d]);
                }
                if (dist2 > 1e-8)
                {
                    cout << std::setprecision(12) << "New failed: " << i << ": "
                         << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << " <-> "
                         << cPP_new[i][0] << " " << cPP_new[i][1] << " " << cPP_new[i][2] << endl;
                }
            }
        }

    }

    // Find points old
    vector<vector<double>> cPP_old(nPts, vector<double>(3));
    if (searchOld)
    {
        if (myRank == 0)
            cout << endl << "Finding points old" << endl;

        // Initialize
        vector<int> elems(nPts);
        vector<vector<double>> rCoords(nPts, vector<double>(disMesh->pDim()));

        // Find
        t.start("old");
        if (myRank == 0)
            cout << " Searching" << endl;
        for (int i = 0; i < nPts; i ++)
            disMesh->searchElement(elems[i], rCoords[i], gCoords[i]);
        t.end("old");

        // Interpolate position
        if (interpolate)
        {
            if (myRank == 0)
                cout << " Interpolating" << endl;
            for (int i = 0; i < nPts; i++)
            {
                int p = disMesh->elemPartition(elems[i]);
                if (disMesh->isElemInPart(elems[i]))
                    cPP_old[i] = disMesh->interpolatePosition(elems[i], rCoords[i]);
                MPI_Bcast(cPP_old[i].data(), 3, MPI_DOUBLE, p, disMesh->comm());
            }
        }

        // Print points
        if (myRank == 0 and interpolate and print)
        {
            cout << " Printing" << endl;
            ofstream myfile;
            myfile.open("found_old.csv", std::ofstream::out | std::ofstream::trunc);
            for (int i = 0; i < nPts; i++)
                myfile << std::setprecision(16) << cPP_old[i][0] << " " << cPP_old[i][1] << " " << cPP_old[i][2] << endl;
            myfile.close();
        }


        // Check
        if (myRank == 0 and interpolate and check)
        {
            cout << " Checking" << endl;
            for (int i = 0; i < nPts; i++)
            {
                double dist2{};
                for (int d = 0; d < 3; d++)
                {
                    dist2 += (cPP_old[i][d]-cPP_vtk[i][d])*(cPP_old[i][d]-cPP_vtk[i][d]);
                }
                if (dist2 > 1e-8)
                {
                    cout << std::setprecision(12) << "Old failed: " << i << ": "
                         << cPP_vtk[i][0] << " " << cPP_vtk[i][1] << " " << cPP_vtk[i][2] << " <-> "
                         << cPP_old[i][0] << " " << cPP_old[i][1] << " " << cPP_old[i][2] << endl;
                }
            }
        }
    }

    // // Finalize
    // MPI_Finalize();
    // return 0;


    //*************************************************************************
    // [5] Print
    //*************************************************************************

    // Print times
    t.printTiming(true);
    double t_vtk = t.printAccumTime("vtk");
    MPI_Allreduce(&t_vtk, &t_vtk, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_ser = t.printAccumTime("ser");
    MPI_Allreduce(&t_ser, &t_ser, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_oct = t.printAccumTime("oct");
    MPI_Allreduce(&t_oct, &t_oct, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_qua = t.printAccumTime("qua");
    MPI_Allreduce(&t_qua, &t_qua, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_new = t.printAccumTime("new");
    MPI_Allreduce(&t_new, &t_new, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_old = t.printAccumTime("old");
    MPI_Allreduce(&t_old, &t_old, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_build_vtk = t_build.printAccumTime("build_vtk");
    MPI_Allreduce(&t_build_vtk, &t_build_vtk, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_build_oct = t_build.printAccumTime("build_oct");
    MPI_Allreduce(&t_build_oct, &t_build_oct, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    double t_build_qua = t_build.printAccumTime("build_qua");
    MPI_Allreduce(&t_build_qua, &t_build_qua, 1,  MPI_DOUBLE, MPI_MAX, disMesh->comm());
    if (myRank == 0)
    {
        cout << endl << "Max times" << endl;
        cout << "VTK:       " << t_vtk << endl;
        cout << "ser:       " << t_ser << endl;
        cout << "oct:       " << t_oct << endl;
        cout << "qua:       " << t_qua << endl;
        cout << "new:       " << t_new << endl;
        cout << "old:       " << t_old << endl;
        // cout << endl << t_vtk << " " << t_ser << " " << t_oct << " " << t_qua << " " << t_new << " " << t_old << endl;
        cout << endl << t_vtk << " " << t_qua << " " << t_oct << " " << t_new << " " << t_ser << " " << t_old << endl;
        cout << endl << endl << "Max build times" << endl;
        cout << "VTK:       " << t_build_vtk << endl;
        cout << "oct:       " << t_build_oct << endl;
        cout << "qua:       " << t_build_qua << endl;
    }

    // Print
    dhand->printFileVtk("dhand", true);
    dhand->printFileLegacyVtk("dhand", true);

    // Finalize
    MPI_Finalize();
    return 0;
}


// 1, log(8)
// Max times
// VTK:       3.1502e+00
// ser:       0.0000e+00
// oct:       5.2905e-01
// qua:       3.5157e-01
// new:       0.0000e+00
// old:       0.0000e+00

// 4, log(8)
// Max times
// VTK:       3.8200e+00
// ser:       0.0000e+00
// oct:       2.1583e+00
// qua:       1.7841e+00
// new:       0.0000e+00
// old:       0.0000e+00

// 1, log(4)
// Max times
// VTK:       3.1817e+00
// ser:       0.0000e+00
// oct:       5.3013e-01
// qua:       4.0729e-01
// new:       0.0000e+00
// old:       0.0000e+00

// 4, log(4)
// Max times
// VTK:       3.8431e+00
// ser:       0.0000e+00
// oct:       2.1531e+00
// qua:       3.3905e+00
// new:       0.0000e+00
// old:       0.0000e+00


// New times. (some points outside)
// 1 Old quad
// VTK:       4.5441e+00
// oct:       9.0171e-01
// qua:       8.4344e-01

// 4 Old quad
// VTK:       2.4721e+00
// oct:       1.8074e+00
// qua:       1.1758e+00

// 1 New quad
// VTK:       4.5246e+00
// oct:       8.9929e-01
// qua:       8.4737e-01

// 4 New quad
// VTK:       2.4813e+00
// oct:       1.7986e+00
// qua:       6.1921e-01

// New times. (all points inside)
// 1 Old quad
// VTK:       2.4147e+00
// oct:       3.4612e-01
// qua:       3.2802e-01

// 4 Old quad
// VTK:       2.2739e+00
// oct:       1.4915e+00
// qua:       8.1070e-01

// 1 New quad
// VTK:       2.4413e+00
// oct:       3.4187e-01
// qua:       3.4132e-01

// 4 New quad
// VTK:       2.2591e+00
// oct:       1.4817e+00
// qua:       3.1289e-01
