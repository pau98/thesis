#include <iostream> // input/output stream objects
#include <chrono>   // timing

#include <Teuchos_RCP.hpp>          // Trilinos header that defines RCP objects
#include <mpi.h>                    // C++ header that defines MPI objects
#include <EpetraExt_RowMatrixOut.h> // Exporting stiffness matrix

#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_ConstitutiveModels_Elasticity.h"
#include "hl_ConstitutiveModels_Piezoelectricity.h"
#include "hl_ConstitutiveModels_Flexoelectricity.h"
#include "hl_MultiPatchMeshGenerator.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_StructMeshGenerator.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using namespace std;
using Teuchos::rcp;
using Teuchos::RCP;
using namespace hiperlife;

enum class syntheticSolutionType
{
    polynomial,
    sinusoidal1,
    sinusoidal2
};

void computeL2Error(int);
void domain(Teuchos::RCP<hiperlife::FillStructure>);
void borderDirichletDirichlet(Teuchos::RCP<hiperlife::FillStructure>);
void borderDirichletNeumann(Teuchos::RCP<hiperlife::FillStructure>);
std::vector<double> syntheticSolution(double, double, syntheticSolutionType);
std::vector<double> DSyntheticSolution(double, double, syntheticSolutionType);
void syntheticVolumeLoad(std::vector<double>&, double&, syntheticSolutionType,
    double, double, double, double, double, double, double,
    double, double, double, double, double, double);
std::vector<double> doubleTraction(double, double, double, double, double, double,
    double, double, syntheticSolutionType);

int main()
{
    // Get starting timepoint
    auto start = std::chrono::high_resolution_clock::now();

    MPI_Init(nullptr, nullptr);

    int myRank{};
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    for (int i = 2; i < 7; ++i)
    {
        computeL2Error(pow(2, i));
    }

    MPI_Finalize();

    // Get ending timepoint
    auto stop = std::chrono::high_resolution_clock::now();

    // Get duration. Substart timepoints to
    // get duration. To cast it to proper unit
    // use duration cast method
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(stop - start);

    cout << "Time taken by function: "
        << duration.count() << " seconds" << endl;
    return 0;
}

void computeL2Error(int elemPerDir)
{
    /*---------------------------------------------------------------------
        Mesh parameters
    -----------------------------------------------------------------------*/
    BasisFuncType BFType{ BasisFuncType::BSplines };
    ElemType EType{ ElemType::Square };
    int BFOrder{ 3 };
    double domainLength{ 0.5 };
    // int elemPerDir{16};
    int numImmElem{ 600 };
    // Choose synthetic solution
    // 0: polynomial
    // 1: sinusodial1 (Jordi's thesis)
    // 2: sinusodial2 (David's thesis)
    int synSolType{ 1 };
    int nGaussPts{ (int)pow(ceil((double)(2 * BFOrder + 1) / 2.), 2) };
    int nGaussPtsBorder{ (int)ceil((double)(2 * BFOrder + 1) / 2.) + 1 };

    /*---------------------------------------------------------------------
        Material parameters in SI units
    -----------------------------------------------------------------------*/
    // double Young = 152.e9;
    // double nu = 0.33;
    // double lMech = 1.0e-9;
    // double kappaL = 141.e-9;
    // double piezoL = 8.8, piezoT = -4.4, piezoS = 4.4;
    // double flexoL = 150.e-6, flexoT = 110.e-6, flexoS = 110.e-6;

    // Material properties for debuging
    double Young = 152.e9;
    double nu = 0.33;
    double lMech = 0.;
    double kappaL = 141.e-9;
    double piezoL = 0., piezoT = 0., piezoS = 0.;
    double flexoL = 0., flexoT = 0., flexoS = 0.;

    /*---------------------------------------------------------------------
        Nitsche's parameter
    -----------------------------------------------------------------------*/
    // Normalization Scales
    double lengthScale{ 1.e-6 };     // length scale for normalization
    double stressScale{ 1.e+9 };     // stress scale for normalization
    double polarizationScale{ 1.0 }; // polarization scale for normalization

    double zeta = 100;
    double flexoLength = std::max(fabs(flexoL), std::max(fabs(flexoT), fabs(flexoS))) / sqrt(kappaL * Young);
    double hypermechLength = sqrt(lMech * lMech + flexoLength * flexoLength);
    double mechWeight = zeta * Young / stressScale;
    double hypermechWeight = zeta * Young / stressScale * hypermechLength * hypermechLength / lengthScale / lengthScale;
    double electricWeight = zeta * kappaL * stressScale / polarizationScale / polarizationScale;
    double h = 1. / static_cast<double>(elemPerDir);

    std::vector<double> beta(4);
    beta[0] = mechWeight / h;          // beta u
    beta[1] = hypermechWeight / h;     // beta v
    beta[2] = electricWeight / h;      // beta phi
    beta[3] = hypermechWeight / h / h; // beta C u

    // beta[0] = 1.e7; // beta u
    // beta[1] = 1.e7; // beta v
    // beta[2] = 1.e7; // beta phi
    // beta[3] = 1.e7; // beta C u

    /*---------------------------------------------------------------------
        Normalizing the material properties
    -----------------------------------------------------------------------*/
    Young /= stressScale;
    lMech /= lengthScale;
    kappaL /= (polarizationScale * polarizationScale / stressScale);
    piezoL /= polarizationScale;
    piezoT /= polarizationScale;
    piezoS /= polarizationScale;
    flexoL /= (lengthScale * polarizationScale);
    flexoT /= (lengthScale * polarizationScale);
    flexoS /= (lengthScale * polarizationScale);

    /*---------------------------------------------------------------------
        Linear elasticity parameters for 2D plane strain problem
    -----------------------------------------------------------------------*/
    double CL = Young * (1. - nu) / (1. + nu) / (1. - 2. * nu);
    double CT = Young * nu / (1. + nu) / (1. - 2. * nu);
    double CS = Young / 2. / (1. + nu);

    /*---------------------------------------------------------------------
        Saving parameters in user structure
    -----------------------------------------------------------------------*/
    RCP<UserStructure> userStr = rcp(new UserStructure);

    userStr->i_aux.resize(1);
    userStr->i_aux[0] = synSolType;

    userStr->dparam.resize(14);
    userStr->dparam[0] = Young;
    userStr->dparam[1] = nu;
    userStr->dparam[2] = lMech;
    userStr->dparam[4] = kappaL;
    userStr->dparam[5] = piezoL;
    userStr->dparam[6] = piezoT;
    userStr->dparam[7] = piezoS;
    userStr->dparam[8] = flexoL;
    userStr->dparam[9] = flexoT;
    userStr->dparam[10] = flexoS;
    userStr->dparam[11] = CL;
    userStr->dparam[12] = CT;
    userStr->dparam[13] = CS;

    std::vector<double> C;  // Linear elasticity tensor
    std::vector<double> H;  // Linear gradient elasticity tensor
    std::vector<double> K;  // Linear isotropic dielectric tensor
    std::vector<double> E;  // Linear piezoelectric tensor
    std::vector<double> Mu; // Linear Flexoelectric tensor

    ConstitutiveModels::LinearElasticity::elasticityTensor(C, CL, CT, CS, 2);
    ConstitutiveModels::LinearElasticity::gradElasticityTensor(H, CL, CT, CS, lMech, 2);
    ConstitutiveModels::Piezoelectricity::dielectricTensor(K, kappaL, 2);
    ConstitutiveModels::Piezoelectricity::piezoelectricTensor(E, piezoL, piezoT, piezoS, 2);
    ConstitutiveModels::Flexoelectricity::flexoelectricityTensor(Mu, flexoL, flexoT, flexoS, 2);

    userStr->a_aux = C;
    userStr->b_aux = H;
    userStr->c_aux = K;
    userStr->u_aux = E;
    userStr->v_aux = Mu;

    userStr->z_aux.resize(4);
    userStr->z_aux[0] = beta[0];
    userStr->z_aux[1] = beta[1];
    userStr->z_aux[2] = beta[2];
    userStr->z_aux[3] = beta[3];

    /*---------------------------------------------------------------------
        Dummy mesh for parametric space representation
    -----------------------------------------------------------------------*/
    RCP<StructMeshGenerator> dummyMesh = rcp(new StructMeshGenerator);
    dummyMesh->setMesh(EType, BFType, 1);
    dummyMesh->genSquare(elemPerDir, 1.0);

    RCP<DistributedMesh> disDummyMesh = rcp(new DistributedMesh);
    disDummyMesh->setMesh(dummyMesh);
    disDummyMesh->setBalanceMesh(true);
    disDummyMesh->Update();
    disDummyMesh->printFileLegacyVtk("paramSp");

    /*---------------------------------------------------------------------
        Back mesh
    -----------------------------------------------------------------------*/
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(EType, BFType, BFOrder);
    structMesh->genSquare(elemPerDir, 1.0);

    RCP<DistributedMesh> disBackMesh = rcp(new DistributedMesh);
    disBackMesh->setMesh(structMesh);
    disBackMesh->setBalanceMesh(true);
    disBackMesh->Update();
    disBackMesh->printFileLegacyVtk("rawBackMesh");

    /*---------------------------------------------------------------------
        Immersed geometry (mesh)
    -----------------------------------------------------------------------*/
    RCP<StructMeshGenerator> immersedMesh = rcp(new StructMeshGenerator);
    immersedMesh->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);

    // Circle
    immersedMesh->genCircle(numImmElem, domainLength / 2.-0.001);
    immersedMesh->translate(0.5, 0.5, 0.0);

    // Square
    // immersedMesh->genSquareLine(numImmElem, domainLength);
    // immersedMesh->rotate2D(M_PI * 20 / 180);
    // immersedMesh->translate(0.35, 0.2, 0.0);

    RCP<DistributedMesh> disImmMesh = rcp(new DistributedMesh);
    disImmMesh->setMesh(immersedMesh);
    disImmMesh->setImmersedInteriorPoints({ {0.5, 0.5, 0.} });
    disImmMesh->setMeshRelation(MeshRelation::Immersed, disBackMesh);
    disImmMesh->setBalanceMesh(true);
    disImmMesh->Update();
    disImmMesh->printFileLegacyVtk("meshImm");

    /*---------------------------------------------------------------------
        DOF handler
    -----------------------------------------------------------------------*/
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disBackMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setDOFs({ "u", "v", "phi" });
    dofHand->Update();

    dofHand->UpdateGhosts();
    dofHand->printFileLegacyVtk("dofHand", true);

    /*---------------------------------------------------------------------
        HiperProblem
    -----------------------------------------------------------------------*/
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({ dofHand });

    // Set integral in the bulk
    hiperProbl->setIntegration("Integ", { "dofHand" });
    hiperProbl->setCubatureCutCellNonConforming("Integ", nGaussPts, nGaussPts, 10);
    hiperProbl->setElementFillings("Integ", domain);

    // Set integral in the border
    hiperProbl->setIntegration("BorderInteg", { "dofHand" });
    hiperProbl->setCubatureBorderImmersed("BorderInteg", 9);
    hiperProbl->setElementFillings("BorderInteg", borderDirichletDirichlet);

    // FIXME: Integration on BoB is missing.

    // L2 Errors as global integrals
    hiperProbl->setGlobalIntegrals({ "L2Err_Ux_D", "L2Err_Uy_D", "L2Err_Phi_D",
                                     "L2Err_Ux_B", "L2Err_Uy_B", "L2Err_Phi_B",
                                     "L2Err_Ux", "L2Err_Uy", "L2Err_Phi",
                                     "ImmArea", "ImmLength" });

    hiperProbl->Update();

    /*---------------------------------------------------------------------
        Clear the file for writing integration points
    -----------------------------------------------------------------------*/
    ofstream myfile;
    myfile.open("cubature_" + to_string(hiperProbl->myRank()) + ".csv", std::ofstream::out | std::ofstream::trunc);
    myfile.close();

    /*---------------------------------------------------------------------
        Solver
    -----------------------------------------------------------------------*/
    /// Iterative solver
    // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setDefaultParameters();
    // solver->setTolerance(1.E-16);
    // solver->setMaxNumIterations(2000);
    // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    // solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver->Update();

    /// Direct solver
    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setDefaultParameters();
    solver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General); // General or Symmetric
    solver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->Update();
    solver->solve();

    hiperProbl->UpdateSolution();         // Update node values
    dofHand->printFileLegacyVtk("Flexo"); // Print as VTK
    solver->Update();
    hiperProbl->FillLinearSystem();

    /*---------------------------------------------------------------------
        Outputs
    -----------------------------------------------------------------------*/
    if (hiperProbl->myRank() == 0)
    {
        std::vector<double> errors(9);
        errors[0] = sqrt(hiperProbl->globalIntegral("L2Err_Ux"));
        errors[1] = sqrt(hiperProbl->globalIntegral("L2Err_Uy"));
        errors[2] = sqrt(hiperProbl->globalIntegral("L2Err_Phi"));
        errors[3] = sqrt(hiperProbl->globalIntegral("L2Err_Ux_D"));
        errors[4] = sqrt(hiperProbl->globalIntegral("L2Err_Uy_D"));
        errors[5] = sqrt(hiperProbl->globalIntegral("L2Err_Phi_D"));
        errors[6] = sqrt(hiperProbl->globalIntegral("L2Err_Ux_B"));
        errors[7] = sqrt(hiperProbl->globalIntegral("L2Err_Uy_B"));
        errors[8] = sqrt(hiperProbl->globalIntegral("L2Err_Phi_B"));

        std::cout << std::setprecision(6);
        std::cout << "Area of immersed geometry: "
            << hiperProbl->globalIntegral("ImmArea") << std::endl;
        std::cout << "Length of immersed geometry: "
            << hiperProbl->globalIntegral("ImmLength") << std::endl;

        std::cout << "Nitsche's parameters: \n"
            << "beta_u \t " << beta[0]
            << "\nbeta_v \t " << beta[1]
            << "\nbeta_p \t " << beta[2]
            << "\nbeta_c \t " << beta[3] << std::endl;

        std::cout << "-> L2 Errors: " << std::endl;
        std::cout << "\t-> Ux  : " << errors[0] << std::endl;
        std::cout << "\t-> Uy  : " << errors[1] << std::endl;
        std::cout << "\t-> Phi : " << errors[2] << std::endl;

        std::ofstream writeOut("L2Errors.csv", std::ios::app);
        assert(writeOut.is_open());
        writeOut.precision(12);
        writeOut << elemPerDir << "\t" << log10(h) << "\t"
            << hiperProbl->globalIntegral("ImmArea") << "\t"
            << hiperProbl->globalIntegral("ImmLength") << "\t"
            << log10(errors[0]) << "\t"
            << log10(errors[1]) << "\t"
            << log10(errors[2]) << "\t"
            << log10(errors[3]) << "\t"
            << log10(errors[4]) << "\t"
            << log10(errors[5]) << "\t"
            << log10(errors[6]) << "\t"
            << log10(errors[7]) << "\t"
            << log10(errors[8]) << endl;
    }

    // Export stiffness matrix
    // string matName = "A.mm";
    // EpetraExt::RowMatrixToMatrixMarketFile(matName.c_str(), *hiperProbl->A, "LHS", "Left hand side matrix");
}

void domain(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    /*----------------------------------------------------------------------------
            Initialize variables
    ------------------------------------------------------------------------------*/
    SubFillStructure& subFill = (*fillStr)[0];
    int eNN = subFill.eNN;         // Number of neighbor nodes (Number of nodes)
    int nDim = subFill.nDim;       // Number of spatial dimensions (2->x,y / 3->x,y,z)
    int pDim = subFill.pDim;       // Number of parametric dimension
    int numDOFs = subFill.numDOFs; // Number of degrees of freedom per node

    tensor<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);  // Coordinates for each node
    tensor<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);   // DOF values at the nodes
    tensor<double, 1> bf(subFill.nborBasisFunctionsDerivatives(0), eNN); // Basis functions

    // Global derivatives (wrt x and y ) of the basis functions
    tensor<double, 2> GlobDBF(eNN, pDim);       // Gradient
    tensor<double, 3> GlobHBF(eNN, pDim, pDim); // Hessian
    tensor<double, 1> GlobLBF(eNN);             // Laplacian
    double jac{};
    GlobalBasisFunctions::hessians(GlobDBF, jac, GlobHBF, GlobLBF, subFill);

    // Global coordinates (x,y,z) of integration point
    tensor<double, 1> coords = product(nborCoords, bf, { {0, 0} });

    /*----------------------------------------------------------------------------
        Material Tensors
    ------------------------------------------------------------------------------*/
    tensor<double, 4> C(fillStr->userStr->a_aux.data(), pDim, pDim, pDim, pDim);
    tensor<double, 6> H(fillStr->userStr->b_aux.data(), pDim, pDim, pDim, pDim, pDim, pDim);
    tensor<double, 2> K(fillStr->userStr->c_aux.data(), pDim, pDim);
    tensor<double, 3> E(fillStr->userStr->u_aux.data(), pDim, pDim, pDim);
    tensor<double, 4> Mu(fillStr->userStr->v_aux.data(), pDim, pDim, pDim, pDim);

    /*----------------------------------------------------------------------------
        Differential operators
    ------------------------------------------------------------------------------*/
    tensor<double, 4> Strain(pDim, pDim, pDim, eNN);
    tensor<double, 5> gradStrain(pDim, pDim, pDim, pDim, eNN);
    tensor<double, 2> EField(pDim, eNN);

    ConstitutiveModels::LinearElasticity::strain(Strain, GlobDBF, pDim);
    ConstitutiveModels::LinearElasticity::gradStrain(gradStrain, GlobHBF, pDim);
    ConstitutiveModels::Piezoelectricity::electricFieldTensor(EField, GlobDBF, pDim);

    /*----------------------------------------------------------------------------
        Synthetic Solution
    ------------------------------------------------------------------------------*/
    syntheticSolutionType type;
    if (fillStr->userStr->i_aux[0] == 0)
        type = syntheticSolutionType::polynomial;
    else if (fillStr->userStr->i_aux[0] == 1)
        type = syntheticSolutionType::sinusoidal1;
    else if (fillStr->userStr->i_aux[0] == 2)
        type = syntheticSolutionType::sinusoidal2;

    std::vector<double> syntheticSol = syntheticSolution(coords(0), coords(1), type);

    double l_mech = fillStr->userStr->dparam[2];
    double kappaL = fillStr->userStr->dparam[4];
    double e_L = fillStr->userStr->dparam[5];
    double e_T = fillStr->userStr->dparam[6];
    double e_S = fillStr->userStr->dparam[7];
    double mu_L = fillStr->userStr->dparam[8];
    double mu_T = fillStr->userStr->dparam[9];
    double mu_S = fillStr->userStr->dparam[10];
    double CL = fillStr->userStr->dparam[11];
    double CT = fillStr->userStr->dparam[12];
    double CS = fillStr->userStr->dparam[13];

    std::vector<double> B(2); // volumetric loads in x and y directions
    double Q{};          // volumetric electric charge
    syntheticVolumeLoad(B, Q, type,
        l_mech, kappaL, e_L, e_T, e_S,
        mu_L, mu_T, mu_S, CL, CT, CS, coords(0), coords(1));

    /*----------------------------------------------------------------------------
        Integration in Domain
    ------------------------------------------------------------------------------*/
    // Allocate space:
    tensor<double, 2> Bk(fillStr->Bk(0).data(), eNN, numDOFs);
    tensor<double, 4> Ak(fillStr->Ak(0, 0).data(), eNN, numDOFs, eNN, numDOFs);

    // 1. Cauchy Stress : Strain(u)_ijQR · C_ijkl · Strain(u)_klST
    tensor<double, 4> CauchyStress = product(Strain, product(C, Strain, { {2, 0}, {3, 1} }), { {0, 0}, {1, 1} });
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            Ak(all, i, all, j) += CauchyStress(i, all, j, all) * jac;

    // 2. Hyper Stress : gradStrain(u)_ijkQR · H_ijkLMN · gradStrain(u)_LMNST
    tensor<double, 4> HyperStress = product(gradStrain, product(H, gradStrain, { {3, 0}, {4, 1}, {5, 2} }), { {0, 0}, {1, 1}, {2, 2} });
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            Ak(all, i, all, j) += HyperStress(i, all, j, all) * jac;

    // 3. Electrostatic Energy Density: - EField_lS K_lm EField_mQ
    tensor<double, 2> Electrostatic = -product(EField, product(K, EField, { {1, 0} }), { {0, 0} });
    Ak(all, numDOFs - 1, all, numDOFs - 1) += Electrostatic * jac;

    // 5c. Piezoelectric Effect: - EField_lQ E_lij SymmGrad(u)_ijRS
    tensor<double, 3> Piezoelectric = -product(EField, product(E, Strain, { {1, 0}, {2, 1} }), { {0, 0} });
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, numDOFs - 1, all, i) += Piezoelectric(all, i, all) * jac;
        Ak(all, i, all, numDOFs - 1) += Piezoelectric(all, i, all).transpose({ 1, 0 }) * jac;
    }

    // 6c. Flexoelectric Effect: - EField_lQ Mu_lijk gradStrain(u)_ijkRS
    tensor<double, 3> Flexoelectric = -product(EField, product(Mu, gradStrain, { {1, 0}, {2, 1}, {3, 2} }), { {0, 0} });
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, numDOFs - 1, all, i) += Flexoelectric(all, i, all) * jac;
        Ak(all, i, all, numDOFs - 1) += Flexoelectric(all, i, all).transpose({ 1, 0 }) * jac;
    }

    // Loads and charge
    for (int i = 0; i < eNN; ++i)
    {
        Bk(i, 0) += B[0] * bf(i) * jac; // Load in x
        Bk(i, 1) += B[1] * bf(i) * jac; // Load in y
        Bk(i, 2) -= Q * bf(i) * jac;    // Charge
    }

    /*----------------------------------------------------------------------------
        Calculate Error
    ------------------------------------------------------------------------------*/
    double err_Ux{};
    double err_Uy{};
    double err_Phi{};

    tensor<double, 1> sol = product(nborDOFs, bf, { {0, 0} }); // numerical solution

    err_Ux += jac * (sol(0) - syntheticSol[0]) * (sol(0) - syntheticSol[0]);
    err_Uy += jac * (sol(1) - syntheticSol[1]) * (sol(1) - syntheticSol[1]);
    err_Phi += jac * (sol(2) - syntheticSol[2]) * (sol(2) - syntheticSol[2]);
    fillStr->addToGlobalIntegral("L2Err_Ux", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi", err_Phi);
    fillStr->addToGlobalIntegral("L2Err_Ux_D", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy_D", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi_D", err_Phi);
    fillStr->addToGlobalIntegral("ImmArea", jac);

    /*----------------------------------------------------------------------------
        Writing integration points
    ------------------------------------------------------------------------------*/
    ofstream myfile;
    myfile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    myfile << std::setprecision(16)
        << coords(0) << " "
        << coords(1) << " "
        << 0 << " "
        << 0 << " "
        << 0 << " " << 0 << " " << 0 << endl;
    myfile.close();
}

void borderDirichletDirichlet(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    /*----------------------------------------------------------------------------
        Initialize variables
    ------------------------------------------------------------------------------*/
    SubFillStructure& subFill = (*fillStr)[0];
    int eNN = subFill.eNN;         // Number of neighbor nodess
    int nDim = subFill.nDim;       // Number of spatial dimensions
    int pDim = subFill.pDim;       // Number of parametric dimension
    int numDOFs = subFill.numDOFs; // Number of degrees of freedom per node

    tensor<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);                 // Coordinates for each node
    tensor<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);                  // DOFS -> ux = (:,0), uy = (:,1), phi = (:,2)
    tensor<double, 1> bf(subFill.nborBasisFunctionsDerivatives(0), eNN);                // Basis functions
    tensor<double, 2> Dbf_l(subFill.nborBasisFunctionsDerivatives(1), eNN, pDim);       // Local derivatives of the bf
    tensor<double, 3> Hbf_l(subFill.nborBasisFunctionsDerivatives(2), eNN, pDim, pDim); // Local Hessian of the bf

    // Global derivatives (wrt x and y ) of the basis functions
    tensor<double, 2> GlobDBF(eNN, pDim);             // Gradient
    tensor<double, 3> GlobHBF(eNN, pDim, pDim);       // Hessian
    tensor<double, 4> GlobTBF(eNN, pDim, pDim, pDim); // Third Derivatives
    tensor<double, 1> Lbf_g(eNN);                     // Laplacian
    double jac{};                                     // jacobian of back mesh and must be recomputed
    GlobalBasisFunctions::thirdGlobalDerivs(GlobDBF, jac, GlobHBF, Lbf_g, GlobTBF, subFill);

    // Global coordinates (x,y,z)
    tensor<double, 1> coords = product(nborCoords, bf, { {0, 0} });

    /*----------------------------------------------------------------------------
        Normal vectors
    ------------------------------------------------------------------------------*/
    double normal[3]{};
    tensor<double, 1> NDbf_g(eNN); // Normal derivative
    double Nu[3]{}, Nv[3]{};       // Derivatives of the normal vector (using Weingarten Eqs)

    double Ip[2 * 2], xu[3], xv[3];            // First Fundamental form and metric mappings
    double IIp[2 * 2], xuu[3], xvv[3], xuv[3]; // Second Fundamental form and metric mappings
    SurfLagrParam::Curvatures(IIp, Ip, normal, xu, xv, xuu, xvv, xuv, eNN, nborCoords.data(), Dbf_l.data(), Hbf_l.data());

    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    std::vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim * subFill.kPt + n];
    double dl = Math::Norm3D(t.data());

    // Normal vector
    normal[0] = t[1] / dl;
    normal[1] = -t[0] / dl;
    normal[2] = 0.0;

    NDbf_g(all) = normal[0] * GlobDBF(all, 0) + normal[1] * GlobDBF(all, 1);

    double detIp = Math::DetMat2x2(Ip);
    Math::AXPY(Nu, nDim, (IIp[1] * Ip[1] - IIp[0] * Ip[3]) / detIp, xu);
    Math::AXPY(Nu, nDim, (IIp[0] * Ip[1] - IIp[1] * Ip[0]) / detIp, xv);
    Math::AXPY(Nv, nDim, (IIp[3] * Ip[1] - IIp[1] * Ip[3]) / detIp, xu);
    Math::AXPY(Nv, nDim, (IIp[1] * Ip[1] - IIp[3] * Ip[0]) / detIp, xv);

    /*----------------------------------------------------------------------------
        Surface tensors
    ------------------------------------------------------------------------------*/
    tensor<double, 2> PMat(pDim, pDim);
    PMat(all, all) = 0.0; // PMat_ij = delta_ij - n_i n_j
    for (int i = 0; i < pDim; ++i)
    {
        PMat(i, i) += 1.0;
        for (int j = 0; j < pDim; ++j)
            PMat(i, j) -= normal[i] * normal[j];
    }

    tensor<double, 2> SMat(pDim, pDim);
    SMat(all, all) = 0.0; // SMat_ij = -N_i,l * P_lj
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            SMat(i, j) = -Nu[i] * PMat(0, j) - Nv[i] * PMat(1, j);

    double STrace = 0.0;
    for (int i = 0; i < pDim; ++i)
        STrace += 0.5 * SMat(i, i); // Mean Curvature

    tensor<double, 2> NMat(pDim, pDim);
    NMat(all, all) = 0.0; // NMat_ij = S_ij - 2.0 * H * n_i * n_j
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            NMat(i, j) = SMat(i, j) - 2.0 * STrace * normal[i] * normal[j];

    /*----------------------------------------------------------------------------
        Material tensors
    ------------------------------------------------------------------------------*/
    tensor<double, 4> C(fillStr->userStr->a_aux.data(), pDim, pDim, pDim, pDim);
    tensor<double, 6> H(fillStr->userStr->b_aux.data(), pDim, pDim, pDim, pDim, pDim, pDim);
    tensor<double, 2> K(fillStr->userStr->c_aux.data(), pDim, pDim);
    tensor<double, 3> E(fillStr->userStr->u_aux.data(), pDim, pDim, pDim);
    tensor<double, 4> Mu(fillStr->userStr->v_aux.data(), pDim, pDim, pDim, pDim);

    /*----------------------------------------------------------------------------
       Differential operators
   ------------------------------------------------------------------------------*/
    tensor<double, 4> Strain(pDim, pDim, pDim, eNN);
    tensor<double, 5> GradStrain(pDim, pDim, pDim, pDim, eNN);
    tensor<double, 6> HessStrain(pDim, pDim, pDim, pDim, pDim, eNN);
    tensor<double, 2> EField(pDim, eNN);
    tensor<double, 3> GradEField(pDim, pDim, eNN);

    ConstitutiveModels::LinearElasticity::strain(Strain, GlobDBF, pDim);
    ConstitutiveModels::LinearElasticity::gradStrain(GradStrain, GlobHBF, pDim);
    ConstitutiveModels::LinearElasticity::hessStrain(HessStrain, GlobTBF, pDim);
    ConstitutiveModels::Piezoelectricity::electricFieldTensor(EField, GlobDBF, pDim);
    ConstitutiveModels::Piezoelectricity::gradElectricField(GradEField, GlobHBF, pDim);

    /*----------------------------------------------------------------------------
        Constitutive relations
    ------------------------------------------------------------------------------*/
    tensor<double, 4> SigHat(pDim, pDim, numDOFs, eNN);
    tensor<double, 5> SigTilde(pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 6> GradSigTilde(pDim, pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 3> DHat(pDim, numDOFs, eNN);
    tensor<double, 4> DTilde(pDim, pDim, numDOFs, eNN);
    tensor<double, 5> GradDTilde(pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 3> Ti(pDim, numDOFs, eNN);
    tensor<double, 3> ri(pDim, numDOFs, eNN);
    tensor<double, 2> W(numDOFs, eNN);

    ConstitutiveModels::Flexoelectricity::Direct::stress(SigHat, C, Strain, E, EField, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::doubleStress(SigTilde, H, GradStrain, EField, Mu, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::gradDoubleStress(GradSigTilde, H, HessStrain, Mu, GradEField, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::electricDisplacement(DHat, EField, Strain, GradStrain, Mu, K, E, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::traction(Ti, SigHat, SigTilde, GradSigTilde, PMat, NMat, normal, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::doubleTraction(ri, SigTilde, normal, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::surfaceChargeDensity(W, DHat, PMat, NMat, normal, pDim);

    /*----------------------------------------------------------------------------
        Retrive Nitsche's parameters
    ------------------------------------------------------------------------------*/
    double betaU = fillStr->userStr->z_aux[0];
    double betaV = fillStr->userStr->z_aux[1];
    double betaPhi = fillStr->userStr->z_aux[2];

    /*----------------------------------------------------------------------------
       Synthetic solution
    ------------------------------------------------------------------------------*/
    syntheticSolutionType type;
    if (fillStr->userStr->i_aux[0] == 0)
        type = syntheticSolutionType::polynomial;
    else if (fillStr->userStr->i_aux[0] == 1)
        type = syntheticSolutionType::sinusoidal1;
    else if (fillStr->userStr->i_aux[0] == 2)
        type = syntheticSolutionType::sinusoidal2;
    /* u   : sol[0]
       v   : sol[1]
       phi : sol[2] */
    std::vector<double> syntheticSol = syntheticSolution(coords(0), coords(1), type);
    /* Derivative of synthetic solution
       u,X   : Dsol[0]     u,Y   : Dsol[1]
       v,X   : Dsol[2]     v,Y   : Dsol[3]
       phi,X : Dsol[4]     phi,Y : Dsol[5] */
    std::vector<double> dSyntheticSol = DSyntheticSolution(coords(0), coords(1), type);

    // Normal Derivative
    double dnU[3];
    dnU[0] = normal[0] * dSyntheticSol[0] + normal[1] * dSyntheticSol[1]; // Normal derivative of u: DU = nx Ux + ny Uy
    dnU[1] = normal[0] * dSyntheticSol[2] + normal[1] * dSyntheticSol[3]; // Normal derivative of v: Dv = nx Vx + ny Vy
    dnU[2] = normal[0] * dSyntheticSol[4] + normal[1] * dSyntheticSol[5]; // Normal derivative of phi: Dphi = nx Vx + ny Vy

    /*----------------------------------------------------------------------------
        Integration on boundaries
    ------------------------------------------------------------------------------*/
    // Allocate space:
    tensor<double, 4> Ak(fillStr->Ak(0, 0).data(), eNN, numDOFs, eNN, numDOFs);
    tensor<double, 2> Bk(fillStr->Bk(0).data(), eNN, numDOFs);

    // Integration on \partial Omega_u
    // int ( u_i betaU du_i - u_i dt_i - uB_i betaU du_i + uB_i dt_i - t_i du_i )
    //       ~~~~~~~~~~~~~~   ~~~~~~~~   ~~~~~~~~~~~~~~~   ~~~~~~~~~   ~~~~~~~~
    //            LHS           LHS            RHS            RHS         LHS
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, i, all, i) += betaU * outer(bf, bf) * dl; // u_i betaU du_i
        Bk(all, i) += syntheticSol[i] * betaU * bf * dl;  // Goes to RHS: - uB_i betaU du_i
        for (int j = 0; j < numDOFs; ++j)
        {
            Ak(all, i, all, j) -= outer(bf, Ti(i, j, all)) * dl; // - u_i dt_i
            Ak(all, j, all, i) -= outer(Ti(i, j, all), bf) * dl; // - t_i du_i
            Bk(all, j) -= syntheticSol[i] * Ti(i, j, all) * dl;  // Goes to RHS: uB_i dt_i
        }
    }

    // Integration on \partial Omega_v
    // int ( Du_i betaV Ddu_i - Du_i dr_i - vB_i betaV Ddu_i + vB_i dr_i - r_i Ddu_i )
    //       ~~~~~~~~~~~~~~~~   ~~~~~~~~~   ~~~~~~~~~~~~~~~~   ~~~~~~~~~   ~~~~~~~~~
    //              LHS            LHS             RHS            RHS         LHS
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, i, all, i) += betaV * outer(NDbf_g, NDbf_g) * dl; // Du_i betaV Ddu_i
        Bk(all, i) += dnU[i] * betaV * NDbf_g * dl;               // Goes to RHS: - vB_i betaV Ddu_i
        for (int j = 0; j < numDOFs; ++j)
        {
            Ak(all, i, all, j) -= outer(NDbf_g, ri(i, j, all)) * dl; // - r_i Ddu_i
            Ak(all, j, all, i) -= outer(ri(i, j, all), NDbf_g) * dl; // - Du_i dr_i
            Bk(all, j) -= dnU[i] * ri(i, j, all) * dl;               // Goes to RHS: vB_i dr_i
        }
    }

    // Integration on \partial Omega_phi
    // int ( -phi betaPhi dphi + phi dw + phiB betaPhi dphi - phiB dw + w dphi )
    //       ~~~~~~~~~~~~~~~~~   ~~~~~~   ~~~~~~~~~~~~~~~~~   ~~~~~~~   ~~~~~~
    //              LHS           LHS            RHS            RHS       LHS
    Ak(all, numDOFs - 1, all, numDOFs - 1) -= outer(bf, betaPhi * bf) * dl; // -phi betaPhi dphi
    Bk(all, numDOFs - 1) -= betaPhi * syntheticSol[2] * bf * dl;            // Goes to RHS: phiB betaPhi dphi
    for (int i = 0; i < numDOFs; ++i)
    {
        Ak(all, numDOFs - 1, all, i) += outer(bf, W(i, all)) * dl; // w dphi
        Ak(all, i, all, numDOFs - 1) += outer(W(i, all), bf) * dl; // phi dw
        Bk(all, i) += syntheticSol[2] * W(i, all) * dl;            // Goes to RHS: -phiB dw
    }

    /*----------------------------------------------------------------------------
        Calculate Error
    ------------------------------------------------------------------------------*/
    double err_Ux = 0.0;
    double err_Uy = 0.0;
    double err_Phi = 0.0;

    // L2 Error calculation
    tensor<double, 1> sol = product(nborDOFs, bf, { {0, 0} });

    err_Ux += dl * (sol(0) - syntheticSol[0]) * (sol(0) - syntheticSol[0]);
    err_Uy += dl * (sol(1) - syntheticSol[1]) * (sol(1) - syntheticSol[1]);
    err_Phi += dl * (sol(2) - syntheticSol[2]) * (sol(2) - syntheticSol[2]);
    fillStr->addToGlobalIntegral("L2Err_Ux", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi", err_Phi);
    fillStr->addToGlobalIntegral("L2Err_Ux_B", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy_B", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi_B", err_Phi);
    fillStr->addToGlobalIntegral("ImmLength", dl);

    /*----------------------------------------------------------------------------
        Writing Integration points
    ------------------------------------------------------------------------------*/
    ofstream myfile;
    myfile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    if (pDim == 2)
    {
        myfile << std::setprecision(16)
            << coords(0) << " " << coords(1) << " " << 0 << " "
            << 1 << " " << normal[0] << " " << normal[1] << " " << 0 << endl;
        myfile.close();
    }
}

void borderDirichletNeumann(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    /*----------------------------------------------------------------------------
        Initialize variables
    ------------------------------------------------------------------------------*/
    SubFillStructure& subFill = (*fillStr)[0];
    int eNN = subFill.eNN;         // Number of neighbor nodess
    int nDim = subFill.nDim;       // Number of spatial dimensions
    int pDim = subFill.pDim;       // Number of parametric dimension
    int numDOFs = subFill.numDOFs; // Number of degrees of freedom per node

    tensor<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);                 // Coordinates for each node
    tensor<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);                  // DOFS -> ux = (:,0), uy = (:,1), phi = (:,2)
    tensor<double, 1> bf(subFill.nborBasisFunctionsDerivatives(0), eNN);                // Basis functions
    tensor<double, 2> Dbf_l(subFill.nborBasisFunctionsDerivatives(1), eNN, pDim);       // Local derivatives of the bf
    tensor<double, 3> Hbf_l(subFill.nborBasisFunctionsDerivatives(2), eNN, pDim, pDim); // Local Hessian of the bf

    // Global derivatives (wrt x and y ) of the basis functions
    tensor<double, 2> GlobDBF(eNN, pDim);             // Gradient
    tensor<double, 3> GlobHBF(eNN, pDim, pDim);       // Hessian
    tensor<double, 4> GlobTBF(eNN, pDim, pDim, pDim); // Third Derivatives
    tensor<double, 1> Lbf_g(eNN);                     // Laplacian
    double jac{};
    GlobalBasisFunctions::thirdGlobalDerivs(GlobDBF, jac, GlobHBF, Lbf_g, GlobTBF, subFill);

    // Global coordinates (x,y,z)
    tensor<double, 1> coords = product(nborCoords, bf, { {0, 0} });

    /*----------------------------------------------------------------------------
        Normal vectors
    ------------------------------------------------------------------------------*/
    /*----------------------------------------------------------------------------
       Normal vectors
   ------------------------------------------------------------------------------*/
    double normal[3]{};
    tensor<double, 1> NDbf_g(eNN); // Normal derivative
    double Nu[3], Nv[3];           // Derivatives of the normal vector (using Weingarten Eqs)

    double Ip[2 * 2], xu[3], xv[3];            // First Fundamental form and metric mappings
    double IIp[2 * 2], xuu[3], xvv[3], xuv[3]; // Second Fundamental form and metric mappings
    SurfLagrParam::Curvatures(IIp, Ip, normal, xu, xv, xuu, xvv, xuv, eNN, nborCoords.data(), Dbf_l.data(), Hbf_l.data());

    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    std::vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim * subFill.kPt + n];
    double dl = Math::Norm3D(t.data());

    // Normal vector
    normal[0] = -t[1] / dl;
    normal[1] = t[0] / dl;
    normal[2] = 0.0;

    NDbf_g(all) = normal[0] * GlobDBF(all, 0) + normal[1] * GlobDBF(all, 1);

    double detIp = Math::DetMat2x2(Ip);
    Math::AXPY(Nu, nDim, (IIp[1] * Ip[1] - IIp[0] * Ip[3]) / detIp, xu);
    Math::AXPY(Nu, nDim, (IIp[0] * Ip[1] - IIp[1] * Ip[0]) / detIp, xv);
    Math::AXPY(Nv, nDim, (IIp[3] * Ip[1] - IIp[1] * Ip[3]) / detIp, xu);
    Math::AXPY(Nv, nDim, (IIp[1] * Ip[1] - IIp[3] * Ip[0]) / detIp, xv);

    tensor<double, 2> PMat(pDim, pDim);
    PMat(all, all) = 0.0; // PMat_ij = delta_ij - n_i n_j
    for (int i = 0; i < pDim; ++i)
    {
        PMat(i, i) += 1.0;
        for (int j = 0; j < pDim; ++j)
            PMat(i, j) -= normal[i] * normal[j];
    }

    tensor<double, 2> SMat(pDim, pDim);
    SMat(all, all) = 0.0; // SMat_ij = -N_i,l * P_lj
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            SMat(i, j) = -Nu[i] * PMat(0, j) - Nv[i] * PMat(1, j);

    double STrace = 0.0;
    for (int i = 0; i < pDim; ++i)
        STrace += 0.5 * SMat(i, i); // Mean Curvature

    tensor<double, 2> NMat(pDim, pDim);
    NMat(all, all) = 0.0; // NMat_ij = S_ij - 2.0 * H * n_i * n_j
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            NMat(i, j) = SMat(i, j) - 2.0 * STrace * normal[i] * normal[j];

    /*----------------------------------------------------------------------------
        Material tensors
    ------------------------------------------------------------------------------*/
    tensor<double, 4> C(fillStr->userStr->a_aux.data(), pDim, pDim, pDim, pDim);
    tensor<double, 6> H(fillStr->userStr->b_aux.data(), pDim, pDim, pDim, pDim, pDim, pDim);
    tensor<double, 2> K(fillStr->userStr->c_aux.data(), pDim, pDim);
    tensor<double, 3> E(fillStr->userStr->u_aux.data(), pDim, pDim, pDim);
    tensor<double, 4> Mu(fillStr->userStr->v_aux.data(), pDim, pDim, pDim, pDim);
    tensor<double, 4> M(fillStr->userStr->w_aux.data(), pDim, pDim, pDim, pDim);

    /*----------------------------------------------------------------------------
        Differential operators
    ------------------------------------------------------------------------------*/
    tensor<double, 4> Strain(pDim, pDim, pDim, eNN);
    tensor<double, 5> GradStrain(pDim, pDim, pDim, pDim, eNN);
    tensor<double, 6> HessStrain(pDim, pDim, pDim, pDim, pDim, eNN);
    tensor<double, 2> EField(pDim, eNN);
    tensor<double, 3> GradEField(pDim, pDim, eNN);
    tensor<double, 4> HessEField(pDim, pDim, pDim, eNN);

    ConstitutiveModels::LinearElasticity::strain(Strain, GlobDBF, pDim);
    ConstitutiveModels::LinearElasticity::gradStrain(GradStrain, GlobHBF, pDim);
    ConstitutiveModels::LinearElasticity::hessStrain(HessStrain, GlobTBF, pDim);
    ConstitutiveModels::Piezoelectricity::electricFieldTensor(EField, GlobDBF, pDim);
    ConstitutiveModels::Piezoelectricity::gradElectricField(GradEField, GlobHBF, pDim);
    ConstitutiveModels::Piezoelectricity::hessElectricField(HessEField, GlobTBF, pDim);

    /*----------------------------------------------------------------------------
        Constitutive relations
    ------------------------------------------------------------------------------*/
    tensor<double, 4> SigHat(pDim, pDim, numDOFs, eNN);
    tensor<double, 5> SigTilde(pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 6> GradSigTilde(pDim, pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 3> DHat(pDim, numDOFs, eNN);
    tensor<double, 3> Ti(pDim, numDOFs, eNN);
    tensor<double, 3> ri(pDim, numDOFs, eNN);
    tensor<double, 2> W(numDOFs, eNN);
    tensor<double, 2> Tau(numDOFs, eNN);

    ConstitutiveModels::Flexoelectricity::Direct::stress(SigHat, C, Strain, E, EField, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::doubleStress(SigTilde, H, GradStrain, EField, Mu, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::gradDoubleStress(GradSigTilde, H, HessStrain, Mu, GradEField, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::electricDisplacement(DHat, EField, Strain, GradStrain, Mu, K, E, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::traction(Ti, SigHat, SigTilde, GradSigTilde, PMat, NMat, normal, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::doubleTraction(ri, SigTilde, normal, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::surfaceChargeDensity(W, DHat, PMat, NMat, normal, pDim);

    /*----------------------------------------------------------------------------
        Retrive Nitsche's parameters
    ------------------------------------------------------------------------------*/
    double betaU = fillStr->userStr->z_aux[0];
    double betaPhi = fillStr->userStr->z_aux[2];

    /*----------------------------------------------------------------------------
       Synthetic solution
    ------------------------------------------------------------------------------*/
    syntheticSolutionType type;
    if (fillStr->userStr->i_aux[0] == 0)
        type = syntheticSolutionType::polynomial;
    else if (fillStr->userStr->i_aux[0] == 1)
        type = syntheticSolutionType::sinusoidal1;
    else if (fillStr->userStr->i_aux[0] == 2)
        type = syntheticSolutionType::sinusoidal2;
    /* u   : sol[0]
       v   : sol[1]
       phi : sol[2] */
    std::vector<double> syntheticSol = syntheticSolution(coords(0), coords(1), type);

    /*----------------------------------------------------------------------------
       Integration on boundaries
    ------------------------------------------------------------------------------*/
    // Allocate space:
    tensor<double, 4> Ak(fillStr->Ak(0, 0).data(), eNN, numDOFs, eNN, numDOFs);
    tensor<double, 2> Bk(fillStr->Bk(0).data(), eNN, numDOFs);

    // Dir BC: Integration on \partial Omega_u
    // int ( u_i betaU du_i - u_i dt_i - uB_i betaU du_i + uB_i dt_i - t_i du_i )
    //       ~~~~~~~~~~~~~~   ~~~~~~~~   ~~~~~~~~~~~~~~~   ~~~~~~~~~   ~~~~~~~~
    //            LHS           LHS            RHS            RHS         LHS
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, i, all, i) += betaU * outer(bf, bf) * dl; // u_i betaU du_i
        Bk(all, i) += syntheticSol[i] * betaU * bf * dl;  // Goes to RHS: - uB_i betaU du_i
        for (int j = 0; j < numDOFs; ++j)
        {
            Ak(all, i, all, j) -= outer(bf, Ti(i, j, all)) * dl; // - u_i dt_i
            Ak(all, j, all, i) -= outer(Ti(i, j, all), bf) * dl; // - t_i du_i
            Bk(all, j) -= syntheticSol[i] * Ti(i, j, all) * dl;  // Goes to RHS: uB_i dt_i
        }
    }

    /*----------------------------------------------------------------------------
       Synthetic Neumann boundary condition
    ------------------------------------------------------------------------------*/
    std::vector<double> dTrac = doubleTraction(fillStr->userStr->dparam[2],
        fillStr->userStr->dparam[8],
        fillStr->userStr->dparam[10],
        fillStr->userStr->dparam[11],
        fillStr->userStr->dparam[12],
        fillStr->userStr->dparam[13],
        coords(0), coords(1), type);
    // Neu BC: double traction
    // int ( -rBi * Dui )
    //      ~~~~~~~~~~~~~
    //           RHS
    for (int i = 0; i < eNN; ++i)
    {
        Bk(i, 0) += dTrac[0] * NDbf_g(i) * dl;
        Bk(i, 1) += dTrac[1] * NDbf_g(i) * dl;
        Bk(all, i) += syntheticSol[3] * W(i, all) * dl;
    }

    //

    // Dir BC: Integration on \partial Omega_phi
    // int ( -phi betaPhi dphi + phi dw + phiB betaPhi dphi - phiB dw + w dphi )
    //       ~~~~~~~~~~~~~~~~~   ~~~~~~   ~~~~~~~~~~~~~~~~~   ~~~~~~~   ~~~~~~
    //              LHS           LHS            RHS            RHS       LHS
    Ak(all, numDOFs - 1, all, numDOFs - 1) -= outer(bf, betaPhi * bf) * dl; // -phi betaPhi dphi
    Bk(all, numDOFs - 1) -= betaPhi * syntheticSol[2] * bf * dl;            // Goes to RHS: phiB betaPhi dphi
    for (int i = 0; i < numDOFs; ++i)
    {
        Ak(all, numDOFs - 1, all, i) += outer(bf, W(i, all)) * dl; // w dphi
        Ak(all, i, all, numDOFs - 1) += outer(W(i, all), bf) * dl; // phi dw
        Bk(all, i) += syntheticSol[2] * W(i, all) * dl;            // Goes to RHS: -phiB dw
    }

    /*----------------------------------------------------------------------------
        Calculate Error
    ------------------------------------------------------------------------------*/
    double err_Ux = 0.0;
    double err_Uy = 0.0;
    double err_Phi = 0.0;

    // L2 Error calculation
    tensor<double, 1> sol = product(nborDOFs, bf, { {0, 0} });

    err_Ux += dl * (sol(0) - syntheticSol[0]) * (sol(0) - syntheticSol[0]);
    err_Uy += dl * (sol(1) - syntheticSol[1]) * (sol(1) - syntheticSol[1]);
    err_Phi += dl * (sol(2) - syntheticSol[2]) * (sol(2) - syntheticSol[2]);
    fillStr->addToGlobalIntegral("L2Err_Ux", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi", err_Phi);
}

void syntheticVolumeLoad(std::vector<double>& B,
    double& Q,
    syntheticSolutionType type,
    double L, double K_L,
    double e_L, double e_T, double e_S,
    double mu_L, double mu_T, double mu_S,
    double C_L, double C_T, double C_S,
    double x, double y)
{
    if (type == syntheticSolutionType::polynomial)
    {
        B[0] = -C_L * (6. * x + 2. * y + 2.) - C_T * (-6. * x - 2. * y - 2.) +
            (-6. * x + 4. * y) * e_L + 6. * mu_L - 2. * C_S * (-6. * x - y - 1.) - 2 * e_S;
        B[1] = -2. * C_S * (x - 6. * y - 1.) + 4. * e_S * x - 8. * mu_S -
            C_T * (2. * x - 6. * y - 2.) - C_L * (-2. * x + 6. * y + 2.) + 4. * e_T * x - 4. * mu_T;

        Q = K_L * (-6. * x + 4. * y - 2.) + e_L * (6. * x + 2. * y + 2.) +
            e_T * (-6. * x - 2. * y - 2.) + 12. * mu_L - 12. * mu_T - 24. * mu_S +
            2. * e_S * (-6. * x - y - 1.);
    }
    else if (type == syntheticSolutionType::sinusoidal1)
    {
        B[0] = -e_L * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.4e1 + C_L * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 - pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_L / 0.8e1 + C_T * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 - pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_T / 0.2e1 + pow(M_PI, 0.4e1) * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * L * L * C_T / 0.8e1 + pow(M_PI, 0.4e1) * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * L * L * C_L / 0.8e1 - e_S * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) + C_S * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1 - pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_S + pow(M_PI, 0.4e1) * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * L * L * C_S / 0.4e1;
        B[1] = -e_S * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.2e1 + C_S * M_PI * M_PI * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) / 0.2e1 - pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_S / 0.2e1 + pow(M_PI, 0.4e1) * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) * L * L * C_S / 0.4e1 - e_T * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.2e1 + C_T * M_PI * M_PI * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) / 0.4e1 - pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_T / 0.4e1 + C_L * M_PI * M_PI * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) / 0.4e1 - pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_L + pow(M_PI, 0.4e1) * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) * L * L * C_L / 0.8e1 + pow(M_PI, 0.4e1) * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) * L * L * C_T / 0.8e1;

        Q = pow(M_PI, 0.3e1) * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * mu_T / 0.4e1 - e_T * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 + pow(M_PI, 0.3e1) * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * mu_S / 0.2e1 + pow(M_PI, 0.3e1) * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * mu_L / 0.4e1 - e_L * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 - 0.5e1 / 0.4e1 * K_L * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) - e_S * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1;
    }
    else if (type == syntheticSolutionType::sinusoidal2)
    {
        B[0] = e_L * M_PI * M_PI * sin(M_PI * x / 0.10e2) / 0.100e3 + C_L * M_PI * M_PI * sin(M_PI * x) - pow(M_PI, 0.3e1) * cos(M_PI * x / 0.10e2) * mu_L / 0.1000e4 + pow(M_PI, 0.4e1) * sin(M_PI * x) * L * L * C_L + e_S * M_PI * M_PI * sin(M_PI * y / 0.10e2) / 0.100e3;
        B[1] = C_L * M_PI * M_PI * sin(M_PI * y) - pow(M_PI, 0.3e1) * cos(M_PI * y / 0.10e2) * mu_L / 0.1000e4 + pow(M_PI, 0.4e1) * sin(M_PI * y) * L * L * C_L;

        Q = -pow(M_PI, 0.3e1) * cos(M_PI * x) * mu_L - e_L * M_PI * M_PI * sin(M_PI * x) + K_L * M_PI * M_PI * sin(M_PI * x / 0.10e2) / 0.100e3 - pow(M_PI, 0.3e1) * cos(M_PI * y) * mu_L + K_L * M_PI * M_PI * sin(M_PI * y / 0.10e2) / 0.100e3;
    }
}

std::vector<double> syntheticSolution(double x, double y, syntheticSolutionType type)
{
    std::vector<double> sol(3);
    if (type == syntheticSolutionType::polynomial)
    {
        sol[0] = x + x * x - 2 * x * y + x * x * x - 3 * x * y * y + x * x * y;
        sol[1] = -y + y * y - 2 * x * y + y * y * y - 3 * x * x * y - x * y * y;
        sol[2] = x * x * x + y * y - 2 * x * x * y;
    }
    else if (type == syntheticSolutionType::sinusoidal1)
    {
        sol[0] = cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1);        // displacement u
        sol[1] = sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1);        // displacement v
        sol[2] = 0.10e1 - cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)); // electirc charge phi
    }
    else if (type == syntheticSolutionType::sinusoidal2)
    {
        sol[0] = sin(M_PI * x);
        sol[1] = cos(M_PI * y);
        sol[2] = sin(M_PI * x / 0.10e2) + sin(M_PI * y / 0.10e2);
    }
    return sol;
}

std::vector<double> DSyntheticSolution(double x, double y, syntheticSolutionType type)
{
    std::vector<double> Dsol(6);
    if (type == syntheticSolutionType::polynomial)
    {
        Dsol[0] = 1.0 + 2.0 * x - 2 * y + 3.0 * x * x - 3 * y * y + 2.0 * x * y;  // Ux,x
        Dsol[1] = -2 * x - 6 * x * y + x * x;                                     // Ux,y
        Dsol[2] = -2 * y - 6.0 * x * y - y * y;                                   // Uy,x
        Dsol[3] = -1.0 + 2.0 * y - 2 * x + 3.0 * y * y - 3 * x * x - 2.0 * x * y; // Uy,y
        Dsol[4] = 3.0 * x * x - 4.0 * x * y;                                      // Phi,x
        Dsol[5] = 2.0 * y - 2.0 * x * x;                                          // Phi,y
    }
    else if (type == syntheticSolutionType::sinusoidal1)
    {
        Dsol[0] = -M_PI * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1; // u,x
        Dsol[1] = cos(M_PI * x / 0.2e1) * M_PI * cos(M_PI * y / 0.2e1) / 0.2e1;  // u,y
        Dsol[2] = cos(M_PI * x / 0.2e1) * M_PI * cos(M_PI * y / 0.2e1) / 0.2e1;  // v,x
        Dsol[3] = -M_PI * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1; // v,y
        Dsol[4] = M_PI * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.2e1;    // phi,x
        Dsol[5] = M_PI * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1));            // phi,y
    }
    else if (type == syntheticSolutionType::sinusoidal2)
    {
        Dsol[0] = M_PI * cos(M_PI * x);                   // u,x
        Dsol[1] = 0.0;                                    // u,y
        Dsol[2] = 0.0;                                    // v,x
        Dsol[3] = M_PI * cos(M_PI * y);                   // v,y
        Dsol[4] = M_PI * cos(M_PI * x / 0.10e2) / 0.10e2; // phi,x
        Dsol[5] = M_PI * cos(M_PI * y / 0.10e2) / 0.10e2; // phi,y
    }
    return Dsol;
}

std::vector<double> doubleTraction(double l,
    double mu_L, double mu_S,
    double C_L, double C_T, double C_S,
    double x, double y, syntheticSolutionType type)
{
    std::vector<double> R(2);
    if (type == syntheticSolutionType::polynomial)
    {
        if (abs(y) < 1.e-10 or abs(y - 1.0) < 1.e-10)
        {
            R[0] = 2. * l * l * C_S * (-6. * x - y - 1.) - mu_S * (-3. * x * x + 4. * x * y);
            R[1] = l * l * C_T * (2. * x - 6. * y - 2.) + l * l * C_L * (-2. * x + 6. * y + 2.) - mu_L * (2. * x * x - 2. * y);
        }
        else
        {
            R[0] = l * l * C_L * (6. * x + 2. * y + 2.) + l * l * C_T * (-6. * x - 2. * y - 2.) - mu_L * (-3. * x * x + 4. * x * y);
            R[1] = 2. * l * l * C_S * (x - 6. * y - 1.) - mu_S * (2. * x * x - 2. * y);
        }
    }
    else if (type == syntheticSolutionType::sinusoidal1)
    {
        if (abs(y) < 1.e-10 or abs(y - 1.0) < 1.e-10)
        {
            R[0] = -8.0 * l * l * C_S * M_PI * M_PI * cos(2 * M_PI * x) * sin(2 * M_PI * y) +
                2 * mu_S * M_PI * sin(2 * M_PI * (x + 2 * y));
            R[1] = -4 * l * l * C_T * M_PI * M_PI * sin(2 * M_PI * x) * cos(2 * M_PI * y) -
                4.0 * l * l * C_L * M_PI * M_PI * sin(2 * M_PI * x) * cos(2 * M_PI * y) +
                4 * mu_L * M_PI * sin(2 * M_PI * (x + 2 * y));
        }
        else
        {
            R[0] = -4.0 * l * l * C_L * M_PI * M_PI * cos(2 * M_PI * x) * sin(2 * M_PI * y) -
                4 * l * l * C_T * M_PI * M_PI * cos(2 * M_PI * x) * sin(2 * M_PI * y) +
                2 * mu_L * M_PI * sin(2 * M_PI * (x + 2 * y));
            R[1] = -8 * l * l * C_S * M_PI * M_PI * sin(2 * M_PI * x) * cos(2 * M_PI * y) +
                4 * mu_S * M_PI * sin(2 * M_PI * (x + 2 * y));
        }
    }
    else if (type == syntheticSolutionType::sinusoidal2)
    {
        throw runtime_error("doubleTraction: not implemented for sinusoidal2.");
    }
    return R;
}
