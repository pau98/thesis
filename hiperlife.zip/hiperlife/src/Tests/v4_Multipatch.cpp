
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// HiPerLiFE headers
#include "hl_MeshMap_Trivial.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_MultiPatchMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<FillStructure> fillStr)
{
    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFs();  // Local shape function
    double gNa[eNN*pDim], jac;
    GlobalBasisFunctions::gradients(gNa, jac, subFill);

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        // /// Fill RHS
        // fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}

void createMultipatch0(RCP<MultiPatchMeshGenerator> mpatch)
{

    //Mesh generator for the circle
    RCP<StructMeshGenerator> imm1 = rcp(new StructMeshGenerator);
    imm1->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    imm1->genCircle(40, 0.15);
    imm1->translate(0.5, 0.5, 0.0);

    //Mesh generator for the square
    RCP<StructMeshGenerator> imm2 = rcp(new StructMeshGenerator);
    imm2->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    imm2->genCircle(4, 0.5);
    imm2->rotate2D(M_PI/4.0);
    imm2->translate(0.5, 0.5, 0.0);
    // imm2->genSquareLine(40, 0.7);
    // imm2->translate(0.15, 0.15, 0.0);

    //Mesh generator for csv
    RCP<StructMeshGenerator> imm3 = rcp(new StructMeshGenerator);
    imm3->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    imm3->genPolygonalCurve("../meshes/fish.csv");
    imm3->translate(0.15, 0.15, 0.0);

    // Multipatch
    mpatch = rcp(new MultiPatchMeshGenerator);
    mpatch->setMeshes({imm1, imm2}, MultiPatchConnectivity::Disconnected);
    mpatch->Update();
}

void createMultipatch1(RCP<MultiPatchMeshGenerator> mpatch)
{
    // Initialize
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Square;
    int bfOrder = 1;
    bool balance = false;

    // Square mesh1
    RCP<StructMeshGenerator> mesh1 = rcp(new StructMeshGenerator);
    mesh1->setMesh(eType, bfType, bfOrder);
    mesh1->genStructMesh(4, 4);
    RCP<DistributedMesh> disMesh1 = rcp(new DistributedMesh);
    disMesh1->setMesh(mesh1);
    disMesh1->setBalanceMesh(balance);
    disMesh1->Update();
    disMesh1->printFileLegacyVtk("Mesh1");

    // Square mesh2
    RCP<StructMeshGenerator> mesh2 = rcp(new StructMeshGenerator);
    mesh2->setMesh(eType, bfType, bfOrder);
    mesh2->genStructMesh(4, 4);
    mesh2->translateX(1.0);
    RCP<DistributedMesh> disMesh2 = rcp(new DistributedMesh);
    disMesh2->setMesh(mesh2);
    disMesh2->setBalanceMesh(balance);
    disMesh2->Update();
    disMesh2->printFileLegacyVtk("Mesh2");

    // Square mesh3
    RCP<StructMeshGenerator> mesh3 = rcp(new StructMeshGenerator);
    mesh3->setMesh(eType, bfType, bfOrder);
    // mesh3->genStructMesh(4);
    mesh3->genSquare(6, 1.5);
    // mesh3->genRectangle(8, 4, 2.0, 1.0);
    // mesh3->genSquare(2, 0.5);
    mesh3->translateY(1.0);
    // mesh3->translateX(2.0);
    RCP<DistributedMesh> disMesh3 = rcp(new DistributedMesh);
    disMesh3->setMesh(mesh3);
    disMesh3->setBalanceMesh(balance);
    disMesh3->Update();
    disMesh3->printFileLegacyVtk("Mesh3");

    // Multipatch
    // mpatch->setMeshes({mesh1, mesh2}, MultiPatchConnectivity::Unclamped, 0.0001);
    mpatch->setMeshes({mesh1, mesh2, mesh3}, MultiPatchConnectivity::Unclamped, 0.0001);
    mpatch->Update();
}

void createMultipatch2(RCP<MultiPatchMeshGenerator> mpatch)
{
    // Initialize
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Square;
    int bfOrder = 1;
    bool balance = true;

    // Left channel
    RCP<StructMeshGenerator> mesh1 = rcp(new StructMeshGenerator);
    mesh1->setMesh(eType, bfType, bfOrder);
    mesh1->genRectangle(10, 20, 2.0, 1.0);

    // Left transition
    RCP<StructMeshGenerator> mesh2 = rcp(new StructMeshGenerator);
    mesh2->setMesh(eType, bfType, bfOrder);
    mesh2->genRuledSurface(10, 20, {2.0,.0,.0}, {2.5,.0,.0}, {2.5,0.75,.0},{2.0,1.0,.0});

    // Center
    RCP<StructMeshGenerator> mesh3 = rcp(new StructMeshGenerator);
    mesh3->setMesh(eType, bfType, bfOrder);
    mesh3->genRectangle(40, 20, 0.5, 0.75);
    mesh3->translateX(2.5);

    // Multipatch
    mpatch->setMeshes({mesh1, mesh2, mesh3}, MultiPatchConnectivity::LinearConstraints, 0.0001);
    mpatch->Update();
}

void createMultipatch3(RCP<MultiPatchMeshGenerator> mpatch)
{
    // Initialize
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Parallelep;
    int bfOrder = 1;
    bool balance = false;

    // Square mesh1
    RCP<StructMeshGenerator> mesh1 = rcp(new StructMeshGenerator);
    mesh1->setMesh(eType, bfType, bfOrder);
    mesh1->genStructMesh(12);
    RCP<DistributedMesh> disMesh1 = rcp(new DistributedMesh);
    disMesh1->setMesh(mesh1);
    disMesh1->setBalanceMesh(balance);
    disMesh1->Update();
    disMesh1->printFileLegacyVtk("Mesh1");

    // Square mesh2
    RCP<StructMeshGenerator> mesh2 = rcp(new StructMeshGenerator);
    mesh2->setMesh(eType, bfType, bfOrder);
    // mesh2->genStructMesh(2);
    mesh2->genRectangularParallelepiped(12, 12, 6, 1.0, 1.0, 0.5);
    mesh2->translateX(1.0);
    mesh2->translateZ(0.5);
    RCP<DistributedMesh> disMesh2 = rcp(new DistributedMesh);
    disMesh2->setMesh(mesh2);
    disMesh2->setBalanceMesh(balance);
    disMesh2->Update();
    disMesh2->printFileLegacyVtk("Mesh2");

    // Square mesh3
    RCP<StructMeshGenerator> mesh3 = rcp(new StructMeshGenerator);
    mesh3->setMesh(eType, bfType, bfOrder);
    mesh3->genStructMesh(6);
    mesh3->scale(0.5);
    mesh3->translate(0.75, 0.25, 1.0);
    RCP<DistributedMesh> disMesh3 = rcp(new DistributedMesh);
    disMesh3->setMesh(mesh3);
    disMesh3->setBalanceMesh(balance);
    disMesh3->Update();
    disMesh3->printFileLegacyVtk("Mesh3");

    // Multipatch
    mpatch->setMeshes({mesh1, mesh2}, MultiPatchConnectivity::LinearConstraints, 0.001);
    // mpatch->setMeshes({mesh1, mesh2, mesh3}, MultiPatchConnectivity::LinearConstraints, 0.001);
    mpatch->Update();
}

void createMultipatch4(RCP<MultiPatchMeshGenerator> mpatch)
{
    // Initialize
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Square;
    int bfOrder = 1;
    bool balance = false;

    // Nose
    RCP<StructMeshGenerator> mesh1 = rcp(new StructMeshGenerator);
    mesh1->setMesh(eType, bfType, bfOrder);
    mesh1->genDisk_Polar(20, 20, 1.0);
    mesh1->transformFree([](double x, double y, double z)
                             {
                                 double r = sqrt(x*x + y*y);
                                 return std::make_tuple(x, y, pow(r, 2.0));
                             });
    mesh1->scaleZ(4.0);
    RCP<DistributedMesh> disMesh1 = rcp(new DistributedMesh);
    disMesh1->setMesh(mesh1);
    disMesh1->setBalanceMesh(balance);
    disMesh1->Update();
    disMesh1->printFileLegacyVtk("Mesh1");

    // Body
    RCP<StructMeshGenerator> mesh2 = rcp(new StructMeshGenerator);
    mesh2->setMesh(eType, bfType, bfOrder);
    mesh2->genStructMesh(20);
    mesh2->transformFree([](double x, double y, double z)
                             {
                                 double theta = 2.0*M_PI*(1.0-x);
                                 return std::make_tuple(cos(theta), y, sin(theta));
                             });
    mesh2->scaleY(4);
    mesh2->rotateX(M_PI/2.0);
    mesh2->translateZ(4.0);
    RCP<DistributedMesh> disMesh2 = rcp(new DistributedMesh);
    disMesh2->setMesh(mesh2);
    disMesh2->setBalanceMesh(balance);
    disMesh2->Update();
    disMesh2->printFileLegacyVtk("Mesh2");

    // Square mesh3
    RCP<StructMeshGenerator> mesh3 = rcp(new StructMeshGenerator);
    mesh3->setMesh(eType, bfType, bfOrder);
    mesh3->genStructMesh(6);
    mesh3->scale(0.5);
    mesh3->translate(0.75, 0.25, 1.0);
    RCP<DistributedMesh> disMesh3 = rcp(new DistributedMesh);
    disMesh3->setMesh(mesh3);
    disMesh3->setBalanceMesh(balance);
    disMesh3->Update();
    disMesh3->printFileLegacyVtk("Mesh3");

    // Multipatch
    // mpatch->setMeshes({mesh1, mesh2}, 0.0001);
    mpatch->setMeshes({mesh1, mesh2, mesh3}, MultiPatchConnectivity::LinearConstraints, 0.0001);
    mpatch->Update();
}

int main()
{
    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);

    // Define parameters of the model
    double force = 0.0;
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;


    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//

    // Create mesh
    RCP<MultiPatchMeshGenerator> mpatch = rcp(new MultiPatchMeshGenerator);
    createMultipatch3(mpatch);

    // Distribute mesh
    RCP<DistributedMesh> disMeshP = rcp(new DistributedMesh);
    disMeshP->setMesh(mpatch);
    disMeshP->setBalanceMesh(true);
    disMeshP->Update();
    disMeshP->printFileLegacyVtk("MeshP");


    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//
    /// **************************************************************//

    ///===========           Create DOFHandler            ===========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMeshP));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    // dofHand->setNumNodeAuxF(1);
    dofHand->Update();

    ///===========          Boundary conditions          ===========///
    // dofHand->setBoundaryCondition(0, 0.0);
    // dofHand->setBoundaryCondition(0, MAxis::Xmin, -1.0);
    // dofHand->setBoundaryCondition(0, MAxis::Xmax, 1.0);
    // dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x){return x;});
    // dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});

    for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    {
        double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
        double y = dofHand->mesh->nodeCoord(i, 1, IndexType::Local);
        double z = dofHand->mesh->nodeCoord(i, 2, IndexType::Local);
        if (mpatch->_pDim == 2)
        {
            if (x < 0.001)
                dofHand->setConstraint(0, i, IndexType::Local, -2.0);
            if (x > 1.999)
                dofHand->setConstraint(0, i, IndexType::Local, 1.0);
        }
        else if (mpatch->_pDim == 3)
        {
            if (x < 0.005 and z >= 0.5)
                dofHand->setConstraint(0, i, IndexType::Local, -2.0);
            if (x > 1.999)
                dofHand->setConstraint(0, i, IndexType::Local, 1.0);
            if (z < 0.0005)
                dofHand->setConstraint(0, i, IndexType::Local, -3.0);
            if (z > 1.4999)
                dofHand->setConstraint(0, i, IndexType::Local, 3.0);
        }
        // if (x > 0.999 and y > 0.999)
        //     dofHand->setConstraint(0, i, IndexType::Local, -2.0);
        // if (y > 1.999)
        //     dofHand->setConstraint(0, i, IndexType::Local, -1.0);
        // dofHand->nodeAuxF->setValue(0, i, IndexType::Local, x);
    }
    dofHand->UpdateGhosts();


    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ", pow(mpatch->_bfOrder+1, mpatch->_pDim));
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->Update();


    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//

    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->setDefaultParameters();
    solver->Update();

    // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setTolerance(1.E-8);
    // solver->setMaxNumIterations(500);
    // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    // solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilu);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::Extreme);
    // solver->setDefaultParameters();
    // solver->Update();


    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    bool status = solver->solve();
    solver->UpdateSolution();

    dofHand->printFile("Poisson");
    dofHand->printFileLegacyVtk("Poisson", true);


    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}
