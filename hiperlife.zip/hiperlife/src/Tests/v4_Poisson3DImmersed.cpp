/// C++ headers
#include <iostream>
#include <fstream>
#include <mpi.h>
#include <cmath>
#include <unistd.h>
#include <chrono>

/// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_MultiPatchMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"

void Domain(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void Nitsche(Teuchos::RCP<hiperlife::FillStructure> fillStr);
double computeL2Error(int numElements, int levelOfRefinement);
double analyticalSolution(double x, double y, double z);
double bodyForce(double x, double y, double z);

int main()
{
    // Get starting timepoint
    auto start = std::chrono::high_resolution_clock::now();

    MPI_Init(nullptr, nullptr);

    int myRank{};
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    for (int j = 3; j < 4; ++j) // 2 to 8
    {
        for (int i = 2; i < 6; ++i)
        {
            computeL2Error(pow(2, i), j);
        }
    }

    MPI_Finalize();

    // Get ending timepoint
    auto stop = std::chrono::high_resolution_clock::now();

    // Get duration. Substart timepoints to
    // get duration. To cast it to proper unit
    // use duration cast method
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);

    cout << "Time taken by function: "
         << duration.count() << " seconds" << endl;
    return 0;
}

// int main()
// {
//     // Get starting timepoint

//     MPI_Init(nullptr, nullptr);

//     int myRank{};
//     MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

//     std::ofstream runtime("run-time.txt");
//     assert(runtime.is_open());
//     runtime.precision(12);
//     runtime << "num GPs\t"
//             << "level\t"
//             << "time\t"
//             << "error\n";

//     for (int j = 1; j < 4; ++j) // level of refinement
//     {
//         for (int i = 1; i < 5; ++i) // number of gps
//         {
//             auto start = std::chrono::high_resolution_clock::now();
//             double error = computeL2Error(std::pow(i, 3), j);
//             auto stop = std::chrono::high_resolution_clock::now();
//             auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
//             runtime << std::pow(i, 3) << "\t"
//                     << j << "\t"
//                     << duration.count() << "\t"
//                     << error << "\n";
//         }
//     }

//     MPI_Finalize();
//     return 0;
// }

double computeL2Error(int numElements, int epsilon)
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;

    int i = 1;
    while (0 == i)
        sleep(5);

    /// **************************************************************//
    /// *****                 Parameters                         *****//
    /// **************************************************************//
    double h = 1. / static_cast<double>(numElements);
    double domainLength = 0.499999 + pow(2, -2);
    ElemType elemType = ElemType::Parallelep;
    BasisFuncType bfType = BasisFuncType::BSplines;
    int numImmElem{8};
    int bfOrder{3};
    // set<MAxis> ax = {MAxis::Xmin, MAxis::Xmax, MAxis::Ymin, MAxis::Ymax};
    double lambda{1000./ h};                           // Nitsche's parameter
    RCP<UserStructure> userStr = rcp(new UserStructure); // New user structure
    userStr->a_aux.resize(1);
    userStr->a_aux[0] = lambda;

    ///====================== Mesh generation ======================///
    RCP<StructMeshGenerator> dummyMesh = rcp(new StructMeshGenerator);
    dummyMesh->setMesh(elemType, bfType, 1);
    dummyMesh->genCube(numElements, 1.0);

    RCP<DistributedMesh> disDummyMesh = rcp(new DistributedMesh);
    disDummyMesh->setMesh(dummyMesh);
    disDummyMesh->setBalanceMesh(true);
    disDummyMesh->Update();
    disDummyMesh->printFileLegacyVtk("paramSp");

    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(elemType, bfType, bfOrder);
    structMesh->genCube(numElements, 1.0);

    // Distributed mesh
    RCP<DistributedMesh> disBackMesh = rcp(new DistributedMesh);
    disBackMesh->setMesh(structMesh);
    disBackMesh->setBalanceMesh(true);
    disBackMesh->Update();
    disBackMesh->printFileLegacyVtk("backMesh");

    //--------------------------- Immersed mesh --------------------------//
    RCP<StructMeshGenerator> faceZMin = rcp(new StructMeshGenerator);
    faceZMin->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    faceZMin->genSquare(numImmElem, domainLength);
    faceZMin->translate((1. - domainLength) / 2., (1. - domainLength) / 2., (1. + domainLength) / 2.);

    RCP<StructMeshGenerator> faceZMax = rcp(new StructMeshGenerator);
    faceZMax->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    faceZMax->genSquare(numImmElem, domainLength);
    faceZMax->rotateX(M_PI, {domainLength / 2., domainLength / 2., 0.});
    faceZMax->translate((1. - domainLength) / 2., (1. + domainLength) / 2., (1. - domainLength) / 2.);

    RCP<StructMeshGenerator> faceYMin = rcp(new StructMeshGenerator);
    faceYMin->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    faceYMin->genSquare(numImmElem, domainLength);
    faceYMin->rotateX(M_PI / 2.);
    faceYMin->translate((1. - domainLength) / 2., (1. - domainLength) / 2., (1. - domainLength) / 2.);

    RCP<StructMeshGenerator> faceYMax = rcp(new StructMeshGenerator);
    faceYMax->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    faceYMax->genSquare(numImmElem, domainLength);
    faceYMax->rotateX(-M_PI / 2., {0., domainLength, 0.});
    faceYMax->translate((1. - domainLength) / 2., (1. + domainLength) / 2., (1. + domainLength) / 2.);

    RCP<StructMeshGenerator> faceXMin = rcp(new StructMeshGenerator);
    faceXMin->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    faceXMin->genSquare(numImmElem, domainLength);
    faceXMin->rotateY(-M_PI / 2.);
    faceXMin->translate((1. - domainLength) / 2., (1. - domainLength) / 2., (1. - domainLength) / 2.);

    RCP<StructMeshGenerator> faceXMax = rcp(new StructMeshGenerator);
    faceXMax->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    faceXMax->genSquare(numImmElem, domainLength);
    faceXMax->rotateY(M_PI / 2.);
    faceXMax->translate((1. + domainLength) / 2., (1. - domainLength) / 2., (1. + domainLength) / 2.);

    RCP<MultiPatchMeshGenerator> immersedMeshCube = rcp(new MultiPatchMeshGenerator);
    immersedMeshCube->setMeshes({faceXMin, faceXMax, faceYMin, faceYMax, faceZMin, faceZMax},
                                MultiPatchConnectivity::LinearConstraints, 1e-9);
    immersedMeshCube->Update();
    // immersedMeshCube->rotateX(M_PI*5/180);
    // immersedMeshCube->rotateY(M_PI*5/180);
    // immersedMeshCube->rotateZ(M_PI*5/180);

    // RCP<StructMeshGenerator> xPlane = rcp(new StructMeshGenerator);
    // xPlane->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // xPlane->genSquare(numImmElem, 1.1);
    // xPlane->rotateY(M_PI / 2.);
    // xPlane->translate(0.5, -0.05, 1.05);

    // Sphere
    // RCP<UnstructVtkMeshGenerator> sphereMesh = rcp(new UnstructVtkMeshGenerator);
    // sphereMesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // sphereMesh->genSphere([](double x[3])
    //                       { return 0.05; });
    // sphereMesh->scale(0.3);
    // sphereMesh->translate(0.5, 0.5, 0.5);

    // Distributed mesh
    RCP<DistributedMesh> disImmMesh = rcp(new DistributedMesh);
    disImmMesh->setMesh(immersedMeshCube);
    disImmMesh->setMeshRelation(MeshRelation::Immersed, disBackMesh);
    disImmMesh->setImmersedInteriorPoints({{0.5, 0.5, 0.5}});
    disImmMesh->setBalanceMesh(true);
    disImmMesh->Update();
    disImmMesh->printFileLegacyVtk("meshImm");

    /// **************************************************************//
    /// *****               DOFsHANDLER CREATION                 *****//
    /// **************************************************************//
    RCP<DOFsHandler> dofHandBack = rcp(new DOFsHandler(disBackMesh));
    dofHandBack->setNameTag("dofHandBack");
    dofHandBack->setNumDOFs(1);
    dofHandBack->Update();

    dofHandBack->setConstraint(0, 0.0);
    for (int e = 0; e < dofHandBack->mesh->loc_nElem(); e++)
    {
        if (dofHandBack->mesh->_elemFlags->getValue(1, e, IndexType::Local) != 0)
        {
            vector<int> nbors = dofHandBack->mesh->_connec->getNborList(e, IndexType::Local);
            for (auto n : nbors)
            {
                if (dofHandBack->mesh->isNodeInPart(n))
                {
                    dofHandBack->removeConstraint(0, n, IndexType::Global);
                }
            }
        }
    }

    dofHandBack->UpdateGhosts();
    dofHandBack->printFileLegacyVtk("dofHand", true);

    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHandBack});

    hiperProbl->setIntegration("Integ", {"dofHandBack"});
    int nGaussPts = pow(ceil(static_cast<double>(2 * bfOrder + 1) / 2.), 3);
    // int nGaussPtsBorder = pow(ceil(static_cast<double>(2 * bfOrder + 1) / 2.)+1., 2);
    hiperProbl->setCubatureCutCellNonConforming("Integ", nGaussPts, nGaussPts, 2);
    hiperProbl->setElementFillings("Integ", Domain);

    hiperProbl->setIntegration("BorderInteg", {"dofHand"});
    hiperProbl->setCubatureBorderImmersed("BorderInteg", 16);
    hiperProbl->setElementFillings("BorderInteg", Nitsche);

    hiperProbl->setGlobalIntegrals({"L2E", "Volume", "BoundaryArea"});

    hiperProbl->Update();

    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    ofstream myfile;
    myfile.open("cubature_" + to_string(hiperProbl->myRank()) + ".csv", std::ofstream::out | std::ofstream::trunc);
    myfile.close();

    //===========               Set solver               ===========//
    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->setDefaultParameters();
    solver->Update();

    // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setTolerance(1.E-8);
    // solver->setMaxNumIterations(500);
    // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver->setDefaultParameters();
    // solver->Update();

    solver->solve();
    solver->UpdateSolution();
    dofHandBack->printFileLegacyVtk("solBack", true);

    // Create timer
    RCP<Timer> _timer = Teuchos::rcp(new Timer({"filling"}));

    // Fill linear system
    _timer->start("filling");
    hiperProbl->FillLinearSystem();
    _timer->end("filling");
    _timer->printTiming();

    double error = sqrt(hiperProbl->globalIntegral("L2E"));

    if (hiperProbl->myRank() == 0)
    {
        cout.precision(15);
        cout << "L2 error      = \t" << error << endl;

        std::ofstream writeOut("L2Errors.csv", std::ios::app);
        assert(writeOut.is_open());
        writeOut.precision(12);
        writeOut << numElements << "\t" << log10(h) << "\t"
                 << hiperProbl->globalIntegral("Volume") << "\t"
                 << hiperProbl->globalIntegral("BoundaryArea") << "\t"
                 << lambda << "\t" << log10(error) << endl;
    }
    return log10(error);
    // Export stiffness matrix
    // string matName = "A" + to_string(epsilon) + ".mm";
    // EpetraExt::RowMatrixToMatrixMarketFile(matName.c_str(), *hiperProbl->A_new, "LHS", "Left hand side matrix");
}

//===============================================================================

void Domain(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;                                              // Number of neighbor nodes
    int nDim = subFill.nDim;                                            // Number of spatial dimensions
    int pDim = subFill.pDim;                                            // Number of parametric dimension
    int numDOFs = subFill.numDOFs;                                      // Number of degrees of freedom per node
    tensor<double, 1, false> bf(subFill.nborBasisFunctions(), eNN);            // Basis functions
    tensor<double, 2> Dbf_g(eNN, pDim);                                 // Derivatives of basis functions wrt x and y global coordinates
    tensor<double, 2, false> nborCoords(subFill.nborCoords.data(), eNN, nDim); // Coordinates for each node
    tensor<double, 2, false> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);  // DOF values at the nodes
    double jac;                                                         // Jacobian (differential of line/area/volume)
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}}); // Global coordinates (x,y,z)

    //===========              Finding Force              ==========//
    double force = bodyForce(coords(0), coords(1), coords(2));

    // Writing coordinates of Gaussian points to file
    ofstream myFile;
    myFile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    myFile << std::setprecision(16) << coords(0) << " "
           << coords(1) << " "
           << coords(2) << " "
           << 0 << " " << 0 << " " << 0 << " " << 0 << endl;

    //===================   Filling Ak and Bk  =====================//
    tensor<double, 2, false> Ak(fillStr->Ak(0, 0).data(), eNN, eNN);
    tensor<double, 1, false> Bk(fillStr->Bk(0).data(), eNN);
    Ak += product(Dbf_g, Dbf_g, {{1, 1}}) * jac;
    Bk += bf * force * jac;

    ///============          Calculate Errors         ===================///
    double uExact = analyticalSolution(coords(0), coords(1), coords(2));
    tensor<double, 1> uFEM = product(nborDOFs, bf, {{0, 0}});
    double L2error = (uExact - uFEM(0)) * (uExact - uFEM(0)) * jac;
    fillStr->addToGlobalIntegral("L2E", L2error);
    fillStr->addToGlobalIntegral("Volume", jac);
}

//===============================================================================

void Nitsche(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;                                                        // Number of neighbor nodes
    int nDim = subFill.nDim;                                                      // Number of spatial dimensions
    int pDim = subFill.pDim;                                                      // Number of parametric dimension
    int numDOFs = subFill.numDOFs;                                                // Number of degrees of freedom per node
    tensor<double, 1, false> bf(subFill.nborBasisFunctions(), eNN);                      // Basis functions
    tensor<double, 2, false> Dbf_l(subFill.nborBasisFunctionsDerivatives(1), eNN, pDim); // Local derivatives of the bf
    tensor<double, 2> Dbf_g(eNN, pDim);                                           // Derivatives of basis functions wrt x and y global coordinates
    tensor<double, 2, false> nborCoords(subFill.nborCoords.data(), eNN, nDim);           // Coordinates for each node
    tensor<double, 2, false> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);            // DOF values at the nodes
    double jac;                                                                   // Jacobian (differential of line/area/volume)
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}}); // Global coordinates (x,y,z)
    double lambda{fillStr->userStr->a_aux[0]};

    //===========              Finding Force              ==========//
    double u0 = analyticalSolution(coords(0), coords(1), coords(2));

    //===========              Normal Vector              ==========//
    // Normal Vector
    double Ip[4], xu[3], xv[3]; // First Fundamental form and metric mappings
    SurfLagrParam::MetricTensor(Ip, xu, xv, eNN, nborCoords.data(), Dbf_l.data());
    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    std::vector<std::vector<double>> t(2, std::vector<double>(3));
    for (int i{}; i < 2; ++i)
    {
        for (int j{}; j < 3; ++j)
        {
            t[i][j] = immMesh->_immTangents[subFill.loc_elemID][t.size() * nDim * subFill.kPt + i * nDim + j];
        }
    }

    // Compute unitary normal
    std::vector<double> NormalRef(3, 0.0);
    Math::Cross(NormalRef.data(), t[0].data(), t[1].data());
    jac = Math::Norm3D(NormalRef.data()); // FIXME: is this correct?
    transform(NormalRef.begin(), NormalRef.end(), NormalRef.begin(), [&](double &a)
              { return (a / jac); });

    tensor<double, 1> NDbf_g(eNN); // Normal derivative
    NDbf_g(all) = NormalRef[0] * Dbf_g(all, 0) + NormalRef[1] * Dbf_g(all, 1) + NormalRef[2] * Dbf_g(all, 2);

    // Writing Gaussian point coordinates and normal unit vectors in the reference configuration to the file
    ofstream myFile;
    myFile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    myFile << std::setprecision(16) << coords(0) << " "
           << coords(1) << " "
           << coords(2) << " "
           << 1 << " "
           << NormalRef[0] << " "
           << NormalRef[1] << " "
           << NormalRef[2] << endl;
    myFile.close();

    //======================   Output  =============================//
    tensor<double, 2, false> Ak(fillStr->Ak(0, 0).data(), eNN, eNN);
    tensor<double, 1, false> Bk(fillStr->Bk(0).data(), eNN);
    Ak -= outer(NDbf_g, bf) * jac;
    Ak -= outer(bf, NDbf_g) * jac;
    Ak += lambda * outer(bf, bf) * jac;
    Bk -= u0 * NDbf_g * jac;
    Bk += lambda * u0 * bf * jac;

    ///============          Calculate Errors         ===================///
    tensor<double, 1> uFEM = product(nborDOFs, bf, {{0, 0}});
    double L2error = (u0 - uFEM(0)) * (u0 - uFEM(0)) * jac;
    fillStr->addToGlobalIntegral("L2E", L2error);
    fillStr->addToGlobalIntegral("BoundaryArea", jac);
}

double analyticalSolution(double x, double y, double z)
{
    double f{4};
    return (x * y * z + sin(M_PI * f * x) * sin(M_PI * f * y) * sin(M_PI * f * z));
    // return (x * x + y * y + z * z - x * y * z);
}

double bodyForce(double x, double y, double z)
{
    double f{4};
    return (3 * f * f * M_PI * M_PI * sin(M_PI * f * x) * sin(M_PI * f * y) * sin(M_PI * f * z));
    // return -6;
}
