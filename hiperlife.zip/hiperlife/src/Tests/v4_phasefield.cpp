/*
    **************************************************************************************************
    hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Copyright (c) 2018 Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
    **************************************************************************************************
    hiperlife is under GNU General Public License ("GPL").
    GNU General Public License ("GPL") copyright permissions statement:
    This file is part of hiperlife, hiperlife is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by the Free Software Foundation,
    either version 3 of the License, or (at your option) any later version.
    hiperlife is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along with this program.
    If not, see <http://www.gnu.org/licenses/>.
    **************************************************************************************************
*/


#include <iostream>
#include <mpi.h>

#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_ConsistencyCheck.h"

#include "hl_Math.h"


using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void CahnHilliard_constantMobility(RCP<FillStructure> fillStr)
{
    //Parameters
    double deltat   = fillStr->userStr->dparam[0];
    double mobility = fillStr->userStr->dparam[1];
    double epsilon2 = fillStr->userStr->dparam[2];

    //Rename variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int DOF   = subFill.numDOFs;
    int eNN   = subFill.eNN;
    int nDim  = subFill.nDim;
    int pDim  = subFill.pDim;
    double *xe_nodes  = subFill.nborCoords.data();
    double *ue_nodes  = subFill.nborDOFs.data();
    double *ue_nodes0 = subFill.nborDOFs0.data();

    //Shape functions and derivatives at Gauss points
    double jac;
    double* Na = subFill.nborBasisFunctions();
    vector<double> gNa(eNN*pDim), hNa(eNN*pDim*pDim), lapNa(eNN);
    GlobalBasisFunctions::hessians(gNa.data(), jac, hNa.data(), lapNa.data(), subFill);

    //Values at integration points
    vector<double> x(pDim), gphi(pDim);
    double phi{}, phin{}, lapphi{};
    Array::Fill(x.data(), pDim, 0.0);
    Array::Fill(gphi.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d] * Na[i];
        phi  += ue_nodes[DOF*i+0]  * Na[i];
        phin += ue_nodes0[DOF*i+0] * Na[i];

        //Gradients
        for (int d = 0; d < pDim; d++)
            gphi[d] += ue_nodes[DOF*i+0] * gNa[pDim*i+d];

        //Hessians
        for (int d = 0; d < pDim; d++)
            lapphi += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+d];
    }

    //Double well and derivatives
    double    W = (phi*phi)*(1.0-phi)*(1.0-phi)/4.0;
    double   dW = phi*(1.0-phi)*(1.0-2.0*phi)/2.0;
    double  ddW = (1.0-6.0*phi+6.0*phi*phi)/2.0;
    double dddW = (-1.0+2.0*phi)*3.0;

    //Fill
    for (int i = 0; i < eNN; i++)
    {
        //Gradient of basis function times gradient of phase-field variable
        double gNagphi{};
        for (int d = 0; d < pDim; d++)
            gNagphi += gNa[pDim*i+d]*gphi[d];

        for (int j = 0; j < eNN; j++)
        {
            //Product of the gradient of basis functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            //Fill Ak
            fillStr->Ak(0, 0)[i*eNN+j] += jac * Na[i] * Na[j] / deltat;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * dddW * Na[j] * gNagphi;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * ddW * gNagNb;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * epsilon2 * lapNa[i] * lapNa[j];
        }

        //Fill RHS
        fillStr->Bk(0)[i] += jac * Na[i] * (phi-phin) / deltat;
        fillStr->Bk(0)[i] += jac * mobility * ddW * gNagphi;
        fillStr->Bk(0)[i] += jac * mobility * epsilon2 * lapNa[i] * lapphi;
    }

    //Add to global integral
    fillStr->addToGlobalIntegral("ChemicalFreeEnergy", jac*W);
    fillStr->addToGlobalIntegral("SurfaceFreeEnergy", jac*0.5*epsilon2*Math::SNorm(pDim, gphi.data()));
    fillStr->addToGlobalIntegral("GinzburgLandauFreeEnergy", jac*(W + 0.5*epsilon2*Math::SNorm(pDim, gphi.data())));
    fillStr->addToGlobalIntegral("Mass", jac*phi);

    return;
}

void AllenCahn_constantMobility(RCP<FillStructure> fillStr)
{
    // Parameters
    double deltat   = fillStr->userStr->dparam[0];
    double mobility = fillStr->userStr->dparam[1];
    double epsilon2 = fillStr->userStr->dparam[2];

    // Rename variables
    SubFillStructure& subFill = (*fillStr)[0];
    int eNN   = subFill.eNN;
    int pDim  = subFill.pDim;
    double *nborDOFs  = subFill.nborDOFs.data();
    double *nborDOFs0 = subFill.nborDOFs0.data();

    // Shape functions and derivatives at Gauss points
    double jac;
    double* bf = subFill.nborBFs();
    vector<double> gbf(eNN*pDim);
    GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

    // Values at integration points
    double c{}, c0{};
    vector<double> gc(pDim);
    Array::Fill(gc.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        // Values
        c  += nborDOFs[i]  * bf[i];
        c0 += nborDOFs0[i] * bf[i];

        // Gradients
        for (int d = 0; d < pDim; d++)
            gc[d] += nborDOFs[i] * gbf[pDim*i+d];
    }

    //Double well and derivatives
    double    W = (c*c)*(1.0-c)*(1.0-c)/4.0;
    double   dW = c*(1.0-c)*(1.0-2.0*c)/2.0;
    double  ddW = (1.0-6.0*c+6.0*c*c)/2.0;
    double dddW = (-1.0+2.0*c)*3.0;

    // Fill
    for (int i = 0; i < eNN; i++)
    {
        // Gradient of basis function times gradient of phase-field variable
        double gbfgc{};
        for (int d = 0; d < pDim; d++)
            gbfgc += gbf[pDim*i+d]*gc[d];

        // Fill RHS
        fillStr->Bk(0)[i] += jac * bf[i] * (c-c0) / deltat;
        fillStr->Bk(0)[i] += jac * mobility * bf[i] * dW;
        fillStr->Bk(0)[i] += jac * mobility * epsilon2 * gbfgc;

        for (int j = 0; j < eNN; j++)
        {
            // Product of the gradient of basis functions
            double gbfgbf{};
            for (int d = 0; d < pDim; d++)
                gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

            // Fill Ak
            fillStr->Ak(0, 0)[i*eNN+j] += jac * bf[i] * bf[j] / deltat;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * bf[i] * ddW * bf[j];
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * epsilon2 * gbfgbf;
        }
    }

    double E = W + 0.5*epsilon2*Math::SNorm(pDim, gc.data());
    double D = 0.5*((c-c0)/deltat*(c-c0)/deltat);

    //Add to global integral
    fillStr->addToGlobalIntegral("ChemicalFreeEnergy", jac*W);
    fillStr->addToGlobalIntegral("SurfaceFreeEnergy", jac*0.5*epsilon2*Math::SNorm(pDim, gc.data()));
    fillStr->addToGlobalIntegral("GinzburgLandauFreeEnergy", jac*(W + 0.5*epsilon2*Math::SNorm(pDim, gc.data())));
    fillStr->addToGlobalIntegral("Ray", jac*(E/deltat + D));
    fillStr->addToGlobalIntegral("Mass", jac*c);

    return;
}

int main(int argc, char *argv[])
{
    //Initialize MPI
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    //Mesh parameters
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Line;
    int bfOrder = 1;
    int gPts = pow(bfOrder+1, computePDim(eType));
    int nEl = 100;

    //Model parameters
    double deltat   = 10.E0;
    double mobility = 1.0;
    double epsilon2 = 0.00005*10;

    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(3);
    userStr->dparam[0] = deltat;
    userStr->dparam[1] = mobility;
    userStr->dparam[2] = epsilon2;

    //Time parameters
    string oname = "CahnHilliard.";
    double maxTime  = 10000000;
    double maxNStep = 2;
    double maxDelt  = 10000000;
    double stepFactor = 0.95;
    int nSave = 1;

    //Generate mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genStructMesh(nEl);
    // structMesh->translateX(-0.5);
    // structMesh->scaleX(2.0);

    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->Update();
    disMesh->printFileLegacyVtk("Mesh");

    //DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"rho"});
    dhand->Update();

    //Initial and boundary conditions
    srand(1);
    for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
    {
        double r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        dhand->nodeDOFs0->setValue(0, i, IndexType::Local, 0.51+0.3*r*0);
        // double x = dhand->mesh->nodeCoord(i, 0, IndexType::Local);
        // dhand->nodeDOFs0->setValue(0, i, IndexType::Local, 0.5-0.5*tanh(10.0*(x-0.4)));
    }
    dhand->UpdateGhosts();

    //Create HiPerProblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setConsistencyDOFs("dhand", {"rho"});
    hiperProbl->setConsistencyCheckType(ConsistencyCheckType::Both, "Ray");
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->setElementFillings("Integ", ConsistencyCheck<AllenCahn_constantMobility>);
    hiperProbl->setGlobalIntegrals({"ChemicalFreeEnergy", "SurfaceFreeEnergy", "GinzburgLandauFreeEnergy", "Mass", "Ray"});
    hiperProbl->Update();

    // Linear solver
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    // linSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::SPD);
    // linSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Parallel);
    // linSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::PtScotch);
    linSolver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // Nonlinear solver
    RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp (new NewtonRaphsonNonlinearSolver());
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-7);
    nonlinSolver->setSolTolerance(1.E-7);
    // nonlinSolver->setLineSearch(true);
    // nonlinSolver->setLineSearchEnergyMethod("Ray");
    // nonlinSolver->setLineSearch_step(0.95);
    // nonlinSolver->setLineSearch_minDecrease(0.000001);
    nonlinSolver->setExitRelMaximum(true);
    nonlinSolver->setResMaximum(1e7);
    nonlinSolver->setSolMaximum(1e7);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    //Print initial condition
    dhand->nodeDOFs->setValue(dhand->nodeDOFs0);
    dhand->printFileLegacyVtk(oname + to_string(0), false);
    dhand->printFile(oname + to_string(0), OutputMode::Text, true, 0.0, hiperProbl->globalIntegrals());

    //Open file to write global integrals and write headers
    ofstream gIntegFile;
    gIntegFile.open ("globalIntegrals.csv");
    gIntegFile << "TS time deltat";
    for (auto g: hiperProbl->globalIntegralNames())
        gIntegFile << " " << g;
    gIntegFile << endl;

    //Loop over time steps
    double time{0.0};
    int timeStep{0};
    double ener_prev{1.E8};
    hiperProbl->FillLinearSystem();
    ener_prev = hiperProbl->globalIntegral("GinzburgLandauFreeEnergy");
    while ((timeStep < maxNStep) && (time < maxTime))
    {
        //Write
        if (dhand->myRank() == 0)
            cout << endl << " TS: " << to_string(timeStep) << " Time " << time <<  " Delta " << deltat << endl;

        //Initial guess
        dhand->nodeDOFs->setValue(dhand->nodeDOFs0);
        hiperProbl->UpdateGhosts();

        //Newton-Raphson method
        int ierr = nonlinSolver->solve();

        if (myRank == 0)
            cout << "    Energies: " << ener_prev << " " << hiperProbl->globalIntegral("GinzburgLandauFreeEnergy") << endl;

        //Check convergence
        if (ierr != 0 and hiperProbl->globalIntegral("GinzburgLandauFreeEnergy") <= ener_prev)
        {
            //Save solution
            dhand->nodeDOFs0->setValue(dhand->nodeDOFs);

            //Update variables
            timeStep ++;
            if (deltat > maxDelt)
                deltat = maxDelt;
            deltat /= stepFactor;
            if (deltat >= maxDelt)
                deltat = maxDelt;
            time += deltat;
            ener_prev = hiperProbl->globalIntegral(2);

            //Write results
            if (timeStep % nSave == 0)
            {
                string solName = oname + to_string(timeStep);
                dhand->printFileLegacyVtk(solName, false);
                dhand->printFile(solName, OutputMode::Text, true, time, hiperProbl->globalIntegrals());
            }

            //Write global integrals
            if (myRank == 0)
            {
                gIntegFile << timeStep << " " << time << " " << deltat;
                for (auto g: hiperProbl->globalIntegrals())
                    gIntegFile  << " " << g;
                gIntegFile << endl;
            }
        }
        else
        {
            // Print
            if (myRank == 0)
                cout << "  * Repeat time step" << endl;

            //Correct time-step size
            deltat *= stepFactor;
        }

        //Save value of delta
        userStr->dparam[0] = deltat;

        //Check steady-state
        if (deltat < 1.e-14)
            break;
    }

    //Close file
    gIntegFile.close();

    //Finalize
    MPI_Finalize();
    return 0;
}
