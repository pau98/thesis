#include <thread>

#include "hl_Core.h"
#include "hl_Timer.h"

int main(int argc, char** argv)
{
    using namespace std;

    hiperlife::Init(argc, argv);

    for (int i = 0; i < 4; i++)
    {
        hiperlife::timer::start("timer1");
        this_thread::sleep_for(chrono::seconds(2));
        hiperlife::timer::stop("timer1");
    }

    hiperlife::timer::start("timer2");
    this_thread::sleep_for(chrono::seconds(5));
    hiperlife::timer::stop("timer2");

    hiperlife::timer::output();

    assert(abs(hiperlife::timer::getTime("timer1") - 8.0) < 1e-1);
    assert(abs(hiperlife::timer::getTime("timer2") - 5.0) < 1e-1);

    hiperlife::Finalize();

}