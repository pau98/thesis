
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_MeshLoader.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Iterative_Belos.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

int main()
{
    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);

    BasisFuncType bfType = BasisFuncType::Nurbs;
    ElemType eType = ElemType::Square;
    int bfOrder = 7;
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genStructMesh(30);

    ///===========             Distribute mesh            ===========///
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setVerbosity(Verbosity::High);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    disMesh->printFileVtk("output_mesh");
    
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setDOFs({"x","y","z"});
    dofHand->setElemAuxF({"a", "b"});
    dofHand->Update();

    dofHand->setInitialCondition("x",[](double x, double y, double z){ return x*y;});
    dofHand->setInitialCondition("y",[](double x, double y, double z){ return y;});
    dofHand->setInitialCondition("z",[](double x, double y, double z){ return -x;});
    dofHand->elemAuxF->setValue("a", 1.0);
    dofHand->elemAuxF->setValue("b", 1.0);
    dofHand->UpdateGhosts();


    // dofHand->printFileVtk("output", true, 10.0, {1.0, 2.0}, {"glob1", "glob2"});
    dofHand->printFileVtk("output", true, 10.0);

    MPI_Finalize();

    return 0;
}
