/// C++ headers
#include <iostream>
#include <mpi.h>
// #include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <AztecOO.h>
#include <AztecOO_ConditionNumber.h>
#include <Teuchos_CommandLineProcessor.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_SurfLagrParam.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


void LS(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    vector<double>& ue_nodes  = subFill.nborDOFs;
    double* Na   = subFill.nborBFsDers(0);  // Local shape function
    double* glNa = subFill.nborBFsDers(1); // Local shape function derivatives
    double* hlNa = subFill.nborBFsDers(2); // Local shape function second derivatives
    double hNa[eNN*pDim*pDim], gNa[eNN*pDim], jac, lapNa[eNN];
    GlobalBasisFunctions::hessians(gNa, jac, hNa, lapNa, subFill);

    vector<double> x(pDim);
    double phi{};
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d] * Na[i];

        for (int d = 0; d < pDim; d++)
            phi += ue_nodes[DOF*i+d] * Na[i];
    }

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * lapNa[i]*lapNa[j];
        }

        /// Fill RHS
        // fillStr->Bk(0)[i*DOF] += jac * Na[i] * sin(M_PI*x[0])*sin(M_PI*x[1]);
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * sin(M_PI*x[0]);
    }

    if (subFill.elemID < 4)
    {
        cout << x[0] << " ";
        for (int i = 0; i < eNN; i++)
            cout << Na[i] << " ";
        for (int i = 0; i < eNN; i++)
            cout << gNa[i] << " ";
        for (int i = 0; i < eNN; i++)
            cout << hNa[i] << " ";
        cout << endl;
    }

    // double val = phi - sin(M_PI*x[0])*sin(M_PI*x[1])/M_PI/M_PI/M_PI/M_PI/4.0;
    double val = phi - sin(M_PI*x[0])/M_PI/M_PI/M_PI/M_PI;
    val *= val;


    fillStr->addToGlobalIntegral("Area", jac*val);

    return;
}

void LS_fit(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    vector<double>& ue_nodes  = subFill.nborDOFs;
    double* Na   = subFill.nborBFsDers(0);  // Local shape function
    double* glNa = subFill.nborBFsDers(1); // Local shape function derivatives
    double* hlNa = subFill.nborBFsDers(2); // Local shape function second derivatives
    double hNa[eNN*pDim*pDim], gNa[eNN*pDim], jac, lapNa[eNN];
    GlobalBasisFunctions::hessians(gNa, jac, hNa, lapNa, subFill);

    vector<double> x(pDim);
    double phi{};
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d] * Na[i];

        for (int d = 0; d < pDim; d++)
            phi += ue_nodes[DOF*i+d] * Na[i];
    }

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * Na[i]*Na[j];
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * (sin(M_PI*x[0])*sin(M_PI*x[1])/M_PI/M_PI/M_PI/M_PI/4.0);
    }


    double val = phi - sin(M_PI*x[0])*sin(M_PI*x[1])/M_PI/M_PI/M_PI/M_PI/4.0;
    val *= val;

    fillStr->addToGlobalIntegral("Area", jac*val);


    return;
}


int main(int argc, char *argv[])
{

    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);

    Teuchos::CommandLineProcessor parser;
    parser.setDocString("Get options from the command-line and print this help message automatically.\n");
    int nx{10};
    parser.setOption("nx", &nx, "nx.");
    Teuchos::CommandLineProcessor::EParseCommandLineReturn parseReturn= parser.parse(argc, argv);
    if (parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED)
        return 0;
    if (parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL)
        return 1;

    ///=============== Define parameters of the model ===============///
    double force = 0.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;

    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//


    ///====================== Mesh generation ======================///
    ///
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Line;
    int bfOrder = 2;
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genStructMesh(nx);
    structMesh->stretchElemsSymmetric(1.2);

    int iPts{};
    if (eType == ElemType::Line)
        iPts = 10;
    else if (eType == ElemType::Triang)
        iPts = 12;
    else if (eType == ElemType::Square)
        iPts = 9;
    else
        throw runtime_error("Check gauss points");

    ///===========             Distribute mesh            ===========///
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//
    /// **************************************************************//

    ///===========           Create DOFHandler            ===========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    ///===========          Boundary conditions          ===========///
    dofHand->setBoundaryCondition(0.0);
    // dofHand->setInitialCondition(0, [](double x){return x*x;});
    // dofHand->setBoundaryCondition(0, MAxis::Xmin, 1.0);
    // dofHand->setBoundaryCondition(0, MAxis::Xmax, 0.0);
    // dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x){return x;});
    // dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});

    // for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    // {
    //     double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
    //     double y = dofHand->mesh->nodeCoord(i, 1, IndexType::Local);
    //     double z = dofHand->mesh->nodeCoord(i, 2, IndexType::Local);
    //     // cout << x*x << endl;
    //     // if (x > 0.9)
    //     //     dofHand->setConstraint(0, i, IndexType::Local, 1.0);
    //     // if (x < 0.1)
    //     //     dofHand->setConstraint(0, i, IndexType::Local, 0.0);
    //     // dofHand->nodeAuxF->setValue(0, i, IndexType::Local, x);
    // }
    dofHand->UpdateGhosts();
    dofHand->printFileLegacyVtk("Initial");


    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hp_fit = rcp(new HiPerProblem);
    hp_fit->setUserStructure(userStr);
    hp_fit->setDOFsHandlers({dofHand});

    hp_fit->setIntegration("Integ", {"dofHand"});
    hp_fit->setElementFillings("Integ", LS);
    hp_fit->setCubatureGauss("Integ", iPts);

    hp_fit->setGlobalIntegrals({"Area"});
    hp_fit->Update();



    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
    // RCP<AztecOOIterativeLinearSolver> solver_fit = rcp (new AztecOOIterativeLinearSolver());
    // solver_fit->setHiPerProblem(hp_fit);
    // solver_fit->setSolver(AztecOOIterativeLinearSolver::Solver::ConjGrad);
    // solver_fit->setPrecond(AztecOOIterativeLinearSolver::Precond::Jacobi);
    // // solver_fit->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::ilut);
    // solver_fit->setTolerance(1.E-8);
    // solver_fit->setMaxNumIterations(500);
    // solver_fit->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver_fit->Update();

    RCP<AmesosDirectLinearSolver> solver_fit = rcp (new AmesosDirectLinearSolver());
    solver_fit->setHiPerProblem(hp_fit);
    solver_fit->setSolver(AmesosDirectLinearSolver::Solver::Klu);
    solver_fit->setMatrixType(AmesosDirectLinearSolver::MatrixType::General);
    solver_fit->setUseTranspose(false);
    solver_fit->setScaleMethod(true);
    solver_fit->setRefactorize(false);
    solver_fit->setNumericFactorization(true);
    solver_fit->setSymbolicFactorization(true);
    solver_fit->setVerbosity(AmesosDirectLinearSolver::Verbosity::High);
    solver_fit->Update();

    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//

    hp_fit->FillLinearSystem();
    solver_fit->solve();
    solver_fit->UpdateSolution();
    dofHand->printFileLegacyVtk("Biharmonic_fit", true);

    cout << "Area " << hp_fit->globalIntegral("Area_total") << endl;

    hp_fit->FillLinearSystem();

    cout << "Area " << hp_fit->globalIntegral("Area_total") << endl;



    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}
