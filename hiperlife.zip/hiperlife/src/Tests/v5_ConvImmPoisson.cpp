/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>
#include <set>
#include <unordered_map>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"


// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct PoissonParams
{
  enum RealParameters
  {
    beta,
    k0,
    k1,
    gGP1,
    gGP2
  };

  enum IntParameters
  {
    timeStep,
    testN,
  };

  enum BoolParameters
  {
    ghP,
  };

  HL_PARAMETER_LIST DefaultValues
  {
    {"beta", 100.0},
    {"timeStep",0},
    {"k0",10.},
    {"k1",1.},
    {"testN",-1},
    {"ghP",false},
    {"gGP1",0.1},
    {"gGP2",0.01}
  };
};

bool fileExists(const std::string& filename)
{
  struct stat buf;
  if (stat(filename.c_str(), &buf) != -1)
  {
    return true;
  }
  return false;
}

struct Params {
  double rx, ry, k0, k1, wpTh, beta, ghP, gp1, gp2, levels;
};

Params parseArgs(int argc, char* argv[]) {
  std::unordered_map<std::string, std::string> args;
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg.rfind("--", 0) == 0 && i + 1 < argc) {
      args[arg.substr(2)] = argv[++i];
    }
  }

  auto get = [&](const std::string& key,double defVal) -> double {
    auto it = args.find(key);
    if (it == args.end()) {
      cout << "Using default for --" + key<<endl;
      return defVal;
    }
    try {
      return std::stod(it->second);
    } catch (...) {
      throw std::runtime_error("Invalid value for --" + key + ": '" + it->second + "'");
    }
  };

  return Params{
    get("rx",0.5),
    get("ry",0.5),
    get("k0",1.),
    get("k1",1000.),
    get("wpTh",0.2),
    get("beta",-1.),
    get("ghP",0.),
    get("gp1",0.1),
    get("gp2",0.01),
    get("levels",5)
  };
}


std::string buildFilename(const Params& p)
{
  std::ostringstream oss;
  oss << "_rx" << std::fixed << std::setprecision(3) << p.rx
    << "_ry" << std::fixed << std::setprecision(3) << p.ry
    << "_k0" << std::fixed << std::setprecision(3) << p.k0
    << "_k1" << std::fixed << std::setprecision(3) << p.k1
    << "_wpTh" << std::fixed << std::setprecision(3) << p.wpTh
    << "_beta" << std::fixed << std::setprecision(3) << p.beta;
  return oss.str();
}

// ─── helper: find adjacent element pairs ────────────────────────────────────

std::vector<std::pair<int,int>> findBorderAdjacentPairs(
  Teuchos::RCP<hiperlife::DOFsHandler> dhand, int p, int rInt)
{
  using namespace hiperlife;

  auto mesh = dhand->mesh;
  vector<string> rTags = mesh->_regionTags();
  // if (std::find(rTags.begin(), rTags.end(), rTag) == rTags.end())
  //   throw runtime_error("findBorderAdjacentPairs: The provided region name could not be found");
  vector<int> rPrimes = {3,5,7,11};

  // Corner local-node indices per side of a Q_p square element:
  //   Side 0 (v=-1): nodes 0    and p
  //   Side 1 (u=+1): nodes p    and p*(p+2)
  //   Side 2 (v=+1): nodes p*(p+2) and p*(p+1)
  //   Side 3 (u=-1): nodes p*(p+1) and 0
  const std::array<std::array<int,2>,4> sideCorners = {{
    {0,     p    },
    {p,     p*(p+2)  },
    {p*(p+2), p*(p+1)  },
    {p*(p+1), 0    }
  }};
  
  dhand->elemAuxF->setValue("GhP"+to_string(rInt),1);

  std::unordered_map<int, std::vector<int>> nodeToElems;
  for (int e = 0; e < mesh->loc_nElem(); e++)
  {
    int eNN = mesh->_adjcyEN->getNumNbors(e, IndexType::Local);
    for (int i = 0; i < eNN; i++)
    {
      int gn = mesh->_adjcyEN->getNbor(e, i, IndexType::Global);
      nodeToElems[gn].push_back(e);
    }
  }

  int offs = mesh->offs_nElem();
  std::set<std::pair<int,int>> seen;
  std::vector<std::pair<int,int>> result;

  for (int e1 = 0; e1 < mesh->loc_nElem(); e1++)
  {
    if((int)dhand->elemAuxF->getValue(0,e1)%2 == 0)
    {
      int sCount = 0;
      for (auto& sc : sideCorners)
      {
        int gA = mesh->_adjcyEN->getNbor(e1, sc[0], IndexType::Global);
        int gB = mesh->_adjcyEN->getNbor(e1, sc[1], IndexType::Global);

        const auto& eA = nodeToElems[gA];
        const auto& eB = nodeToElems[gB];

        for (int e2 : eA)
        {
          if (e2 == e1) continue;
          if (std::find(eB.begin(), eB.end(), e2) == eB.end()) continue;
          if ((int)dhand->elemAuxF->getValue(0,e2)%rPrimes[rInt] != 0) continue;
          int g1 = e1 + offs, g2 = e2 + offs;
          auto key = std::make_pair(std::min(g1,g2), std::max(g1,g2));
          if (seen.insert(key).second)
          {
            result.push_back(key);
            double e1Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e1,IndexType::Global);
            if ((int)e1Val%rPrimes[sCount] != 0)
              dhand->elemAuxF->setValue("GhP"+to_string(rInt),e1,IndexType::Global,e1Val*rPrimes[sCount]);
            double e2Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e2,IndexType::Global);
            if ((int)e2Val%rPrimes[(sCount+2)%4] != 0)
              dhand->elemAuxF->setValue("GhP"+to_string(rInt),e2,IndexType::Global,e2Val*rPrimes[(sCount+2)%4]);
          }
        }
        sCount++;
      }
    }
  }
  return result;
}

void LS_backBulk0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;

  //============      Initialize variables       ===========//
  SubFillStructure& subFill = fillStr["backDHand"];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  tensor<double,2> Dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);
  int nS = fillStr.getIntParameter(PoissonParams::timeStep);
  double k0 = fillStr.getRealParameter(PoissonParams::k0);
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  ///===================== Values at int. points ====================///
  vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf[i];
  }

  // ofstream myfile;
  // myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
  // myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << endl;
  // myfile.close();


  ///=====================  Fill linear system =====================///
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
  Ak *=0;
  Bk *=0;
  double f = 2.*M_PI*M_PI*k0*cos(M_PI*x[0])*sin(M_PI*x[1]);

  for (int i = 0; i < eNN; i++)
  {
    Bk(i,0) += jac * bf[i]* f;

    for (int j = 0; j < eNN; j++)
    {
      /// Fill matrix
      Ak(i,0,j,0) += jac * k0 * Dbf(i,ttl::all)*Dbf(j,ttl::all);
    }
  }

  // Save local area
  fillStr.addToGlobalIntegral("Area", jac);
  // Output integration points
  // if (subFill.dhandDHand->nameTag() == "backDHand")
  // {
  //   ofstream myfile;
  //   if (!fileExists("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv"))
  //   {
  //     myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
  //     myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
  //     myfile.close();
  //   }
  //   myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
  //   myfile << std::setprecision(16) << x[0] << "," << x[1] << "," << jac << endl;
  //   myfile.close();
  // }
  return;
}

void LS_backBulk1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;

  //============      Initialize variables       ===========//
  SubFillStructure& subFill = fillStr["backDHand"];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  tensor<double,2> Dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);
  int nS = fillStr.getIntParameter(PoissonParams::timeStep);
  double k0 = fillStr.getRealParameter(PoissonParams::k0);
  double k1 = fillStr.getRealParameter(PoissonParams::k1);
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  ///===================== Values at int. points ====================///
  vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf[i];
  }

  // ofstream myfile;
  // myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
  // myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << endl;
  // myfile.close();


  ///=====================  Fill linear system =====================///
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
  Ak *=0;
  Bk *=0;
  double f = 2.*M_PI*M_PI*k0*cos(M_PI*x[0])*sin(M_PI*x[1]);

  for (int i = 0; i < eNN; i++)
  {
    Bk(i,1) += jac * bf[i]* f;

    for (int j = 0; j < eNN; j++)
    {
      /// Fill matrix
      Ak(i,1,j,1) += jac * k1 * Dbf(i,ttl::all)*Dbf(j,ttl::all);
    }
  }

  // Save local area
  fillStr.addToGlobalIntegral("Area", jac);
  // Output integration points
  // if (subFill.dhandDHand->nameTag() == "backDHand")
  // {
  //   ofstream myfile;
  //   if (!fileExists("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv"))
  //   {
  //     myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
  //     myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
  //     myfile.close();
  //   }
  //   myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
  //   myfile << std::setprecision(16) << x[0] << "," << x[1] << "," << jac << endl;
  //   myfile.close();
  // }
  return;
}

void LS_backBorder(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;

  //============      Initialize variables       ===========//
  // Parameters
  double beta = fillStr.getRealParameter(PoissonParams::beta);
  int nS = fillStr.getIntParameter(PoissonParams::timeStep);
  double k0 = fillStr.getRealParameter(PoissonParams::k0);
  double k1 = fillStr.getRealParameter(PoissonParams::k1);
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  // Background
  SubFillStructure& subFill = fillStr["backDHand"];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives

  // ===================== Values at int. points ==================== //
  // Compute jacobian
  vector<double> dbf(eNN*pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

  // Get tangent to immersed mesh at integration point
  auto immMesh = subFill.dhandDHand->mesh->_childMesh;
  vector<double> t(3);
  for (int n = 0; n < nDim; n++)
    t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
  jac = Math::Norm3D(t.data());

  // Compute unitary normal
  vector<double> n(3, 0.0);
  n[0] = -t[1]/jac;
  n[1] = -(-t[0])/jac;

  // Compute coordinates using the back mesh
  vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf[i];
  }


  // ofstream myfile;
  // myfile.open("cubatureImm2."+to_string(nS)+".csv", std::ios_base::app);
  // // myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
  // // myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
  // myfile << std::setprecision(16) << std::setprecision(16) << x[0] << " " << x[1] << " " << " " << n[0] << " " << n[1] << " " << t[0] << " " << t[1] << endl;
  // myfile.close();

  // Obtain Nitsche parameter from each side
  double C02 = subFill.dhandDHand->elemAuxF->getValue("l0",subFill.elemID);
  double C12 = subFill.dhandDHand->elemAuxF->getValue("l1",subFill.elemID);
  
  double gmm0 = sqrt(C12)/(sqrt(C12)+sqrt(C02));
  double gmm1 = 1.-gmm0;

  double C2 = gmm0*gmm0*C02;
  subFill.dhandDHand->elemAuxF->setValue("lE",subFill.elemID,IndexType::Local,C2);
  subFill.dhandDHand->elemAuxF->setValue("gmm0",subFill.elemID,IndexType::Local,gmm0);
  beta = 5.*C2;
  // gmm0 = k1/(k1+k0);
  // gmm1 = k0/(k1+k0);
  if (fillStr.getRealParameter(PoissonParams::beta)>0)
  {
    beta = fillStr.getRealParameter(PoissonParams::beta);
    // // beta *= 2*k0*k1/(k0+k1);
    // Diffusivity-weighted average, as in CheckNitsche
    gmm0 = k1/(k1+k0);
  }
  gmm1 = 1-gmm0;
  // =====================  Fill linear system ===================== //
  double gD = (1.-k0/k1)*cos(M_PI*x[0])*sin(M_PI*x[1]);//(x[0]-0.5)*(x[0]-0.5)+(x[1]-0.5)*(x[1]-0.5);
  if (testN == 1)
    gD = 0.;
  // cout << gD << " " << x[0] <<  " " << x[1] <<endl;
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);
  Ak *= 0;
  Bk *= 0;
  // cout << gD << endl;

  // Nitsche symmetric
  if (true)
  {
    for (int i = 0; i < eNN; i++)
    {
      double dbfnI{};
      for (int d = 0; d < pDim; d++)
        dbfnI += dbf[pDim*i+d]*n[d];

      Bk(i,0) += jac * beta * bf[i] * gD;
      Bk(i,1) -= jac * beta * bf[i] * gD;
      Bk(i,0) -= jac * gmm0 * k0 * dbfnI * gD;
      Bk(i,1) -= jac * gmm1 * k1 * dbfnI * gD;

      for (int j = 0; j < eNN; j++)
      {
        double dbfnJ{};
        for (int d = 0; d < pDim; d++)
          dbfnJ += dbf[pDim*j+d]*n[d];

        // Fill 00 matrix
        Ak(i,0,j,0) += jac * beta * bf[i] * bf[j];
        Ak(i,0,j,0) -= gmm0 * jac * bf[i] * k0 * dbfnJ;
        Ak(i,0,j,0) -= gmm0 * jac * k0 * dbfnI * bf[j];

        // Fill 01 matrix
        Ak(i,0,j,1) -= jac * beta * bf[i] * bf[j];
        Ak(i,0,j,1) -= gmm1 * jac * bf[i] * k1 * dbfnJ;
        Ak(i,0,j,1) += gmm0 * jac * k0 * dbfnI * bf[j];
        
        // Fill 10 matrix
        Ak(i,1,j,0) -= jac * beta * bf[i] * bf[j];
        Ak(i,1,j,0) += gmm0 * jac * bf[i] * k0 * dbfnJ;
        Ak(i,1,j,0) -= gmm1 * jac * k1 * dbfnI * bf[j];

        // Fill 11 matrix
        Ak(i,1,j,1) += jac * beta * bf[i] * bf[j];
        Ak(i,1,j,1) += gmm1 * jac * bf[i] * k1 * dbfnJ;
        Ak(i,1,j,1) += gmm1 * jac * k1 * dbfnI * bf[j];
      }
    }
  }
  // Save local length
  fillStr.addToGlobalIntegral("Length", jac);

  return;
}

void CheckSolution0(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  const double u_numeric = dofsI(N,0) * bf(N);
  double u_analytial = cos(M_PI*x(0))*sin(M_PI*x(1));//(x(0)-0.5)*(x(0)-0.5)+(x(1)-0.5)*(x(1)-0.5);

  const double error = jac * (u_numeric-u_analytial)*(u_numeric-u_analytial);
  fillStr.addToGlobalIntegral("error0", error);
}

void CheckSolution1(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;
  int testN = fillStr.getIntParameter(PoissonParams::testN);
  double k0 = fillStr.getRealParameter(PoissonParams::k0);
  double k1 = fillStr.getRealParameter(PoissonParams::k1);

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  const double u_numeric = dofsI(N,1) * bf(N);
  double u_analytial = k0/k1*cos(M_PI*x(0))*sin(M_PI*x(1));//(x(0)-0.5)*(x(0)-0.5)+(x(1)-0.5)*(x(1)-0.5);
  const double error = jac *(u_numeric-u_analytial)*(u_numeric-u_analytial);
  fillStr.addToGlobalIntegral("error1", error);
}

// Optional per-integration-point dump of the interface fluxes, opened in main
// around checkSolution->FillLinearSystem() (serial only).
static std::ofstream* gFluxCSV = nullptr;

void CheckNitsche(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;
  double k0 = fillStr.getRealParameter(PoissonParams::k0);
  double k1 = fillStr.getRealParameter(PoissonParams::k1);
  double testN = fillStr.getRealParameter(PoissonParams::testN);
  //============      Initialize variables       ===========//

  // Background
  SubFillStructure &subFill = fillStr[0];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  ttl::wrapper<double, 1> bft(subFill.nborBFs(), eNN);

  // ===================== Values at int. points ==================== //
  // Compute jacobian
  tensor<double,2> dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf, jac, subFill);

  // Get tangent to immersed mesh at integration point
  auto immMesh = subFill.dhandDHand->mesh->_childMesh;
  vector<double> t(3);
  for (int n = 0; n < nDim; n++)
    t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
  jac = Math::Norm3D(t.data());

  // Compute unitary normal
  tensor<double,1> n(2);
  n(0) = -t[1]/jac;
  n(1) = -(-t[0])/jac;

  // Compute coordinates using the back mesh
  vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf[i];
  }
  ttl::wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOF);
  const double u0 = dofsI(N,0) * bft(N);
  const double u1 = dofsI(N,1) * bft(N);
  tensor<double,1> du0 = k0*dofsI(N,0) * dbf(N,i);
  tensor<double,1> du1 = k1*dofsI(N,1) * dbf(N,i);
  double gD = (1.-k0/k1)*cos(M_PI*x[0])*sin(M_PI*x[1]);//(x[0]-0.5)*(x[0]-0.5)+(x[1]-0.5)*(x[1]-0.5);
  // if (testN == 1)
  //   gD = 0.;
  
  // beta = 5*C;
  double gmm0 = subFill.dhandDHand->elemAuxF->getValue("gmm0",subFill.elemID,IndexType::Local);
  double gmm1 = 1. - gmm0;
  if (fillStr.getRealParameter(PoissonParams::beta)>0)
  {
    gmm0 = k1/(k1+k0);
    gmm1 = k0/(k1+k0);
  }

  // double beta = fillStr.getRealParameter(PoissonParams::beta);
  // beta *= 2*k0*k1/(k0+k1);
  double tu = du0*gmm0*n+du1*gmm1*n;//-beta*(u0-u1-gD);
  double tAn = M_PI*k0*(-sin(M_PI*x[0])*sin(M_PI*x[1])*n(0)+cos(M_PI*x[0])*cos(M_PI*x[1])*n(1));

  // Save local length
  // cout << u0-u1 << " "<< gD << u0-u1-gD << endl;
  fillStr.addToGlobalIntegral("uErr", jac*(u0-u1-gD)*(u0-u1-gD));
  fillStr.addToGlobalIntegral("duErr", jac*(du0*n-du1*n)*(du0*n-du1*n));
  // fillStr.addToGlobalIntegral("duErr", jac*(du0*n-tAn)*(du0*n-tAn));
  fillStr.addToGlobalIntegral("tErr", jac*(tu-tAn)*(tu-tAn));
  double t0 = du0*n;  // kappa0 * grad(u0) * n
  double t1 = du1*n;  // kappa1 * grad(u1) * n
  if (gFluxCSV)
  {
    // Same measure addToGlobalIntegral uses: sum(dGamma*f^2) reproduces the global errors
    double dGamma = subFill._jacobianParentElementToParameterSpace(subFill.loc_elemID)
                    * subFill.wk_sample * jac;
    (*gFluxCSV) << subFill.elemID << "," << subFill.loc_elemID << "," << subFill.kPt << ","
                << dGamma << ","
                << x[0] << "," << x[1] << "," << n(0) << "," << n(1) << ","
                << t0 << "," << t1 << "," << t0 - t1 << ","
                << tu << "," << tAn << "," << tu - tAn << ","
                << u0 - u1 - gD << "\n";
  }
  return;
}

void LSPre(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace hiperlife::Tensor;

  SubFillStructure& subFill = fillStr["preDhand"];

  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int numAuxF  = subFill.numAuxF;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  ttl::wrapper<double,2> nborAuxF(subFill.nborAuxF.data(), eNN, numAuxF);

  std::vector<double> b0 = {-1};
  std::vector<std::vector<double>>& pbf0 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b0, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

  std::vector<double> bf1 ={pbf0[0][0],pbf0[0][1],pbf0[0][2],pbf0[0][3]}; 
  std::vector<double> b1 = {1};
  std::vector<std::vector<double>>& pbf1 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b1, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

  std::vector<double> bf2 ={pbf1[0][0],pbf1[0][1],pbf1[0][2],pbf1[0][3]}; 

  // Get output
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  Bk(1,0) = nborAuxF(1,0);
  Bk(1,1) = nborAuxF(1,1);
  Bk(2,0) = nborAuxF(2,0);
  Bk(2,1) = nborAuxF(2,1);
  for (int a = 0; a<eNN; a++)
  {
    Ak(a,0,1,0) = bf1[a];
    Ak(a,1,1,1) = bf1[a];

    Ak(a,0,2,0) = bf2[a];
    Ak(a,1,2,1) = bf2[a];
  }
}

void genCircBspline(double r, std::vector<double> &U,std::vector<std::vector<std::vector<std::vector<double>>>> &CP, double xOff, double yOff, ElemType eTypeB,BasisFuncType bTypeB,int bfOrderB,int nPtsCircOr,SmartPtr<ParamStructure> paramStr)
{
  // Compute immersed mesh CPs position
  SmartPtr<StructMeshGenerator> preBSMesh = Create<StructMeshGenerator>();

  preBSMesh->setMesh(eTypeB, bTypeB, bfOrderB);
  
  std::vector<double> preU(nPtsCircOr+1,0);
  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
  preU[i] = preU[i-1]+1;
  }
  
  std::vector<std::vector<std::vector<std::vector<double>>>> preCP(nPtsCircOr, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
  for (int k = 0;  k < nPtsCircOr; k++)
  {
  double t = 2*M_PI*k/nPtsCircOr;
  preCP[k][0][0] = {std::cos(t),std::sin(t),0,0};
  }
  
  preBSMesh->genBsplinesClosedCurve(preU,preCP);
  // Distributed mesh
  SmartPtr<DistributedMesh> preDisBSMesh = Create<DistributedMesh>("preDisBSMesh");
  preDisBSMesh->setMesh(preBSMesh);
  preDisBSMesh->setBalanceMesh(true);
  preDisBSMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
  preDisBSMesh->setVerbosity(Verbosity::None);
  preDisBSMesh->Update();
  
  // Set Degree of Freedom handler
  SmartPtr<DOFsHandler> preDhand = Create<DOFsHandler>(preDisBSMesh);
  preDhand->setNameTag("preDhand");
  preDhand->setNumDOFs(2);
  preDhand->setDOFs({"pcx","pcy"});
  preDhand->setNodeAuxF({"x","y","dxdt","dydt"});
  preDhand->Update();


  std::vector<double> cw = {1};
  for (int i = 0; i<preDisBSMesh->nPts();i++)
  {
  double t = 2.*M_PI*double(i)/double(nPtsCircOr);
  double x = xOff;
  double y = yOff;
  for (int iw = 0; iw<cw.size(); iw++)
  {
    x += cw[iw]*cos((iw+1)*t)*r;
    y += cw[iw]*sin((iw+1)*t)*r;
  }
  preDhand->nodeAuxF->setValue(0,i,IndexType::Global,x);
  preDhand->nodeAuxF->setValue(1,i,IndexType::Global,y);
  }

  SmartPtr<HiPerProblem> preHiperProbl = Create<HiPerProblem>();
  preHiperProbl->setParameterStructure(paramStr);
  preHiperProbl->setDOFsHandlers({preDhand});
  
  // Interface integration
  preHiperProbl->setIntegration("IntegPre", {"preDhand"});
  preHiperProbl->setCubatureGauss("IntegPre", 1);
  preHiperProbl->setElementFillings("IntegPre", LSPre);

  preHiperProbl->Update();

  SmartPtr<MUMPSDirectLinearSolver> preSolver = Create<MUMPSDirectLinearSolver>();
  preSolver->setHiPerProblem(preHiperProbl);
  preSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
  preSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
  preSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Sequential);
  preSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
  preSolver->setConvergenceCriteria(MUMPSDirectLinearSolver::ConvergenceCriteria::Relative);
  preSolver->setTolerance(1e-8);
  preSolver->setDefaultParameters();
  preSolver->Update();

  // Solve
  preSolver->solve();
  preHiperProbl->UpdateGhosts();

  // Update Solution
  preSolver->UpdateSolution();

  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
  U[i] = U[i-1]+1.;
  }

  for (int k = 0;  k < nPtsCircOr; k++)
  {  
  double x = preDhand->nodeDOFs->getValue(0,k,IndexType::Global);
  double y = preDhand->nodeDOFs->getValue(1,k,IndexType::Global);
  CP[k][0][0] = {x,y,0,0};
  }
}

// Largest lambda of A x = lambda B x (A: boundary flux term of K, B: patch
// bulk stiffness), robust to the near-singular directions of B:
//  1. Jacobi scaling D = diag(B)^-1/2, so the null-space threshold below is
//     relative to each DOF's own bulk control (cut fraction / element size
//     no longer spread the spectrum of B over many orders of magnitude).
//  2. The null modes Rm (columns, unscaled; constants for Poisson) are
//     projected out explicitly: there both A and B vanish (0/0).
//  3. On the remaining space B is reduced to its eigenvalues > relTol*max and
//     the problem becomes the symmetric Lambda^-1/2 V^T A V Lambda^-1/2:
//     no Cholesky, deterministic, exact for the reduced problem.
// Returns 0 if B has no range left. nUncontrolled counts DOFs that A sees but
// B does not (no bulk control at all -- they are dropped, so the estimate is
// not a bound for them).
double nitscheEigenEstimate(const Eigen::MatrixXd& A, const Eigen::MatrixXd& B, const Eigen::MatrixXd& Rm,
                            int& nUncontrolled, double relTol = 1e-8)
{
  int n = B.rows();
  nUncontrolled = 0;
  if (n == 0)
    return 0.;

  double maxDiagB = B.diagonal().maxCoeff();
  double maxDiagA = A.diagonal().cwiseAbs().maxCoeff();
  if (!(maxDiagB > 0.))
    return 0.;

  Eigen::VectorXd d(n), dInv(n);
  for (int i = 0; i < n; i++)
  {
    if (B(i,i) > 1e-14*maxDiagB)
    {
      d(i) = 1./sqrt(B(i,i));
      dInv(i) = sqrt(B(i,i));
    }
    else
    {
      d(i) = 0.;
      dInv(i) = 0.;
      if (fabs(A(i,i)) > 1e-12*maxDiagA)
        nUncontrolled++;
    }
  }
  Eigen::MatrixXd As = d.asDiagonal()*A*d.asDiagonal();
  Eigen::MatrixXd Bs = d.asDiagonal()*B*d.asDiagonal();

  // Orthonormal complement of the (scaled) null modes
  Eigen::MatrixXd Rs = dInv.asDiagonal()*Rm;
  Eigen::ColPivHouseholderQR<Eigen::MatrixXd> qr(Rs);
  qr.setThreshold(1e-10);
  int r = qr.rank();
  Eigen::MatrixXd Q = qr.householderQ();
  Eigen::MatrixXd Cc = Q.rightCols(n - r);

  Eigen::MatrixXd Bc = Cc.transpose()*Bs*Cc;
  Eigen::MatrixXd Ac = Cc.transpose()*As*Cc;
  Bc = 0.5*(Bc + Bc.transpose());
  Ac = 0.5*(Ac + Ac.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> bes(Bc);
  const Eigen::VectorXd& bEv = bes.eigenvalues();
  double bMax = bEv.maxCoeff();
  if (!(bMax > 0.))
    return 0.;
  std::vector<int> keep;
  for (int i = 0; i < bEv.size(); i++)
    if (bEv(i) > relTol*bMax)
      keep.push_back(i);
  if (keep.empty())
    return 0.;

  Eigen::MatrixXd W(Bc.rows(), keep.size());
  for (size_t j = 0; j < keep.size(); j++)
    W.col(j) = bes.eigenvectors().col(keep[j])/sqrt(bEv(keep[j]));
  Eigen::MatrixXd S = W.transpose()*Ac*W;
  S = 0.5*(S + S.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> ses(S, Eigen::EigenvaluesOnly);
  return ses.eigenvalues().maxCoeff();
}

// Clamp of the eigen estimate around the geometric estimate
// C_geo = 2*k_i*|Gamma_K|/|Omega_patch|: lambda in [g_nitscheGeoLo, g_nitscheGeoHi]*C_geo.
// The upper cap is wide and only meant to catch garbage (too small a penalty
// loses coercivity); the per-call summary prints the actual lambda/C_geo range.
static const double g_nitscheGeoLo = 0.1;
static const double g_nitscheGeoHi = 1e5;

void localNitscheEstimation(SmartPtr<HiPerProblem> immHP, SmartPtr<DOFsHandler> backDHand, SmartPtr<ParamStructure> paramStr, SmartPtr<DistributedMesh> immMesh)
{
  // Distributed mesh
  SmartPtr<DistributedMesh> backMesh = backDHand->mesh;

  // Get values from paraStructure
  double k0 = paramStr->getRealParameter(PoissonParams::k0);
  double k1 = paramStr->getRealParameter(PoissonParams::k1);
  vector<double> vki = {k0,k1};

  // One scalar DOF per region (u0 in region 0, u1 in region 1)
  int pDim = 2;
  int eNN = 9;
  int nElem = backMesh->nElem();

  // Cubature info for the boundary integration
  std::vector<Teuchos::RCP<CubatureSet>> cubaSetsB = immHP->_integ[0]->_cubaSets;

  // Linear constraints
  std::vector<std::vector<linearConstraint>>& constrReg = backMesh->_cutBFConstrRegions;

  vector<int> rTags = {3,5,7,11};

  // Element nodes and node -> elements, from the connectivity (not _adjcyNE)
  std::vector<std::vector<int>> elNds(nElem);
  std::unordered_map<int, std::vector<int>> ndEls;
  for (int iE = 0; iE < nElem; iE++)
  {
    elNds[iE].resize(eNN);
    for (int n = 0; n < eNN; n++)
    {
      elNds[iE][n] = backMesh->_connec->getNbor(iE, n);
      ndEls[elNds[iE][n]].push_back(iE);
    }
  }

  // Patches: one per cut element K of the region, made of K plus the root
  // element(s) of K's slave nodes. The roots carry the bulk that controls
  // the DOFs K's slaves are extrapolated from. Roots are shared between
  // patches, so each element's bulk enters every patch it belongs to scaled
  // by 1/(number of such patches): the patch bulks then sum to the global one
  // and the patch constants combine into a global bound. K's boundary term
  // only enters K's own patch, so l0/l1 of K is just its patch's lambda.
  for (int rInt = 0; rInt < 2; rInt++)
  {
    double ki = vki[rInt];

    // Agg field name tag (number of roots of each cut element, for inspection)
    std::string aggTag = "Agg"+to_string(rInt);
    backDHand->elemAuxF->setValue(aggTag,0);

    // Cubature info for the integration in the current region
    std::vector<Teuchos::RCP<CubatureSet>> cubaSetsR = immHP->_integ[rInt+1]->_cubaSets;

    // Slave node -> its constraint in this region
    std::unordered_map<int, const linearConstraint*> slaveOf;
    for (const linearConstraint& lCnt : constrReg[rInt])
      slaveOf[lCnt.slave] = &lCnt;

    // Bad (aggregated) cut element: its centre node is a slave. Never a root.
    auto isBad = [&](int iE) { return slaveOf.count(elNds[iE][4]) > 0; };

    std::vector<int> cutEls;
    for (int iE = 0; iE < nElem; iE++)
    {
      int eTag = backDHand->elemAuxF->getValue(0,iE);
      if (eTag%2 == 0 && eTag%rTags[rInt] == 0)
        cutEls.push_back(iE);
    }

    // Roots of each slave node of a bad K: the non-bad elements containing
    // the most of its masters (all tied ones). Constraints with best count
    // <= 3 are plain hanging-node constraints and need no root. Well-cut K
    // has no aggregation slaves: patch {K}.
    int nWeakRoots = 0, nNoRoots = 0;
    std::vector<std::vector<int>> AP(cutEls.size());
    std::vector<int> mEl(nElem, 0);
    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      std::set<int> patch = {K};
      std::set<int> roots;
      for (int nd : (isBad(K) ? elNds[K] : std::vector<int>{}))
      {
        auto it = slaveOf.find(nd);
        if (it == slaveOf.end())
          continue;
        const linearConstraint& lCnt = *it->second;
        std::unordered_map<int,int> count;
        for (size_t m = 0; m < lCnt.masters.size(); m++)
          for (int e : ndEls[lCnt.masters[m]])
            if (!isBad(e))
              count[e]++;
        int best = 0;
        for (auto& c : count)
          best = max(best, c.second);
        if (best <= 3)
          continue;
        if (best < 6)
          nWeakRoots++;
        for (auto& c : count)
          if (c.second == best)
            roots.insert(c.first);
      }
      if (isBad(K) && roots.empty())
        nNoRoots++;
      patch.insert(roots.begin(), roots.end());

      // Free nodes of a bad K outside its roots are controlled through some
      // other good element of the region: add it, otherwise their only bulk
      // control in the patch is K's sliver
      if (isBad(K))
      {
        std::set<int> rootNds;
        for (int e : roots)
          rootNds.insert(elNds[e].begin(), elNds[e].end());
        for (int nd : elNds[K])
        {
          if (slaveOf.count(nd) || rootNds.count(nd))
            continue;
          for (int e : ndEls[nd])
          {
            int eTag = backDHand->elemAuxF->getValue(0,e);
            if (e != K && eTag%rTags[rInt] == 0 && !isBad(e))
              patch.insert(e);
          }
        }
      }
      backDHand->elemAuxF->setValue(aggTag,K,IndexType::Global,(double)roots.size());
      AP[k].assign(patch.begin(), patch.end());
      for (int e : AP[k])
        mEl[e]++;
    }

    // Summary counters
    int nAgg = 0, nLo = 0, nHi = 0, nFallback = 0, nUncTot = 0, maxNM = 0;
    double rMin = 1e300, rMax = 0.;

    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      const std::vector<int>& akp = AP[k];
      if (akp.size() > 1)
        nAgg++;

      // Patch DOF nodes (masters after the constraint mapping) and, per
      // element node, its (patch node, weight) list
      std::vector<int> igNds;
      std::unordered_map<int,int> igIdx;
      auto patchIdx = [&](int nd) {
        auto it = igIdx.find(nd);
        if (it != igIdx.end())
          return it->second;
        igIdx[nd] = igNds.size();
        igNds.push_back(nd);
        return (int)igNds.size()-1;
      };
      std::unordered_map<int, std::vector<std::vector<std::pair<int,double>>>> elMap;
      for (int iE : akp)
      {
        std::vector<std::vector<std::pair<int,double>>>& mp = elMap[iE];
        mp.resize(eNN);
        for (int il = 0; il < eNN; il++)
        {
          auto it = slaveOf.find(elNds[iE][il]);
          if (it == slaveOf.end())
            mp[il].push_back({patchIdx(elNds[iE][il]), 1.});
          else
          {
            // |w|: extrapolation weights are often negative (e.g. 6, -8, 3)
            const linearConstraint& lCnt = *it->second;
            for (size_t m = 0; m < lCnt.masters.size(); m++)
              if (fabs(lCnt.weights[m]) > 1e-13)
                mp[il].push_back({patchIdx(lCnt.masters[m]), lCnt.weights[m]});
          }
        }
      }
      int nM = igNds.size();
      maxNM = max(maxNM, nM);

      // M1: patch bulk, M2: K's boundary term
      Eigen::MatrixXd M1 = Eigen::MatrixXd::Zero(nM, nM);
      Eigen::MatrixXd M2 = Eigen::MatrixXd::Zero(nM, nM);
      auto scatter = [&](Eigen::MatrixXd& M, const std::vector<std::vector<std::pair<int,double>>>& mp,
                         tensor<double,2>& Ke, double s) {
        for (int a = 0; a < eNN; a++)
          for (auto& pa : mp[a])
            for (int b = 0; b < eNN; b++)
              for (auto& pb : mp[b])
                M(pa.first, pb.first) += s*pa.second*pb.second*Ke(a,b);
      };

      double APatch = 0.; // bulk measure, scaled as M1
      double LPatch = 0.; // K's boundary measure

      for (int iE : akp)
      {
        double sE = 1./mEl[iE];

        // Compute bulk integration
        for (auto info: cubaSetsR[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,2> Aku1(eNN,eNN);
          for (int a = 0; a < eNN; a++)
            for (int b = 0; b < eNN; b++)
              Aku1(a,b) = 0;
          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int a = 0; a < 2; a++)
              for (int b = 0; b < 2; b++)
                Jac(a,b) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();
            double jac = Jac.det();

            tensor<double,2> dede = product(Dbf_g,Dbf_g,{{1,1}});
            Aku1 += wS[gpi]*jac*dede;
            APatch += sE*wS[gpi]*jac;
          }
          scatter(M1, elMap[iE], Aku1, sE);
        }

        // Boundary term of K only
        if (iE != K)
          continue;

        for (auto info: cubaSetsB[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,2> Bku1(eNN,eNN);
          for (int a = 0; a < eNN; a++)
            for (int b = 0; b < eNN; b++)
              Bku1(a,b) = 0;
          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int a = 0; a < 2; a++)
              for (int b = 0; b < 2; b++)
                Jac(a,b) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();

            // Normal and jacobian
            int nDim = 3;
            std::vector<double> t(nDim);
            for (int n = 0; n < nDim; n++)
              t[n] = immMesh->_immTangents[iE][nDim*gpi+n];
            double jac = Math::Norm3D(t.data());

            // Compute unitary normal (sign irrelevant: the term is quadratic)
            tensor<double,1> nB(2);
            nB(0) = -t[1]/jac;
            nB(1) = t[0]/jac;
            tensor<double,1> Dbf_gN = Dbf_g*nB;
            for (int a{}; a < eNN; a++)
              for (int b{}; b < eNN; b++)
                Bku1(a,b) += wS[gpi]*jac*2.*ki*Dbf_gN(a)*Dbf_gN(b);
            LPatch += wS[gpi]*jac;
          }
          scatter(M2, elMap[iE], Bku1, 1.);
        }
      }

      // Null mode on the patch nodes: constants (extrapolation weights sum to 1)
      Eigen::MatrixXd Rm = Eigen::MatrixXd::Ones(nM, 1);

      int nUnc = 0;
      double lEig = nitscheEigenEstimate(M2, M1, Rm, nUnc);
      nUncTot += nUnc;

      if (LPatch > 0. && !(APatch > 0.))
        throw runtime_error("localNitscheEstimation: cut element " + to_string(K) + " has no bulk in region "
                            + to_string(rInt) + " (patch of " + to_string(akp.size()) + " elements)");
      double Cgeo = (APatch > 0.) ? 2.*ki*LPatch/APatch : 0.;

      double lmax = lEig;
      if (Cgeo > 0.)
      {
        if (!(lEig > 0.) || !std::isfinite(lEig))
        {
          lmax = Cgeo;
          nFallback++;
        }
        else
        {
          rMin = min(rMin, lEig/Cgeo);
          rMax = max(rMax, lEig/Cgeo);
          if (lEig < g_nitscheGeoLo*Cgeo)
          {
            lmax = g_nitscheGeoLo*Cgeo;
            nLo++;
          }
          else if (lEig > g_nitscheGeoHi*Cgeo)
          {
            lmax = g_nitscheGeoHi*Cgeo;
            nHi++;
          }
        }
      }
      else if (!(lEig > 0.) || !std::isfinite(lEig))
        nFallback++; // no boundary points in K: lmax unused by LS_backBorder

      backDHand->elemAuxF->setValue("l"+to_string(rInt),K,IndexType::Global,lmax);
    }

    cout << "Nitsche r" << rInt << ": " << cutEls.size() << " patches (" << nAgg << " with roots, max "
         << maxNM << " nodes), lambda/Cgeo in [" << (rMin < 1e300 ? rMin : 0.) << ", " << rMax << "], clamped lo "
         << nLo << " hi " << nHi << ", fallback " << nFallback << ", weak roots " << nWeakRoots
         << ", bad without root " << nNoRoots << ", uncontrolled DOFs " << nUncTot << endl;
  }
}

void FacetStbR0(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  int nS = fillStr.getIntParameter(PoissonParams::timeStep);

  SubFillStructure& e0 = fillStr[0];
  SubFillStructure& e1 = fillStr[1];
  int eNN  = e0.eNN;
  int nDim = e0.nDim;
  int pDim = e0.pDim;
  int numDOFs = e0.numDOFs;
  // Ghost-penalty coefficients, scaled by the region's diffusivity
  double k0 = fillStr.getRealParameter(PoissonParams::k0);
  double gmm1 = k0*fillStr.getRealParameter(PoissonParams::gGP1);
  double gmm2 = k0*fillStr.getRealParameter(PoissonParams::gGP2);
  double* Dbf0  = e0.nborBFsGrads();    // local BF derivatives: [eNN × pDim]
  double* bf0  = e0.nborBFs();    // local BF: [eNN]
  double* bf1  = e1.nborBFs();    // local BF: [eNN]
  double* coords0 = e0.nborCoords.data();   // node coordinates:   [eNN × nDim]
  double* coords1 = e1.nborCoords.data();   // node coordinates:   [eNN × nDim]
  double h = fabs(coords0[0]-coords0[8*nDim]);
  vector<double> Ecoords = {-1.,-1.,-0.,-1.,1.,-1.,-1.,0.,0.,0.,1.,0.,-1.,1.,0.,1.,1.,1.};   // node coordinates:   [eNN × nDim]

  // cout << h << endl;
  // Reference tangent vector along the boundary side (length pDim)
  std::vector<double> tangRef = e0.tangentsBoundaryRef();

  // Push tangRef through the Jacobian to obtain the physical tangent
  //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
  //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
  std::vector<double> tangPhys(nDim, 0.0);
  for (int a = 0; a < nDim; a++)
  {
    for (int b = 0; b < pDim; b++)
    {
      double Jab = 0.0;
      for (int i = 0; i < eNN; i++)
        Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
      tangPhys[a] += Jab * tangRef[b];
    }
  }
  tensor<double,1> x0(2);
  x0 *=0;
  tensor<double,1> x1(2);
  x1 *=0;
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      x0(i) += bf0[a]*coords0[a*nDim + i];
      x1(i) += bf1[a]*coords1[a*nDim + i];
    }
  }

  tensor<double,1> xl0(2);
  tensor<double,1> xl1(2);
  tensor<double,2> dbf(9,2);
  xl0 *=0;
  xl1 *=0;
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      xl0(i) += bf0[a]*Ecoords[a*pDim + i];
      xl1(i) += bf1[a]*Ecoords[a*pDim + i];
      dbf(a,i) = Dbf0[a*pDim + i];
    }
  }
  
  double edge_jac = 0.0;
  for (double t : tangPhys) edge_jac += t * t;
  edge_jac = std::sqrt(edge_jac);

  // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
  // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
  tensor<double,1> n(2);
  n(0) = tangPhys[1]/edge_jac;
  n(1) = -tangPhys[0]/edge_jac;
  // cout << "N: " << n<<endl;

  tensor<double,2> gDbf0(eNN,pDim);
  tensor<double,3> gHbf0(eNN,pDim,pDim);
  tensor<double,1> gLbf0(eNN);
  double jac0;
  // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);

  tensor<double,1> HbfN0(eNN);
  GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
  tensor<double,1> DbfN0 = gDbf0*n;

  tensor<double,2> gDbf1(eNN,pDim);
  tensor<double,3> gHbf1(eNN,pDim,pDim);
  tensor<double,1> gLbf1(eNN);
  double jac1;
  // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);

  tensor<double,1> HbfN1(eNN);
  GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
  tensor<double,1> DbfN1 = gDbf1*n;

  // Second normal derivative n^T H n
  for (int a = 0; a < eNN; a++)
  {
    HbfN0(a) = 0.;
    HbfN1(a) = 0.;
    for (int i = 0; i < pDim; i++)
      for (int j = 0; j < pDim; j++)
      {
        HbfN0(a) += n(i)*gHbf0(a,i,j)*n(j);
        HbfN1(a) += n(i)*gHbf1(a,i,j)*n(j);
      }
  }

  // cout << xl0 << ", " << xl1<< DbfN0 << DbfN1 << endl;
  // cout << dbf << n << dbf*n << endl;        
  tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
  Ak00 *=0;
  Ak01 *=0;
  Ak10 *=0;
  Ak11 *=0;
  for (int a = 0; a < eNN; a++)
  {
    for (int b = 0; b < eNN; b++)
    {
      Ak00(a,0,b,0) += edge_jac*h*gmm1*(DbfN0(a)*DbfN0(b));
      Ak01(a,0,b,0) += -edge_jac*h*gmm1*(DbfN0(a)*DbfN1(b));
      Ak10(a,0,b,0) += -edge_jac*h*gmm1*(DbfN1(a)*DbfN0(b));
      Ak11(a,0,b,0) += edge_jac*h*gmm1*(DbfN1(a)*DbfN1(b));

      if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
      {
        Ak00(a,0,b,0) += edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
        Ak01(a,0,b,0) += -edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
        Ak10(a,0,b,0) += -edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
        Ak11(a,0,b,0) += edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
      }
    }
    
  }
  // Ak00 *=-1;
  // Ak01 *=-1;
  // Ak10 *=-1;
  // Ak11 *=-1;
  fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
  // cout << edge_jac << endl;
  // ofstream myfile;
  // myfile.open("fStb0."+to_string(nS)+".csv", std::ios_base::app);
  // myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
  // myfile.close();

  // myfile.open("fStb1."+to_string(nS)+".csv", std::ios_base::app);
  // myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
  // myfile.close();

}

void FacetStbR1(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  int nS = fillStr.getIntParameter(PoissonParams::timeStep);

  SubFillStructure& e0 = fillStr[0];
  SubFillStructure& e1 = fillStr[1];
  int eNN  = e0.eNN;
  int nDim = e0.nDim;
  int pDim = e0.pDim;
  int numDOFs = e0.numDOFs;
  // Ghost-penalty coefficients, scaled by the region's diffusivity
  double k1 = fillStr.getRealParameter(PoissonParams::k1);
  double gmm1 = k1*fillStr.getRealParameter(PoissonParams::gGP1);
  double gmm2 = k1*fillStr.getRealParameter(PoissonParams::gGP2);
  double* Dbf0  = e0.nborBFsGrads();    // local BF derivatives: [eNN × pDim]
  double* bf0  = e0.nborBFs();    // local BF: [eNN]
  double* bf1  = e1.nborBFs();    // local BF: [eNN]
  double* coords0 = e0.nborCoords.data();   // node coordinates:   [eNN × nDim]
  double* coords1 = e1.nborCoords.data();   // node coordinates:   [eNN × nDim]
  double h = fabs(coords0[0]-coords0[8*nDim]);
  vector<double> Ecoords = {-1.,-1.,-0.,-1.,1.,-1.,-1.,0.,0.,0.,1.,0.,-1.,1.,0.,1.,1.,1.};   // node coordinates:   [eNN × nDim]

  // cout << h << endl;
  // Reference tangent vector along the boundary side (length pDim)
  std::vector<double> tangRef = e0.tangentsBoundaryRef();

  // Push tangRef through the Jacobian to obtain the physical tangent
  //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
  //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
  std::vector<double> tangPhys(nDim, 0.0);
  for (int a = 0; a < nDim; a++)
  {
    for (int b = 0; b < pDim; b++)
    {
      double Jab = 0.0;
      for (int i = 0; i < eNN; i++)
        Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
      tangPhys[a] += Jab * tangRef[b];
    }
  }
  tensor<double,1> x0(2);
  x0 *=0;
  tensor<double,1> x1(2);
  x1 *=0;
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      x0(i) += bf0[a]*coords0[a*nDim + i];
      x1(i) += bf1[a]*coords1[a*nDim + i];
    }
  }

  tensor<double,1> xl0(2);
  tensor<double,1> xl1(2);
  tensor<double,2> dbf(9,2);
  xl0 *=0;
  xl1 *=0;
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      xl0(i) += bf0[a]*Ecoords[a*pDim + i];
      xl1(i) += bf1[a]*Ecoords[a*pDim + i];
      dbf(a,i) = Dbf0[a*pDim + i];
    }
  }
  
  double edge_jac = 0.0;
  for (double t : tangPhys) edge_jac += t * t;
  edge_jac = std::sqrt(edge_jac);

  // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
  // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
  tensor<double,1> n(2);
  n(0) = tangPhys[1]/edge_jac;
  n(1) = -tangPhys[0]/edge_jac;
  // cout << "N: " << n<<endl;

  tensor<double,2> gDbf0(eNN,pDim);
  tensor<double,3> gHbf0(eNN,pDim,pDim);
  tensor<double,1> gLbf0(eNN);
  double jac0;
  // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);

  tensor<double,1> HbfN0(eNN);
  GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
  tensor<double,1> DbfN0 = gDbf0*n;

  tensor<double,2> gDbf1(eNN,pDim);
  tensor<double,3> gHbf1(eNN,pDim,pDim);
  tensor<double,1> gLbf1(eNN);
  double jac1;
  // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);

  tensor<double,1> HbfN1(eNN);
  GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
  tensor<double,1> DbfN1 = gDbf1*n;

  // Second normal derivative n^T H n
  for (int a = 0; a < eNN; a++)
  {
    HbfN0(a) = 0.;
    HbfN1(a) = 0.;
    for (int i = 0; i < pDim; i++)
      for (int j = 0; j < pDim; j++)
      {
        HbfN0(a) += n(i)*gHbf0(a,i,j)*n(j);
        HbfN1(a) += n(i)*gHbf1(a,i,j)*n(j);
      }
  }

  // cout << xl0 << ", " << xl1<< DbfN0 << DbfN1 << endl;
  // cout << dbf << n << dbf*n << endl;        
  tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
  Ak00 *=0;
  Ak01 *=0;
  Ak10 *=0;
  Ak11 *=0;
  for (int a = 0; a < eNN; a++)
  {
    for (int b = 0; b < eNN; b++)
    {
      Ak00(a,1,b,1) += edge_jac*h*gmm1*(DbfN0(a)*DbfN0(b));
      Ak01(a,1,b,1) += -edge_jac*h*gmm1*(DbfN0(a)*DbfN1(b));
      Ak10(a,1,b,1) += -edge_jac*h*gmm1*(DbfN1(a)*DbfN0(b));
      Ak11(a,1,b,1) += edge_jac*h*gmm1*(DbfN1(a)*DbfN1(b));

      if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
      {
        Ak00(a,1,b,1) += edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
        Ak01(a,1,b,1) += -edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
        Ak10(a,1,b,1) += -edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
        Ak11(a,1,b,1) += edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
      }
    }
    
  }
  // Ak00 *=-1;
  // Ak01 *=-1;
  // Ak10 *=-1;
  // Ak11 *=-1;
  fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
  // cout << e0.kPt << " " <<e1.kPt << endl;
  // ofstream myfile;
  // myfile.open("fStb00."+to_string(nS)+".csv", std::ios_base::app);
  // myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
  // myfile.close();

  // myfile.open("fStb11."+to_string(nS)+".csv", std::ios_base::app);
  // myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
  // myfile.close();

}

// *******************************************************************//
// *******************************************************************//
// *******************************************************************//
// *****            MAIN FUNCTION            *****//
// *******************************************************************//
// *******************************************************************//
// *******************************************************************//

int main(int argc, char** argv)
{
  hiperlife::Init(argc, argv);

  Params p;
  try {
    p = parseArgs(argc, argv);
  } catch (const std::exception& e) {
    std::cerr << "Error: " << e.what() << "\n";
    std::cerr << "Usage: " << argv[0]
           << " --rx <val> --ry <val> --k0 <val> --k1 <val> --wpTh <val> --beta <val>\n";
    return 1;
  }

  std::cout << "rx=" << p.rx << " ry=" << p.ry
      << " k0=" << p.k0 << " k1=" << p.k1
      << " wpTh=" << p.wpTh << " beta=" << p.beta << "\n";

  //============================ Parameters ============================//
  int nx = 100;
  int ny = nx;
  vector<int> nxt = {8, 16, 32, 64, 128};
  nxt.resize(std::max(1, std::min((int)nxt.size(), (int)p.levels)));
  // cout << "Type number of elements per side: " << endl;
  // cin >> nx;
  SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();

  int testN = -1;
  if (fabs(p.k0-p.k1) <1e-15)
    testN = 1;
  else
    testN = 2;
  

  paramStr->setIntParameter(PoissonParams::testN,testN);

  // *******************************************************************//
  // *****            MESH CREATION            *****//
  // *******************************************************************//
  int nSteps = nxt.size();
  int bfOrder = 2;
  int timeStep = 0;
  bool ghP = (p.ghP != 0.);
  double wellPosedTh = p.wpTh;

  std::vector<double> Merr; 
  std::vector<double> Kerr; 
  std::vector<double> Terr;
  std::vector<double> nTerr;
  

  double k0 = p.k0;
  double k1 = p.k1;
  
  paramStr->setRealParameter(PoissonParams::k0,p.k0);
  paramStr->setRealParameter(PoissonParams::k1,p.k1);
  paramStr->setBoolParameter(PoissonParams::ghP,ghP);
  paramStr->setRealParameter(PoissonParams::gGP1,p.gp1);
  paramStr->setRealParameter(PoissonParams::gGP2,p.gp2);

  double beta0 = p.beta;
  // Ghost penalty replaces aggregation: every cut element with etaK > 0 is a root
  if(ghP)
    wellPosedTh = 0.;
  for (int nS{}; nS < nSteps; nS++)
  {
    paramStr->setIntParameter(PoissonParams::timeStep,nS);
    //-------------------------- Background mesh -------------------------//
    double beta = beta0*nxt[nS]; // beta = 100/h (from 2017Badia)
    paramStr->setRealParameter(PoissonParams::beta,beta);

    // Mesh generator
    SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
    back->genStructMesh(nxt[nS], nxt[nS]);
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0001;    

    SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();

    ElemType eTypeB = ElemType::Line; // Element type
    int bfOrderB = 3;   // Basis function order
    BasisFuncType bTypeB = BasisFuncType::BSplines; // Basis function type
    double r = 0.7/sqrt(5.); // Radius of immersed mesh
    int nPtsCirc = 5*nxt[nS]; // Number of control points
    std::vector<std::vector<std::vector<std::vector<double>>>> CP(nPtsCirc, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
    std::vector<double> U(nPtsCirc+1,0);

    imm->setMesh(eTypeB, bTypeB, bfOrderB);
    genCircBspline(r,U,CP,p.rx,p.ry,eTypeB,bTypeB,bfOrderB,nPtsCirc,paramStr);
    imm->genBsplinesClosedCurve(U,CP);

  
    SmartPtr<DistributedMesh> immProva = Create<DistributedMesh>("immMeshProva");
    immProva->setMesh(imm);
    immProva->setBalanceMesh(true);
    immProva->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immProva->setVerbosity(Verbosity::None);
    immProva->Update();
    // immProva->printFileLegacyVtk("meshProva");

    // Distributed mesh
    SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->Update();


    //--------------------------- Immersed mesh --------------------------//

    // Distributed mesh
    SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setImmersedInteriorPoints({{{0.5, 0.5, 0.0}},{{0.01,0.01,0}}});
    immMesh->setRegionTags({"Interior","Exterior"});
    immMesh->setBalanceMesh(true);
    immMesh->setIllPosThreshold(wellPosedTh);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->Update();

    // Print meshes
    // backMesh->printFileLegacyVtk("meshBack");
    // immMesh->printFileLegacyVtk("meshImm");


    // *******************************************************************//
    // *****           DOFsHandler CREATION          *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"u0","u1"});
    backDHand->setNodeAuxF({"const","ctag","stab"});
    backDHand->setElemAuxF({"tag","WI","Agg0","gmm0","l0","GhP0","Agg1","gmm1","l1","GhP1","lE"});
    backDHand->setDofTags({"Interior","Exterior"});
    backDHand->Update();

    // Save interior/cut/exterior flags for plotting
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
      int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
      backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
      vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
      vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
      for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
      {
        if (backDHand->mesh->isNodeInPart(nbors[n]))
          backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
      }
    }
    backDHand->UpdateGhosts();
    
    // Set boundary conditions

    backDHand->setBoundaryCondition("u1", MAxis::Xmin, [=](double x){return k0/k1*cos(0.)*sin(M_PI*x);});
    backDHand->setBoundaryCondition("u1", MAxis::Xmax, [=](double x){return k0/k1*cos(M_PI)*sin(M_PI*x);});
    backDHand->setBoundaryCondition("u1", MAxis::Ymin, 0);
    backDHand->setBoundaryCondition("u1", MAxis::Ymax, 0);


    // backDHand->printFileLegacyVtk("dofBack", true);

    // Compute facet pairs
    std::vector<std::pair<int,int>> borderFacetPairsR0 = findBorderAdjacentPairs(backDHand, bfOrder,0);
    std::vector<std::pair<int,int>> borderFacetPairsR1 = findBorderAdjacentPairs(backDHand, bfOrder,1);


    // *******************************************************************//
    // *****          IMMERSED PROBLEM           *****//
    // *******************************************************************//
    if (true)
    {
      // Immersed HiPerProblem
      SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
      //General setters
      immHP->setParameterStructure(paramStr);
      immHP->setGlobalIntegrals({"Area","Length","uError","duError","total_edge_length"});
      immHP->setDOFsHandlers({backDHand});

      // Set integration for the border
      immHP->setIntegration("IntegBorder", {"backDHand"});
      immHP->setCubatureBorderImmersed("IntegBorder", 10);
      immHP->setElementFillings("IntegBorder", LS_backBorder);

      // Set integration for the background mesh
      immHP->setIntegration("Integ0", {"backDHand"});
      // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
      immHP->setCubatureCutCellConforming("Integ0", 9, 5,"Interior");
      immHP->setElementFillings("Integ0", LS_backBulk0);

      // Set integration for the background mesh
      immHP->setIntegration("Integ1", {"backDHand"});
      // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
      immHP->setCubatureCutCellConforming("Integ1", 9, 5,"Exterior");
      immHP->setElementFillings("Integ1", LS_backBulk1);

      if (ghP)
      {
        // Face stabilization
        // Region 0
        immHP->setIntegration("IntegF0",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF0", /*iPts=*/5, borderFacetPairsR0);
        immHP->setElementFillings("IntegF0", FacetStbR0);

        // Region 1
        immHP->setIntegration("IntegF1",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF1", /*iPts=*/5, borderFacetPairsR1);
        immHP->setElementFillings("IntegF1", FacetStbR1);
      }
      immHP->Update();

      localNitscheEstimation(immHP, backDHand, paramStr, immMesh);
      string solNamePre = "solBackPre."+to_string(nS);
      // backDHand->printFileLegacyVtk(solNamePre, true);

      //-------------------------- Immersed solver -------------------------//
      SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
      immSOL->setHiPerProblem(immHP);
      immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
      immSOL->setDefaultParameters();
      immSOL->Update();
      //---------------------------- Solve immersed ------------------------//
      // Solve
      // immHP->FillLinearSystem();
      immSOL->solve();
      immSOL->UpdateSolution();
      string Kname = "K"+buildFilename(p)+to_string(nS)+".mm";
      const char *CKname = Kname.c_str();

      EpetraExt::RowMatrixToMatrixMarketFile(CKname, *immHP->A);

      string meshName = buildFilename(p)+to_string(nS);
      if(false) // Print matrix and rhs
      {
        // string LHSName = "LHS." + meshName +".mm";
        // string SolName = "Sol." + meshName +".mm";
        // string RHSName = "RHS." + meshName +".mm";
        // const char *CLHSName = LHSName.c_str();
        // const char *CSolName = SolName.c_str();
        // const char *CRHSName = RHSName.c_str();
        // EpetraExt::RowMatrixToMatrixMarketFile(CLHSName, *immHP->A, "LHS", "Left hand side matrix");
        // EpetraExt::MultiVectorToMatrixMarketFile(CSolName, *immHP->sol, "Sol", "Solution vector");
        // EpetraExt::MultiVectorToMatrixMarketFile(CRHSName, *immHP->rhs, "RHS", "Right hand side vector");

        ofstream CoordsFile;
        CoordsFile.open ("Coords." + meshName +".csv");
        for (int d = 0; d < backMesh->loc_nPts(); d++)
        {
          // Get node coordinates
          std::vector<double> x = backMesh->nodeCoords(d, IndexType::Local);
          CoordsFile << x[0] << "," << x[1] << endl;
        }
        for (int d = 0; d < immMesh->loc_nPts(); d++)
        {
          // Get node coordinates
          std::vector<double> x = immMesh->nodeCoords(d, IndexType::Local);
          CoordsFile << x[0] << "," << x[1] << endl;
        }
        CoordsFile.close(); 
      }

      
      // Print
      string solName = "solBack."+buildFilename(p)+"."+to_string(nS);
      backDHand->printFileLegacyVtk(solName, true);
      string immMshName = "meshImm."+to_string(nS);
      immMesh->printFileLegacyVtk(immMshName);

      double L = immHP->globalIntegral("Length");
      double A = immHP->globalIntegral("Area");
      // cout << "Area: " << A << " Lenght: " << L << endl;

      SmartPtr<HiPerProblem> checkSolution = Create<HiPerProblem>();
      checkSolution->setDOFsHandlers({backDHand});
      checkSolution->setParameterStructure(paramStr);

      // Set integration for the border
      checkSolution->setIntegration("IntegBorder", {"backDHand"});
      checkSolution->setCubatureBorderImmersed("IntegBorder", 15);
      checkSolution->setElementFillings("IntegBorder", CheckNitsche);

      // Set integration for the background mesh
      checkSolution->setIntegration("Integ0", {"backDHand"});
      checkSolution->setCubatureCutCellConforming("Integ0", 9, 8,"Interior");
      checkSolution->setElementFillings("Integ0", CheckSolution0);


      // Set integration for the background mesh
      checkSolution->setIntegration("Integ1", {"backDHand"});
      checkSolution->setCubatureCutCellConforming("Integ1", 9, 8,"Exterior");
      checkSolution->setElementFillings("Integ1", CheckSolution1);

      checkSolution->setGlobalIntegrals({"error0","error1","uErr","duErr","tErr"});
      checkSolution->Update();

      // Interface flux dump: one row per interface integration point
      std::ofstream fluxCSV("flux."+buildFilename(p)+"."+to_string(nS)+".csv");
      fluxCSV << std::setprecision(12)
              << "backElem,immElem,kPt,dGamma,x,y,nx,ny,"
                 "t0,t1,jumpT,tNitsche,tExact,errTNitsche,jumpU\n";
      gFluxCSV = &fluxCSV;
      checkSolution->FillLinearSystem();
      gFluxCSV = nullptr;
      fluxCSV.close();

      // if (testN == 3)
      // {
      //   SmartPtr<HiPerProblem> checkSolution2 = Create<HiPerProblem>();
      //   checkSolution2->setDOFsHandlers({immDHand});
      //   // Set integration for the border
      //   checkSolution2->setIntegration("IntegBorder", {"immDHand"});
      //   checkSolution2->setCubatureBorderImmersed("IntegBorder", 15);
      //   checkSolution2->setElementFillings("IntegBorder", CheckNitsche);
      // }
      double error0 = checkSolution->globalIntegral("error0");
      double error1 = checkSolution->globalIntegral("error1");
      std::cout << "error: " << error0<<error1 << std::endl;
      double Uerror = checkSolution->globalIntegral("uErr");
      std::cout << "U border error: " << sqrt(Uerror) << std::endl;
      double dUerror = checkSolution->globalIntegral("duErr");
      std::cout << "dU*n border error: " << sqrt(dUerror) << std::endl;
            double tUerr = checkSolution->globalIntegral("tErr");
      std::cout << "dU*n border error: " << sqrt(tUerr) << std::endl;

      Merr.push_back(sqrt(error0+error1));
      Kerr.push_back(sqrt(Uerror));
      Terr.push_back(sqrt(dUerror));
      nTerr.push_back(sqrt(tUerr));
    }
  }
  cout << "k0 = " << k0 << ", k1 = " << k1 <<endl;
  // Column headers
  cout << left
     << setw(20) << "1/h"
     << setw(20)  << "M Err"
     << setw(20) << "K Err"
     << setw(20) << "T Err"
     << setw(20) << "Nitsche T Err"
     << endl;

  // Separator line
  cout << string(80, '-') << endl;

  for(int nS = 0; nS < nxt.size(); nS++)
  {
    cout << left << setw(20) <<  nxt[nS] <<  setw(20) <<  Merr[nS]  << setw(20) << Kerr[nS] << setw(20) << Terr[nS] << setw(20) << nTerr[nS]  << endl;
  }

  hiperlife::Finalize();
  return 0;
}