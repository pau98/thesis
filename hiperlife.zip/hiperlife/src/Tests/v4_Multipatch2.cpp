

// C++ headers
#include <cstddef>
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// HiPerLiFE headers
#include "hl_MeshCreator.h"
#include "hl_MeshMap_Trivial.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_MultiPatchMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<FillStructure> fillStr)
{
    // Initialize variables
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    std::vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFs();  // Local shape function
    double gNa[eNN*pDim], jac;
    GlobalBasisFunctions::gradients(gNa, jac, subFill);

    // Fill
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            // Compute the product of the gradient of the basis
            // functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            // Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        // // Fill RHS
        // fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}

RCP<StructMeshGenerator> genQuarterPlate(int nEx, int nEy, int nEz, double radius, double sidex)
{
    ElemType eType = ElemType::Parallelep;
    if (nEz == -1)
        eType = ElemType::Square;
    if (nEx%2 != 0 or nEy%2 != 0)
        throw runtime_error("Please use an even number of elements.");

    // Declare and set
    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(eType, BasisFuncType::Lagrangian, 1);

    // Generate regular mesh
    mesh->genStructMesh(nEx, nEy, nEz);

    // Transform into annular sector (phi=pi/2)
    mesh->transformFree([radius, sidex](double x, double y, double z){
                      double x2 = x * (sidex - radius) + radius;
                      double y2 = y * M_PI/2.0;
                      return std::make_tuple(x2*cos(y2), x2*sin(y2), z);
                  });

    // Transform annular sector to plate
    mesh->transformFree([radius, sidex](double x, double y, double z){
                      double theta = std::atan2(y, x);
                      double r0    = sqrt(x*x+y*y);
                      double alpha = pow((r0-radius)/(sidex-radius), 4.0);
                      double r1{};
                      if (theta <= M_PI/4.0)
                          r1 = r0*pow(1.0/cos(theta), alpha);
                      else
                          r1 = r0*pow(1.0/sin(theta), alpha);
                      return std::make_tuple(r1*cos(theta), r1*sin(theta), z);
                  });

    return mesh;
}

RCP<StructMeshGenerator> genLinkMesh(int nEx, int nEy, int nEz)
{
    ElemType eType = ElemType::Parallelep;
    if (nEz == -1)
        eType = ElemType::Square;

    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(eType, BasisFuncType::Lagrangian, 1);
    mesh->genStructMesh(nEx, nEy, nEz);
    mesh->transformFree([](double x, double y, double z){
                             double radius = 0.2;
                             double sidex = 1.0;

                             double x2 = 1.0 * (sidex - radius) + radius;
                             double y2 = y/2.0 * M_PI/2.0;

                             double theta = std::atan2(x2*sin(y2), x2*cos(y2));
                             double r0    = 1.0;
                             double alpha = pow((r0-0.2)/(1.0-0.2), 4.0);
                             double r1 = r0*pow(1.0/cos(theta), alpha);
                             double y1 = r1*sin(theta);
                             return std::make_tuple(x, y1, z);
                         });

    return mesh;
}

RCP<StructMeshGenerator> genLinkMesh0(int nEx, int nEy, int nEz, double sx, double sy)
{
    RCP<StructMeshGenerator> mesh = genLinkMesh(nEx, nEy, nEz);
    mesh->scaleXY(sx, sy);
    mesh->translate(sy, 0.0, 0.0);

    return mesh;
}

RCP<StructMeshGenerator> genLinkMesh1(int nEx, int nEy, int nEz, double sx, double sy)
{
    RCP<StructMeshGenerator> mesh = genLinkMesh(nEx, nEy, nEz);
    mesh->translate(-0.5, -0.5, 0.0);
    mesh->rotate2D(M_PI);
    mesh->translate(0.5, 0.5, 0.0);
    mesh->scaleXY(sx, sy);
    mesh->translate(sy, -sy, 0.0);

    return mesh;
}

RCP<StructMeshGenerator> genSquare(int nEx, int nEy, int nEz, double s, double sx, double sy)
{
    ElemType eType = ElemType::Parallelep;
    if (nEz == -1)
        eType = ElemType::Square;

    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(eType, BasisFuncType::Lagrangian, 1);
    mesh->genStructMesh(nEx, nEy, nEz);
    mesh->scaleXY(sx, sy);
    mesh->translate(s, s, 0.0);

    return mesh;
}

void genHalfPlate(int nEr, int nEa, int nEh, int nEl, int nEc, int nEz, double L, double H, double W, double r, double c, double s, vector<RCP<MeshCreator>> &patches)
{
    // Hole
    patches.push_back(genQuarterPlate(nEr, nEa, nEz, r, s));
    patches.push_back(genQuarterPlate(nEr, nEa, nEz, r, s));
    patches.back()->rotate2D(M_PI/2.0);
    // patches.push_back(genQuarterPlate(nEr, nEa, nEz, r, s));
    // patches.back()->rotate2D(M_PI);
    // patches.push_back(genQuarterPlate(nEr, nEa, nEz, r, s));
    // patches.back()->rotate2D(-M_PI/2.0);

    // // Right
    // patches.push_back(genLinkMesh0(nEc, nEa/2, nEz, (c-2.0*s)/2.0, s));
    // patches.push_back(genLinkMesh1(nEc, nEa/2, nEz, (c-2.0*s)/2.0, s));

    // // Top-right
    // patches.push_back(genSquare(nEc, nEh, nEz, s, (c-2.0*s)/2.0, (H-2*s)/2.0));

    // Top
    patches.push_back(genLinkMesh0(nEh, nEa/2, nEz, (H-2*s)/2.0, s));
    patches.back()->rotate2D(M_PI/2.0);
    // patches.push_back(genLinkMesh1(nEh, nEa/2, nEz, (H-2*s)/2.0, s));
    // patches.back()->rotate2D(M_PI/2.0);

    // // Top-left
    // patches.push_back(genSquare(nEh, nEl, nEz, s, (H-2*s)/2.0, (L-2*s-c)/2.0));
    // patches.back()->rotate2D(M_PI/2.0);

    // // Left
    // patches.push_back(genLinkMesh0(nEl, nEa/2, nEz, (L-2*s-c)/2.0, s));
    // patches.back()->rotate2D(M_PI);
    // patches.push_back(genLinkMesh1(nEl, nEa/2, nEz, (L-2*s-c)/2.0, s));
    // patches.back()->rotate2D(M_PI);

    // // Bottom-left
    // patches.push_back(genSquare(nEl, nEh, nEz, s, (L-2*s-c)/2.0, (H-2*s)/2.0));
    // patches.back()->rotate2D(M_PI);

    // // Bottom
    // patches.push_back(genLinkMesh0(nEh, nEa/2, nEz, (H-2*s)/2.0, s));
    // patches.back()->rotate2D(-M_PI/2.0);
    // patches.push_back(genLinkMesh1(nEh, nEa/2, nEz, (H-2*s)/2.0, s));
    // patches.back()->rotate2D(-M_PI/2.0);

    // // Bottom-right
    // patches.push_back(genSquare(nEh, nEc, nEz, s, (H-2*s)/2.0, (c-2.0*s)/2.0));
    // patches.back()->rotate2D(-M_PI/2.0);
}

RCP<MultiPatchMeshGenerator> genGeom()
{
    // Number of elements
    int nEr = 10; // Number of radial elements in quarter plate
    int nEa = 20; // Number of elements in angular direction
    int nEz = -1; // Number of elements in z direction
    int nEh = 5;
    int nEl = 6;
    int nEc = 10;

    // Domain size
    double L = 8.0;  // Length (x)
    double H = 4.0;  // Height (y)
    double W = 0.3;  // Width  (z)

    // Holes
    double r = 0.2;  // Radius
    double c = 2.0;  // Distance between holes
    double s = 0.5;  // Transition (circle to square) distance

    // Vector of patches
    vector<RCP<MeshCreator>> patches;

    // Left half
    genHalfPlate(nEr, nEa, nEh, nEl, nEc, nEz, L, H, W, r, c, s, patches);

    // // Right half
    // genHalfPlate(nEr, nEa, nEh, nEl, nEc, nEz, L, H, W, r, c, s, patches);

    // Transform
    for (auto p: patches)
        p->translate(-c/2.0, 0.0, 0.0);
    // for (size_t i = 16; i < patches.size(); i++)
    //     patches[i]->rotate2D(M_PI);

    // Join patches
    RCP<MultiPatchMeshGenerator> mpatch = rcp(new MultiPatchMeshGenerator);
    mpatch->setMeshes(patches, MultiPatchConnectivity::Unclamped, 0.00001);
    mpatch->Update();
    mpatch->scaleZ(W);
    mpatch->translateZ(-W/2.0);

    return mpatch;
}

int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    MPI_Init(nullptr, nullptr);

    // Define parameters of the model
    double force = 0.0;
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create mesh
    // RCP<MultiPatchMeshGenerator> mpatch = genGeom();

    RCP<StructMeshGenerator> mesh0 = rcp(new StructMeshGenerator);
    mesh0->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    mesh0->genStructMesh(2, 2);

    RCP<StructMeshGenerator> mesh1 = rcp(new StructMeshGenerator);
    mesh1->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    mesh1->genStructMesh(2, 2);
    mesh1->rotate2D(M_PI/2.0, {0.5, 0.5, 0.0});
    mesh1->translate(-1.0, 1.0, 0.0);

    RCP<StructMeshGenerator> mesh2 = rcp(new StructMeshGenerator);
    mesh2->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    mesh2->genStructMesh(2, 2);
    mesh2->rotate2D(M_PI, {0.5, 0.5, 0.0});
    // mesh2->scale(0.4);
    // mesh2->translate(-0.4, 0.6, 0.0);
    mesh2->translate(-1.0, 0.0, 0.0);

    {
        RCP<MultiPatchMeshGenerator> mpatch0 = rcp(new MultiPatchMeshGenerator);
        mpatch0->setMeshes({mesh0, mesh1}, MultiPatchConnectivity::LinearConstraints, 0.00001);
        mpatch0->Update();


        // Distribute mesh
        RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
        disMesh->setMesh(mpatch0);
        disMesh->setBalanceMesh(false);
        disMesh->Update();
        disMesh->printFileLegacyVtk("Mesh0");
    }
    {
        // Distribute mesh
        RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
        disMesh->setMesh(mesh2);
        disMesh->setBalanceMesh(false);
        disMesh->Update();
        disMesh->printFileLegacyVtk("Mesh2");

    }

    RCP<MultiPatchMeshGenerator> mpatch2 = rcp(new MultiPatchMeshGenerator);
    mpatch2->setMeshes({mesh0, mesh1, mesh2}, MultiPatchConnectivity::Unclamped, 0.00001);
    mpatch2->Update();

    // Distribute mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mpatch2);
    disMesh->setBalanceMesh(false);
    disMesh->Update();
    disMesh->printFileLegacyVtk("Mesh");


    // MPI_Finalize();
    // return 0;

    // **************************************************************//
    // *****               DOFHANDLER CREATION                  *****//
    // **************************************************************//

    // DOFhandler
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    // Boundary conditions
    for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    {
        double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
        double y = dofHand->mesh->nodeCoord(i, 1, IndexType::Local);
        double z = dofHand->mesh->nodeCoord(i, 2, IndexType::Local);
        if (disMesh->_pDim == 2)
        {
            // if (x < 0.001)
            //     dofHand->setConstraint(0, i, IndexType::Local, -2.0);
            // if (x > 1.999)
            //     dofHand->setConstraint(0, i, IndexType::Local, 1.0);

            // double r = sqrt(x*x+y*y+z*z);
            // if (r <= 0.201)
            // // if (x <= 1.0001)
            //     dofHand->setConstraint(0, i, IndexType::Local, 1.0);
            // double r = sqrt((x+1.0)*(x+1.0)+y*y);
            // if (r < 0.2001)
            //     dofHand->setConstraint(0, i, IndexType::Local, 1.0);

            if (x >= 0.999)
                dofHand->setConstraint(0, i, IndexType::Local, 3.0);
            if (x <= -0.99)
                dofHand->setConstraint(0, i, IndexType::Local, 2.0);
        }
        else if (disMesh->_pDim == 3)
        {
            // if (x < 0.005 and z >= 0.5)
            //     dofHand->setConstraint(0, i, IndexType::Local, -2.0);
            // if (x > 1.999)
            //     dofHand->setConstraint(0, i, IndexType::Local, 1.0);
            // if (z < 0.0005)
            //     dofHand->setConstraint(0, i, IndexType::Local, -3.0);
            // if (z > 1.4999)
            //     dofHand->setConstraint(0, i, IndexType::Local, 3.0);
            double r = sqrt((x+1.0)*(x+1.0)+y*y);
            if (r < 0.2001)
                dofHand->setConstraint(0, i, IndexType::Local, 2.0);
            r = sqrt((x-1.0)*(x-1.0)+y*y);
            if (r < 0.2001)
                dofHand->setConstraint(0, i, IndexType::Local, 3.0);
            if (x <= -3.999)
                dofHand->setConstraint(0, i, IndexType::Local, 0.0);
            if (x >= 3.999)
                dofHand->setConstraint(0, i, IndexType::Local, 1.0);

        }
    }
    dofHand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ", pow(disMesh->_bfOrder+1, disMesh->_pDim));
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->Update();


    // **************************************************************//
    // *****                  SOLVER CREATION                   *****//
    // **************************************************************//

    // RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver->setDefaultParameters();
    // solver->Update();

    RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setTolerance(1.E-8);
    solver->setMaxNumIterations(500);
    solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilu);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::Extreme);
    solver->setDefaultParameters();
    solver->Update();


    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//
    bool status = solver->solve();
    solver->UpdateSolution();

    dofHand->printFile("Poisson");
    dofHand->printFileLegacyVtk("Poisson", true);


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
