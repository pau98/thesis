/*
**************************************************************************************************
hiperlife - High Performance Library for Finite Elements
Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
Copyright (c) 2018 Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
**************************************************************************************************
hiperlife is under GNU General Public License ("GPL").
GNU General Public License ("GPL") copyright permissions statement:
This file is part of hiperlife, hiperlife is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by the Free Software Foundation,
either version 3 of the License, or (at your option) any later version.
hiperlife is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program.
If not, see <http://www.gnu.org/licenses/>.
**************************************************************************************************
*/
////////////////////////////////////////////////////////////////////////



/// C++ headers
#include <iostream>
#include <mpi.h>

/// Trilinos headers
#include <Teuchos_RCP.hpp> // Trilinos header that defines RCP objects

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Iterative_Belos.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_Tensor.h"

void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    // This function fills the elemental matrix and right-hand side
    //   vector at a given integration point. All the necessary
    //   information is in the FillStructure object fillStr that we
    //   passed as argument to this function, such as the elemental
    //   matrix (K), the right-hand side vector (rhs_k), the
    //   UserStructure, and the SubFillStructures. In turn, the
    //   SubFillStructures include all the necessary variables at an
    //   integration point (eg. spatial coordinates, basis functions
    //   and derivatives).
    // Note that there are as many SubFillStructures as DOFHandlers.

    //===========          Initialize variables           ==========//
    //
    // First, we get the model parameters from the UserStructure
    double force = fillStr->userStr->dparam[0];
    //
    // Then, we get the SubFillStructure for the dofHand from our
    //   fillStr as follows
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    // which we use to declare the variables:
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension

    // //Coordinates of the nodes in the element. We store this data
    // //in a hiperlife tensor of order 2, i.e. a matrix. It has eNN
    // //rows and nDim columns.
    // tensor<double,2> nborCoords(subFill.nborCoords.data(),eNN,nDim);

    //Basis functions evaluated at the Gauss point. The basis functions
    // are a vector (tensor of order 1) of size eNN.
    tensor<double,1,false>  bf(subFill.nborBFsDers(0),eNN);

    //To make the calculations, we transform the local basis functions
    //(more precisely, their derivatives) from local coordinates to car
    //tesian (global) coordinates. The derivatives of the basis functions
    //in global coordinates are a matrix of size eNN*pDim
    tensor<double,2> Dbf_g(eNN,pDim);
    double jac; //Jacobian (differential of line/area/volume)
    //To calculate the global basis functions and the jacobian we call the
    //function gradients from the namespace GlobalBasisFunctions
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

    //We are going to fill the matrix and the right hand side. Here, we define
    //the matrix Ak (eNN*eNN) and the vector Bk (eNN).
    tensor<double,2,false> Ak(fillStr->Ak(0, 0).data(),eNN,eNN);
    tensor<double,1,false> Bk(fillStr->Bk(0).data(),eNN);

    //=====================  Fill linear system =====================//
    //
    // We loop through the neighboring nodes to fill both the matrix
    //   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            // Compute the product of the gradient of the basis functions
            double dotij{};
            for (int d = 0; d < pDim; d++)
                dotij += Dbf_g(i,d)*Dbf_g(j,d);

            // Fill matrix
            Ak(i,j) += jac * dotij;
        }

        // Fill RHS
        Bk(i) += jac * bf(i) * force;
    }

}

int main()
{
    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;

    int myRank, numProcs;
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    MPI_Comm_size(MPI_COMM_WORLD, &numProcs);

    ///=============== Define parameters of the model ===============///
    double force = 0.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;

    //Solvers and preconditioners
    vector<string> precList = {"Ilu"};//, "Ilut"};
    vector<string> iterSolvList = {"GMRES"};//, "TFQMR", "CG"};
    vector<string> direSolvList = {"MUMPS"};//, "KLU"};
    vector<int> sizeList = {(int)std::round(128*sqrt(3.0)), 256, 512, 1024, 2048};

    int x = std::round(128*sqrt(3.0)+ 0.5);


    ofstream myfile;
    if (myRank == 0)
    {
        string fname = "output" + to_string(numProcs) + ".dat";
        myfile.open(fname, std::ofstream::out | std::ofstream::trunc);
    }

    for (int t = 0; t < sizeList.size(); t++)
    {
        /// **************************************************************//
        /// *****                   MESH CREATION                    *****//
        /// **************************************************************//
        RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
        structMesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
        structMesh->genStructMesh(sizeList[t]);

        ///===========             Distribute mesh            ===========///
        RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
        disMesh->setMesh(structMesh);
        disMesh->setBalanceMesh(true);
        disMesh->Update();

        //Amesos
        if (false)
        {
            for (int s = 0; s < direSolvList.size(); s++)
            {
                if (myRank == 0)
                    cout << endl << endl << sizeList[t] << " Amesos " << direSolvList[s] << endl << endl;

                /// **************************************************************//
                /// *****               DOFHANDLER CREATION                  *****//
                /// **************************************************************//

                ///===========           Create DOFHandler            ===========///
                RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
                dofHand->setNameTag("dofHand");
                dofHand->setNumDOFs(1);
                dofHand->Update();

                ///===========          Boundary conditions          ===========///
                dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x) { return x; });
                dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x) { return x * x; });
                dofHand->UpdateGhosts();


                /// **************************************************************//
                /// *****               HIPERPROBLEM CREATION                *****//
                /// **************************************************************//
                RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
                hiperProbl->setUserStructure(userStr);
                hiperProbl->setDOFsHandlers({dofHand});
                hiperProbl->setIntegration("Integ", {"dofHand"});
                hiperProbl->setElementFillings("Integ", LS);
                hiperProbl->setCubatureGauss("Integ", 4);
                hiperProbl->Update();


                /// **************************************************************//
                /// *****                  SOLVER CREATION                   *****//
                /// **************************************************************//
                RCP<AmesosDirectLinearSolver> solver = rcp(new AmesosDirectLinearSolver());
                solver->setHiPerProblem(hiperProbl);
                if (direSolvList[s] == "KLU")
                    solver->setSolver(AmesosDirectLinearSolver::Solver::Klu);
                else if (direSolvList[s] == "MUMPS")
                    solver->setSolver(AmesosDirectLinearSolver::Solver::Mumps);
                solver->setUseTranspose(false);
                solver->setSymbolicFactorization(true);
                solver->setNumericFactorization(true);
                solver->setScaleMethod(true);
                solver->setRefactorize(false);
                solver->setMatrixType(AmesosDirectLinearSolver::MatrixType::General);
                solver->Update();

                /// **************************************************************//
                /// *****                SOLVE HIPERPROBLEM                  *****//
                /// **************************************************************//
                bool converged = solver->solve();
                solver->output(AmesosDirectLinearSolver::Verbosity::High);

                //Output info
                if (myRank == 0)
                {
                    myfile << std::setprecision(16)
                           << sizeList[t] << " "
                           << numProcs << " "
                           << "Amesos" << " "
                           << direSolvList[s] << " "
                           << " " << " ";
                    if (converged == true)
                        myfile << solver->time(AmesosDirectLinearSolver::TimerName::Total) <<  " " << endl;
                    else
                        myfile << 0.0 << endl;
                }
            }
        }

        //Amesos2
        if (true)
        {
            for (int s = 0; s < direSolvList.size(); s++)
            {
                if (myRank == 0)
                    cout << endl << endl << sizeList[t] << " Amesos2 " << direSolvList[s] << endl << endl;

                /// **************************************************************//
                /// *****               DOFHANDLER CREATION                  *****//
                /// **************************************************************//

                ///===========           Create DOFHandler            ===========///
                RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
                dofHand->setNameTag("dofHand");
                dofHand->setNumDOFs(1);
                dofHand->Update();

                ///===========          Boundary conditions          ===========///
                dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x) { return x; });
                dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x) { return x * x; });
                dofHand->UpdateGhosts();


                /// **************************************************************//
                /// *****               HIPERPROBLEM CREATION                *****//
                /// **************************************************************//
                RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
                hiperProbl->setUserStructure(userStr);
                hiperProbl->setDOFsHandlers({dofHand});
                hiperProbl->setIntegration("Integ", {"dofHand"});
                hiperProbl->setElementFillings("Integ", LS);
                hiperProbl->setCubatureGauss("Integ", 4);
                hiperProbl->Update();


                /// **************************************************************//
                /// *****                  SOLVER CREATION                   *****//
                /// **************************************************************//
                RCP<Amesos2DirectLinearSolver> solver = rcp(new Amesos2DirectLinearSolver());
                solver->setHiPerProblem(hiperProbl);
                if (direSolvList[s] == "KLU")
                    solver->setSolver(Amesos2DirectLinearSolver::Solver::Klu);
                else if (direSolvList[s] == "MUMPS")
                    solver->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
                solver->setUseTranspose(false);
                solver->setSymbolicFactorization(true);
                solver->setNumericFactorization(true);
                solver->Update();

                /// **************************************************************//
                /// *****                SOLVE HIPERPROBLEM                  *****//
                /// **************************************************************//
                bool converged = solver->solve();
                solver->output(Amesos2DirectLinearSolver::Verbosity::High);

                //Output info
                if (myRank == 0)
                {
                    myfile << std::setprecision(16)
                           << sizeList[t] << " "
                           << numProcs << " "
                           << "Amesos2" << " "
                           << direSolvList[s] << " "
                           << " " << " ";
                    if (converged == true)
                        myfile << solver->time(Amesos2DirectLinearSolver::TimerName::Total) <<  " " << endl;
                    else
                        myfile << 0.0 << endl;
                }
            }
        }

        //AztecOO
        if (false and t < 3)
        {
            for (int s = 0; s < iterSolvList.size(); s++)
            {
                for (int p = 0; p < precList.size(); p++)
                {
                    if (myRank == 0)
                        cout << endl << endl << sizeList[t] << " AztecOO " << iterSolvList[s] << " " << precList[p] << endl << endl;
                    /// **************************************************************//
                    /// *****               DOFHANDLER CREATION                  *****//
                    /// **************************************************************//
                    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
                    dofHand->setNameTag("dofHand");
                    dofHand->setNumDOFs(1);
                    dofHand->Update();

                    dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x) { return x; });
                    dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x) { return x * x; });
                    dofHand->UpdateGhosts();

                    /// **************************************************************//
                    /// *****               HIPERPROBLEM CREATION                *****//
                    /// **************************************************************//
                    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
                    hiperProbl->setUserStructure(userStr);
                    hiperProbl->setDOFsHandlers({dofHand});
                    hiperProbl->setIntegration("Integ", {"dofHand"});
                    hiperProbl->setElementFillings("Integ", LS);
                    hiperProbl->setCubatureGauss("Integ", 4);
                    hiperProbl->Update();


                    /// **************************************************************//
                    /// *****                  SOLVER CREATION                   *****//
                    /// **************************************************************//
                    RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
                    solver->setHiPerProblem(hiperProbl);
                    solver->setTolerance(1.E-6);
                    solver->setMaxNumIterations(500);
                    solver->setKrylovSpaceMaxSize(500);
                    solver->setConvergenceCriteria(AztecOOIterativeLinearSolver::ConvergenceCriteria::Relative);
                    if (iterSolvList[s] == "CG")
                        solver->setSolver(AztecOOIterativeLinearSolver::Solver::ConjGrad);
                    else if (iterSolvList[s] == "GMRES")
                        solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
                    else if (iterSolvList[s] == "TFQMR")
                        solver->setSolver(AztecOOIterativeLinearSolver::Solver::Tfqmr);
                    else
                        throw runtime_error("AztecOO: Solver not specified");
                    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
                    if (precList[p] == "Ilu")
                        solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilu);
                    else if (precList[p] == "Ic")
                        solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Icc);
                    else if (precList[p] == "Ilut")
                        solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
                    else
                        throw runtime_error("AztecOO: SubdomainSolve not specified");
                    solver->Update();

                    /// **************************************************************//
                    /// *****                SOLVE HIPERPROBLEM                  *****//
                    /// **************************************************************//
                    bool converged = solver->solve();
                    solver->output(AztecOOIterativeLinearSolver::Verbosity::High);

                    //Output info
                    if (myRank == 0)
                    {
                        myfile << std::setprecision(16)
                               << sizeList[t] << " "
                               << numProcs << " "
                               << "AztecOO" << " "
                               << iterSolvList[s] << " "
                               << precList[p] << " ";
                        if (converged == true)
                            myfile << solver->time(AztecOOIterativeLinearSolver::TimerName::Solver) << endl;
                        else
                            myfile << 0.0 << endl;
                    }
                }
            }
        }

        //Belos
        if (false)
        {
            for (int s = 0; s < iterSolvList.size(); s++)
            {
                for (int p = 0; p < precList.size(); p++)
                {
                    if (myRank == 0)
                        cout << endl << endl << sizeList[t] << " Belos " << iterSolvList[s] << " " << precList[p] << endl << endl;

                    /// **************************************************************//
                    /// *****               DOFHANDLER CREATION                  *****//
                    /// **************************************************************//

                    ///===========           Create DOFHandler            ===========///
                    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
                    dofHand->setNameTag("dofHand");
                    dofHand->setNumDOFs(1);
                    dofHand->Update();

                    ///===========          Boundary conditions          ===========///
                    dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x) { return x; });
                    dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x) { return x * x; });
                    dofHand->UpdateGhosts();


                    /// **************************************************************//
                    /// *****               HIPERPROBLEM CREATION                *****//
                    /// **************************************************************//
                    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
                    hiperProbl->setUserStructure(userStr);
                    hiperProbl->setDOFsHandlers({dofHand});
                    hiperProbl->setIntegration("Integ", {"dofHand"});
                    hiperProbl->setElementFillings("Integ", LS);
                    hiperProbl->setCubatureGauss("Integ", 4);
                    hiperProbl->Update();


                    /// **************************************************************//
                    /// *****                  SOLVER CREATION                   *****//
                    /// **************************************************************//
                    RCP<BelosIterativeLinearSolver> solver = rcp(new BelosIterativeLinearSolver());
                    solver->setHiPerProblem(hiperProbl);
                    solver->setTolerance(1.E-6);
                    solver->setMaxNumIterations(500);
                    solver->setKrylovSpaceMaxSize(500);
                    solver->setMaxNumRestarts(500);
                    if (iterSolvList[s] == "CG")
                        solver->setSolver(BelosIterativeLinearSolver::Solver::BlockCG);
                    else if (iterSolvList[s] == "GMRES")
                        solver->setSolver(BelosIterativeLinearSolver::Solver::PseudoBlockGMRES);
                    else if (iterSolvList[s] == "TFQMR")
                        solver->setSolver(BelosIterativeLinearSolver::Solver::TFQMR);
                    else
                        throw runtime_error("Belos: Solver not specified");
                    if (precList[p] == "Ilu")
                        solver->setPreconditioner(BelosIterativeLinearSolver::Preconditioner::Ilu);
                    else if (precList[p] == "Ic")
                        solver->setPreconditioner(BelosIterativeLinearSolver::Preconditioner::Ic);
                    else if (precList[p] == "Ilut")
                        solver->setPreconditioner(BelosIterativeLinearSolver::Preconditioner::Ilut);
                    else
                        throw runtime_error("Belos: SubdomainSolve not specified");
                    solver->setPreconditionerSide(BelosIterativeLinearSolver::PreconditionerSide::Left);
                    solver->Update();

                    /// **************************************************************//
                    /// *****                SOLVE HIPERPROBLEM                  *****//
                    /// **************************************************************//
                    bool converged = solver->solve();
                    solver->output(BelosIterativeLinearSolver::Verbosity::High);

                    //Output info
                    if (myRank == 0)
                    {
                        myfile << std::setprecision(16)
                               << sizeList[t] << " "
                               << numProcs << " "
                               << "Belos" << " "
                               << iterSolvList[s] << " "
                               << precList[p] << " ";
                        if (converged == true)
                            myfile << solver->time(BelosIterativeLinearSolver::TimerName::Solver) << endl;
                        else
                            myfile << 0.0 << endl;
                    }
                }
            }
        }
    }


    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    myfile.close();

    MPI_Finalize();
    return 0;
}
