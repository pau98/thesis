
// C++ headers
#include <iostream>
#include <mpi.h>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_BasicMeshGenerator.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_Tensor.h"
#include "hl_SurfLagrParam.h"
#include "hl_MeshLoader.h"


void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void RHS_Border(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void LS_Border(Teuchos::RCP<hiperlife::FillStructure> fillStr);

int main()
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;

    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//
    MPI_Init(nullptr, nullptr);

    string geom = "Tetrah";
    string fMesh;
    if (geom == "Prism" or geom == "Tetrah")
        fMesh = "../meshes/prisma_prova.msh";
    else if (geom == "Googles")
        fMesh = "/home/guille/3Dgoogles.msh";
    // string fMesh = "/home/guille/untitled.msh";
    // string fMesh = "/home/guille/Programs/HPLFEapps/organoid/meshes/3Dgoogles_0.01.msh";

    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Load mesh
    RCP<MeshLoader> mesh = rcp(new MeshLoader);
    mesh->setMesh(ElemType::Tetrah, BasisFuncType::Lagrangian, 1);
    mesh->loadMesh(fMesh, MeshType::Sequential);
    bool tetra = true;

    // RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    // mesh->setMesh(ElemType::Parallelep, BasisFuncType::Lagrangian, 1);
    // mesh->genStructMesh(2,4,2);
    // mesh->scaleY(2.0);
    // bool tetra = false;

    vector<double> distCoords = {0.0, 1.0, 0.0, 0.0,
                                 0.0, 0.0, 1.0, 0.0,
                                 0.0, 0.0, 0.0, 1.0};
    vector<int> distConnec = {0, 1, 2, 3};
    vector<int> distCreases = {0, 1, 1, 1,
                               1, 1, 1, 1};
    vector<int> distElemFlags = {0};
    RCP<BasicMeshGenerator> bmesh = rcp(new BasicMeshGenerator);
    bmesh->setMeshType(MeshType::Parallel);
    bmesh->setMesh(ElemType::Tetrah, BasisFuncType::Lagrangian, 1);
    bmesh->setLocNElem(1);
    bmesh->setLocNPts(4);
    bmesh->setDistCoords(distCoords);
    bmesh->setDistConnec(distConnec);
    bmesh->setDistCreases(distCreases);
    bmesh->setDistElemFlags(distElemFlags);

    // Distribute the mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    if (geom == "Prism" or geom == "Googles")
        disMesh->setMesh(mesh);
    else
        disMesh->setMesh(bmesh);
    disMesh->setBalanceMesh(false);
    disMesh->Update();

    // Mark elements for integration and add creases
    for (int i = 0; i < disMesh->loc_nPts(); i++)
    {
        vector<double> x = disMesh->nodeCoords(i, IndexType::Local);
        if (geom == "Prism")
        {
            if (x[1] > 1.999)
                disMesh->_nodeFlags->setValue(0, i, IndexType::Local, 1);
        }
        else if (geom == "Googles")
        {
            double dC1 = sqrt((x[0]-0.4)*(x[0]-0.4)+(x[1]-0.25)*(x[1]-0.25));
            if (dC1 < 0.022)
                disMesh->_nodeFlags->setValue(0, i, IndexType::Local, 1);
        }
    }
    disMesh->_nodeFlags->UpdateGhosts();

    // Print mesh
    disMesh->printFileLegacyVtk("mesh");

    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    // Boundary conditions
    for (int i = 0; i < disMesh->loc_nPts(); i++)
    {
        // Get coordinates of the node
        vector<double> x = disMesh->nodeCoords(i, IndexType::Local);

        // Prism
        if (geom == "Prism")
        {
            // Fix faces
            if (x[1] < 0.001)
                dofHand->setConstraint(0, i, IndexType::Local, 0.0);
        }
    }
    dofHand->UpdateGhosts();

    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // Hiperproblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setDOFsHandlers({dofHand});
    int nquad = (tetra) ? 4 : 8;
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ", nquad);
    hiperProbl->setElementFillings("Integ", LS);

    hiperProbl->setIntegration("BorderInteg", {"dofHand"});
    hiperProbl->setCubatureBorderGauss("BorderInteg", 1);
    hiperProbl->setElementFillings("BorderInteg", LS_Border);

    hiperProbl->setGlobalIntegrals({"BorderArea"});
    hiperProbl->Update();

    // Solver
    RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setTolerance(1.E-8);
    solver->setMaxNumIterations(500);
    solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
    solver->setDefaultParameters();
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->Update();


    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    // Solve
    solver->solve();
    hiperProbl->UpdateSolution();

    // Print
    dofHand->printFileLegacyVtk("Poisson", true);
    if (dofHand->myRank() == 0)
        cout << std::scientific << std::setprecision(5) << "Border Length = " << hiperProbl->globalIntegral("BorderLength");


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}

void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using std::vector;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& nborCoords  = subFill.nborCoords;  // Vector of node coordinates
    tensor<double,1,false> bf(subFill.nborBFs(),eNN);
    tensor<double,2,false> Ak(fillStr->Ak(0, 0).data(),eNN,eNN);
    tensor<double,1,false> Bk(fillStr->Bk(0).data(),eNN);

    double x[3]={};
    for (int i = 0; i < eNN; i++)
        for (int d = 0; d < nDim; d++)
            x[d] += nborCoords[nDim*i+d] * bf(i);


    // Derivatives of the basis functions
    double jac;
    tensor<double,2> Dbf_g(eNN,pDim);
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

    //=====================  Fill linear system =====================//
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            // Compute the product of the gradient of the basis functions
            double dotij{};
            for (int d = 0; d < pDim; d++)
                dotij += Dbf_g(i,d)*Dbf_g(j,d);

            // Fill matrix
            Ak(i,j) += jac * dotij;
        }
    }

    return;
}

void LS_Border(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using std::vector;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;
    
    // Variables
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;                       // degrees of freedom
    int eNN  = subFill.eNN;                          // number of nodes of the neighborhood
    int pDim = subFill.pDim;                         // dimension of the space of the problem
    int nDim = subFill.nDim;                         // dimension of the space of the problem
    vector<double>& nborCoords  = subFill.nborCoords;  // Vector of node coordinates
    double *bf  = subFill.nborBFs();

    double x[3]={};
    for (int i = 0; i < eNN; i++)
        for (int d = 0; d < nDim; d++)
            x[d] += nborCoords[nDim*i+d] * bf[i];

    // Compute deformation gradient
    tensor<double, 2> G(nDim, nDim);
    GlobalBasisFunctions::deformationGradient(G.data(), subFill);

    // Compute tangents (vectors):
    vector<double> tRef(6);
    tRef = subFill.tangentsBoundaryRef();
    vector<double> t0(nDim, 0.0);
    vector<double> t1(nDim, 0.0);
    for (int i = 0; i < nDim; i++)
    {
        for (int j = 0; j < nDim; j++)
        {
            t0[i] += tRef[j]*G(i,j);
            t1[i] += tRef[nDim+j]*G(i,j);
        }
    }

    // Compute normal: (xu x xv)
    vector<double> n(3,0.0);
    Math::Cross(n.data(), t0.data(), t1.data());

    // Compute jacobian: |n| = |xu x xv|
    double jac = Math::Norm3D(n.data());


    // Print
    cout << subFill.cubaInfo.cubaType << endl;
    cout << "x   = " << x[0] << " " << x[1] << " " << x[2] << endl;
    cout << "tR0 = " << tRef[0] << " " << tRef[1] << " " << tRef[2] << endl;
    cout << "tR1 = " << tRef[3] << " " << tRef[4] << " " << tRef[5] << endl;
    cout << "t0  = " << t0[0] << " " << t0[1] << " " << t0[2] << endl;
    cout << "t1  = " << t1[0] << " " << t1[1] << " " << t1[2] << endl;
    cout << "n   = " << n[0] << " " << n[1] << " " << n[2] << endl;
    cout << jac << " " << subFill.wk_sample << endl;
    cout << endl;

    // Open file to write global integrals and write headers
    ofstream gIntegFile;
    gIntegFile.open("BoundaryPoints.csv", std::ios_base::app);
    gIntegFile << x[0] << " " << x[1] << " " << x[2] << " "
               << t0[0]+x[0] << " " << t0[1]+x[1] << " " << t0[2]+x[2] << " "
               << t1[0]+x[0] << " " << t1[1]+x[1] << " " << t1[2]+x[2] << " "
               << n[0]+x[0] << " " << n[1]+x[1] << " " << n[2]+x[2] << " "
               << subFill.cubaInfo.cubaType << endl;
    gIntegFile.close();


    // Fill RHS
    for (int i = 0; i < eNN; i++)
        fillStr->Bk(0)[i*DOF] += jac*bf[i];


    fillStr->addToGlobalIntegral("BorderArea", jac);

    return;
}
