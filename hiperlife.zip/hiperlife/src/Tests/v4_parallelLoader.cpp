
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_MeshLoader.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_Timer.h"

using namespace hiperlife;
using namespace std;

using Teuchos::rcp;
using Teuchos::RCP;


int main()
{

    //Initialize
    MPI_Init(nullptr, nullptr);
    Timer timer({"loadSeq", "disMeshSeq", "loadPar", "disMeshPar"});


    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType elemType = ElemType::Triang;
    int order = 1;

    ///////////////////////////////////////////////////////////////////////
    //Create an structured mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(elemType, bfType, order);
    structMesh->genRectangle(5, 5, 1.0, 2.1);
    // structMesh->printMesh("struct");

    //Distribute the mesh
    RCP<DistributedMesh> dismesh = rcp(new DistributedMesh);
    dismesh->setMesh(structMesh);
    dismesh->setBalanceMesh(true, 0.001);
    dismesh->Update();
    dismesh->printFileLegacyVtk("struct");


    ///////////////////////////////////////////////////////////////////////
    //Store name of the mesh
    std::string mesh = "/home/guille/simulations/meshes/circleF_n4.vtk";
    mesh = "struct.vtk";


    ///////////////////////////////////////////////////////////////////////
    //Load sequential
    if (timer.myRank() == 0)
        cout << "Load sequential mesh" << endl;
    timer.start("loadSeq");
    RCP<MeshLoader> loadSeq = rcp(new MeshLoader);
    loadSeq->setMesh(elemType, bfType, order);
    loadSeq->loadMesh(mesh, MeshType::Sequential);
    // loadSeq->printMesh("Sequential");
    timer.end("loadSeq");

    //Distribute sequential
    if (timer.myRank() == 0)
        cout << "Distribute sequential mesh" << endl;
    timer.start("disMeshSeq");
    RCP<DistributedMesh> disMeshSeq = rcp(new DistributedMesh);
    disMeshSeq->setMesh(loadSeq);
    disMeshSeq->setBalanceMesh(true, 0.01);
    disMeshSeq->Update();
    disMeshSeq->printFileLegacyVtk("loadSeq");
    timer.end("disMeshSeq");


    ///////////////////////////////////////////////////////////////////////
    //Load parallel
    if (timer.myRank() == 0)
        cout << "Load parallel mesh" << endl;
    timer.start("loadPar");
    RCP<MeshLoader> loadPar = rcp(new MeshLoader);
    loadPar->setMesh(elemType, bfType, order);
    loadPar->loadLegacyVtk(mesh, hiperlife::MeshType::Parallel);
    // loadPar->printMesh("Parallel");
    timer.end("loadPar");

    //Distribute parallel
    if (timer.myRank() == 0)
        cout << "Distribute parallel mesh" << endl;
    timer.start("disMeshPar");
    RCP<DistributedMesh> disMeshPar = rcp(new DistributedMesh);
    disMeshPar->setMesh(loadPar);
    disMeshPar->setBalanceMesh(true);
    disMeshPar->Update();
    disMeshPar->printFileLegacyVtk("loadPar");
    timer.end("disMeshPar");


    ///////////////////////////////////////////////////////////////////////
    timer.printTesting("  Timing:");

    MPI_Finalize();
    return 0;
}
