
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_MeshLoader.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_GlobalBasisFunctions.h"


using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;



void LS(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = 1.0;
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFsDers(0);  // Local shape function
    // double* glNa = subFill.nborBFsDers(1); // Local shape function derivatives
    double gNa[eNN*pDim], jac;
    // GlobalBasisFunctions::gradients(gNa, jac, eNN, pDim, nDim, xe_nodes.data(), glNa);
    GlobalBasisFunctions::gradients(gNa, jac, subFill);

    vector<double> x(pDim);
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d]  * Na[i];
    }

    // if (x[0] < 0.9)
    // force *= x[0];

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}


int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    MPI_Init(nullptr, nullptr);
    int myRank;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//
    if (myRank == 0)
        cout << "Loading the mesh" << endl;
    RCP<MeshLoader> mesh = rcp(new MeshLoader);
    mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // mesh->loadMesh("del.msh", MeshType::Sequential);
    mesh->loadMesh("test_"+std::to_string(myRank+1)+".msh", MeshType::Parallel);
    // mesh->loadMesh("h1-8_"+std::to_string(myRank+1)+".msh", MeshType::Parallel);
    // mesh->loadMesh("h1-8.vtk", MeshType::Parallel);
    // mesh->printMesh("asd");

    // Distribute mesh
    if (myRank == 0)
        cout << "Distributing the mesh" << endl;
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(false);
    disMesh->Update();

    // disMesh->printFileLegacyVtk("gmsh");


    if (true)
    {
        /// **************************************************************//
        /// *****               DOFHANDLER CREATION                  *****//
        /// **************************************************************//

        ///===========           Create DOFHandler            ===========///
        if (myRank == 0)
            cout << "Creating DOFsHandler" << endl;
        RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
        dofHand->setNameTag("dofHand");
        dofHand->setDOFs({"d"});
        dofHand->Update();

        ///===========          Boundary conditions          ===========///
        for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
        {
            double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
            double y = dofHand->mesh->nodeCoord(i, 1, IndexType::Local);
            double z = dofHand->mesh->nodeCoord(i, 2, IndexType::Local);
            if (x < 240+0.01)
                dofHand->setConstraint(0, i, IndexType::Local, 1.0);
            if (x > 720-0.01)
                dofHand->setConstraint(0, i, IndexType::Local, y);
        }
        dofHand->UpdateGhosts();


        /// **************************************************************//
        /// *****               HIPERPROBLEM CREATION                *****//
        /// **************************************************************//
        if (myRank == 0)
            cout << "Creating hiperproblem" << endl;
        RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
        hiperProbl->setDOFsHandlers({dofHand});
        hiperProbl->setIntegration("Integ", {"dofHand"});
        hiperProbl->setElementFillings("Integ", LS);
        hiperProbl->setCubatureGauss("Integ", computeDefaultNumGPts(disMesh->elemType(), disMesh->_bfOrder));
        hiperProbl->Update();


        /// **************************************************************//
        /// *****                  SOLVER CREATION                   *****//
        /// **************************************************************//
        if (myRank == 0)
            cout << "Creating solver" << endl;
        RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
        solver->setHiPerProblem(hiperProbl);
        solver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
        solver->setDefaultParameters();
        solver->Update();


        /// **************************************************************//
        /// *****                SOLVE HIPERPROBLEM                  *****//
        /// **************************************************************//
        if (myRank == 0)
            cout << "Solving the problem" << endl;
        solver->solve();
        if (myRank == 0)
            cout << "Updating solution" << endl;
        solver->UpdateSolution();

        if (myRank == 0)
            cout << "Printing results" << endl;
        dofHand->printFileLegacyVtk("Poisson", true);
    }

    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
