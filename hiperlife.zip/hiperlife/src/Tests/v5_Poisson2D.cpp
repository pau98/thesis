/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"


struct PoissonParameters
{
    enum RealParameters
    {
        force
    };

    HL_PARAMETER_LIST DefaultValues{
            {"force", -4.0}
    };
};

void CheckSolution(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::N, ttl::index::i;

    SubFillStructure &subFill = fillStr[0];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN = subFill.eNN;

    tensor<double, 2> Dbf(eNN, pDim);
    double jac;
    GlobalBasisFunctions::gradients(Dbf, jac, subFill);

    wrapper<double, 1> dofsI(subFill.nborDOFs.data(), eNN);
    wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
    wrapper<double, 1> bf(subFill.nborBFs(), eNN);
    tensor<double, 1> x(nDim);
    x = coordsI(N, i) * bf(N);

    const double u_numeric = dofsI(N) * bf(N);
    const double u_analytial = (x(0)-0.5)*(x(0)-0.5)+(x(1)-0.5)*(x(1)-0.5);//sin(M_PI*x(0))*sinh(M_PI*x(1)) / sinh(M_PI);
    const double error = jac * abs(u_numeric-u_analytial);
    fillStr.addToGlobalIntegral("error", error);
}

void ElementFillingPoisson(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::i;
    using ttl::index::I, ttl::index::J;

    double force = fillStr.getRealParameter(PoissonParameters::force);
    SubFillStructure& subFill = fillStr[0];
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int pDim = subFill.pDim;      // Number of parametric dimension

    wrapper<double, 1> bf(subFill. nborBFs(), eNN);
    tensor<double, 2> Dbf(eNN, pDim);
    double jac;
    GlobalBasisFunctions::gradients(Dbf, jac, subFill);

    wrapper<double,2> Ak(fillStr.Ak(0, 0).data(), eNN, eNN);
    wrapper<double,1> Bk(fillStr.Bk(0).data(), eNN);

    Bk(I) = jac * bf(I) * force;
    Ak(I, J) = jac * Dbf(I, i) * Dbf(J, i);
}

int main(int argc, char** argv)
{
    using namespace hiperlife;

    hiperlife::Init(argc, argv);

    ///=============== Define parameters of the model ===============///
    SmartPtr<ParamStructure> paramStruct = CreateParamStructure<PoissonParameters>();

    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//

    ///====================== Mesh generation ======================///
    ///
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Square;
    int bfOrder = 2;
    SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genStructMesh(4);
    
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0005;
    vector<int> phmodes = {5};
    
    auto phfunc = [&] (vector<double> pos)
    {
        double phr = 0.5*r0*(((pos[1]-c0)*(pos[1]-c0)+(pos[0]-c0)*(pos[0]-c0))/(r0*r0)-1.0);  //Circular phase field
        double phr2 = 0.0;
        for (int phm = 0; phm < phmodes.size(); phm++)
            phr2 += 0.005*r0*sin(phmodes[phm]*atan2(pos[1]-c0,pos[0]-c0));
        double ph = 0.5*(1.0+tanh((phr+phr2)/(sqrt(2.0)*eps)));
        return ph;
    };
    // int refmax = 3;
    // structMesh->threeRefine([=](double x,double y, double z){
    //                         double phval = phfunc({x,y});
    //                         if ((phval < 1.-1.0e-6) & (phval > 1.0e-6)) return 3;
    //                         if ((phval < 1.-1.0e-15) & (phval > 1.0e-15)) return 2;
    //                         if ((phval < 1.-1.0e-25) & (phval > 1.0e-25)) return 1;
    //                         return 0;
    //                         },refmax,{10,10,10,10});

    
    ///===========             Distribute mesh            ===========///
    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(structMesh);
    // disMesh->setVerbosity(Verbosity::High);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    vector<linearConstraint> constraints = disMesh->_linearConstraints;
    cout << "Number of constraints: " << constraints.size() << endl;
    for (auto cnstr:constraints)
    {

        cout << "Slave: " << cnstr.slave << endl;
        cout << "Masters: " << endl;
        for (auto mstr:cnstr.masters)
            cout << mstr << ", " ;
        cout << endl;
        cout << "Weights: " << endl;
        for (auto mstr:cnstr.weights)
            cout << mstr << ", " ;
        cout << endl;

    }
    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//
    /// **************************************************************//

    ///===========           Create DOFHandler            ===========///
    SmartPtr<DOFsHandler> dofHand = Create<DOFsHandler>(disMesh);
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    ///===========          Boundary conditions          ===========///
    dofHand->setBoundaryCondition(0, MAxis::Xmin, [](double x){return (x-0.5)*(x-0.5)+(1-0.5)*(1-0.5);});
    dofHand->setBoundaryCondition(0, MAxis::Xmax, [](double x){return (x-0.5)*(x-0.5)+(1-0.5)*(1-0.5);});
    dofHand->setBoundaryCondition(0, MAxis::Ymin,[](double x){return (x-0.5)*(x-0.5)+(1-0.5)*(1-0.5);});
    dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return (x-0.5)*(x-0.5)+(1-0.5)*(1-0.5);});
    dofHand->UpdateGhosts();

    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();
    hiperProbl->setParameterStructure(paramStruct);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setElementFillings("Integ", ElementFillingPoisson);
    hiperProbl->setCubatureGauss("Integ", 4);
    hiperProbl->Update();

    SmartPtr<Amesos2DirectLinearSolver> solver = Create<Amesos2DirectLinearSolver>();
    solver->setSolver(Amesos2DirectLinearSolver::Solver::Klu);
    solver->setHiPerProblem(hiperProbl);
    solver->setNumericFactorization(true);
    solver->setSymbolicFactorization(true);
    solver->setVerbosity(Amesos2DirectLinearSolver::Verbosity::High);
    solver->setDefaultParameters();
    solver->Update();

    solver->solve();
    solver->UpdateSolution();

    dofHand->printFileLegacyVtk("Poisson", true);

    SmartPtr<HiPerProblem> checkSolution = Create<HiPerProblem>();
    checkSolution->setDOFsHandlers({dofHand});
    checkSolution->setIntegration("Integ", {"dofHand"});
    checkSolution->setElementFillings("Integ", CheckSolution);
    checkSolution->setCubatureGauss("Integ", 4);
    checkSolution->setGlobalIntegrals({"error"});
    checkSolution->Update();

    checkSolution->FillLinearSystem();
    double error = checkSolution->globalIntegral("error");
    std::cout << "error: " << error << std::endl;

    assert(error < 1e-4);

    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    hiperlife::Finalize();
    return 0;
}
