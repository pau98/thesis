/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include <ad.h>



// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct HyElParams
{
  enum RealParameters
  {
    force,
    beta,
    deltat,
    mu0,
    lambda0,
    mu1,
    lambda1
  };

  enum IntParameters
  {
    timeStep,
  };

  HL_PARAMETER_LIST DefaultValues
  {
    {"force", 0.0},
    {"beta", 100.0},
    {"deltat", 1.},
    {"timeStep",0},
    {"k0",10.},
    {"k1",0.01},
    {"mu0",1.},
    {"mu1",1.},
    {"lambda0",1.},
    {"lambda1",1.}
  };
};

bool fileExists(const std::string& filename)
{
  struct stat buf;
  if (stat(filename.c_str(), &buf) != -1)
  {
    return true;
  }
  return false;
}

// ─── helper: find adjacent element pairs ────────────────────────────────────

std::vector<std::pair<int,int>> findBorderAdjacentPairs(
    Teuchos::RCP<hiperlife::DOFsHandler> dhand, int p, int rInt)
{
    using namespace hiperlife;

    auto mesh = dhand->mesh;
    vector<string> rTags = mesh->_regionTags();
    // if (std::find(rTags.begin(), rTags.end(), rTag) == rTags.end())
    //     throw runtime_error("findBorderAdjacentPairs: The provided region name could not be found");
    vector<int> rPrimes = {3,5,7,11};

    // Corner local-node indices per side of a Q_p square element:
    //   Side 0 (v=-1): nodes 0      and p
    //   Side 1 (u=+1): nodes p      and p*(p+2)
    //   Side 2 (v=+1): nodes p*(p+2) and p*(p+1)
    //   Side 3 (u=-1): nodes p*(p+1) and 0
    const std::array<std::array<int,2>,4> sideCorners = {{
        {0,       p        },
        {p,       p*(p+2)  },
        {p*(p+2), p*(p+1)  },
        {p*(p+1), 0        }
    }};
    
    dhand->elemAuxF->setValue("GhP"+to_string(rInt),1);

    std::unordered_map<int, std::vector<int>> nodeToElems;
    for (int e = 0; e < mesh->loc_nElem(); e++)
    {
        int eNN = mesh->_adjcyEN->getNumNbors(e, IndexType::Local);
        for (int i = 0; i < eNN; i++)
        {
            int gn = mesh->_adjcyEN->getNbor(e, i, IndexType::Global);
            nodeToElems[gn].push_back(e);
        }
    }

    int offs = mesh->offs_nElem();
    std::set<std::pair<int,int>> seen;
    std::vector<std::pair<int,int>> result;

    for (int e1 = 0; e1 < mesh->loc_nElem(); e1++)
    {
        if((int)dhand->elemAuxF->getValue(0,e1)%2 == 0)
        {
            int sCount = 0;
            for (auto& sc : sideCorners)
            {
                int gA = mesh->_adjcyEN->getNbor(e1, sc[0], IndexType::Global);
                int gB = mesh->_adjcyEN->getNbor(e1, sc[1], IndexType::Global);

                const auto& eA = nodeToElems[gA];
                const auto& eB = nodeToElems[gB];

                for (int e2 : eA)
                {
                    if (e2 == e1) continue;
                    if (std::find(eB.begin(), eB.end(), e2) == eB.end()) continue;
                    if ((int)dhand->elemAuxF->getValue(0,e2)%rPrimes[rInt] != 0) continue;
                    int g1 = e1 + offs, g2 = e2 + offs;
                    auto key = std::make_pair(std::min(g1,g2), std::max(g1,g2));
                    if (seen.insert(key).second)
                    {
                        result.push_back(key);
                        double e1Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e1,IndexType::Global);
                        if ((int)e1Val%rPrimes[sCount] != 0)
                            dhand->elemAuxF->setValue("GhP"+to_string(rInt),e1,IndexType::Global,e1Val*rPrimes[sCount]);
                        double e2Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e2,IndexType::Global);
                        if ((int)e2Val%rPrimes[(sCount+2)%4] != 0)
                            dhand->elemAuxF->setValue("GhP"+to_string(rInt),e2,IndexType::Global,e2Val*rPrimes[(sCount+2)%4]);
                    }
                }
                sCount++;
            }
        }
    }
    return result;
}

// Cavity flow

vector<double> bodyForce(double x,double y)
{
  double sx  = sin(M_PI*x);
  double cx = cos(M_PI*x);
  double sy  = sin(M_PI*y);
  double cy = cos(M_PI*y);
  double sxy = sin(M_PI*(x + y));
  double cxy = cos(M_PI*(x + y));
  double J   = 1. + M_PI*sxy/5.;
  double lnJ = log(J);

  double denom = (M_PI*sxy + 5.)*(M_PI*sxy + 5.);
  vector<double> b(2);

  b[0] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sx*cy + 5.)*(lnJ - 1.)*cxy - (M_PI*sx*cy + 5.)*cxy - M_PI*(lnJ - 1.)*sy*cx*cxy + M_PI*sy*cx*cxy) / denom;

  b[1] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sy*cx + 5.)*(lnJ - 1.)*cxy - (M_PI*sy*cx + 5.)*cxy - M_PI*(lnJ - 1.)*sx*cy*cxy + M_PI*sx*cy*cxy) / denom;

  return b;
}

void LSV0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;
  using namespace autodiff;
  double mu0 = fillStr.getRealParameter(HyElParams::mu0);
  double lm0 = fillStr.getRealParameter(HyElParams::lambda0);
  double deltat = fillStr.getRealParameter(HyElParams::deltat);
  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);


  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofsT = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofsT(0),dofsT(1)};
  double uu = sqrt((-x(1)+0.5)*(-x(1)+0.5)+(x(0)+0.3)*(x(0)+0.3));

  ttl::tensor<double,1> f(2);
  std::vector<double> b = bodyForce(x(0),x(1));
  f(0) = b[0];
  f(1) = b[1];
  // cout << f << endl;
  tensor<double,2> Id2 = Identity2;
    
  auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  {
    //***********************************************************
    // Initialize
    //***********************************************************

    // Rearrange DOFs  // FIXME: I don't think this is the fastest way
    tensor<dual2nd,2> nborDOFsd(eNN, numDOFs);
    for (int i = 0; i < eNN; i++)
    {
      for (int d = 0; d < numDOFs; d++)
      {
        nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
      }
    }
    tensor<dual2nd,1> dofsd = bf*nborDOFsd;
    tensor<dual2nd,1> u0d = dofsd(rngR0);

    tensor<dual2nd,2> nborx = nborDOFsd(all,rngR0)*deltat+nborCoords;
    tensor<dual2nd,2> Fd = product(nborx, Dbf_g, {{0,0}}); // dx/dchi
    dual2nd Jd = Fd.det(); // J = det(Fd)
    tensor<dual2nd,2> iFd = Fd.inv();

    tensor<dual2nd,2> nboru = nborDOFsd(all,rngR0);
    tensor<dual2nd,2> gud = product(nboru, Dbf_g, {{0,0}}); // dx/dchi
    tensor<dual2nd,2> epd = 0.5*(gud*iFd+iFd.T()*gud.T());

    // Energy and 2nd Piola-Kirchhoff stress tensor (background)
    dual2nd ray = jac*mu0*product(epd,epd,{{0,1},{1,0}})*Jd;
    return(ray);
  };

  // Compute nborDOFs as dual2nd type
  std::vector<dual2nd> dofs(eNN*numDOFs);
  for (int i = 0; i < eNN*numDOFs; i++)
  {
    dofs.at(i) = subFill.nborDOFs.at(i);
  }

  // Compute rayleighian, jacobian, and hessian
  dual2nd ray;
  std::vector<double> Jac(eNN*numDOFs);
  std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  // Rearrange into Bk and Ak
  int n0 = eNN*numDOFs;
  for (int i = 0; i < n0; i++)
  {
    fillStr.Bk(0).at(i) = Jac[i];
  }

  for (int i = 0; i < n0; i++)
  {
    for (int j = 0; j < n0; j++)
    {
      fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
    }
  }
  

  // Output integration points
  ofstream myfile;
  if (!fileExists("Cut.csv"))
  {
    myfile.open("Cut.csv", std::ios_base::app);
    myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
    myfile.close();
  }
  myfile.open("Cut.csv", std::ios_base::app);
  myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << jac << endl;
  myfile.close();
  fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));

}

void LSP0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;
  using namespace autodiff;
  double mu0 = fillStr.getRealParameter(HyElParams::mu0);
  double lm0 = fillStr.getRealParameter(HyElParams::lambda0);
  double deltat = fillStr.getRealParameter(HyElParams::deltat);
  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);


  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofsT = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofsT(0),dofsT(1)};
  double uu = sqrt((-x(1)+0.5)*(-x(1)+0.5)+(x(0)+0.3)*(x(0)+0.3));

  ttl::tensor<double,1> f(2);
  std::vector<double> b = bodyForce(x(0),x(1));
  f(0) = b[0];
  f(1) = b[1];
  // cout << f << endl;
  tensor<double,2> Id2 = Identity2;
    
  auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  {
    //***********************************************************
    // Initialize
    //***********************************************************

    // Rearrange DOFs  // FIXME: I don't think this is the fastest way
    tensor<dual2nd,2> nborDOFsd(eNN, numDOFs);
    for (int i = 0; i < eNN; i++)
    {
      for (int d = 0; d < numDOFs; d++)
      {
        nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
      }
    }
    tensor<dual2nd,1> dofsd = bf*nborDOFsd;
    tensor<dual2nd,1> u0d = dofsd(rngR0);

    // Compute pressure
    tensor<double,2> nborLocCoords = {{-1,-1},{0,-1},{1,-1},{-1,0},{0,0},{1,0},{-1,1},{0,1},{1,1}};
    tensor<double,1> eC = bf*nborLocCoords;
    tensor<double,1> bf1 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
    dual2nd p0d = bf1(0)*nborDOFsd(0,4) + bf1(1)*nborDOFsd(1,4) + bf1(2)*nborDOFsd(3,4);

    // Compute velocity gradient
    tensor<dual2nd,2> nboru = nborDOFsd(all,rngR0);
    tensor<dual2nd,2> gud = product(nboru, Dbf_g, {{0,0}}); // dx/dchi

    tensor<dual2nd,2> nborx = nborDOFsd(all,rngR0)*deltat+nborCoords;
    tensor<dual2nd,2> Fd = product(nborx, Dbf_g, {{0,0}}); // dx/dchi
    dual2nd Jd = Fd.det(); // J = det(Fd)
    // Energy and 2nd Piola-Kirchhoff stress tensor (background)
    dual2nd ray = -jac*p0d*(Jd-1.);
    return(ray);
  };

  // Compute nborDOFs as dual2nd type
  std::vector<dual2nd> dofs(eNN*numDOFs);
  for (int i = 0; i < eNN*numDOFs; i++)
  {
    dofs.at(i) = subFill.nborDOFs.at(i);
  }

  // Compute rayleighian, jacobian, and hessian
  dual2nd ray;
  std::vector<double> Jac(eNN*numDOFs);
  std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  // Rearrange into Bk and Ak
  int n0 = eNN*numDOFs;
  for (int i = 0; i < n0; i++)
  {
    fillStr.Bk(0).at(i) = Jac[i];
  }

  for (int i = 0; i < n0; i++)
  {
    for (int j = 0; j < n0; j++)
    {
      fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
    }
  }
  

  // Output integration points
  ofstream myfile;
  if (!fileExists("Cut.csv"))
  {
    myfile.open("Cut.csv", std::ios_base::app);
    myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
    myfile.close();
  }
  myfile.open("Cut.csv", std::ios_base::app);
  myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << jac << endl;
  myfile.close();
  fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));

}

void LSV1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  using namespace autodiff;

  double mu1 = fillStr.getRealParameter(HyElParams::mu1);
  double lm1 = fillStr.getRealParameter(HyElParams::lambda1);
  double deltat = fillStr.getRealParameter(HyElParams::deltat);
  auto rngCoords = range(0,1);
  auto rngR1 = range(2,3);

  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  
  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  // ttl::wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2
  
  // ttl::wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofsT = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofsT(2),dofsT(3)};

  ttl::tensor<double,1> f(2);
  std::vector<double> b = bodyForce(x(0),x(1));
  f(0) = b[0];
  f(1) = b[1];

  tensor<double,2> Id2 = Identity2;
    
  auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  {
    //***********************************************************
    // Initialize
    //***********************************************************

    // Rearrange DOFs  // FIXME: I don't think this is the fastest way
    tensor<dual2nd,2> nborDOFsd(eNN, numDOFs);
    for (int i = 0; i < eNN; i++)
    {
      for (int d = 0; d < numDOFs; d++)
      {
        nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
      }
    }

    tensor<dual2nd,1> dofsd = bf*nborDOFsd;
    tensor<dual2nd,1> u1d = dofsd(rngR1);
    tensor<dual2nd,2> nborx = nborDOFsd(all,rngR1)*deltat+nborCoords;
    tensor<dual2nd,2> Fd = product(nborx, Dbf_g, {{0,0}}); // dx/dchi
    dual2nd Jd = Fd.det(); // J = det(Fd)

    // Elastic
    // Right Cauchy-Green tensor and inverse (background)
    tensor<dual2nd,2> Cd = Fd.T()*Fd;

    // Energy and 2nd Piola-Kirchhoff stress tensor (background)
    dual2nd W = 0.5*lm1*log(Jd)*log(Jd) - mu1*log(Jd) + 0.5*mu1*(trace(Cd)-pDim);
    dual2nd ray = jac*W/deltat; //-jac*f*u1d;
    return(ray);
  };
    // Compute nborDOFs as dual2nd type
  std::vector<dual2nd> dofs(eNN*numDOFs);
  for (int i = 0; i < eNN*numDOFs; i++)
  {
    dofs.at(i) = subFill.nborDOFs.at(i);
  }

  // Compute rayleighian, jacobian, and hessian
  dual2nd ray;
  std::vector<double> Jac(eNN*numDOFs);
  std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  // Rearrange into Bk and Ak
  int n0 = eNN*numDOFs;
  for (int i = 0; i < n0; i++)
  {
    fillStr.Bk(0).at(i) = Jac[i];
  }

  for (int i = 0; i < n0; i++)
  {
    for (int j = 0; j < n0; j++)
    {
      fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
    }
  }
  
  // Output integration points
  ofstream myfile;
  if (!fileExists("Cut.csv"))
  {
    myfile.open("Cut.csv", std::ios_base::app);
    myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
    myfile.close();
  }
  myfile.open("Cut.csv", std::ios_base::app);
  myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << jac << endl;
  myfile.close();
  
  fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));

}

void LSBorder(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  using namespace autodiff;
  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);
  auto rngR1 = range(2,3);

  //============          Initialize variables           ===========//
  // Parameters
  double beta = fillStr.getRealParameter(HyElParams::beta);
  double deltat = fillStr.getRealParameter(HyElParams::deltat);
  double mu0 = fillStr.getRealParameter(HyElParams::mu0);
  double mu1 = fillStr.getRealParameter(HyElParams::mu1);
  double lm0 = fillStr.getRealParameter(HyElParams::lambda0);
  double lm1 = fillStr.getRealParameter(HyElParams::lambda1);


  // Background
  SubFillStructure& subFill = fillStr[0];
  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;       // Number of neighbor nodes
  int nDim = subFill.nDim;      // Number of spatial dimensions
  int pDim = subFill.pDim;      // Number of parametric dimension
  std::vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  // ===================== Values at int. points ==================== //
  // Compute jacobian
  tensor<double,2> dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf, jac, subFill);

  // Get tangent to immersed mesh at integration point
  auto immMesh = subFill.dhandDHand->mesh->_childMesh;
  std::vector<double> t(3);
  for (int n = 0; n < nDim; n++)
    t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
  jac = Math::Norm3D(t.data());

  // Compute unitary normal
  ttl::tensor<double,1> n(2);
  n(0) = t[1]/jac;
  n(1) = -t[0]/jac;

  n *= -1;
  // Compute coordinates using the back mesh
  std::vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf(i);
  }

  // Nitsche symmetric
  double gmm0 = 0.;
  double gmm1 = 1.-gmm0;


  double vd = 0.0;

  auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  {
    //***********************************************************
    // Initialize
    //***********************************************************

    // Rearrange DOFs 
    tensor<dual2nd,2,true>   nborDOFsd(eNN, numDOFs);
    for (int i = 0; i < eNN; i++)
    {
      for (int d = 0; d < numDOFs; d++)
      {
        nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
      }
    }

    tensor<dual2nd,1> dofsd = bf*nborDOFsd;
    tensor<dual2nd,1> u0d = {dofsd(0),dofsd(1)};
    tensor<dual2nd,1> u1d = {dofsd(2),dofsd(3)};
    ttl::tensor<double,2> Id2 = Identity2;

    tensor<double,2> nborLocCoords = {{-1,-1},{0,-1},{1,-1},{-1,0},{0,0},{1,0},{-1,1},{0,1},{1,1}};
    tensor<double,1> eC = bf*nborLocCoords;
    tensor<double,1> bf1 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
    dual2nd p0d = bf1(0)*nborDOFsd(0,4) + bf1(1)*nborDOFsd(1,4) + bf1(2)*nborDOFsd(3,4);


    tensor<dual2nd,1> vdiffd = (u0d-u1d-vd*n);

    tensor<dual2nd,2> nborud0 = nborDOFsd(all,rngR0);
    tensor<dual2nd,2> gud0 = product(nborud0, dbf, {{0,0}}); // dx/dchi
    tensor<dual2nd,2> epd0 = 0.5*(gud0+gud0.T());

    tensor<dual2nd,2> Hd0 = gud0*deltat; // dx/dchi

    tensor<dual2nd,2> nborxd0 = nborDOFsd(all,rngR0)*deltat+nborCoords;
    tensor<dual2nd,2> Fd0 = product(nborxd0, dbf, {{0,0}}); // dx/dchi
    dual2nd Jd0 = Fd0.det(); // J = det(Fd)
    tensor<dual2nd,2> iFd0 = Fd0.inv();

    tensor<dual2nd,2> nborxd1 = nborDOFsd(all,rngR1)*deltat+nborCoords;
    tensor<dual2nd,2> Fd1 = product(nborxd1, dbf, {{0,0}}); // dx/dchi
    dual2nd Jd1 = Fd1.det(); // J = det(Fd)

    // Right Cauchy-Green tensor and inverse (background)
    tensor<dual2nd,2> Cd1 = Fd1.T()*Fd1;
    tensor<dual2nd,2> Fd1_i = Fd1.inv();
    tensor<dual2nd,2> Cd1_i = Fd1_i*Fd1_i.T();

    // Energy and 2nd Piola-Kirchhoff stress tensor (background)
    tensor<dual2nd,2> Sd1 = mu1*Id2 + (lm1*log(Jd1)-mu1)*Cd1_i;

    tensor<dual2nd,2> tHd0 =  {{Hd0(0,0)+Hd0(1,1),0.},{0., Hd0(0,0)+Hd0(1,1)}};
    // ttl::tensor<dual2nd,2> sd = gmm1*(d1d-p1d*Id2)+gmm1*(d1d-p1d*Id2);


    tensor<dual2nd,2> epd = 0.5*(gud0*iFd0+iFd0.T()*gud0.T());

    tensor<dual2nd,2> sd0 =  2.*mu0*epd - p0d*Id2;
    tensor<dual2nd,2> Pd0 =  Jd0*sd0*iFd0.T();

    tensor<dual2nd,2> Pd1 = Fd1*Sd1;
    ttl::tensor<dual2nd,2> sd = gmm0*Pd0+gmm1*Pd1;

    ttl::tensor<dual2nd,1> Td = sd*n;
    dual2nd pen = jac*0.5*beta*vdiffd*(gmm0*Id2+gmm1*mu1*(Id2+2*outer(n,n)))*vdiffd;
    dual2nd tra = 0;//-jac*vdiffd*Td;
    return(pen+tra);
  };
  
  // Compute nborDOFs as dual2nd type
  std::vector<dual2nd> dofs(eNN*numDOFs);
  for (int i = 0; i < eNN*numDOFs; i++)
  {
    dofs.at(i) = subFill.nborDOFs.at(i);
  }

  // Compute rayleighian, jacobian, and hessian
  dual2nd ray;
  std::vector<double> Jac(eNN*numDOFs);
  std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  // Rearrange into Bk and Ak
  int n0 = eNN*numDOFs;
  for (int i = 0; i < n0; i++)
  {
    fillStr.Bk(0).at(i) = Jac[i];
  }

  for (int i = 0; i < n0; i++)
  {
    for (int j = 0; j < n0; j++)
    {
      fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
    }
  }
  
  fillStr.addToGlobalIntegral("Length", jac);
  fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));
}

void CheckSolution0(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  const double u_numeric = dofsI(N,0) * bf(N);
  const double u_analytial = sin(M_PI*x(0))*cos(M_PI*x(1));//(x(0)-0.5)*(x(0)-0.5)+(x(1)-0.5)*(x(1)-0.5);
  const double error = jac * abs(u_numeric-u_analytial);
  fillStr.addToGlobalIntegral("error", error);
}

void CheckSolution1(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  const double u_numeric = dofsI(N,1) * bf(N);
  const double u_analytial = sin(M_PI*x(0))*cos(M_PI*x(1));//(x(0)-0.5)*(x(0)-0.5)+(x(1)-0.5)*(x(1)-0.5);
  const double error = jac * abs(u_numeric-u_analytial);
  fillStr.addToGlobalIntegral("error", error);
}

void CheckNitsche(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace ttl;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::N, ttl::index::i, ttl::index::j;
    double mu0 = fillStr.getRealParameter(HyElParams::mu0);
    double mu1 = fillStr.getRealParameter(HyElParams::mu1);
    double lm1 = fillStr.getRealParameter(HyElParams::lambda1);
    double deltat = fillStr.getRealParameter(HyElParams::deltat);

    auto rngCoords = range(0,1);
    auto rngR0 = range(0,1);
    auto rngR1 = range(2,3);
    //============          Initialize variables           ===========//

    // Background
    SubFillStructure &subFill = fillStr[0];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    std::vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    ttl::wrapper<double, 1> bft(subFill.nborBFs(), eNN);
    ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
    tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
    // ===================== Values at int. points ==================== //
    // Compute jacobian
    tensor<double,2> dbf(eNN,pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf, jac, subFill);

    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    std::vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
    jac = Math::Norm3D(t.data());

    // Compute unitary normal
    tensor<double,1> n(2);
    n(0) = -t[1]/jac;
    n(1) = -(-t[0])/jac;

    // Compute coordinates using the back mesh
    std::vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf(i);
    }
    ttl::wrapper<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN,DOF);

    // tensor<double,2> du = k0*dofsI(N,j) * dbf(N,i);
    // cout << jac*((du(range(0,1),0)*n-du(range(2,3),0)*n)+(du(range(0,1),1)*n-du(range(2,3),1)*n)) << endl;

    double vd = 0.0;

    tensor<double,2> nborLocCoords = {{-1,-1},{0,-1},{1,-1},{-1,0},{0,0},{1,0},{-1,1},{0,1},{1,1}};
    tensor<double,1> eC = bf*nborLocCoords;
    tensor<double,1> bf1 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
    double p0 = bf1(0)*nborDOFs(0,4) + bf1(1)*nborDOFs(1,4) + bf1(2)*nborDOFs(3,4);

    tensor<double,2> nbru0 = nborDOFs(all,rngR0);
    tensor<double,2> gu0 = product(nbru0, dbf, {{0,0}}); // dx/dchi
    tensor<double,2> ep0 = 0.5*(gu0+gu0.T());

    tensor<double,2> nborx1 = nborDOFs(all,rngR1)*deltat+nborCoords;
    tensor<double,2> F1 = product(nborx1, dbf, {{0,0}}); // dx/dchi
    double J1 = F1.det(); // J = det(Fd)

    // Right Cauchy-Green tensor and inverse (background)
    tensor<double,2> C1 = F1.T()*F1;
    tensor<double,2> F1_i = F1.inv();
    tensor<double,2> C1_i = F1_i*F1_i.T();

    // Energy and 2nd Piola-Kirchhoff stress tensor (background)
    tensor<double,2> S1 = mu1*Identity2 + (lm1*log(J1)-mu1)*C1_i;


    // ttl::tensor<dual2nd,2> sd = gmm1*(d1d-p1d*Id2)+gmm1*(d1d-p1d*Id2);
    tensor<double,2> Pd0 =  2.*mu0*ep0 - p0*Identity2;
    tensor<double,2> Pd1 = F1*S1;

    tensor<double,1> dofs = bf*nborDOFs;
    tensor<double,1> u0 = dofs(rngR0);
    tensor<double,1> u1 = dofs(rngR1);
    tensor<double,1> vdiff = (u0-u1-vd*n);

    // Save local length
    fillStr.addToGlobalIntegral("uErr", jac*vdiff*vdiff);
    // fillStr.addToGlobalIntegral("pErr", jac *(p0-p1)*(p0-p1))
    fillStr.addToGlobalIntegral("duErr", jac*(Pd0*n-Pd1*n)*(Pd0*n-Pd1*n));
    
    return;
}

void LSPre(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using hiperlife::Tensor::tensor;
    using namespace hiperlife::Tensor;

    SubFillStructure& subFill = fillStr[0];

    int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
    int numAuxF  = subFill.numAuxF;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    ttl::wrapper<double,2> nborAuxF(subFill.nborAuxF.data(), eNN, numAuxF);

    std::vector<double> b0 = {-1};
    std::vector<std::vector<double>>& pbf0 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b0, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf1 ={pbf0[0][0],pbf0[0][1],pbf0[0][2],pbf0[0][3]}; 
    std::vector<double> b1 = {1};
    std::vector<std::vector<double>>& pbf1 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b1, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf2 ={pbf1[0][0],pbf1[0][1],pbf1[0][2],pbf1[0][3]}; 

    // Get output
    tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    Bk(1,0) = nborAuxF(1,0);
    Bk(1,1) = nborAuxF(1,1);
    Bk(2,0) = nborAuxF(2,0);
    Bk(2,1) = nborAuxF(2,1);
    for (int a = 0; a<eNN; a++)
    {
        Ak(a,0,1,0) = bf1[a];
        Ak(a,1,1,1) = bf1[a];

        Ak(a,0,2,0) = bf2[a];
        Ak(a,1,2,1) = bf2[a];
    }
}


void genCircBspline(double r, std::vector<double> &U,std::vector<std::vector<std::vector<std::vector<double>>>> &CP, double xOff, double yOff, ElemType eTypeB,BasisFuncType bTypeB,int bfOrderB,int nPtsCircOr,SmartPtr<ParamStructure> paramStr)
{
  // Compute immersed mesh CPs position
  SmartPtr<StructMeshGenerator> preBSMesh = Create<StructMeshGenerator>();

  preBSMesh->setMesh(eTypeB, bTypeB, bfOrderB);
  
  std::vector<double> preU(nPtsCircOr+1,0);
  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    preU[i] = preU[i-1]+1;
  }
  
  std::vector<std::vector<std::vector<std::vector<double>>>> preCP(nPtsCircOr, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
  for (int k = 0;  k < nPtsCircOr; k++)
  {
    double t = 2*M_PI*k/nPtsCircOr;
    preCP[k][0][0] = {std::cos(t),std::sin(t),0,0};
  }
  
  preBSMesh->genBsplinesClosedCurve(preU,preCP);
  // Distributed mesh
  SmartPtr<DistributedMesh> preDisBSMesh = Create<DistributedMesh>("preDisBSMesh");
  preDisBSMesh->setMesh(preBSMesh);
  preDisBSMesh->setBalanceMesh(true);
  preDisBSMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
  preDisBSMesh->setVerbosity(Verbosity::None);
  preDisBSMesh->Update();
  
  // Set Degree of Freedom handler
  SmartPtr<DOFsHandler> preDhand = Create<DOFsHandler>(preDisBSMesh);
  preDhand->setNameTag("preDhand");
  preDhand->setNumDOFs(2);
  preDhand->setDOFs({"pcx","pcy"});
  preDhand->setNodeAuxF({"x","y","dxdt","dydt"});
  preDhand->Update();


  std::vector<double> cw = {1};
  for (int i = 0; i<preDisBSMesh->nPts();i++)
  {
    double t = 2.*M_PI*double(i)/double(nPtsCircOr);
    double x = xOff;
    double y = yOff;
    for (int iw = 0; iw<cw.size(); iw++)
    {
      x += cw[iw]*cos((iw+1)*t)*r;
      y += cw[iw]*sin((iw+1)*t)*r;
    }
    preDhand->nodeAuxF->setValue(0,i,IndexType::Global,x);
    preDhand->nodeAuxF->setValue(1,i,IndexType::Global,y);
  }

  SmartPtr<HiPerProblem> preHiperProbl = Create<HiPerProblem>();
  preHiperProbl->setParameterStructure(paramStr);
  preHiperProbl->setDOFsHandlers({preDhand});
  
  // Interface integration
  preHiperProbl->setIntegration("IntegPre", {"preDhand"});
  preHiperProbl->setCubatureGauss("IntegPre", 1);
  preHiperProbl->setElementFillings("IntegPre", LSPre);

  preHiperProbl->Update();

  SmartPtr<MUMPSDirectLinearSolver> preSolver = Create<MUMPSDirectLinearSolver>();
  preSolver->setHiPerProblem(preHiperProbl);
  preSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
  preSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
  preSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Sequential);
  preSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
  preSolver->setConvergenceCriteria(MUMPSDirectLinearSolver::ConvergenceCriteria::Relative);
  preSolver->setTolerance(1e-8);
  preSolver->setDefaultParameters();
  preSolver->Update();

  // Solve
  preSolver->solve();
  preHiperProbl->UpdateGhosts();

  // Update Solution
  preSolver->UpdateSolution();

  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    U[i] = U[i-1]+1.;
  }

  for (int k = 0;  k < nPtsCircOr; k++)
  {  
    double x = preDhand->nodeDOFs->getValue(0,k,IndexType::Global);
    double y = preDhand->nodeDOFs->getValue(1,k,IndexType::Global);
    CP[k][0][0] = {x,y,0,0};
  }
}

void FacetStbR0(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    int nS = fillStr.getIntParameter(HyElParams::timeStep);

    SubFillStructure& e0 = fillStr[0];
    SubFillStructure& e1 = fillStr[1];
    int eNN  = e0.eNN;
    int nDim = e0.nDim;
    int pDim = e0.pDim;
    int numDOFs = e0.numDOFs;
    double gmm1 = 0.01;
    double gmm2 = 0.01;
    double* Dbf0    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
    double* bf0    = e0.nborBFs();      // local BF: [eNN]
    double* bf1    = e1.nborBFs();      // local BF: [eNN]
    double* coords0 = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]
    double* coords1 = e1.nborCoords.data();   // node coordinates:     [eNN × nDim]
    double h = fabs(coords0[0]-coords0[8*nDim]);
    vector<double> Ecoords = {-1.,-1.,-0.,-1.,1.,-1.,-1.,0.,0.,0.,1.,0.,-1.,1.,0.,1.,1.,1.};   // node coordinates:     [eNN × nDim]

    // cout << h << endl;
    // Reference tangent vector along the boundary side (length pDim)
    std::vector<double> tangRef = e0.tangentsBoundaryRef();

    // Push tangRef through the Jacobian to obtain the physical tangent
    //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
    //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
    std::vector<double> tangPhys(nDim, 0.0);
    for (int a = 0; a < nDim; a++)
    {
        for (int b = 0; b < pDim; b++)
        {
            double Jab = 0.0;
            for (int i = 0; i < eNN; i++)
                Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
            tangPhys[a] += Jab * tangRef[b];
        }
    }
    tensor<double,1> x0(2);
    x0 *=0;
    tensor<double,1> x1(2);
    x1 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int i = 0; i < pDim; i++)
        {
            x0(i) += bf0[a]*coords0[a*nDim + i];
            x1(i) += bf1[a]*coords1[a*nDim + i];
        }
    }

    tensor<double,1> xl0(2);
    tensor<double,1> xl1(2);
    tensor<double,2> dbf(9,2);
    xl0 *=0;
    xl1 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int i = 0; i < pDim; i++)
        {
            xl0(i) += bf0[a]*Ecoords[a*pDim + i];
            xl1(i) += bf1[a]*Ecoords[a*pDim + i];
            dbf(a,i) = Dbf0[a*pDim + i];
        }
    }
    
    double edge_jac = 0.0;
    for (double t : tangPhys) edge_jac += t * t;
    edge_jac = std::sqrt(edge_jac);

    // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
    tensor<double,1> n(2);
    // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
    n(0) = tangPhys[1]/edge_jac;
    n(1) = -tangPhys[0]/edge_jac;
    // cout << "N: " << n<<endl;

    tensor<double,2> gDbf0(eNN,pDim);
    tensor<double,3> gHbf0(eNN,pDim,pDim);
    tensor<double,1> gLbf0(eNN);
    double jac0;
    // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);

    tensor<double,1> HbfN0(eNN);
    GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
    tensor<double,1> DbfN0 = gDbf0*n;

    tensor<double,2> gDbf1(eNN,pDim);
    tensor<double,3> gHbf1(eNN,pDim,pDim);
    tensor<double,1> gLbf1(eNN);
    double jac1;
    // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);

    tensor<double,1> HbfN1(eNN);
    GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
    tensor<double,1> DbfN1 = gDbf1*n;

    for (int a = 0; a < eNN; a++)
    {
        if (fabs(n(0))>fabs(n(1))) // Vertical face
        {
            HbfN0(a) = gHbf0(a,0,0);
            HbfN1(a) = gHbf1(a,0,0);
        }
        else // Horizontal face
        {
            HbfN0(a) = gHbf0(a,1,1);
            HbfN1(a) = gHbf1(a,1,1);
        }
    }

    // cout << xl0 << ", " << xl1<< DbfN0 << DbfN1 << endl;
    // cout << dbf << n << dbf*n << endl;                
    tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
    Ak00 *=0;
    Ak01 *=0;
    Ak10 *=0;
    Ak11 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int b = 0; b < eNN; b++)
        {
            Ak00(a,0,b,0) += edge_jac*h*gmm1*(DbfN0(a)*DbfN0(b));
            Ak01(a,0,b,0) += -edge_jac*h*gmm1*(DbfN0(a)*DbfN1(b));
            Ak10(a,0,b,0) += -edge_jac*h*gmm1*(DbfN1(a)*DbfN0(b));
            Ak11(a,0,b,0) += edge_jac*h*gmm1*(DbfN1(a)*DbfN1(b));

            if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
            {
                Ak00(a,0,b,0) += edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
                Ak01(a,0,b,0) += -edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
                Ak10(a,0,b,0) += -edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
                Ak11(a,0,b,0) += edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
            }
        }
        
    }
    // Ak00 *=-1;
    // Ak01 *=-1;
    // Ak10 *=-1;
    // Ak11 *=-1;
    fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
    // cout << e0.kPt << " " <<e1.kPt << endl;
    ofstream myfile;
    myfile.open("fStb0."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
    myfile.close();

    myfile.open("fStb1."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
    myfile.close();

}

void FacetStbR1(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    int nS = fillStr.getIntParameter(HyElParams::timeStep);

    SubFillStructure& e0 = fillStr[0];
    SubFillStructure& e1 = fillStr[1];
    int eNN  = e0.eNN;
    int nDim = e0.nDim;
    int pDim = e0.pDim;
    int numDOFs = e0.numDOFs;
    double gmm1 = 0.01;
    double gmm2 = 0.01;
    double* Dbf0    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
    double* bf0    = e0.nborBFs();      // local BF: [eNN]
    double* bf1    = e1.nborBFs();      // local BF: [eNN]
    double* coords0 = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]
    double* coords1 = e1.nborCoords.data();   // node coordinates:     [eNN × nDim]
    double h = fabs(coords0[0]-coords0[8*nDim]);
    vector<double> Ecoords = {-1.,-1.,-0.,-1.,1.,-1.,-1.,0.,0.,0.,1.,0.,-1.,1.,0.,1.,1.,1.};   // node coordinates:     [eNN × nDim]

    // cout << h << endl;
    // Reference tangent vector along the boundary side (length pDim)
    std::vector<double> tangRef = e0.tangentsBoundaryRef();

    // Push tangRef through the Jacobian to obtain the physical tangent
    //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
    //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
    std::vector<double> tangPhys(nDim, 0.0);
    for (int a = 0; a < nDim; a++)
    {
        for (int b = 0; b < pDim; b++)
        {
            double Jab = 0.0;
            for (int i = 0; i < eNN; i++)
                Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
            tangPhys[a] += Jab * tangRef[b];
        }
    }
    tensor<double,1> x0(2);
    x0 *=0;
    tensor<double,1> x1(2);
    x1 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int i = 0; i < pDim; i++)
        {
            x0(i) += bf0[a]*coords0[a*nDim + i];
            x1(i) += bf1[a]*coords1[a*nDim + i];
        }
    }

    tensor<double,1> xl0(2);
    tensor<double,1> xl1(2);
    tensor<double,2> dbf(9,2);
    xl0 *=0;
    xl1 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int i = 0; i < pDim; i++)
        {
            xl0(i) += bf0[a]*Ecoords[a*pDim + i];
            xl1(i) += bf1[a]*Ecoords[a*pDim + i];
            dbf(a,i) = Dbf0[a*pDim + i];
        }
    }
    
    double edge_jac = 0.0;
    for (double t : tangPhys) edge_jac += t * t;
    edge_jac = std::sqrt(edge_jac);

    // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
    tensor<double,1> n(2);
    // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
    n(0) = tangPhys[1]/edge_jac;
    n(1) = -tangPhys[0]/edge_jac;
    // cout << "N: " << n<<endl;

    tensor<double,2> gDbf0(eNN,pDim);
    tensor<double,3> gHbf0(eNN,pDim,pDim);
    tensor<double,1> gLbf0(eNN);
    double jac0;
    // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);

    tensor<double,1> HbfN0(eNN);
    GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
    tensor<double,1> DbfN0 = gDbf0*n;

    tensor<double,2> gDbf1(eNN,pDim);
    tensor<double,3> gHbf1(eNN,pDim,pDim);
    tensor<double,1> gLbf1(eNN);
    double jac1;
    // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);

    tensor<double,1> HbfN1(eNN);
    GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
    tensor<double,1> DbfN1 = gDbf1*n;

    for (int a = 0; a < eNN; a++)
    {
        if (fabs(n(0))>fabs(n(1))) // Vertical face
        {
            HbfN0(a) = gHbf0(a,0,0);
            HbfN1(a) = gHbf1(a,0,0);
        }
        else // Horizontal face
        {
            HbfN0(a) = gHbf0(a,1,1);
            HbfN1(a) = gHbf1(a,1,1);
        }
    }

    // cout << xl0 << ", " << xl1<< DbfN0 << DbfN1 << endl;
    // cout << dbf << n << dbf*n << endl;                
    tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
    Ak00 *=0;
    Ak01 *=0;
    Ak10 *=0;
    Ak11 *=0;
    for (int a = 0; a < eNN; a++)
    {
        for (int b = 0; b < eNN; b++)
        {
            Ak00(a,1,b,1) += edge_jac*h*gmm1*(DbfN0(a)*DbfN0(b));
            Ak01(a,1,b,1) += -edge_jac*h*gmm1*(DbfN0(a)*DbfN1(b));
            Ak10(a,1,b,1) += -edge_jac*h*gmm1*(DbfN1(a)*DbfN0(b));
            Ak11(a,1,b,1) += edge_jac*h*gmm1*(DbfN1(a)*DbfN1(b));

            if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
            {
                Ak00(a,1,b,1) += edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
                Ak01(a,1,b,1) += -edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
                Ak10(a,1,b,1) += -edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
                Ak11(a,1,b,1) += edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
            }
        }
        
    }
    // Ak00 *=-1;
    // Ak01 *=-1;
    // Ak10 *=-1;
    // Ak11 *=-1;
    fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
    // cout << e0.kPt << " " <<e1.kPt << endl;
    ofstream myfile;
    myfile.open("fStb00."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
    myfile.close();

    myfile.open("fStb11."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
    myfile.close();

}

// *******************************************************************//
// *******************************************************************//
// *******************************************************************//
// *****                      MAIN FUNCTION                      *****//
// *******************************************************************//
// *******************************************************************//
// *******************************************************************//

int main(int argc, char** argv)
{

  hiperlife::Init(argc, argv);

  //============================ Parameters ============================//
  int nx = 100;
  int ny = nx;
  vector<int> nxt = {8, 16, 32, 64, 128};

  SmartPtr<ParamStructure> paramStr = CreateParamStructure<HyElParams>();
  // userStr->dparam.resize(1);
  double beta = 100*nx; // beta = 100*h (from 2017Badia)
  paramStr->setRealParameter(HyElParams::beta,beta);



  // *******************************************************************//
  // *****                      MESH CREATION                      *****//
  // *******************************************************************//
  int nSteps = nxt.size();
  int bfOrder = 2;
  int timeStep = 0;
  bool ghP = 0;
  double wellPosedTh = 0.5;
  if(ghP)
  {
    wellPosedTh = 0.;
  }
  for (int nS{}; nS < nSteps; nS++)
  {
    paramStr->setIntParameter(HyElParams::timeStep,nS);
    //-------------------------- Background mesh -------------------------//
    double beta = 400.*nxt[nS]; // beta = 100/h (from 2017Badia)
    paramStr->setRealParameter(HyElParams::beta,beta);

    // Mesh generator
    SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
    back->genStructMesh(nxt[nS], nxt[nS]);
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0001;        

    SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();

    ElemType eTypeB = ElemType::Line; // Element type
    int bfOrderB = 3;   // Basis function order
    BasisFuncType bTypeB = BasisFuncType::BSplines; // Basis function type
    double r = 0.5/sqrt(5.); // Radius of immersed mesh
    int nPtsCirc = 5*nxt[nS]; // Number of control points
    std::vector<std::vector<std::vector<std::vector<double>>>> CP(nPtsCirc, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
    std::vector<double> U(nPtsCirc+1,0);

    imm->setMesh(eTypeB, bTypeB, bfOrderB);
    genCircBspline(r,U,CP,0.5,0.5,eTypeB,bTypeB,bfOrderB,nPtsCirc,paramStr);
    imm->genBsplinesClosedCurve(U,CP);


    SmartPtr<DistributedMesh> immProva = Create<DistributedMesh>("immMeshProva");
    immProva->setMesh(imm);
    immProva->setBalanceMesh(true);
    immProva->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immProva->setVerbosity(Verbosity::None);
    immProva->Update();
    immProva->printFileLegacyVtk("meshProva");

    // Distributed mesh
    SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->Update();


    //--------------------------- Immersed mesh --------------------------//

    // Distributed mesh
    SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setImmersedInteriorPoints({{{0.5, 0.5, 0.0}},{{0.01,0.01,0}}});
    immMesh->setRegionTags({"Interior","Exterior"});
    immMesh->setBalanceMesh(true);
    immMesh->setIllPosThreshold(wellPosedTh);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->Update();

    // Print meshes
    backMesh->printFileLegacyVtk("meshBack");
    immMesh->printFileLegacyVtk("meshImm");


    // *******************************************************************//
    // *****                   DOFsHandler CREATION                  *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"ux0","uy0","ux1","uy1","p0"});
    backDHand->setNodeAuxF({"const","ctag","stab","pp0"});
    backDHand->setElemAuxF({"tag","WI","Agg0","gmm0","l0","GhP0","Agg1","gmm1","l1","GhP1","lE","stbP"});
    backDHand->setDofTags({"Interior","Interior","Exterior","Exterior"});
    backDHand->Update();

    // Save interior/cut/exterior flags for plotting
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
      int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
      backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
      vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
      vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
      for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
      {
        if (backDHand->mesh->isNodeInPart(nbors[n]))
          backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
      }
    }
    backDHand->UpdateGhosts();

    //--------------------  Pressure constraints  --------------------//
        
    backDHand->setConstraint("p0", 0.0);

    backDHand->nodeAuxF->setValue(0,-2);
    backDHand->elemAuxF->setValue(3,1);
    std::vector<int> eNNp = {0,1,3};

    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    { 
      std::vector<int> elCornerFlags = backDHand->mesh->_immersedCornerFlags(e,IndexType::Local);
      std::vector<int> elCorners = backDHand->mesh->_getElementCornerNodes(e,IndexType::Local);
      std::vector<int> nborNode = backMesh->elemNodeNbors(e,IndexType::Global);
      
      if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%3 == 0)
      {
        std::vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
        std::vector<int> eNNp = {0,1,3};
        for (int k{}; k < 3; k++)
          backDHand->removeConstraint(4,nborNode[eNNp[k]],IndexType::Local);
      } 
    }
    
    // Set boundary conditions
    for (int i{}; i < backMesh->nPts(); i++)
    {
      std::vector<double> x = backMesh->nodeCoords(i,IndexType::Global);
      backDHand->nodeDOFs->setValue(0,i,IndexType::Local, 0.);
      backDHand->nodeDOFs->setValue(1,i,IndexType::Local, 0.);
      backDHand->nodeDOFs->setValue(2,i,IndexType::Local, 0.);//0.01*sin(2.*M_PI*x[0])*sin(M_PI*x[1]));
      backDHand->nodeDOFs->setValue(3,i,IndexType::Local, 0.1*x[1]);//0.01*sin(M_PI*x[0])*sin(2.*M_PI*x[1]));
      backDHand->nodeDOFs->setValue(4,i,IndexType::Local, 0.);
      // if (backMesh->nodeCrease(i,IndexType::Global) > 0)
      {
        if (x[0]>0.9999 || x[0]<0.001 || x[1]>0.9999 || x[1]<0.001)
        {
          {
            backDHand->setConstraint(2,i,IndexType::Global,0.);
            backDHand->nodeDOFs->setValue(2,i,IndexType::Global,0.);

            // backDHand->setConstraint(3,i,IndexType::Global,0.);
            // backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.);
          }
        }

        if (x[1]>0.999)
        {
          backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.1);
          backDHand->setConstraint(3,i,IndexType::Global,0.);
        }

        
        if (x[1]<0.001)
        {
          backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.);
          backDHand->setConstraint(3,i,IndexType::Global,0.);
        }
      }
    }

    // Adding face info
    vector<int> rPrime = {3,5,7,11};
    backDHand->elemAuxF->setValue("stbP",1);
    for (int r = 0; r < 1; r++)
    {
      for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
      {
        if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%rPrime[r] == 0)
        {
          std::vector<int> nborNodes = backDHand->mesh->elemNodeNbors(e,IndexType::Local);
          int prova1 = backDHand->mesh->_adjcyNE->getNumNbors(nborNodes[1],IndexType::Local);
          std::vector<int> idF = {3,5,7,11};
          std::vector<int> ndF = {5,7};
          for (int i{}; i < 2; i++)
          {
            int Fstb = backDHand->elemAuxF->getValue("stbP",e,IndexType::Local);
            std::vector<int> nborElms = backDHand->mesh->_adjcyNE->getNborList(nborNodes[ndF[i]],IndexType::Local);
            int e1 = -1;
            for (int j{0}; j < nborElms.size(); j++)
            {
              if (nborElms[j] != e)
              {
                e1 = nborElms[j];
                break;
              }
            }
            if (e1 >= 0)
            {
              if (backDHand->mesh->_elemFlags->getValue(1, e1, IndexType::Local)%rPrime[r] == 0)
              {
                backDHand->elemAuxF->setValue("stbP",e,IndexType::Local,Fstb*idF[i+2*r]);
              }
            }
          }
        }  
      }
    }

    backDHand->printFileLegacyVtk("dofBack", true);


    // Compute facet pairs
    std::vector<std::pair<int,int>> borderFacetPairsR0 = findBorderAdjacentPairs(backDHand, bfOrder,0);
    std::vector<std::pair<int,int>> borderFacetPairsR1 = findBorderAdjacentPairs(backDHand, bfOrder,1);


    // *******************************************************************//
    // *****                    IMMERSED PROBLEM                     *****//
    // *******************************************************************//
    if (true)
    {
      // Immersed HiPerProblem
      SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
      //General setters
      immHP->setParameterStructure(paramStr);
      immHP->setGlobalIntegrals({"Area","Length","uError","duError","total_edge_length","Ray"});
      immHP->setDOFsHandlers({backDHand});

      // Set integration for the border
      immHP->setIntegration("IntegBorder", {"backDHand"});
      immHP->setCubatureBorderImmersed("IntegBorder", 6);
      immHP->setElementFillings("IntegBorder", LSBorder);

      // Set integration for Region 0
      immHP->setIntegration("IntegCavityV0", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV0", 9,5,"Interior");
      immHP->setElementFillings("IntegCavityV0", LSV0);

      immHP->setIntegration("IntegCavityP0", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityP0", 4,3,"Interior");
      immHP->setElementFillings("IntegCavityP0", LSP0);

      // Set integration for Region 1
      immHP->setIntegration("IntegCavityV1", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV1", 9,5,"Exterior");
      immHP->setElementFillings("IntegCavityV1", LSV1);

      if (ghP)
      {
        // Face stabilization
        // Region 0
        immHP->setIntegration("IntegF0",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF0", /*iPts=*/5, borderFacetPairsR0);
        immHP->setElementFillings("IntegF0", FacetStbR0);

        // Region 1
        immHP->setIntegration("IntegF1",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF1", /*iPts=*/5, borderFacetPairsR1);
        immHP->setElementFillings("IntegF1", FacetStbR1);
      }

      std::vector<double> pR = {4,5};

      for (int r = 0; r < 1; r++)
      {
        std::vector<hiperlife::linearConstraint> pLCns;
        std::vector<int> touchFlags = backMesh->_createTouchFlags(r);
        unordered_map<int, std::vector<int>> aggEls = backMesh->_findClosestFAE(touchFlags);
        for (auto itr = aggEls.begin(); itr != aggEls.end(); ++itr)
        {
          // Compute the extrapolation weights
          std::vector<int> MEls = itr->second;
          int sEl = itr->first;
          std::vector<int> sNodes = backMesh->elemNodeNbors(sEl,IndexType::Global);
          double p0 = 0.;
          double p1 = 0.;
          double p2 = 0.;
          std::vector<double> xS0 = backMesh->nodeCoords(sNodes[0],IndexType::Local);
          std::vector<int> m0{}, m1{}, m2{};
          std::vector<double> w0{}, w1{}, w2{};
          int s0 = sNodes[0];
          int s1 = sNodes[1];
          int s2 = sNodes[3];
          int nMs = MEls.size();
          for(int mEl:MEls)
          {
            // Obtain master element corners
            std::vector<int> mNodes = backMesh->elemNodeNbors(mEl,IndexType::Global);
            std::vector<double> xM0 = backMesh->nodeCoords(mNodes[0],IndexType::Local);
            std::vector<double> xM1 = backMesh->nodeCoords(mNodes[8],IndexType::Local);

            // Compute slave p0 as a function of masters p1 and p2
            m1.push_back(mNodes[1]);
            w1.push_back(1./nMs);
            m2.push_back(mNodes[3]);
            w2.push_back(1./nMs);
            double ax = 2./(xM1[0]-xM0[0]);
            double ay = 2./(xM1[1]-xM0[1]);
            double bx = -1.-ax*xM0[0];
            double by = -1.-ay*xM0[1];
            double xs = ax*xS0[0]+bx;
            double ys = ay*xS0[1]+by;
            m0.push_back(mNodes[0]);
            w0.push_back(1./nMs);
            m0.push_back(mNodes[1]);
            w0.push_back(0.5*(xs+1.)/nMs);
            m0.push_back(mNodes[3]);
            w0.push_back(0.5*(ys+1.)/nMs);
          }

          linearConstraint lcAgg0, lcAgg1, lcAgg2;
          lcAgg0.slave = s0;
          lcAgg0.masters = m0;
          lcAgg0.weights = w0;
          pLCns.push_back(lcAgg0);

          lcAgg1.slave = s1;
          lcAgg1.masters = m1;
          lcAgg1.weights = w1;
          pLCns.push_back(lcAgg1);

          lcAgg2.slave = s2;
          lcAgg2.masters = m2;
          lcAgg2.weights = w2;
          pLCns.push_back(lcAgg2);
        }

        for (linearConstraint lC :pLCns)
        {
          int iSlv = lC.slave;
          std::vector<CompHiPerIndex> mstrsV;
          CompHiPerIndex slv = CompHiPerIndex(0, pR[r], iSlv, IndexType::Global); // Get slave hiperIndex
      
          for (int mstrIdx:lC.masters)
            mstrsV.push_back(CompHiPerIndex(0, pR[r], mstrIdx, IndexType::Global)); // Get mstr hiperIndex
          
          immHP->setLinearConstraint(slv,mstrsV,lC.weights); // Set constraint
        }
      }
      immHP->Update();

      //-------------------------- Immersed solver -------------------------//
      SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
      immSOL->setHiPerProblem(immHP);
      immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
      immSOL->setDefaultParameters();
      // immSOL->setWorkSpaceMemoryIncrease(200);
      immSOL->Update();

      //------------------ Non-linear solver creation ------------------//

      SmartPtr<NewtonRaphsonNonlinearSolver> nonLinSolver = Create<NewtonRaphsonNonlinearSolver>();
      nonLinSolver->setLinearSolver(immSOL);
      nonLinSolver->setConvRelTolerance(true);
      nonLinSolver->setMaxNumIterations(50);
      nonLinSolver->setResTolerance(1e-6);
      nonLinSolver->setSolTolerance(1e-8);
      nonLinSolver->setResMaximum(1e5);
      nonLinSolver->setSolMaximum(1e5);
      nonLinSolver->setExitRelMaximum(true);
      nonLinSolver->setLineSearch(false);
      // nonLinSolver->setLineSearchEnergyMethod("Ray");
      nonLinSolver->setPrintSummary(false);
      nonLinSolver->setPrintIntermInfo(true);
      nonLinSolver->Update();

      //---------------------------- Solve immersed ------------------------//
      // Solve
      // immHP->FillLinearSystem();
      bool converged = nonLinSolver->solve();
      immHP->UpdateGhosts();
      string meshName = to_string(nS);

      //------------------    Pressure postprocess    ------------------//

      ttl::tensor<double,2> nborCoordsEl = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
      std::vector<int> pPstR = {3,4};
      double diffP = 0.;

      for (int i{}; i < backMesh->nElem(); i++)
      {
        std::vector<int> nborNode = backMesh->elemNodeNbors(i,IndexType::Global);

        for(int r = 0; r < 1; r++)
        {
          // cout << "HII" << endl;
          if (backDHand->mesh->_elemFlags->getValue(1, i, IndexType::Local)%rPrime[r] == 0)
          {
            std::vector<int> nborCornersNode = backMesh->_getElementCornerNodes(i,IndexType::Global);
            double a = backDHand->nodeDOFs->getValue(pR[r],nborNode[0],IndexType::Global);
            double b = backDHand->nodeDOFs->getValue(pR[r],nborNode[1],IndexType::Global);
            double c = backDHand->nodeDOFs->getValue(pR[r],nborNode[3],IndexType::Global);
            for (int j{}; j < 9; j++)
            {
              ttl::tensor<double,1> bf1 = {1.,0.5*(nborCoordsEl(j,0)+1.),0.5*(nborCoordsEl(j,1)+1.)};
              ttl::tensor<double,1> x = nborCoordsEl(j,ttl::all);
              double p = a+0.5*b*(x(0)+1.)+0.5*c*(x(1)+1.);
              // cout << p <<", "<< pPstR[r] << "," << nborNode[j]<<  endl;
              backDHand->nodeAuxF->setValue(pPstR[r],nborNode[j],IndexType::Global,p);
            }
          }
        }
      }
                  
      // Print
      string solName = "solBack."+to_string(nS);
      backDHand->printFileLegacyVtk(solName, true);
      string immMshName = "meshImm."+to_string(nS);
      immMesh->printFileLegacyVtk(immMshName);

      double L = immHP->globalIntegral("Length");
      double A = immHP->globalIntegral("Area");
      cout << "Area: " << A << " Lenght: " << L << endl;

      SmartPtr<HiPerProblem> checkSolution = Create<HiPerProblem>();
      checkSolution->setDOFsHandlers({backDHand});
      checkSolution->setParameterStructure(paramStr);

      // Set integration for the border
      checkSolution->setIntegration("IntegBorder", {"backDHand"});
      checkSolution->setCubatureBorderImmersed("IntegBorder", 5);
      checkSolution->setElementFillings("IntegBorder", CheckNitsche);

      // Set integration for the background mesh
      checkSolution->setIntegration("Integ0", {"backDHand"});
      checkSolution->setCubatureCutCellConforming("Integ0", 9, 5,"Interior");
      checkSolution->setElementFillings("Integ0", CheckSolution0);

      // Set integration for the background mesh
      checkSolution->setIntegration("Integ1", {"backDHand"});
      checkSolution->setCubatureCutCellConforming("Integ1", 9, 5,"Interior");
      checkSolution->setElementFillings("Integ1", CheckSolution1);

      checkSolution->setGlobalIntegrals({"error","uErr","duErr"});
      checkSolution->Update();

      checkSolution->FillLinearSystem();
      double error = checkSolution->globalIntegral("error");
      std::cout << "error: " << error << std::endl;
      double Uerror = checkSolution->globalIntegral("uErr");
      std::cout << "U border error: " << sqrt(Uerror) << std::endl;
      double dUerror = checkSolution->globalIntegral("duErr");
      std::cout << "dU*n border error: " << sqrt(dUerror) << std::endl;

    }
  }

  hiperlife::Finalize();
  return 0;
}