
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_PredefinedElementFillings.h"
#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_TimeIterator.h"
#include "hl_Remesher.h"

#include "hl_FillStructure.h"
#include "hl_GlobalBasisFunctions.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    if (myRank == 0)
        cout << endl;

    // Time parameters
    string oname = "AllenCahn.";
    double maxTime  = 10000000;
    double maxNStep = 10000000;
    double maxDelt  = 50;
    double stepFactor = 0.95;
    int nSave  = 1;
    int nRemsh = 10;

    // Put parameters in the user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->time.deltat = 1e-2;
    userStr->AllenCahn.epsilon2 = 0.00005/8;
    userStr->AllenCahn.constantMobility = 1.0;
    userStr->AllenCahn.doubleWell = [](double c)->vector<double>
    {
        return {(c*c)*(1.0-c)*(1.0-c)/4.0,
                c*(1.0-c)*(1.0-2.0*c)/2.0,
                (1.0-6.0*c+6.0*c*c)/2.0};
    };

    auto levels = [](double f)
                      {
                          double c = abs(f-0.5);
                          if (c < 0.1)
                              return 3;
                          if (c < 0.25)
                              return 3;
                          // if (c < 0.2)
                          //     return 2;
                          if (c < 0.4)
                              return 3;
                          // if (c < 0.45)
                          //     return 1;
                          // if (c < 0.49)
                          //     return 1;
                          return 0;
                      };

    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create a line structured mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    structMesh->genStructMesh(9*2);
    // structMesh->rotate2D(M_PI/6.0);
    structMesh->threeRefine([=](double x, double y, double z){
                                      double d = sqrt((x-0.5)*(x-0.5)/2+(y-0.5)*(y-0.5));
                                      double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*userStr->AllenCahn.epsilon2)));
                                      return levels(u);
                            }, 3, {8,8,8,8,8});

    // Distribute the mesh among all the processors
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setElementLocatorEngine(ElementLocatorEngine::Quadtree);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    disMesh->printFileLegacyVtk("Initial_mesh");


    // MPI_Finalize();
    // return 0;

    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Create a DOFsHandler with one degree of freedom (c)
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"DOF_0", "c"});
    // dhand->setNodeAuxF({"c"});
    dhand->Update();

    // Set initial and boundary conditions for the DOF
    dhand->setInitialCondition(0, [=](double x, double y){
                                      // double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
                                      // return 0.63+0.05*r;
                                      double d = sqrt((x-0.5)*(x-0.5)/2+(y-0.5)*(y-0.5));
                                      double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*userStr->AllenCahn.epsilon2)));
                                      // return 0.8*u+0.1;//*(0.63+0.05*r);
                                      return u;
                                  });
    dhand->setInitialCondition(1, [=](double x, double y){
                                      // double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
                                      // return 0.63+0.05*r;
                                      double d = sqrt((x-0.5)*(x-0.5)/2+(y-0.5)*(y-0.5));
                                      double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*userStr->AllenCahn.epsilon2)));
                                      // return 0.8*u+0.1;//*(0.63+0.05*r);
                                      return levels(u);
                                  });
    dhand->UpdateGhosts();
    dhand->printFileLegacyVtk("Initial_dhand");
    // dhand->printFileVtk("dhand_parallel", false); // <----------------------------- Remove


    // // MPI_Finalize();
    // // return 0;


    // // Distribute the mesh among all the processors
    // RCP<DistributedMesh> disMeshP = rcp(new DistributedMesh);
    // disMeshP->setMeshRelation(MeshRelation::pRefin, disMesh);
    // disMeshP->setPRefinement(2);
    // disMeshP->setBalanceMesh(true);
    // disMeshP->Update();

    // disMeshP->printFileLegacyVtk("Initial_mesh_prefined");

    // // Create a DOFsHandler with one degree of freedom (c)
    // RCP<DOFsHandler> dhandP = rcp(new DOFsHandler(disMeshP));
    // dhandP->setNameTag("dhandP");
    // dhandP->setDOFs({"DOF_0", "c"});
    // dhandP->Update();

    // // Set initial and boundary conditions for the DOF
    // dhandP->setInitialCondition(0, [=](double x, double y){
    //                                   // double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
    //                                   // return 0.63+0.05*r;
    //                                   double d = sqrt((x-0.5)*(x-0.5)/2+(y-0.5)*(y-0.5));
    //                                   double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*userStr->AllenCahn.epsilon2)));
    //                                   // return 0.8*u+0.1;//*(0.63+0.05*r);
    //                                   return u;
    //                               });
    // dhandP->setInitialCondition(1, [=](double x, double y){
    //                                   // double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
    //                                   // return 0.63+0.05*r;
    //                                   double d = sqrt((x-0.5)*(x-0.5)/2+(y-0.5)*(y-0.5));
    //                                   double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*userStr->AllenCahn.epsilon2)));
    //                                   // return 0.8*u+0.1;//*(0.63+0.05*r);
    //                                   return levels(u);
    //                               });
    // dhandP->UpdateGhosts();
    // dhandP->printFileLegacyVtk("Initial_dhand_refined");

    // MPI_Finalize();
    // return 0;






    // Remesh
    RCP<Remesher> remesher = rcp(new Remesher);
    remesher->setDOFsHandler(dhand, {"DOF_0"});
    remesher->setRemeshMethod(RemeshMethod::Parallel, levels);
    remesher->setDefaultParameters();
    remesher->Update();
    remesher->newDOFsHands(dhand);
    //dhand = remesher->_dhands[0];
    cout << "Finished remeshing" << endl;

    // // remesher->setDOFsHandler(dhand, {"DOF_0"});
    // remesher->Update();
    // // dhand = remesher->_dhands[0];
    // // remesher->newDOFsHands(dhand);

    // MPI_Finalize();
    // return 0;

    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // hiperproblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setElementFillings("Integ", PredefinedElementFillings::AllenCahn);
    hiperProbl->setCubatureGauss("Integ", 4);
    hiperProbl->Update();

    // Linear solver MUMPS
    // RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    // linSolver->setHiPerProblem(hiperProbl);
    // linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    // linSolver->setDefaultParameters();
    // linSolver->Update();

    // Linear solver AztecOO
    RCP<AztecOOIterativeLinearSolver> linSolver = rcp (new AztecOOIterativeLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    linSolver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    linSolver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilu);
    linSolver->setTolerance(1.E-8);
    linSolver->setMaxNumIterations(5000);
    linSolver->setDefaultParameters();
    linSolver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
    linSolver->Update();

    // Non-linear solver
    RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp (new NewtonRaphsonNonlinearSolver());
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    // Time iterator
    RCP<TimeIterator> tIterator = rcp(new TimeIterator);
    // tIterator->setLinearSolver(linSolver);
    tIterator->setNonlinearSolver(nonlinSolver);
    tIterator->setTimeStepSize(1e-5);
    tIterator->setStopCriteria(2000, 1e3, 1e-12);
    tIterator->setTimeSteppingScheme(TimeSteppingScheme::AdaptiveLinear);
    tIterator->setLinearStepFactor(1.01, 0.5);
    tIterator->setMaximumTimeStepSize(0.1);
    tIterator->setPrintToFile(PrintToFileMethod::LegacyVtk, 1, "predElemFill");
    // tIterator->setPrintRestart(10, "restart");
    // tIterator->setPostprocess(1, [=](){dhand->printFileLegacyVtk("HeatEq" + to_string(tIterator->timeStep()));});
    tIterator->Update();


    // **************************************************************//
    // *****                       SOLVE                        *****//
    // **************************************************************//

    // tIterator->Iterate();


    //Loop over time steps
    double time{0.0};
    int timeStep{0};
    double ener_prev{1.E8};
    while ((timeStep < maxNStep) && (time < maxTime))
    {
        // Write
        if (dhand->myRank() == 0)
            cout << endl << " TS: " << to_string(timeStep) << " Time " << time <<  " Delta " << userStr->time.deltat << endl;

        // Initial guess
        dhand->nodeDOFs0->setValue(dhand->nodeDOFs);
        hiperProbl->UpdateGhosts();

        // Newton-Raphson method
        int ierr = nonlinSolver->solve();

        //Check convergence
        if (ierr != 0)
        {
            // //Save solution
            // dhand->nodeDOFs0->setValue(dhand->nodeDOFs);

            // Update variables
            timeStep ++;
            if (userStr->time.deltat > maxDelt)
                userStr->time.deltat = maxDelt;
            userStr->time.deltat /= stepFactor;
            if (userStr->time.deltat >= maxDelt)
                userStr->time.deltat = maxDelt;
            time += userStr->time.deltat;

            // Write results
            if (timeStep % nSave == 0)
            {
                string solName = oname + to_string(timeStep);
                dhand->printFileLegacyVtk(solName, false);
                // dhand->printFileVtk(solName, false, time);
                // dhand->printFile(solName, OutputMode::Text, true, time, hiperProbl->globalIntegrals());
            }

            if (userStr->time.deltat > 4.0)
                nRemsh = 5;
            if (userStr->time.deltat > 6.0)
                nRemsh = 2;
            if (userStr->time.deltat > 8.0)
                nRemsh = 1;

            // Remesh
            if (timeStep % nRemsh == 0)
            {
                // Remesh
                RCP<Remesher> remesher = rcp(new Remesher);
                remesher->setDOFsHandler(dhand, {"DOF_0"});
                remesher->setRemeshMethod(RemeshMethod::Parallel, levels);
                remesher->setDefaultParameters();
                remesher->Update();
                remesher->newDOFsHands(dhand);
                cout << "Finished remeshing" << endl;

                // hiperproblem
                hiperProbl = rcp(new HiPerProblem);
                hiperProbl->setUserStructure(userStr);
                hiperProbl->setDOFsHandlers({dhand});
                hiperProbl->setIntegration("Integ", {"dhand"});
                hiperProbl->setElementFillings("Integ", PredefinedElementFillings::AllenCahn);
                hiperProbl->setCubatureGauss("Integ", 4);
                hiperProbl->Update();

                // Linear solver MUMPS
                // RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
                // linSolver->setHiPerProblem(hiperProbl);
                // linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
                // linSolver->setDefaultParameters();
                // linSolver->Update();

                // Linear solver AztecOO
                linSolver = rcp (new AztecOOIterativeLinearSolver());
                linSolver->setHiPerProblem(hiperProbl);
                linSolver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
                linSolver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
                linSolver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilu);
                linSolver->setTolerance(1.E-8);
                linSolver->setMaxNumIterations(5000);
                linSolver->setDefaultParameters();
                linSolver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
                linSolver->Update();

                // Non-linear solver
                nonlinSolver = rcp (new NewtonRaphsonNonlinearSolver());
                nonlinSolver->setLinearSolver(linSolver);
                nonlinSolver->setMaxNumIterations(10);
                nonlinSolver->setResTolerance(1.E-8);
                nonlinSolver->setSolTolerance(1.E-8);
                nonlinSolver->setLineSearch(false);
                nonlinSolver->setConvRelTolerance(true);
                nonlinSolver->setPrintIntermInfo(true);
                nonlinSolver->setPrintSummary(false);
                nonlinSolver->Update();

            }
        }
        else
        {
            // Restore previous values
            dhand->nodeDOFs->setValue(dhand->nodeDOFs0);

            // Correct time-step size
            userStr->time.deltat *= stepFactor;
        }

        //Check steady-state
        if (userStr->time.deltat < 1.e-14)
            break;
    }


    // **************************************************************//
    // *****                      FINALIZE                      *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
