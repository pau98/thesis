// hiperlife headers
#include "hl_Core.h"
#include "hl_ParamStructure.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"             
#include "hl_GlobalBasisFunctions.h" 
#include "hl_StructMeshGenerator.h"  
#include "hl_UnstructGmshMeshGenerator.h"  
#include "hl_MeshLoader.h"  
#include "hl_DistributedMesh.h"      
#include "hl_FillStructure.h"        
#include "hl_DOFsHandler.h"          
#include "hl_HiPerProblem.h"         
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include <ttl.h>
#include <ad.h>

void ElementFilling(hiperlife::FillStructure& fillStr);
void BorderFilling(hiperlife::FillStructure& fillStr);

int main(int argc, char** argv)
{
    using namespace std;
    using namespace hiperlife;

    hiperlife::Init(argc, argv);
       
    // SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();
    // structMesh->setBasisFuncType(BasisFuncType::Lagrangian);
    // structMesh->setBasisFuncOrder(1);
    // structMesh->setElemType(ElemType::Parallelep);
    // structMesh->genCube(10);

    SmartPtr<MeshLoader> structMesh = Create<MeshLoader>();
    structMesh->setBasisFuncType(BasisFuncType::Linear);
    // structMesh->setBasisFuncOrder(1);
    structMesh->setElemType(ElemType::Tetrah);
    structMesh->loadVtk("ball.vtk",MeshType::Sequential);

    if(MyRank()==0)
    {
        for(int i = 0; i < structMesh->_nPts; i++)
        {
            using namespace ttl;
            wrapper<double,1> x(&structMesh->_glob_x_nodes[3*i],3);
            if(x.norm()>0.99)
                structMesh->_glob_creases[structMesh->_nCreases*i+0] = 1;
        }
    }


    //
    // First, we create the object, which we name disMesh:
    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    SmartPtr<DOFsHandler> dofHand = Create<DOFsHandler>(disMesh);
    dofHand->setNameTag("dofHand");
    dofHand->setDOFs({"Px","Py","Pz"});
    dofHand->Update();
    dofHand->UpdateGhosts();

    dofHand->nodeDOFs->setValue("Px",0.001);


    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ", 4);
    hiperProbl->setElementFillings("Integ", ElementFilling);
    hiperProbl->setIntegration("Border", {"dofHand"});
    hiperProbl->setCubatureBorderGauss("Border", 3);
    hiperProbl->setElementFillings("Border", BorderFilling);
    hiperProbl->setGlobalIntegrals({"Energy"});
    hiperProbl->Update();

    SmartPtr<MUMPSDirectLinearSolver> linSolver = Create<MUMPSDirectLinearSolver>();
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    SmartPtr<NewtonRaphsonNonlinearSolver> nonlinSolver = Create<NewtonRaphsonNonlinearSolver>();
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(100);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearchEnergyMethod("Energy");
    nonlinSolver->setExitRelMaximum(true);
    nonlinSolver->setResMaximum(1e7);
    nonlinSolver->setSolMaximum(1e7);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    nonlinSolver->solve();

    dofHand->printFileLegacyVtk("polar");

    hiperlife::Finalize();
    return 0;
}

void ElementFilling(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using namespace ttl;
    using namespace autodiff;

    // Define Energy
    auto energy = [&fillStr](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
    {
        using namespace hiperlife;
        using namespace ttl;
        using index::i, index::j, index::l, index::m, index::n;

        SubFillStructure& subFill = fillStr["dofHand"];
        int numDOFs = subFill.numDOFs;
        int nDim = subFill.nDim;
        int pDim = subFill.pDim;
        int eNN  = subFill.eNN;
        wrapper<dual2nd,2> nborDOFs(nborDOFs_vec.data(), eNN, numDOFs);
        wrapper<double,2> nborCoords(subFill.nborCoords.data(), eNN, nDim);
        wrapper<double,1> bf(subFill.nborBFs(), eNN);

        double jac;
        tensor<double,2> gbf(eNN, pDim);
        GlobalBasisFunctions::gradients(gbf, jac, subFill);

        tensor<dual2nd,1> P = bf * nborDOFs;
        tensor<dual2nd,2> gP = nborDOFs.T() * gbf;

        double a=-2.0;
        double b=1.0;
        double k=1.E-1;

        dual2nd splay = gP(i,i);
        dual2nd twist = P(i) * antisym3D(i,j,n) * gP(j,n);
        tensor<dual2nd,1> bend = (antisym3D(i,j,n) * P(j)) * (antisym3D(n,l,m) * gP(l,m)); 

        return jac * 0.5 *  (a * P * P + b * (P*P)*(P*P) + k * ( splay * splay + twist * twist + bend * bend));
    };

    SubFillStructure& subFill = fillStr["dofHand"];
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;
    std::vector<dual2nd> dofs(eNN*numDOFs);
    for (int i = 0; i < eNN*numDOFs; i++)
        dofs[i] = subFill.nborDOFs[i];

    dual2nd en;
    hessian(energy, wrt(dofs), at(dofs), en, fillStr.Bk(0), fillStr.Ak(0,0));

    fillStr.addToGlobalIntegral("Energy", static_cast<double>(en));
}

void BorderFilling(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using namespace ttl;
    using namespace autodiff;

    // Define Energy
    auto energy = [&fillStr](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
    {
        using namespace hiperlife;
        using namespace ttl;
        using index::i, index::j, index::l, index::m, index::n;

        // Rename variables for the main dofsHandler
        SubFillStructure& subFill = fillStr["dofHand"];
        int numDOFs = subFill.numDOFs;
        int nDim = subFill.nDim;
        int pDim = subFill.pDim;
        int eNN  = subFill.eNN;
        wrapper<dual2nd,2> nborDOFs(nborDOFs_vec.data(), eNN, numDOFs);
        wrapper<double,2> nborCoords(subFill.nborCoords.data(), eNN, nDim);
        wrapper<double,1> bf(subFill.nborBFs(), eNN);
        wrapper<double,2> gbf_local(subFill.nborBasisFunctionsGradients(), eNN, pDim);

        auto tangentsRef_ = subFill.tangentsBoundaryRef();
        wrapper<double,2> tangentsRef(tangentsRef_.data(),2,3);
        
        tensor<double,1> x = nborCoords.T() * bf;
        tensor<double,2> Dx = nborCoords.T() * gbf_local;

        tensor<double,2> e = Dx * tangentsRef.T();
        tensor<double,1> cross = antisym3D(n,i,j) * e(i,0) * e(j,1);
        double jac = cross.norm();
        tensor<double,1> normal = cross/jac;

        tensor<dual2nd,1> P = bf * nborDOFs;

        double w=10.0;
        // tensor<double,1> P0 = 0.0*cross/jac;

        // return jac * 0.5 * w * (P-P0) * (P-P0);
        return jac * 0.5 * (w * (P*normal) * (P*normal));
    };
    SubFillStructure& subFill = fillStr["dofHand"];
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;
    std::vector<dual2nd> dofs(eNN*numDOFs);
    for (int i = 0; i < eNN*numDOFs; i++)
        dofs[i] = subFill.nborDOFs[i];

    dual2nd en;
    hessian(energy, wrt(dofs), at(dofs), en, fillStr.Bk(0), fillStr.Ak(0,0));

    fillStr.addToGlobalIntegral("Energy", static_cast<double>(en));
}