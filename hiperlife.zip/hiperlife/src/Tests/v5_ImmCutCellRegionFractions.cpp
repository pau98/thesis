// C++ headers
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <mpi.h>
#include <random>
#include <sstream>
#include <string>
#include <vector>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_Core.h"
#include "hl_CubatureCutCellConforming.h"
#include "hl_DOFsHandler.h"
#include "hl_DistributedMesh.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_HiPerProblem.h"
#include "hl_StructMeshGenerator.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;
using namespace std;

// ---------------------------------------------------------------------
// Region fractions of cut cells used for the aggregation (touch flags).
//
// _createTouchFlags takes the fraction of a cut cell that belongs to a
// region from _cutCellRegionFractions: the exact area of the cell enclosed
// by the polyline the CutCellConforming cubature integrates on (signed
// areas below the chords, no intersections, tolerances or corner flags).
// The 10x10 ray-casting grid (_gridRegionFraction) is only a fallback if
// the regions can not be built from the curves, and here any fallback is a
// failure. Background: quadratic Lagrangian squares; immersed: closed
// cubic BSplines placed in difficult positions (curve passing 1e-8..1e-3
// from a node on either side, knots on mesh lines and nodes, tangency to
// element sides, mode-5 flowers, high curvature, nested curves with three
// regions, hanging-node meshes, random placements).
//
// For every cut cell the fractions are compared against an independent
// reference: the exact BSpline (evaluated here from the control points,
// densely sampled) clipped against the cell. Checks:
//   (a) the BSpline evaluated here is the curve hiperlife builds (knots
//       of _compBsplineEq);
//   (b) fractions match the nine-chord polyline clipped against the cell
//       (Sutherland-Hodgman) to roundoff, and the exact curve up to the
//       chord error;
//   (c) touch flags (well-posed / aggregated) agree with the reference
//       fraction vs eta0 (cells within the tolerance of eta0 are skipped);
//   (d) the region areas integrated with setCubatureCutCellConforming
//       (polygons from _cutCellRegionPolygons: same polyline, no
//       tolerances nor corner flags) match the exact areas;
//   (e) in every element, cut or not, the cubature built from
//       _cutCellRegionPolygons integrates the clipped polyline area to
//       roundoff, with its points in the element and non-negative weights.
// How many cells the grid alone would misclassify is reported for
// information.
//
// Run in serial (the reference is built from the local cut cells).
// ---------------------------------------------------------------------

typedef array<double, 2> Pt;
typedef vector<Pt> Poly;

const double eta0 = 0.5;
const vector<int> regionTag = {3, 5, 7, 11};

// Uniform periodic cubic BSpline (the curve genBsplinesClosedCurve builds
// from uniform knots): piece j uses P_j..P_{j+3}, s in [0,1] (t = 2s-1 in
// hiperlife's immersed element j)
Pt bsplinePoint(const Poly& P, int j, double s)
{
    int n = P.size();
    double b0 = (1. - s) * (1. - s) * (1. - s) / 6.;
    double b1 = (3. * s * s * s - 6. * s * s + 4.) / 6.;
    double b2 = (-3. * s * s * s + 3. * s * s + 3. * s + 1.) / 6.;
    double b3 = s * s * s / 6.;
    Pt x{};
    for (int d = 0; d < 2; d++)
        x[d] = b0 * P[j % n][d] + b1 * P[(j + 1) % n][d] + b2 * P[(j + 2) % n][d] + b3 * P[(j + 3) % n][d];
    return x;
}

Pt bsplineTangent(const Poly& P, int j, double s)
{
    int n = P.size();
    double b0 = -(1. - s) * (1. - s) / 2.;
    double b1 = 1.5 * s * s - 2. * s;
    double b2 = -1.5 * s * s + s + 0.5;
    double b3 = s * s / 2.;
    Pt x{};
    for (int d = 0; d < 2; d++)
        x[d] = b0 * P[j % n][d] + b1 * P[(j + 1) % n][d] + b2 * P[(j + 2) % n][d] + b3 * P[(j + 3) % n][d];
    return x;
}

Poly finePolygon(const Poly& P, int nSub)
{
    Poly poly;
    for (size_t j = 0; j < P.size(); j++)
        for (int k = 0; k < nSub; k++)
            poly.push_back(bsplinePoint(P, j, double(k) / nSub));
    return poly;
}

double signedArea(const Poly& poly)
{
    double A = 0.;
    for (size_t i = 0; i < poly.size(); i++)
    {
        const Pt& a = poly[i];
        const Pt& b = poly[(i + 1) % poly.size()];
        A += a[0] * b[1] - b[0] * a[1];
    }
    return 0.5 * A;
}

double perimeter(const Poly& poly)
{
    double L = 0.;
    for (size_t i = 0; i < poly.size(); i++)
        L += hypot(poly[(i + 1) % poly.size()][0] - poly[i][0], poly[(i + 1) % poly.size()][1] - poly[i][1]);
    return L;
}

// Sutherland-Hodgman against [x0,x1]x[y0,y1]. For a simple (possibly
// non-convex) polygon and a convex window the result can have degenerate
// edges along the window, but its signed area is the intersection area
double clippedArea(const Poly& poly, double x0, double y0, double x1, double y1)
{
    Poly out = poly;
    for (int side = 0; side < 4 and !out.empty(); side++)
    {
        auto inside = [&](const Pt& p)
        {
            switch (side)
            {
                case 0: return p[0] >= x0;
                case 1: return p[0] <= x1;
                case 2: return p[1] >= y0;
                default: return p[1] <= y1;
            }
        };
        auto cut = [&](const Pt& a, const Pt& b)
        {
            double t;
            switch (side)
            {
                case 0: t = (x0 - a[0]) / (b[0] - a[0]); break;
                case 1: t = (x1 - a[0]) / (b[0] - a[0]); break;
                case 2: t = (y0 - a[1]) / (b[1] - a[1]); break;
                default: t = (y1 - a[1]) / (b[1] - a[1]);
            }
            return Pt{a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])};
        };

        Poly in = out;
        out.clear();
        for (size_t i = 0; i < in.size(); i++)
        {
            const Pt& a = in[i];
            const Pt& b = in[(i + 1) % in.size()];
            bool ia = inside(a);
            bool ib = inside(b);
            if (ia and ib)
                out.push_back(b);
            else if (ia and !ib)
                out.push_back(cut(a, b));
            else if (!ia and ib)
            {
                out.push_back(cut(a, b));
                out.push_back(b);
            }
        }
    }
    return fabs(signedArea(out));
}

// Largest distance between the curve and the nine-chord polyline that the
// cut-cell subdivision uses (chords at t = -1 + 2k/9)
double chordError(const Poly& P)
{
    const int nChords = 9;
    const int nS = 40;
    double err = 0.;
    for (size_t j = 0; j < P.size(); j++)
    {
        for (int c = 0; c < nChords; c++)
        {
            Pt a = bsplinePoint(P, j, double(c) / nChords);
            Pt b = bsplinePoint(P, j, double(c + 1) / nChords);
            double lab = hypot(b[0] - a[0], b[1] - a[1]);
            for (int k = 1; k < nS; k++)
            {
                Pt q = bsplinePoint(P, j, (c + double(k) / nS) / nChords);
                double d = fabs((b[0] - a[0]) * (q[1] - a[1]) - (b[1] - a[1]) * (q[0] - a[0])) / lab;
                err = max(err, d);
            }
        }
    }
    return err;
}

// Control points on r(phi) = R*(1 + amp*cos(mode*(phi-phi0))), centered at
// the origin, counter-clockwise, first one at phi0
Poly flowerCP(double R, double amp, int mode, int n, double phi0)
{
    Poly P(n);
    for (int k = 0; k < n; k++)
    {
        double phi = phi0 + 2. * M_PI * k / n;
        double r = R * (1. + amp * cos(mode * (phi - phi0)));
        P[k] = {r * cos(phi), r * sin(phi)};
    }
    return P;
}

// Control points (centered at the origin) whose knots lie on the circle of
// radius Rk, the knot at the start of piece n-1 being at angle phi0
Poly circleKnotsCP(double Rk, int n, double phi0)
{
    double Rcp = 6. * Rk / (4. + 2. * cos(2. * M_PI / n));
    return flowerCP(Rcp, 0., 0, n, phi0);
}

Poly translated(const Poly& P, Pt off)
{
    Poly Q = P;
    for (auto& q : Q)
    {
        q[0] += off[0];
        q[1] += off[1];
    }
    return Q;
}

// Translation that puts the curve point (piece j, s) at distance dist
// from N along the outward normal: dist > 0 leaves N outside the curve
Pt placeOffset(const Poly& P, int j, double s, Pt N, double dist)
{
    Pt q = bsplinePoint(P, j, s);
    Pt t = bsplineTangent(P, j, s);
    double lt = hypot(t[0], t[1]);
    Pt nOut = {t[1] / lt, -t[0] / lt};
    return {N[0] - dist * nOut[0] - q[0], N[1] - dist * nOut[1] - q[1]};
}

string sci(double x)
{
    ostringstream s;
    s << scientific << setprecision(1) << x;
    return s.str();
}

struct Case
{
    string name;
    vector<Poly> curves;             // control points; with two curves: {inner, outer}
    vector<Pt> regionPts;            // a point in each region: {Interior, Exterior} or {R0, R1, Out}
    int nE = 20;
    bool refined = false;
    // (d) integrated region areas (switch off to check only the fractions and the polygons)
    bool checkArea = true;
};

// Single curve: Interior around center, Exterior at the domain corner
Case singleCurve(string name, Poly curve, Pt center)
{
    Case c;
    c.name = name;
    c.curves = {curve};
    c.regionPts = {center, {0.01, 0.01}};
    return c;
}

template <int I>
void LS_area(hiperlife::FillStructure& fillStr)
{
    SubFillStructure& subFill = fillStr[0];
    vector<double> dbf(subFill.eNN * subFill.pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);
    fillStr.addToGlobalIntegral("Area" + to_string(I), jac);
}

struct Summary
{
    int cases{}, cutCells{}, fallbacks{}, gridMisclassified{};
};

int runCase(const Case& c, Summary& summary)
{
    const bool nested = c.curves.size() == 2;
    const vector<string> tags = nested ? vector<string>{"R0", "R1", "Out"} : vector<string>{"Interior", "Exterior"};
    const int nTags = tags.size();

    // Reference geometry
    vector<Poly> fine;
    vector<Poly> chords9; // the nine-chord polyline hiperlife uses (t = -1 + 2k/9 <-> s = k/9)
    double chordErr = 0.;
    for (auto& P : c.curves)
    {
        fine.push_back(finePolygon(P, 64));
        chords9.push_back(finePolygon(P, 9));
        chordErr = max(chordErr, chordError(P));
    }
    // Fraction of region t in a cell, from the clipped area of each curve (fraction of the cell)
    auto regionFractions = [&](const vector<double>& a) -> vector<double>
    {
        if (nested)
            return {a[1] - a[0], a[0], 1. - a[1]};
        return {a[0], 1. - a[0]};
    };

    // ------------------------------------------------------------------
    // Meshes
    // ------------------------------------------------------------------
    RCP<StructMeshGenerator> back = rcp(new StructMeshGenerator);
    if (!c.refined)
    {
        back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 2);
        back->genStructMesh(c.nE, c.nE);
    }
    else
    {
        // As in 555_ModelVerification: refined towards the curves, with hanging nodes
        Poly coarse;
        for (auto& P : c.curves)
        {
            Poly f = finePolygon(P, 6);
            coarse.insert(coarse.end(), f.begin(), f.end());
        }
        back->setNDim(3);
        back->setBasisFuncType(BasisFuncType::Lagrangian);
        back->setBasisFuncOrder(2);
        back->setElemType(ElemType::Square);
        back->genSquare(c.nE, 1.0);
        back->threeRefine([=](double x, double y, double z)
        {
            double d = 1e10;
            for (auto& p : coarse)
                d = min(d, hypot(x - p[0], y - p[1]));
            if (d < 0.02) return 2;
            if (d < 0.05) return 1;
            return 0;
        }, 2, {20, 20});
    }

    RCP<DistributedMesh> backMesh = rcp(new DistributedMesh);
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->Update();

    RCP<StructMeshGenerator> imm = rcp(new StructMeshGenerator);
    imm->setMesh(ElemType::Line, BasisFuncType::BSplines, 3);
    vector<vector<double>> vU;
    vector<vector<vector<vector<vector<double>>>>> vCP;
    for (auto& P : c.curves)
    {
        int n = P.size();
        vector<double> U(n + 1);
        for (int i = 0; i < n + 1; i++)
            U[i] = i;
        vector<vector<vector<vector<double>>>> CP(n, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        for (int k = 0; k < n; k++)
            CP[k][0][0] = {P[k][0], P[k][1], 0., 0.};
        vU.push_back(U);
        vCP.push_back(CP);
    }
    if (nested)
        imm->genBsplinesNClosedCurves(vU, vCP);
    else
        imm->genBsplinesClosedCurve(vU[0], vCP[0]);

    RCP<DistributedMesh> immMesh = rcp(new DistributedMesh);
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    vector<vector<vector<double>>> regionPts;
    for (auto& p : c.regionPts)
        regionPts.push_back({{p[0], p[1], 0.0}});
    immMesh->setImmersedInteriorPoints(regionPts);
    immMesh->setRegionTags(tags);
    immMesh->setIllPosThreshold(eta0);
    immMesh->setBalanceMesh(true);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->Update();

    // ------------------------------------------------------------------
    // (a) The reference curve is the curve hiperlife builds
    // ------------------------------------------------------------------
    // Start (t = -1) and middle (t = 0) of every immersed element must be the
    // start and middle of a piece of the reference BSpline
    vector<pair<Pt, Pt>> pieces;
    for (auto& P : c.curves)
        for (size_t j = 0; j < P.size(); j++)
            pieces.push_back({bsplinePoint(P, j, 0.), bsplinePoint(P, j, 0.5)});
    for (int e = 0; e < immMesh->loc_nElem(); e++)
    {
        vector<double> abcd = immMesh->_compBsplineEq(immMesh.get(), e);
        Pt xs = {-abcd[0] + abcd[2] - abcd[4] + abcd[6], -abcd[1] + abcd[3] - abcd[5] + abcd[7]};
        Pt xm = {abcd[6], abcd[7]};
        double dmin = 1e10;
        for (auto& pc : pieces)
            dmin = min(dmin, max(hypot(xs[0] - pc.first[0], xs[1] - pc.first[1]),
                                 hypot(xm[0] - pc.second[0], xm[1] - pc.second[1])));
        if (dmin > 1e-10)
        {
            cout << "  [FAIL] " << c.name << ": immersed element " << e << " is not a piece of the reference "
                 << "BSpline (distance " << dmin << "); the reference curve is not the mesh curve" << endl;
            return 1;
        }
    }

    // ------------------------------------------------------------------
    // (b), (c) Fractions and touch flags of every cut cell
    // ------------------------------------------------------------------
    vector<vector<int>> touch(nTags);
    for (int t = 0; t < nTags; t++)
        touch[t] = backMesh->_createTouchFlags(t);

    int nCut{}, nFallback{}, nBadFrac{}, nBadTouch{}, nGridBad{}, nPrinted{};
    double maxErr{}, maxErr9{}, minRef = 1.;
    for (int e = 0; e < backMesh->loc_nElem(); e++)
    {
        int flag = backMesh->elemTag(1, e, IndexType::Local);
        if (flag % 2 != 0)
            continue;
        nCut++;

        vector<double> cc = backMesh->_elemNborCornerCoords(e, IndexType::Local);
        double x0 = cc[0], y0 = cc[1], x1 = cc[9], y1 = cc[10];
        double h = x1 - x0;
        double area = (x1 - x0) * (y1 - y0);
        vector<double> a;
        for (auto& f : fine)
            a.push_back(clippedArea(f, x0, y0, x1, y1) / area);
        vector<double> ref = regionFractions(a);
        vector<double> a9;
        for (auto& p9 : chords9)
            a9.push_back(clippedArea(p9, x0, y0, x1, y1) / area);
        vector<double> ref9 = regionFractions(a9);
        // Area between the curve and the polyline inside the cell, over the cell area
        double tol = 4. * chordErr / h + 2e-6;
        // Same polyline, different algorithm (clipping vs areas below the chords): roundoff only
        const double tol9 = 1e-10;

        vector<double> fr = backMesh->_cutCellRegionFractions(e);
        if (fr.empty())
        {
            nFallback++;
            if (nPrinted++ < 5)
                cout << "  [FAIL] " << c.name << ": cell " << e << " no region fractions (grid fallback)" << endl;
        }
        else
        {
            for (int t = 0; t < nTags; t++)
            {
                double err = fabs(fr[t] - ref[t]);
                double err9 = fabs(fr[t] - ref9[t]);
                maxErr = max(maxErr, err);
                maxErr9 = max(maxErr9, err9);
                if (err > tol or err9 > tol9)
                {
                    nBadFrac++;
                    if (nPrinted++ < 5)
                        cout << "  [FAIL] " << c.name << ": cell " << e << " [" << x0 << "," << x1 << "]x[" << y0 << ","
                             << y1 << "] region " << tags[t] << " fraction " << setprecision(15) << fr[t]
                             << " vs polyline " << ref9[t] << " and curve " << ref[t] << setprecision(6) << " (tol "
                             << tol9 << ", " << tol << ")" << endl;
                }
            }
        }

        int glob = backMesh->globalElemId(e);
        for (int t = 0; t < nTags; t++)
        {
            if (flag % regionTag[t] != 0)
                continue;
            minRef = min(minRef, ref[t]);
            bool expected = ref[t] > eta0;
            if (fabs(ref[t] - eta0) <= tol)
                continue;
            if ((touch[t][glob] == 1) != expected)
            {
                nBadTouch++;
                if (nPrinted++ < 5)
                    cout << "  [FAIL] " << c.name << ": cell " << e << " [" << x0 << "," << x1 << "]x[" << y0 << ","
                         << y1 << "] region " << tags[t] << " touch flag " << touch[t][glob]
                         << " but reference fraction " << ref[t] << (fr.empty() ? " (grid fallback)" : "") << endl;
            }
            if ((backMesh->_gridRegionFraction(glob, t) > eta0) != expected)
                nGridBad++;
        }
    }

    // ------------------------------------------------------------------
    // (d) Region areas through setCubatureCutCellConforming
    // ------------------------------------------------------------------
    int nBadArea{};
    string note;
    if (c.checkArea)
    {
        RCP<DOFsHandler> backDHand = rcp(new DOFsHandler(backMesh));
        backDHand->setNameTag("backDHand");
        vector<string> dofs;
        for (int t = 0; t < nTags; t++)
            dofs.push_back("u" + to_string(t));
        backDHand->setDOFs(dofs);
        backDHand->setDofTags(tags);
        backDHand->Update();

        void (*fills[3])(FillStructure&) = {LS_area<0>, LS_area<1>, LS_area<2>};
        RCP<HiPerProblem> hp = rcp(new HiPerProblem);
        hp->setDOFsHandlers({backDHand});
        vector<string> integrals;
        for (int t = 0; t < nTags; t++)
            integrals.push_back("Area" + to_string(t));
        hp->setGlobalIntegrals(integrals);
        for (int t = 0; t < nTags; t++)
        {
            hp->setIntegration("Integ" + to_string(t), {"backDHand"});
            hp->setCubatureCutCellConforming("Integ" + to_string(t), 4, 2, tags[t]);
            hp->setElementFillings("Integ" + to_string(t), fills[t]);
        }
        try
        {
            hp->Update();
            hp->FillLinearSystem();

            vector<double> aCurves;
            double perimeters{};
            for (auto& f : fine)
            {
                aCurves.push_back(fabs(signedArea(f)));
                perimeters += perimeter(f);
            }
            vector<double> exact = regionFractions(aCurves); // domain area is 1
            double tolArea = 2. * chordErr * perimeters + 1e-10;
            for (int t = 0; t < nTags; t++)
            {
                double A = hp->globalIntegral("Area" + to_string(t));
                if (fabs(A - exact[t]) > tolArea)
                {
                    nBadArea++;
                    cout << "  [FAIL] " << c.name << ": integrated area of " << tags[t] << " " << setprecision(12) << A
                         << " vs exact " << exact[t] << " (tol " << tolArea << ")" << setprecision(6) << endl;
                }
            }
        }
        catch (const std::exception& ex)
        {
            nBadArea++;
            note = "  (cubature threw)";
            cout << "  [FAIL] " << c.name << ": setCubatureCutCellConforming threw: " << ex.what() << endl;
        }
    }
    else
        note = "  (no area check)";

    // ------------------------------------------------------------------
    // (e) Cubature from _cutCellRegionPolygons in every element (cut or not):
    //     weights add up to the clipped polyline area, points in the
    //     element, weights non-negative
    // ------------------------------------------------------------------
    int nBadPoly{};
    double maxErrPoly{};
    for (int e = 0; e < backMesh->loc_nElem(); e++)
    {
        vector<double> cc = backMesh->_elemNborCornerCoords(e, IndexType::Local);
        double x0 = cc[0], y0 = cc[1], x1 = cc[9], y1 = cc[10];
        double area = (x1 - x0) * (y1 - y0);
        vector<double> a9;
        for (auto& p9 : chords9)
            a9.push_back(clippedArea(p9, x0, y0, x1, y1) / area);
        vector<double> ref9 = regionFractions(a9);
        for (int t = 0; t < nTags; t++)
        {
            string what;
            try
            {
                CubatureCutCellConforming cuba;
                cuba.setElemType(ElemType::Square);
                cuba.setNumIntPts(1);
                cuba.setIntegrationOrder(1);
                cuba.setPolygons(backMesh->_cutCellRegionPolygons(e, t));
                cuba.Update();
                CubatureInfo info = cuba.cubatureInfo();
                double A{};
                for (int k = 0; k < info.iPts; k++)
                {
                    A += info.wSamples[k];
                    if (info.wSamples[k] < 0.)
                        what = "negative weight";
                    if (fabs(info.xSamples[2 * k]) > 1. + 1e-14 or fabs(info.xSamples[2 * k + 1]) > 1. + 1e-14)
                        what = "point outside the element";
                }
                double err = fabs(A / 4. - ref9[t]);
                maxErrPoly = max(maxErrPoly, err);
                if (err > 1e-10)
                {
                    ostringstream s;
                    s << setprecision(15) << "area " << A / 4. << " vs polyline " << ref9[t];
                    what = s.str();
                }
            }
            catch (const std::exception& ex)
            {
                what = string("threw: ") + ex.what();
            }
            if (!what.empty())
            {
                nBadPoly++;
                if (nPrinted++ < 5)
                    cout << "  [FAIL] " << c.name << ": polygons of element " << e << " [" << x0 << "," << x1 << "]x["
                         << y0 << "," << y1 << "] region " << tags[t] << ": " << what << endl;
            }
        }
    }

    int err = nBadFrac + nBadTouch + nBadArea + nFallback + nBadPoly;
    if (VerboseRank())
        cout << "  " << left << setw(46) << c.name << right << " cut " << setw(4) << nCut << "  fallback " << setw(3)
             << nFallback << "  max|frac err| polyline " << scientific << setprecision(1) << maxErr9 << " curve "
             << maxErr << " cubature " << maxErrPoly << "  min frac " << minRef
             << fixed << setprecision(6) << "  grid-only misclassified " << setw(2) << nGridBad << "  "
             << (err == 0 ? "OK" : "FAILED") << note << defaultfloat << endl;

    summary.cases++;
    summary.cutCells += nCut;
    summary.fallbacks += nFallback;
    summary.gridMisclassified += nGridBad;
    return err;
}

int main(int argc, char** argv)
{
    hiperlife::Init(argc, argv);

    int nProcs{};
    MPI_Comm_size(MPI_COMM_WORLD, &nProcs);
    if (nProcs != 1)
    {
        if (VerboseRank())
            cout << "v5_ImmCutCellRegionFractions: run it in serial" << endl;
        hiperlife::Finalize();
        return 1;
    }

    const double h = 1. / 20.;
    vector<Case> cases;

    // Curve passing at distance delta from the node (0.55,0.45), at a knot,
    // node outside (corner sliver of the exterior) and inside (corner sliver
    // of the interior)
    {
        const int n = 24;
        Poly base = circleKnotsCP(0.2, n, 0.4);
        for (double delta : {5e-3, 5e-5, 6.7e-6, 1e-8})
        {
            for (int sgn : {1, -1})
            {
                Pt off = placeOffset(base, n - 1, 0., {0.55, 0.45}, sgn * delta);
                cases.push_back(singleCurve(string("sliver at knot, node ") + (sgn > 0 ? "out" : "in") + " by " + sci(delta),
                                            translated(base, off), off));
            }
        }
        // Same, in the middle of the first chord: with the node inside by less
        // than the chord error the corner flags (exact curve) and the
        // polyline disagree, which should end in the grid fallback
        double ce = chordError(base);
        for (double dist : {ce / 3., -ce / 3.})
        {
            Pt off = placeOffset(base, n - 1, 1. / 18., {0.55, 0.45}, dist);
            cases.push_back(singleCurve(string("node ") + (dist > 0 ? "out" : "in") + " by chord err/3, mid-chord",
                                        translated(base, off), off));
        }
    }

    // Knot exactly on a horizontal mesh line (y = 9h, a row of points of
    // the ray-casting grid), on a mesh node, and the curve through a mesh
    // node inside a piece
    {
        const int n = 24;
        Poly base = circleKnotsCP(0.2, n, 2. * M_PI / 3.);
        vector<pair<string, pair<Pt, double>>> spots = {{"knot on mesh line", {{0.5 + 0.3 * h, 9 * h}, 0.}},
                                                        {"knot on mesh node", {{0.5, 9 * h}, 0.}},
                                                        {"curve through node mid-piece", {{0.5, 9 * h}, 0.37}}};
        for (auto& sp : spots)
        {
            Pt off = placeOffset(base, n - 1, sp.second.second, sp.second.first, 0.);
            cases.push_back(singleCurve(sp.first, translated(base, off), off));
        }
    }

    // Top of the curve tangent to the mesh line y = 12h, just below and
    // just above it (thin cap with two crossings on one side and no
    // corner of the cap's region in the cell)
    {
        const int n = 24;
        Poly base = circleKnotsCP(0.2, n, M_PI / 2.);
        for (double delta : {5e-6, 5e-9})
        {
            for (int sgn : {1, -1})
            {
                Pt off = placeOffset(base, n - 1, 0., {0.5 + 0.37 * h, 12 * h}, sgn * delta);
                Case c = singleCurve(string("tangent to mesh line, ") + (sgn > 0 ? "below" : "above") + " by " + sci(delta),
                                     translated(base, off), off);
                cases.push_back(c);
            }
        }
    }

    // Mode-5 flower (organoid-like), on 20x20 and on a coarser 10x10 mesh
    // (several immersed pieces per cell)
    for (int nE : {20, 10})
    {
        Pt off = {0.5 + 0.21 * h, 0.5 + 0.37 * h};
        Case c = singleCurve("mode-5 flower, " + to_string(nE) + "x" + to_string(nE),
                             translated(flowerCP(0.25, 0.15, 5, 30, 0.1), off), off);
        c.nE = nE;
        cases.push_back(c);
    }

    // Top knot exactly on the mesh node (0.5,12h), tangent along the mesh line
    // (the curve touches four elements at one corner)
    {
        const int n = 24;
        Poly base = circleKnotsCP(0.2, n, M_PI / 2.);
        Pt off = placeOffset(base, n - 1, 0., {0.5, 12 * h}, 0.);
        cases.push_back(singleCurve("knot on mesh node, tangent to mesh line", translated(base, off), off));
    }

    // Curve inside a single element (a ring in that element), and nested
    // curves whose inner curve is inside a single element (a hole in R0)
    {
        Pt cellCenter = {0.5 + 0.5 * h, 0.5 + 0.5 * h};
        Case c = singleCurve("curve inside one element", translated(circleKnotsCP(0.3 * h, 8, 0.2), cellCenter), cellCenter);
        cases.push_back(c);

        Case cn;
        cn.name = "nested, inner curve inside one element";
        cn.curves = {translated(circleKnotsCP(0.3 * h, 8, 0.2), cellCenter),
                     translated(circleKnotsCP(0.3, 40, 0.), {0.5 + 0.17 * h, 0.5 - 0.23 * h})};
        cn.regionPts = {{0.28, 0.5}, cellCenter, {0.01, 0.01}};
        cases.push_back(cn);
    }

    // High curvature: radius below one element, several crossings per side
    {
        Pt off = {0.5 + 0.13 * h, 0.5 - 0.29 * h};
        cases.push_back(singleCurve("small circle (R = 0.8h)", translated(circleKnotsCP(0.8 * h, 8, 0.3), off), off));
    }

    // Nested curves (regions R0 between them, R1 inside, Out), as in
    // 555_ModelVerification, with an off-center inner flower
    Case nestedCase;
    {
        // (outer center off the mesh nodes: centered at (0.5,0.5) its leftmost knot would be exactly on
        // the node (0.2,0.5) with a vertical tangent, which the region flags of the corners do not handle)
        Pt offIn = {0.54, 0.5 + 0.11 * h};
        Pt offOut = {0.5 + 0.17 * h, 0.5 - 0.23 * h};
        nestedCase.name = "nested curves, R0/R1/Out";
        nestedCase.curves = {translated(flowerCP(0.13, 0.1, 5, 20, 0.2), offIn),
                             translated(circleKnotsCP(0.3, 40, 0.), offOut)};
        nestedCase.regionPts = {{0.28, 0.5}, offIn, {0.01, 0.01}};
        cases.push_back(nestedCase);
    }

    // Hanging-node meshes refined towards the curves
    {
        Pt off = {0.5 + 0.21 * h, 0.5 + 0.37 * h};
        Case c = singleCurve("mode-5 flower, refined mesh", translated(flowerCP(0.25, 0.15, 5, 30, 0.1), off), off);
        c.nE = 16;
        c.refined = true;
        cases.push_back(c);

        Case cn = nestedCase;
        cn.name = "nested curves, refined mesh";
        cn.nE = 16;
        cn.refined = true;
        cases.push_back(cn);
    }

    // Random slivers (random node, side, angle and distance 1e-8..1e-3)
    // and random flowers
    {
        mt19937 gen(1234);
        uniform_real_distribution<double> U01(0., 1.);
        uniform_int_distribution<int> node(7, 13);
        const int n = 20;
        for (int r = 0; r < 25; r++)
        {
            Poly base = circleKnotsCP(0.15, n, 2. * M_PI * U01(gen));
            double delta = pow(10., -8. + 5. * U01(gen));
            if (U01(gen) < 0.5)
                delta = -delta;
            double s = U01(gen) < 0.5 ? 0. : U01(gen);
            Pt N = {node(gen) * h, node(gen) * h};
            Pt off = placeOffset(base, n - 1, s, N, delta);
            cases.push_back(singleCurve("random sliver " + to_string(r) + " (" + sci(delta) + ")", translated(base, off), off));
        }
        for (int r = 0; r < 15; r++)
        {
            Pt off = {0.5 + h * U01(gen), 0.5 + h * U01(gen)};
            double R = 0.2 + 0.1 * U01(gen);
            double amp = 0.2 * U01(gen);
            double phi0 = 2. * M_PI * U01(gen);
            cases.push_back(singleCurve("random flower " + to_string(r), translated(flowerCP(R, amp, 5, 24 + r, phi0), off), off));
        }
    }

    int err = 0;
    Summary summary;
    if (VerboseRank())
        cout << "Cut-cell region fractions for aggregation (quadratic squares, cubic BSplines, eta0 = " << eta0 << ")"
             << endl;
    for (auto& c : cases)
    {
        try
        {
            err += runCase(c, summary);
        }
        catch (const std::exception& ex)
        {
            err++;
            cout << "  [FAIL] " << c.name << ": threw " << ex.what() << endl;
        }
    }

    if (VerboseRank())
    {
        cout << "Cases " << summary.cases << ", cut cells " << summary.cutCells << ", grid fallbacks "
             << summary.fallbacks << ", cells the grid alone would misclassify " << summary.gridMisclassified << endl;
        if (err == 0)
            cout << "** All tests passed **" << endl;
        else
            cout << "** " << err << " failures **" << endl;
    }

    hiperlife::Finalize();
    return err == 0 ? 0 : 1;
}
