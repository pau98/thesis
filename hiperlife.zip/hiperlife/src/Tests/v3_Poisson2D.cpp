
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_Geometry.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);

/// In this first tutorial everything is implemented inside the main
///   function
int main()
{


    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);


    ///=============== Define parameters of the model ===============///
    double force = 0.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;


    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//



    // Remove warning by an error in unclamp nurbs
    // Implement unclamp nurbs
    // diskSquared only for nurbs
    // Quarterplatewithcircularhole only for nurbs
    // Minimize the number of repeated knot spans in surfaces of revolution


    ///====================== Mesh generation ======================///
    ///
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Triang;
    int bfOrder = 3;
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genStructMesh(8);
    // structMesh->genAnnularSector(21, 29, 0.25, 0.5, 0.0, M_PI/2.0);

    ///===========             Distribute mesh            ===========///
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    disMesh->printFileLegacyVtk("Mesh");
    disMesh->printFileLegacyCSV("Mesh");

    cout << disMesh->myRank() << ": " << disMesh->listGhosts().size() << endl;

    cout <<  disMesh->myRank()  << " ";
    for (auto g: disMesh->listGhosts())
        cout << g << " ";
    cout << endl;

    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//  //FIXME: Change name in this section
    /// **************************************************************//

    ///===========           Create DOFHandler            ===========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    // dofHand->setNumNodeAuxF(1);
    dofHand->Update();

    ///===========          Boundary conditions          ===========///
    // dofHand->setBoundaryCondition(0, 0.0);
    dofHand->setBoundaryCondition(0, MAxis::Xmin, -1.0);
    dofHand->setBoundaryCondition(0, MAxis::Xmax, 1.0);
    // dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x){return x;});
    // dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});

    for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    {
        double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
        double y = dofHand->mesh->nodeCoord(i, 1, IndexType::Local);
        double z = dofHand->mesh->nodeCoord(i, 2, IndexType::Local);
        // if (y > 0.9)
        //     dofHand->setConstraint(0, i, IndexType::Local, 1.0);
        // if (y < -0.9)
        //     dofHand->setConstraint(0, i, IndexType::Local, -1.0);
        // dofHand->nodeAuxF->setValue(0, i, IndexType::Local, x);
    }
    dofHand->UpdateGhosts();



    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//  //FIXME: Change name in this section
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStruct(userStr);
    hiperProbl->setDOFsHandlers({dofHand});

    ///===========            Set integration             ===========///
    hiperProbl->setIntegration("Integ", {"dofHand"}, {IntegType::Master});
<<<<<<< HEAD
    hiperProbl->setIntegration_CubatureStd("Integ", "CubatureGauss", 3);
=======
    hiperProbl->setCubatureGauss("Integ");
>>>>>>> dev-v3-restructure
    hiperProbl->setIntegration_ElemFillings("Integ", LS);

    ///===========               Set solver               ===========///
    hiperProbl->setSolver(PDEType::Linear, LinSolverType::AztecOO);
    hiperProbl->setSolverOptions({{"precond", "Jacobi"}});
    hiperProbl->setSolverOptions({{"solver", "cg"}});
    hiperProbl->setSolverOptions({{"tol", "1e-8"}});
    hiperProbl->setSolverOptions({{"max_iter", "5000"}});
    hiperProbl->setSolverOptions({{"output", "none"}});

    ///===========                 Update                ===========///
    hiperProbl->Update();



    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    hiperProbl->FillLinearSystem();
    // cout << *hiperProbl->A << endl;

    ofstream ofiletxt("matrix."+ to_string(hiperProbl->myRank())+".txt");
    ofiletxt << *hiperProbl->A << endl;
    ofiletxt.close();

    auto status = hiperProbl->Solve();
    cout << status << endl;

    hiperProbl->UpdateSolution();

    dofHand->printFile("Poisson");
    dofHand->printFileLegacyVtk("Poisson", true);
    dofHand->printFileLegacyCSV("Poisson", true);


    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}

void LS(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.getDer(0);  // Local shape function
    double* glNa = subFill.getDer(1); // Local shape function derivatives
    double gNa[eNN*pDim], jac;
    SGeometry::globalBasisFunctionGradient(gNa, jac, eNN, pDim, nDim, xe_nodes.data(), glNa);

    vector<double> x(pDim);
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d]  * Na[i];
    }

    // if (x[0] < 0.9)
        // force *= x[0];

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}
