/*
    **************************************************************************************************
    hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Copyright (c) 2018 Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
    **************************************************************************************************
    hiperlife is under GNU General Public License ("GPL").
    GNU General Public License ("GPL") copyright permissions statement:
    This file is part of hiperlife, hiperlife is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by the Free Software Foundation,
    either version 3 of the License, or (at your option) any later version.
    hiperlife is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along with this program.
    If not, see <http://www.gnu.org/licenses/>.
    **************************************************************************************************
*/


////////////////////////////////////////////////////////////////////////
///                                                                  ///
///                       ###     ###   ######                       ///
///                       ###     ###   ######                       ///
///                       ###     ###   ######                       ///
///                       ###########   ######                       ///
///                       ###########   ######                       ///
///                       ###     ###   ######                       ///
///                       ###     ###                                ///
///                       ###     ###                                ///
///                                                                  ///
///                        hiperlife Tutorials                       ///
///                                                                  ///
////////////////////////////////////////////////////////////////////////
///  TODO                                                            ///
////////////////////////////////////////////////////////////////////////


// C++ headers
#include <iostream>
#include <mpi.h>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_Geometry.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_ConsistencyCheck.h"
#include <hl_LoadBalance.h>
#include <hl_LinearSolver_Direct_Amesos2.h>
#include <hl_NonlinearSolver_NewtonRaphson.h>
#include "hl_Geometry.h"
#include "hl_SurfLagrParam.h"
#include "hl_Tensor.h"
#include "hl_LinearSolver_Direct_Amesos.h"


using namespace hiperlife;
using Teuchos::rcp;
using Teuchos::RCP;


void LS_GEOM(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace hiperlife;
    using Teuchos::RCP;

    auto& subFill = (*fillStr)[0];

    int numDOFs  = subFill.numDOFs;
    int eNN      = subFill.eNN;
    vector<double>& nborCoords  = subFill.nborCoords;

    RCP<UserStructure> userStr   = fillStr->userStr;

    //MAIN OUTPUT declaration
    auto& Ak  = fillStr->Ak(0, 0); // <<=== MAIN OUTPUT
    auto& Bk  = fillStr->Bk(0);    // <<=== MAIN OUTPUT

    int N_e = numDOFs*eNN;
    //------------------------------------------------------------------------------------

    // Get the value of the basis functions and derivatives at the Gauss point k
    double *bf  = subFill.nborBFsDers(0);
    double *dbf = subFill.nborBFsDers(1);

    double x[3];
    double metric[4];
    double e1[3], e2[3];
    Math::MatTMult(x, 3, eNN, 1, nborCoords.data(), bf);
    SurfLagrParam::MetricTensor(metric,e1,e2,eNN,nborCoords.data(),dbf);
    double jac = sqrt(Math::DetMat2x2(metric));




    int shapeType = fillStr->userStr->iparam[0];
    double z = x[2];

    double targetx[3];
    double r = Math::Norm3D(x);
    Math::AX(x, 3 , 1.0/r);

    double fr = sqrt(x[0]*x[0] + x[1]*x[1]);

    if (shapeType == 1) //Ellipsoid
        z = x[2] * 0.75;
    else if (shapeType == 2) //Red blood cell
        z = x[2] * 0.4 * (1.0-0.4*cos(1.15*M_PI*fr));
    else if (shapeType == 3) //spacecraft
        z = x[2] * 0.7 * (1.0+0.1*cos(2.0*M_PI*x[1]/r));

    targetx[0] = 100.0 * x[0];
    targetx[1] = 100.0 * x[1];
    targetx[2] = 100.0 * z;

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            //Add submatrix to elemental matrix
            for (int n = 0; n < numDOFs; n++)
                Ak[(numDOFs*i+n)*N_e + numDOFs*j + n] = jac * bf[i] * bf[j];
        }

        //Add submatrix to elemental matrix
        for (int n = 0; n < numDOFs; n++)
            Bk[numDOFs*i + n] = jac * bf[i] * targetx[n];

    }
}

void CorrectCoordNodalValues(Teuchos::RCP<hiperlife::DistributedMesh> mesh, int shapeType)
{
    using namespace std;
    using namespace hiperlife;
    using Teuchos::rcp;
    using Teuchos::RCP;

    RCP<DOFsHandler> predofHand;
    predofHand = rcp(new DOFsHandler(mesh));
    predofHand->setNameTag("predofHand");
    predofHand->setNumDOFs(3);
    predofHand->Update();


    RCP<UserStructure> userStr = rcp(new UserStructure);      //User structure
    userStr->iparam.resize(1);
    userStr->iparam[0] = shapeType;


    RCP<HiPerProblem> prehp = rcp(new HiPerProblem("HiPerProblem"));
    prehp->setUserStructure(userStr);

    prehp->setDOFsHandlers({predofHand});
    prehp->setGlobalIntegrals({"OrigVol", "OrigArea", "LSVol", "LSArea"});
    prehp->setIntegration("LeastSq", {"premech"});

    prehp->setCubatureGauss("LeastSq", 3);
    prehp->setElementFillings("LeastSq", LS_GEOM);

    prehp->Update();

    RCP<AmesosDirectLinearSolver> linSolver = rcp (new AmesosDirectLinearSolver());
    linSolver->setHiPerProblem(prehp);
    linSolver->setNumericFactorization(true);
    linSolver->setSymbolicFactorization(true);
    linSolver->Update();

    linSolver->solve();

    // Set the coordinates obtained by the Least Squares
    mesh->_nodeData->setValue(prehp->linProbl->GetLHS());
    mesh->_nodeData->UpdateGhosts();

}

void LS(RCP<FillStructure> fillStr)
{

    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //------------------------------------------------------------------
    // [2] Input variables

    //[1.1] Positions
    auto& subFill = (*fillStr)["posDHand"];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;

    tensor<double,2,false> nborDOFs0(subFill.nborDOFs0.data(),eNN,numDOFs);
    tensor<double,2,false> nborDOFs(subFill.nborDOFs.data(),eNN,numDOFs);

    tensor<double,1,false>   bf(subFill.nborBFsDers(0),eNN);
    tensor<double,2,false>  Dbf(subFill.nborBFsDers(1),eNN,pDim);
    tensor<double,3,false> DDbf(subFill.nborBFsDers(2),eNN,pDim,pDim);

    //[1.2] Tensions
    auto& t_subFill = (*fillStr)["tenDHand"];
    int t_eNN  = t_subFill.eNN;

    tensor<double,1,false> t_nborDOFs(t_subFill.nborDOFs.data(),t_eNN);

    tensor<double,1,false> t_bf(t_subFill.nborBFsDers(0),t_eNN);

    //[1.3] Global constraints
    auto& g_subFill = (*fillStr)["gloDHand"];
    int g_numDOFs = g_subFill.numDOFs;

    tensor<double,1,false> gDOFs(g_subFill.nborDOFs.data(),g_numDOFs);
    double pressure = gDOFs(0);
    tensor<double,1> F = gDOFs(range(1,3));
    tensor<double,1> L = gDOFs(range(4,6));

    //[1.4] Parameters
    double deltat = fillStr->userStr->dparam[2];
    double kappa  = fillStr->userStr->dparam[0] * deltat;
    double mu     = fillStr->userStr->dparam[1];

    //OUTPUTS
    tensor<double,2,false> Bp(fillStr->Bk(0).data(),eNN,numDOFs);
    tensor<double,1,false> Bt(fillStr->Bk(1).data(),t_eNN);
    tensor<double,1,false> Bg(fillStr->Bk(2).data(),g_numDOFs);

    tensor<double,4,false> App(fillStr->Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,3,false> Apt(fillStr->Ak(0,1).data(),eNN,numDOFs,t_eNN);
    tensor<double,3,false> Apg(fillStr->Ak(0,2).data(),eNN,numDOFs,g_numDOFs);
    tensor<double,3,false> Atp(fillStr->Ak(1,0).data(),t_eNN,eNN,numDOFs);
    tensor<double,3,false> Agp(fillStr->Ak(2,0).data(),g_numDOFs,eNN,numDOFs);


    //------------------------------------------------------------------
    // [2] Compute variables

    //[2.1] Previous time-step
    tensor<double,1> xu_n(nDim);
    tensor<double,1> xv_n(nDim);
    tensor<double,1> normal_n(nDim);
    tensor<double,2> metric_n(pDim,pDim);
    SurfLagrParam::Normal(normal_n, metric_n, xu_n, xv_n, eNN, nborDOFs0, Dbf);

    tensor<double,1> x_n = bf * nborDOFs0;
    tensor<double,2> imetric_n = metric_n.inv();
    double jac_n = sqrt(metric_n.det());

    double xnormal_n = x_n * normal_n;

    //[2.2] Current time-step
    tensor<double,1> xu(nDim);
    tensor<double,1> xv(nDim);
    tensor<double,1> xuu(nDim);
    tensor<double,1> xuv(nDim);
    tensor<double,1> xvv(nDim);
    tensor<double,1> normal(nDim);
    tensor<double,2> metric(pDim,pDim);
    tensor<double,2> curva(pDim,pDim);
    tensor<double,3> christsym(pDim,pDim,pDim);
    SurfLagrParam::ChristoffelSymbols(christsym, curva, metric, normal, xu, xv, xuu, xvv, xuv, eNN, nborDOFs, Dbf, DDbf);

    tensor<double,1> x =  bf * nborDOFs;
    tensor<double,2> imetric = metric.inv();
    double jac       = sqrt(metric.det());
    double meancurva = product(imetric,curva,{{0,0},{1,1}});

    double xnormal = x * normal;

    tensor<double,2> rodt    = metric-metric_n;
    tensor<double,2> rodt_CnCn = imetric_n * rodt * imetric_n;

    //[2.3] Other variables
    double tr_rodt = (jac - jac_n)/jac_n;

    double tension = (t_nborDOFs * t_bf) * deltat;

    //------------------------------------------------------------------
    // [3] Energies and dissipations

    //[3.1] Shear dissipation
    double dissipation = jac_n * mu * product(rodt, rodt_CnCn,{{0,0},{1,1}});
    //[3.2] Helfrich energy
    double helfrich    = 0.5 * jac * kappa * meancurva * meancurva;
    //[3.3] Rayleighian
    double rayleighian = helfrich + dissipation;

    //[3.4] Add contributions to global integrals
    fillStr->addToGlobalIntegral("Rayleighian",rayleighian);
    fillStr->addToGlobalIntegral("Helfrich",helfrich);
    fillStr->addToGlobalIntegral("Dissipation",dissipation);
    fillStr->addToGlobalIntegral("Trd",jac_n * tr_rodt);

    //------------------------------------------------------------------
    // [4] Right-hand sides

    tensor<double,4> d_metric(eNN,numDOFs,pDim,pDim);
    SurfLagrParam::d_Metric(d_metric,Dbf,xu,xv);

    tensor<double,4> d_metric_CC  = product(product(d_metric,imetric,{{2,0}}),imetric,{{2,0}});
    tensor<double,4> d_metric_CnCn = product(product(d_metric,imetric_n,{{2,0}}),imetric_n,{{2,0}});

    tensor<double,4> d_imetric = -1.0 * d_metric_CC;

    tensor<double,2> d_jac(eNN,numDOFs);
    SurfLagrParam::d_Jac(d_jac,Dbf,xu,xv,normal);

    tensor<double,3> d_normal(eNN,numDOFs,nDim);
    SurfLagrParam::d_Normal(d_normal,Dbf,xu,xv,normal,jac,d_jac);

    tensor<double,4> d_curva(eNN,numDOFs,pDim,pDim);
    SurfLagrParam::d_Curva(d_curva,DDbf,xuu,xuv,xvv,normal,d_normal);

    tensor<double,2> d_meancurva = product(imetric,d_curva,{{0,2},{1,3}}) + product(curva,d_imetric,{{0,2},{1,3}});

    //[4.1] Dissipation
    Bp += 0.5 * jac_n * mu * product(rodt_CnCn,d_metric,{{0,2},{1,3}});

    //[4.2] Helfrich energy
    Bp += 0.5 * kappa * (d_jac * meancurva * meancurva + (2.0 * jac * meancurva) * d_meancurva);

    //[4.3] Tension
    Bp += tension * d_jac;
    Bt += (jac_n * tr_rodt * deltat) * t_bf;

    //[4.4] Volume constraint
    Bp    += pressure/3.0 * (d_jac * xnormal + jac * (d_normal * x) + jac * outer(bf,normal));
    Bg(0) += (jac * xnormal - jac_n*xnormal_n)/3.0;

    //[4.5] Rigid body
    //[4.5.1] Translations
    Bp += jac_n * outer(bf,F);
    Bg(range(1,3)) += jac_n * (x-x_n);

    //[4.5.2] Rotations
    Bp             += jac_n * outer(bf, antisym3D * x_n) * L;
    Bg(range(4,6)) += jac_n * ((x-x_n) * antisym3D * x_n) ;

    //------------------------------------------------------------------
    // [5] Matrix

    tensor<double,6> dd_metric(eNN,numDOFs,eNN,numDOFs,pDim,pDim);
    SurfLagrParam::dd_Metric(dd_metric,Dbf);

    tensor<double,6> dd_metric_CC  = product(product(dd_metric,imetric,{{4,0}}),imetric,{{4,0}});

    tensor<double,6> dd_imetric = -1.0 * dd_metric_CC - product(product(d_metric,d_imetric,{{2,2}}).transpose({0,1,3,4,5,2}),imetric,{{5,0}}) - product(product(d_metric,imetric,{{2,0}}),d_imetric,{{2,2}}).transpose({0,1,3,4,2,5});

    tensor<double,4> dd_jac(eNN,numDOFs,eNN,numDOFs);
    SurfLagrParam::dd_Jac(dd_jac,Dbf,xu,xv,normal,d_normal);

    tensor<double,5> dd_normal(eNN,numDOFs,eNN,numDOFs,nDim);
    SurfLagrParam::dd_Normal (dd_normal, Dbf, jac, d_jac, dd_jac, normal, d_normal);

    tensor<double,6> dd_curva(eNN,numDOFs,eNN,numDOFs,pDim,pDim);
    SurfLagrParam::dd_Curva(dd_curva, DDbf, xuu, xuv, xvv, d_normal, dd_normal);

    tensor<double,4> dd_meancurva = product(imetric,dd_curva,{{0,4},{1,5}}) + product(d_imetric,d_curva,{{2,2},{3,3}})+ product(d_curva,d_imetric,{{2,2},{3,3}}) + product(curva,dd_imetric,{{0,4},{1,5}});

    //[5.1] Dissipation
    App += 0.5 * jac_n * mu * (product(d_metric_CnCn,d_metric,{{2,2},{3,3}}) + product(rodt_CnCn,dd_metric,{{0,4},{1,5}}));

    //[5.2] Helfrich energy
    App += 0.5 * kappa * (dd_jac * meancurva * meancurva + (2.0 * jac * meancurva) * dd_meancurva + (2.0 * meancurva) * outer(d_jac,d_meancurva) +  (2.0 * meancurva) * outer(d_meancurva,d_jac) + (2.0 * jac) * outer(d_meancurva,d_meancurva));

    //[5.3] Tension
    App += tension * dd_jac;
    Apt += outer(d_jac,t_bf) * deltat;

    //[5.4] Volume constraint
    App += pressure/3.0 * (dd_jac * xnormal + outer(d_jac,d_normal*x) + outer(d_jac,outer(bf,normal)) + outer(d_normal*x,d_jac) + outer(outer(bf,normal),d_jac) + jac * dd_normal * x + jac * outer(d_normal,bf).transpose({0,1,3,2}) + jac * outer(bf,d_normal.transpose({2,0,1})));
    Apg(all,all,0) += 1.0/3.0 * (d_jac * xnormal + jac * d_normal * x + jac * outer(bf,normal));

    //[5.5] Rigid body
    //[5.5.1] Translations
    Apg(all,0,1) += jac_n * bf;
    Apg(all,1,2) += jac_n * bf;
    Apg(all,2,3) += jac_n * bf;

    //[5.5.1] Rotations
    Apg(all,all,range(4,6)) += jac_n * outer(bf, antisym3D * x_n);

    Atp = Apt.transpose({2,0,1});
    Agp = Apg.transpose({2,0,1});
}

int main(int argc, char *argv[])
{

    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//
    #ifdef EXTRAE_PROFILING
        Extrae_shutdown();
    #endif

    //Initialize MPI
    int myRank{};
    MPI_Init(nullptr, nullptr);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    //Command-line parameters
    Teuchos::CommandLineProcessor parser;
    parser.setDocString("Get options from the command-line and print this help message automatically.\n");
    int nElem = 500;
    parser.setOption("nElem", &nElem, "nElem.");
    int maxNSteps = 500;
    parser.setOption("maxNSteps", &maxNSteps, "maxNSteps.");
    Teuchos::CommandLineProcessor::EParseCommandLineReturn
        parseReturn= parser.parse(argc, argv);
    if (parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED)
        return 0;
    if (parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL)
        return 1;

    // Parameters of the model
    double kappa  = 1.E0;
    double mu     = 1.E1;
    double deltat = 1.E1;

    //Put parameters in UserStructure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(3);
    userStr->dparam[0] = kappa;
    userStr->dparam[1] = mu;
    userStr->dparam[2] = deltat;

    // Time related parameters
    double maxTime = 1.E15;
    double maxDelt = 1.E4;
    double stepFactor = 0.9;

    //Print parameters
    int nSave = 1;
    bool printVtk = false;
    string pos_outName = "pos.";
    string ten_outName = "ten.";


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Mesh generator
    RCP<UnstructVtkMeshGenerator> unstructMesh = rcp(new UnstructVtkMeshGenerator);
    try
    {
        if (nElem < 500)
            throw runtime_error("The number of elements cannot be smaller than 500.");
        unstructMesh->setBasisFuncType(BasisFuncType::SubdivSurfs);
        unstructMesh->setElemType(ElemType::Triang);
        unstructMesh->genSphere([nElem](double x[3]){(void) x; return 20.0/double(nElem);});
    }
    catch (runtime_error& err)
    {
        cout << myRank << ": MeshGenerator could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

    cout << unstructMesh->_nElem << endl;

    // Distribute meshes
    RCP<DistributedMesh> tensDisMesh = rcp(new DistributedMesh);
    tensDisMesh->setMesh(unstructMesh);
    tensDisMesh->setBalanceMesh(true);
    tensDisMesh->Update();

    RCP<DistributedMesh> posDisMesh = rcp(new DistributedMesh);
    posDisMesh->setHRefinement(1);
    posDisMesh->setMeshRelation(MeshRelation::hRefin, tensDisMesh);
    posDisMesh->setBalanceMesh(true);
    posDisMesh->Update();

    RCP<DistributedMesh> gloDisMesh = rcp(new DistributedMesh);
    gloDisMesh->setMeshRelation(MeshRelation::GlobConstr, posDisMesh);
    gloDisMesh->setBalanceMesh(false);
    gloDisMesh->Update();

    //Correct mesh
    CorrectCoordNodalValues(posDisMesh, 3);


    // **************************************************************//
    // *****               DOFHANDLER CREATION                  *****//  //FIXME: Change name in this section
    // **************************************************************//
    RCP<DOFsHandler> posDHand = rcp(new DOFsHandler(posDisMesh));
    posDHand->setNameTag("posDHand");
    posDHand->setNumDOFs(3);
    posDHand->Update();

    RCP<DOFsHandler> tenDHand = rcp(new DOFsHandler(tensDisMesh));
    tenDHand->setNameTag("tenDHand");
    tenDHand->setNumDOFs(1);
    tenDHand->Update();

    RCP<DOFsHandler> gloDHand = rcp(new DOFsHandler(gloDisMesh));
    gloDHand->setNameTag("gloDHand");
    gloDHand->setNumDOFs(7);
    gloDHand->Update();

    //Initial conditions
    posDHand->nodeDOFs->setValue(posDisMesh->_nodeData);
    posDHand->nodeDOFs0->setValue(posDHand->nodeDOFs);
    posDHand->UpdateGhosts();
    tenDHand->nodeDOFs->setValue(0.0);
    gloDHand->nodeDOFs->setValue(0.0);

    //Print initial conditions
    if (printVtk)
    {
        posDHand->printFileLegacyVtk(pos_outName + to_string(0), false);
        tenDHand->printFileLegacyVtk(ten_outName + to_string(0), false);
    }
    posDHand->printFile(pos_outName + to_string(0), OutputMode::Text, true, 0.0);
    tenDHand->printFile(ten_outName + to_string(0), OutputMode::Text, true, 0.0);


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setConsistencyCheckDelta(1.E-4);
    hiperProbl->setConsistencyCheckTolerance(1.E-4);
    hiperProbl->setDOFsHandlers({posDHand, tenDHand, gloDHand});
    hiperProbl->setIntegration("Integ", {"posDHand", "tenDHand", "gloDHand"});
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->setGlobalIntegrals({"Rayleighian", "Helfrich", "Dissipation", "Trd"});
    hiperProbl->Update();


    /// **************************************************************//
    /// *****                SOLVER CREATION                     *****//
    /// **************************************************************//
    RCP<Amesos2DirectLinearSolver> linSolver = rcp(new Amesos2DirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
    linSolver->setNumericFactorization(true);
    linSolver->setSymbolicFactorization(true);
    linSolver->Update();

    RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp(new NewtonRaphsonNonlinearSolver());
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(5);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->Update();


    /// **************************************************************//
    /// *****                     TIME LOOP                      *****//
    /// **************************************************************//

    #ifdef EXTRAE_PROFILING
        Extrae_restart();
    #endif

    //Loop over time steps
    int timeStep{};
    double time{};
    while ((timeStep < maxNSteps) && (time < maxTime))
    {
        if (gloDHand->myRank() == 0)
            cout << endl << " TS: " << to_string(timeStep) << " Time " << time <<  " Delta " << deltat << endl;

        //Prepare for solver
        posDHand->nodeDOFs0->setValue(posDHand->nodeDOFs);
        tenDHand->nodeDOFs0->setValue(tenDHand->nodeDOFs);
        gloDHand->nodeDOFs0->setValue(gloDHand->nodeDOFs);
        hiperProbl->UpdateGhosts();

        //Solve
        bool converged = nonlinSolver->solve();

        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 100);
        #endif
        //The solutions - velocity and density are stored in VTK files
        if (converged)
        {
            //Update time variables
            timeStep++;
            if (nonlinSolver->numberOfIterations() < 5 and deltat < maxDelt)
                deltat /= stepFactor;
            time += deltat;

            //Print files
            if (timeStep % nSave == 0)
            {
                string solName = pos_outName + to_string(timeStep);
                if (printVtk)
                    posDHand->printFileLegacyVtk(solName, true);
                posDHand->printFile(solName, OutputMode::Text, true, time);
                solName = ten_outName + to_string(timeStep);
                if (printVtk)
                    tenDHand->printFileLegacyVtk(solName, true);
                tenDHand->printFile(solName, OutputMode::Text, true, time);
            }
        }
        else if (linSolver->converged())
        {
            if (gloDHand->myRank() == 0)
                std::cout << "ERROR::EXIT from Newton-Raphson but linear solver converged" << endl;

            //Modify time-step
            deltat *= stepFactor;

            //Restore initial values
            posDHand->nodeDOFs->setValue(posDHand->nodeDOFs0);
            tenDHand->nodeDOFs->setValue(tenDHand->nodeDOFs0);
            gloDHand->nodeDOFs->setValue(gloDHand->nodeDOFs0);
        }
        else
        {
            if (gloDHand->myRank() == 0)
                std::cout << "ERROR::EXIT from Newton-Raphson because linear solver failed to converge " << endl;
            MPI_Abort(gloDHand->comm(),1);
            return 1;
        }
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif

        userStr->dparam[2] = deltat;
    }


    MPI_Finalize();
    return 0;
}
