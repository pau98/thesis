//***********************************************************************************//
// In this application the Direct invariant of flexo is solved in 2D with immersed   //
// boundary method (IBM). Dirichlet boundary conditions are applied for lower        //
// order and higher order variables weakly using the Nitsche's method.               //
// Author: Mohammad Reza Bayat                                                       //
// Email: mohammad.reza.bayat@upc.edu                                                //
//***********************************************************************************//

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
// Headers
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
#include <iostream> // input/output stream objects
#include <chrono>   // timing

#include <Teuchos_RCP.hpp>          // Trilinos header that defines RCP objects
#include <mpi.h>                    // C++ header that defines MPI objects
#include <EpetraExt_RowMatrixOut.h> // Exporting stiffness matrix

#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_ConstitutiveModels_Elasticity.h"
#include "hl_ConstitutiveModels_Piezoelectricity.h"
#include "hl_ConstitutiveModels_Flexoelectricity.h"
#include "hl_MultiPatchMeshGenerator.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_StructMeshGenerator.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using namespace hiperlife;
using Teuchos::rcp;
using Teuchos::RCP;

enum class syntheticSolutionType
{
    polynomial,
    sinusoidal1,
    sinusoidal2
};

std::vector<double> computeL2Error(int);
void NitscheParameters(double *, double, double, double, double);
void material(RCP<UserStructure> &);
void domain(Teuchos::RCP<hiperlife::FillStructure>);
void borderDirichletDirichlet(Teuchos::RCP<hiperlife::FillStructure>);
void borderBorderDirichletDirichlet(Teuchos::RCP<hiperlife::FillStructure>);
void syntheticSolution(double *, double *, double[], syntheticSolutionType, int);
void syntheticVolumeLoad(double *, double &,
                         double,
                         double, double, double,
                         double, double, double,
                         double, double, double,
                         double, double, double,
                         double[], syntheticSolutionType, int);
void norm(std::vector<double> &);

/*************************************************************************************************/

int main()
{
    // Get starting timepoint
    auto start = std::chrono::high_resolution_clock::now();

    MPI_Init(nullptr, nullptr);

    int myRank{};
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    for (int i = 3; i < 4; ++i)
    {
        computeL2Error(std::pow(2, i));
    }

    MPI_Finalize();

    // Get ending timepoint
    auto stop = std::chrono::high_resolution_clock::now();

    // Get duration: Substart timepoints to get duration. To cast it to proper unit
    // use duration cast method
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(stop - start);

    cout << "Time taken by function: "
         << duration.count() << " seconds" << endl;
    return 0;
}

/*************************************************************************************************/

std::vector<double> computeL2Error(int elemPerDir)
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;

    /*---------------------------------------------------------------------
        Mesh parameters
    -----------------------------------------------------------------------*/
    BasisFuncType BFType = BasisFuncType::BSplines;
    ElemType EType = ElemType::Square;
    int BFOrder{3};
    double domainLength = 0.44;
    int numImmElem{elemPerDir * 2};
    // Choose synthetic solution
    // 0: polynomial
    // 1: sinusodial1 (Jordi's thesis)
    // 2: sinusodial2 (David's thesis)
    int synSolType = 0;
    int nGaussPts{};
    int nGaussPtsBorder{};
    if (EType == ElemType::Square)
    {
        nGaussPts = pow(ceil(static_cast<double>(2 * BFOrder + 1) / 2.), 2);
        nGaussPtsBorder = ceil(static_cast<double>(2 * BFOrder + 1) / 2.);
    }
    else if (EType == ElemType::Parallelep)
    {
        nGaussPts = pow(ceil(static_cast<double>(2 * BFOrder + 1) / 2.), 3);
        nGaussPtsBorder = pow(ceil(static_cast<double>(2 * BFOrder + 1) / 2.), 2);
    }
    /*---------------------------------------------------------------------
        Material parameters
    -----------------------------------------------------------------------*/
    // Material properties in SI units
    double Young = 152.e9;
    double nu = 0.33;
    double lMech = 1.0e-9;
    double lElec = 1.0e-9;
    double kappaL = 141.e-9;
    double piezoL = 8.8, piezoT = -4.4, piezoS = 4.4;
    double flexoL = 150.e-6, flexoT = 110.e-6, flexoS = 110.e-6;

    // Material properties for debuging
    // double Young = 152.e9;
    // double nu = 0.33;
    // double lMech = 1.0e-9;
    // double lElec = 1.0e-9;
    // double kappaL = 141.e-9;
    // double piezoL = 0., piezoT = 0., piezoS = 0.;
    // double flexoL = 0., flexoT = 0., flexoS = 0.;

    // Normalization Scales
    double lengthScale{1.e-6};     // length scale for normalization
    double stressScale{1.e+9};     // stress scale for normalization
    double polarizationScale{1.0}; // polarization scale for normalization

    // Nitsche's parameter
    double zeta = 1000;
    double flexoLength = std::max(fabs(flexoL), std::max(fabs(flexoT), fabs(flexoS))) / sqrt(kappaL * Young);
    double hypermechLength = sqrt(lMech * lMech + flexoLength * flexoLength);
    double mechWeight = zeta * Young / stressScale;
    double hypermechWeight = zeta * Young / stressScale * hypermechLength * hypermechLength / lengthScale / lengthScale;
    double electricWeight = zeta * kappaL * stressScale / polarizationScale / polarizationScale;
    double h = 1. / static_cast<double>(elemPerDir);
    double beta[4]{0};
    NitscheParameters(beta, h, mechWeight, hypermechWeight, electricWeight);

    // Normalizing the material properties
    Young /= stressScale;
    lMech /= lengthScale;
    lElec /= lengthScale;
    kappaL /= (polarizationScale * polarizationScale / stressScale);
    piezoL /= polarizationScale;
    piezoT /= polarizationScale;
    piezoS /= polarizationScale;
    flexoL /= (lengthScale * polarizationScale);
    flexoT /= (lengthScale * polarizationScale);
    flexoS /= (lengthScale * polarizationScale);

    // Linear elasticity parameters for 2D plane strain problem
    double CL = Young * (1. - nu) / (1. + nu) / (1. - 2. * nu);
    double CT = Young * nu / (1. + nu) / (1. - 2. * nu);
    double CS = Young / 2. / (1. + nu);

    // New user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);

    userStr->i_aux.resize(1);
    userStr->i_aux[0] = synSolType;

    userStr->dparam.resize(14);
    userStr->dparam[0] = Young;
    userStr->dparam[1] = nu;
    userStr->dparam[2] = lMech;
    userStr->dparam[3] = lElec;
    userStr->dparam[4] = kappaL;
    userStr->dparam[5] = piezoL;
    userStr->dparam[6] = piezoT;
    userStr->dparam[7] = piezoS;
    userStr->dparam[8] = flexoL;
    userStr->dparam[9] = flexoT;
    userStr->dparam[10] = flexoS;
    userStr->dparam[11] = CL;
    userStr->dparam[12] = CT;
    userStr->dparam[13] = CS;

    material(userStr);

    userStr->z_aux.resize(4);
    userStr->z_aux[0] = beta[0];
    userStr->z_aux[1] = beta[1];
    userStr->z_aux[2] = beta[2];
    userStr->z_aux[3] = beta[3];

    /*---------------------------------------------------------------------
        Mesh creation and distribution
    -----------------------------------------------------------------------*/
    // Dummy mesh to represent the knot vector space
    RCP<StructMeshGenerator> dummyMesh = rcp(new StructMeshGenerator);
    dummyMesh->setMesh(EType, BFType, 1);
    if (EType == ElemType::Square)
        dummyMesh->genSquare(elemPerDir, 1.0);
    else if (EType == ElemType::Parallelep)
        dummyMesh->genCube(elemPerDir);

    RCP<DistributedMesh> disDummyMesh = rcp(new DistributedMesh);
    disDummyMesh->setMesh(dummyMesh);
    disDummyMesh->setBalanceMesh(true);
    disDummyMesh->Update();
    disDummyMesh->printFileLegacyVtk("paramSp");

    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(EType, BFType, BFOrder);
    if (EType == ElemType::Square)
        structMesh->genSquare(elemPerDir, 1.0);
    else if (EType == ElemType::Parallelep)
        structMesh->genCube(elemPerDir);

    // Distributed mesh
    RCP<DistributedMesh> disBackMesh = rcp(new DistributedMesh);
    disBackMesh->setMesh(structMesh);
    disBackMesh->setBalanceMesh(true);
    disBackMesh->Update();
    disBackMesh->printFileLegacyVtk("backMesh");

    //--------------------------- Immersed mesh --------------------------//
    RCP<StructMeshGenerator> immersedMesh2D = rcp(new StructMeshGenerator);
    RCP<MultiPatchMeshGenerator> immersedMesh3D = rcp(new MultiPatchMeshGenerator);
    if (EType == ElemType::Square)
    {
        immersedMesh2D->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
        immersedMesh2D->genSquareLine(numImmElem, domainLength);
        immersedMesh2D->translate((1. - domainLength) / 2., (1. - domainLength) / 2., 0.0);

        // RCP<StructMeshGenerator> immersedMesh2 = rcp(new StructMeshGenerator);
        // immersedMesh2->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
        // immersedMesh2->genCircle(50, 0.2);
        // immersedMesh2->translate(0.5, 0.5, 0.0);

        // RCP<MultiPatchMeshGenerator> mpatch = rcp(new MultiPatchMeshGenerator);
        // mpatch->setMeshes({immersedMesh, immersedMesh2}, MultiPatchConnectivity::LinearConstraints, 0.000001);
        // mpatch->Update();

        // immersedMesh->genCircle(4, 0.5/sqrt(2));
        // immersedMesh->rotate2D(M_PI / 180 * 45);
        // immersedMesh->translate(0.5, 0.5, 0.0);

        // immersedMesh->genPolygonalCurve("../../meshes/fish.csv", true);
        // immersedMesh->scale(0.4);
        // immersedMesh->translate(0.5, 0.51, 0.0);

        // immersedMesh->genPolygonalCurve("../../meshes/violin.csv", true);
        // immersedMesh->scale(0.91);
        // immersedMesh->translate(0.5, 0.5, 0.0);
    }
    else if (EType == ElemType::Parallelep)
    {
        RCP<StructMeshGenerator> faceZMin = rcp(new StructMeshGenerator);
        faceZMin->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        faceZMin->genSquare(numImmElem, domainLength);
        faceZMin->translate((1. - domainLength) / 2., (1. - domainLength) / 2., (1. + domainLength) / 2.);

        RCP<StructMeshGenerator> faceZMax = rcp(new StructMeshGenerator);
        faceZMax->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        faceZMax->genSquare(numImmElem, domainLength);
        faceZMax->rotateX(M_PI, {domainLength / 2., domainLength / 2., 0.});
        faceZMax->translate((1. - domainLength) / 2., (1. + domainLength) / 2., (1. - domainLength) / 2.);

        RCP<StructMeshGenerator> faceYMin = rcp(new StructMeshGenerator);
        faceYMin->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        faceYMin->genSquare(numImmElem, domainLength);
        faceYMin->rotateX(M_PI / 2.);
        faceYMin->translate((1. - domainLength) / 2., (1. - domainLength) / 2., (1. - domainLength) / 2.);

        RCP<StructMeshGenerator> faceYMax = rcp(new StructMeshGenerator);
        faceYMax->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        faceYMax->genSquare(numImmElem, domainLength);
        faceYMax->rotateX(-M_PI / 2., {0., domainLength, 0.});
        faceYMax->translate((1. - domainLength) / 2., (1. + domainLength) / 2., (1. + domainLength) / 2.);

        RCP<StructMeshGenerator> faceXMin = rcp(new StructMeshGenerator);
        faceXMin->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        faceXMin->genSquare(numImmElem, domainLength);
        faceXMin->rotateY(-M_PI / 2.);
        faceXMin->translate((1. - domainLength) / 2., (1. - domainLength) / 2., (1. - domainLength) / 2.);

        RCP<StructMeshGenerator> faceXMax = rcp(new StructMeshGenerator);
        faceXMax->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        faceXMax->genSquare(numImmElem, domainLength);
        faceXMax->rotateY(M_PI / 2.);
        faceXMax->translate((1. + domainLength) / 2., (1. - domainLength) / 2., (1. + domainLength) / 2.);

        immersedMesh3D->setMeshes({faceXMin, faceXMax, faceYMin, faceYMax, faceZMin, faceZMax},
                                  MultiPatchConnectivity::LinearConstraints, 1e-9);
        immersedMesh3D->Update();
    }

    // Distributed mesh
    RCP<DistributedMesh> disImmMesh = rcp(new DistributedMesh);
    if (EType == ElemType::Square)
    {
        disImmMesh->setMesh(immersedMesh2D);
        disImmMesh->setImmersedInteriorPoints({{0.5, 0.5, 0.}});
    }
    else if (EType == ElemType::Parallelep)
    {
        disImmMesh->setMesh(immersedMesh3D);
        disImmMesh->setImmersedInteriorPoints({{0.5, 0.5, 0.5}});
    }
    disImmMesh->setMeshRelation(MeshRelation::Immersed, disBackMesh);
    disImmMesh->setBalanceMesh(true);
    disImmMesh->Update();
    disImmMesh->printFileLegacyVtk("meshImm");

    /// **************************************************************//
    /// *****               DOFsHANDLER CREATION                 *****//
    /// **************************************************************//
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disBackMesh));
    dofHand->setNameTag("dofHand");
    if (EType == ElemType::Square)
        dofHand->setDOFs({"u", "v", "phi"});
    else if (EType == ElemType::Parallelep)
        dofHand->setDOFs({"u", "v", "w", "phi"});
    dofHand->Update();

    dofHand->setConstraint(0, 0.0);
    for (int e = 0; e < dofHand->mesh->loc_nElem(); e++)
    {
        if (dofHand->mesh->_elemFlags->getValue(1, e, IndexType::Local) != 0)
        {
            std::vector<int> nbors = dofHand->mesh->_connec->getNborList(e, IndexType::Local);
            for (auto n : nbors)
            {
                if (dofHand->mesh->isNodeInPart(n))
                {
                    dofHand->removeConstraint(0, n, IndexType::Global);
                }
            }
        }
    }

    dofHand->UpdateGhosts();
    dofHand->printFileLegacyVtk("dofHand", true);

    /*---------------------------------------------------------------------
        HiPerProblem
    -----------------------------------------------------------------------*/
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});

    // Set integral in the bulk
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureCutCellNonConforming("Integ", nGaussPts, nGaussPts, 3);
    hiperProbl->setElementFillings("Integ", domain);

    // Set integral in the border
    hiperProbl->setIntegration("BorderInteg", {"dofHand"});
    hiperProbl->setCubatureBorderImmersed("BorderInteg", nGaussPtsBorder);
    hiperProbl->setElementFillings("BorderInteg", borderDirichletDirichlet);

    // // Set integral at boundary intersections
    // hiperProbl->setIntegration("Corners", {"dofHand"});
    // if (EType == ElemType::Square)
    // {
    //     hiperProbl->setCubatureBorderIntersection("Corners", 1, {BorderIntersections::XmaxYmax, BorderIntersections::XmaxYmin, BorderIntersections::XminYmax, BorderIntersections::XminYmin});
    //     hiperProbl->setElementFillings("Corners", nullptr, nullptr, borderBorderDirichletDirichlet);
    // }

    // L2 Errors as global integrals
    if (EType == ElemType::Square)
        hiperProbl->setGlobalIntegrals({"L2Err_Ux", "L2Err_Uy", "L2Err_Phi", "ImmArea", "ImmLength"});
    else if (EType == ElemType::Parallelep)
        hiperProbl->setGlobalIntegrals({"L2Err_Ux", "L2Err_Uy", "L2Err_Uz", "L2Err_Phi"});

    hiperProbl->Update();

    // Write left-hand-side matrix to file
    // hiperProbl->FillLinearSystem();
    // ofstream fout_a;
    // fout_a.precision(15);
    // fout_a << scientific << *hiperProbl->A << endl;
    // EpetraExt::RowMatrixToMatrixMarketFile("A2.mm", *hiperProbl->A, "LHS", "Left hand side matrix");
    // fout_a.close();

    /*---------------------------------------------------------------------
        Set solver
    -----------------------------------------------------------------------*/
    /// Iterative solver
    // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setDefaultParameters();
    // solver->setTolerance(1.E-12);
    // solver->setMaxNumIterations(500);
    // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // solver->setPrecond(AztecOOIterativeLinearSolver::Precond::DomainDecomp);
    // solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver->Update();

    /// Direct solver
    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setDefaultParameters();
    solver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General); // General or Symmetric
    solver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->Update();

    /*---------------------------------------------------------------------
        Create a file for writing integration points
    -----------------------------------------------------------------------*/
    ofstream myfile;
    myfile.open("cubature_" + to_string(hiperProbl->myRank()) + ".csv", std::ofstream::out | std::ofstream::trunc);
    myfile.close();

    /*---------------------------------------------------------------------
        Solve HiPerProblem
    -----------------------------------------------------------------------*/
    solver->solve();                      // Solve problem
    hiperProbl->UpdateSolution();         // Update node values
    dofHand->printFileLegacyVtk("Flexo"); // Print as VTK
    solver->Update();

    hiperProbl->FillLinearSystem();

    std::vector<double> errors(4);

    if (hiperProbl->myRank() == 0 && EType == ElemType::Square)
    {
        std::cout << std::setprecision(6);
        std::cout << "Area of immersed geometry: " << hiperProbl->globalIntegral("ImmArea") << std::endl;
        std::cout << "Length of immersed geometry: " << hiperProbl->globalIntegral("ImmLength") << std::endl;

        std::cout << "Nitsche's parameters: \n"
                  << "beta_u \t " << beta[0]
                  << "\nbeta_v \t " << beta[1]
                  << "\nbeta_p \t " << beta[2]
                  << "\nbeta_c \t " << beta[3] << std::endl;


        errors[0] = sqrt(hiperProbl->globalIntegral("L2Err_Ux"));
        errors[1] = sqrt(hiperProbl->globalIntegral("L2Err_Uy"));
        errors[2] = sqrt(hiperProbl->globalIntegral("L2Err_Phi"));
        std::cout << "-> L2 Errors: " << std::endl;
        std::cout << "\t-> Ux  : " << errors[0] << std::endl;
        std::cout << "\t-> Uy  : " << errors[1] << std::endl;
        std::cout << "\t-> Phi : " << errors[2] << std::endl;
    }
    else if (hiperProbl->myRank() == 0 && EType == ElemType::Parallelep)
    {
        errors[0] = sqrt(hiperProbl->globalIntegral("L2Err_Ux"));
        errors[1] = sqrt(hiperProbl->globalIntegral("L2Err_Uy"));
        errors[2] = sqrt(hiperProbl->globalIntegral("L2Err_Uz"));
        errors[3] = sqrt(hiperProbl->globalIntegral("L2Err_Phi"));
        std::cout << "-> L2 Errors: " << std::endl;
        std::cout << "\t-> Ux  : " << errors[0] << std::endl;
        std::cout << "\t-> Uy  : " << errors[1] << std::endl;
        std::cout << "\t-> Uz  : " << errors[2] << std::endl;
        std::cout << "\t-> Phi : " << errors[3] << std::endl;
    }

    return errors;
}

/*************************************************************************************************/

void NitscheParameters(double *beta, double h, double mechWeight, double hypermechWeight, double electricWeight)
{
    beta[0] = mechWeight / h;          // beta u
    beta[1] = hypermechWeight / h;     // beta v
    beta[2] = electricWeight / h;      // beta phi
    beta[3] = hypermechWeight / h / h; // beta C u
}

/*************************************************************************************************/

void material(RCP<UserStructure> &usrStr)
{
    // Material properties
    double lMech = usrStr->dparam[2];
    double lElec = usrStr->dparam[3];
    double kappaL = usrStr->dparam[4];
    double piezoL = usrStr->dparam[5];
    double piezoT = usrStr->dparam[6];
    double piezoS = usrStr->dparam[7];
    double flexoL = usrStr->dparam[8];
    double flexoT = usrStr->dparam[9];
    double flexoS = usrStr->dparam[10];

    // Linear elasticity parameters for 2D plane strain problem
    double CL = usrStr->dparam[11];
    double CT = usrStr->dparam[12];
    double CS = usrStr->dparam[13];

    // Linear elasticity tensor
    std::vector<double> C;
    ConstitutiveModels::LinearElasticity::elasticityTensor(C, CL, CT, CS, 2);

    // Linear gradient elasticity tensor
    std::vector<double> H;
    H.resize(2 * 2 * 2 * 2 * 2 * 2);
    ConstitutiveModels::LinearElasticity::gradElasticityTensor(H, CL, CT, CS, lMech, 2);

    // Linear isotropic dielectric tensor
    std::vector<double> K;
    ConstitutiveModels::Piezoelectricity::dielectricTensor(K, kappaL, 2);

    // Linear piezoelectric tensor
    std::vector<double> E;
    ConstitutiveModels::Piezoelectricity::piezoelectricTensor(E, piezoL, piezoT, piezoS, 2);

    // Linear Flexoelectric tensor
    std::vector<double> Mu;
    ConstitutiveModels::Flexoelectricity::flexoelectricityTensor(Mu, flexoL, flexoT, flexoS, 2);

    usrStr->a_aux = C;
    usrStr->b_aux = H;
    usrStr->c_aux = K;
    usrStr->u_aux = E;
    usrStr->v_aux = Mu;
}

/*************************************************************************************************/

void domain(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    /*----------------------------------------------------------------------------
            Initialize variables
    ------------------------------------------------------------------------------*/
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;         // Number of neighbor nodes (Number of nodes)
    int nDim = subFill.nDim;       // Number of spatial dimensions (2->x,y / 3->x,y,z)
    int pDim = subFill.pDim;       // Number of parametric dimension
    int numDOFs = subFill.numDOFs; // Number of degrees of freedom per node

    tensor<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);  // Coordinates for each node
    tensor<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);   // DOF values at the nodes
    tensor<double, 1> bf(subFill.nborBasisFunctionsDerivatives(0), eNN); // Basis functions

    // Global derivatives (wrt x and y ) of the basis functions
    tensor<double, 2> GlobDBF(eNN, pDim);       // Gradient
    tensor<double, 3> GlobHBF(eNN, pDim, pDim); // Hessian
    tensor<double, 1> GlobLBF(eNN);             // Laplacian
    double jac{};
    GlobalBasisFunctions::hessians(GlobDBF, jac, GlobHBF, GlobLBF, subFill);

    // Global coordinates (x,y,z)
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}});

    /*----------------------------------------------------------------------------
        Material Tensors
    ------------------------------------------------------------------------------*/
    tensor<double, 4> C(fillStr->userStr->a_aux.data(), pDim, pDim, pDim, pDim);
    tensor<double, 6> H(fillStr->userStr->b_aux.data(), pDim, pDim, pDim, pDim, pDim, pDim);
    tensor<double, 2> K(fillStr->userStr->c_aux.data(), pDim, pDim);
    tensor<double, 3> E(fillStr->userStr->u_aux.data(), pDim, pDim, pDim);
    tensor<double, 4> Mu(fillStr->userStr->v_aux.data(), pDim, pDim, pDim, pDim);

    // cout << "C\n"
    //          << C
    //          << "\nH\n"
    //          << H
    //          << "\nK\n"
    //          << K
    //          << "\nE\n"
    //          << E
    //          << "\nE\n"
    //          << "\nMu"
    //          << Mu
    //          << endl;

    /*----------------------------------------------------------------------------
        Differential operators
    ------------------------------------------------------------------------------*/
    tensor<double, 4> Strain(pDim, pDim, pDim, eNN);
    tensor<double, 5> gradStrain(pDim, pDim, pDim, pDim, eNN);
    tensor<double, 2> EField(pDim, eNN);

    ConstitutiveModels::LinearElasticity::strain(Strain, GlobDBF, pDim);
    ConstitutiveModels::LinearElasticity::gradStrain(gradStrain, GlobHBF, pDim);
    ConstitutiveModels::Piezoelectricity::electricFieldTensor(EField, GlobDBF, pDim);

    /*----------------------------------------------------------------------------
        Synthetic Solution
    ------------------------------------------------------------------------------*/
    double l_mech = fillStr->userStr->dparam[2];
    double l_elec = fillStr->userStr->dparam[3];
    double kappaL = fillStr->userStr->dparam[4];
    double e_L = fillStr->userStr->dparam[5];
    double e_T = fillStr->userStr->dparam[6];
    double e_S = fillStr->userStr->dparam[7];
    double mu_L = fillStr->userStr->dparam[8];
    double mu_T = fillStr->userStr->dparam[9];
    double mu_S = fillStr->userStr->dparam[10];
    double CL = fillStr->userStr->dparam[11];
    double CT = fillStr->userStr->dparam[12];
    double CS = fillStr->userStr->dparam[13];

    double syntheticSol[3]{}; // synthetic solution
    double B[2]{};            // volumetric loads in x and y directions
    double Q{};               // volumetric electric charge

    syntheticSolutionType type;
    if (fillStr->userStr->i_aux[0] == 0)
        type = syntheticSolutionType::polynomial;
    else if (fillStr->userStr->i_aux[0] == 1)
        type = syntheticSolutionType::sinusoidal1;
    syntheticVolumeLoad(B, Q, l_mech, kappaL, l_mech, l_elec, e_L, e_T, e_S, mu_L, mu_T, mu_S, CL, CT, CS, coords.data(), type, pDim);

    /*----------------------------------------------------------------------------
            Integration in Domain
    ------------------------------------------------------------------------------*/
    // Allocate space:
    tensor<double, 2> Bk(fillStr->Bk(0).data(), eNN, numDOFs);
    tensor<double, 4> Ak(fillStr->Ak(0, 0).data(), eNN, numDOFs, eNN, numDOFs);

    // 1. Cauchy Stress : delta_Strain(u)_ijQR · C_ijkl · Strain(u)_klST
    tensor<double, 4> CauchyStress = product(Strain, product(C, Strain, {{2, 0}, {3, 1}}), {{0, 0}, {1, 1}});
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            Ak(all, i, all, j) += CauchyStress(i, all, j, all) * jac;

    // 2. Hyper Stress : delta_gradStrain(u)_ijkQR · H_ijklmn · gradStrain(u)_lmnST
    tensor<double, 4> HyperStress = product(gradStrain, product(H, gradStrain, {{3, 0}, {4, 1}, {5, 2}}), {{0, 0}, {1, 1}, {2, 2}});
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            Ak(all, i, all, j) += HyperStress(i, all, j, all) * jac;

    // 3. Electrostatic Energy Density: - EField_lS K_lm EField_mQ
    tensor<double, 2> Electrostatic = -product(EField, product(K, EField, {{1, 0}}), {{0, 0}});
    Ak(all, numDOFs - 1, all, numDOFs - 1) += Electrostatic * jac;

    // 5c. Piezoelectric Effect: - EField_lQ E_lij SymmGrad(u)_ijRS
    tensor<double, 3> Piezoelectric = -product(EField, product(E, Strain, {{1, 0}, {2, 1}}), {{0, 0}});
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, numDOFs - 1, all, i) += Piezoelectric(all, i, all) * jac;
        Ak(all, i, all, numDOFs - 1) += Piezoelectric(all, i, all).transpose({1, 0}) * jac;
    }

    // 6c. Flexoelectric Effect: - EField_lQ Mu_lijk gradStrain(u)_ijkRS
    tensor<double, 3> Flexoelectric = -product(EField, product(Mu, gradStrain, {{1, 0}, {2, 1}, {3, 2}}), {{0, 0}});
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, numDOFs - 1, all, i) += Flexoelectric(all, i, all) * jac;
        Ak(all, i, all, numDOFs - 1) += Flexoelectric(all, i, all).transpose({1, 0}) * jac;
    }

    // Loads and charge
    for (int i = 0; i < eNN; ++i)
    {
        Bk(i, 0) += B[0] * bf(i) * jac; // Load in x
        Bk(i, 1) += B[1] * bf(i) * jac; // Load in y
        Bk(i, 2) -= Q * bf(i) * jac;    // Charge
    }

    /*----------------------------------------------------------------------------
        Calculate Error
    ------------------------------------------------------------------------------*/
    double err_Ux = 0.0;
    double err_Uy = 0.0;
    double err_Phi = 0.0;

    tensor<double, 1> sol = product(nborDOFs, bf, {{0, 0}}); // numerical solution

    err_Ux += jac * (sol(0) - syntheticSol[0]) * (sol(0) - syntheticSol[0]);
    err_Uy += jac * (sol(1) - syntheticSol[1]) * (sol(1) - syntheticSol[1]);
    err_Phi += jac * (sol(2) - syntheticSol[2]) * (sol(2) - syntheticSol[2]);
    fillStr->addToGlobalIntegral("L2Err_Ux", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi", err_Phi);
    fillStr->addToGlobalIntegral("ImmArea", jac);
    // cout << Ak;
    /*----------------------------------------------------------------------------
        Writing integration points
    ------------------------------------------------------------------------------*/
    ofstream myfile;
    myfile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    if (pDim == 2)
    {
        myfile << std::setprecision(16)
               << coords(0) << " "
               << coords(1) << " "
               << 0 << " "
               << 0 << " "
               << 0 << " " << 0 << " " << 0 << endl;
        myfile.close();
    }
}

/*************************************************************************************************/

void borderDirichletDirichlet(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    /*----------------------------------------------------------------------------
            Initialize variables
    ------------------------------------------------------------------------------*/
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;         // Number of neighbor nodess
    int nDim = subFill.nDim;       // Number of spatial dimensions
    int pDim = subFill.pDim;       // Number of parametric dimension
    int numDOFs = subFill.numDOFs; // Number of degrees of freedom per node

    tensor<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);                 // Coordinates for each node
    tensor<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);                  // DOFS -> ux = (:,0), uy = (:,1), phi = (:,2)
    tensor<double, 1> bf(subFill.nborBasisFunctionsDerivatives(0), eNN);                // Basis functions
    tensor<double, 2> Dbf_l(subFill.nborBasisFunctionsDerivatives(1), eNN, pDim);       // Local derivatives of the bf
    tensor<double, 3> Hbf_l(subFill.nborBasisFunctionsDerivatives(2), eNN, pDim, pDim); // Local Hessian of the bf

    // Global derivatives (wrt x and y ) of the basis functions
    tensor<double, 2> GlobDBF(eNN, pDim);             // Gradient
    tensor<double, 3> GlobHBF(eNN, pDim, pDim);       // Hessian
    tensor<double, 4> GlobTBF(eNN, pDim, pDim, pDim); // Third Derivatives
    tensor<double, 1> Lbf_g(eNN);                     // Laplacian
    double jac{};
    GlobalBasisFunctions::thirdGlobalDerivs(GlobDBF, jac, GlobHBF, Lbf_g, GlobTBF, subFill);

    // Global coordinates (x,y,z)
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}});

    /*----------------------------------------------------------------------------
        Normal vectors
    ------------------------------------------------------------------------------*/
    double normal[3]{};
    tensor<double, 1> NDbf_g(eNN); // Normal derivative
    double Nu[3], Nv[3];           // Derivatives of the normal vector (using Weingarten Eqs)
    if (pDim == 2)
    {
        double Ip[2 * 2], xu[3], xv[3];            // First Fundamental form and metric mappings
        double IIp[2 * 2], xuu[3], xvv[3], xuv[3]; // Second Fundamental form and metric mappings
        SurfLagrParam::Curvatures(IIp, Ip, normal, xu, xv, xuu, xvv, xuv, eNN, nborCoords.data(), Dbf_l.data(), Hbf_l.data());

        // Get tangent to immersed mesh at integration point
        auto immMesh = subFill.dhandDHand->mesh->_childMesh;
        std::vector<double> t(3);
        for (int n = 0; n < nDim; n++)
            t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim * subFill.kPt + n];
        jac = Math::Norm3D(t.data());

        // Normal vector
        normal[0] = -t[1] / jac;
        normal[1] = t[0] / jac;
        normal[2] = 0.0;

        NDbf_g(all) = normal[0] * GlobDBF(all, 0) + normal[1] * GlobDBF(all, 1);

        double detIp = Math::DetMat2x2(Ip);
        Math::AXPY(Nu, nDim, (IIp[1] * Ip[1] - IIp[0] * Ip[3]) / detIp, xu);
        Math::AXPY(Nu, nDim, (IIp[0] * Ip[1] - IIp[1] * Ip[0]) / detIp, xv);
        Math::AXPY(Nv, nDim, (IIp[3] * Ip[1] - IIp[1] * Ip[3]) / detIp, xu);
        Math::AXPY(Nv, nDim, (IIp[1] * Ip[1] - IIp[3] * Ip[0]) / detIp, xv);
    }
    else if (pDim == 3)
    {
        throw runtime_error("Integration on boundary: Calculation of normal vectors and jacobi not implemented.\n");
    }

    tensor<double, 2> PMat(pDim, pDim);
    PMat(all, all) = 0.0; // PMat_ij = delta_ij - n_i n_j
    for (int i = 0; i < pDim; ++i)
    {
        PMat(i, i) += 1.0;
        for (int j = 0; j < pDim; ++j)
            PMat(i, j) -= normal[i] * normal[j];
    }

    tensor<double, 2> SMat(pDim, pDim);
    SMat(all, all) = 0.0; // SMat_ij = -N_i,l * P_lj
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            SMat(i, j) = -Nu[i] * PMat(0, j) - Nv[i] * PMat(1, j);

    double STrace = 0.0;
    for (int i = 0; i < pDim; ++i)
        STrace += 0.5 * SMat(i, i); // Mean Curvature

    tensor<double, 2> NMat(pDim, pDim);
    NMat(all, all) = 0.0; // NMat_ij = S_ij - 2.0 * H * n_i * n_j
    for (int i = 0; i < pDim; ++i)
        for (int j = 0; j < pDim; ++j)
            NMat(i, j) = SMat(i, j) - 2.0 * STrace * normal[i] * normal[j];

    /*----------------------------------------------------------------------------
            Material tensors
    ------------------------------------------------------------------------------*/
    tensor<double, 4> C(fillStr->userStr->a_aux.data(), pDim, pDim, pDim, pDim);
    tensor<double, 6> H(fillStr->userStr->b_aux.data(), pDim, pDim, pDim, pDim, pDim, pDim);
    tensor<double, 2> K(fillStr->userStr->c_aux.data(), pDim, pDim);
    tensor<double, 3> E(fillStr->userStr->u_aux.data(), pDim, pDim, pDim);
    tensor<double, 4> Mu(fillStr->userStr->v_aux.data(), pDim, pDim, pDim, pDim);

    /*----------------------------------------------------------------------------
        Differential operators
    ------------------------------------------------------------------------------*/
    tensor<double, 4> Strain(pDim, pDim, pDim, eNN);
    tensor<double, 5> GradStrain(pDim, pDim, pDim, pDim, eNN);
    tensor<double, 6> HessStrain(pDim, pDim, pDim, pDim, pDim, eNN);
    tensor<double, 2> EField(pDim, eNN);
    tensor<double, 3> GradEField(pDim, pDim, eNN);

    ConstitutiveModels::LinearElasticity::strain(Strain, GlobDBF, pDim);
    ConstitutiveModels::LinearElasticity::gradStrain(GradStrain, GlobHBF, pDim);
    ConstitutiveModels::LinearElasticity::hessStrain(HessStrain, GlobTBF, pDim);
    ConstitutiveModels::Piezoelectricity::electricFieldTensor(EField, GlobDBF, pDim);
    ConstitutiveModels::Piezoelectricity::gradElectricField(GradEField, GlobHBF, pDim);

    /*----------------------------------------------------------------------------
        Constitutive relations
    ------------------------------------------------------------------------------*/
    tensor<double, 4> SigHat(pDim, pDim, numDOFs, eNN);
    tensor<double, 5> SigTilde(pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 6> GradSigTilde(pDim, pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 3> DHat(pDim, numDOFs, eNN);
    tensor<double, 4> DTilde(pDim, pDim, numDOFs, eNN);
    tensor<double, 5> GradDTilde(pDim, pDim, pDim, numDOFs, eNN);
    tensor<double, 3> Ti(pDim, numDOFs, eNN);
    tensor<double, 3> ri(pDim, numDOFs, eNN);
    tensor<double, 2> W(numDOFs, eNN);

    ConstitutiveModels::Flexoelectricity::Direct::stress(SigHat, C, Strain, E, EField, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::doubleStress(SigTilde, H, GradStrain, EField, Mu, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::gradDoubleStress(GradSigTilde, H, HessStrain, Mu, GradEField, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::electricDisplacement(DHat, EField, Strain, GradStrain, Mu, K, E, numDOFs, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::traction(Ti, SigHat, SigTilde, GradSigTilde, PMat, NMat, normal, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::doubleTraction(ri, SigTilde, normal, pDim);
    ConstitutiveModels::Flexoelectricity::Direct::surfaceChargeDensity(W, DHat, PMat, NMat, normal, pDim);

    /*----------------------------------------------------------------------------
        Retrive Nitsche's parameters
    ------------------------------------------------------------------------------*/
    double betaU = fillStr->userStr->z_aux[0];
    double betaV = fillStr->userStr->z_aux[1];
    double betaPhi = fillStr->userStr->z_aux[2];

    /*----------------------------------------------------------------------------
       Synthetic solution
    ------------------------------------------------------------------------------*/
    /* u   : sol[0]
       v   : sol[1]
       phi : sol[2] */
    double syntheticSol[3]{};
    /* Derivative of synthetic solution
       u,X   : Dsol[0]     u,Y   : Dsol[1]
       v,X   : Dsol[2]     v,Y   : Dsol[3]
       phi,X : Dsol[4]     phi,Y : Dsol[5] */
    double dSyntheticSol[6]{};

    syntheticSolutionType type;
    if (fillStr->userStr->i_aux[0] == 0)
        type = syntheticSolutionType::polynomial;
    else if (fillStr->userStr->i_aux[0] == 1)
        type = syntheticSolutionType::sinusoidal1;
    syntheticSolution(syntheticSol, dSyntheticSol, coords.data(), type, pDim);
    // Normal Derivative
    double dnU[3];
    dnU[0] = normal[0] * dSyntheticSol[0] + normal[1] * dSyntheticSol[1]; // Normal derivative of u: DU = nx Ux + ny Uy
    dnU[1] = normal[0] * dSyntheticSol[2] + normal[1] * dSyntheticSol[3]; // Normal derivative of v: Dv = nx Vx + ny Vy
    dnU[2] = normal[0] * dSyntheticSol[4] + normal[1] * dSyntheticSol[5]; // Normal derivative of phi: Dphi = nx Vx + ny Vy

    /*----------------------------------------------------------------------------
           Integration on boundaries
    ------------------------------------------------------------------------------*/
    // Allocate space:
    tensor<double, 4> Ak(fillStr->Ak(0, 0).data(), eNN, numDOFs, eNN, numDOFs);
    tensor<double, 2> Bk(fillStr->Bk(0).data(), eNN, numDOFs);

    // Integration on \partial Omega_u
    // int ( u_i betaU du_i - u_i dt_i - uB_i betaU du_i + uB_i dt_i - t_i du_i )
    //       ~~~~~~~~~~~~~~   ~~~~~~~~   ~~~~~~~~~~~~~~~   ~~~~~~~~~   ~~~~~~~~
    //            LHS           LHS            RHS            RHS         LHS
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, i, all, i) += betaU * outer(bf, bf) * jac; // u_i betaU du_i
        Bk(all, i) += syntheticSol[i] * betaU * bf * jac;  // Goes to RHS: - uB_i betaU du_i
        for (int j = 0; j < numDOFs; ++j)
        {
            Ak(all, i, all, j) -= outer(bf, Ti(i, j, all)) * jac; // - u_i dt_i
            Ak(all, j, all, i) -= outer(Ti(i, j, all), bf) * jac; // - t_i du_i
            Bk(all, j) -= syntheticSol[i] * Ti(i, j, all) * jac;  // Goes to RHS: uB_i dt_i
        }
    }

    // Integration on \partial Omega_v
    // int ( Du_i betaV Ddu_i - Du_i dr_i - vB_i betaV Ddu_i + vB_i dr_i - r_i Ddu_i )
    //       ~~~~~~~~~~~~~~~~   ~~~~~~~~~   ~~~~~~~~~~~~~~~~   ~~~~~~~~~   ~~~~~~~~~
    //              LHS            LHS             RHS            RHS         LHS
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, i, all, i) += betaV * outer(NDbf_g, NDbf_g) * jac; // Du_i betaV Ddu_i
        Bk(all, i) += dnU[i] * betaV * NDbf_g * jac;               // Goes to RHS: - vB_i betaV Ddu_i
        for (int j = 0; j < numDOFs; ++j)
        {
            Ak(all, i, all, j) -= outer(NDbf_g, ri(i, j, all)) * jac; // - r_i Ddu_i
            Ak(all, j, all, i) -= outer(ri(i, j, all), NDbf_g) * jac; // - Du_i dr_i
            Bk(all, j) -= dnU[i] * ri(i, j, all) * jac;               // Goes to RHS: vB_i dr_i
        }
    }

    // Integration on \partial Omega_phi
    // int ( -phi betaPhi dphi + phi dw + phiB betaPhi dphi - phiB dw + w dphi )
    //       ~~~~~~~~~~~~~~~~~   ~~~~~~   ~~~~~~~~~~~~~~~~~   ~~~~~~~   ~~~~~~
    //              LHS           LHS            RHS            RHS       LHS
    Ak(all, numDOFs - 1, all, numDOFs - 1) -= outer(bf, betaPhi * bf) * jac; // -phi betaPhi dphi
    Bk(all, numDOFs - 1) -= betaPhi * syntheticSol[2] * bf * jac;            // Goes to RHS: phiB betaPhi dphi
    for (int i = 0; i < numDOFs; ++i)
    {
        Ak(all, numDOFs - 1, all, i) += outer(bf, W(i, all)) * jac; // w dphi
        Ak(all, i, all, numDOFs - 1) += outer(W(i, all), bf) * jac; // phi dw
        Bk(all, i) += syntheticSol[2] * W(i, all) * jac;            // Goes to RHS: -phiB dw
    }

    /*----------------------------------------------------------------------------
        Calculate Error
    ------------------------------------------------------------------------------*/
    double err_Ux = 0.0;
    double err_Uy = 0.0;
    double err_Phi = 0.0;

    // L2 Error calculation
    tensor<double, 1> sol = product(nborDOFs, bf, {{0, 0}});

    err_Ux += jac * (sol(0) - syntheticSol[0]) * (sol(0) - syntheticSol[0]);
    err_Uy += jac * (sol(1) - syntheticSol[1]) * (sol(1) - syntheticSol[1]);
    err_Phi += jac * (sol(2) - syntheticSol[2]) * (sol(2) - syntheticSol[2]);
    fillStr->addToGlobalIntegral("L2Err_Ux", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi", err_Phi);
    fillStr->addToGlobalIntegral("ImmLength", jac);

    /*----------------------------------------------------------------------------
        Writing Integration points
    ------------------------------------------------------------------------------*/
    ofstream myfile;
    myfile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    if (pDim == 2)
    {
        myfile << std::setprecision(16)
               << coords(0) << " " << coords(1) << " " << 0 << " "
               << 1 << " " << normal[0] << " " << normal[1] << " " << 0 << endl;
        myfile.close();
    }
}

/*************************************************************************************************/

void borderBorderDirichletDirichlet(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    /*----------------------------------------------------------------------------
            Initialize variables
    ------------------------------------------------------------------------------*/
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;         // Number of neighbor nodess
    int nDim = subFill.nDim;       // Number of spatial dimensions
    int pDim = subFill.pDim;       // Number of parametric dimension
    int numDOFs = subFill.numDOFs; // Number of degrees of freedom per node

    tensor<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);                 // Coordinates for each node
    tensor<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);                  // DOFS -> ux = (:,0), uy = (:,1), phi = (:,2)
    tensor<double, 1> bf(subFill.nborBasisFunctionsDerivatives(0), eNN);                // Basis functions
    tensor<double, 2> Dbf_l(subFill.nborBasisFunctionsDerivatives(1), eNN, pDim);       // Local derivatives of the bf
    tensor<double, 3> Hbf_l(subFill.nborBasisFunctionsDerivatives(2), eNN, pDim, pDim); // Local Hessian of the bf

    // Global derivatives (wrt x and y ) of the basis functions
    tensor<double, 2> GlobDbf(eNN, pDim);              // Gradient
    tensor<double, 3> GlobD2bf(eNN, pDim, pDim);       // Hessian
    tensor<double, 4> GlobD3bf(eNN, pDim, pDim, pDim); // Third Derivatives
    tensor<double, 1> Lbf_g(eNN);                      // Laplacian
    double jac{};
    GlobalBasisFunctions::thirdGlobalDerivs(GlobDbf, jac, GlobD2bf, Lbf_g, GlobD3bf, subFill);

    // Global coordinates (x,y,z)
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}});

    ///===========       Calculate Tangent and Normal vectors       =========///
    double normal[3];
    double Ip[2 * 2], xu[3], xv[3];            // First Fundamental form and metric mappings
    double IIp[2 * 2], xuu[3], xvv[3], xuv[3]; // Second Fundamental form and metric mappings
    SurfLagrParam::Curvatures(IIp, Ip, normal, xu, xv, xuu, xvv, xuv, eNN, nborCoords.data(), Dbf_l.data(), Hbf_l.data());

    auto tangentRef = subFill.tangentsBoundaryRef(); // Tangent vector in the reference element
    auto normalRef = subFill.normalsBoundaryRef();   // Normal vector in the reference element

    double tangentRefSide1[2] = {tangentRef[0], tangentRef[1]};
    double tangentRefSide2[2] = {tangentRef[2], tangentRef[3]};

    double normalRefSide1[2] = {normalRef[0], normalRef[1]};
    double normalRefSide2[2] = {normalRef[2], normalRef[3]};

    std::vector<double> tangentSide1; // Tangent vector in real coordinates
    std::vector<double> tangentSide2;
    std::vector<double> normalSide1; // Normal vector in real coordinates
    std::vector<double> normalSide2;

    tangentSide1.push_back(xu[0] * tangentRefSide1[0] + xu[1] * tangentRefSide1[1]);
    tangentSide1.push_back(xv[0] * tangentRefSide1[0] + xv[1] * tangentRefSide1[1]);
    norm(tangentSide1);

    tangentSide2.push_back(xu[0] * tangentRefSide2[0] + xu[1] * tangentRefSide2[1]);
    tangentSide2.push_back(xv[0] * tangentRefSide2[0] + xv[1] * tangentRefSide2[1]);
    norm(tangentSide2);

    normalSide1.push_back(xu[0] * normalRefSide1[0] + xu[1] * normalRefSide1[1]);
    normalSide1.push_back(xv[0] * normalRefSide1[0] + xv[1] * normalRefSide1[1]);
    norm(normalSide1);

    normalSide2.push_back(xu[0] * normalRefSide2[0] + xu[1] * normalRefSide2[1]);
    normalSide2.push_back(xv[0] * normalRefSide2[0] + xv[1] * normalRefSide2[1]);
    norm(normalSide2);

    double dl = 1.0; // Length differential

    /*----------------------------------------------------------------------------
        Material tensors
    ------------------------------------------------------------------------------*/
    tensor<double, 6> H(fillStr->userStr->b_aux.data(), pDim, pDim, pDim, pDim, pDim, pDim);
    tensor<double, 4> Mu(fillStr->userStr->v_aux.data(), pDim, pDim, pDim, pDim);

    /*----------------------------------------------------------------------------
        Retrive Nitsche's parameters
    ------------------------------------------------------------------------------*/
    double betaCu = fillStr->userStr->z_aux[3];

    /*----------------------------------------------------------------------------
        Differential operators
    ------------------------------------------------------------------------------*/
    tensor<double, 4> Strain(pDim, pDim, pDim, eNN);
    tensor<double, 5> GradStrain(pDim, pDim, pDim, pDim, eNN);
    tensor<double, 2> EField(pDim, eNN);

    ConstitutiveModels::LinearElasticity::strain(Strain, GlobDbf, pDim);
    ConstitutiveModels::LinearElasticity::gradStrain(GradStrain, GlobD2bf, pDim);
    ConstitutiveModels::Piezoelectricity::electricFieldTensor(EField, GlobDbf, pDim);

    /*----------------------------------------------------------------------------
        Constitutive relations
    ------------------------------------------------------------------------------*/
    tensor<double, 5> SigTilde(pDim, pDim, pDim, numDOFs, eNN);

    ConstitutiveModels::Flexoelectricity::Direct::doubleStress(SigTilde, H, GradStrain, EField, Mu, numDOFs, pDim);

    tensor<double, 3> Ji(pDim, numDOFs, eNN); // Ji_iQR
    tensor<double, 2> P(numDOFs, eNN);        // P_QR
    Ji(all, all, all) = 0.0;
    P(all, all) = 0.0;

    // Filling Ji_iQR = SigTilde_ijkQR tangent_j normal_k
    for (int j{}; j < pDim; ++j)
        for (int k{}; k < pDim; ++k)
            Ji(all, all, all) += SigTilde(all, j, k, all, all) * (tangentSide1[j] * normalSide1[k] + tangentSide2[j] * normalSide2[k]);

    /*----------------------------------------------------------------------------
       Synthetic solution
    ------------------------------------------------------------------------------*/
    /* u   : sol[0]
       v   : sol[1]
       phi : sol[2] */
    double syntheticSol[3]{};
    /* Derivative of synthetic solution
       u,X   : Dsol[0]     u,Y   : Dsol[1]
       v,X   : Dsol[2]     v,Y   : Dsol[3]
       phi,X : Dsol[4]     phi,Y : Dsol[5] */
    double dSyntheticSol[6]{};

    syntheticSolutionType type;
    if (fillStr->userStr->i_aux[0] == 0)
        type = syntheticSolutionType::polynomial;
    else if (fillStr->userStr->i_aux[0] == 1)
        type = syntheticSolutionType::sinusoidal1;
    syntheticSolution(syntheticSol, dSyntheticSol, coords.data(), type, pDim);

    /*----------------------------------------------------------------------------
           Integration on boundaries
    ------------------------------------------------------------------------------*/
    // Allocate space:
    tensor<double, 4> Ak(fillStr->Ak(0, 0).data(), eNN, numDOFs, eNN, numDOFs);
    tensor<double, 2> Bk(fillStr->Bk(0).data(), eNN, numDOFs);

    // Integration on C_u
    // int ( u_i beta_Cu du_i - uB_i beta_Cu du_i - u_i dj_i + uB_i dj_i - j_i du_i )
    //       ~~~~~~~~~~~~~~~~   ~~~~~~~~~~~~~~~~~   ~~~~~~~~   ~~~~~~~~~   ~~~~~~~~
    //             LHS                 RHS            LHS          RHS        LHS
    for (int i = 0; i < pDim; ++i)
    {
        Ak(all, i, all, i) += betaCu * outer(bf, bf) * dl; // u_i beta_Cu du_i
        Bk(all, i) += syntheticSol[i] * betaCu * bf * dl;  // Goes to RHS: - uB_i beta_Cu du_i
        for (int j = 0; j < numDOFs; ++j)
        {
            Ak(all, i, all, j) -= outer(bf, Ji(i, j, all)) * dl; // - u_i dj_i
            Ak(all, j, all, i) -= outer(Ji(i, j, all), bf) * dl; // - j_i du_i
            Bk(all, j) -= syntheticSol[i] * Ji(i, j, all) * dl;  // Goes to RHS: uB_i dj_i
        }
    }

    /*----------------------------------------------------------------------------
        Calculate Error
    ------------------------------------------------------------------------------*/
    double err_Ux = 0.0;
    double err_Uy = 0.0;
    double err_Phi = 0.0;

    // L2 Error calculation
    tensor<double, 1> sol = product(nborDOFs, bf, {{0, 0}});

    err_Ux += jac * (sol(0) - syntheticSol[0]) * (sol(0) - syntheticSol[0]);
    err_Uy += jac * (sol(1) - syntheticSol[1]) * (sol(1) - syntheticSol[1]);
    err_Phi += jac * (sol(2) - syntheticSol[2]) * (sol(2) - syntheticSol[2]);
    fillStr->addToGlobalIntegral("L2Err_Ux", err_Ux);
    fillStr->addToGlobalIntegral("L2Err_Uy", err_Uy);
    fillStr->addToGlobalIntegral("L2Err_Phi", err_Phi);

    /*----------------------------------------------------------------------------
        Writing Integration points
    ------------------------------------------------------------------------------*/
    ofstream myfile;
    myfile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    if (pDim == 2)
    {
        myfile << std::setprecision(16)
               << coords(0) << " " << coords(1) << " " << 0 << " "
               << 1 << " "
               << ((normalSide1[0] + normalSide2[0]) / 2) << " "
               << ((normalSide1[1] + normalSide2[1]) / 2) << " "
               << 0 << " " << endl;
        myfile.close();
    }
}

/*************************************************************************************************/

void syntheticSolution(double *sol, double *Dsol, double coords[], syntheticSolutionType type, int pDim)
{
    if (pDim == 2)
    {
        double x{coords[0]};
        double y{coords[1]};
        if (type == syntheticSolutionType::polynomial)
        {
            sol[0] = x + x * x - 2 * x * y + x * x * x - 3 * x * y * y + x * x * y;
            sol[1] = -y + y * y - 2 * x * y + y * y * y - 3 * x * x * y - x * y * y;
            sol[2] = x * x * x + y * y - 2 * x * x * y;

            Dsol[0] = 3 * x * x + 2 * y * x - 3 * y * y + 2 * x - 2 * y + 1;  // u,X
            Dsol[1] = x * x - 6 * y * x - 2 * x;                              // u,Y
            Dsol[2] = -6 * y * x - y * y - 2 * y;                             // v,X
            Dsol[3] = -3 * x * x - 2 * y * x + 3 * y * y - 2 * x + 2 * y - 1; // v,Y
            Dsol[4] = 3 * x * x - 4 * y * x;                                  // phi,X
            Dsol[5] = -2 * x * x + 2 * y;                                     // phi,Y
        }
        else if (type == syntheticSolutionType::sinusoidal1)
        {
            sol[0] = cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1);        // displacement u
            sol[1] = sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1);        // displacement v
            sol[2] = 0.10e1 - cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)); // electirc charge phi

            Dsol[0] = -M_PI * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1; // u,x
            Dsol[1] = cos(M_PI * x / 0.2e1) * M_PI * cos(M_PI * y / 0.2e1) / 0.2e1;  // u,y
            Dsol[2] = cos(M_PI * x / 0.2e1) * M_PI * cos(M_PI * y / 0.2e1) / 0.2e1;  // v,x
            Dsol[3] = -M_PI * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1; // v,y
            Dsol[4] = M_PI * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.2e1;    // phi,x
            Dsol[5] = M_PI * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1));            // phi,y
        }
        else if (type == syntheticSolutionType::sinusoidal2)
        {
            sol[0] = sin(M_PI * x);
            sol[1] = cos(M_PI * y);
            sol[2] = sin(M_PI * x / 0.10e2) + sin(M_PI * y / 0.10e2);

            Dsol[0] = M_PI * cos(M_PI * x);                   // u,X
            Dsol[1] = 0.0;                                    // u,Y
            Dsol[2] = 0.0;                                    // v,X
            Dsol[3] = -M_PI * sin(M_PI * y);                  // v,Y
            Dsol[4] = M_PI / 0.10e2 * cos(M_PI * x / 0.10e2); // phi,X
            Dsol[5] = M_PI / 0.10e2 * cos(M_PI * y / 0.10e2); // phi,Y
        }
    }
    else if (pDim == 3)
    {
        throw runtime_error("syntheticSolution: Not implemented for 3D.\n");
    }
}

/*************************************************************************************************/

void syntheticVolumeLoad(double *B, double &Q,
                         double l,
                         double K_L, double mL, double eL,
                         double e_L, double e_T, double e_S,
                         double mu_L, double mu_T, double mu_S,
                         double C_L, double C_T, double C_S,
                         double coords[], syntheticSolutionType type, int pDim)
{
    if (pDim == 2)
    {
        double x{coords[0]};
        double y{coords[1]};
        if (type == syntheticSolutionType::polynomial)
        {
            B[0] = -C_L * (6. * x + 2. * y + 2.) - C_T * (-6. * x - 2. * y - 2.) +
                   (-6. * x + 4. * y) * e_L + 6. * mu_L - 2. * C_S * (-6. * x - y - 1.) - 2 * e_S;
            B[1] = -2. * C_S * (x - 6. * y - 1.) + 4. * e_S * x - 8. * mu_S -
                   C_T * (2. * x - 6. * y - 2.) - C_L * (-2. * x + 6. * y + 2.) + 4. * e_T * x - 4. * mu_T;

            Q = K_L * (-6. * x + 4. * y - 2.) + e_L * (6. * x + 2. * y + 2.) +
                e_T * (-6. * x - 2. * y - 2.) + 12. * mu_L - 12. * mu_T - 24. * mu_S +
                2. * e_S * (-6. * x - y - 1.);
        }
        else if (type == syntheticSolutionType::sinusoidal1)
        {
            B[0] = -e_L * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.4e1 +
                   C_L * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 -
                   pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_L / 0.8e1 +
                   C_T * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 -
                   pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_T / 0.2e1 +
                   pow(M_PI, 0.4e1) * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * l * l * C_T / 0.8e1 +
                   pow(M_PI, 0.4e1) * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * l * l * C_L / 0.8e1 -
                   e_S * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) +
                   C_S * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1 -
                   pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_S +
                   pow(M_PI, 0.4e1) * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * l * l * C_S / 0.4e1;
            B[1] = -e_S * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.2e1 +
                   C_S * M_PI * M_PI * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) / 0.2e1 -
                   pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_S / 0.2e1 +
                   pow(M_PI, 0.4e1) * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) * l * l * C_S / 0.4e1 -
                   e_T * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) / 0.2e1 +
                   C_T * M_PI * M_PI * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) / 0.4e1 -
                   pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_T / 0.4e1 +
                   C_L * M_PI * M_PI * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) / 0.4e1 -
                   pow(M_PI, 0.3e1) * sin(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) * mu_L +
                   pow(M_PI, 0.4e1) * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) * l * l * C_L / 0.8e1 +
                   pow(M_PI, 0.4e1) * sin(M_PI * x / 0.2e1) * cos(M_PI * y / 0.2e1) * l * l * C_T / 0.8e1;

            Q = pow(M_PI, 0.3e1) * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * mu_T / 0.4e1 -
                e_T * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 +
                pow(M_PI, 0.3e1) * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * mu_S / 0.2e1 +
                pow(M_PI, 0.3e1) * sin(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) * mu_L / 0.4e1 -
                e_L * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.4e1 -
                0.5e1 / 0.4e1 * K_L * M_PI * M_PI * cos(0.2e1 * M_PI * (x / 0.4e1 + y / 0.2e1)) -
                e_S * M_PI * M_PI * cos(M_PI * x / 0.2e1) * sin(M_PI * y / 0.2e1) / 0.2e1;
        }
        else if (type == syntheticSolutionType::sinusoidal2)
        {
            B[0] = e_L * M_PI * M_PI * sin(M_PI * x / 0.10e2) / 0.100e3 +
                   C_L * M_PI * M_PI * sin(M_PI * x) - pow(M_PI, 0.3e1) * cos(M_PI * x / 0.10e2) * mu_L / 0.1000e4 +
                   pow(M_PI, 0.4e1) * sin(M_PI * x) * l * l * C_L + e_S * M_PI * M_PI * sin(M_PI * y / 0.10e2) / 0.100e3;
            B[1] = C_L * M_PI * M_PI * sin(M_PI * y) - pow(M_PI, 0.3e1) * cos(M_PI * y / 0.10e2) * mu_L / 0.1000e4 +
                   pow(M_PI, 0.4e1) * sin(M_PI * y) * l * l * C_L;

            Q = -pow(M_PI, 0.3e1) * cos(M_PI * x) * mu_L - e_L * M_PI * M_PI * sin(M_PI * x) +
                K_L * M_PI * M_PI * sin(M_PI * x / 0.10e2) / 0.100e3 -
                pow(M_PI, 0.3e1) * cos(M_PI * y) * mu_L + K_L * M_PI * M_PI * sin(M_PI * y / 0.10e2) / 0.100e3;
        }
    }
    else if (pDim == 3)
    {
        throw runtime_error("syntheticSolution: Not implemented for 3D.\n");
    }
}

/*************************************************************************************************/

void norm(std::vector<double> &A)
{
    double normA{};

    for (size_t i{}; i < A.size(); ++i)
        normA += A[i] * A[i];

    normA = sqrt(normA);

    for (size_t i{}; i < A.size(); ++i)
        A[i] /= normA;
}
