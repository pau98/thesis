#include <iostream>
#include <mpi.h>
#include <math.h>

#include <unistd.h> //FIXME sleep function
#include <stdlib.h>

#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include <hl_DistributedSrcData.h>
#include "hl_BasisFunctions.h"
#include "hl_Timer.h"
#include <vector>
#include <stdio.h>      /* printf, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */      /* time */

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


int main()
{

    MPI_Init(nullptr, nullptr);

    Timer timer({"Init", "OutputFile" ,"SearchAlg", "Linear"});
    timer.start("Init");

    RCP<StructMeshGenerator> meshGen = rcp(new StructMeshGenerator);
    meshGen->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    int nx = 100;
    meshGen->genRectangle(nx, nx, 1.0, 1.0);


    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh("DisMesh"));
    disMesh->setMesh(meshGen);
    disMesh->Update();

    timer.end("Init");


    std::vector<double> v(3);
    int max_points = 10;
    int precision = 5;
    int pointRange = 1.E5;
    srand(time(0));
    int fails = 0;
    for (int k = 0; k < max_points; k++)
    {
        if(disMesh->myRank() == 0)
        {
            v[0] = double(rand() % pointRange)/double(pointRange);
            v[1] = double(rand() % pointRange)/double(pointRange);
            v[2] = 0.00;
        }

        MPI_Bcast(v.data(), v.size(), MPI_DOUBLE, 0, disMesh->comm());


        // SEARCH TIME
        int max_iters = 1;
        int element;
        timer.start("SearchAlg");
        for (int i = 0; i < max_iters; i++)
        {

            if (disMesh->insideRange(v))
            {
                element = disMesh->searchElem(v);
                if (element != -1)
                {
                    cout << disMesh->myRank() << ":   Point: [" << v[0] << ", " << v[1] << "]. Element: " << element << endl;
                    vector<double> w = disMesh->barCoordInsideElem(element, v);
                    if (!w.empty())
                        cout << disMesh->myRank() << ":   Point: [" << v[0] << ", " << v[1] << "]. Bar. coord.: [" << w[0] << ", " << w[1] << "]." << endl;
                    else
                        cout << "PROBLEM: BARICENTRIC COORDINATES WRONG" << endl;
                }
            }
            else
                element = -1;


            int maxElem;
            MPI_Allreduce(&element, &maxElem, 1, MPI_INT, MPI_MAX, disMesh->comm());
            if (maxElem == -1)
            {
                if (disMesh->myRank() == 0)
                    //cout << "Point: [" << v[0] << ", " << v[1] << "]. Element not found in any partition in iteration " << i << ", sorry." << endl;
                    fails++;
            }
        }
        int idx = -2;
        vector<double> w;

        int found = disMesh->elementSearch(idx, w, v);

        if (found == disMesh->myRank())
        {
            if (!w.empty())
                cout << "Partition: " << disMesh->myRank() << ". Point: [" << v[0] << "," << v[1] << "]. Element: " << idx << ". Baricentric: [" << w[0] << "," << w[1] << "]." << endl;
            else
            {
                cout << "Partition: " << disMesh->myRank() << ". Point: [" << v[0] << "," << v[1] << "]. Element: " << idx << ". NO BARICENTRIC" << endl;
                fails++;
            }
        }
        else if (found == -2)
        {
            cout << "Point: [" << v[0] << "," << v[1] << "]. HERE WE HAVE A PROBLEM" << endl;
            fails++;
        }
        /*else
          cout << "Partition: " << disMesh->myRank() << ". NOT FOUND." << endl;*/

        timer.end("SearchAlg");



        // LINEAR TIME
        timer.start("Linear");
        for (int i = 0; i < max_iters; i++)
        {
            int element2 = -1;
            if (disMesh->insideRange(v))
            {
                int numElem = disMesh->loc_nElem();
                for(int j = 0; j < numElem and element2 == -1; j++)
                {
                    if(disMesh->isXinsideElem(j, v, IndexType::Local))
                        element2 = j;
                }
            }
            else
            {
                cout << "Impossible to be at partition " << disMesh->myRank() << endl;
            }
       }

       timer.end("Linear");


       // COMPUTING TIME
       string prefix = to_string(disMesh->numProcs()) + " " + to_string(nx*nx);
       sleep(1);
       timer.printTiming(true);
       sleep(1);
       timer.printTesting(prefix);

    }

    if (disMesh->myRank() == 0)
        cout << " Total Failures: " + to_string(fails) << "  -  " + to_string(double(fails)/double(max_points)) << endl;

    MPI_Finalize();
    return 0;

}
