
#include <iostream>
#include <mpi.h>
#include <tuple>

#include <Teuchos_RCP.hpp>

#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;



int main(int argc, char **argv)
{

    //Initialize
    MPI_Init(nullptr, nullptr);
    int myRank;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    //###################################################################//
    //                             MAIN MESH                             //
    //###################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "MESH" << endl;

    //Generate mesh
    RCP<UnstructVtkMeshGenerator> unstructMesh = rcp (new UnstructVtkMeshGenerator);
    unstructMesh->setElemType(ElemType::Triang);
    unstructMesh->setBasisFuncType(BasisFuncType::SubdivSurfs);
    // unstructMesh->genTorus([](double x[3]){return -0.5*0.0125*(tanh(100.0*x[1])+1.0)+0.015;});
    // unstructMesh->genSphere([](double x[3]){return 0.001;},[](double x[3]){return std::array<double,3>({x[0],x[1],x[2]*(1.0+0.2*cos(3*M_PI*x[1]))});});
    // unstructMesh->genSphere([](double x[3]){return 0.01;});
    // unstructMesh->genPolygon([](double x[3]){return 0.01*(1.0-0.9*(0.5*tanh(10.0*(sqrt(x[0]*x[0]+x[1]*x[1])-0.6))+0.5));},[](double x[3]){return array<double,3>({x[0],x[1],exp(-(x[0]*x[0]+x[1]*x[1]))});});
    // unstructMesh->genSphere([](double x[3]){return 0.05;}, [](double x[3]){return array<double,3>({x[0],x[1],x[2]});});
    // [](double x[3]){return x;});
    unstructMesh->genSphere([](double x[3]){
                                if (x[2]>-0.5)
                                    return 0.02;
                                else
                                    return 0.002;
                            });

    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(unstructMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    //Print mesh
    disMesh->printFileLegacyVtk("MeshGenerated");
    disMesh->printFile("MeshGenerated");

    RCP<DistributedMesh> disMesh2 = rcp(new DistributedMesh);
    disMesh2->setMeshRelation(MeshRelation::hRefin, disMesh);
    disMesh2->setHRefinement(1);
    disMesh2->setBalanceMesh(true);
    disMesh2->Update();
    disMesh2->printFileLegacyVtk("MeshGenerated2");


    //Finalize
    MPI_Finalize();

    return 0;
}
