/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct PoissonParams
{
    enum RealParameters
    {
        force,
        beta
    };

    enum IntParameters
    {
        timeStep,
    };

    HL_PARAMETER_LIST DefaultValues
    {
        {"force", 0.0},
        {"beta", 100.0},
        {"timeStep",0}
    };
};

bool fileExists(const std::string& filename)
{
    struct stat buf;
    if (stat(filename.c_str(), &buf) != -1)
    {
        return true;
    }
    return false;
}

void LS_backBulk1(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            Ak(i,0,j,0) += jac * gNagNb;
        }
    }

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);
    // Output integration points
    if (subFill.dhandDHand->nameTag() == "backDHand")
    {
        ofstream myfile;
        if (!fileExists("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv"))
        {
            myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
            myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
            myfile.close();
        }
        myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
        myfile << std::setprecision(16) << x[0] << "," << x[1] << "," << jac << endl;
        myfile.close();
    }
    return;
}

void LS_backBulk2(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    ttl::tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            Ak(i,1,j,1) += jac * gNagNb;
        }
    }

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);
    return;
}

void LS_backBulk3(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 2 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    ttl::tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            Ak(i,2,j,2) += jac * gNagNb;
        }
    }

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);
    return;
}

void LS_backBorder(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    // Parameters
    double beta = fillStr.getRealParameter(PoissonParams::beta);

    // Background
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives

    // ===================== Values at int. points ==================== //
    // Compute jacobian
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
    jac = Math::Norm3D(t.data());

    // Compute unitary normal
    vector<double> n(3, 0.0);
    n[0] = t[1]/jac;
    n[1] = -t[0]/jac;

    // Compute coordinates using the back mesh
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    

    ofstream myfile;
    myfile.open("cubatureImm2."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    // myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    // myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
    myfile << std::setprecision(16) << std::setprecision(16) << x[0] << " " << x[1] << " " << " " << n[0] << " " << n[1] << " " << t[0] << " " << t[1] << endl;
    myfile.close();

    // =====================  Fill linear system ===================== //
    double gD = x[0]*x[1];
    // if (abs(jac-0.025) < 0.02)
    // {
    //     cout << jac << endl;
    //     cout << "n: (" << n[0] << ", " << n[1] << ")"<< endl;
    //     cout << "t: (" << t[0] << ", " << t[1] << ")"<< endl;
    //     cout << "x: (" << x[0] << ", " << x[1] << ")"<< endl;

    // }// cout << eNN << endl;
    tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    if (false)
    {
        double beta = 5000.0;

        for (int i = 0; i < eNN; i++)
        {
            for (int j = 0; j < eNN; j++)
            {
                // Fill matrix
                Ak(i,0,j,0) +=  jac * beta * bf[i] * bf[j];
                Ak(i,1,j,0) += - jac * beta * bf[i] * bf[j];
                Ak(i,0,j,1) += - jac * beta * bf[i] * bf[j];
                Ak(i,1,j,1) +=  jac * beta * bf[i] * bf[j];
            }
        }
    }   
    // Nitsche symmetric
    if (true)
    {
        for (int i = 0; i < eNN; i++)
        {
            double dbfnI{};
            for (int d = 0; d < pDim; d++)
                dbfnI += dbf[pDim*i+d]*n[d];
            
            // Bk(i,0) += jac * beta * bf[i]* gD;
            // Bk(i,0) += jac * gD * dbfnI;
            // Bk(i,1) += jac * beta * bf[i]* gD;
            // Bk(i,1) += jac * gD * dbfnI;
            // fillStr.Bk(0)[i*DOF*eNN] += jac * gD * gD;

            for (int j = 0; j < eNN; j++)
            {
                double dbfnJ{};
                for (int d = 0; d < pDim; d++)
                    dbfnJ += dbf[pDim*j+d]*n[d];

                // Fill matrix
                Ak(i,0,j,0) += jac * beta * bf[i] * bf[j];
                Ak(i,0,j,0) += jac * bf[i] * dbfnJ;
                Ak(i,0,j,0) += jac * dbfnI * bf[j];

                Ak(i,0,j,2) -= jac*beta*bf[i]*bf[j];
                Ak(i,0,j,2) -= jac*dbfnI*bf[j];
                Ak(i,2,j,0) -= jac*beta*bf[j]*bf[i];
                Ak(i,2,j,0) -= jac*dbfnJ*bf[i];

                Ak(i,2,j,2) += jac * beta * bf[i] * bf[j];

                Ak(i,1,j,1) += jac * beta * bf[i] * bf[j];
                Ak(i,1,j,1) += jac * bf[i] * dbfnJ;
                Ak(i,1,j,1) += jac * dbfnI * bf[j];

                Ak(i,1,j,2) -= jac*beta*bf[i]*bf[j];
                Ak(i,1,j,2) -= jac*dbfnI*bf[j];
                Ak(i,2,j,1) -= jac*beta*bf[j]*bf[i];
                Ak(i,2,j,1) -= jac*dbfnJ*bf[i];

                // Ak(i,2,j,2) += jac * beta * bf[i] * bf[j];
                
                // Ak(i,1,j,1) += jac * bf[i] * dbfnJ;
                // Ak(i,1,j,1) += jac * dbfnI * bf[j];
            }
        }
    }
    // Save local length
    fillStr.addToGlobalIntegral("Length", jac);

    return;
}

RCP<MultiPatchMeshGenerator> genGeom(double xC1, double yC1, double xC2, double yC2)
{
    // Vector of patches
    vector<RCP<MeshCreator>> patches;

    int nEx = 50;

    // First mesh
    RCP<StructMeshGenerator> mesh1 = Create<StructMeshGenerator>();
    mesh1->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    mesh1->genCircle(nEx, 0.09);
    mesh1->translateXY(xC1, yC1);

    // Second mesh
    RCP<StructMeshGenerator> mesh2 = Create<StructMeshGenerator>();
    mesh2->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    mesh2->genCircle(nEx, 0.09);
    mesh2->translateXY(xC2, yC2);

    // Join patches
    patches.push_back(mesh1);
    patches.push_back(mesh2);
    RCP<MultiPatchMeshGenerator> mpatch = Create<MultiPatchMeshGenerator>();
    mpatch->setMeshes(patches, MultiPatchConnectivity::Unclamped, 0.0001);

    mpatch->Update();

    return mpatch;
}    

void CheckSolution(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::N, ttl::index::i;

    SubFillStructure &subFill = fillStr[0];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN = subFill.eNN;

    tensor<double, 2> Dbf(eNN, pDim);
    double jac;
    GlobalBasisFunctions::gradients(Dbf, jac, subFill);

    wrapper<double, 1> dofsI(subFill.nborDOFs.data(), eNN);
    wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
    wrapper<double, 1> bf(subFill.nborBFs(), eNN);
    tensor<double, 1> x(nDim);
    x = coordsI(N, i) * bf(N);

    const double u_numeric = dofsI(N) * bf(N);
    const double u_analytial = sin(M_PI*x(0))*sinh(M_PI*x(1)) / sinh(M_PI);
    const double error = jac * abs(u_numeric-u_analytial);
    fillStr.addToGlobalIntegral("error", error);
}

int main(int argc, char** argv)
{

    hiperlife::Init(argc, argv);

    //============================ Parameters ============================//
    int nx = 10;
    int ny = 10;
    // cout << "Type number of elements per side: " << endl;
    // cin >> nx;
    SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();
    // userStr->dparam.resize(1);
    double beta = 8*100*nx; // beta = 100*h (from 2017Badia)
    paramStr->setRealParameter(PoissonParams::beta,beta);



    // *******************************************************************//
    // *****                      MESH CREATION                      *****//
    // *******************************************************************//
    int nSteps = 20;
    int bfOrder = 2;
    int timeStep = 0;
    for (int nS{}; nS < nSteps; nS++)
        {
        timeStep++;
        paramStr->setIntParameter(PoissonParams::timeStep,timeStep);
        //-------------------------- Background mesh -------------------------//

        // Mesh generator
        SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
        back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
        back->genStructMesh(nx, ny);
        // Mesh refinement
        double c0 = 0.5;
        double r0 = 0.3;
        double eps = 0.0001;
        vector<int> phmodes = {5};
        
        int refmax = 3;
        int nEside = 60;
        double theta = (double)nS/(double)nSteps*2*M_PI+0.5;

        double xC1 = 0.8; double yC1 = 0.2; double xC2 = 0.2; double yC2 = 0.8; 
        if (nS < nSteps/2)
        {
            yC1 += (double)nS/(double)nSteps*0.6*2.;
            yC2 -= (double)nS/(double)nSteps*0.6*2.;
        }
        else
        {
            yC1 = 0.8;
            yC2 = 0.2;
            xC1 -= (double)(nS-nSteps/2)/(double)nSteps*0.6*2.;
            xC2 += (double)(nS-nSteps/2)/(double)nSteps*0.6*2.;
        }

        // SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();
        RCP<MultiPatchMeshGenerator> imm = genGeom(xC1, yC1, xC2, yC2);

        // imm->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
        // // imm->genSquareLine(nEside, 0.51);
        // imm->genCircle(nEside, 0.2);
        // // imm->translateXY(-0.255, -0.255);
        // imm->rotate2D(theta);
        // imm->translateXY(0.5, 0.5);
    
        SmartPtr<DistributedMesh> immProva = Create<DistributedMesh>("immMeshProva");
        immProva->setMesh(imm);
        immProva->setBalanceMesh(true);
        immProva->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        immProva->setVerbosity(Verbosity::None);
        immProva->Update();

        vector<vector<double>> immPtsBndry;
        for (int n = 0; n < immProva->loc_nPts(); n++)
        {
            vector<double> x = immProva->nodeCoords(n,IndexType::Local);
            immPtsBndry.push_back({x[0],x[1]});
        }

        auto immDist = [&] (vector<double> pos)
        {
            double minDist = 1e10;
            for (vector<double> ptImm : immPtsBndry)
            {
                vector<double> pdiff = {abs(ptImm[0]-pos[0]),abs(ptImm[1]-pos[1])};
                double modPdiff = max(pdiff[0],pdiff[1]);
                minDist = min(modPdiff,minDist);
            }
            return minDist;
        };
        back->threeRefine([=](double x,double y, double z){
                                double idist = immDist({x,y});
                                if (idist < 2*1e-3) return 3;
                                if (idist < 1e-2) return 2;
                                if (idist < 2*1e-2) return 1;
                                return 0;
                                },refmax,{20,20,20,20});
        // Distributed mesh
        SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
        backMesh->setMesh(back);
        backMesh->setBalanceMesh(true);
        backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        backMesh->setVerbosity(Verbosity::None);
        backMesh->Update();


        //--------------------------- Immersed mesh --------------------------//

        // Distributed mesh
        SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
        immMesh->setMesh(imm);
        immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
        // immMesh->setImmersedInteriorPoints({{0.5, 0.5, 0.0}});
        immMesh->setImmersedInteriorPoints({{{xC1, yC1, 0.0}},{{xC2,yC2,0.0}},{{0.5,0.5,0}}});
        immMesh->setRegionTags({"Interior1","Interior2","Exterior"});
        immMesh->setBalanceMesh(true);
        immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        immMesh->setVerbosity(Verbosity::None);
        immMesh->Update();

        // Print meshes
        backMesh->printFileLegacyVtk("meshBack");
        immMesh->printFileLegacyVtk("meshImm");

        // for (size_t i = 0; i < (_immSegments.size() / 9); ++i)

        // vector<double> immSegments = backMesh->_ImmersedSegments();
        // for (size_t i = 0; i < (immSegments.size() / 6); ++i)
        // {
        //     double xStart = immSegments[6 * i + 0];
        //     double yStart = immSegments[6 * i + 1];
        //     double xEnd = immSegments[6 * i + 3];
        //     double yEnd = immSegments[6 * i + 4];
        //     cout << "(" << xStart<< ", "<< yStart<<")";
        //     cout << "-> (" << xEnd<< ", "<< yEnd<<")";
        //     cout << endl;
        // }
        // *******************************************************************//
        // *****                   DOFsHandler CREATION                  *****//
        // *******************************************************************//

        //----------------------- Background DOFsHandler ---------------------//
        SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
        backDHand->setNameTag("backDHand");
        backDHand->setDOFs({"u1","u2","u3"});
        backDHand->setNodeAuxF({"const","ctag","stab"});
        backDHand->setElemAuxF({"tag","WI"});
        backDHand->setDofTags({"Interior1","Interior2","Exterior"});
        backDHand->Update();

        // Save interior/cut/exterior flags for plotting
        for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
        {
            int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
            backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
            vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
            vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
            for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
            {
                if (backDHand->mesh->isNodeInPart(nbors[n]))
                    backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
            }
        }
        backDHand->UpdateGhosts();

        // Set boundary conditions
        backDHand->setBoundaryCondition("u3", MAxis::Xmin, 1.0);
        backDHand->setBoundaryCondition("u3", MAxis::Xmax, [](double y){return y*y;});
        // backDHand->setBoundaryCondition("u2", MAxis::Xmax, [](double y){return 0.0*y;});
        backDHand->UpdateGhosts();

        backDHand->printFileLegacyVtk("dofBack", true);

        // hiperlife::Finalize();
        // return 0;

        // *******************************************************************//
        // *****                    IMMERSED PROBLEM                     *****//
        // *******************************************************************//
        if (true)
        {
            // Immersed HiPerProblem
            SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
            //General setters
            immHP->setParameterStructure(paramStr);
            immHP->setGlobalIntegrals({"Area","Length","Error"});
            immHP->setDOFsHandlers({backDHand});

            // Set integration for the border
            immHP->setIntegration("IntegBorder", {"backDHand"});
            immHP->setCubatureBorderImmersed("IntegBorder", 3);
            immHP->setElementFillings("IntegBorder", LS_backBorder);

            // Set integration for the background mesh
            immHP->setIntegration("Integ1", {"backDHand"});
            // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
            immHP->setCubatureCutCellConforming("Integ1", 9, 2,"Interior1");
            immHP->setElementFillings("Integ1", LS_backBulk1);

            // Set integration for the background mesh
            immHP->setIntegration("Integ2", {"backDHand"});
            // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
            immHP->setCubatureCutCellConforming("Integ2", 9, 2,"Interior2");
            immHP->setElementFillings("Integ2", LS_backBulk2);

            // Set integration for the background mesh
            immHP->setIntegration("Integ3", {"backDHand"});
            // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
            immHP->setCubatureCutCellConforming("Integ3", 9, 2,"Exterior");
            immHP->setElementFillings("Integ3", LS_backBulk3);

            immHP->Update();

            // hiperlife::Finalize();
            // return 0;

            //-------------------------- Immersed solver -------------------------//
            SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
            immSOL->setHiPerProblem(immHP);
            immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
            immSOL->setDefaultParameters();
            immSOL->Update();
            //---------------------------- Solve immersed ------------------------//
            // Solve
            // immHP->FillLinearSystem();
            immSOL->solve();
            immSOL->UpdateSolution();
            string meshName = to_string(nS);
            if(false) // Print matrix and rhs
            {
                string LHSName = "LHS." + meshName +".mm";
                string SolName = "Sol." + meshName +".mm";
                string RHSName = "RHS." + meshName +".mm";
                const char *CLHSName = LHSName.c_str();
                const char *CSolName = SolName.c_str();
                const char *CRHSName = RHSName.c_str();
                EpetraExt::RowMatrixToMatrixMarketFile(CLHSName, *immHP->A, "LHS", "Left hand side matrix");
                EpetraExt::MultiVectorToMatrixMarketFile(CSolName, *immHP->sol, "Sol", "Solution vector");
                EpetraExt::MultiVectorToMatrixMarketFile(CRHSName, *immHP->rhs, "RHS", "Right hand side vector");

                ofstream CoordsFile;
                CoordsFile.open ("Coords." + meshName +".csv");
                for (int d = 0; d < backMesh->loc_nPts(); d++)
                {
                    // Get node coordinates
                    std::vector<double> x = backMesh->nodeCoords(d, IndexType::Local);
                    CoordsFile << x[0] << "," << x[1] << endl;
                }
                for (int d = 0; d < immMesh->loc_nPts(); d++)
                {
                    // Get node coordinates
                    std::vector<double> x = immMesh->nodeCoords(d, IndexType::Local);
                    CoordsFile << x[0] << "," << x[1] << endl;
            }
            CoordsFile.close();
            }

            
            // Print
            string solName = "solBack."+to_string(nS);
            backDHand->printFileLegacyVtk(solName, true);
            string immMshName = "meshImm."+to_string(nS);
            immMesh->printFileLegacyVtk(immMshName);

            double L = immHP->globalIntegral("Length");
            double A = immHP->globalIntegral("Area");
            cout <<"Theta: " <<theta<< "Area: " << A << " Lenght: " << L << endl;

        }
    }

    hiperlife::Finalize();
    return 0;
}