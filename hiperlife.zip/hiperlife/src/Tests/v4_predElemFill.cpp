
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_PredefinedElementFillings.h"
#include "hl_TypeDefs.h"
#include "hl_UserStructure.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_TimeIterator.h"

#include "hl_FillStructure.h"
#include "hl_GlobalBasisFunctions.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    MPI_Init(nullptr, nullptr);

    // Put parameters in the user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->Poisson.source = [](double x, double y, double z){return x*x*10.0;};
    userStr->TransientDiffusion.source = userStr->Poisson.source;
    userStr->TransientDiffusion.diffusionCoefficient = 1.0;
    userStr->CahnHilliard.epsilon2 = 0.0005*4;
    // userStr->CahnHilliard.constantMobility = 1.0;
    userStr->CahnHilliard.mobility = [](double c)->vector<double>
    {
        return {c*(1-c), 1-2*c};
    };
    // userStr->CahnHilliard.doubleWell = [](double c)->vector<double>
    // {
    //     return {(c*c)*(1.0-c)*(1.0-c)/4.0,
    //             c*(1.0-c)*(1.0-2.0*c)/2.0,
    //             (1.0-6.0*c+6.0*c*c)/2.0,
    //             (-1.0+2.0*c)*3.0};
    // };
    userStr->CahnHilliard.doubleWell = [](double c)->vector<double>
    {
        return {0, 0, 1.0/(c*(1.0-c)) - 2.0*3.0, (2.0*c-1.0)/(c*c*(1.0-c)*(1.0-c))};
    };


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create a line structured mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(ElemType::Line, BasisFuncType::BSplines, 2);
    // structMesh->genAnnularSector(50, 50, 0.2, 1.0, M_PI/2.0);
    structMesh->genStructMesh(50);

    // Distribute the mesh among all the processors
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Create a DOFsHandler with one degree of freedom (c)
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"u"});
    dhand->Update();

    // Set initial and boundary conditions for the DOF
    srand(time(NULL));
    dhand->setInitialCondition("u",
                                 [](double x, double y)
                                 {
                                     double r = sqrt(x*x + y*y);
                                     double d = sqrt((r-0.6)*(r-0.6));
                                     return 6.25*d*d-1.0;
                                 });
    dhand->setInitialCondition("u", [=](double x, double y){
                                        double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
                                        return 0.63+0.05*r;
                                        double u = 0.5-0.5*tanh((sqrt((x-0.5)*(x-0.5))-0.25)/(sqrt(2*0.001)));
                                        return u*(0.63+0.05*r);
                                    });
    int fid = 0;
    int sid = 1;
    int pid = dhand->mesh->loc_nPts()-2;
    int lid = dhand->mesh->loc_nPts()-1;
    double f = dhand->nodeDOFs->getValue(0, fid, IndexType::Local);
    double l = dhand->nodeDOFs->getValue(0, lid, IndexType::Local);
    double s = dhand->nodeDOFs->getValue(0, sid, IndexType::Local);
    double p = dhand->nodeDOFs->getValue(0, pid, IndexType::Local);
    dhand->nodeDOFs->setValue(0, lid, IndexType::Local, (s+p)/2.0);
    dhand->nodeDOFs->setValue(0, 0,   IndexType::Local, (s+p)/2.0);
    // dhand->setBoundaryCondition("u", MAxis::Xmin, 0.0);
    // dhand->setBoundaryCondition("u", MAxis::Xmax, 0.0);
    dhand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // hiperproblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setElementFillings("Integ", PredefinedElementFillings::CahnHilliard);
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->setLinearConstraint({0, 0, lid, IndexType::Global},
                                    {0, 0, fid, IndexType::Global});
    hiperProbl->setLinearConstraint({0, 0, pid, IndexType::Global},
                                    {{0, 0, fid, IndexType::Global}, {0, 0, sid, IndexType::Global}},
                                    {2.0, -1.0});
    hiperProbl->Update();

    // Linear solver
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // linSolver->solve();
    // linSolver->UpdateSolution();
    // MPI_Finalize();
    // return 0;

    RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp (new NewtonRaphsonNonlinearSolver());
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    // Time iterator
    RCP<TimeIterator> tIterator = rcp(new TimeIterator);
    // tIterator->setLinearSolver(linSolver);
    tIterator->setNonlinearSolver(nonlinSolver);
    tIterator->setTimeStepSize(1e-5);
    tIterator->setStopCriteria(2000, 1e3, 1e-12);
    tIterator->setTimeSteppingScheme(TimeSteppingScheme::AdaptiveLinear);
tIterator->setLinearStepFactor(1.01, 0.5);
    tIterator->setMaximumTimeStepSize(0.1);
    tIterator->setPrintToFile(PrintToFileMethod::LegacyVtk, 1, "predElemFill");
    // tIterator->setPrintRestart(10, "restart");
    // tIterator->setPostprocess(1, [=](){dhand->printFileLegacyVtk("HeatEq" + to_string(tIterator->timeStep()));});
    tIterator->Update();


    // **************************************************************//
    // *****                       SOLVE                        *****//
    // **************************************************************//

    tIterator->Iterate();

    // **************************************************************//
    // *****                      FINALIZE                      *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
