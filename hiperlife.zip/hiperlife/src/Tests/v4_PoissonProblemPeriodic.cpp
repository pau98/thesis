
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);

/// In this first tutorial everything is implemented inside the main
///   function
int main()
{


    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);


    ///=============== Define parameters of the model ===============///

    int nx,ny,nz;
    double Lx, Ly, Lz;
    double force = 1000.0;     // Forcing
    int order = 1; // interpolation order
    vector<Axis> axis;
    int testCase = 2; // if t testCase=2 for 2D and testCase=3 for 2D
    double deltat=0.02;
    string solname_v = "PoissonPeriodicBC";

    nx=10;   // number of elements in x-direction
    ny=10;    // number of elements in y-direction
    Lx = 1; // length along the x-direction
    Ly = 1; // length along the y-direction
    axis.push_back(Axis::Xaxis);
    axis.push_back(Axis::Yaxis);


    /// Save the parameters into double data type variables
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(2);
    userStr->dparam[0] = force;
    userStr->dparam[1] = deltat;
    userStr->iparam.resize(1);
    userStr->iparam[0] = testCase;




    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//



    // Remove warning by an error in unclamp nurbs
    // Implement unclamp nurbs
    // diskSquared only for nurbs
    // Quarterplatewithcircularhole only for nurbs
    // Minimize the number of repeated knot spans in surfaces of revolution


    ///====================== Mesh generation ======================///
    ///
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setBasisFuncType(BasisFuncType::Lagrangian);
    structMesh->setBasisFuncOrder(order);

    ElemType eType = ElemType::Triang;
    int bfOrder = 1;

    if (axis.size()>0)
        structMesh->setPeriodicBoundaryCondition(axis);

    // Impose the periodic BCs

    structMesh->setElemType(ElemType::Triang);
    structMesh->genRectangle(nx, ny, Lx, Ly);
    // structMesh->genAnnularSector(21, 29, 0.25, 0.5, 0.0, M_PI/2.0);

    ///===========             Distribute mesh            ===========///
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    RCP<DistributedMesh> disMesh_ = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();



    disMesh->printFileLegacyVtk("Mesh");
    disMesh->printFileLegacyCSV("Mesh");


    cout << disMesh->myRank() << ": " << disMesh->listGhosts().size() << endl;

    cout <<  disMesh->myRank()  << " ";
    for (auto g: disMesh->listGhosts())
        cout << g << " ";
    cout << endl;



    /// Constructing the pressure Distributed Mesh through p-refinement of the previous one
    disMesh_->setMeshRelation(MeshRelation::pRefin, disMesh);  // Set Parent mesh and relation to it.
    disMesh_->setPRefinement(1);        // Set this mesh a pRef respect to the velocity one
    disMesh_->setBalanceMesh(true);      // Enable Load Balance
    disMesh_->Update();                  // Create the DistributedMesh

    /// Constructing the pressure Distributed Mesh through h-refinement of the previous one
    // Distribute mesh
    RCP<DistributedMesh> posDisMesh = rcp(new DistributedMesh);
    posDisMesh->setHRefinement(1);
    posDisMesh->setMeshRelation(MeshRelation::hRefin, disMesh);
    posDisMesh->setBalanceMesh(true);
    posDisMesh->Update();


/// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//  //FIXME: Change name in this section
    /// **************************************************************//

    ///===========           Create DOFHandler            ===========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh_));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    // dofHand->setNumNodeAuxF(1);
    dofHand->Update();

    ///===========          Initial conditions          ===========///


    // Impose initial conditions
    for(int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    {
        dofHand->nodeDOFs->setValue(0, i, IndexType::Local, 0) ;
    }

    for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
    {
        double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
        double y = dofHand->mesh->nodeCoord(i, 1, IndexType::Local);
        double z = dofHand->mesh->nodeCoord(i, 2, IndexType::Local);
        // if (y > 0.9)
        //     dofHand->setConstraint(0, i, IndexType::Local, 1.0);
        // if (y < -0.9)
        //     dofHand->setConstraint(0, i, IndexType::Local, -1.0);
        // dofHand->nodeAuxF->setValue(0, i, IndexType::Local, x);
    }
    dofHand->UpdateGhosts();



    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});

    ///===========            Set integration             ===========///
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->setElementFillings("Integ", LS);

    ///===========                 Update                ===========///
    hiperProbl->Update();

    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
//    RCP<AmesosDirectLinearSolver> solver = rcp ( new AmesosDirectLinearSolver());
//    solver->setHiPerProblem(hiperProbl);
//    solver->setnumericfactorization(true);
//    solver->setsymbolicfactorization(true);
//    solver->Update();

    RCP<AztecOOIterativeLinearSolver> solver = rcp ( new AztecOOIterativeLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setTolerance(1.E-8);
    solver->setMaxNumIterations(500);
    solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    solver->setDefaultParameters();
    solver->Update();

    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    //Loop over time steps
    //Loop over time steps
    double time    = 0.0;
    double totTime = 1.E2;
    int timeStep   = 0;
    while (timeStep < 10)
    {
        //Write
        if (hiperProbl->myRank() == 0)
            cout << endl << "Time step " + to_string(timeStep) + " Time " << to_string(time) + " Increment " << to_string(deltat) << endl;

        //Initial guess
        dofHand->nodeDOFs0->setValue(dofHand->nodeDOFs);
        hiperProbl->UpdateGhosts();
        hiperProbl->FillLinearSystem();


        bool status = solver->solve();

        solver->output(AztecOOIterativeLinearSolver::Verbosity::High);

        hiperProbl->UpdateSolution();

        dofHand->printFile("Poisson");
        dofHand->printFileLegacyVtk("Poisson_"+to_string(timeStep), true);
        timeStep++;
    }



    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}

void LS(RCP<FillStructure> fillStr)
{
    using namespace std;



    ///===========          Initialize variables           ==========///

    ///   fillStr as follows
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    /// which we use to declare the variables:
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFsDers(0);  // Local shape function
    double* glNa = subFill.nborBFsDers(1); // Local shape function derivatives
    double *uNodes0 = subFill.nborDOFs0.data();
    /// Finally, we compute the global values of the shape function
    ///   derivatives and the jacobian determinant of the mapping
    vector<double> gNa(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(gNa.data(), jac, subFill);
    vector<double> kCoords(3);
    Math::MatProduct(kCoords.data(), 1, eNN, nDim, Na, xe_nodes.data());
    double xx = kCoords[0];
    double yy = kCoords[1];
    double zz = kCoords[2];
    double force;
    double deltat = fillStr->userStr->dparam[1];
    double u0[1]{};
    for (int i = 0; i < eNN; i++)
    {
        Math::AXPY(u0,1,Na[i],&uNodes0[i]);
    }

    // Initializing source term

    ///=====================  Fill linear system =====================///
    ///
    /// We loop through the neighboring nodes to fill both the matrix
    ///   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute efethe product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * Na[i]*Na[j]/deltat;
        }
        if (false)
        {
            if ( xx > 0.40*0.40 and xx < 0.43*0.43 ) //source is a line
            {
                force = fillStr->userStr->dparam[0];
            }
            else
            {
                force = 0;
            }
        }
        else if (true)
        {
            if ( (xx-0.6)*(xx-0.6) + (yy-0.6)*(yy-0.6) < 0.4*0.4 ) //source is a circle
            {
                force = fillStr->userStr->dparam[0];
            }
            else
            {
                force = 0;
            }

        }
        else if (false)
        {
            if ( (xx-0.7)*(xx-0.7) + (yy-0.7)*(yy-0.7)   + (zz-0.5)*(zz-0.5) < 0.4*0.4 ) //source is a sphere
            {
                force = fillStr->userStr->dparam[0];
            }
            else
            {
                force = 0;
            }
        }


        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * u0[0]/deltat ;
    }

    return;
}
