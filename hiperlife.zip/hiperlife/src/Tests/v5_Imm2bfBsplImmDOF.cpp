/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct PoissonParams
{
    enum RealParameters
    {
        force,
        beta
    };

    enum IntParameters
    {
        timeStep,
    };

    HL_PARAMETER_LIST DefaultValues
    {
        {"force", 0.0},
        {"beta", 100.0},
        {"timeStep",0}
    };
};

bool fileExists(const std::string& filename)
{
    struct stat buf;
    if (stat(filename.c_str(), &buf) != -1)
    {
        return true;
    }
    return false;
}

void LS_backBulk1(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            Ak(i,0,j,0) += jac * gNagNb;
        }
    }

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);
    // Output integration points
    if (subFill.dhandDHand->nameTag() == "backDHand")
    {
        ofstream myfile;
        if (!fileExists("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv"))
        {
            myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
            myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
            myfile.close();
        }
        myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
        myfile << std::setprecision(16) << x[0] << "," << x[1] << "," << jac << endl;
        myfile.close();
    }
    return;
}

void LS_backBulk2(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    ///===================== Values at int. points ====================///
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }

    ofstream myfile;
    myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
    myfile.close();


    ///=====================  Fill linear system =====================///
    ttl::tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += dbf[pDim*i+d]*dbf[pDim*j+d];

            /// Fill matrix
            Ak(i,1,j,1) += jac * gNagNb;
        }
    }

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);
    return;
}

void LS_backBorder(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //============          Initialize variables           ===========//
    // Parameters
    double beta = fillStr.getRealParameter(PoissonParams::beta);

    // Background
    SubFillStructure& subFill = fillStr["backDHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.nborBFsDers(0);   // Local shape function
    double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives

    // ===================== Values at int. points ==================== //
    // Compute jacobian
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    // Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
    jac = Math::Norm3D(t.data());

    // Compute unitary normal
    vector<double> n(3, 0.0);
    n[0] = -t[1]/jac;
    n[1] = -(-t[0])/jac;

    // Compute coordinates using the back mesh
    vector<double> x(nDim);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < nDim; d++)
            x[d] += coords[nDim*i+d] * bf[i];
    }


    ofstream myfile;
    myfile.open("cubatureImm2."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    // myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
    // myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
    myfile << std::setprecision(16) << std::setprecision(16) << x[0] << " " << x[1] << " " << " " << n[0] << " " << n[1] << " " << t[0] << " " << t[1] << endl;
    myfile.close();

    // =====================  Fill linear system ===================== //
    double gD = x[0]*x[1];

    tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);

    // Nitsche symmetric
    if (true)
    {
        for (int i = 0; i < eNN; i++)
        {
            double dbfnI{};
            for (int d = 0; d < pDim; d++)
                dbfnI += dbf[pDim*i+d]*n[d];
            
            // Bk(i,0) += jac * beta * bf[i]* gD;
            // Bk(i,0) += jac * gD * dbfnI;
            // Bk(i,1) += jac * beta * bf[i]* gD;
            // Bk(i,1) += jac * gD * dbfnI;
            // fillStr.Bk(0)[i*DOF*eNN] += jac * gD * gD;

            for (int j = 0; j < eNN; j++)
            {
                double dbfnJ{};
                for (int d = 0; d < pDim; d++)
                    dbfnJ += dbf[pDim*j+d]*n[d];

                // Fill matrix
                Ak(i,0,j,0) += jac * beta * bf[i] * bf[j];
                Ak(i,0,j,0) += jac * bf[i] * dbfnJ;
                Ak(i,0,j,0) += jac * dbfnI * bf[j];

                Ak(i,0,j,1) -= jac*beta*bf[i]*bf[j];
                Ak(i,0,j,1) -= jac*dbfnI*bf[j];
                Ak(i,1,j,0) -= jac*beta*bf[j]*bf[i];
                Ak(i,1,j,0) -= jac*dbfnJ*bf[i];


                Ak(i,1,j,1) += jac * beta * bf[i] * bf[j];
                // Ak(i,1,j,1) += jac * bf[i] * dbfnJ;
                // Ak(i,1,j,1) += jac * dbfnI * bf[j];
            }
        }
    }
    // Save local length
    fillStr.addToGlobalIntegral("Length", jac);

    return;
}

void CheckSolution(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::N, ttl::index::i;

    SubFillStructure &subFill = fillStr[0];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN = subFill.eNN;

    tensor<double, 2> Dbf(eNN, pDim);
    double jac;
    GlobalBasisFunctions::gradients(Dbf, jac, subFill);

    wrapper<double, 1> dofsI(subFill.nborDOFs.data(), eNN);
    wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
    wrapper<double, 1> bf(subFill.nborBFs(), eNN);
    tensor<double, 1> x(nDim);
    x = coordsI(N, i) * bf(N);

    const double u_numeric = dofsI(N) * bf(N);
    const double u_analytial = sin(M_PI*x(0))*sinh(M_PI*x(1)) / sinh(M_PI);
    const double error = jac * abs(u_numeric-u_analytial);
    fillStr.addToGlobalIntegral("error", error);
}


void LSPre(hiperlife::FillStructure& fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using hiperlife::Tensor::tensor;
    using namespace hiperlife::Tensor;

    SubFillStructure& subFill = fillStr["preDhand"];

    int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
    int numAuxF  = subFill.numAuxF;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    ttl::wrapper<double,2> nborAuxF(subFill.nborAuxF.data(), eNN, numAuxF);

    std::vector<double> b0 = {-1};
    std::vector<std::vector<double>>& pbf0 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b0, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf1 ={pbf0[0][0],pbf0[0][1],pbf0[0][2],pbf0[0][3]}; 
    std::vector<double> b1 = {1};
    std::vector<std::vector<double>>& pbf1 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b1, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

    std::vector<double> bf2 ={pbf1[0][0],pbf1[0][1],pbf1[0][2],pbf1[0][3]}; 

    // Get output
    tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
    tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    Bk(1,0) = nborAuxF(1,0);
    Bk(1,1) = nborAuxF(1,1);
    Bk(2,0) = nborAuxF(2,0);
    Bk(2,1) = nborAuxF(2,1);
    for (int a = 0; a<eNN; a++)
    {
        Ak(a,0,1,0) = bf1[a];
        Ak(a,1,1,1) = bf1[a];

        Ak(a,0,2,0) = bf2[a];
        Ak(a,1,2,1) = bf2[a];
    }
}


void genCircBspline(double r, std::vector<double> &U,std::vector<std::vector<std::vector<std::vector<double>>>> &CP, double xOff, double yOff, ElemType eTypeB,BasisFuncType bTypeB,int bfOrderB,int nPtsCircOr,SmartPtr<ParamStructure> paramStr)
{
  // Compute immersed mesh CPs position
  SmartPtr<StructMeshGenerator> preBSMesh = Create<StructMeshGenerator>();

  preBSMesh->setMesh(eTypeB, bTypeB, bfOrderB);
  
  std::vector<double> preU(nPtsCircOr+1,0);
  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    preU[i] = preU[i-1]+1;
  }
  
  std::vector<std::vector<std::vector<std::vector<double>>>> preCP(nPtsCircOr, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
  for (int k = 0;  k < nPtsCircOr; k++)
  {
    double t = 2*M_PI*k/nPtsCircOr;
    preCP[k][0][0] = {std::cos(t),std::sin(t),0,0};
  }
  
  preBSMesh->genBsplinesClosedCurve(preU,preCP);
  // Distributed mesh
  SmartPtr<DistributedMesh> preDisBSMesh = Create<DistributedMesh>("preDisBSMesh");
  preDisBSMesh->setMesh(preBSMesh);
  preDisBSMesh->setBalanceMesh(true);
  preDisBSMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
  preDisBSMesh->setVerbosity(Verbosity::None);
  preDisBSMesh->Update();
  
  // Set Degree of Freedom handler
  SmartPtr<DOFsHandler> preDhand = Create<DOFsHandler>(preDisBSMesh);
  preDhand->setNameTag("preDhand");
  preDhand->setNumDOFs(2);
  preDhand->setDOFs({"pcx","pcy"});
  preDhand->setNodeAuxF({"x","y","dxdt","dydt"});
  preDhand->Update();


  std::vector<double> cw = {1};
  for (int i = 0; i<preDisBSMesh->nPts();i++)
  {
    double t = 2.*M_PI*double(i)/double(nPtsCircOr);
    double x = xOff;
    double y = yOff;
    for (int iw = 0; iw<cw.size(); iw++)
    {
      x += cw[iw]*cos((iw+1)*t)*r;
      y += cw[iw]*sin((iw+1)*t)*r;
    }
    preDhand->nodeAuxF->setValue(0,i,IndexType::Global,x);
    preDhand->nodeAuxF->setValue(1,i,IndexType::Global,y);
  }

  SmartPtr<HiPerProblem> preHiperProbl = Create<HiPerProblem>();
  preHiperProbl->setParameterStructure(paramStr);
  preHiperProbl->setDOFsHandlers({preDhand});
  
  // Interface integration
  preHiperProbl->setIntegration("IntegPre", {"preDhand"});
  preHiperProbl->setCubatureGauss("IntegPre", 1);
  preHiperProbl->setElementFillings("IntegPre", LSPre);

  preHiperProbl->Update();

  SmartPtr<MUMPSDirectLinearSolver> preSolver = Create<MUMPSDirectLinearSolver>();
  preSolver->setHiPerProblem(preHiperProbl);
  preSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
  preSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
  preSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Sequential);
  preSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
  preSolver->setConvergenceCriteria(MUMPSDirectLinearSolver::ConvergenceCriteria::Relative);
  preSolver->setTolerance(1e-8);
  preSolver->setDefaultParameters();
  preSolver->Update();

  // Solve
  preSolver->solve();
  preHiperProbl->UpdateGhosts();

  // Update Solution
  preSolver->UpdateSolution();

  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    U[i] = U[i-1]+1.;
  }

  for (int k = 0;  k < nPtsCircOr; k++)
  {  
    double x = preDhand->nodeDOFs->getValue(0,k,IndexType::Global);
    double y = preDhand->nodeDOFs->getValue(1,k,IndexType::Global);
    CP[k][0][0] = {x,y,0,0};
  }
}


int main(int argc, char** argv)
{

    hiperlife::Init(argc, argv);

    //============================ Parameters ============================//
    int nx = 50;
    int ny = 50;
    // cout << "Type number of elements per side: " << endl;
    // cin >> nx;
    SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();
    // userStr->dparam.resize(1);
    double beta = 8*100*nx; // beta = 100*h (from 2017Badia)
    paramStr->setRealParameter(PoissonParams::beta,beta);



    // *******************************************************************//
    // *****                      MESH CREATION                      *****//
    // *******************************************************************//
    int nSteps = 20;
    int bfOrder = 2;
    int timeStep = 0;
    for (int nS{}; nS < nSteps; nS++)
    {
        timeStep++;
        paramStr->setIntParameter(PoissonParams::timeStep,timeStep);
        //-------------------------- Background mesh -------------------------//

        // Mesh generator
        SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
        back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
        back->genStructMesh(nx, ny);
        // Mesh refinement
        double c0 = 0.5;
        double r0 = 0.3;
        double eps = 0.0001;
        vector<int> phmodes = {5};
        
        int refmax = 3;
        int nEside = 60;
        double theta = (double)nS/(double)nSteps*2*M_PI+0.5;

        double xC1 = 0.8; double yC1 = 0.2; double xC2 = 0.2; double yC2 = 0.8; 
        if (nS < nSteps/2)
        {
            yC1 += (double)nS/(double)nSteps*0.6*2.;
            yC2 -= (double)nS/(double)nSteps*0.6*2.;
        }
        else
        {
            yC1 = 0.8;
            yC2 = 0.2;
            xC1 -= (double)(nS-nSteps/2)/(double)nSteps*0.6*2.;
            xC2 += (double)(nS-nSteps/2)/(double)nSteps*0.6*2.;
        }

        SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();

        ElemType eTypeB = ElemType::Line; // Element type
        int bfOrderB = 3;   // Basis function order
        BasisFuncType bTypeB = BasisFuncType::BSplines; // Basis function type
        double r = 0.11; // Radius of immersed mesh
        int nPtsCirc = 30; // Number of control points
        std::vector<std::vector<std::vector<std::vector<double>>>> CP(nPtsCirc, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
        std::vector<double> U(nPtsCirc+1,0);

        imm->setMesh(eTypeB, bTypeB, bfOrderB);
        genCircBspline(r,U,CP,xC1,yC1,eTypeB,bTypeB,bfOrderB,nPtsCirc,paramStr);
        imm->genBsplinesClosedCurve(U,CP);

    
        SmartPtr<DistributedMesh> immProva = Create<DistributedMesh>("immMeshProva");
        immProva->setMesh(imm);
        immProva->setBalanceMesh(true);
        immProva->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        immProva->setVerbosity(Verbosity::None);
        immProva->Update();

        // Distributed mesh
        SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
        backMesh->setMesh(back);
        backMesh->setBalanceMesh(true);
        backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        backMesh->setVerbosity(Verbosity::None);
        backMesh->Update();


        //--------------------------- Immersed mesh --------------------------//

        // Distributed mesh
        SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
        immMesh->setMesh(imm);
        immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
        immMesh->setImmersedInteriorPoints({{{xC1, yC1, 0.0}},{{0.01,0.01,0}}});
        immMesh->setRegionTags({"Interior","Exterior"});
        immMesh->setBalanceMesh(true);
        immMesh->setIllPosThreshold(0.5);
        immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
        immMesh->setVerbosity(Verbosity::None);
        immMesh->Update();

        // Print meshes
        backMesh->printFileLegacyVtk("meshBack");
        immMesh->printFileLegacyVtk("meshImm");


        // *******************************************************************//
        // *****                   DOFsHandler CREATION                  *****//
        // *******************************************************************//

        //----------------------- Background DOFsHandler ---------------------//
        SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
        backDHand->setNameTag("backDHand");
        backDHand->setDOFs({"u1","u2"});
        backDHand->setNodeAuxF({"const","ctag","stab"});
        backDHand->setElemAuxF({"tag","WI"});
        backDHand->setDofTags({"Interior","Exterior"});
        backDHand->Update();

        //----------------------- Immersed DOFsHandler ---------------------//
        SmartPtr<DOFsHandler> immDHand = Create<DOFsHandler>(immMesh);
        immDHand->setNameTag("immDHand");
        immDHand->setDOFs({"uB"});
        immDHand->Update();

        // Save interior/cut/exterior flags for plotting
        for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
        {
            int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
            backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
            vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
            vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
            for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
            {
                if (backDHand->mesh->isNodeInPart(nbors[n]))
                    backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
            }
        }
        backDHand->UpdateGhosts();

        // Set boundary conditions
        backDHand->setBoundaryCondition("u2", MAxis::Xmin, 1.0);
        backDHand->setBoundaryCondition("u2", MAxis::Xmax, [](double y){return y*y;});
        // backDHand->setBoundaryCondition("u2", MAxis::Xmax, [](double y){return 0.0*y;});
        backDHand->UpdateGhosts();

        backDHand->printFileLegacyVtk("dofBack", true);

        immDHand->setConstraint("uB",0);
        // hiperlife::Finalize();
        // return 0;

        // *******************************************************************//
        // *****                    IMMERSED PROBLEM                     *****//
        // *******************************************************************//
        if (true)
        {
            // Immersed HiPerProblem
            SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
            //General setters
            immHP->setParameterStructure(paramStr);
            immHP->setGlobalIntegrals({"Area","Length","Error"});
            immHP->setDOFsHandlers({backDHand,immDHand});

            // Set integration for the border
            immHP->setIntegration("IntegBorder", {"backDHand","immDHand"});
            immHP->setCubatureBorderImmersed("IntegBorder", 3);
            immHP->setElementFillings("IntegBorder", LS_backBorder);

            // Set integration for the background mesh
            immHP->setIntegration("Integ1", {"backDHand"});
            // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
            immHP->setCubatureCutCellConforming("Integ1", 9, 2,"Interior");
            immHP->setElementFillings("Integ1", LS_backBulk1);

            // Set integration for the background mesh
            immHP->setIntegration("Integ2", {"backDHand"});
            // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
            immHP->setCubatureCutCellConforming("Integ2", 9, 2,"Exterior");
            immHP->setElementFillings("Integ2", LS_backBulk2);

            immHP->Update();

            // hiperlife::Finalize();
            // return 0;

            //-------------------------- Immersed solver -------------------------//
            SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
            immSOL->setHiPerProblem(immHP);
            immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
            immSOL->setDefaultParameters();
            immSOL->Update();
            //---------------------------- Solve immersed ------------------------//
            // Solve
            // immHP->FillLinearSystem();
            immSOL->solve();
            immSOL->UpdateSolution();
            string meshName = to_string(nS);
            if(false) // Print matrix and rhs
            {
                string LHSName = "LHS." + meshName +".mm";
                string SolName = "Sol." + meshName +".mm";
                string RHSName = "RHS." + meshName +".mm";
                const char *CLHSName = LHSName.c_str();
                const char *CSolName = SolName.c_str();
                const char *CRHSName = RHSName.c_str();
                EpetraExt::RowMatrixToMatrixMarketFile(CLHSName, *immHP->A, "LHS", "Left hand side matrix");
                EpetraExt::MultiVectorToMatrixMarketFile(CSolName, *immHP->sol, "Sol", "Solution vector");
                EpetraExt::MultiVectorToMatrixMarketFile(CRHSName, *immHP->rhs, "RHS", "Right hand side vector");

                ofstream CoordsFile;
                CoordsFile.open ("Coords." + meshName +".csv");
                for (int d = 0; d < backMesh->loc_nPts(); d++)
                {
                    // Get node coordinates
                    std::vector<double> x = backMesh->nodeCoords(d, IndexType::Local);
                    CoordsFile << x[0] << "," << x[1] << endl;
                }
                for (int d = 0; d < immMesh->loc_nPts(); d++)
                {
                    // Get node coordinates
                    std::vector<double> x = immMesh->nodeCoords(d, IndexType::Local);
                    CoordsFile << x[0] << "," << x[1] << endl;
                }
                CoordsFile.close(); 
            }

            
            // Print
            string solName = "solBack."+to_string(nS);
            backDHand->printFileLegacyVtk(solName, true);
            string immMshName = "meshImm."+to_string(nS);
            immMesh->printFileLegacyVtk(immMshName);

            double L = immHP->globalIntegral("Length");
            double A = immHP->globalIntegral("Area");
            cout <<"Theta: " <<theta<< "Area: " << A << " Lenght: " << L << endl;

        }
    }

    hiperlife::Finalize();
    return 0;
}