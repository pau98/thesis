/// C++ headers
#include <iostream>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_Parser.h"

using namespace hiperlife;

void ElementFilling(hiperlife::FillStructure& fillStr);

struct TestParams
{
    enum IntParameters
    {
        mode,
    };

    enum RealParameters
    {
        h,
    };

    enum StringParameters
    {
        name,
    };
};


SmartPtr<MeshCreator> GenerateMeshCreator(ParamStructure& params)
{
    SmartPtr<UnstructVtkMeshGenerator> meshCreator = Create<UnstructVtkMeshGenerator>();;
    int mode = params.getIntParameter(TestParams::mode);

    if(mode == 0) {
        double h = 0.01;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "sphere");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genSphere([h](double x[3]){ return h;});
    }
    else if(mode == 1) {
        double h = 0.001;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "sphere");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genSphere([h](double x[3]){ return h;});
    }
    else if(mode == 2) {
        double h = 0.01;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "def. sphere");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genSphere([h](double x[3]){ return h;}, [](double x[3]){
            const double fz = 2-x[2]*x[2];
            return std::array<double,3>({fz*x[0], fz*x[1], x[2]});
        });
    }
    else if(mode == 3) {
        double h = 0.001;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "def. sphere");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genSphere([h](double x[3]){ return h;}, [](double x[3]){
            const double fz = 2-x[2]*x[2];
            return std::array<double,3>({fz*x[0], fz*x[1], x[2]});
        });
    }
    else if(mode == 4) {
        double h = 0.02;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "cylinder");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genCylinder(1.0, 3.0, false, [h](double x[3]){ return h;});
    }
    else if(mode == 5) {
        double h = 0.005;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "cylinder");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genCylinder(1.0, 3.0, false, [h](double x[3]){ return h;});
    }
    else if(mode == 6) {
        double h = 0.02;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "def. cylinder");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genCylinder(1.0, 3.0, false, [h](double x[3]){ return h;},
            [](double x[3]) {
                const double fz = 2+0.5*x[2]*x[2];
                return std::array<double, 3>({fz * x[0], fz*x[1], x[2]});
            }
        );
    }
    else if(mode == 7) {
        double h = 0.005;
        params.setRealParameter(TestParams::h, h);
        params.setStringParameter(TestParams::name, "def. cylinder");

        meshCreator->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        meshCreator->genCylinder(1.0, 3.0, false, [h](double x[3]){ return h;},
                                 [](double x[3]) {
                                     const double fz = 2+0.5*x[2]*x[2];
                                     return std::array<double, 3>({fz * x[0], fz*x[1], x[2]});
                                 }
        );
    }


    return meshCreator;
}

int TestVtkMeshGen(int mode = 0, bool output_debug = false)
{
    SmartPtr<ParamStructure> params = CreateParamStructure<TestParams>();
    params->setIntParameter(TestParams::mode, mode);

    SmartPtr<MeshCreator> mesh = GenerateMeshCreator(*params.get());

    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(mesh);
    disMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    disMesh->setBalanceMesh(false);
    disMesh->Update();

    if(output_debug)
        disMesh->printFileLegacyVtk("disMesh_" + to_string(mode) +".vtk");

    SmartPtr<DOFsHandler> field = Create<DOFsHandler>(disMesh);
    field->setNameTag("field");
    field->setNumDOFs(3);
    field->Update();

    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();
    hiperProbl->setDOFsHandlers({field});
    hiperProbl->setIntegration("Integ", {"field"});
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->setElementFillings("Integ", ElementFilling);
    hiperProbl->setGlobalIntegrals({"errorCoords", "estimatedH", "area"});
    hiperProbl->setParameterStructure(params);
    hiperProbl->Update();

    hiperProbl->FillLinearSystem();

    const double errorCoords = hiperProbl->globalIntegral("errorCoords")/hiperProbl->globalIntegral("area");
    const double estimatedH = hiperProbl->globalIntegral("estimatedH")/hiperProbl->globalIntegral("area");
    const double ratioH = estimatedH / params->getRealParameter(TestParams::h);
    bool success = ratioH > 0.5 and ratioH < 2.0 and errorCoords < 1e-1;

    if(VerboseRank())
    {
        std::cout << "Testing vtk mesh generator for " << params->getStringParameter(TestParams::name);
        std::cout << " and h: " << params->getRealParameter(TestParams::h) << std::endl;
        std::cout << "   Ratio in H: " << ratioH << " Estimated h: " << estimatedH << " nElems: " << disMesh->nElem() << " Area/nElem: " << hiperProbl->globalIntegral("area") / disMesh->nElem() <<  "  ErrorCoords = " << errorCoords << std::endl;
        if (success) {
            std::cout << "   ** Test passed **" << std::endl;
        }
        else {
            std::cout << "   ** Test failed **" << std::endl;
        }
    }

    return int(success);
}

int main(int argc, char **argv)
{
    hiperlife::Init(argc, argv);

    for (int i = 0; i < 8; i++) {
        bool success = TestVtkMeshGen(i, false);
        if (!success)
            return 1;
    }

    hiperlife::Finalize();
    return 0;
}


void ElementFilling(FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::I, ttl::index::a, ttl::index::b, ttl::index::α;

    SubFillStructure& subFill = fillStr[0];

    wrapper<double, 1> bf(subFill.nborBFs(), subFill.eNN);
    wrapper<double, 2> Dbf(subFill.nborBFsGrads(), subFill.eNN, subFill.pDim);
    wrapper<double, 2> nborCoords(subFill.nborCoords.data(), subFill.eNN, subFill.nDim);

    tensor<double, 2> Dx  = Dbf(I,a) * nborCoords(I,α);
    tensor<double,2> metric = Dx(a,α) * Dx(b,α);
    double jac = sqrt(metric.det());

    double error{};

    int mode = fillStr.getIntParameter(TestParams::mode);
    if (mode == 0 or mode == 1) {
        for (int i = 0; i < subFill.eNN; i++)
            error += abs(nborCoords(i, a)*nborCoords(i, a)-1.0);
    }
    else if (mode == 2 or mode == 3) {
        for (int i = 0; i < subFill.eNN; i++) {
            const double r2 = nborCoords(i, a)*nborCoords(i, a);
            const double z2 = nborCoords(i, 2)*nborCoords(i, 2);
            const double th2 = (2.0-z2)*(2.0-z2)*(1-z2)+z2;
            error += abs(r2-th2);
        }
    }
    else if (mode == 4 or mode == 5) {
        for (int i = 0; i < subFill.eNN; i++)
            error += abs(nborCoords(i, ttl::range(0,1))*nborCoords(i, ttl::range(0,1))-1.0);
    }
    else if (mode == 6 or mode == 7) {
        for (int i = 0; i < subFill.eNN; i++) {
            const double r2 = nborCoords(i, ttl::range(0,1))*nborCoords(i, ttl::range(0,1));
            const double z2 = nborCoords(i, 2)*nborCoords(i, 2);
            const double th = 2.0+0.5*z2;
            error += abs(r2-th*th);
        }
    }

    ///===================== Values at int. points ====================///
    fillStr.addToGlobalIntegral("errorCoords", jac*error);

    double area = SGeometry::AreaTriangle3D(nborCoords(0, ttl::all).data(), nborCoords(1, ttl::all).data(), nborCoords(2, ttl::all).data());

    fillStr.addToGlobalIntegral("area", jac);
    fillStr.addToGlobalIntegral("estimatedH", jac*area);
}
