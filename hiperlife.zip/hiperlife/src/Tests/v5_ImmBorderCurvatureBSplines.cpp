// C++ headers
#include <cmath>
#include <iomanip>
#include <iostream>
#include <mpi.h>
#include <vector>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_Core.h"
#include "hl_DOFsHandler.h"
#include "hl_DistributedMesh.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_HiPerProblem.h"
#include "hl_StructMeshGenerator.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;
using namespace std;

// ---------------------------------------------------------------------
// Regression check: adding the _immElemID/_immLocalParam caches
// alongside _immTangents (in Integration::_genCubaSetBorderImmersed)
// must not perturb the pre-existing tangent-based border integration.
// Same scenario as testLength_immersedBoundary in
// v5_BorderImmersedIntegration.cpp: a square of side 0.5, rotated by
// theta, immersed (Lagrangian) in a background mesh. Its perimeter
// (integrated purely from _immTangents, exactly as production fill
// functions do) must still come out to exactly 2.0.
// ---------------------------------------------------------------------
void LS_length(hiperlife::FillStructure& fillStr)
{
    SubFillStructure& subFill = fillStr[0];
    int nDim = subFill.nDim;

    vector<double> dbf(subFill.eNN * subFill.pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim * subFill.kPt + n];
    jac = Math::Norm3D(t.data());

    fillStr.addToGlobalIntegral("Length", jac);
}

int testTangentsUnaffected(int nEx, int nEy, int nEside, double theta)
{
    // Background mesh
    RCP<StructMeshGenerator> back = rcp(new StructMeshGenerator);
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    back->genStructMesh(nEx, nEy);

    RCP<DistributedMesh> backMesh = rcp(new DistributedMesh);
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->Update();

    // Immersed mesh: rotated square, side 0.5 (perimeter 2.0)
    RCP<StructMeshGenerator> imm = rcp(new StructMeshGenerator);
    imm->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    imm->genSquareLine(nEside, 0.5);
    imm->translateXY(-0.25, -0.25);
    imm->rotate2D(theta);
    imm->translateXY(0.5, 0.5);

    RCP<DistributedMesh> immMesh = rcp(new DistributedMesh);
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setImmersedInteriorPoints({{{0.01, 0.01, 0.0}}});
    immMesh->setBalanceMesh(true);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->Update();

    RCP<DOFsHandler> backDHand = rcp(new DOFsHandler(backMesh));
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"u"});
    backDHand->Update();

    // No actual linear solve happens below (only FillLinearSystem(), to
    // accumulate the "Length" global integral), so "u" never needs to be
    // constrained.

    RCP<HiPerProblem> immHP = rcp(new HiPerProblem);
    immHP->setDOFsHandlers({backDHand});
    immHP->setGlobalIntegrals({"Length"});
    immHP->setIntegration("IntegBorder", {"backDHand"});
    immHP->setCubatureBorderImmersed("IntegBorder", 3);
    immHP->setElementFillings("IntegBorder", LS_length);
    immHP->Update();

    if (VerboseRank())
    {
        int totalPts = 0;
        for (int e = 0; e < backMesh->loc_nElem(); e++)
            totalPts += immMesh->_immTangents[e].size() / 3;
        cout << "  [debug] total border integration points = " << totalPts
             << " (immersed elements = " << immMesh->loc_nElem() << ")" << endl;
    }

    immHP->FillLinearSystem();
    double L = immHP->globalIntegral("Length");
    if (VerboseRank())
        cout << "  [debug] L = " << setprecision(16) << L << endl;

    if (abs(2.0 - L) > 1e-12)
        return 1;
    return 0;
}

// ---------------------------------------------------------------------
// New capability: for a BSplines immersed border curve, _immElemID and
// _immLocalParam give, for every border integration point, the
// (immersed element, local parametric coordinate) pair that produced
// it. At each such point we check:
//
//   (a) Position consistency: re-evaluating the immersed mesh's own
//       0th-order basis functions at the cached (iElem, t) must
//       reconstruct the SAME physical point as the border integration
//       point (reconstructed independently from the background
//       mesh's shape functions). This is the core correctness
//       requirement for the new cache -- it must point at the right
//       spot, not just some point on the curve.
//
//   (b) Curvature self-consistency: the curvature computed from the
//       immersed mesh's analytic 2nd derivatives (basis function
//       Hessians) at (iElem, t) must agree with an independent
//       finite-difference estimate built only from 0th-order basis
//       functions evaluated at t +/- h.
//
//   (c) Physical sanity: the average curvature over the whole curve
//       must be close to 1/R, since the immersed curve is a closed
//       cubic BSpline whose control points lie on a circle of radius
//       R (an approximation of a circle, not an exact one, hence the
//       loose tolerance).
// ---------------------------------------------------------------------
void LS_curvature(hiperlife::FillStructure& fillStr)
{
    SubFillStructure& subFill = fillStr[0];

    // Physical position of this border integration point, reconstructed
    // from the BACKGROUND mesh's own shape functions (independent of
    // anything immersed-mesh related).
    int eNN = subFill.eNN;
    int nDim = subFill.nDim;
    double* bf = subFill.nborBFs();
    double xg = 0., yg = 0.;
    for (int n = 0; n < eNN; n++)
    {
        xg += bf[n] * subFill.nborCoords[nDim * n + 0];
        yg += bf[n] * subFill.nborCoords[nDim * n + 1];
    }

    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    int iElem = immMesh->_immElemID[subFill.loc_elemID][subFill.kPt];
    double t = immMesh->_immLocalParam[subFill.loc_elemID][subFill.kPt];

    const int numNbors = 4; // cubic BSpline Line element
    vector<double> cx(numNbors), cy(numNbors);
    for (int n = 0; n < numNbors; n++)
    {
        int nbor = immMesh->_connec->getNbor(iElem, n);
        vector<double> c = immMesh->nodeCoords(nbor);
        cx[n] = c[0];
        cy[n] = c[1];
    }

    auto evalPos = [&](double tt, double& x, double& y)
    {
        vector<double> tv = {tt};
        vector<vector<double>>& lbf = immMesh->_basisFunctions->computeBasisFunctionsReference(
            tv, immMesh->_basisFunctions->getTag(iElem, IndexType::Local));
        x = 0.;
        y = 0.;
        for (int n = 0; n < numNbors; n++)
        {
            x += lbf[0][n] * cx[n];
            y += lbf[0][n] * cy[n];
        }
    };

    vector<double> tv = {t};
    vector<vector<double>>& bfc = immMesh->_basisFunctions->computeBasisFunctionsReference(
        tv, immMesh->_basisFunctions->getTag(iElem, IndexType::Local));

    double x0 = 0., y0 = 0., dx = 0., dy = 0., ddx = 0., ddy = 0.;
    for (int n = 0; n < numNbors; n++)
    {
        x0 += bfc[0][n] * cx[n];
        y0 += bfc[0][n] * cy[n];
        dx += bfc[1][n] * cx[n];
        dy += bfc[1][n] * cy[n];
        ddx += bfc[2][n] * cx[n];
        ddy += bfc[2][n] * cy[n];
    }

    double kappaAnalytic = fabs(dx * ddy - dy * ddx) / pow(dx * dx + dy * dy, 1.5);

    double h = 1e-4;
    double xp, yp, xm, ym;
    evalPos(t + h, xp, yp);
    evalPos(t - h, xm, ym);
    double dxFD = (xp - xm) / (2. * h);
    double dyFD = (yp - ym) / (2. * h);
    double ddxFD = (xp - 2. * x0 + xm) / (h * h);
    double ddyFD = (yp - 2. * y0 + ym) / (h * h);
    double kappaFD = fabs(dxFD * ddyFD - dyFD * ddxFD) / pow(dxFD * dxFD + dyFD * dyFD, 1.5);

    double posErr2 = (x0 - xg) * (x0 - xg) + (y0 - yg) * (y0 - yg);
    double kappaErr2 = (kappaAnalytic - kappaFD) * (kappaAnalytic - kappaFD);

    fillStr.addToGlobalIntegral("PosErr2", posErr2);
    fillStr.addToGlobalIntegral("KappaErr2", kappaErr2);
    fillStr.addToGlobalIntegral("Kappa", kappaAnalytic);
    fillStr.addToGlobalIntegral("Weight", 1.0);
}

int testCurvature_BSplinesCircle(int nEx, int nEside, double R)
{
    // Background mesh, covers [0,1]x[0,1]
    RCP<StructMeshGenerator> back = rcp(new StructMeshGenerator);
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    back->genStructMesh(nEx, nEx);

    RCP<DistributedMesh> backMesh = rcp(new DistributedMesh);
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->Update();

    // Immersed mesh: closed cubic BSpline curve whose control points lie
    // directly on a circle of radius R, centered at (0.5, 0.5) -- an
    // approximate (but, as nEside grows, converging) BSpline circle,
    // built without any fitting/solve step.
    RCP<StructMeshGenerator> imm = rcp(new StructMeshGenerator);
    int bfOrder = 3;
    imm->setMesh(ElemType::Line, BasisFuncType::BSplines, bfOrder);

    vector<double> U(nEside + 1, 0.);
    for (int i = 1; i < nEside + 1; i++)
        U[i] = U[i - 1] + 1.;

    vector<vector<vector<vector<double>>>> CP(
        nEside, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
    for (int k = 0; k < nEside; k++)
    {
        double th = 2. * M_PI * k / nEside;
        CP[k][0][0] = {0.5 + R * cos(th), 0.5 + R * sin(th), 0., 0.};
    }
    imm->genBsplinesClosedCurve(U, CP);

    RCP<DistributedMesh> immMesh = rcp(new DistributedMesh);
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setRegionTags({"Interior", "Exterior"});
    immMesh->setImmersedInteriorPoints({{{0.5, 0.5, 0.0}}, {{0.01, 0.01, 0.0}}});
    immMesh->setBalanceMesh(true);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->Update();

    RCP<DOFsHandler> backDHand = rcp(new DOFsHandler(backMesh));
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"u"});
    backDHand->setDofTags({"Interior"});
    backDHand->Update();

    RCP<HiPerProblem> hp = rcp(new HiPerProblem);
    hp->setDOFsHandlers({backDHand});
    hp->setGlobalIntegrals({"PosErr2", "KappaErr2", "Kappa", "Weight"});
    hp->setIntegration("IntegBorder", {"backDHand"});
    hp->setCubatureBorderImmersed("IntegBorder", 5);
    hp->setElementFillings("IntegBorder", LS_curvature);
    hp->Update();

    hp->FillLinearSystem();

    double posErr2 = hp->globalIntegral("PosErr2");
    double kappaErr2 = hp->globalIntegral("KappaErr2");
    double weight = hp->globalIntegral("Weight");
    double kappaAvg = hp->globalIntegral("Kappa") / weight;

    bool ok = true;

    if (sqrt(posErr2 / weight) > 1e-8)
    {
        if (VerboseRank())
            cout << "  [FAIL] Position mismatch (RMS): " << sqrt(posErr2 / weight) << endl;
        ok = false;
    }

    if (sqrt(kappaErr2 / weight) > 1e-4 * (1. / R))
    {
        if (VerboseRank())
            cout << "  [FAIL] Curvature self-consistency error (RMS): " << sqrt(kappaErr2 / weight)
                 << " vs tolerance " << 1e-4 * (1. / R) << endl;
        ok = false;
    }

    if (fabs(kappaAvg - 1. / R) > 0.05 * (1. / R))
    {
        if (VerboseRank())
            cout << "  [FAIL] Average curvature " << kappaAvg << " vs analytic 1/R = " << 1. / R << endl;
        ok = false;
    }

    return ok ? 0 : 1;
}

int main(int argc, char** argv)
{
    hiperlife::Init(argc, argv);

    int err = 0;

    // Regression: border length via _immTangents must be unaffected by
    // the new _immElemID/_immLocalParam caches.
    for (int e = 16; e < 19 && err == 0; e++)
    {
        for (int eS = 8; eS < 11 && err == 0; eS++)
        {
            if (VerboseRank())
                cout << "Testing _immTangents regression (background " << e << "x" << e
                     << ", immersed square with " << eS << " segments/side)... ";
            err = testTangentsUnaffected(e, e, eS, 0.3);
            if (VerboseRank())
                cout << (err == 0 ? "OK" : "FAILED") << endl;
        }
    }

    // New capability: _immElemID/_immLocalParam give a correct, usable
    // handle on the BSplines immersed curve's own geometry/curvature.
    if (err == 0)
    {
        if (VerboseRank())
            cout << "Testing BSplines border curvature cache... " << endl;
        err = testCurvature_BSplinesCircle(24, 24, 0.3);
        if (VerboseRank())
            cout << (err == 0 ? "OK" : "FAILED") << endl;
    }

    if (err == 0 && VerboseRank())
        cout << "** All tests passed **" << endl;

    hiperlife::Finalize();
    return err;
}
