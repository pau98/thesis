/*
    **************************************************************************************************
    hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Copyright (c) 2018 Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
    **************************************************************************************************
    hiperlife is under GNU General Public License ("GPL").
    GNU General Public License ("GPL") copyright permissions statement:
    This file is part of hiperlife, hiperlife is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by the Free Software Foundation,
    either version 3 of the License, or (at your option) any later version.
    hiperlife is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along with this program.
    If not, see <http://www.gnu.org/licenses/>.
    **************************************************************************************************
*/


/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_Tensor.h"


#include "hl_LinearSolver_Iterative_Belos.h"
// #include <Ifpack.h>
// #include <Ifpack_Preconditioner.h>

// #include <BelosConfigDefs.hpp>
// #include <BelosLinearProblem.hpp>
// #include <BelosEpetraAdapter.hpp>
// #include <BelosBlockGmresSolMgr.hpp>


#include "BelosConfigDefs.hpp"
#include "BelosLinearProblem.hpp"
#include "BelosEpetraAdapter.hpp"
#include "BelosBlockGmresSolMgr.hpp"

#include "Ifpack.h"

#include "Teuchos_CommandLineProcessor.hpp"
#include "Teuchos_ParameterList.hpp"
#include "Teuchos_StandardCatchMacros.hpp"

void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    //
    // First, we get the model parameters from the UserStructure
    double force = fillStr->userStr->dparam[0];
    //
    // Then, we get the SubFillStructure for the dofHand from our
    //   fillStr as follows
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    // which we use to declare the variables:
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension

    //Coordinates of the nodes in the element. We store this data
    //in a hiperlife tensor of order 2, i.e. a matrix. It has eNN
    //rows and nDim columns.
    tensor<double,2,false> nborCoords(subFill.nborCoords.data(),eNN,nDim);

    //Basis functions and their local derivatives evaluated at the
    // Gauss point. The basis functions are a vector (tensor of or
    // der 1) of size eNN. The first-order derivatives are a matrix
    //of size eNN*pDim.
    tensor<double,1,false>  bf  (subFill.nborBFsDers(0),eNN);
    tensor<double,2,false> Dbf_l(subFill.nborBFsDers(1),eNN,pDim);

    //To make the calculations, we transform the local basis functions
    //(more precisely, their derivatives) from local coordinates to car
    //tesian (global) coordinates. The derivatives of the basis functions
    //in global coordinates are also a matrix of size eNN*pDim
    tensor<double,2> Dbf_g(eNN,pDim);
    double jac; //Jacobian (differential of line/area/volume)
    //To calculate the global basis functions and the jacobian we call the
    //function gradients from the namespace GlobalBasisFunctions
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

    //We are going to fill the matrix and the right hand side. Here, we define
    //the matrix Ak (eNN*eNN) and the vector Bk (eNN).
    tensor<double,2,false> Ak(fillStr->Ak(0, 0).data(),eNN,eNN);
    tensor<double,1,false> Bk(fillStr->Bk(0).data(),eNN);

    //=====================  Fill linear system =====================//
    //
    // We loop through the neighboring nodes to fill both the matrix
    //   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            // Compute the product of the gradient of the basis functions
            double dotij{};
            for (int d = 0; d < pDim; d++)
                dotij += Dbf_g(i,d)*Dbf_g(j,d);

            // Fill matrix
            Ak(i,j) += jac * dotij;
        }

        // Fill RHS
        Bk(i) += jac * bf(i) * force;
    }

}


int main()
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;


    //=========== Initialize the MPI execution environment ==========//
    MPI_Init(nullptr, nullptr);


    //=============== Define parameters of the model ===============//
    double force = 0.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    //====================== Mesh generation ======================//
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setNDim(3);
    structMesh->setBasisFuncType(BasisFuncType::Lagrangian);
    structMesh->setBasisFuncOrder(1);
    structMesh->setElemType(ElemType::Square);
    structMesh->genRectangle(80, 40, 1.0, 0.5);
    structMesh->translateY(0.5);

    //===========             Distribute mesh            ===========//
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    //===========           Create DOFHandler            ===========//
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    //===========          Boundary conditions          ===========//
    dofHand->setBoundaryCondition(0, 0.0);
    dofHand->setBoundaryCondition(0, MAxis::Xmax, 1.0);
    dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x){return x;});
    dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});
    dofHand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ", 4);
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->Update();


    //Solver working (hard-coded)
    if (true)
    {
        hiperProbl->FillLinearSystem();

        typedef double                ST;
        typedef Epetra_MultiVector    MV;
        typedef Epetra_Operator       OP;

        Teuchos::RCP<Epetra_LinearProblem> linearProblem = hiperProbl->linProbl;
        // Teuchos::RCP<Ifpack_Preconditioner> precond = Teuchos::null;
        // Teuchos::RCP<Belos::LinearProblem<ST, MV, OP >> problem = Teuchos::null;
        // Teuchos::RCP<Belos::SolverManager<ST, MV, OP >> solver = Teuchos::null;
        // // Teuchos::RCP<Belos::EpetraPrecOp> _belosPrec = Teuchos::null;

        auto A = Teuchos::rcpFromRef(*linearProblem->GetMatrix());
        auto X = Teuchos::rcpFromRef(*linearProblem->GetLHS());
        auto B = Teuchos::rcpFromRef(*linearProblem->GetRHS());
        // problem = Teuchos::rcp(new Belos::LinearProblem<ST, MV, OP>(A, X, B));



        bool success = true;
        bool verbose = true;
        bool proc_verbose = true;
        int frequency = -1;        // frequency of status test output.
        int blocksize = 1;         // blocksize
        int numrhs = 1;            // number of right-hand sides to solve for
        int maxrestarts = 15;      // maximum number of restarts allowed
        int maxiters = -1;         // maximum number of iterations allowed per linear system
        int maxsubspace = 25;      // maximum number of blocks the solver can use for the subspace
        double tol = 1e-8;

        //
        // ************Construct preconditioner*************
        //
        Teuchos::ParameterList ifpackList;
        // allocates an IFPACK factory. No data is associated
        // to this object (only method Create()).
        Ifpack Factory;
        // create the preconditioner. For valid PrecType values,
        // please check the documentation
        std::string PrecType = "ILU"; // incomplete LU
        int OverlapLevel = 1; // must be >= 0. If Comm.NumProc() == 1,
        // it is ignored.
        RCP<Ifpack_Preconditioner> Prec = Teuchos::rcp( Factory.Create(PrecType, &*A, OverlapLevel) );
        assert(Prec != Teuchos::null);
        // specify parameters for ILU
        ifpackList.set("fact: level-of-fill", 1);
        // the combine mode is on the following:
        // "Add", "Zero", "Insert", "InsertAdd", "Average", "AbsMax"
        // Their meaning is as defined in file Epetra_CombineMode.h
        ifpackList.set("schwarz: combine mode", "Add");
        // sets the parameters
        IFPACK_CHK_ERR(Prec->SetParameters(ifpackList));
        // initialize the preconditioner. At this point the matrix must
        // have been FillComplete()'d, but actual values are ignored.
        IFPACK_CHK_ERR(Prec->Initialize());
        // Builds the preconditioners, by looking for the values of
        // the matrix.
        IFPACK_CHK_ERR(Prec->Compute());
        // Create the Belos preconditioned operator from the Ifpack preconditioner.
        // NOTE:  This is necessary because Belos expects an operator to apply the
        //        preconditioner with Apply() NOT ApplyInverse().
        RCP<Belos::EpetraPrecOp> belosPrec = rcp( new Belos::EpetraPrecOp( Prec ) );

        //
        // *****Create parameter list for the block GMRES solver manager*****
        //
        const int NumGlobalElements = B->GlobalLength();
        if (maxiters == -1)
            maxiters = NumGlobalElements/blocksize - 1; // maximum number of iterations to run
        //
        Teuchos::ParameterList belosList;
        belosList.set( "Flexible Gmres", true );               // Flexible Gmres will be used to solve this problem
        belosList.set( "Num Blocks", maxsubspace );            // Maximum number of blocks in Krylov factorization
        belosList.set( "Block Size", blocksize );              // Blocksize to be used by iterative solver
        belosList.set( "Maximum Iterations", maxiters );       // Maximum number of iterations allowed
        belosList.set( "Maximum Restarts", maxrestarts );      // Maximum number of restarts allowed
        belosList.set( "Convergence Tolerance", tol );         // Relative convergence tolerance requested
        if (numrhs > 1) {
            belosList.set( "Show Maximum Residual Norm Only", true );  // Show only the maximum residual norm
        }
        if (verbose) {
            belosList.set( "Verbosity", Belos::Errors + Belos::Warnings +
                           Belos::TimingDetails + Belos::StatusTestDetails );
            if (frequency > 0)
                belosList.set( "Output Frequency", frequency );
        }
        else
            belosList.set( "Verbosity", Belos::Errors + Belos::Warnings );

        //
        // *******Construct a preconditioned linear problem********
        //
        RCP<Belos::LinearProblem<double,MV,OP> > problem
            = rcp( new Belos::LinearProblem<double,MV,OP>( A, X, B ) );
        problem->setRightPrec( belosPrec );
        bool set = problem->setProblem();
        if (set == false) {
            if (proc_verbose)
                std::cout << std::endl << "ERROR:  Belos::LinearProblem failed to set up correctly!" << std::endl;
            return EXIT_FAILURE;
        }
        // Create an iterative solver manager.
        RCP< Belos::SolverManager<double,MV,OP> > solver
            = rcp( new Belos::BlockGmresSolMgr<double,MV,OP>(problem, rcp(&belosList,false)));

        //
        // *******************************************************************
        // *************Start the block Gmres iteration*************************
        // *******************************************************************
        //
        if (proc_verbose) {
            std::cout << std::endl << std::endl;
            std::cout << "Dimension of matrix: " << NumGlobalElements << std::endl;
            std::cout << "Number of right-hand sides: " << numrhs << std::endl;
            std::cout << "Block size used by solver: " << blocksize << std::endl;
            std::cout << "Number of restarts allowed: " << maxrestarts << std::endl;
            std::cout << "Max number of Gmres iterations per restart cycle: " << maxiters << std::endl;
            std::cout << "Relative residual tolerance: " << tol << std::endl;
            std::cout << std::endl;
        }
        //
        // Perform solve
        //
        Belos::ReturnType ret = solver->solve();
        //
        // Compute actual residuals.
        //
        // bool badRes = false;
        // std::vector<double> actual_resids( numrhs );
        // std::vector<double> rhs_norm( numrhs );
        // Epetra_MultiVector resid(*Map, numrhs);
        // OPT::Apply( *A, *X, resid );
        // MVT::MvAddMv( -1.0, resid, 1.0, *B, resid );
        // MVT::MvNorm( resid, actual_resids );
        // MVT::MvNorm( *B, rhs_norm );
        // if (proc_verbose) {
        //     std::cout<< "---------- Actual Residuals (normalized) ----------"<<std::endl<<std::endl;
        //     for ( int i=0; i<numrhs; i++) {
        //         double actRes = actual_resids[i]/rhs_norm[i];
        //         std::cout<<"Problem "<<i<<" : \t"<< actRes <<std::endl;
        //         if (actRes > tol) badRes = true;
        //     }
        // }
        // success = ret==Belos::Converged && !badRes;
        success = ret==Belos::Converged;
        if (success) {
            if (proc_verbose)
                std::cout << "End Result: TEST PASSED" << std::endl;
        } else {
            if (proc_verbose)
                std::cout << "End Result: TEST FAILED" << std::endl;
        }
    }

    //Solver not working (hiperlife's way)
    if (false)
    {
        // **************************************************************//
        // *****                  SOLVER CREATION                   *****//
        // **************************************************************//
        // RCP<Amesos2DirectLinearSolver> solver = rcp(new Amesos2DirectLinearSolver());
        // solver->setHiPerProblem(hiperProbl);
        // solver->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
        // solver->setSymbolicFactorization(true);
        // solver->setNumericFactorization(true);
        // solver->setUseTranspose(false);
        // solver->setVerbosity(Amesos2DirectLinearSolver::Verbosity::High);
        // // solver->setDefaultParameters();
        // solver->Update();

        RCP<BelosIterativeLinearSolver> solver = rcp(new BelosIterativeLinearSolver());
        solver->setHiPerProblem(hiperProbl);
        solver->setTolerance(1.E-6);
        solver->setMaxNumIterations(5000);
        solver->setKrylovSpaceMaxSize(205);
        solver->setMaxNumRestarts(15);
        solver->setSolver(BelosIterativeLinearSolver::Solver::BlockGMRES);
        solver->setPreconditioner(BelosIterativeLinearSolver::Preconditioner::Ilu);
        solver->setPreconditionerSide(BelosIterativeLinearSolver::PreconditionerSide::Right);
        solver->setVerbosity(BelosIterativeLinearSolver::Verbosity::High);
        solver->Update();


        // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
        // solver->setHiPerProblem(hiperProbl);
        // solver->setTolerance(1.E-6);
        // solver->setMaxNumIterations(500);
        // solver->setKrylovSpaceMaxSize(500);
        // solver->setConvergence(AztecOOIterativeLinearSolver::Convergence::Relative);
        // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
        // solver->setPrecond(AztecOOIterativeLinearSolver::Precond::DomainDecomp);
        // solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilu);
        // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
        // solver->Update();


        solver->solve();
    }

    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//
    hiperProbl->UpdateSolution();

    dofHand->printFileLegacyVtk("Poisson");


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
