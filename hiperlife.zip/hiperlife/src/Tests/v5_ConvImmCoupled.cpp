/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>
#include <set>
#include <unordered_map>
#include <limits>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include <ad.h>



// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct CoupledParams
{
  enum RealParameters
  {
    force,
    beta,
    mu0,
    mu1,
    lambda1,
    deltat,
    beta0
  };

  enum IntParameters
  {
    timeStep,
  };

  enum BoolParameters
  {
    postProcess,
    approxStep
  };

  HL_PARAMETER_LIST DefaultValues
  {
    {"force", 0.0},
    {"beta", 100.0},
    {"timeStep",0},
    {"mu0",1.},
    {"mu1",0.5},
    {"lambda1",5.},
    {"deltat",0.1},
    {"beta0",-1.},
    {"postProcess",false},
    {"approxStep",false}
  };
};

bool fileExists(const std::string& filename)
{
  struct stat buf;
  if (stat(filename.c_str(), &buf) != -1)
  {
    return true;
  }
  return false;
}

struct Params {
  double rx, ry, mu0, mu1, lm1, dt, wpTh, beta, levels, checkBorder, walls;
};

Params parseArgs(int argc, char* argv[]) {
  std::unordered_map<std::string, std::string> args;
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg.rfind("--", 0) == 0 && i + 1 < argc) {
      args[arg.substr(2)] = argv[++i];
    }
  }

  auto get = [&](const std::string& key,double defVal) -> double {
    auto it = args.find(key);
    if (it == args.end()) {
      cout << "Using default for --" + key<<endl;
      return defVal;
    }
    try {
      return std::stod(it->second);
    } catch (...) {
      throw std::runtime_error("Invalid value for --" + key + ": '" + it->second + "'");
    }
  };

  return Params{
    get("rx",0.5),
    get("ry",0.5),
    get("mu0",1),     // fluid viscosity
    get("mu1",0.5),   // solid shear modulus
    get("lm1",5),     // solid Lame lambda
    get("dt",0.1),    // time step (solid displacement = dt * velocity)
    get("wpTh",0.5),
    get("beta",-1.),  // gamma of a fixed beta = gamma/h; <= 0: local estimate
    get("levels",5),
    get("checkBorder",0), // 1: compare LSBorder with the full autodiff assembly (slow)
    get("walls",1)        // solid on the box walls: 1 rollers (normal velocity 0), 0 clamped (v1 = 0)
  };
}

// ─── helper: find adjacent element pairs ────────────────────────────────────

std::vector<std::pair<int,int>> findBorderAdjacentPairs(
    Teuchos::RCP<hiperlife::DOFsHandler> dhand, int p, int rInt)
{
    using namespace hiperlife;

    auto mesh = dhand->mesh;
    vector<string> rTags = mesh->_regionTags();
    // if (std::find(rTags.begin(), rTags.end(), rTag) == rTags.end())
    //     throw runtime_error("findBorderAdjacentPairs: The provided region name could not be found");
    vector<int> rPrimes = {3,5,7,11};

    // Corner local-node indices per side of a Q_p square element:
    //   Side 0 (v=-1): nodes 0      and p
    //   Side 1 (u=+1): nodes p      and p*(p+2)
    //   Side 2 (v=+1): nodes p*(p+2) and p*(p+1)
    //   Side 3 (u=-1): nodes p*(p+1) and 0
    const std::array<std::array<int,2>,4> sideCorners = {{
        {0,       p        },
        {p,       p*(p+2)  },
        {p*(p+2), p*(p+1)  },
        {p*(p+1), 0        }
    }};
    
    dhand->elemAuxF->setValue("GhP"+to_string(rInt),1);

    std::unordered_map<int, std::vector<int>> nodeToElems;
    for (int e = 0; e < mesh->loc_nElem(); e++)
    {
        int eNN = mesh->_adjcyEN->getNumNbors(e, IndexType::Local);
        for (int i = 0; i < eNN; i++)
        {
            int gn = mesh->_adjcyEN->getNbor(e, i, IndexType::Global);
            nodeToElems[gn].push_back(e);
        }
    }

    int offs = mesh->offs_nElem();
    std::set<std::pair<int,int>> seen;
    std::vector<std::pair<int,int>> result;

    for (int e1 = 0; e1 < mesh->loc_nElem(); e1++)
    {
        if((int)dhand->elemAuxF->getValue(0,e1)%2 == 0)
        {
            int sCount = 0;
            for (auto& sc : sideCorners)
            {
                int gA = mesh->_adjcyEN->getNbor(e1, sc[0], IndexType::Global);
                int gB = mesh->_adjcyEN->getNbor(e1, sc[1], IndexType::Global);

                const auto& eA = nodeToElems[gA];
                const auto& eB = nodeToElems[gB];

                for (int e2 : eA)
                {
                    if (e2 == e1) continue;
                    if (std::find(eB.begin(), eB.end(), e2) == eB.end()) continue;
                    if ((int)dhand->elemAuxF->getValue(0,e2)%rPrimes[rInt] != 0) continue;
                    int g1 = e1 + offs, g2 = e2 + offs;
                    auto key = std::make_pair(std::min(g1,g2), std::max(g1,g2));
                    if (seen.insert(key).second)
                    {
                        result.push_back(key);
                        double e1Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e1,IndexType::Global);
                        if ((int)e1Val%rPrimes[sCount] != 0)
                            dhand->elemAuxF->setValue("GhP"+to_string(rInt),e1,IndexType::Global,e1Val*rPrimes[sCount]);
                        double e2Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e2,IndexType::Global);
                        if ((int)e2Val%rPrimes[(sCount+2)%4] != 0)
                            dhand->elemAuxF->setValue("GhP"+to_string(rInt),e2,IndexType::Global,e2Val*rPrimes[(sCount+2)%4]);
                    }
                }
                sCount++;
            }
        }
    }
    return result;
}

// Cavity flow

vector<double> bodyForce(double x,double y)
{
  double sx  = sin(M_PI*x);
  double cx = cos(M_PI*x);
  double sy  = sin(M_PI*y);
  double cy = cos(M_PI*y);
  double sxy = sin(M_PI*(x + y));
  double cxy = cos(M_PI*(x + y));
  double J   = 1. + M_PI*sxy/5.;
  double lnJ = log(J);

  double denom = (M_PI*sxy + 5.)*(M_PI*sxy + 5.);
  vector<double> b(2);

  b[0] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sx*cy + 5.)*(lnJ - 1.)*cxy - (M_PI*sx*cy + 5.)*cxy - M_PI*(lnJ - 1.)*sy*cx*cxy + M_PI*sy*cx*cxy) / denom;

  b[1] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sy*cx + 5.)*(lnJ - 1.)*cxy - (M_PI*sy*cx + 5.)*cxy - M_PI*(lnJ - 1.)*sx*cy*cxy + M_PI*sx*cy*cxy) / denom;

  return b;
}

inline void tensorToVoigt(tensor<double,1>& A_v, tensor<double,2> A)
{
  int n = A.shape()[0];
  if (n == 1)
  {
    A_v(0) = A(0,0);
  }
  else if (n == 2)
  {
    A_v(0) = A(0,0);
    A_v(1) = A(1,1);
    A_v(2) = A(0,1);
  }
  else if (n == 3)
  {
    A_v(0) = A(0,0);
    A_v(1) = A(1,1);
    A_v(2) = A(2,2);
    A_v(3) = A(0,1);
    A_v(4) = A(0,2);
    A_v(5) = A(1,2);
  }
  else
  {
    throw runtime_error("tensorToVoigt: working for 1D, 2D and 3D.");
  }
}

inline void tendot4oo(tensor<double,2> bb, tensor<double,2>& aa)
{
  // *************************************************************************
  // a =  b o b (b packed)
  // []_abcd = 0.5*(C^-1_ac*C^-1_bd + C^-1_ad*C^-1_bc)
  // *************************************************************************

  int n = bb.shape()[0];
  if (n == 1)
  {
    aa(0,0) = 0.5*(bb(0,0)*bb(0,0) + bb(0,0)*bb(0,0));
  }
  else if (n == 2)
  {
    tensor<int,2> ks{{0,2}, {2,1}};
    for (int i = 0; i < 2; i++)
      for (int j = 0; j < 2; j++)
        for (int k = 0; k < 2; k++)
          for (int l = 0; l < 2; l++)
            aa(ks(i,j), ks(k,l)) = 0.5*(bb(i,k)*bb(j,l) + bb(i,l)*bb(j,k));
  }
  else if (n == 3)
  {
    tensor<int,2> ks{{0,3,4}, {3,1,5}, {4,5,2}};
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++)
        for (int k = 0; k < 3; k++)
          for (int l = 0; l < 3; l++)
            aa(ks(i,j), ks(k,l)) = 0.5*(bb(i,k)*bb(j,l) + bb(i,l)*bb(j,k));
  }
  else
  {
    throw runtime_error("tensorToVoigt: working for 1D, 2D and 3D.");
  }
}

// Constitutive models
void constitutiveModel_Coupled_NeoHookean(tensor<double,1>& S_v, tensor<double,2>& S, tensor<double,2>& D, double& W, tensor<double,2> F, map<string, double>& params)
{
  using namespace hiperlife::Tensor;

  //***********************************************************
  // [0] Initialize
  //***********************************************************

  // Parameters
  double mu = params.at("mu");
  double lm = params.at("lambda");

  // Dimensions
  int pDim = F.shape()[0];
  int nVoi{0};
  if (pDim == 1)
    nVoi = 1;
  else if (pDim == 2)
    nVoi = 3;
  else if (pDim == 3)
    nVoi = 6;


  //***********************************************************
  // [1] Compute jacobian, right Cauchy def tensor and inverse
  //***********************************************************

  // Jacobian
  double J = F.det();

  // Inverse of the right Cauchy-Green tensor (tensor and voigt notation)
  tensor<double,2> Finv = F.inv();
  tensor<double,2> Cinv = Finv*Finv.T(); //This seems to introduce less error than C.inv()
  tensor<double,1> Cinv_v(nVoi);
  tensorToVoigt(Cinv_v, Cinv);

  // Compute Cinv(x)Cinv => []_abcd=Cinv_ab*Cinv_cd
  tensor<double,2> CinvCinv = outer(Cinv_v, Cinv_v);

  // Compute Cinv(·)Cinv => []_abcd=0.5(Cinv_ac*Cinv_bd+Cinv_ad*Cinv_bc) [Eq. 6.165]
  tensor<double,2> Cinv_Cinv(nVoi,nVoi);
  tendot4oo(Cinv, Cinv_Cinv);


  //***********************************************************
  // [2] Compute 2nd Piola-Kirchhoff stress tensor
  //***********************************************************

  // Energy
  tensor<double,2> C = F.T()*F;
  W = 0.5*lm*log(J)*log(J) - mu*log(J) + 0.5*mu*(trace(C)-pDim);
  // W = 0.5*lm*(J-1.0)*(J-1.0) - mu*log(J) + 0.5*mu*(trace(C)-2.0); // Wiki

  // Stress tensor
  tensor<double,2> Id = Identity(pDim);
  S = mu*Id + (lm*log(J)-mu)*Cinv;
  
  // S = mu*Id + 2.0*(lm*J*(J-1.0)-mu)*Cinv; // Wiki
  tensorToVoigt(S_v, S);

  //***********************************************************
  // [3] Compute elasticity tensor
  //***********************************************************

  // Elasticity tensor
  D = lm*CinvCinv + 2.0*(mu-lm*log(J))*Cinv_Cinv;
  // D = 4.0*(2.0*lm*J*J-lm*J)*CinvCinv - 4.0*(lm*J*(J-1.0)-mu)*Cinv_Cinv; // Wiki
}

void constitutiveModel_Coupled_NeoHookean(tensor<double,1>& S_v, tensor<double,2>& S, tensor<double,2>& D,tensor<double,3>& CC, double& W, tensor<double,2> F, map<string, double>& params)
{
  using namespace hiperlife::Tensor;

  //***********************************************************
  // [0] Initialize
  //***********************************************************

  // Parameters
  double mu = params.at("mu");
  double lm = params.at("lambda");

  // Dimensions
  int pDim = F.shape()[0];
  int nVoi{0};
  if (pDim == 1)
    nVoi = 1;
  else if (pDim == 2)
    nVoi = 3;
  else if (pDim == 3)
    nVoi = 6;


  //***********************************************************
  // [1] Compute jacobian, right Cauchy def tensor and inverse
  //***********************************************************

  // Jacobian
  double J = F.det();
  double lnJ = log(J);

  // Inverse of the right Cauchy-Green tensor (tensor and voigt notation)
  tensor<double,2> Finv = F.inv();
  tensor<double,2> Cinv = Finv*Finv.T(); //This seems to introduce less error than C.inv()
  tensor<double,1> Cinv_v(nVoi);
  tensorToVoigt(Cinv_v, Cinv);

  // Compute Cinv(x)Cinv => []_abcd=Cinv_ab*Cinv_cd
  tensor<double,2> CinvCinv = outer(Cinv_v, Cinv_v);

  // Compute Cinv(·)Cinv => []_abcd=0.5(Cinv_ac*Cinv_bd+Cinv_ad*Cinv_bc) [Eq. 6.165]
  tensor<double,2> Cinv_Cinv(nVoi,nVoi);
  tendot4oo(Cinv, Cinv_Cinv);


  //***********************************************************
  // [2] Compute 2nd Piola-Kirchhoff stress tensor
  //***********************************************************

  // Energy
  tensor<double,2> C = F.T()*F;
  W = 0.5*lm*log(J)*log(J) - mu*lnJ + 0.5*mu*(trace(C)-pDim);
  // W = 0.5*lm*(J-1.0)*(J-1.0) - mu*log(J) + 0.5*mu*(trace(C)-2.0); // Wiki

  // Stress tensor
  tensor<double,2> Id = Identity(pDim);
  S = mu*Id + (lm*lnJ-mu)*Cinv;
  // S = mu*Id + 2.0*(lm*J*(J-1.0)-mu)*Cinv; // Wiki
  tensorToVoigt(S_v, S);

  //***********************************************************
  // [3] Compute elasticity tensor
  //***********************************************************

  // Elasticity tensor
  D = lm*CinvCinv + 2.0*(mu-lm*log(J))*Cinv_Cinv;
  // D = 4.0*(2.0*lm*J*J-lm*J)*CinvCinv - 4.0*(lm*J*(J-1.0)-mu)*Cinv_Cinv; // Wiki

  //***********************************************************
  // [4] Compute high order elasticity tensor
  //***********************************************************
  // From the chain rule on D = lm*(cv x cv) + 2*muhat*(Cinv_ovov_Cinv):
  //
  //   dD/dC_g = lm * d(cv x cv)/dC_g
  //           + 2 * d(muhat)/dC_g * (Cinv_ovov_Cinv)
  //           + 2 * muhat * d(Cinv_ovov_Cinv)/dC_g
  //
  // where muhat = mu - lm*lnJ,  d(muhat)/dC_g = -lm/2 * cv(g)
  //
  // Key identity: dCinv_PQ/dC_EF = -1/2*(Cinv_PE*Cinv_FQ + Cinv_PF*Cinv_EQ)

  // index map helper: voigt index -> (i,j) tensor index (1-based)
  tensor<double,2> voigt_to_ij = {{0,0}, {1,1}, {0,1}};   // row = voigt index, cols = i,j

  double muhat = mu - lm*lnJ;

  for (int a = 0; a<3; a++)
  {
    int ai = voigt_to_ij(a,0);  int aj = voigt_to_ij(a,1);
    for (int b = 0; b<3; b++)
    {
      int bi = voigt_to_ij(b,0);  int bj = voigt_to_ij(b,1);
      for (int g = 0; g<3; g++)
      {
        int gi = voigt_to_ij(g,0);  int gj = voigt_to_ij(g,1);

        // d(cv_a)/dC_g  [scalar]
        double dcva = -0.5*(Cinv(ai,gi)*Cinv(gj,aj) + Cinv(ai,gj)*Cinv(gi,aj));

        // d(cv_b)/dC_g  [scalar]
        double dcvb = -0.5*(Cinv(bi,gi)*Cinv(gj,bj) + Cinv(bi,gj)*Cinv(gi,bj));

        // d(cv_a * cv_b)/dC_g  [scalar]
        double dCvCv = dcva*Cinv_v(b) + Cinv_v(a)*dcvb;

        // d(Cinv_Cinv_ab)/dC_g  from product rule on 0.5*(Cinv_ai_bi*Cinv_aj_bj + Cinv_ai_bj*Cinv_aj_bi)
        double d1 = (-0.5*(Cinv(ai,gi)*Cinv(gj,bi) + Cinv(ai,gj)*Cinv(gi,bi)))*Cinv(aj,bj);
        d1 += Cinv(ai,bi)*(-0.5*(Cinv(aj,gi)*Cinv(gj,bj) + Cinv(aj,gj)*Cinv(gi,bj)));

        double d2 = (-0.5*(Cinv(ai,gi)*Cinv(gj,bj) + Cinv(ai,gj)*Cinv(gi,bj)))*Cinv(aj,bi);
        d2 +=  Cinv(ai,bj)*(-0.5*(Cinv(aj,gi)*Cinv(gj,bi) + Cinv(aj,gj)*Cinv(gi,bi)));

        double dCsC = 0.5*(d1 + d2);

        // d(muhat)/dC_g = -lm * 0.5 * cv_g
        double dmuhat = -lm * 0.5 * Cinv_v(g);

        // CsC_ab at current C (needed for the muhat coefficient term)
        double CsC_ab = 0.5*(Cinv(ai,bi)*Cinv(aj,bj) + Cinv(ai,bj)*Cinv(aj,bi));

        // Assemble
        CC(a,b,g) = 2.*lm * dCvCv + 2.*2.0 * dmuhat * CsC_ab + 2.*2.0 * muhat  * dCsC;
      }
    }
  }
}

// ─── previous (coarser) level, for errors between successive levels ─────────
struct CoarseLevel
{
  bool valid = false;
  SmartPtr<DOFsHandler> dh;
  SmartPtr<DistributedMesh> immMesh; // keeps dh's child mesh alive
  int n = 0;
  double x0 = 0., y0 = 0., hx = 1., hy = 1.;
  std::vector<int> cell2elem;
};
static CoarseLevel g_coarse;

void setCoarseLevel(SmartPtr<DOFsHandler> dh, SmartPtr<DistributedMesh> immMesh, int n)
{
  auto mesh = dh->mesh;
  double xMin = 1e300, yMin = 1e300, xMax = -1e300, yMax = -1e300;
  for (int i = 0; i < mesh->nPts(); i++)
  {
    xMin = std::min(xMin, mesh->nodeCoord(i,0));
    xMax = std::max(xMax, mesh->nodeCoord(i,0));
    yMin = std::min(yMin, mesh->nodeCoord(i,1));
    yMax = std::max(yMax, mesh->nodeCoord(i,1));
  }
  g_coarse.dh = dh;
  g_coarse.immMesh = immMesh;
  g_coarse.n = n;
  g_coarse.x0 = xMin;
  g_coarse.y0 = yMin;
  g_coarse.hx = (xMax-xMin)/n;
  g_coarse.hy = (yMax-yMin)/n;
  g_coarse.cell2elem.assign(n*n, -1);
  for (int e = 0; e < mesh->nElem(); e++)
  {
    int c = mesh->_connec->getNbor(e, 4); // centre node
    int ix = (int)floor((mesh->nodeCoord(c,0)-xMin)/g_coarse.hx);
    int iy = (int)floor((mesh->nodeCoord(c,1)-yMin)/g_coarse.hy);
    g_coarse.cell2elem[iy*n+ix] = e;
  }
  g_coarse.valid = true;
}

// Coarse velocity u and gradient G(i,J) = du_i/dX_J of region rInt at X, and
// the fluid pressure p (region 0 only, P1 from nodes 0, 1, 3 as in LSBorder).
// Returns false if the coarse element is not active in that region
// (possible only where the coarse and fine interfaces differ).
bool evalCoarse(const double* x, int rInt, double u[2], double G[2][2], double& p, int& elem)
{
  const std::vector<int> rPrime = {3,5};
  auto mesh = g_coarse.dh->mesh;
  int n = g_coarse.n;
  int ix = std::min(n-1, std::max(0, (int)floor((x[0]-g_coarse.x0)/g_coarse.hx)));
  int iy = std::min(n-1, std::max(0, (int)floor((x[1]-g_coarse.y0)/g_coarse.hy)));
  elem = g_coarse.cell2elem[iy*n+ix];
  if (elem < 0 || (int)mesh->_elemFlags->getValue(1, elem, IndexType::Local)%rPrime[rInt] != 0)
    return false;

  int eNN = 9;
  std::vector<int> nds(eNN);
  for (int a = 0; a < eNN; a++)
    nds[a] = mesh->_connec->getNbor(elem, a);
  double ex0 = mesh->nodeCoord(nds[0],0), ey0 = mesh->nodeCoord(nds[0],1);
  double ex1 = mesh->nodeCoord(nds[8],0), ey1 = mesh->nodeCoord(nds[8],1);
  std::vector<double> rC = {(2.*x[0]-ex1-ex0)/(ex1-ex0), (2.*x[1]-ey1-ey0)/(ey1-ey0)};
  std::vector<std::vector<double>>& bf = mesh->_basisFunctions->computeBasisFunctionsReference(rC, mesh->_basisFunctions->getTag(elem, IndexType::Local));

  // Jacobian dx_J/dxi_K and its inverse
  double J[2][2] = {{0.,0.},{0.,0.}};
  for (int a = 0; a < eNN; a++)
    for (int K = 0; K < 2; K++)
      for (int d = 0; d < 2; d++)
        J[d][K] += mesh->nodeCoord(nds[a],d)*bf[1][2*a+K];
  double det = J[0][0]*J[1][1]-J[0][1]*J[1][0];
  double Ji[2][2] = {{J[1][1]/det, -J[0][1]/det}, {-J[1][0]/det, J[0][0]/det}}; // dxi_K/dx_J

  for (int i = 0; i < 2; i++)
  {
    u[i] = 0.;
    G[i][0] = G[i][1] = 0.;
  }
  for (int a = 0; a < eNN; a++)
  {
    double dx = bf[1][2*a]*Ji[0][0] + bf[1][2*a+1]*Ji[1][0];
    double dy = bf[1][2*a]*Ji[0][1] + bf[1][2*a+1]*Ji[1][1];
    for (int i = 0; i < 2; i++)
    {
      double v = g_coarse.dh->nodeDOFs->getValue(2*rInt+i, nds[a], IndexType::Global);
      u[i] += bf[0][a]*v;
      G[i][0] += dx*v;
      G[i][1] += dy*v;
    }
  }
  p = 0.;
  if (rInt == 0)
  {
    double pa = g_coarse.dh->nodeDOFs->getValue(4, nds[0], IndexType::Global);
    double pb = g_coarse.dh->nodeDOFs->getValue(4, nds[1], IndexType::Global);
    double pc = g_coarse.dh->nodeDOFs->getValue(4, nds[3], IndexType::Global);
    p = pa + 0.5*(rC[0]+1.)*pb + 0.5*(rC[1]+1.)*pc;
  }
  return true;
}

// ‖u_h − u_2h‖² and ‖∇u_h − ∇u_2h‖² contributions of region rInt at the
// current point, Gu(i,J) = du_i/dX_J. No exact solution exists for this test
// (it is driven by the prescribed normal velocity jump vd), so only the
// differences with the previous level are measured.
void addCoarseDiff(hiperlife::FillStructure& fillStr, ttl::tensor<double,1> x, int rInt,
                   double ux, double uy, ttl::tensor<double,2> Gu, double jac)
{
  if (!g_coarse.valid)
    return;
  double u[2], G[2][2], p;
  int elem;
  if (!evalCoarse(x.data(), rInt, u, G, p, elem))
  {
    fillStr.addToGlobalIntegral("dMiss", jac);
    return;
  }
  double dU = (ux-u[0])*(ux-u[0]) + (uy-u[1])*(uy-u[1]);
  double dG = 0.;
  for (int i = 0; i < 2; i++)
    for (int J = 0; J < 2; J++)
      dG += (Gu(i,J)-G[i][J])*(Gu(i,J)-G[i][J]);
  fillStr.addToGlobalIntegral("dErr", jac*dU);
  fillStr.addToGlobalIntegral("dGerr", jac*dG);
  fillStr.addToGlobalIntegral("dErr"+to_string(rInt), jac*dU);  // per region
  fillStr.addToGlobalIntegral("dGerr"+to_string(rInt), jac*dG);
}

// Flux weight of side 0 for a fixed beta: stiffness-weighted (harmonic) average,
// gmm0 = k1/(k0+k1), with the normal stiffness of each side in velocity units:
// k0 = 2 mu0 (fluid) and k1 = dt (lambda1 + 2 mu1) (solid, displacement = dt v)
double fixedBetaGmm0(double mu0, double mu1, double lm1, double deltat)
{
  double k0 = 2.*mu0;
  double k1 = deltat*(lm1 + 2.*mu1);
  return k1/(k0+k1);
}

void LSV0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;
  using namespace autodiff;

  double mu  = fillStr.getRealParameter(CoupledParams::mu0);

  double deltat = fillStr.getRealParameter(CoupledParams::deltat);

  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);

  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr["backDHand"];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;        //  eNN = 9
  int numDOFs = subFill.numDOFs;//  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  tensor<double,2,false> Dbf(subFill.nborBFsGrads(), eNN, pDim);
  ttl::tensor<double,2> Dbf_g(eNN,pDim); // Global basis function gradient (eNN,pDim)
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  // ttl::wrapper<double,2> Bk0(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2
  
  // ttl::wrapper<double,4> Ak00(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//
  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> df = bf*nborDOFs;
  ttl::tensor<double,1> u = {df(2),df(3)};
  double uu = sqrt((-x(1)+0.5)*(-x(1)+0.5)+(x(0)+0.3)*(x(0)+0.3));
  ttl::tensor<double,2> Gp = product(nborCoords, Dbf_g, {{0,0}}); // dxp/dchi  
  tensor<double,2> Gp_i = Gp.inv(); // dchi/dxp
  double ff = 0.;
  ttl::tensor<double,1> f(2);
  f(0) = 0.05*(2.*mu*M_PI*M_PI*sin(M_PI*x(0))*cos(M_PI*x(1))+M_PI*cos(M_PI*x(0))*sin(M_PI*x(1)));
  f(1) = -0.05*(2.*mu*M_PI*M_PI*cos(M_PI*x(0))*sin(M_PI*x(1))-M_PI*sin(M_PI*x(0))*cos(M_PI*x(1)));

  f(0) = 0.;
  f(1) = 0.;
  tensor<double,2> Gu = product(Dbf_g,nborDOFs(all,rngR0), {{0,0}}); // dv/dchi
  tensor<double,2> eu = 0.5*(Gu+Gu.T());

  tensor<double,2> nborx = nborDOFs(all,rngR0)*deltat+nborCoords;
  tensor<double,2> F = product(Dbf_g,nborx, {{0,0}});
  tensor<double,2> Fi = F.inv();
  tensor<double,2> Eu = 0.5*(Gu*Fi+Fi.T()*Gu.T());

  if (false)
  {
  auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  {
    // Rearrange DOFs into tensor
    tensor<dual2nd,2,true>   nborDOFsd(eNN, numDOFs);  // nborDOFsd(eNN,numDOFs)
    for (int i = 0; i < eNN; i++)
    {
      for (int d = 0; d < numDOFs; d++)
      {
        nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
      }
    }

    ttl::tensor<dual2nd,1> dfd = bf*nborDOFsd;
    ttl::tensor<dual2nd,1> ud = {dfd(0),dfd(1)};

    tensor<dual2nd,2> Gud = product(nborDOFsd(all,rngR0),Dbf_g, {{0,0}}); // Gradient of velocities Gud(i,J) = dv_i/dX_J

    tensor<dual2nd,2> dd = 0.5*(Gud+Gud.T());
    // tensor<dual2nd,2> Fd = deltat*Gud+Identity2;// Gradient deformation F(i,J) = dx_i/dX_J
    // tensor<dual2nd,2> Fd_i = Fd.inv(); // F_i(J,i) =  dX_J/dx_i
    // tensor<dual2nd,2> GuFi = Gud*Fd_i; // GuFi(i,j) = Gud(i,J)*Fd_i(J,j)
    // tensor<dual2nd,2> DD = 0.5*(GuFi+GuFi.T());
    // // cout << DD << endl;
    // dual2nd Jd = Fd.det();
    // dual2nd ray = jac*mu*product(DD,DD,{{0,0},{1,1}})*Jd-jac*ud*f*Jd;
    dual2nd ray = jac*mu*product(dd,dd,{{0,1},{1,0}})-jac*ud*f;
    // dual2nd ray = jac*mu*product(DD,DD,{{0,0},{1,1}})-jac*ud*f;

    return(ray);
  };

  // Compute nborDOFs as dual2nd type
  std::vector<dual2nd> dofs(eNN*numDOFs);
  for (int i = 0; i < eNN*numDOFs; i++)
  {
    dofs.at(i) = subFill.nborDOFs.at(i);
  }

  // Compute rayleighian, jacobian, and hessian
  dual2nd ray;
  std::vector<double> Jac(eNN*numDOFs);
  std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  // Rearrange into Bk and Ak
  int n0 = eNN*numDOFs;
  for (int i = 0; i < n0; i++)
  {
    fillStr.Bk(0).at(i) = Jac[i];
  }

  for (int i = 0; i < n0; i++)
  {
    for (int j = 0; j < n0; j++)
    {
      fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
    }
  }  
  }
  if(true)
  {
  tensor<double,2> Bk(eNN,numDOFs);
  tensor<double,4> Ak(eNN,numDOFs,eNN,numDOFs);
  tensor<double,4> de(eNN,pDim,pDim,pDim);
  tensor<double,2> Id2 = Identity2;
  std::vector<int> eNNp = {0,1,3};
  for (int a{}; a< eNN; a++)
    for (int i{}; i< numDOFs; i++)
      for (int b{}; b< eNN; b++)
        for (int j{}; j< numDOFs; j++)
          Ak(a,i,b,j) = 0.;
  for (int a{}; a< eNN; a++)
    for (int i{}; i< numDOFs; i++)
      Bk(a,i) = 0.;
  
  for (int a{}; a< eNN; a++)
    for (int i{}; i< pDim; i++)
      for (int k{}; k< pDim; k++)
        for (int l{}; l< pDim; l++)
          de(a,i,k,l) = 0.5*(Dbf_g(a,k)*Id2(i,l)+Dbf_g(a,l)*Id2(i,k));

  Bk(all,rngR0) = 2.*jac*mu*product(eu,de,{{0,2},{1,3}});
  Ak(all,rngR0,all,rngR0) = 2.*jac*mu*product(de,de,{{2,2},{3,3}});

  for (int a{}; a< eNN; a++)
  {
    Bk(a,0) += -jac*bf(a)*f(0);
    Bk(a,1) += -jac*bf(a)*f(1);
  }
  

  ttl::wrapper<double,2> Bk0(fillStr.Bk(0).data(), eNN, numDOFs);     // 9 * 2
  ttl::wrapper<double,4> Ak0(fillStr.Ak(0,0).data(), eNN, numDOFs, eNN, numDOFs);     // 9 * 2
  Ak0 = Ak;
  Bk0 = Bk;

  if (fillStr.getBoolParameter(CoupledParams::postProcess))
  {
    tensor<double,2> Gu0 = product(nborDOFs(all,rngR0), Dbf_g, {{0,0}}); // Gu0(i,J) = du_i/dX_J
    addCoarseDiff(fillStr, x, 0, df(0), df(1), Gu0, jac);
  }
  // for (int a{}; a< eNN; a++)
  // {
  //   for (int i = 2; i< 4; i++)
  //   {
  //     if(abs(Bk0(a,i)-Bk(a,i))>1e-16)
  //       cout << "ERROR LSV1 at (" <<a<<","<<i<<") Bkad = "<<Bk0(a,i) << " Bk = " << Bk(a,i) << endl; 

  //     for(int b{}; b< eNN; b++)
  //     {
  //       for (int j = 2; j< 4; j++)
  //       {
  //         if(abs(Ak0(a,i,b,j)-Ak(a,i,b,j))>1e-16)
  //           cout << "ERROR LSV1 at (" <<a<<","<<i<<","<<b<<","<<j<<") Akad = "<<Ak0(a,i,b,j) << " Ak = " << Ak(a,i,b,j) << endl; 
  //       }
  //     }
  //   }
  // }
  
  }
}

void LSP0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;
  using namespace autodiff;
  auto rngCoords = range(0,1);

  auto rngR0 = range(0,1);
  double deltat = fillStr.getRealParameter(CoupledParams::deltat);

  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr["backDHand"];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 2
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  tensor<double,2> nborCoordsEl = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);

  ttl::tensor<double,2> Dbf_g(eNN,pDim); // dbf(a,i)
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  tensor<double,1> eC = bf*nborCoordsEl;
  
  ttl::tensor<double,1> x = bf*nborCoords;

  tensor<double,1> bf1 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
  double p = nborDOFs(0,4)*bf1(0)+(nborDOFs(1,4))*bf1(1)+(nborDOFs(3,4))*bf1(2);

  // cout << x << p << endl;
  ttl::tensor<double,2> Gp = product(nborCoords, Dbf_g, {{0,0}}); // dxp/dchi  
  tensor<double,2> Gp_i = Gp.inv(); // dchi/dxp
  tensor<double,2> Gu = product(Dbf_g,nborDOFs(all,rngR0), {{0,0}}); // dv/dchi

  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//

  if(false)
  {
    auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
    {
      //***********************************************************
      // Initialize
      //***********************************************************

      // Rearrange DOFs  // FIXME: I don't think this is the fastest way
      tensor<dual2nd,2,true>   nborDOFsd(eNN, numDOFs);
      for (int i = 0; i < eNN; i++)
      {
        for (int d = 0; d < numDOFs; d++)
        {
          nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
        }
      }

      tensor<dual2nd,2> Gud = product(nborDOFsd(all,rngR0), Dbf_g,{{0,0}}); // Gud(i,J) =  d\dot{u}_i/dX_J
      // tensor<dual2nd,2> Fd = Identity2+deltat*Gud; // Fd(i,J) = dx_i/dX_J
      // tensor<dual2nd,2> Fd_i = Fd.inv(); // Fd_i(J,i)
      // dual2nd Jd = Fd.det();
      tensor<dual2nd,1> pdfs = {nborDOFsd(0,4),nborDOFsd(1,4),nborDOFsd(3,4)};
      dual2nd pd = pdfs*bf1;

      dual2nd ray = -jac*(Gud(0,0)+Gud(1,1))*pd;
      // dual2nd ray = -jac*pd*product(Gud,Fd_i,{{0,1},{1,0}})*Jd;

      return(ray);
    };

    // Compute nborDOFs as dual2nd type
    std::vector<dual2nd> dofs(eNN*numDOFs);
    for (int i = 0; i < eNN*numDOFs; i++)
    {
      dofs.at(i) = subFill.nborDOFs.at(i);
    }
    // Compute rayleighian, jacobian, and hessian
    dual2nd ray;
    std::vector<double> Jac(eNN*numDOFs);
    std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
    hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

    // Rearrange into Bk and Ak
    int n0 = eNN*numDOFs;
    for (int i = 0; i < n0; i++)
    {
      fillStr.Bk(0).at(i) = Jac[i];
    }

    for (int i = 0; i < n0; i++)
    {
      for (int j = 0; j < n0; j++)
      {
        fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
      }
    }
  }
  if(true)
  {
    tensor<double,2> Bk(eNN,numDOFs);
    tensor<double,4> Ak(eNN,numDOFs,eNN,numDOFs);
    for (int a{}; a< eNN; a++)
      for (int i{}; i< numDOFs; i++)
        for (int b{}; b< eNN; b++)
          for (int j{}; j< numDOFs; j++)
            Ak(a,i,b,j) = 0.;
    for (int a{}; a< eNN; a++)
      for (int i{}; i< numDOFs; i++)
        Bk(a,i) = 0.;
    std::vector<int> eNNp = {0,1,3};

    for (int a{}; a< eNN; a++)
    {
      Bk(a,0) = -jac*Dbf_g(a,0)*p;
      Bk(a,1) = -jac*Dbf_g(a,1)*p;

      if(a < 3)
      {
        Bk(eNNp[a],4) = -jac*(Gu(0,0)+Gu(1,1))*bf1(a);
      }

      for (int b{}; b< eNN; b++)
      {
        if(a < 3)
        {
          Ak(eNNp[a],4,b,0) = -jac*Dbf_g(b,0)*bf1(a);
          Ak(eNNp[a],4,b,1) = -jac*Dbf_g(b,1)*bf1(a);
          Ak(b,0,eNNp[a],4) = -jac*Dbf_g(b,0)*bf1(a);
          Ak(b,1,eNNp[a],4) = -jac*Dbf_g(b,1)*bf1(a);
        }
      }
    }

    ttl::wrapper<double,2> Bk0(fillStr.Bk(0).data(), eNN, numDOFs);     // 9 * 2
    ttl::wrapper<double,4> Ak0(fillStr.Ak(0,0).data(), eNN, numDOFs, eNN, numDOFs);     // 9 * 2

    Ak0 = Ak;
    Bk0 = Bk;
    // for (int a{}; a< eNN; a++)
    // {
    //   for (int i{}; i< numDOFs; i++)
    //   {
    //     if(abs(Bk0(a,i)-Bk(a,i))>1e-12)
    //         cout << "ERROR LSP1 at (" <<a<<","<<i<<") Bkad = "<<Bk0(a,i) << " Bk = " << Bk(a,i) << endl; 

    //     for(int b{}; b< eNN; b++)
    //     {
    //       for (int j{}; j< numDOFs; j++)
    //       {
    //         if(abs(Ak0(a,i,b,j)-Ak(a,i,b,j))>1e-12)
    //         cout << "ERROR LSP1 at (" <<a<<","<<i<<","<<b<<","<<j<<") Akad = "<<Ak0(a,i,b,j) << " Ak = " << Ak(a,i,b,j) << endl; 
    //       }
    //     }
    //   }
    // }
  }
  

  // if (p*p > 1e-10)
  // {
  //   // Output integration points
  //   ofstream myfile;
  //   if (!fileExists("iPts.csv"))
  //   {
  //       myfile.open("iPts.csv", std::ios_base::app);
  //       myfile << "x(0)" << "," << "x(1)" << "," << "p" << endl;
  //       myfile.close();
  //   }
  //   myfile.open("iPts.csv", std::ios_base::app);
  //   myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << p << endl;
  //   myfile.close();
  // }
}


void LSV1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  using namespace autodiff;

  double mu1 = fillStr.getRealParameter(CoupledParams::mu1);
  double lm1 = fillStr.getRealParameter(CoupledParams::lambda1);
  double deltat = fillStr.getRealParameter(CoupledParams::deltat);
  auto rngCoords = range(0,1);
  auto rngR1 = range(2,3);

  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  
  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  // ttl::wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2
  
  // ttl::wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofsT = bf*nborDOFs;
  ttl::tensor<double,2> Gu_numeric = product(Dbf_g,nborDOFs,{{0,0}});
  ttl::tensor<double,1> u = {dofsT(2),dofsT(3)};

  ttl::tensor<double,1> f(2);
  std::vector<double> b = bodyForce(x(0),x(1));
  f(0) = b[0];
  f(1) = b[1];

  f(0) = 0.;
  f(1) = 0.;

  tensor<double,2> Id2 = Identity2;
    
  map<string, double> params1{{"mu",  fillStr.getRealParameter(CoupledParams::mu1)},
                             {"lambda", fillStr.getRealParameter(CoupledParams::lambda1)}};
  // Coordinates
  auto rng1 = range(2,3);

  // Deformation gradient G = dx/dchi (from chi to x)
  tensor<double,2> F1 = product(nborDOFs(all,rng1)*deltat, Dbf_g, {{0,0}})+Identity2;
  
  // Constitutive model
  double W1{};
  int nVoi = 3;
  tensor<double, 1> S1_v(nVoi);
  tensor<double, 2> S1(pDim, pDim), C1_v(nVoi, nVoi);
  constitutiveModel_Coupled_NeoHookean(S1_v, S1, C1_v, W1, F1, params1);

  // B0 tensor
  tensor<double,3> B10(nVoi, eNN, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      B10(i,a,all) = F1(all,i)*Dbf_g(a,i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      B10(2,a,all) = F1(all,1)*Dbf_g(a,0) + F1(all,0)*Dbf_g(a,1);
  }

  // Geometric stiffness matrix
  tensor<double, 2> k1g(eNN, eNN);
  k1g = Dbf_g*(S1*Dbf_g.T());

  // Geometric stiffness tensor
  tensor<double,2> Id = Identity(pDim);
  tensor<double,4> K1geo(eNN, pDim, eNN, pDim);
  tensor<double,4> K1geo2(eNN, pDim, eNN, pDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int j = 0; j < eNN; j++)
      K1geo2(i,all,j,all) = k1g(i,j)*Id;
  }
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            K1geo(b,j,a,i) = k1g(a,b);
          else
            K1geo(b,j,a,i) = 0.;
        }
      }
    }
  }

  //***********************************************************
  // Fill linear system
  //***********************************************************
  
  // Internal stresses
  tensor<double,2> Bk0(eNN,numDOFs);
  tensor<double,4> Ak0(eNN,numDOFs,eNN,numDOFs);
  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      for (int b = 0; b<eNN; b++)
        for (int j = 0; j<numDOFs; j++)
          Ak0(a,i,b,j) = 0;
  for (int a = 0; a<eNN; a++)
    for (int i = 0; i<numDOFs; i++)
      Bk0(a,i) = 0;

  double dEner = jac*W1/deltat;
  Bk0(all,rng1) += jac*(B10.transpose({1,2,0})*S1_v)-jac*outer(bf,f);
  Ak0(all,rng1,all,rng1) += deltat*jac*(B10.transpose({1,2,0})*C1_v*B10 + K1geo);

  
  ttl::wrapper<double,2> Bkt(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2

  ttl::wrapper<double,4> Akt(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2


  // for (int a = 0; a<eNN; a++)
  //   for (int i = 0; i<numDOFs; i++)
  //   {
  //     if (fabs(Bk0(a,i)-Bkt(a,i)) > 1e-10)
  //       cout << "BV1 error("<<a<<","<<i<<"): "<< fabs(Bk0(a,i)-Bkt(a,i))<< " " <<Bk0(a,i)<< " " << Bkt(a,i) << endl;
  //     for (int b = 0; b<eNN; b++)
  //       for (int j = 0; j<numDOFs; j++)
  //       {
  //         if (fabs(Ak0(a,i,b,j)-Akt(a,i,b,j)) > 1e-8)
  //           cout << "AV1 error("<<a<<","<<i<<","<<b<<","<<j<<"): "<<fabs(Ak0(a,i,b,j)-Akt(a,i,b,j))<<" "<< Ak0(a,i,b,j) << " "<<Akt(a,i,b,j) <<endl;
  //       }
  
  //   }

  Bkt = Bk0;
  Akt = Ak0;

  fillStr.addToGlobalIntegral("Ray", dEner+jac*f*u);

  if (fillStr.getBoolParameter(CoupledParams::postProcess))
  {
    tensor<double,2> Gu1 = product(nborDOFs(all,rng1), Dbf_g, {{0,0}}); // Gu1(i,J) = du_i/dX_J
    addCoarseDiff(fillStr, x, 1, dofsT(2), dofsT(3), Gu1, jac);
  }
}

// Reference autodiff assembly of LSBorder over all 45 element DOFs (slow);
// when on, the hand-written assembly is compared with it (g_borderCheck)
static bool g_borderAutodiff = false;
static double g_borderCheck[2] = {0., 0.}; // max relative difference in Bk, Ak

void LSBorder(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  using namespace autodiff;
  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);
  auto rngR1 = range(2,3);

  //============          Initialize variables           ===========//
  // Parameters
  double beta = fillStr.getRealParameter(CoupledParams::beta);
  double mu0 = fillStr.getRealParameter(CoupledParams::mu0);
  double mu1 = fillStr.getRealParameter(CoupledParams::mu1);
  double lm1 = fillStr.getRealParameter(CoupledParams::lambda1);
  double deltat = fillStr.getRealParameter(CoupledParams::deltat);
  int nS = fillStr.getIntParameter(CoupledParams::timeStep);
  bool pstPrcss = fillStr.getBoolParameter(CoupledParams::postProcess);
  bool approxStep = fillStr.getBoolParameter(CoupledParams::approxStep);

  // Background
  SubFillStructure& subFill = fillStr[0];
  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;       // Number of neighbor nodes
  int nDim = subFill.nDim;      // Number of spatial dimensions
  int pDim = subFill.pDim;      // Number of parametric dimension
  std::vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);

  tensor<double,2> nborLocCoords = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
  tensor<double,1> eC = bf*nborLocCoords;
  tensor<double,1> bf0 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
  tensor<double,1> x = bf*nborCoords;
  // ===================== Values at int. points ==================== //
  // Compute jacobian
  tensor<double,2> dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf, jac, subFill);

  // Get tangent to immersed mesh at integration point
  auto immMesh = subFill.dhandDHand->mesh->_childMesh;
  std::vector<double> t(3);
  for (int d0 = 0; d0 < nDim; d0++)
    t[d0] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+d0];
  jac = Math::Norm3D(t.data());

  // Compute unitary normal
  ttl::tensor<double,1> n(2);
  n(0) = t[1]/jac;
  n(1) = -t[0]/jac;
  n *= -1;
  // // Compute coordinates using the back mesh
  // std::vector<double> x(nDim);
  // for (int i = 0; i < eNN; i++)
  // {
  //   for (int d = 0; d < nDim; d++)
  //     x[d] += coords[nDim*i+d] * bf(i);
  // }


  ttl::tensor<double,2> Id2 = Identity2;
  // Nitsche symmetric
  double gmm0 = 0.5;
  double gmm1 = 1.-gmm0;

  // Obtain Nitsche parameter from each side
  double C02 = subFill.dhandDHand->elemAuxF->getValue("l0",subFill.elemID);
  double C12 = subFill.dhandDHand->elemAuxF->getValue("l1",subFill.elemID);
  
  gmm0 = sqrt(C12)/(sqrt(C12)+sqrt(C02));
  gmm1 = 1.-gmm0;
  // cout << gmm0+gmm1 << endl;
  double C2 = gmm0*gmm0*C02;
  // cout << C2 << "   "  << C02*C12/((sqrt(C02)+sqrt(C12))*(sqrt(C02)+sqrt(C12))) << endl;
  subFill.dhandDHand->elemAuxF->setValue("lE",subFill.elemID,IndexType::Local,C2);
  subFill.dhandDHand->elemAuxF->setValue("gmm0",subFill.elemID,IndexType::Local,gmm0);
  beta = 10.*C2;

  // Fixed beta = gamma/h (set per level in main) with stiffness weights
  bool fixedBeta = fillStr.getRealParameter(CoupledParams::beta0) > 0;
  if (fixedBeta)
  {
    beta = fillStr.getRealParameter(CoupledParams::beta);
    gmm0 = fixedBetaGmm0(mu0, mu1, lm1, deltat);
  }
  gmm1 = 1.-gmm0;

  // Coordinates
  auto rng0 = range(0,1);

  int nVoi = 3;

  map<string, double> params1{{"mu",  fillStr.getRealParameter(CoupledParams::mu1)},
                             {"lambda", fillStr.getRealParameter(CoupledParams::lambda1)}};
  // Coordinates
  auto rng1 = range(2,3);
  double vd = 0.01;
  std::vector<double> JacAD, HesAD; // reference autodiff assembly (g_borderAutodiff)
  if(g_borderAutodiff)
  {
  auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  {
    //***********************************************************
    // Initialize
    //***********************************************************

    // Rearrange DOFs 
    tensor<dual2nd,2,true>   nborDOFsd(eNN, numDOFs);
    for (int i = 0; i < eNN; i++)
    {
      for (int d = 0; d < numDOFs; d++)
      {
        nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
      }
    }

    tensor<dual2nd,1> dofsd = bf*nborDOFsd;
    tensor<dual2nd,1> u0d = {dofsd(0),dofsd(1)};
    tensor<dual2nd,1> u1d = {dofsd(2),dofsd(3)};

    tensor<dual2nd,1> pf0d = {nborDOFsd(0,4),nborDOFsd(1,4),nborDOFsd(3,4)};
    dual2nd p0d = pf0d*bf0;

    tensor<dual2nd,2> Gu0d = product(nborDOFsd(all,rngR0),dbf, {{0,0}}); // Gradient of velocities Gud(i,J) = dv_i/dX_J

    // tensor<dual2nd,2> du0d = Gu0d*Gp_i; //du0/dx
    tensor<dual2nd,2> d0d = 0.5*(Gu0d+Gu0d.T()); 
    // tensor<dual2nd,2> d0d = 0.5*(Gu0d+Gu0d.T()); 
    tensor<dual2nd,1> vdiffd = (u0d-u1d)-vd*n;

    // // Lagrangian fluid
    // tensor<dual2nd,2> F0d = deltat*Gu0d+Identity2;// Gradient deformation F(i,J) = dx_i/dX_J
    // tensor<dual2nd,2> F0d_i = F0d.inv(); // F_i(J,i) =  dX_J/dx_i
    // tensor<dual2nd,2> GuF0i = Gu0d*F0d_i;  // GuF0i(i,j) = Gu0d(i,J)*F0d_i(J,j)
    // tensor<dual2nd,2> D0D = 0.5*(GuF0i+GuF0i.T());
    // dual2nd J0d = F0d.det();



    tensor<dual2nd,2> Finc1d = deltat*product(nborDOFsd(all,rngR1), dbf, {{0,0}})+Identity2; // Fd_iJ = dx_i/dX_J
    tensor<dual2nd,2> F1d = Finc1d;// *Fp; // Fd_iJ = dx_i/dX_J
    dual2nd J1d = F1d.det(); // J = det(Fd)

    // Elastic
    // Right Cauchy-Green tensor and inverse (background)
    tensor<dual2nd,2> C1d = F1d.T()*F1d;
    tensor<dual2nd,2> F1d_i = F1d.inv();
    tensor<dual2nd,2> C1d_i = F1d_i*F1d_i.T();

    // Energy and 2nd Piola-Kirchhoff stress tensor (background)
    tensor<dual2nd,2> S1d = mu1*Id2 + (lm1*log(J1d)-mu1)*C1d_i;
    // dual2nd W1d = 0.5*lm1*log(J1d)*log(J1d) - mu1*log(J1d) + 0.5*mu1*(trace(C1d)-pDim);

    // ttl::tensor<dual2nd,2> sd = gmm1*(d1d-p1d*Id2)+gmm1*(d1d-p1d*Id2);
    tensor<dual2nd,2> P0d = (2.*mu0*d0d-p0d*Id2);
    // tensor<dual2nd,2> P0d = (2.*mu0*D0D)*F0d_i.T()*J0d;  // \sigma(i,j)*F0d_i.T(j,J)
    // P0d += -deltat*2.*mu0*(F0d_i*D0D*Gu0d*F0d_i).T()*J0d;
    // P0d += deltat*mu0*product(D0D,D0D,{{0,1},{1,0}})*F0d_i.T()*J0d;
    // P0d += -p0d*F0d_i.T()*J0d;  // \sigma(i,j)*F0d_i.T(j,J)
    // P0d += +deltat*p0d*(F0d_i*Gu0d*F0d_i).T()*J0d;
    // P0d += -deltat*p0d*product(Gu0d,F0d_i,{{0,1},{1,0}})*F0d_i.T()*J0d;
    tensor<dual2nd,2> P1d = F1d*S1d;
    // ttl::tensor<dual2nd,2> sd = gmm0*s0z+gmm1*(2.*muF*d1z-p1z*Id2);
    ttl::tensor<dual2nd,2> Pd = gmm0*P0d+gmm1*P1d;
    // tensor<dual2nd,1> jacl = J0d*n*F0d_i;
    // dual2nd jd = sqrt(jacl(0)*jacl(0)+jacl(1)*jacl(1));
    ttl::tensor<dual2nd,1> Td = Pd*n;
    dual2nd pen = jac*0.5*beta*vdiffd*vdiffd;//*jd;
    dual2nd tra = -jac*vdiffd*Td;
    if (approxStep)
      tra = 0;
    return(pen+tra);
  };

  // Compute nborDOFs as dual2nd type
  std::vector<dual2nd> dofs(eNN*numDOFs);
  for (int i = 0; i < eNN*numDOFs; i++)
  {
    dofs.at(i) = subFill.nborDOFs.at(i);
  }

  
  // Compute rayleighian, jacobian, and hessian
  dual2nd ray;
  std::vector<double> Jac(eNN*numDOFs);
  std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);
  JacAD = Jac;
  HesAD = Hes;
  }

  // Assembly of the border Rayleighian jac*(beta/2 |w|^2 - w.T), with
  // w = u0 - u1 - vd n and T = gmm0 P0 n + gmm1 P1 n. The penalty and the fluid
  // traction P0 n = 2 mu0 d0 n - p0 n are quadratic and written by hand; the
  // solid traction enters through its linearisation d(P1 n)/dv = dt H (as in
  // localNitscheEstimation) and, for the Hessian, w . d2(P1 n)/dv2, which is
  // taken by autodiff over the 18 solid velocity DOFs only.
  {
    std::vector<int> eNNp = {0,1,3}; // pressure nodes
    int n0 = eNN*numDOFs;
    tensor<double,1> dofsN = bf*nborDOFs;
    tensor<double,1> w = {dofsN(0)-dofsN(2)-vd*n(0), dofsN(1)-dofsN(3)-vd*n(1)};

    // Tractions at the current state
    tensor<double,2> Gu0 = product(nborDOFs(all,rngR0), dbf, {{0,0}}); // Gu0(i,J) = dv_i/dX_J
    double p0 = nborDOFs(0,4)*bf0(0) + nborDOFs(1,4)*bf0(1) + nborDOFs(3,4)*bf0(2);
    tensor<double,2> P0 = mu0*(Gu0+Gu0.T()) - p0*Id2;
    tensor<double,2> F1 = deltat*product(nborDOFs(all,rngR1), dbf, {{0,0}}) + Id2;
    double W1{};
    tensor<double,1> S1_v(nVoi);
    tensor<double,2> S1(pDim,pDim), C1_v(nVoi,nVoi);
    constitutiveModel_Coupled_NeoHookean(S1_v, S1, C1_v, W1, F1, params1);
    tensor<double,1> T = gmm0*(P0*n) + gmm1*((F1*S1)*n);

    // Solid traction linearisation H(a,i,j) = d(P1 n)_j/du_{a,i} (u = dt v)
    tensor<double,3> B10(nVoi, eNN, pDim);
    for (int a = 0; a < eNN; a++)
    {
      for (int i = 0; i < pDim; i++)
        B10(i,a,all) = F1(all,i)*dbf(a,i);
      B10(2,a,all) = F1(all,1)*dbf(a,0) + F1(all,0)*dbf(a,1);
    }
    tensor<double,2> b10(nVoi, pDim);
    for (int i = 0; i < pDim; i++)
      b10(i,all) = F1(all,i)*n(i);
    b10(2,all) = F1(all,1)*n(0) + F1(all,0)*n(1);
    tensor<double,1> kg = dbf*S1*n;
    tensor<double,3> H = B10.transpose({1,2,0})*(C1_v*b10);
    for (int a = 0; a < eNN; a++)
      for (int i = 0; i < pDim; i++)
        H(a,i,i) += kg(a);

    // Derivatives of w and T with respect to each element DOF q = a*numDOFs+d
    std::vector<std::array<double,2>> dw(n0, {0.,0.}), dT(n0, {0.,0.});
    for (int a = 0; a < eNN; a++)
    {
      double nDbf = dbf(a,0)*n(0) + dbf(a,1)*n(1);
      for (int i = 0; i < pDim; i++)
      {
        dw[a*numDOFs+i][i] = bf(a);
        dw[a*numDOFs+2+i][i] = -bf(a);
        for (int j = 0; j < pDim; j++)
        {
          dT[a*numDOFs+i][j] = gmm0*mu0*(nDbf*Id2(i,j) + dbf(a,j)*n(i));
          dT[a*numDOFs+2+i][j] = gmm1*deltat*H(a,i,j);
        }
      }
    }
    for (int k = 0; k < 3; k++)
      for (int j = 0; j < pDim; j++)
        dT[eNNp[k]*numDOFs+4][j] = -gmm0*bf0(k)*n(j);

    // w . d2(P1 n)/dv2 over the solid DOFs U1(a,i) -> a*2+i
    std::vector<double> Hg;
    if (!approxStep)
    {
      double wc0 = w(0), wc1 = w(1); // const ttl tensors can't be indexed in the lambda
      auto wP1n = [=](std::vector<dual2nd> U1) -> dual2nd
      {
        tensor<dual2nd,2,true> U1d(eNN, pDim);
        for (int a = 0; a < eNN; a++)
          for (int i = 0; i < pDim; i++)
            U1d(a,i) = U1[a*pDim+i];
        tensor<dual2nd,2> F1d = deltat*product(U1d, dbf, {{0,0}}) + Identity2;
        dual2nd J1d = F1d.det();
        tensor<dual2nd,2> F1d_i = F1d.inv();
        tensor<dual2nd,2> C1d_i = F1d_i*F1d_i.T();
        tensor<dual2nd,2> S1d = mu1*Id2 + (lm1*log(J1d)-mu1)*C1d_i;
        tensor<dual2nd,1> P1nd = (F1d*S1d)*n;
        return wc0*P1nd(0) + wc1*P1nd(1);
      };
      std::vector<dual2nd> U1(eNN*pDim);
      for (int a = 0; a < eNN; a++)
        for (int i = 0; i < pDim; i++)
          U1[a*pDim+i] = nborDOFs(a,2+i);
      dual2nd g;
      std::vector<double> gg(eNN*pDim);
      Hg.resize(eNN*pDim*eNN*pDim);
      hessian(wP1n, wrt(U1), at(U1), g, gg, Hg);
    }

    std::vector<double>& Bk = fillStr.Bk(0);
    std::vector<double>& Ak = fillStr.Ak(0,0);
    for (int q = 0; q < n0; q++)
    {
      double wdw = w(0)*dw[q][0] + w(1)*dw[q][1];
      Bk[q] = jac*beta*wdw;
      if (!approxStep)
        Bk[q] -= jac*(dw[q][0]*T(0) + dw[q][1]*T(1) + w(0)*dT[q][0] + w(1)*dT[q][1]);
      for (int r = 0; r < n0; r++)
      {
        double A = jac*beta*(dw[q][0]*dw[r][0] + dw[q][1]*dw[r][1]);
        if (!approxStep)
          A -= jac*(dw[q][0]*dT[r][0] + dw[q][1]*dT[r][1] + dT[q][0]*dw[r][0] + dT[q][1]*dw[r][1]);
        Ak[q*n0+r] = A;
      }
    }
    if (!approxStep)
      for (int a = 0; a < eNN; a++)
        for (int i = 0; i < pDim; i++)
          for (int b = 0; b < eNN; b++)
            for (int j = 0; j < pDim; j++)
              Ak[(a*numDOFs+2+i)*n0 + b*numDOFs+2+j] -= jac*gmm1*Hg[(a*pDim+i)*eNN*pDim + b*pDim+j];

    if (g_borderAutodiff) // check against the reference assembly
    {
      double dB = 0., dA = 0., mB = 0., mA = 0.;
      for (int q = 0; q < n0; q++)
      {
        dB = max(dB, fabs(Bk[q]-JacAD[q]));
        mB = max(mB, fabs(JacAD[q]));
        for (int r = 0; r < n0; r++)
        {
          dA = max(dA, fabs(Ak[q*n0+r]-HesAD[q*n0+r]));
          mA = max(mA, fabs(HesAD[q*n0+r]));
        }
      }
      g_borderCheck[0] = max(g_borderCheck[0], dB/max(mB,1e-300));
      g_borderCheck[1] = max(g_borderCheck[1], dA/max(mA,1e-300));
    }
  }

  // // double vd = 0.0;

  // tensor<double,1> dofs = bf*nborDOFs;
  // tensor<double,1> u0 = dofs(rngR0);
  // tensor<double,1> u1 = dofs(rngR1);
  // tensor<double,1> vdiff = (u0-u1-vd*n);

  // // Deformation gradient G = dx/dchi (from chi to x)
  // tensor<double,2> F1 = product(nborDOFs(all,rng1), dbf, {{0,0}})+Identity2;
  
  // // Constitutive model
  // double W1{};

  // tensor<double, 1> S1_v(nVoi);
  // tensor<double, 2> S1(pDim, pDim), C1_v(nVoi, nVoi);
  // tensor<double, 3> CC1(nVoi, nVoi,nVoi);
  // constitutiveModel_Coupled_NeoHookean(S1_v, S1, C1_v,CC1, W1, F1, params1);

  // tensor<double,2> P1 =  F1*S1;

  // // B0 tensor
  // tensor<double,3> B10(nVoi, eNN, pDim);
  // for (int a = 0; a < eNN; a++)
  // {
  //   for (int i = 0; i < pDim; i++)
  //     B10(i,a,all) = F1(all,i)*dbf(a,i);
  // }
  // if (pDim == 2)
  // {
  //   for (int a = 0; a < eNN; a++)
  //     B10(2,a,all) = F1(all,1)*dbf(a,0) + F1(all,0)*dbf(a,1);
  // }

  // // b0 tensor (F*n)
  // tensor<double,2> b00(nVoi, pDim);
  // for (int a = 0; a < eNN; a++)
  // {
  //   for (int i = 0; i < pDim; i++)
  //     b00(i,all) = F0(all,i)*n(i);
  // }
  // if (pDim == 2)
  // {
  //   for (int a = 0; a < eNN; a++)
  //     b00(2,all) = F0(all,1)*n(0) + F0(all,0)*n(1);
  // }
  
  
  // // b1 tensor (F*n)
  // tensor<double,2> b10(nVoi, pDim);
  // for (int a = 0; a < eNN; a++)
  // {
  //   for (int i = 0; i < pDim; i++)
  //     b10(i,all) = F1(all,i)*n(i);
  // }
  // if (pDim == 2)
  // {
  //   for (int a = 0; a < eNN; a++)
  //     b10(2,all) = F1(all,1)*n(0) + F1(all,0)*n(1);
  // }

  // // nv0 tensor (dNa*n*u)
  // tensor<double,3> nv(nVoi, eNN, pDim);
  // for (int a = 0; a < eNN; a++)
  // {
  //   for (int i = 0; i < pDim; i++)
  //     nv(i,a,all) = n(i)*vdiff(all)*dbf(a,i);
  // }
  // if (pDim == 2)
  // {
  //   for (int a = 0; a < eNN; a++)
  //     nv(2,a,all) = n(1)*vdiff(all)*dbf(a,0) + n(0)*vdiff(all)*dbf(a,1);
  // }

  // // NN tensor (dNa*dNb)
  // tensor<double,3> nn(nVoi, eNN, eNN);
  // for (int a = 0; a < eNN; a++)
  // {
  //   for (int b = 0; b < eNN; b++)
  //   {
  //     for (int i = 0; i < pDim; i++)
  //       nn(i,a,b) = dbf(b,i)*dbf(a,i);
  //   }
  // }
  // if (pDim == 2)
  // {
  //   for (int a = 0; a < eNN; a++)
  //     for (int b = 0; b < eNN; b++)
  //       nn(2,a,b) = dbf(b,1)*dbf(a,0) + dbf(b,0)*dbf(a,1);
  // }

  // // Border geometric stiffness matrix
  // tensor<double, 2> k1g = outer(dbf*S1*n,bf); // gNa*S*n*Nb

  // // Border geometric stiffness tensor
  // tensor<double,4> k1geo(eNN, pDim, eNN, pDim);

  // for (int a = 0; a < eNN; a++)
  // {
  //   for (int i = 0; i < pDim; i++)
  //   {
  //     for (int b = 0; b < eNN; b++)
  //     {
  //       for (int j = 0; j < pDim; j++)
  //       {
  //         if (i == j)
  //           k1geo(a,i,b,j) = k1g(a,b);
  //         else
  //           k1geo(a,i,b,j) = 0.;
  //       }
  //     }
  //   }
  // }

  // tensor<double,2> FnCC1 = (b10*vdiff)*CC1;

  // tensor<double,4> k1mat = product(B10.transpose({1,2,0})*C1_v,outer(bf,b10),{{2,1}}); // gNa*C*n*Nb
  

  // tensor<double,2> dD1geo =(vdiff*b10.transpose({1,0})*C1_v)*nn;

  // tensor<double,4> kdD1geo(eNN,pDim,eNN,pDim);
  // for (int a = 0; a < eNN; a++)
  // {
  //   for (int i = 0; i < pDim; i++)
  //   {
  //     for (int b = 0; b < eNN; b++)
  //     {
  //       for (int j = 0; j < pDim; j++)
  //       {
  //         if (i == j)
  //           kdD1geo(a,i,b,j) = dD1geo(a,b);
  //         else
  //           kdD1geo(a,i,b,j) = 0.;
  //       }
  //     }
  //   }
  // }


  //***********************************************************
  // Fill linear system
  //***********************************************************
  
  // // Internal stresses
  // tensor<double,2> Bk0(eNN,numDOFs);
  // tensor<double,4> Ak0(eNN,numDOFs,eNN,numDOFs);
  // Bk0 *=0;
  // Ak0 *=0;
  // for (int a = 0; a<eNN; a++)
  //   for (int i = 0; i<numDOFs; i++)
  //     for (int b = 0; b<eNN; b++)
  //       for (int j = 0; j<numDOFs; j++)
  //         Ak0(a,i,b,j) = 0;
  // for (int a = 0; a<eNN; a++)
  //   for (int i = 0; i<numDOFs; i++)
  //     Bk0(a,i) = 0;

  // Bk0(all,rng0) += jac * beta * outer(bf,Id2) * vdiff;
  // Bk0(all,rng0) -= jac * outer(bf,Id2)*(gmm0*P0+gmm1*P1)*n;
  // Bk0(all,rng0) -= jac * gmm0 * (duP0)*vdiff);
  // Bk0(all,rng0) -= jac * gmm0 *b*vdiff);

  // // R1
  // Bk0(all,rng1) -= jac * beta * outer(bf,Id2) * vdiff;
  // Bk0(all,rng1) += jac * outer(bf,Id2)*(gmm0*P0+gmm1*P1)*n;
  // Bk0(all,rng1) -= jac * gmm1 * (outer(dbf *(S1 * n),Id2)*vdiff);
  // Bk0(all,rng1) -= jac * gmm1 *(B10.transpose({1,2,0})*C1_v*b10*vdiff);

  // // K00
  // Ak0(all,rng0,all,rng0) += jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});
  // Ak0(all,rng0,all,rng1) -= jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});
  // Ak0(all,rng1,all,rng0) -= jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});
  // Ak0(all,rng1,all,rng1) += jac * beta * product(outer(bf,Id2),outer(bf,Id2),{{2,1}});

  // // dbFSNa 1.1
  // Ak0(all,rng0,all,rng0) += -jac*gmm0*k0geo.transpose({2,3,0,1});

  // // // FdbSNa 1.2
  // Ak0(all,rng0,all,rng0) += -jac*gmm0*k0mat.transpose({2,3,0,1});
 
  // // dDFFvdiff 2.1
  // Ak0(all,rng0,all,rng0) -= jac*gmm0*B00.transpose({1,2,0})*FnCC0*B00;
  // Ak0(all,rng0,all,rng0) -= jac*gmm0*kdD0geo;

  // Ak0(all,rng0,all,rng0) -= jac*gmm0*B00.transpose({1,2,0})*C0_v*nv;
  // Ak0(all,rng0,all,rng0) -= jac*gmm0*nv.transpose({1,2,0})*C0_v*B00;

  // // daFSNb 3.1
  // Ak0(all,rng0,all,rng0) += -jac*gmm0*k0geo;

  // // FdaSNb 3.2
  // Ak0(all,rng0,all,rng0) += -jac*gmm0*k0mat;

  // // K01
  // // dbFSNa 1.1
  // Ak0(all,rng1,all,rng0) += jac*gmm0*k0geo.transpose({2,3,0,1});

  // // FdbSNa 1.2
  // Ak0(all,rng1,all,rng0) += jac*gmm0*k0mat.transpose({2,3,0,1});
  
  // // daFSNb 3.1
  // Ak0(all,rng1,all,rng0) -= jac*gmm1*k1geo;

  // // FdaSNb 3.2
  // Ak0(all,rng1,all,rng0) -= jac*gmm1*k1mat;

  // // K10
  // // dbFSNa 1.1
  // Ak0(all,rng0,all,rng1) -= jac*gmm1*k1geo.transpose({2,3,0,1});

  // // FdbSNa 1.2
  // Ak0(all,rng0,all,rng1) -= jac*gmm1*k1mat.transpose({2,3,0,1});
  
  // // daFSNb 3.1
  // Ak0(all,rng0,all,rng1) += jac*gmm0*k0geo;

  // // FdaSNb 3.2
  // Ak0(all,rng0,all,rng1) += jac*gmm0*k0mat;
    
  // // // K11

  // // dbFSNa 1.1
  // Ak0(all,rng1,all,rng1) += jac*gmm1*k1geo.transpose({2,3,0,1});

  // // // FdbSNa 1.2
  // Ak0(all,rng1,all,rng1) += jac*gmm1*k1mat.transpose({2,3,0,1});
 
  // // dDFFvdiff 2.1
  // Ak0(all,rng1,all,rng1) -= jac*gmm1*B10.transpose({1,2,0})*FnCC1*B10;
  // Ak0(all,rng1,all,rng1) -= jac*gmm1*kdD1geo;

  // Ak0(all,rng1,all,rng1) -= jac*gmm1*B10.transpose({1,2,0})*C1_v*nv;
  // Ak0(all,rng1,all,rng1) -= jac*gmm1*nv.transpose({1,2,0})*C1_v*B10;

  // // dbFSNa 1.1
  // Ak0(all,rng1,all,rng1) += jac*gmm1*k1geo;

  // // // FdbSNa 1.2
  // Ak0(all,rng1,all,rng1) += jac*gmm1*k1mat;


  // ttl::wrapper<double,2> Bkt(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2

  // ttl::wrapper<double,4> Akt(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  // Akt = Ak0;
  // Bkt = Bk0;

  
  tensor<double,1> dofs = bf*nborDOFs;
  tensor<double,1> u0 = {dofs(0),dofs(1)};
  tensor<double,1> u1 = {dofs(2),dofs(3)};

  tensor<double,1> pf0 = {nborDOFs(0,4),nborDOFs(1,4),nborDOFs(3,4)};
  double p0 = pf0*bf0;
  // cout <<"B: "<< x << p0 << endl;
  tensor<double,2> Gu0 = product(nborDOFs(all,rngR0),dbf, {{0,0}}); // Gradient of velocities Gud(i,J) = dv_i/dX_J
 
  tensor<double,1> vdiff = (u0-u1)-vd*n;

  // // Lagrangian fluid
  // tensor<double,2> F0 = deltat*Gu0+Identity2;// Gradient deformation F(i,J) = dx_i/dX_J
  // tensor<double,2> F0_i = F0.inv(); // F_i(J,i) =  dX_J/dx_i
  // tensor<double,2> GuF0i = Gu0*F0_i;  // GuF0i(i,j) = Gu0d(i,J)*F0d_i(J,j)
  // tensor<double,2> D0 = 0.5*(GuF0i+GuF0i.T());
  tensor<double,2> d0 = 0.5*(Gu0+Gu0.T());
  // double J0 = F0.det();



  tensor<double,2> F1 = deltat*product(nborDOFs(all,rngR1), dbf, {{0,0}})+Identity2; // Fd_iJ = dx_i/dX_J
  // tensor<double,2> F1 = Finc1// *Fp; // Fd_iJ = dx_i/dX_J
  double J1 = F1.det(); // J = det(Fd)

  // Elastic
  // Right Cauchy-Green tensor and inverse (background)
  tensor<double,2> C1 = F1.T()*F1;
  tensor<double,2> F1_i = F1.inv();
  tensor<double,2> C1_i = F1_i*F1_i.T();

  // Energy and 2nd Piola-Kirchhoff stress tensor (background)
  tensor<double,2> S1 = mu1*Id2 + (lm1*log(J1)-mu1)*C1_i;
  // double W1d = 0.5*lm1*log(J1d)*log(J1d) - mu1*log(J1d) + 0.5*mu1*(trace(C1)-pDim);

  // ttl::tensor<double,2> sd = gmm1*(d1d-p1d*Id2)+gmm1*(d1d-p1d*Id2);
  // tensor<double,2> P0 = (2.*mu0*d0-p0*Id2); //eulerian fluid
  // tensor<double,2> P0 = (2.*mu0*D0-p0*Id2)*F0_i.T()*J0;  // \sigma(i,j)*F0d_i.T(j,J)
  // P0 += -deltat*2.*mu0*(F0_i*D0*Gu0*F0_i).T()*J0;
  // P0 += deltat*mu0*product(D0,D0,{{0,1},{1,0}})*F0_i.T()*J0;
  // P0 += +deltat*p0*(F0_i*Gu0*F0_i).T()*J0;
  // P0 += -deltat*p0*product(Gu0,F0_i,{{0,1},{1,0}})*F0_i.T()*J0;
  tensor<double,2> P0 = (2.*mu0*d0-p0*Id2);
  // tensor<double,2> P0 = (2.*mu0*D0)*F0_i.T()*J0;  // \sigma(i,j)*F0d_i.T(j,J)
  // P0 += -deltat*2.*mu0*(F0_i*D0*Gu0*F0_i).T()*J0;
  // P0 += deltat*mu0*product(D0,D0,{{0,1},{1,0}})*F0_i.T()*J0;
  // P0 += -p0*F0_i.T()*J0;  // \sigma(i,j)*F0d_i.T(j,J)
  // P0 += +deltat*p0*(F0_i*Gu0*F0_i).T()*J0;
  // P0 += -deltat*p0*product(Gu0,F0_i,{{0,1},{1,0}})*F0_i.T()*J0;
  tensor<double,2> P1 = F1*S1;
  // ttl::tensor<double,2> sd = gmm0*s0z+gmm1*(2.*muF*d1z-p1z*Id2);
  tensor<double,2> P = gmm0*P0+gmm1*P1;

  tensor<double,1> T0 = P0*n;
  tensor<double,1> T1 = P1*n;
  tensor<double,1> TMu0 = 2.*mu0*d0*n;//(2.*mu0*D0*F0_i.T()*J0)*n;
  tensor<double,1> Tp0 = -p0*Id2*n; //-p0*Id2*F0_i.T()*J0*n;

  // tensor<double,1> jacl = J0*n*F0_i;
  // double jl = sqrt(jacl(0)*jacl(0)+jacl(1)*jacl(1));

  fillStr.addToGlobalIntegral("Ray",jac*0.5*beta*vdiff*vdiff -  jac*(gmm0*P0*n+gmm1*P1*n)*vdiff);
  if (pstPrcss)
  {
    // Output integration points
    ofstream myfile;
    if (!fileExists("Border"+to_string(nS)+".csv"))
    {
      myfile.open("Border"+to_string(nS)+".csv", std::ios_base::app);
      myfile << "x(0)" << "," << "x(1)" << "," << "nx" <<  "," << "ny" << "," << "TxMu0" <<  "," << "TyMu0" <<  "," << "Tpx0" <<  "," << "Tpy0" <<  "," << "Tx1" <<  "," << "Ty1" << endl;
      myfile.close();
    }
    myfile.open("Border"+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x(0) << "," << x(1) <<"," << n(0) <<"," << n(1) << "," << TMu0(0) <<"," << TMu0(1) << "," << Tp0(0) <<"," << Tp0(1) << "," << T1(0) <<"," << T1(1) << endl;
    myfile.close();



    // Save local length
    fillStr.addToGlobalIntegral("uErr", jac*vdiff*vdiff);
    // fillStr.addToGlobalIntegral("pErr", jac *(p0-p1)*(p0-p1))
    fillStr.addToGlobalIntegral("duErr", jac*(P0*n-P1*n)*(P0*n-P1*n));
    fillStr.addToGlobalIntegral("tErr", jac*(P*n)*(P*n));
    // fillStr.addToGlobalIntegral("MduErr", jac*(gmm0*P0*n+gmm1*P1*n-PAn*n)*(gmm0*P0*n+gmm1*P1*n-PAn*n));

    fillStr.addToGlobalIntegral("Length", jac);

    // Averaged traction against the previous level, at the same point and normal:
    // fluid 2 mu0 d - p I, solid F S with F = I + dt grad v
    if (g_coarse.valid)
    {
      double uc[2], Gc[2][2], pc;
      int elc[2];
      tensor<double,1> tc(2);
      tc(0) = 0.;
      tc(1) = 0.;
      bool ok = true;
      double g0c = 0.;
      for (int r = 0; r < 2 && ok; r++)
      {
        ok = evalCoarse(x.data(), r, uc, Gc, pc, elc[r]);
        if (!ok)
          break;
        tensor<double,2> Pc(2,2);
        if (r == 0)
        {
          g0c = fixedBeta ? fixedBetaGmm0(mu0, mu1, lm1, deltat)
                          : g_coarse.dh->elemAuxF->getValue("gmm0", elc[0], IndexType::Global);
          tensor<double,2> dc = {{Gc[0][0], 0.5*(Gc[0][1]+Gc[1][0])}, {0.5*(Gc[0][1]+Gc[1][0]), Gc[1][1]}};
          Pc = 2.*mu0*dc - pc*Id2;
        }
        else
        {
          tensor<double,2> Fc = {{1.+deltat*Gc[0][0], deltat*Gc[0][1]}, {deltat*Gc[1][0], 1.+deltat*Gc[1][1]}};
          double Wc{};
          tensor<double,1> Sc_v(nVoi);
          tensor<double,2> Sc(pDim,pDim), Cc_v(nVoi,nVoi);
          constitutiveModel_Coupled_NeoHookean(Sc_v, Sc, Cc_v, Wc, Fc, params1);
          Pc = Fc*Sc;
        }
        tc += (r == 0 ? g0c : 1.-g0c)*Pc*n;
      }
      if (ok)
      {
        tensor<double,1> dt = P*n - tc;
        fillStr.addToGlobalIntegral("dtErr", jac*dt*dt);
      }
      else
        fillStr.addToGlobalIntegral("dMiss", jac);
    }
    // fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));
  }
}

void LSF0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;

  int nS = fillStr.getIntParameter(CoupledParams::timeStep);

  auto rngCoords = range(0,1);
  std::vector<int> nxt = {8, 16, 32, 64, 128};

  
  SubFillStructure& subFill = fillStr["backDHand"];

  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;       // Number of neighbor nodes
  int nDim = subFill.nDim;      // Number of spatial dimensions
  int pDim = subFill.pDim;      // Number of parametric dimension
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  double jac;
  ttl::tensor<double,2> Dbf_g(eNN,pDim); // dbf(a,i)
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  double tau = 2./double(nxt[nS]);

  // Basis functions top
  tensor<double,2> bft = {{1.,0.5*(-sqrt(1./3.)+1.),1.},{1.,0.5*(sqrt(1./3.)+1.),1.}};
  
  // Basis functions bottom
  tensor<double,2> bfb = {{1.,0.5*(-sqrt(1./3.)+1.)},{1.,0.5*(sqrt(1./3.)+1.)}};

  // Basis functions right
  tensor<double,2> bfr = {{1.,1.,0.5*(-sqrt(1./3.)+1.)},{1.,1.,0.5*(sqrt(1./3.)+1.)}};

  // Basis functions left
  tensor<double,2> bfl = {{1.,0.5*(-sqrt(1./3.)+1.)},{1.,0.5*(sqrt(1./3.)+1.)}};
  int stbF = subFill.dhandDHand->elemAuxF->getValue("stbP",subFill.loc_elemID,IndexType::Local);

  tensor<double,1> pf1 = {nborDOFs(0,4),nborDOFs(1,4),nborDOFs(3,4)};
  tensor<double,1> pf1l = {nborDOFs(2,4),nborDOFs(5,4)};
  tensor<double,1> pf1b = {nborDOFs(6,4),nborDOFs(7,4)};

  ttl::wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN, numDOFs);     // 9 * 2
  ttl::wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN, numDOFs, eNN, numDOFs);     // 9 * 2
  for (int a{}; a < eNN; a++)
  {
    for (int i{}; i < numDOFs; i++)
    {
      Bk(a,i) = 0;
      for (int b{}; b < eNN; b++)
      {
        for (int j{}; j < numDOFs; j++)
        {
          Ak(a,i,b,j) = 0;
        }
      }
    }
  }
  double ray = 0;

  // Integrate right face
  if (stbF%3 == 0)
  {
    tensor<double,1> pr = bfr*pf1;
    tensor<double,1> pl = bfl*pf1l;
    
    for (int k{}; k < 2; k++)
    {
      ray += sqrt(jac)*0.5*tau*(pr(k)-pl(k))*(pr(k)-pl(k));

      tensor<double,1> bflr(9);
      bflr(0) = bfr(k,0);
      bflr(1) = bfr(k,1);
      bflr(2) = -bfl(k,0);
      bflr(3) = bfr(k,2);
      bflr(4) = 0.;
      bflr(5) = -bfl(k,1);
      bflr(6) = 0.;
      bflr(7) = 0.;
      bflr(8) = 0.;

      for (int a{}; a < eNN; a++)
      {
        Bk(a,4) -= sqrt(jac)*tau*bflr(a)*(pr(k)-pl(k));
        for (int b{}; b < eNN; b++)
        {
          Ak(a,4,b,4) -= sqrt(jac)*tau*bflr(a)*bflr(b);
        }
      }
    }
  }

  // Integrate top face
  if (stbF%5 == 0)
  {
    tensor<double,1> pt = bft*pf1;
    tensor<double,1> pb = bfb*pf1b;
    
    for (int k{}; k < 2; k++)
    {
      ray += sqrt(jac)*0.5*tau*(pt(k)-pb(k))*(pt(k)-pb(k));

      tensor<double,1> bftb(9);
      bftb(0) = bft(k,0);
      bftb(1) = bft(k,1);
      bftb(2) = 0.;
      bftb(3) = bft(k,2);
      bftb(4) = 0.;
      bftb(5) = 0;
      bftb(6) = -bfb(k,0);
      bftb(7) = -bfb(k,1);
      bftb(8) = 0.;

      for (int a{}; a < eNN; a++)
      {
        Bk(a,4) -= sqrt(jac)*tau*bftb(a)*(pt(k)-pb(k));
        for (int b{}; b < eNN; b++)
        {
          Ak(a,4,b,4) -= sqrt(jac)*tau*bftb(a)*bftb(b);
        }
      }
    }
  }

}


void LSPre(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace hiperlife::Tensor;

  SubFillStructure& subFill = fillStr[0];

  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int numAuxF  = subFill.numAuxF;   // Number of degrees of freedom
  int eNN  = subFill.eNN;       // Number of neighbor nodes
  int nDim = subFill.nDim;      // Number of spatial dimensions
  int pDim = subFill.pDim;      // Number of parametric dimension
  ttl::wrapper<double,2> nborAuxF(subFill.nborAuxF.data(), eNN, numAuxF);

  std::vector<double> b0 = {-1};
  std::vector<std::vector<double>>& pbf0 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b0, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

  std::vector<double> bf1 ={pbf0[0][0],pbf0[0][1],pbf0[0][2],pbf0[0][3]}; 
  std::vector<double> b1 = {1};
  std::vector<std::vector<double>>& pbf1 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b1, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

  std::vector<double> bf2 ={pbf1[0][0],pbf1[0][1],pbf1[0][2],pbf1[0][3]}; 

  // Get output
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  Bk(1,0) = nborAuxF(1,0);
  Bk(1,1) = nborAuxF(1,1);
  Bk(2,0) = nborAuxF(2,0);
  Bk(2,1) = nborAuxF(2,1);
  for (int a = 0; a<eNN; a++)
  {
    Ak(a,0,1,0) = bf1[a];
    Ak(a,1,1,1) = bf1[a];

    Ak(a,0,2,0) = bf2[a];
    Ak(a,1,2,1) = bf2[a];
  }
}


void genCircBspline(double r, std::vector<double> &U,std::vector<std::vector<std::vector<std::vector<double>>>> &CP, double xOff, double yOff, ElemType eTypeB,BasisFuncType bTypeB,int bfOrderB,int nPtsCircOr,SmartPtr<ParamStructure> paramStr)
{
  // Compute immersed mesh CPs position
  SmartPtr<StructMeshGenerator> preBSMesh = Create<StructMeshGenerator>();

  preBSMesh->setMesh(eTypeB, bTypeB, bfOrderB);
  
  std::vector<double> preU(nPtsCircOr+1,0);
  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    preU[i] = preU[i-1]+1;
  }
  
  std::vector<std::vector<std::vector<std::vector<double>>>> preCP(nPtsCircOr, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
  for (int k = 0;  k < nPtsCircOr; k++)
  {
    double t = 2*M_PI*k/nPtsCircOr;
    preCP[k][0][0] = {std::cos(t),std::sin(t),0,0};
  }
  
  preBSMesh->genBsplinesClosedCurve(preU,preCP);
  // Distributed mesh
  SmartPtr<DistributedMesh> preDisBSMesh = Create<DistributedMesh>("preDisBSMesh");
  preDisBSMesh->setMesh(preBSMesh);
  preDisBSMesh->setBalanceMesh(true);
  preDisBSMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
  preDisBSMesh->setVerbosity(Verbosity::None);
  preDisBSMesh->Update();
  
  // Set Degree of Freedom handler
  SmartPtr<DOFsHandler> preDhand = Create<DOFsHandler>(preDisBSMesh);
  preDhand->setNameTag("preDhand");
  preDhand->setNumDOFs(2);
  preDhand->setDOFs({"pcx","pcy"});
  preDhand->setNodeAuxF({"x","y","dxdt","dydt"});
  preDhand->Update();


  std::vector<double> cw = {1};
  for (int i = 0; i<preDisBSMesh->nPts();i++)
  {
    double t = 2.*M_PI*double(i)/double(nPtsCircOr);
    double x = xOff;
    double y = yOff;
    for (int iw = 0; iw<cw.size(); iw++)
    {
      x += cw[iw]*cos((iw+1)*t)*r;
      y += cw[iw]*sin((iw+1)*t)*r;
    }
    preDhand->nodeAuxF->setValue(0,i,IndexType::Global,x);
    preDhand->nodeAuxF->setValue(1,i,IndexType::Global,y);
  }

  SmartPtr<HiPerProblem> preHiperProbl = Create<HiPerProblem>();
  preHiperProbl->setParameterStructure(paramStr);
  preHiperProbl->setDOFsHandlers({preDhand});
  
  // Interface integration
  preHiperProbl->setIntegration("IntegPre", {"preDhand"});
  preHiperProbl->setCubatureGauss("IntegPre", 1);
  preHiperProbl->setElementFillings("IntegPre", LSPre);

  preHiperProbl->Update();

  SmartPtr<MUMPSDirectLinearSolver> preSolver = Create<MUMPSDirectLinearSolver>();
  preSolver->setHiPerProblem(preHiperProbl);
  preSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
  preSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
  preSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Sequential);
  preSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
  preSolver->setConvergenceCriteria(MUMPSDirectLinearSolver::ConvergenceCriteria::Relative);
  preSolver->setTolerance(1e-8);
  preSolver->setDefaultParameters();
  preSolver->Update();

  // Solve
  preSolver->solve();
  preHiperProbl->UpdateGhosts();

  // Update Solution
  preSolver->UpdateSolution();

  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
    U[i] = U[i-1]+1.;
  }

  for (int k = 0;  k < nPtsCircOr; k++)
  {  
    double x = preDhand->nodeDOFs->getValue(0,k,IndexType::Global);
    double y = preDhand->nodeDOFs->getValue(1,k,IndexType::Global);
    CP[k][0][0] = {x,y,0,0};
  }
}

void FacetStbR0(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    int nS = fillStr.getIntParameter(CoupledParams::timeStep);

    SubFillStructure& e0 = fillStr[0];
    SubFillStructure& e1 = fillStr[1];
    int eNN  = e0.eNN;
    int nDim = e0.nDim;
    int pDim = e0.pDim;
    int numDOFs = e0.numDOFs;
    // double gmm2 = 0.01;
    double* Dbf0    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
    double* bf0    = e0.nborBFs();      // local BF: [eNN]
    double* bf1    = e1.nborBFs();      // local BF: [eNN]
    double* coords0 = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]
    double* coords1 = e1.nborCoords.data();   // node coordinates:     [eNN × nDim]

    ttl::wrapper<double,2> nborDOFs0(e0.nborDOFs.data(), eNN, numDOFs);
    ttl::wrapper<double,2> nborDOFs1(e1.nborDOFs.data(), eNN, numDOFs);

    double h = fabs(coords0[0]-coords0[(eNN-1)*nDim]);
    double gmm1 = 0.1;
    double gmm2 = 0.1;

    // cout << h << endl;
    // Reference tangent vector along the boundary side (length pDim)
    std::vector<double> tangRef = e0.tangentsBoundaryRef();

    // Push tangRef through the Jacobian to obtain the physical tangent
    //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
    //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
    std::vector<double> tangPhys(nDim, 0.0);
    for (int a = 0; a < nDim; a++)
    {
      for (int b = 0; b < pDim; b++)
      {
        double Jab = 0.0;
        for (int i = 0; i < eNN; i++)
          Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
        tangPhys[a] += Jab * tangRef[b];
      }
    }
    tensor<double,1> x0(2);
    x0 *=0;
    tensor<double,1> x1(2);
    x1 *=0;
    for (int a = 0; a < eNN; a++)
    {
      for (int i = 0; i < pDim; i++)
      {
        x0(i) += bf0[a]*coords0[a*nDim + i];
        x1(i) += bf1[a]*coords1[a*nDim + i];
      }
    }

    tensor<double,2> dbf(9,2);

    for (int a = 0; a < eNN; a++)
    {
      for (int i = 0; i < pDim; i++)
      {
        dbf(a,i) = Dbf0[a*pDim + i];
      }
    }
    
    double edge_jac = 0.0;
    for (double t : tangPhys) edge_jac += t * t;
    edge_jac = std::sqrt(edge_jac);

    // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
    tensor<double,1> n(2);
    // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
    n(0) = tangPhys[1]/edge_jac;
    n(1) = -tangPhys[0]/edge_jac;
    // cout << "N: " << n<<endl;

    tensor<double,2> gDbf0(eNN,pDim);
    tensor<double,3> gHbf0(eNN,pDim,pDim);
    tensor<double,1> gLbf0(eNN);
    double jac0;
    // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);

    tensor<double,1> HbfN0(eNN);
    GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
    tensor<double,1> DbfN0 = gDbf0*n;

    tensor<double,2> gDbf1(eNN,pDim);
    tensor<double,3> gHbf1(eNN,pDim,pDim);
    tensor<double,1> gLbf1(eNN);
    double jac1;
    // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);

    tensor<double,1> HbfN1(eNN);
    GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
    tensor<double,1> DbfN1 = gDbf1*n;
    tensor<double,1> Dbfu0 = DbfN0*nborDOFs0;
    tensor<double,1> Dbfu1 = DbfN1*nborDOFs1;
    
    for (int a = 0; a < eNN; a++)
    {
      if (fabs(n(0))>fabs(n(1))) // Vertical face
      {
        HbfN0(a) = gHbf0(a,0,0);
        HbfN1(a) = gHbf1(a,0,0);
      }
      else // Horizontal face
      {
        HbfN0(a) = gHbf0(a,1,1);
        HbfN1(a) = gHbf1(a,1,1);
      }
    }
    tensor<double,1> Hbfu0 = HbfN0*nborDOFs0;
    tensor<double,1> Hbfu1 = HbfN1*nborDOFs1;
    // cout << xl0 << ", " << xl1<< DbfN0 << DbfN1 << endl;
    // cout << dbf << n << dbf*n << endl;
    tensor<double,2,false> Bk0(fillStr.Bk(0).data(),eNN,numDOFs);
    tensor<double,2,false> Bk1(fillStr.Bk(1).data(),eNN,numDOFs);
    Bk0 *=0;
    Bk1 *=0;
              
    tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
    Ak00 *=0;
    Ak01 *=0;
    Ak10 *=0;
    Ak11 *=0;
    for (int i = 0; i < 2; i++)
    {
      for (int a = 0; a < eNN; a++)
      {
        Bk0(a,i) += 2.*edge_jac*h*gmm1*(DbfN0(a)*Dbfu0(i)) - 2.*edge_jac*h*gmm1*(DbfN0(a)*Dbfu1(i));
        Bk1(a,i) += -2.*edge_jac*h*gmm1*(DbfN1(a)*Dbfu0(i)) + 2.*edge_jac*h*gmm1*(DbfN1(a)*Dbfu1(i));
        if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
        {
          Bk0(a,i) += 2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*Hbfu0(i)) - 2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*Hbfu1(i));
          Bk1(a,i) += - 2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*Hbfu0(i)) + 2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*Hbfu1(i));
        }

        for (int b = 0; b < eNN; b++)
        {
          Ak00(a,i,b,i) += 2.*edge_jac*h*gmm1*(DbfN0(a)*DbfN0(b));
          Ak01(a,i,b,i) += -2.*edge_jac*h*gmm1*(DbfN0(a)*DbfN1(b));
          Ak10(a,i,b,i) += -2.*edge_jac*h*gmm1*(DbfN1(a)*DbfN0(b));
          Ak11(a,i,b,i) += 2.*edge_jac*h*gmm1*(DbfN1(a)*DbfN1(b));

          if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
          {
            Ak00(a,i,b,i) += 2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
            Ak01(a,i,b,i) += -2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
            Ak10(a,i,b,i) += -2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
            Ak11(a,i,b,i) += 2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
          }
        }   
      }
    }

      for (int a = 0; a < numDOFs; a++) {
      if (std::isnan(Dbfu0(a)) || std::isinf(Dbfu0(a)))
          std::cout << "NaN/Inf in Dbfu0 at element " << e0.elemID << std::endl;
      if (std::isnan(Dbfu1(a)) || std::isinf(Dbfu1(a)))
          std::cout << "NaN/Inf in Dbfu1 at element " << e0.elemID << std::endl;
      }
      // 2. Zero or negative edge_jac
      if (edge_jac <= 0)
          std::cout << "Bad edge_jac: " << edge_jac << " at edge " << e0.elemID << std::endl;
      // 3. Zero h
      if (h <= 0)
        std::cout << "Bad h: " << h << " at edge " << e0.elemID << std::endl;
    // Ak00 *=-1;
    // Ak01 *=-1;
    // Ak10 *=-1;
    // Ak11 *=-1;
    // cout <<  Ak00 << Ak01 << Ak10 << Ak11 << endl;
    // cout <<  Bk0 << Bk1 << endl;
    fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
    // cout << e0.kPt << " " <<e1.kPt << endl;
    ofstream myfile;
    myfile.open("fStb0."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
    myfile.close();

    myfile.open("fStb1."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
    myfile.close();

}

void FacetStbR1(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife;
    int nS = fillStr.getIntParameter(CoupledParams::timeStep);

    SubFillStructure& e0 = fillStr[0];
    SubFillStructure& e1 = fillStr[1];
    int eNN  = e0.eNN;
    int nDim = e0.nDim;
    int pDim = e0.pDim;
    int numDOFs = e0.numDOFs;
    // double gmm2 = 0.;
    double* Dbf0    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
    double* bf0    = e0.nborBFs();      // local BF: [eNN]
    double* bf1    = e1.nborBFs();      // local BF: [eNN]
    double* coords0 = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]
    double* coords1 = e1.nborCoords.data();   // node coordinates:     [eNN × nDim]

    ttl::wrapper<double,2> nborDOFs0(e0.nborDOFs.data(), eNN, numDOFs);
    ttl::wrapper<double,2> nborDOFs1(e1.nborDOFs.data(), eNN, numDOFs);
    double h = fabs(coords0[0]-coords0[(eNN-1)*nDim]);
    double gmm1 = 0.1;
    double gmm2 = 0.1;

    // cout << h << endl;
    // Reference tangent vector along the boundary side (length pDim)
    std::vector<double> tangRef = e0.tangentsBoundaryRef();

    // Push tangRef through the Jacobian to obtain the physical tangent
    //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
    //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
    std::vector<double> tangPhys(nDim, 0.0);
    for (int a = 0; a < nDim; a++)
    {
      for (int b = 0; b < pDim; b++)
      {
        double Jab = 0.0;
        for (int i = 0; i < eNN; i++)
          Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
        tangPhys[a] += Jab * tangRef[b];
      }
    }
    tensor<double,1> x0(2);
    x0 *=0;
    tensor<double,1> x1(2);
    x1 *=0;
    for (int a = 0; a < eNN; a++)
    {
      for (int i = 0; i < pDim; i++)
      {
        x0(i) += bf0[a]*coords0[a*nDim + i];
        x1(i) += bf1[a]*coords1[a*nDim + i];
      }
    }

    tensor<double,2> dbf(9,2);
    for (int a = 0; a < eNN; a++)
    {
      for (int i = 0; i < pDim; i++)
      {
        dbf(a,i) = Dbf0[a*pDim + i];
      }
    }
    
    double edge_jac = 0.0;
    for (double t : tangPhys) edge_jac += t * t;
    edge_jac = std::sqrt(edge_jac);

    // cout << tangPhys[0] << ", " << tangPhys[1] << endl; 
    tensor<double,1> n(2);
    // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
    n(0) = tangPhys[1]/edge_jac;
    n(1) = -tangPhys[0]/edge_jac;
    // cout << "N: " << n<<endl;

    tensor<double,2> gDbf0(eNN,pDim);
    tensor<double,3> gHbf0(eNN,pDim,pDim);
    tensor<double,1> gLbf0(eNN);
    double jac0;
    // GlobalBasisFunctions::gradients(gDbf0, jac0, e0);

    tensor<double,1> HbfN0(eNN);
    GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
    tensor<double,1> DbfN0 = gDbf0*n;

    tensor<double,2> gDbf1(eNN,pDim);
    tensor<double,3> gHbf1(eNN,pDim,pDim);
    tensor<double,1> gLbf1(eNN);
    double jac1;
    // GlobalBasisFunctions::gradients(gDbf1, jac1, e1);

    tensor<double,1> HbfN1(eNN);
    GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
    tensor<double,1> DbfN1 = gDbf1*n;

    tensor<double,1> Dbfu0 = DbfN0*nborDOFs0;
    tensor<double,1> Dbfu1 = DbfN1*nborDOFs1;
    
    for (int a = 0; a < eNN; a++)
    {
      if (fabs(n(0))>fabs(n(1))) // Vertical face
      {
        HbfN0(a) = gHbf0(a,0,0);
        HbfN1(a) = gHbf1(a,0,0);
      }
      else // Horizontal face
      {
        HbfN0(a) = gHbf0(a,1,1);
        HbfN1(a) = gHbf1(a,1,1);
      }
    }
    tensor<double,1> Hbfu0 = HbfN0*nborDOFs0;
    tensor<double,1> Hbfu1 = HbfN1*nborDOFs1;
    // cout << xl0 << ", " << xl1<< DbfN0 << DbfN1 << endl;
    // cout << dbf << n << dbf*n << endl;
    tensor<double,2,false> Bk0(fillStr.Bk(0).data(),eNN,numDOFs);
    tensor<double,2,false> Bk1(fillStr.Bk(1).data(),eNN,numDOFs);
    Bk0 *=0;
    Bk1 *=0;
              
    tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);
    Ak00 *=0;
    Ak01 *=0;
    Ak10 *=0;
    Ak11 *=0;
    for (int i = 2; i < 4; i++)
    {
      for (int a = 0; a < eNN; a++)
      {
          Bk0(a,i) += 2.*edge_jac*h*gmm1*(DbfN0(a)*Dbfu0(i)) - 2.*edge_jac*h*gmm1*(DbfN0(a)*Dbfu1(i));
          Bk1(a,i) += -2.*edge_jac*h*gmm1*(DbfN1(a)*Dbfu0(i)) + 2.*edge_jac*h*gmm1*(DbfN1(a)*Dbfu1(i));
          if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
          {
            Bk0(a,i) += 2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*Hbfu0(i)) - 2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*Hbfu1(i));
            Bk1(a,i) += - 2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*Hbfu0(i)) + 2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*Hbfu1(i));
          }
        for (int b = 0; b < eNN; b++)
        {
          Ak00(a,i,b,i) += 2.*edge_jac*h*gmm1*(DbfN0(a)*DbfN0(b));
          Ak01(a,i,b,i) += -2.*edge_jac*h*gmm1*(DbfN0(a)*DbfN1(b));
          Ak10(a,i,b,i) += -2.*edge_jac*h*gmm1*(DbfN1(a)*DbfN0(b));
          Ak11(a,i,b,i) += 2.*edge_jac*h*gmm1*(DbfN1(a)*DbfN1(b));

          if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
          {
            
            Ak00(a,i,b,i) += 2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
            Ak01(a,i,b,i) += -2.*edge_jac*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
            Ak10(a,i,b,i) += -2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
            Ak11(a,i,b,i) += 2.*edge_jac*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
          }
        }   
      }
    }
    // Ak00 *=-1;
    // Ak01 *=-1;
    // Ak10 *=-1;
    // Ak11 *=-1;

    fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
    // cout << e0.kPt << " " <<e1.kPt << endl;
    ofstream myfile;
    myfile.open("fStb00."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
    myfile.close();

    myfile.open("fStb11."+to_string(nS)+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
    myfile.close();

}

// Largest lambda of A x = lambda B x (A: boundary traction term of K, B: patch
// bulk operator), robust to the near-singular directions of B:
//  1. Jacobi scaling D = diag(B)^-1/2, so the null-space threshold below is
//     relative to each DOF's own bulk control (cut fraction / element size
//     no longer spread the spectrum of B over many orders of magnitude).
//  2. The rigid modes Rm (columns, unscaled) are projected out explicitly:
//     there both A and B vanish (0/0), which a threshold only catches by luck.
//  3. On the remaining space B is reduced to its eigenvalues > relTol*max and
//     the problem becomes the symmetric Lambda^-1/2 V^T A V Lambda^-1/2:
//     no Cholesky, deterministic, exact for the reduced problem.
// Returns 0 if B has no range left. nUncontrolled counts DOFs that A sees but
// B does not (no bulk control at all -- they are dropped, so the estimate is
// not a bound for them).
double nitscheEigenEstimate(const Eigen::MatrixXd& A, const Eigen::MatrixXd& B, const Eigen::MatrixXd& Rm,
                            int& nUncontrolled, double relTol = 1e-8)
{
  int n = B.rows();
  nUncontrolled = 0;
  if (n == 0)
    return 0.;

  double maxDiagB = B.diagonal().maxCoeff();
  double maxDiagA = A.diagonal().cwiseAbs().maxCoeff();
  if (!(maxDiagB > 0.))
    return 0.;

  Eigen::VectorXd d(n), dInv(n);
  for (int i = 0; i < n; i++)
  {
    if (B(i,i) > 1e-14*maxDiagB)
    {
      d(i) = 1./sqrt(B(i,i));
      dInv(i) = sqrt(B(i,i));
    }
    else
    {
      d(i) = 0.;
      dInv(i) = 0.;
      if (fabs(A(i,i)) > 1e-12*maxDiagA)
        nUncontrolled++;
    }
  }
  Eigen::MatrixXd As = d.asDiagonal()*A*d.asDiagonal();
  Eigen::MatrixXd Bs = d.asDiagonal()*B*d.asDiagonal();

  // Orthonormal complement of the (scaled) rigid modes
  Eigen::MatrixXd Rs = dInv.asDiagonal()*Rm;
  Eigen::ColPivHouseholderQR<Eigen::MatrixXd> qr(Rs);
  qr.setThreshold(1e-10);
  int r = qr.rank();
  Eigen::MatrixXd Q = qr.householderQ();
  Eigen::MatrixXd Cc = Q.rightCols(n - r);

  Eigen::MatrixXd Bc = Cc.transpose()*Bs*Cc;
  Eigen::MatrixXd Ac = Cc.transpose()*As*Cc;
  Bc = 0.5*(Bc + Bc.transpose());
  Ac = 0.5*(Ac + Ac.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> bes(Bc);
  const Eigen::VectorXd& bEv = bes.eigenvalues();
  double bMax = bEv.maxCoeff();
  if (!(bMax > 0.))
    return 0.;
  std::vector<int> keep;
  for (int i = 0; i < bEv.size(); i++)
    if (bEv(i) > relTol*bMax)
      keep.push_back(i);
  if (keep.empty())
    return 0.;

  Eigen::MatrixXd W(Bc.rows(), keep.size());
  for (size_t j = 0; j < keep.size(); j++)
    W.col(j) = bes.eigenvectors().col(keep[j])/sqrt(bEv(keep[j]));
  Eigen::MatrixXd S = W.transpose()*Ac*W;
  S = 0.5*(S + S.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> ses(S, Eigen::EigenvaluesOnly);
  return ses.eigenvalues().maxCoeff();
}

// Clamp of the eigen estimate around the geometric estimate
// C_geo = k_i*|Gamma_K|/|Omega_patch|, k0 = 2 mu0 (fluid), k1 = dt (lambda1+2 mu1) (solid): lambda in [g_nitscheGeoLo, g_nitscheGeoHi]*C_geo.
// The upper cap is wide and only meant to catch garbage (too small a penalty
// loses coercivity); the per-call summary prints the actual lambda/C_geo range.
static const double g_nitscheGeoLo = 0.1;
static const double g_nitscheGeoHi = 1e5;

void localNitscheEstimation(SmartPtr<HiPerProblem> immHP, SmartPtr<DOFsHandler> backDHand, SmartPtr<ParamStructure> paramStr, SmartPtr<DistributedMesh> immMesh)
{
  using ttl::all;

  // Distributed mesh
  SmartPtr<DistributedMesh> backMesh = backDHand->mesh;

  // Get values from paraStructure
  double mu0 = paramStr->getRealParameter(CoupledParams::mu0);
  double mu1 = paramStr->getRealParameter(CoupledParams::mu1);
  double lm1 = paramStr->getRealParameter(CoupledParams::lambda1);
  double deltat = paramStr->getRealParameter(CoupledParams::deltat);
  vector<double> vki = {2.*mu0, deltat*(lm1+2.*mu1)}; // normal stiffness of each side, velocity units

  // Velocity DOFs of each region (ux,uy); the fluid pressure is not part of the
  // estimate. Region 0 (fluid): bulk 2 mu0 d(v):d(v), boundary |2 mu0 d(v) n|^2.
  // Region 1 (solid, F = I + dt grad v): both operators linearised at the
  // current velocity, bulk dt (B0^T C B0 + Kgeo), boundary dt |d(P n)/du v|^2
  // (d(Pn)/dv = dt d(Pn)/du, so the ratio scales with dt)
  int numDOFs = 2;
  int pDim = 2;
  int eNN = 9;
  int nElem = backMesh->nElem();
  tensor<double,2> Id2 = ttl::Identity2;

  // Cubature info for the boundary integration
  std::vector<Teuchos::RCP<CubatureSet>> cubaSetsB = immHP->_integ[0]->_cubaSets;

  // Linear constraints
  std::vector<std::vector<linearConstraint>>& constrReg = backMesh->_cutBFConstrRegions;

  vector<int> rTags = {3,5};

  // Element nodes and node -> elements, from the connectivity (not _adjcyNE)
  std::vector<std::vector<int>> elNds(nElem);
  std::unordered_map<int, std::vector<int>> ndEls;
  for (int iE = 0; iE < nElem; iE++)
  {
    elNds[iE].resize(eNN);
    for (int n = 0; n < eNN; n++)
    {
      elNds[iE][n] = backMesh->_connec->getNbor(iE, n);
      ndEls[elNds[iE][n]].push_back(iE);
    }
  }

  // Patches: one per cut element K of the region, made of K plus the root
  // element(s) of K's slave nodes. The roots carry the bulk that controls
  // the DOFs K's slaves are extrapolated from. Roots are shared between
  // patches, so each element's bulk enters every patch it belongs to scaled
  // by 1/(number of such patches): the patch bulks then sum to the global one
  // and the patch constants combine into a global bound. K's boundary term
  // only enters K's own patch, so l0/l1 of K is just its patch's lambda.
  for (int rInt = 0; rInt < 2; rInt++)
  {
    map<string, double> params{{"mu", mu1}, {"lambda", lm1}};

    // Agg field name tag (number of roots of each cut element, for inspection)
    std::string aggTag = "Agg"+to_string(rInt);
    backDHand->elemAuxF->setValue(aggTag,0);

    // Cubature info for the integration in the current region
    std::vector<Teuchos::RCP<CubatureSet>> cubaSetsR = immHP->_integ[rInt+1]->_cubaSets;

    // Slave node -> its constraint in this region
    std::unordered_map<int, const linearConstraint*> slaveOf;
    for (const linearConstraint& lCnt : constrReg[rInt])
      slaveOf[lCnt.slave] = &lCnt;

    // Bad (aggregated) cut element: its centre node is a slave. Never a root.
    auto isBad = [&](int iE) { return slaveOf.count(elNds[iE][4]) > 0; };

    std::vector<int> cutEls;
    for (int iE = 0; iE < nElem; iE++)
    {
      int eTag = backDHand->elemAuxF->getValue(0,iE);
      if (eTag%2 == 0 && eTag%rTags[rInt] == 0)
        cutEls.push_back(iE);
    }

    // Roots of each slave node of a bad K: the non-bad elements containing
    // the most of its masters (all tied ones). Constraints with best count
    // <= 3 are plain hanging-node constraints and need no root. Well-cut K
    // has no aggregation slaves: patch {K}.
    int nWeakRoots = 0, nNoRoots = 0;
    std::vector<std::vector<int>> AP(cutEls.size());
    std::vector<int> mEl(nElem, 0);
    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      std::set<int> patch = {K};
      std::set<int> roots;
      for (int nd : (isBad(K) ? elNds[K] : std::vector<int>{}))
      {
        auto it = slaveOf.find(nd);
        if (it == slaveOf.end())
          continue;
        const linearConstraint& lCnt = *it->second;
        std::unordered_map<int,int> count;
        for (size_t m = 0; m < lCnt.masters.size(); m++)
          for (int e : ndEls[lCnt.masters[m]])
            if (!isBad(e))
              count[e]++;
        int best = 0;
        for (auto& c : count)
          best = max(best, c.second);
        if (best <= 3)
          continue;
        if (best < 6)
          nWeakRoots++;
        for (auto& c : count)
          if (c.second == best)
            roots.insert(c.first);
      }
      if (isBad(K) && roots.empty())
        nNoRoots++;
      patch.insert(roots.begin(), roots.end());

      // Free nodes of a bad K outside its roots are controlled through some
      // other good element of the region: add it, otherwise their only bulk
      // control in the patch is K's sliver
      if (isBad(K))
      {
        std::set<int> rootNds;
        for (int e : roots)
          rootNds.insert(elNds[e].begin(), elNds[e].end());
        for (int nd : elNds[K])
        {
          if (slaveOf.count(nd) || rootNds.count(nd))
            continue;
          for (int e : ndEls[nd])
          {
            int eTag = backDHand->elemAuxF->getValue(0,e);
            if (e != K && eTag%rTags[rInt] == 0 && !isBad(e))
              patch.insert(e);
          }
        }
      }
      backDHand->elemAuxF->setValue(aggTag,K,IndexType::Global,(double)roots.size());
      AP[k].assign(patch.begin(), patch.end());
      for (int e : AP[k])
        mEl[e]++;
    }

    // Summary counters
    int nAgg = 0, nLo = 0, nHi = 0, nFallback = 0, nUncTot = 0, maxNM = 0;
    double rMin = 1e300, rMax = 0.;

    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      const std::vector<int>& akp = AP[k];
      if (akp.size() > 1)
        nAgg++;

      // Patch DOF nodes (masters after the constraint mapping) and, per
      // element node, its (patch node, weight) list
      std::vector<int> igNds;
      std::unordered_map<int,int> igIdx;
      auto patchIdx = [&](int nd) {
        auto it = igIdx.find(nd);
        if (it != igIdx.end())
          return it->second;
        igIdx[nd] = igNds.size();
        igNds.push_back(nd);
        return (int)igNds.size()-1;
      };
      std::unordered_map<int, std::vector<std::vector<std::pair<int,double>>>> elMap;
      for (int iE : akp)
      {
        std::vector<std::vector<std::pair<int,double>>>& mp = elMap[iE];
        mp.resize(eNN);
        for (int il = 0; il < eNN; il++)
        {
          auto it = slaveOf.find(elNds[iE][il]);
          if (it == slaveOf.end())
            mp[il].push_back({patchIdx(elNds[iE][il]), 1.});
          else
          {
            // |w|: extrapolation weights are often negative (e.g. 6, -8, 3)
            const linearConstraint& lCnt = *it->second;
            for (size_t m = 0; m < lCnt.masters.size(); m++)
              if (fabs(lCnt.weights[m]) > 1e-13)
                mp[il].push_back({patchIdx(lCnt.masters[m]), lCnt.weights[m]});
          }
        }
      }
      int nM = igNds.size();
      maxNM = max(maxNM, nM);

      // M1: patch bulk, M2: K's boundary term; DOF (node A, comp i) -> A+nM*i
      Eigen::MatrixXd M1 = Eigen::MatrixXd::Zero(nM*numDOFs, nM*numDOFs);
      Eigen::MatrixXd M2 = Eigen::MatrixXd::Zero(nM*numDOFs, nM*numDOFs);
      auto scatter = [&](Eigen::MatrixXd& M, const std::vector<std::vector<std::pair<int,double>>>& mp,
                         tensor<double,4>& Ke, double s) {
        for (int a = 0; a < eNN; a++)
          for (auto& pa : mp[a])
            for (int b = 0; b < eNN; b++)
              for (auto& pb : mp[b])
              {
                double w = s*pa.second*pb.second;
                for (int i = 0; i < numDOFs; i++)
                  for (int j = 0; j < numDOFs; j++)
                    M(pa.first+nM*i, pb.first+nM*j) += w*Ke(a,i,b,j);
              }
      };

      double APatch = 0.; // bulk measure, scaled as M1
      double LPatch = 0.; // K's boundary measure

      for (int iE : akp)
      {
        double sE = 1./mEl[iE];

        // Compute bulk integration
        for (auto info: cubaSetsR[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,4> Aku1(eNN,numDOFs,eNN,numDOFs);
          for (int a = 0 ; a < eNN; a++)
            for (int i = 0 ; i < numDOFs; i++)
              for (int b = 0 ; b < eNN; b++)
                for (int j = 0 ; j < numDOFs; j++)
                  Aku1(a,i,b,j) = 0;

          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int i = 0 ; i < 2; i++)
              for (int j = 0 ; j < 2; j++)
                Jac(i,j) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            tensor<double,2> nborDOFs(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                nborDOFs(n,d0) = backDHand->nodeDOFs->getValue(d0+rInt*2,nbor);
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();

            double jac = Jac.det();
            if (rInt == 0)
            {
              for (int a = 0 ; a < eNN; a++)
                for (int b = 0 ; b < eNN; b++)
                {
                  Aku1(a, 0, b, 0) += wS[gpi] * jac * mu0 * (2.*Dbf_g(a,0)*Dbf_g(b,0) + Dbf_g(a,1)*Dbf_g(b,1));
                  Aku1(a, 0, b, 1) += wS[gpi] * jac * mu0 * (Dbf_g(a,1)*Dbf_g(b,0));
                  Aku1(a, 1, b, 0) += wS[gpi] * jac * mu0 * (Dbf_g(a,0)*Dbf_g(b,1));
                  Aku1(a, 1, b, 1) += wS[gpi] * jac * mu0 * (2.*Dbf_g(a,1)*Dbf_g(b,1) + Dbf_g(a,0)*Dbf_g(b,0));
                }
            }
            else
            {
              // Deformation gradient, constitutive model and B0 (as in LSV1)
              tensor<double,2> F = product(nborDOFs, Dbf_g, {{0,0}})*deltat+Id2;
              double W{};
              int nVoi = 3;
              tensor<double,1> S_v(nVoi);
              tensor<double,2> S(pDim,pDim), C_v(nVoi,nVoi);
              constitutiveModel_Coupled_NeoHookean(S_v, S, C_v, W, F, params);
              tensor<double,3> B0(nVoi, eNN, pDim);
              for (int a = 0; a < eNN; a++)
              {
                for (int i = 0; i < pDim; i++)
                  B0(i,a,all) = F(all,i)*Dbf_g(a,i);
                B0(2,a,all) = F(all,1)*Dbf_g(a,0) + F(all,0)*Dbf_g(a,1);
              }

              // Geometric stiffness
              tensor<double,2> kg = Dbf_g*(S*Dbf_g.T());
              tensor<double,4> Kgeo(eNN,pDim,eNN,pDim);
              for (int a = 0; a < eNN; a++)
                for (int i = 0; i < pDim; i++)
                  for (int b = 0; b < eNN; b++)
                    for (int j = 0; j < pDim; j++)
                      Kgeo(b,j,a,i) = (i == j) ? kg(a,b) : 0.;

              Aku1 += deltat*wS[gpi]*jac*(B0.transpose({1,2,0})*C_v*B0 + Kgeo);
            }
            APatch += sE*wS[gpi]*jac;
          }
          scatter(M1, elMap[iE], Aku1, sE);
        }

        // Boundary term of K only: |d(P n)/dv v|^2
        if (iE != K)
          continue;

        for (auto info: cubaSetsB[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,4> Bku1(eNN,numDOFs,eNN,numDOFs);
          for (int a = 0 ; a < eNN; a++)
            for (int i = 0 ; i < numDOFs; i++)
              for (int b = 0 ; b < eNN; b++)
                for (int j = 0 ; j < numDOFs; j++)
                  Bku1(a,i,b,j) = 0;

          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int i = 0 ; i < 2; i++)
              for (int j = 0 ; j < 2; j++)
                Jac(i,j) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            tensor<double,2> nborDOFs(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                nborDOFs(n,d0) = backDHand->nodeDOFs->getValue(d0+rInt*2,nbor);
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();

            // Normal and jacobian
            int nDim = 3;
            std::vector<double> t(nDim);
            for (int n = 0; n < nDim; n++)
              t[n] = immMesh->_immTangents[iE][nDim*gpi+n];
            double jac = Math::Norm3D(t.data());

            // Compute unitary normal (sign irrelevant: the term is quadratic)
            tensor<double,1> n(2);
            n(0) = -t[1]/jac;
            n(1) = t[0]/jac;

            if (rInt == 0)
            {
              // Viscous traction 2 mu0 d(v) n
              tensor<double,1> nDbf_g = Dbf_g*n;
              tensor<double,2> Dbf_gDbf_g = Dbf_g*Dbf_g.T();
              for (int a = 0 ; a < eNN; a++)
                for (int i = 0 ; i < numDOFs; i++)
                  for (int b = 0 ; b < eNN; b++)
                    for (int j = 0 ; j < numDOFs; j++)
                      Bku1(a,i,b,j) += 2.*mu0*mu0*wS[gpi]*jac*0.5*(nDbf_g(a)*nDbf_g(b)*Id2(i,j)+nDbf_g(a)*Dbf_g(b,i)*n(j)+Dbf_g(a,j)*n(i)*nDbf_g(b)+Dbf_gDbf_g(a,b)*n(i)*n(j));
            }
            else
            {
              // Deformation gradient, constitutive model and B0 (as in LSV1)
              tensor<double,2> F = product(nborDOFs, Dbf_g, {{0,0}})*deltat+Id2;
              double W{};
              int nVoi = 3;
              tensor<double,1> S_v(nVoi);
              tensor<double,2> S(pDim,pDim), C_v(nVoi,nVoi);
              constitutiveModel_Coupled_NeoHookean(S_v, S, C_v, W, F, params);
              tensor<double,3> B0(nVoi, eNN, pDim);
              for (int a = 0; a < eNN; a++)
              {
                for (int i = 0; i < pDim; i++)
                  B0(i,a,all) = F(all,i)*Dbf_g(a,i);
                B0(2,a,all) = F(all,1)*Dbf_g(a,0) + F(all,0)*Dbf_g(a,1);
              }

              // Traction linearisation H(a,i,j) = d(P n)_j/du_{a,i}:
              // material part F C (F^T n)_sym and geometric part (grad N_a . S n) delta_ij
              tensor<double,2> b0(nVoi, pDim);
              for (int i = 0; i < pDim; i++)
                b0(i,all) = F(all,i)*n(i);
              b0(2,all) = F(all,1)*n(0) + F(all,0)*n(1);
              tensor<double,1> kg = Dbf_g*S*n;
              tensor<double,3> kgeo(eNN, pDim, pDim);
              for (int a = 0; a < eNN; a++)
                for (int i = 0; i < pDim; i++)
                  for (int j = 0; j < pDim; j++)
                    kgeo(a,i,j) = (i == j) ? kg(a) : 0.;
              tensor<double,3> H = B0.transpose({1,2,0})*(C_v*b0) + kgeo;

              Bku1 += deltat*wS[gpi]*jac*H*H.transpose({2,0,1});
            }
            LPatch += wS[gpi]*jac;
          }
          scatter(M2, elMap[iE], Bku1, 1.);
        }
      }

      // Rigid modes on the patch nodes (about its centroid): fluid in the
      // reference configuration, solid in the current one x = X + dt v. Under
      // stress the tangent is not exactly singular for the rotation, but it
      // carries no boundary control either
      std::vector<double> xn(nM), yn(nM);
      double xc = 0., yc = 0.;
      for (int A = 0; A < nM; A++)
      {
        double sx = (rInt == 1) ? deltat : 0.;
        xn[A] = backMesh->nodeCoord(igNds[A],0) + sx*backDHand->nodeDOFs->getValue(2*rInt,igNds[A]);
        yn[A] = backMesh->nodeCoord(igNds[A],1) + sx*backDHand->nodeDOFs->getValue(2*rInt+1,igNds[A]);
        xc += xn[A]/nM;
        yc += yn[A]/nM;
      }
      Eigen::MatrixXd Rm = Eigen::MatrixXd::Zero(nM*numDOFs, 3);
      for (int A = 0; A < nM; A++)
      {
        Rm(A,0) = 1.;
        Rm(A+nM,1) = 1.;
        Rm(A,2) = -(yn[A] - yc);
        Rm(A+nM,2) = xn[A] - xc;
      }

      int nUnc = 0;
      double lEig = nitscheEigenEstimate(M2, M1, Rm, nUnc);
      nUncTot += nUnc;

      if (LPatch > 0. && !(APatch > 0.))
        throw runtime_error("localNitscheEstimation: cut element " + to_string(K) + " has no bulk in region "
                            + to_string(rInt) + " (patch of " + to_string(akp.size()) + " elements)");
      double Cgeo = (APatch > 0.) ? vki[rInt]*LPatch/APatch : 0.;

      double lmax = lEig;
      if (Cgeo > 0.)
      {
        if (!(lEig > 0.) || !std::isfinite(lEig))
        {
          lmax = Cgeo;
          nFallback++;
        }
        else
        {
          rMin = min(rMin, lEig/Cgeo);
          rMax = max(rMax, lEig/Cgeo);
          if (lEig < g_nitscheGeoLo*Cgeo)
          {
            lmax = g_nitscheGeoLo*Cgeo;
            nLo++;
          }
          else if (lEig > g_nitscheGeoHi*Cgeo)
          {
            lmax = g_nitscheGeoHi*Cgeo;
            nHi++;
          }
        }
      }
      else if (!(lEig > 0.) || !std::isfinite(lEig))
        nFallback++; // no boundary points in K: lmax unused by LSBorder

      backDHand->elemAuxF->setValue("l"+to_string(rInt),K,IndexType::Global,lmax);
    }

    cout << "Nitsche r" << rInt << ": " << cutEls.size() << " patches (" << nAgg << " with roots, max "
         << maxNM << " nodes), lambda/Cgeo in [" << (rMin < 1e300 ? rMin : 0.) << ", " << rMax << "], clamped lo "
         << nLo << " hi " << nHi << ", fallback " << nFallback << ", weak roots " << nWeakRoots
         << ", bad without root " << nNoRoots << ", uncontrolled DOFs " << nUncTot << endl;
  }
}

// *******************************************************************//
// *******************************************************************//
// *******************************************************************//
// *****                      MAIN FUNCTION                      *****//
// *******************************************************************//
// *******************************************************************//
// *******************************************************************//

int main(int argc, char** argv)
{

  hiperlife::Init(argc, argv);

  //============================ Parameters ============================//
  Params p = parseArgs(argc, argv);
  cout << "rx=" << p.rx << " ry=" << p.ry << " mu0=" << p.mu0 << " mu1=" << p.mu1 << " lm1=" << p.lm1
       << " dt=" << p.dt << " wpTh=" << p.wpTh << " beta=" << p.beta << " levels=" << p.levels << " walls=" << (p.walls > 0 ? "roller" : "clamped") << endl;
  bool rollerWalls = p.walls > 0;
  vector<int> nxt = {8, 16, 32, 64, 128};
  if (p.levels < 1 || p.levels > nxt.size())
    throw std::runtime_error("--levels must be in [1, " + to_string(nxt.size()) + "]");
  nxt.resize((int)p.levels);

  SmartPtr<ParamStructure> paramStr = CreateParamStructure<CoupledParams>();
  paramStr->setRealParameter(CoupledParams::mu0, p.mu0);
  paramStr->setRealParameter(CoupledParams::mu1, p.mu1);
  paramStr->setRealParameter(CoupledParams::lambda1, p.lm1);
  paramStr->setRealParameter(CoupledParams::deltat, p.dt);
  paramStr->setRealParameter(CoupledParams::beta0, p.beta);
  g_borderAutodiff = p.checkBorder > 0;


  // *******************************************************************//
  // *****                      MESH CREATION                      *****//
  // *******************************************************************//
  int nSteps = nxt.size();
  int bfOrder = 2;
  int timeStep = 0;
  bool ghP = 0;
  double wellPosedTh = p.wpTh;

  // K: jump |u0 - u1 - vd n|, T: traction jump, nT: averaged traction,
  // dM/dGM/dTM: differences with the previous level, nrFail: Newton passes that did not converge
  const double nan = std::numeric_limits<double>::quiet_NaN();
  std::vector<double> Kerr, Terr, nTerr, dMerr, dGMerr, dTMerr, dMiss, nrFail;
  std::vector<std::vector<double>> dMr(2), dGMr(2); // per region (0 fluid, 1 solid)
  paramStr->setBoolParameter(CoupledParams::postProcess,false);

  if(ghP)
  {
    wellPosedTh = 0.2;
  }
  for (int nS{}; nS < nSteps; nS++)
  {
    paramStr->setIntParameter(CoupledParams::timeStep,nS);
    //-------------------------- Background mesh -------------------------//
    double beta = p.beta*nxt[nS]; // fixed beta = gamma/h (only used if gamma > 0)
    paramStr->setRealParameter(CoupledParams::beta,beta);

    // Mesh generator
    SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
    back->genStructMesh(nxt[nS], nxt[nS]);
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0001;        

    SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();

    ElemType eTypeB = ElemType::Line; // Element type
    int bfOrderB = 3;   // Basis function order
    BasisFuncType bTypeB = BasisFuncType::BSplines; // Basis function type
    double rC = 0.68/sqrt(5.); // Radius of immersed mesh
    int nPtsCirc = 5*nxt[nS]; // Number of control points
    std::vector<std::vector<std::vector<std::vector<double>>>> CP(nPtsCirc, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
    std::vector<double> U(nPtsCirc+1,0);

    imm->setMesh(eTypeB, bTypeB, bfOrderB);
    genCircBspline(rC,U,CP,p.rx,p.ry,eTypeB,bTypeB,bfOrderB,nPtsCirc,paramStr);
    imm->genBsplinesClosedCurve(U,CP);

    // Distributed mesh
    SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->Update();


    //--------------------------- Immersed mesh --------------------------//

    // Distributed mesh
    SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setImmersedInteriorPoints({{{p.rx, p.ry, 0.0}},{{0.01,0.01,0}}});
    immMesh->setRegionTags({"Interior","Exterior"});
    immMesh->setBalanceMesh(true);
    immMesh->setIllPosThreshold(wellPosedTh);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->Update();



    // *******************************************************************//
    // *****                   DOFsHandler CREATION                  *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"ux0","uy0","ux1","uy1","p0"});
    backDHand->setNodeAuxF({"const","ctag","stab","pp0"});
    backDHand->setElemAuxF({"tag","WI","Agg0","gmm0","l0","GhP0","Agg1","gmm1","l1","GhP1","lE","stbP"});
    backDHand->setDofTags({"Interior","Interior","Exterior","Exterior"});
    backDHand->Update();
    double al = 0.2;

    // Save interior/cut/exterior flags for plotting
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
      int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
      backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
      vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
      vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
      for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
      {
        if (backDHand->mesh->isNodeInPart(nbors[n]))
          backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
      }
    }
    backDHand->UpdateGhosts();
    

    // Set pressure constraints

    backDHand->setConstraint("p0", 0.0);
    std::vector<int> eNNp = {0,1,3};

    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    { 
      std::vector<int> elCornerFlags = backDHand->mesh->_immersedCornerFlags(e,IndexType::Local);
      std::vector<int> elCorners = backDHand->mesh->_getElementCornerNodes(e,IndexType::Local);
      std::vector<int> nborNode = backMesh->elemNodeNbors(e,IndexType::Global);
      
      if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%3 == 0)
      {
        std::vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
        std::vector<int> eNNp = {0,1,3};
        for (int k{}; k < 3; k++)
          backDHand->removeConstraint(4,nborNode[eNNp[k]],IndexType::Local);
      } 
    }

    // Update
    backDHand->UpdateGhosts();


    // Set boundary conditions
    // for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    // { 
    //   std::vector<int> elCornerFlags = backDHand->mesh->_immersedCornerFlags(e,IndexType::Local);
    //   std::vector<int> elCorners = backDHand->mesh->_getElementCornerNodes(e,IndexType::Local);
    //   std::vector<int> nborNode = backMesh->elemNodeNbors(e,IndexType::Global);
      
    //   if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%3 == 0)
    //   {
    //     std::vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
    //     std::vector<int> eNNp = {0,1,3};
    //       backDHand->nodeDOFs->setValue(4,nborNode[eNNp[0]],IndexType::Local, 1);
    //       backDHand->nodeDOFs->setValue(4,nborNode[eNNp[1]],IndexType::Local, 0.1);
    //       backDHand->nodeDOFs->setValue(4,nborNode[eNNp[2]],IndexType::Local, 0.1);
    //   } 
    // }
    for (int i{}; i < backMesh->nPts(); i++)
    {
      std::vector<double> x = backMesh->nodeCoords(i,IndexType::Global);
      if (true)
      {
        backDHand->nodeDOFs->setValue(0,i,IndexType::Local, 0);
        backDHand->nodeDOFs->setValue(1,i,IndexType::Local, 0);
        backDHand->nodeDOFs->setValue(2,i,IndexType::Local, 0);
        backDHand->nodeDOFs->setValue(3,i,IndexType::Local, 0);
      }
      
      // if (backMesh->nodeCrease(i,IndexType::Global) > 0)
      {
        // Solid walls. Clamped (v1 = 0) walls give a corner singularity
        // u ~ r^1.15 (nu = 0.45) that limits the convergence rates; rollers
        // (normal velocity only) extend smoothly by reflection across the walls
        bool xWall = x[0]>0.9999 || x[0]<0.001;
        bool yWall = x[1]>0.9999 || x[1]<0.001;
        if (xWall || (yWall && !rollerWalls))
        {
          backDHand->setConstraint(2,i,IndexType::Global,0.);
          backDHand->nodeDOFs->setValue(2,i,IndexType::Global,0.);
        }
        if (yWall || (xWall && !rollerWalls))
        {
          backDHand->setConstraint(3,i,IndexType::Global,0.);
          backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.);
        }

        // if (x[1]>0.999)
        // {
        //   backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.1);
        //   backDHand->setConstraint(3,i,IndexType::Global,0.);
        // }

        
        // if (x[1]<0.001)
        // {
        //   backDHand->nodeDOFs->setValue(3,i,IndexType::Global,0.);
        //   backDHand->setConstraint(3,i,IndexType::Global,0.);
        // }
      }
    }

    // Compute facet pairs
    std::vector<std::pair<int,int>> borderFacetPairsR0 = findBorderAdjacentPairs(backDHand, bfOrder,0);
    std::vector<std::pair<int,int>> borderFacetPairsR1 = findBorderAdjacentPairs(backDHand, bfOrder,1);

    //------------------- Face stabilization flags -------------------//

    backDHand->elemAuxF->setValue("stbP",1);
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
      if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%3 == 0)
      {
        std::vector<int> nborNodes = backDHand->mesh->elemNodeNbors(e,IndexType::Local);
        int prova1 = backDHand->mesh->_adjcyNE->getNumNbors(nborNodes[1],IndexType::Local);
        std::vector<int> idF = {3,5};
        std::vector<int> ndF = {5,7};
        for (int i{}; i < 2; i++)
        {
          int Fstb = backDHand->elemAuxF->getValue("stbP",e,IndexType::Local);
          std::vector<int> nborElms = backDHand->mesh->_adjcyNE->getNborList(nborNodes[ndF[i]],IndexType::Local);
          int e1 = -1;
          for (int j{0}; j < nborElms.size(); j++)
          {
            if (nborElms[j] != e)
            {
              e1 = nborElms[j];
              break;
            }
          }
          if (e1 >= 0)
          {
            if (int(backDHand->elemAuxF->getValue("tag",e,IndexType::Local))%2 == 0 || int(backDHand->elemAuxF->getValue("tag",e1,IndexType::Local))%2 == 0 )
            {
              if (backDHand->mesh->_elemFlags->getValue(1, e1, IndexType::Local)%3 == 0)
              {
                backDHand->elemAuxF->setValue("stbP",e,IndexType::Local,Fstb*idF[i]);
              }
            }
          }
        }
      }  
    }


    // *******************************************************************//
    // *****                    IMMERSED PROBLEM                     *****//
    // *******************************************************************//
    if (true)
    {
      // Immersed HiPerProblem
      SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
      //General setters
      immHP->setParameterStructure(paramStr);
      immHP->setGlobalIntegrals({"Area","Length","uErr","duErr","tErr","dErr","dGerr","dtErr","dMiss","dErr0","dGerr0","dErr1","dGerr1","total_edge_length","Ray"});
      immHP->setDOFsHandlers({backDHand});

      // Set integration for the border
      immHP->setIntegration("IntegBorder", {"backDHand"});
      immHP->setCubatureBorderImmersed("IntegBorder", 10);
      immHP->setElementFillings("IntegBorder", LSBorder);

      // Set integration for velocity at Region 0
      immHP->setIntegration("IntegCavityV0", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV0", 9,5,"Interior");
      immHP->setElementFillings("IntegCavityV0", LSV0);

      // Set integration for velocity Region 1
      immHP->setIntegration("IntegCavityV1", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV1", 9,5,"Exterior");
      immHP->setElementFillings("IntegCavityV1", LSV1);

      // Set integration for Pressure at Region 0
      immHP->setIntegration("IntegCavityP0", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityP0", 4,3,"Interior");
      immHP->setElementFillings("IntegCavityP0", LSP0);

      // // // Face Pressure integration
      // immHP->setIntegration("IntegFaces", {"backDHand"});
      // immHP->setCubatureGauss("IntegFaces", 1);
      // immHP->setElementFillings("IntegFaces", LSF0);

      if (ghP)
      {
        // Face stabilization
        // Region 0
        immHP->setIntegration("IntegF0",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF0", /*iPts=*/5, borderFacetPairsR0);
        immHP->setElementFillings("IntegF0", FacetStbR0);

        // Region 1
        immHP->setIntegration("IntegF1",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF1", /*iPts=*/5, borderFacetPairsR1);
        immHP->setElementFillings("IntegF1", FacetStbR1);
      }
      
      //------------------- Pressure imm constraints -------------------//

      std::vector<double> pR = {4};
      int r = 0;
      std::vector<hiperlife::linearConstraint> pLCns;
      std::vector<int> touchFlags = backMesh->_createTouchFlags(r);
      unordered_map<int, std::vector<int>> aggEls = backMesh->_findClosestFAE(touchFlags);
      for (auto itr = aggEls.begin(); itr != aggEls.end(); ++itr)
      {
        // Compute the extrapolation weights
        std::vector<int> MEls = itr->second;
        int sEl = itr->first;
        std::vector<int> sNodes = backMesh->elemNodeNbors(sEl,IndexType::Global);
        double p0 = 0.;
        double p1 = 0.;
        double p2 = 0.;
        std::vector<double> xS0 = backMesh->nodeCoords(sNodes[0],IndexType::Local);
        std::vector<int> m0{}, m1{}, m2{};
        std::vector<double> w0{}, w1{}, w2{};
        int s0 = sNodes[0];
        int s1 = sNodes[1];
        int s2 = sNodes[3];
        int nMs = MEls.size();
        for(int mEl:MEls)
        {
          // Obtain master element corners
          std::vector<int> mNodes = backMesh->elemNodeNbors(mEl,IndexType::Global);
          std::vector<double> xM0 = backMesh->nodeCoords(mNodes[0],IndexType::Local);
          std::vector<double> xM1 = backMesh->nodeCoords(mNodes[8],IndexType::Local);

          // Compute slave p0 as a function of masters p1 and p2
          m1.push_back(mNodes[1]);
          w1.push_back(1./nMs);
          m2.push_back(mNodes[3]);
          w2.push_back(1./nMs);
          double ax = 2./(xM1[0]-xM0[0]);
          double ay = 2./(xM1[1]-xM0[1]);
          double bx = -1.-ax*xM0[0];
          double by = -1.-ay*xM0[1];
          double xs = ax*xS0[0]+bx;
          double ys = ay*xS0[1]+by;
          m0.push_back(mNodes[0]);
          w0.push_back(1./nMs);
          m0.push_back(mNodes[1]);
          w0.push_back(0.5*(xs+1.)/nMs);
          m0.push_back(mNodes[3]);
          w0.push_back(0.5*(ys+1.)/nMs);
        }

        linearConstraint lcAgg0, lcAgg1, lcAgg2;
        lcAgg0.slave = s0;
        lcAgg0.masters = m0;
        lcAgg0.weights = w0;
        pLCns.push_back(lcAgg0);

        lcAgg1.slave = s1;
        lcAgg1.masters = m1;
        lcAgg1.weights = w1;
        pLCns.push_back(lcAgg1);

        lcAgg2.slave = s2;
        lcAgg2.masters = m2;
        lcAgg2.weights = w2;
        pLCns.push_back(lcAgg2);
      }

      for (linearConstraint lC :pLCns)
      {
        int iSlv = lC.slave;
        std::vector<CompHiPerIndex> mstrsV;
        CompHiPerIndex slv = CompHiPerIndex(0, pR[r], iSlv, IndexType::Global); // Get slave hiperIndex
      
        for (int mstrIdx:lC.masters)
          mstrsV.push_back(CompHiPerIndex(0, pR[r], mstrIdx, IndexType::Global)); // Get mstr hiperIndex
        
        immHP->setLinearConstraint(slv,mstrsV,lC.weights); // Set constraint
      }
      immHP->Update();

      localNitscheEstimation(immHP, backDHand, paramStr, immMesh);

      immHP->FillLinearSystem();
      //-------------------------- Immersed solver -------------------------//
      SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
      immSOL->setHiPerProblem(immHP);
      immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
      immSOL->setDefaultParameters();
      // immSOL->setWorkSpaceMemoryIncrease(200);
      immSOL->Update();

      //------------------ Newton-Raphson Nonlinear Solver ------------------//


      // Two passes: penalty only (approxStep), then full Nitsche. A pass that
      // reaches maxIt, or whose step cannot be cut back to a finite energy, is
      // counted as a Newton failure for this level
      const int maxIt = 30;
      const int maxCuts = 40;
      int nFailLevel = 0;
      for (int it2 = 0; it2 < 2; it2++)
      {
        double resRErr = 1e10;
        double solRErr = 1e10;
        double resTol = 1e-9;
        double solTol = 1e-9;
        double resErr0, solErr0;
        int it = 0;
        double LSalpha = 1;
        bool failed = false;
        paramStr->setBoolParameter(CoupledParams::approxStep, it2 == 0);

        //Output info
        cout << "    Iter | " << "L2 SolERR      |" << " (relative)     |" << " L2 ResERR      |" << " (relative)     | alpha" << endl;
        cout << std::scientific << std::setprecision(8);
        localNitscheEstimation(immHP, backDHand, paramStr, immMesh);

        while ((resRErr > resTol && solRErr > solTol))
        {
          if (it >= maxIt)
          {
            failed = true;
            break;
          }
          double resErr = {};
          double solErr = {};
          LSalpha = 1;
          // Solve linear system
          immSOL->solve();
          immHP->linProbl->GetRHS()->Norm2(&resErr);
          immHP->linProbl->GetLHS()->Norm2(&solErr);
          if (!std::isfinite(resErr) || !std::isfinite(solErr))
          {
            failed = true;
            break;
          }
          if (it == 0)
          {
            resErr0 = resErr;
            solErr0 = solErr;
          }
          resRErr = resErr/resErr0;
          solRErr = solErr/solErr0;

          // Cut the step back while the energy is not finite (J <= 0 in the solid)
          immHP->AddSolutionToDOFs(-LSalpha);
          immHP->FillLinearSystem();
          int nCuts = 0;
          while (isnan(immHP->globalIntegral("Ray")) && nCuts < maxCuts)
          {
            immHP->AddSolutionToDOFs(LSalpha);
            LSalpha *= 0.8;
            immHP->AddSolutionToDOFs(-LSalpha);
            immHP->FillLinearSystem();
            nCuts++;
          }
          // Print results
          cout << "    " << setfill(' ') << setw(4) <<it << " | ";
          cout <<  setw(14) <<solErr << " | " <<  setw(14)<< solRErr << " | " <<  setw(14)<< resErr << " | " <<  setw(14)<< resRErr << " | " << LSalpha << endl;
          it++;
          if (isnan(immHP->globalIntegral("Ray")))
          {
            failed = true;
            break;
          }
        }
        if (failed)
        {
          nFailLevel++;
          cout << "Newton not converged: 1/h = " << nxt[nS] << ", pass " << it2 << ", " << it << " iterations" << endl;
        }
      }

      //------------------    Pressure postprocess    ------------------//

      ttl::tensor<double,2> nborCoordsEl = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
      std::vector<int> regionTags = {3,5};
      double diffP = 0.;

      for (int i{}; i < backDHand->mesh->nElem(); i++)
      {
          std::vector<int> nborNode = backDHand->mesh->elemNodeNbors(i,IndexType::Global);

          int r = 0;
          if (backDHand->mesh->_elemFlags->getValue(1, i, IndexType::Local)%regionTags[r] == 0)
          {
              std::vector<int> nborCornersNode = backDHand->mesh->_getElementCornerNodes(i,IndexType::Global);
              double a = backDHand->nodeDOFs->getValue(4,nborNode[0],IndexType::Global);
              double b = backDHand->nodeDOFs->getValue(4,nborNode[1],IndexType::Global);
              double c = backDHand->nodeDOFs->getValue(4,nborNode[3],IndexType::Global);
              for (int j{}; j < 9; j++)
              {
                  ttl::tensor<double,1> bf1 = {1.,0.5*(nborCoordsEl(j,0)+1.),0.5*(nborCoordsEl(j,1)+1.)};
                  ttl::tensor<double,1> x = nborCoordsEl(j,ttl::all);
                  double p = a+0.5*b*(x(0)+1.)+0.5*c*(x(1)+1.);
                  backDHand->nodeAuxF->setValue("pp0",nborNode[j],IndexType::Global,p);
              }
          }
      }
      string meshName = to_string(nS);

                  
      // Print
      string solName = "solBackEnd."+to_string(nS);
      backDHand->printFileLegacyVtk(solName, true);
      immMesh->printFileLegacyVtk("meshImm."+to_string(nS));

      paramStr->setBoolParameter(CoupledParams::postProcess,true);
      immHP->FillLinearSystem();
      paramStr->setBoolParameter(CoupledParams::postProcess,false);

      Kerr.push_back(sqrt(immHP->globalIntegral("uErr")));
      Terr.push_back(sqrt(immHP->globalIntegral("duErr")));
      nTerr.push_back(sqrt(immHP->globalIntegral("tErr")));
      dMerr.push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dErr")) : nan);
      dGMerr.push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dGerr")) : nan);
      dTMerr.push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dtErr")) : nan);
      dMiss.push_back(g_coarse.valid ? immHP->globalIntegral("dMiss") : nan);
      nrFail.push_back(nFailLevel);
      for (int r = 0; r < 2; r++)
      {
        dMr[r].push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dErr"+to_string(r))) : nan);
        dGMr[r].push_back(g_coarse.valid ? sqrt(immHP->globalIntegral("dGerr"+to_string(r))) : nan);
      }
      if (g_borderAutodiff)
        cout << "LSBorder vs autodiff, max relative difference: Bk " << g_borderCheck[0] << " Ak " << g_borderCheck[1] << endl;
      cout << "1/h = " << nxt[nS] << ": K " << Kerr.back() << " T " << Terr.back() << " nT " << nTerr.back()
           << " dM " << dMerr.back() << " dGM " << dGMerr.back() << " dTM " << dTMerr.back()
           << " dMiss " << dMiss.back() << " NR fail " << nFailLevel << endl;

      // This level becomes the reference for the next one
      setCoarseLevel(backDHand, immMesh, nxt[nS]);
    }
  }
  g_coarse = CoarseLevel();

  // Column headers
  cout << left
       << setw(20) << "1/h"
       << setw(20) << "K Err"
       << setw(20) << "T Err"
       << setw(20) << "nT Err"
       << setw(20) << "dM Err"
       << setw(20) << "dGM Err"
       << setw(20) << "dTM Err"
       << setw(20) << "dMiss"
       << setw(20) << "NR fail"
       << setw(20) << "dM0 Err"
       << setw(20) << "dGM0 Err"
       << setw(20) << "dM1 Err"
       << setw(20) << "dGM1 Err"
       << endl;

  for(int nS = 0; nS < (int)Kerr.size(); nS++)
  {
    cout << left << setw(20) << nxt[nS] << setw(20) << Kerr[nS] << setw(20) << Terr[nS] << setw(20) << nTerr[nS]
         << setw(20) << dMerr[nS] << setw(20) << dGMerr[nS] << setw(20) << dTMerr[nS]
         << setw(20) << dMiss[nS] << setw(20) << nrFail[nS]
         << setw(20) << dMr[0][nS] << setw(20) << dGMr[0][nS] << setw(20) << dMr[1][nS] << setw(20) << dGMr[1][nS] << endl;
  }

  hiperlife::Finalize();
  return 0;
}