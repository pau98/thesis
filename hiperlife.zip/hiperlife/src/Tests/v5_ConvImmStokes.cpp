/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>
#include <set>
#include <unordered_map>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"


// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct StokesParams
{
  enum RealParameters
  {
    force,
    beta,
    mu0,
    mu1,
    rx,
    ry,
    wpTh,
    beta0
  };

  enum IntParameters
  {
    timeStep,
  };

  HL_PARAMETER_LIST DefaultValues
  {
    {"force", 0.0},
    {"beta", 100.0},
    {"timeStep",0},
    {"k0",10.},
    {"k1",0.01},
    {"mu0",1.},
    {"mu1",1.},
    {"rx",0.5},
    {"ry",0.5},
    {"wpTh",0.5},
    {"beta0",-1.}
  };
};

bool fileExists(const std::string& filename)
{
  struct stat buf;
  if (stat(filename.c_str(), &buf) != -1)
  {
    return true;
  }
  return false;
}

struct Params {
  double rx, ry, mu0, mu1, wpTh, beta, levels, tauMode;
};

// Pressure face-jump stabilization (LSF0/LSF1): 0 tau = c h (original),
// 1 tau = c h/mu_r (scales with the pressure, p ~ mu u/h), 2 off (default).
// The unscaled penalty over-constrains the P1-disc pressure when mu1 >> mu0
// and costs convergence rate; Q2/P1-disc with aggregation is stable without it
static int g_tauMode = 2;

Params parseArgs(int argc, char* argv[]) {
  std::unordered_map<std::string, std::string> args;
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg.rfind("--", 0) == 0 && i + 1 < argc) {
      args[arg.substr(2)] = argv[++i];
    }
  }

  auto get = [&](const std::string& key,double defVal) -> double {
    auto it = args.find(key);
    if (it == args.end()) {
      cout << "Using default for --" + key<<endl;
      return defVal;
    }
    try {
      return std::stod(it->second);
    } catch (...) {
      throw std::runtime_error("Invalid value for --" + key + ": '" + it->second + "'");
    }
  };

  return Params{
    get("rx",0.5),
    get("ry",0.5),
    get("mu0",1),
    get("mu1",1),
    get("wpTh",0.5),
    get("beta",-1.),
    get("levels",5),
    get("tauMode",2)
  };
}


std::string buildFilename(const Params& p)
{
  std::ostringstream oss;
  oss << "_rx" << std::fixed << std::setprecision(3) << p.rx
    << "_ry" << std::fixed << std::setprecision(3) << p.ry
    << "_mu0" << std::fixed << std::setprecision(3) << p.mu0
    << "_mu1" << std::fixed << std::setprecision(3) << p.mu1
    << "_wpTh" << std::fixed << std::setprecision(3) << p.wpTh
    << "_beta" << std::fixed << std::setprecision(3) << p.beta;
  return oss.str();
}


std::vector<std::pair<int,int>> findBorderAdjacentPairs(Teuchos::RCP<hiperlife::DOFsHandler> dhand, int p, int rInt)
{
  using namespace hiperlife;

  auto mesh = dhand->mesh;
  vector<string> rTags = mesh->_regionTags();
  // if (std::find(rTags.begin(), rTags.end(), rTag) == rTags.end())
  //     throw runtime_error("findBorderAdjacentPairs: The provided region name could not be found");
  vector<int> rPrimes = {3,5,7,11};

  // Corner local-node indices per side of a Q_p square element:
  //   Side 0 (v=-1): nodes 0      and p
  //   Side 1 (u=+1): nodes p      and p*(p+2)
  //   Side 2 (v=+1): nodes p*(p+2) and p*(p+1)
  //   Side 3 (u=-1): nodes p*(p+1) and 0
  const std::array<std::array<int,2>,4> sideCorners = {{
    {0,       p        },
    {p,       p*(p+2)  },
    {p*(p+2), p*(p+1)  },
    {p*(p+1), 0        }
  }};
  
  dhand->elemAuxF->setValue("GhP"+to_string(rInt),1);

  std::unordered_map<int, std::vector<int>> nodeToElems;
  for (int e = 0; e < mesh->loc_nElem(); e++)
  {
    int eNN = mesh->_adjcyEN->getNumNbors(e, IndexType::Local);
    for (int i = 0; i < eNN; i++)
    {
      int gn = mesh->_adjcyEN->getNbor(e, i, IndexType::Global);
      nodeToElems[gn].push_back(e);
    }
  }

  int offs = mesh->offs_nElem();
  std::set<std::pair<int,int>> seen;
  std::vector<std::pair<int,int>> result;

  for (int e1 = 0; e1 < mesh->loc_nElem(); e1++)
  {
    if((int)dhand->elemAuxF->getValue(0,e1)%2 == 0)
    {
      int sCount = 0;
      for (auto& sc : sideCorners)
      {
        int gA = mesh->_adjcyEN->getNbor(e1, sc[0], IndexType::Global);
        int gB = mesh->_adjcyEN->getNbor(e1, sc[1], IndexType::Global);

        const auto& eA = nodeToElems[gA];
        const auto& eB = nodeToElems[gB];

        for (int e2 : eA)
        {
          if (e2 == e1) continue;
          if (std::find(eB.begin(), eB.end(), e2) == eB.end()) continue;
          if ((int)dhand->elemAuxF->getValue(0,e2)%rPrimes[rInt] != 0) continue;
          int g1 = e1 + offs, g2 = e2 + offs;
          auto key = std::make_pair(std::min(g1,g2), std::max(g1,g2));
          if (seen.insert(key).second)
          {
            result.push_back(key);
            double e1Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e1,IndexType::Global);
            if ((int)e1Val%rPrimes[sCount] != 0)
              dhand->elemAuxF->setValue("GhP"+to_string(rInt),e1,IndexType::Global,e1Val*rPrimes[sCount]);
            double e2Val = dhand->elemAuxF->getValue("GhP"+to_string(rInt),e2,IndexType::Global);
            if ((int)e2Val%rPrimes[(sCount+2)%4] != 0)
              dhand->elemAuxF->setValue("GhP"+to_string(rInt),e2,IndexType::Global,e2Val*rPrimes[(sCount+2)%4]);
          }
        }
        sCount++;
      }
    }
  }
  return result;
}

// Filling for stokes flow velocity(R0)
void LSV0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  
  double mu0 = fillStr.getRealParameter(StokesParams::mu0);
  
  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;    //  pDim = 2
  int eNN  = subFill.eNN;    //  eNN = 9
  int numDOFs = subFill.numDOFs;//  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords(subFill.nborCoords.data(), eNN, 3);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  
  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  ttl::wrapper<double,2> Bk0(fillStr.Bk(0).data(), eNN,   numDOFs);   // 9 * 2
  
  ttl::wrapper<double,4> Ak00(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);    // 9 * 2 * 9 * 2

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//
  Bk0 *= 0;
  Ak00 *= 0;
  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofs = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofs(0),dofs(1)};
  double uu = sqrt((-x(1)+0.5)*(-x(1)+0.5)+(x(0)+0.3)*(x(0)+0.3));

  ttl::tensor<double,1> f(2);
  f(0) = 2.*mu0*M_PI*M_PI*sin(M_PI*x(0))*cos(M_PI*x(1))+M_PI*cos(M_PI*x(0))*sin(M_PI*x(1));
  f(1) = -2.*mu0*M_PI*M_PI*cos(M_PI*x(0))*sin(M_PI*x(1))+M_PI*sin(M_PI*x(0))*cos(M_PI*x(1));
  
  for (int a{};a < eNN;a++)
  for (int i=0;i < 2;i++)
    Bk0(a,i) += jac*bf(a)*f(i);

  // Indices form
  for (int a=0;a < eNN;a++)
  {
  for (int b=0;b < eNN;b++)
  {
    Ak00(a, 0, b, 0) += jac * mu0 * (2*Dbf_g(a,0)*Dbf_g(b,0) + Dbf_g(a,1)*Dbf_g(b,1));
    Ak00(a, 0, b, 1) += jac * mu0 * (Dbf_g(a,1)*Dbf_g(b,0));
    Ak00(a, 1, b, 0) += jac * mu0 * (Dbf_g(a,0)*Dbf_g(b,1)); 
    Ak00(a, 1, b, 1) += jac * mu0 * (2*Dbf_g(a,1)*Dbf_g(b,1) + Dbf_g(a,0)*Dbf_g(b,0));
  }
  }
  

//   // Output integration points
//   ofstream myfile;
//   if (!fileExists("Cut.csv"))
//   {
//   myfile.open("Cut.csv", std::ios_base::app);
//   myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
//   myfile.close();
//   }
//   myfile.open("Cut.csv", std::ios_base::app);
//   myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << jac << endl;
//   myfile.close();
}

// Filling for stokes flow velocity (R1)
void LSV1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  
  double mu1 = fillStr.getRealParameter(StokesParams::mu1);
  
  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;    //  pDim = 2
  int eNN  = subFill.eNN;    //  eNN = 9
  int numDOFs = subFill.numDOFs;//  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords(subFill.nborCoords.data(), eNN, 3);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  
  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  ttl::wrapper<double,2> Bk0(fillStr.Bk(0).data(), eNN,   numDOFs);   // 9 * 2
  
  ttl::wrapper<double,4> Ak00(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);    // 9 * 2 * 9 * 2

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//
  Bk0 *= 0;
  Ak00 *= 0;

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofs = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofs(2),dofs(3)};
  double uu = sqrt((-x(1)+0.5)*(-x(1)+0.5)+(x(0)+0.3)*(x(0)+0.3));

  ttl::tensor<double,1> f(2);
  
  f(0) = 2.*mu1*M_PI*M_PI*sin(M_PI*x(0))*cos(M_PI*x(1))+M_PI*cos(M_PI*x(0))*sin(M_PI*x(1));
  f(1) = -2.*mu1*M_PI*M_PI*cos(M_PI*x(0))*sin(M_PI*x(1))+M_PI*sin(M_PI*x(0))*cos(M_PI*x(1));
  for (int a{};a < eNN;a++)
  for (int i=0;i < 2;i++)
    Bk0(a,i+2) += jac*bf(a)*f(i);

  // Indices form
  for (int a=0;a < eNN;a++)
  {
  for (int b=0;b < eNN;b++)
  {
    Ak00(a, 2, b, 2) += jac * mu1 * (2*Dbf_g(a,0)*Dbf_g(b,0) + Dbf_g(a,1)*Dbf_g(b,1));
    Ak00(a, 2, b, 3) += jac * mu1 * (Dbf_g(a,1)*Dbf_g(b,0));
    Ak00(a, 3, b, 2) += jac * mu1 * (Dbf_g(a,0)*Dbf_g(b,1)); 
    Ak00(a, 3, b, 3) += jac * mu1 * (2*Dbf_g(a,1)*Dbf_g(b,1) + Dbf_g(a,0)*Dbf_g(b,0));
  }
  }
  
//   // Output integration points
//   ofstream myfile;
//   if (!fileExists("Cut.csv"))
//   {
//   myfile.open("Cut.csv", std::ios_base::app);
//   myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
//   myfile.close();
//   }
//   myfile.open("Cut.csv", std::ios_base::app);
//   myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << jac << endl;
//   myfile.close();
}

// Filling for stokes flow pressure (R0)
void LSP0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  
  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;    //  pDim = 2
  int eNN  = subFill.eNN;     //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 2
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoordsEl = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);

  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  // cout << Dbf_g << endl;
  tensor<double,1> eC = bf*nborCoordsEl;
  
  ttl::tensor<double,1> x = bf*nborCoords;

  tensor<double,1> bf1 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
  double p = nborDOFs(0,4)*bf1(0)+(nborDOFs(1,4))*bf1(1)+(nborDOFs(3,4))*bf1(2);

  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  
  ttl::wrapper<double,4> Ak00(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);    // 9 * 6 * 9 * 6

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//
  Ak00 *=0;
  std::vector<int> eNNp = {0,1,3};
  // Indices form
  for (int a = 0; a < eNN;a++)
  {
  for (int b = 0; b < 3;b++)
  {
    for (int i = 0; i < 2; i++)
    {
    Ak00(a, i, eNNp[b], 4) += -jac * (Dbf_g(a,i) * bf1(b));
    Ak00(eNNp[b], 4, a, i) += -jac * (bf1(b) * Dbf_g(a,i));
    }
  }
  }
  
}

// Filling for stokes flow pressure (R1)
void LSP1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  
  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;    //  pDim = 2
  int eNN  = subFill.eNN;     //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 2
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoordsEl = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);

  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  // cout << Dbf_g << endl;
  tensor<double,1> eC = bf*nborCoordsEl;
  
  ttl::tensor<double,1> x = bf*nborCoords;

  tensor<double,1> bf1 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
  double p = nborDOFs(0,5)*bf1(0)+(nborDOFs(1,5))*bf1(1)+(nborDOFs(3,5))*bf1(2);

  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//
  
  ttl::wrapper<double,4> Ak00(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);    // 9 * 6 * 9 * 6

  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//
  Ak00 *=0;
  std::vector<int> eNNp = {0,1,3};
  // Indices form
  for (int a = 0; a < eNN;a++)
  {
    for (int b = 0; b < 3;b++)
    {
      for (int i = 0; i < 2; i++)
      {
      Ak00(a, i+2, eNNp[b], 5) += -jac * (Dbf_g(a,i) * bf1(b));
      Ak00(eNNp[b], 5, a, i+2) += -jac * (bf1(b) * Dbf_g(a,i));
      }
    }
  }
}

// Filling for interface terms
void LSBorder(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  
  //============      Initialize variables       ===========//
  // Parameters
  double beta = fillStr.getRealParameter(StokesParams::beta);
  double mu0 = fillStr.getRealParameter(StokesParams::mu0);
  double mu1 = fillStr.getRealParameter(StokesParams::mu1);


  // Background
  SubFillStructure& subFill = fillStr[0];
  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  std::vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bft(subFill.nborBFs(), eNN);

  // ===================== Values at int. points ==================== //
  // Compute jacobian
  std::vector<double> dbf(eNN*pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

  ttl::tensor<double,2> dbft(eNN,pDim);
  for (int a = 0; a < eNN; a++)
  for (int i = 0; i < pDim; i++)
    dbft(a,i) = dbf[pDim*a+i];
  // Get tangent to immersed mesh at integration point
  auto immMesh = subFill.dhandDHand->mesh->_childMesh;
  std::vector<double> t(3);
  for (int n = 0; n < nDim; n++)
    t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim*subFill.kPt+n];
  jac = Math::Norm3D(t.data());

  // Compute unitary normal
  ttl::tensor<double,1> n(2);
  n(0) = t[1]/jac;
  n(1) = -t[0]/jac;
  n *=-1;
  // Compute coordinates using the back mesh
  std::vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
  for (int d = 0; d < nDim; d++)
    x[d] += coords[nDim*i+d] * bf[i];
  }

  ttl::tensor<double,1> dofs = bft*nborDOFs;
  ttl::tensor<double,1> u0 = {dofs(0),dofs(1)};
  ttl::tensor<double,1> u1 = {dofs(2),dofs(3)};
  ttl::tensor<double,2> ddofs = product(dbft,nborDOFs,{{0,0}});
  ttl::tensor<double,2> du0 = {{ddofs(0,0),ddofs(0,1)},{ddofs(1,0),ddofs(1,1)}};
  ttl::tensor<double,2> du1 = {{ddofs(0,2),ddofs(0,3)},{ddofs(1,2),ddofs(1,3)}};

  tensor<double,2> nborLocCoords = {{-1,-1},{0,-1},{1,-1},{-1,0},{0,0},{1,0},{-1,1},{0,1},{1,1}};
  tensor<double,1> eC = bft*nborLocCoords;
  tensor<double,1> bf1 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};
  double p0 = bf1(0)*nborDOFs(0,4) + bf1(1)*nborDOFs(1,4) + bf1(2)*nborDOFs(3,4);
  double p1 = bf1(0)*nborDOFs(0,5) + bf1(1)*nborDOFs(1,5) + bf1(2)*nborDOFs(3,5);
  // =====================  Fill linear system ===================== //
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  double gDx = 0.;
  double gDy = 0.;
  for(int a = 0; a < eNN; a++)
    for(int i = 0; i < pDim; i++)
      for(int b = 0; b < eNN; b++)
        for(int j = 0; j < pDim; j++)
        {
          Ak(a,i,b,j) = 0;
          Bk(a,i) = 0;
        }
  ttl::tensor<double,1> f(2);

  double uu = sqrt((-x[1]+0.5)*(-x[1]+0.5)+(x[0]+0.3)*(x[0]+0.3));
  ttl::tensor<double,1> gD = {(-x[1]+0.5)/uu,(x[0]+0.3)/uu};

  std::vector<int> eNNp = {0,1,3};
  ttl::tensor<double,2> Id2 = Identity2;

  // Nitsche symmetric
  double gmm0 = 0.5;
  double gmm1 = 1.-gmm0;

  // Obtain Nitsche parameter from each side
  double C02 = subFill.dhandDHand->elemAuxF->getValue("l0",subFill.elemID);
  double C12 = subFill.dhandDHand->elemAuxF->getValue("l1",subFill.elemID);
  
  gmm0 = sqrt(C12)/(sqrt(C12)+sqrt(C02));
  gmm1 = 1.-gmm0;
  
  double C2 = gmm0*gmm0*C02;
  subFill.dhandDHand->elemAuxF->setValue("lE",subFill.elemID,IndexType::Local,C2);
  subFill.dhandDHand->elemAuxF->setValue("gmm0",subFill.elemID,IndexType::Local,gmm0);
  beta = 5.*C2;

  if (fillStr.getRealParameter(StokesParams::beta)>0)
  {
    beta = fillStr.getRealParameter(StokesParams::beta);
    // // beta *= 2*k0*k1/(k0+k1);
    // Viscosity-weighted average, as in CheckNitsche
    gmm0 = mu1/(mu0+mu1);
  }
  gmm1 = 1.-gmm0;



  for (int a = 0; a < eNN; a++)
  {
    double dbfnA{};
    for (int d = 0; d < pDim; d++)
      dbfnA += dbf[pDim*a+d]*n(d);
    

    for (int b = 0; b < eNN; b++)
    {
      double dbfnB{};
      for (int d = 0; d < pDim; d++)
        dbfnB += dbf[pDim*b+d]*n(d);

      // Penalty terms
      for(int i = 0; i < 2; i++)
      {
        Ak(a,i,b,i) += jac * beta * bf[a] * bf[b]; // (v0,u0,0)
        Ak(a,i,b,i+2) -= jac * beta * bf[a] * bf[b]; // -(v0,u1,0)
        Ak(a,i+2,b,i) -= jac * beta * bf[a] * bf[b]; // -(v1,u0,0)
        Ak(a,i+2,b,i+2) += jac * beta * bf[a] * bf[b]; // (v1,u1,0)
      }

      // Traction terms
      for(int i = 0; i < 2; i++)
      {
        
        if (a < 3)
        {
          Ak(eNNp[a],4,b,i) += gmm0 * jac * bf1(a)*bf[b]*n(i); // g0(q0,u0)
          Ak(eNNp[a],4,b,i+2) -= gmm0 * jac * bf1(a)*bf[b]*n(i); // g0(q0,u1)
          Ak(eNNp[a],4+1,b,i) += gmm1 * jac * bf1(a)*bf[b]*n(i); // g1(q1,u0)
          Ak(eNNp[a],4+1,b,i+2) -= gmm1 * jac * bf1(a)*bf[b]*n(i); // g1(q1,u1)

        }

        if (b < 3)
        {
          Ak(a,i,eNNp[b],4) += gmm0 * jac * bf1(b)*bf[a]*n(i); // g0(v0,p0)
          Ak(a,i,eNNp[b],4+1) += gmm1 * jac * bf1(b)*bf[a]*n(i); // g1(v0,p1)
          Ak(a,i+2,eNNp[b],4) -= gmm0 * jac * bf1(b)*bf[a]*n(i); // g0(v1,p0)
          Ak(a,i+2,eNNp[b],4+1) -= gmm1 * jac * bf1(b)*bf[a]*n(i); // g1(v1,p1)

        }

        for(int j = 0; j < 2; j++)
        {
          Ak(a,i,b,j) -= gmm0 * mu0 * jac * n(j) * dbf[pDim*b+i] * bf[a];  // -(v0,du0,1)
          Ak(a,i,b,j) -= gmm0 * mu0 * jac * bf[a] * dbfnB * Id2(i,j); // -(v0,du0,2)
          Ak(a,i,b,j) -= gmm0 * mu0 * jac * n(i) * dbf[pDim*a+j] * bf[b];  // -(dv0,u0,3)
          Ak(a,i,b,j) -= gmm0 * mu0 * jac * bf[b] * dbfnA * Id2(i,j); // -(dv0,u0,4)

          Ak(a,i,b,j+2) += gmm0 * mu0 * jac * n(i) * dbf[pDim*a+j] * bf[b];  // g0(v0,du1,1)
          Ak(a,i,b,j+2) += gmm0 * mu0 * jac * bf[b] * dbfnA * Id2(i,j); // g0(v0,du1,2)
          Ak(a,i,b,j+2) -= gmm1 * mu1 * jac * n(j) * dbf[pDim*b+i] * bf[a];  // -g1(dv0,u1,3)
          Ak(a,i,b,j+2) -= gmm1 * mu1 * jac * bf[a] * dbfnB * Id2(i,j); // -g1(dv0,u1,4)
          
          Ak(a,i+2,b,j) -= gmm1 * mu1 * jac * n(i) * dbf[pDim*a+j] * bf[b];  // -g1(v1,du0,1)
          Ak(a,i+2,b,j) -= gmm1 * mu1 * jac * bf[b] * dbfnA * Id2(i,j); // g1(v1,du0,2)
          Ak(a,i+2,b,j) += gmm0 * mu0 * jac * n(j) * dbf[pDim*b+i] * bf[a];  // g0(dv1,u0,3)
          Ak(a,i+2,b,j) += gmm0 * mu0 * jac * bf[a] * dbfnB * Id2(i,j); // g0(dv1,u0,4)

          Ak(a,i+2,b,j+2) += gmm1 * mu1 * jac * n(j) * dbf[pDim*b+i] * bf[a];  // (v0,du0,1)
          Ak(a,i+2,b,j+2) += gmm1 * mu1 * jac * bf[a] * dbfnB * Id2(i,j); // (v1,du1,2)
          Ak(a,i+2,b,j+2) += gmm1 * mu1 * jac * n(i) * dbf[pDim*a+j] * bf[b];  // (dv0,u0,3)
          Ak(a,i+2,b,j+2) += gmm1 * mu1 * jac * bf[b] * dbfnA * Id2(i,j); // (dv1,u1,4)
        }
      }
    }
  }
  fillStr.addToGlobalIntegral("Length", jac);
}

void LSF0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;

  int nS = fillStr.getIntParameter(StokesParams::timeStep);

  auto rngCoords = range(0,1);
  std::vector<int> nxt = {8, 16, 32, 64, 128};

  
  SubFillStructure& subFill = fillStr["backDHand"];

  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;       // Number of neighbor nodes
  int nDim = subFill.nDim;      // Number of spatial dimensions
  int pDim = subFill.pDim;      // Number of parametric dimension
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  double jac;
  ttl::tensor<double,2> Dbf_g(eNN,pDim); // dbf(a,i)
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  double tau = 0.1/double(nxt[nS]);
  if (g_tauMode == 1) tau /= fillStr.getRealParameter(StokesParams::mu0);
  if (g_tauMode == 2) tau = 0.;

  // Basis functions top
  tensor<double,2> bft = {{1.,0.5*(-sqrt(1./3.)+1.),1.},{1.,0.5*(sqrt(1./3.)+1.),1.}};
  
  // Basis functions bottom
  tensor<double,2> bfb = {{1.,0.5*(-sqrt(1./3.)+1.)},{1.,0.5*(sqrt(1./3.)+1.)}};

  // Basis functions right
  tensor<double,2> bfr = {{1.,1.,0.5*(-sqrt(1./3.)+1.)},{1.,1.,0.5*(sqrt(1./3.)+1.)}};

  // Basis functions left
  tensor<double,2> bfl = {{1.,0.5*(-sqrt(1./3.)+1.)},{1.,0.5*(sqrt(1./3.)+1.)}};
  int stbF = subFill.dhandDHand->elemAuxF->getValue("stbP",subFill.loc_elemID,IndexType::Local);


  ttl::wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN, numDOFs);     // 9 * 2
  ttl::wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN, numDOFs, eNN, numDOFs);     // 9 * 2
  for (int a{}; a < eNN; a++)
  {
    for (int i{}; i < numDOFs; i++)
    {
      Bk(a,i) = 0;
      for (int b{}; b < eNN; b++)
      {
        for (int j{}; j < numDOFs; j++)
        {
          Ak(a,i,b,j) = 0;
        }
      }
    }
  }
  double ray = 0;

  // Integrate right face
  if (stbF%3 == 0)
  {
  
    for (int k{}; k < 2; k++)
    {
      tensor<double,1> bflr(9);
      bflr(0) = bfr(k,0);
      bflr(1) = bfr(k,1);
      bflr(2) = -bfl(k,0);
      bflr(3) = bfr(k,2);
      bflr(4) = 0.;
      bflr(5) = -bfl(k,1);
      bflr(6) = 0.;
      bflr(7) = 0.;
      bflr(8) = 0.;

      for (int a{}; a < eNN; a++)
      {
        for (int b{}; b < eNN; b++)
        {
          Ak(a,4,b,4) -= sqrt(jac)*tau*bflr(a)*bflr(b);
        }
      }
    }
  }

  // Integrate top face
  if (stbF%5 == 0)
  {
    for (int k{}; k < 2; k++)
    {
      tensor<double,1> bftb(9);
      bftb(0) = bft(k,0);
      bftb(1) = bft(k,1);
      bftb(2) = 0.;
      bftb(3) = bft(k,2);
      bftb(4) = 0.;
      bftb(5) = 0;
      bftb(6) = -bfb(k,0);
      bftb(7) = -bfb(k,1);
      bftb(8) = 0.;

      for (int a{}; a < eNN; a++)
      {
        for (int b{}; b < eNN; b++)
        {
          Ak(a,4,b,4) -= sqrt(jac)*tau*bftb(a)*bftb(b);
        }
      }
    }
  }

}

void LSF1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;

  int nS = fillStr.getIntParameter(StokesParams::timeStep);

  auto rngCoords = range(0,1);
  std::vector<int> nxt = {8, 16, 32, 64, 128};

  
  SubFillStructure& subFill = fillStr["backDHand"];

  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;       // Number of neighbor nodes
  int nDim = subFill.nDim;      // Number of spatial dimensions
  int pDim = subFill.pDim;      // Number of parametric dimension
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  double jac;
  ttl::tensor<double,2> Dbf_g(eNN,pDim); // dbf(a,i)
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
  double tau = 0.2/double(nxt[nS]);
  if (g_tauMode == 1) tau /= fillStr.getRealParameter(StokesParams::mu1);
  if (g_tauMode == 2) tau = 0.;

  // Basis functions top
  tensor<double,2> bft = {{1.,0.5*(-sqrt(1./3.)+1.),1.},{1.,0.5*(sqrt(1./3.)+1.),1.}};
  
  // Basis functions bottom
  tensor<double,2> bfb = {{1.,0.5*(-sqrt(1./3.)+1.)},{1.,0.5*(sqrt(1./3.)+1.)}};

  // Basis functions right
  tensor<double,2> bfr = {{1.,1.,0.5*(-sqrt(1./3.)+1.)},{1.,1.,0.5*(sqrt(1./3.)+1.)}};

  // Basis functions left
  tensor<double,2> bfl = {{1.,0.5*(-sqrt(1./3.)+1.)},{1.,0.5*(sqrt(1./3.)+1.)}};
  int stbF = subFill.dhandDHand->elemAuxF->getValue("stbP",subFill.loc_elemID,IndexType::Local);

  ttl::wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN, numDOFs);     // 9 * 2
  ttl::wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN, numDOFs, eNN, numDOFs);     // 9 * 2
  for (int a{}; a < eNN; a++)
  {
    for (int i{}; i < numDOFs; i++)
    {
      Bk(a,i) = 0;
      for (int b{}; b < eNN; b++)
      {
        for (int j{}; j < numDOFs; j++)
        {
          Ak(a,i,b,j) = 0;
        }
      }
    }
  }
  double ray = 0;

  // Integrate right face
  if (stbF%7 == 0)
  {
    for (int k{}; k < 2; k++)
    {
      tensor<double,1> bflr(9);
      bflr(0) = bfr(k,0);
      bflr(1) = bfr(k,1);
      bflr(2) = -bfl(k,0);
      bflr(3) = bfr(k,2);
      bflr(4) = 0.;
      bflr(5) = -bfl(k,1);
      bflr(6) = 0.;
      bflr(7) = 0.;
      bflr(8) = 0.;

      for (int a{}; a < eNN; a++)
      {
        for (int b{}; b < eNN; b++)
        {
          Ak(a,5,b,5) -= sqrt(jac)*tau*bflr(a)*bflr(b);
        }
      }
    }
  }

  // Integrate top face
  if (stbF%11 == 0)
  {
    for (int k{}; k < 2; k++)
    {
      tensor<double,1> bftb(9);
      bftb(0) = bft(k,0);
      bftb(1) = bft(k,1);
      bftb(2) = 0.;
      bftb(3) = bft(k,2);
      bftb(4) = 0.;
      bftb(5) = 0;
      bftb(6) = -bfb(k,0);
      bftb(7) = -bfb(k,1);
      bftb(8) = 0.;

      for (int a{}; a < eNN; a++)
      {
        for (int b{}; b < eNN; b++)
        {
          Ak(a,5,b,5) -= sqrt(jac)*tau*bftb(a)*bftb(b);
        }
      }
    }
  }
}

void FacetStbR0(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  int nS = fillStr.getIntParameter(StokesParams::timeStep);

  SubFillStructure& e0 = fillStr[0];
  SubFillStructure& e1 = fillStr[1];
  int eNN  = e0.eNN;
  int nDim = e0.nDim;
  int pDim = e0.pDim;
  int numDOFs = e0.numDOFs;
  // double gmm2 = 0.01;
  double* Dbf0    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
  // double* bf0     = e0.nborBFs();      // local BF: [eNN]
  // double* bf1     = e1.nborBFs();      // local BF: [eNN]
  double* coords0 = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]
  double* coords1 = e1.nborCoords.data();   // node coordinates:     [eNN × nDim]


  ttl::wrapper<double,1> bf0(e0.nborBFs(),eNN);
  ttl::wrapper<double,1> bf1(e1.nborBFs(),eNN);
  ttl::wrapper<double,2> nborDOFs0(e0.nborDOFs.data(), eNN, numDOFs);
  ttl::wrapper<double,2> nborDOFs1(e1.nborDOFs.data(), eNN, numDOFs);

  double h = fabs(coords0[0]-coords0[(eNN-1)*nDim]);
  double gmm1 = 0.1;
  double gmm2 = 0.1;
  double gmmD = 0.;
  double gmmP = 0.;//-0.05;
  double gmmP1 = 0.;//-0.01;

  // Reference tangent vector along the boundary side (length pDim)
  std::vector<double> tangRef = e0.tangentsBoundaryRef();

  // Push tangRef through the Jacobian to obtain the physical tangent
  //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
  //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
  std::vector<double> tangPhys(nDim, 0.0);
  for (int a = 0; a < nDim; a++)
  {
    for (int b = 0; b < pDim; b++)
    {
      double Jab = 0.0;
      for (int i = 0; i < eNN; i++)
        Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
      tangPhys[a] += Jab * tangRef[b];
    }
  }
  tensor<double,1> x0(2);
  tensor<double,1> x1(2);
  for (int i = 0; i < pDim; i++)
  {
    x0(i) = 0;
    x1(i) = 0;
  }

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      x0(i) += bf0(a)*coords0[a*nDim + i];
      x1(i) += bf1(a)*coords1[a*nDim + i];
    }
  }

  tensor<double,2> dbf(9,2);

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      dbf(a,i) = Dbf0[a*pDim + i];
    }
  }
  
  double edge_jac = 0.0;
  for (double t : tangPhys) edge_jac += t * t;
  edge_jac = std::sqrt(edge_jac);

  tensor<double,1> n(2);
  // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
  n(0) = tangPhys[1]/edge_jac;
  n(1) = -tangPhys[0]/edge_jac;

  
  tensor<double,2> nborLocCoords = {{-1,-1},{0,-1},{1,-1},{-1,0},{0,0},{1,0},{-1,1},{0,1},{1,1}};
  tensor<double,1> eC0 = bf0*nborLocCoords;
  tensor<double,1> bfp0 = {1.,0.5*(eC0(0)+1.),0.5*(eC0(1)+1.)};
  tensor<double,2> dbfp0 = {{0.,0.},{0.5,0.},{0.,0.5}};
  
  tensor<double,1> eC1 = bf1*nborLocCoords;
  tensor<double,1> bfp1 = {1.,0.5*(eC1(0)+1.),0.5*(eC1(1)+1.)};
  tensor<double,2> dbfp1 = {{0.,0.},{0.5,0.},{0.,0.5}};

  tensor<double,1> bfpN0 = {bfp0(0),bfp0(1),0,bfp0(2),0,0,0,0,0};
  tensor<double,1> bfpN1 = {bfp1(0),bfp1(1),0,bfp1(2),0,0,0,0,0};

  tensor<double,2> Jac(2,2);
  for (int i = 0 ; i < 2; i++)
    for (int j = 0 ; j < 2; j++)
      Jac(i,j) = 0;
  
  for (int a = 0; a < eNN; a++)
    for (int d0 = 0; d0 < 2; d0++)
      for (int d1 = 0; d1 < 2; d1++)
        Jac(d0,d1) += coords0[a*nDim + d1]*Dbf0[pDim*a+d0];
  
  tensor<double,2> dbfp0_g = dbfp0*Jac.inv();
  tensor<double,2> dbfp1_g = dbfp1*Jac.inv();
  
  tensor<double,2> gDbf0(eNN,pDim);
  tensor<double,3> gHbf0(eNN,pDim,pDim);
  tensor<double,1> gLbf0(eNN);
  double jac0;

  tensor<double,1> HbfN0(eNN);
  GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
  tensor<double,1> DbfN0 = gDbf0*n;

  tensor<double,2> gDbf1(eNN,pDim);
  tensor<double,3> gHbf1(eNN,pDim,pDim);
  tensor<double,1> gLbf1(eNN);
  double jac1;

  tensor<double,1> HbfN1(eNN);
  GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
  tensor<double,1> DbfN1 = gDbf1*n;
  tensor<double,1> Dbfu0 = DbfN0*nborDOFs0;
  tensor<double,1> Dbfu1 = DbfN1*nborDOFs1;

  tensor<double,2> DivbfN0(eNN,2);
  tensor<double,2> DivbfN1(eNN,2);
  tensor<double,1> DbfpN0(eNN);
  tensor<double,1> DbfpN1(eNN);
  tensor<int,1> eNNp = {0,1,-1,2,-1,-1,-1,-1,-1};
  for (int a = 0; a < eNN; a++)
  {
    if (fabs(n(0))>fabs(n(1))) // Vertical face
    {
      HbfN0(a) = gHbf0(a,0,0);
      HbfN1(a) = gHbf1(a,0,0);

      DivbfN0(a,0) = gHbf0(a,0,0);
      DivbfN0(a,1) = gHbf0(a,0,1);
      
      DivbfN1(a,0) = gHbf1(a,0,0);
      DivbfN1(a,1) = gHbf1(a,0,1);

      if (eNNp(a) > -1)
      {
        DbfpN0(a) = dbfp0_g(eNNp(a),0);
        DbfpN1(a) = dbfp1_g(eNNp(a),0);
      }
      else
      {
        DbfpN0(a) = 0;
        DbfpN1(a) = 0;
      }
    }
    else // Horizontal face
    {
      HbfN0(a) = gHbf0(a,1,1);
      HbfN1(a) = gHbf1(a,1,1);

      DivbfN0(a,0) = gHbf0(a,1,0);
      DivbfN0(a,1) = gHbf0(a,1,1);
      
      DivbfN1(a,0) = gHbf1(a,1,0);
      DivbfN1(a,1) = gHbf1(a,1,1);

      if (eNNp(a) > -1)
      {
        DbfpN0(a) = dbfp0_g(eNNp(a),1);
        DbfpN1(a) = dbfp1_g(eNNp(a),1);
      }
      else
      {
        DbfpN0(a) = 0;
        DbfpN1(a) = 0;
      }
    }
  }
            
  tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < numDOFs; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < numDOFs; j++)
        {
          Ak00(a,i,b,j) = 0;
          Ak01(a,i,b,j) = 0;
          Ak10(a,i,b,j) = 0;
          Ak11(a,i,b,j) = 0;
        }
      }
    }
  }


  // s(u,v)
  for (int i = 0; i < 2; i++)
  {
    for (int a = 0; a < eNN; a++)
    {
      for (int b = 0; b < eNN; b++)
      {
        Ak00(a,i,b,i) += 2.*edge_jac*h*h*h*gmm1*(DbfN0(a)*DbfN0(b));
        Ak01(a,i,b,i) += -2.*edge_jac*h*h*h*gmm1*(DbfN0(a)*DbfN1(b));
        Ak10(a,i,b,i) += -2.*edge_jac*h*h*h*gmm1*(DbfN1(a)*DbfN0(b));
        Ak11(a,i,b,i) += 2.*edge_jac*h*h*h*gmm1*(DbfN1(a)*DbfN1(b));

        if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
        {
          Ak00(a,i,b,i) += 2.*edge_jac*h*h*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
          Ak01(a,i,b,i) += -2.*edge_jac*h*h*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
          Ak10(a,i,b,i) += -2.*edge_jac*h*h*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
          Ak11(a,i,b,i) += 2.*edge_jac*h*h*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
        }
      }   
    }
  }

  // // s(\nabla \cdot u, q)
  for (int i = 0; i < 2; i++)
  {
    for (int a = 0; a < eNN; a++)
    {
      for (int b = 0; b < eNN; b++)
      {
        Ak00(a,4,b,i) += -2.*edge_jac*h*h*h*gmmD*DbfpN0(a)*DivbfN0(b,i);
        Ak00(a,i,b,4) += -2.*edge_jac*h*h*h*gmmD*DbfpN0(b)*DivbfN0(a,i);

        Ak01(a,4,b,i) += 2.*edge_jac*h*h*h*gmmD*DbfpN0(a)*DivbfN1(b,i);
        Ak01(a,i,b,4) += 2.*edge_jac*h*h*h*gmmD*DbfpN0(b)*DivbfN1(a,i);

        Ak10(a,4,b,i) += 2.*edge_jac*h*h*h*gmmD*DbfpN1(a)*DivbfN0(b,i);
        Ak10(a,i,b,4) += 2.*edge_jac*h*h*h*gmmD*DbfpN1(b)*DivbfN0(a,i);
        
        Ak11(a,4,b,i) += -2.*edge_jac*h*h*h*gmmD*DbfpN1(a)*DivbfN1(b,i);
        Ak11(a,i,b,4) += -2.*edge_jac*h*h*h*gmmD*DbfpN1(b)*DivbfN1(a,i);
      }
    }
  }

  // // s(p, q)
  for (int a = 0; a < eNN; a++)
  {
    for (int b = 0; b < eNN; b++)
    {
      Ak00(a,4,b,4) += 2.*edge_jac*h*gmmP*bfpN0(a)*bfpN0(b);
      Ak01(a,4,b,4) += -2.*edge_jac*h*gmmP*bfpN0(a)*bfpN1(b);
      Ak10(a,4,b,4) += -2.*edge_jac*h*gmmP*bfpN1(a)*bfpN0(b);
      Ak11(a,4,b,4) += 2.*edge_jac*h*gmmP*bfpN1(a)*bfpN1(b);

      Ak00(a,4,b,4) += 2.*edge_jac*h*h*h*gmmP1*DbfpN0(a)*DbfpN0(b);
      Ak01(a,4,b,4) += -2.*edge_jac*h*h*h*gmmP1*DbfpN0(a)*DbfpN1(b);
      Ak10(a,4,b,4) += -2.*edge_jac*h*h*h*gmmP1*DbfpN1(a)*DbfpN0(b);
      Ak11(a,4,b,4) += 2.*edge_jac*h*h*h*gmmP1*DbfpN1(a)*DbfpN1(b);
    }
  }

  // cout << Ak00(ttl::all,4,ttl::all,4) << endl;
  // cout << Ak01(ttl::all,4,ttl::all,4) << endl;
  // cout << Ak10(ttl::all,4,ttl::all,4) << endl;
  // cout << Ak11(ttl::all,4,ttl::all,4) << endl;
  // cout << bfpN0 << endl;
  // cout << bfpN1 << endl;
  

  for (int a = 0; a < numDOFs; a++) {
  if (std::isnan(Dbfu0(a)) || std::isinf(Dbfu0(a)))
      std::cout << "NaN/Inf in Dbfu0 at element " << e0.elemID << std::endl;
  if (std::isnan(Dbfu1(a)) || std::isinf(Dbfu1(a)))
      std::cout << "NaN/Inf in Dbfu1 at element " << e0.elemID << std::endl;
  }
  // 2. Zero or negative edge_jac
  if (edge_jac <= 0)
      std::cout << "Bad edge_jac: " << edge_jac << " at edge " << e0.elemID << std::endl;
  // 3. Zero h
  if (h <= 0)
    std::cout << "Bad h: " << h << " at edge " << e0.elemID << std::endl;
  
  // fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
  // cout << e0.kPt << " " <<e1.kPt << endl;
  ofstream myfile;
  myfile.open("fStb0."+to_string(nS)+".csv", std::ios_base::app);
  myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
  myfile.close();

  myfile.open("fStb1."+to_string(nS)+".csv", std::ios_base::app);
  myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
  myfile.close();

}

void FacetStbR1(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  int nS = fillStr.getIntParameter(StokesParams::timeStep);

  SubFillStructure& e0 = fillStr[0];
  SubFillStructure& e1 = fillStr[1];
  int eNN  = e0.eNN;
  int nDim = e0.nDim;
  int pDim = e0.pDim;
  int numDOFs = e0.numDOFs;
  // double gmm2 = 0.01;
  double* Dbf0    = e0.nborBFsGrads();      // local BF derivatives: [eNN × pDim]
  // double* bf0     = e0.nborBFs();      // local BF: [eNN]
  // double* bf1     = e1.nborBFs();      // local BF: [eNN]
  double* coords0 = e0.nborCoords.data();   // node coordinates:     [eNN × nDim]
  double* coords1 = e1.nborCoords.data();   // node coordinates:     [eNN × nDim]


  ttl::wrapper<double,1> bf0(e0.nborBFs(),eNN);
  ttl::wrapper<double,1> bf1(e1.nborBFs(),eNN);
  ttl::wrapper<double,2> nborDOFs0(e0.nborDOFs.data(), eNN, numDOFs);
  ttl::wrapper<double,2> nborDOFs1(e1.nborDOFs.data(), eNN, numDOFs);

  double h = fabs(coords0[0]-coords0[(eNN-1)*nDim]);
  double gmm1 = 0.1;
  double gmm2 = 0.1;
  double gmmD = 0.;
  double gmmP = 0.;//-0.05;
  double gmmP1 = 0.;//-0.01;

  // Reference tangent vector along the boundary side (length pDim)
  std::vector<double> tangRef = e0.tangentsBoundaryRef();

  // Push tangRef through the Jacobian to obtain the physical tangent
  //   J[a,b] = sum_i Dbf[i*pDim+b] * coords[i*nDim+a]
  //   tangPhys[a] = sum_b J[a,b] * tangRef[b]
  std::vector<double> tangPhys(nDim, 0.0);
  for (int a = 0; a < nDim; a++)
  {
    for (int b = 0; b < pDim; b++)
    {
      double Jab = 0.0;
      for (int i = 0; i < eNN; i++)
        Jab += Dbf0[i*pDim + b] * coords0[i*nDim + a];
      tangPhys[a] += Jab * tangRef[b];
    }
  }
  tensor<double,1> x0(2);
  tensor<double,1> x1(2);
  for (int i = 0; i < pDim; i++)
  {
    x0(i) = 0;
    x1(i) = 0;
  }

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      x0(i) += bf0(a)*coords0[a*nDim + i];
      x1(i) += bf1(a)*coords1[a*nDim + i];
    }
  }

  tensor<double,2> dbf(9,2);

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      dbf(a,i) = Dbf0[a*pDim + i];
    }
  }
  
  double edge_jac = 0.0;
  for (double t : tangPhys) edge_jac += t * t;
  edge_jac = std::sqrt(edge_jac);

  tensor<double,1> n(2);
  // Face normal: tangent rotated by -90 deg (sign irrelevant, both sides use the same n)
  n(0) = tangPhys[1]/edge_jac;
  n(1) = -tangPhys[0]/edge_jac;

  
  tensor<double,2> nborLocCoords = {{-1,-1},{0,-1},{1,-1},{-1,0},{0,0},{1,0},{-1,1},{0,1},{1,1}};
  tensor<double,1> eC0 = bf0*nborLocCoords;
  tensor<double,1> bfp0 = {1.,0.5*(eC0(0)+1.),0.5*(eC0(1)+1.)};
  tensor<double,2> dbfp0 = {{0.,0.},{0.5,0.},{0.,0.5}};
  
  tensor<double,1> eC1 = bf1*nborLocCoords;
  tensor<double,1> bfp1 = {1.,0.5*(eC1(0)+1.),0.5*(eC1(1)+1.)};
  tensor<double,2> dbfp1 = {{0.,0.},{0.5,0.},{0.,0.5}};

  tensor<double,1> bfpN0 = {bfp0(0),bfp0(1),0,bfp0(2),0,0,0,0,0};
  tensor<double,1> bfpN1 = {bfp1(0),bfp1(1),0,bfp1(2),0,0,0,0,0};

  tensor<double,2> Jac(2,2);
  for (int i = 0 ; i < 2; i++)
    for (int j = 0 ; j < 2; j++)
      Jac(i,j) = 0;
  
  for (int a = 0; a < eNN; a++)
    for (int d0 = 0; d0 < 2; d0++)
      for (int d1 = 0; d1 < 2; d1++)
        Jac(d0,d1) += coords0[a*nDim + d1]*Dbf0[pDim*a+d0];
  
  tensor<double,2> dbfp0_g = dbfp0*Jac.inv();
  tensor<double,2> dbfp1_g = dbfp1*Jac.inv();
  
  tensor<double,2> gDbf0(eNN,pDim);
  tensor<double,3> gHbf0(eNN,pDim,pDim);
  tensor<double,1> gLbf0(eNN);
  double jac0;

  tensor<double,1> HbfN0(eNN);
  GlobalBasisFunctions::hessians(gDbf0,jac0,gHbf0,gLbf0,e0);
  tensor<double,1> DbfN0 = gDbf0*n;

  tensor<double,2> gDbf1(eNN,pDim);
  tensor<double,3> gHbf1(eNN,pDim,pDim);
  tensor<double,1> gLbf1(eNN);
  double jac1;

  tensor<double,1> HbfN1(eNN);
  GlobalBasisFunctions::hessians(gDbf1,jac1,gHbf1,gLbf1,e1);
  tensor<double,1> DbfN1 = gDbf1*n;
  tensor<double,1> Dbfu0 = DbfN0*nborDOFs0;
  tensor<double,1> Dbfu1 = DbfN1*nborDOFs1;

  tensor<double,2> DivbfN0(eNN,2);
  tensor<double,2> DivbfN1(eNN,2);
  tensor<double,1> DbfpN0(eNN);
  tensor<double,1> DbfpN1(eNN);
  tensor<int,1> eNNp = {0,1,-1,2,-1,-1,-1,-1,-1};
  for (int a = 0; a < eNN; a++)
  {
    if (fabs(n(0))>fabs(n(1))) // Vertical face
    {
      HbfN0(a) = gHbf0(a,0,0);
      HbfN1(a) = gHbf1(a,0,0);

      DivbfN0(a,0) = gHbf0(a,0,0);
      DivbfN0(a,1) = gHbf0(a,0,1);
      
      DivbfN1(a,0) = gHbf1(a,0,0);
      DivbfN1(a,1) = gHbf1(a,0,1);

      if (eNNp(a) > -1)
      {
        DbfpN0(a) = dbfp0_g(eNNp(a),0);
        DbfpN1(a) = dbfp1_g(eNNp(a),0);
      }
      else
      {
        DbfpN0(a) = 0;
        DbfpN1(a) = 0;
      }
    }
    else // Horizontal face
    {
      HbfN0(a) = gHbf0(a,1,1);
      HbfN1(a) = gHbf1(a,1,1);

      DivbfN0(a,0) = gHbf0(a,1,0);
      DivbfN0(a,1) = gHbf0(a,1,1);
      
      DivbfN1(a,0) = gHbf1(a,1,0);
      DivbfN1(a,1) = gHbf1(a,1,1);

      if (eNNp(a) > -1)
      {
        DbfpN0(a) = dbfp0_g(eNNp(a),1);
        DbfpN1(a) = dbfp1_g(eNNp(a),1);
      }
      else
      {
        DbfpN0(a) = 0;
        DbfpN1(a) = 0;
      }
    }
  }
            
  tensor<double,4,false> Ak00(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak01(fillStr.Ak(0,1).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak10(fillStr.Ak(1,0).data(),eNN,numDOFs,eNN,numDOFs);
  tensor<double,4,false> Ak11(fillStr.Ak(1,1).data(),eNN,numDOFs,eNN,numDOFs);

  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < numDOFs; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < numDOFs; j++)
        {
          Ak00(a,i,b,j) = 0;
          Ak01(a,i,b,j) = 0;
          Ak10(a,i,b,j) = 0;
          Ak11(a,i,b,j) = 0;
        }
      }
    }
  }


  // s(u,v)
  for (int i = 2; i < 4; i++)
  {
    for (int a = 0; a < eNN; a++)
    {
      for (int b = 0; b < eNN; b++)
      {
        Ak00(a,i,b,i) += 2.*edge_jac*h*h*h*gmm1*(DbfN0(a)*DbfN0(b));
        Ak01(a,i,b,i) += -2.*edge_jac*h*h*h*gmm1*(DbfN0(a)*DbfN1(b));
        Ak10(a,i,b,i) += -2.*edge_jac*h*h*h*gmm1*(DbfN1(a)*DbfN0(b));
        Ak11(a,i,b,i) += 2.*edge_jac*h*h*h*gmm1*(DbfN1(a)*DbfN1(b));

        if (e0.dhandDHand->mesh->basisFuncOrder() > 1)
        {
          Ak00(a,i,b,i) += 2.*edge_jac*h*h*h*h*h*gmm2*(HbfN0(a)*HbfN0(b));
          Ak01(a,i,b,i) += -2.*edge_jac*h*h*h*h*h*gmm2*(HbfN0(a)*HbfN1(b));
          Ak10(a,i,b,i) += -2.*edge_jac*h*h*h*h*h*gmm2*(HbfN1(a)*HbfN0(b));
          Ak11(a,i,b,i) += 2.*edge_jac*h*h*h*h*h*gmm2*(HbfN1(a)*HbfN1(b));
        }
      }   
    }
  }

  // // s(\nabla \cdot u, q)
  for (int i = 2; i < 4; i++)
  {
    for (int a = 0; a < eNN; a++)
    {
      for (int b = 0; b < eNN; b++)
      {
        Ak00(a,5,b,i) += -2.*edge_jac*h*h*h*gmmD*DbfpN0(a)*DivbfN0(b,i);
        Ak00(a,i,b,5) += -2.*edge_jac*h*h*h*gmmD*DbfpN0(b)*DivbfN0(a,i);

        Ak01(a,5,b,i) += 2.*edge_jac*h*h*h*gmmD*DbfpN0(a)*DivbfN1(b,i);
        Ak01(a,i,b,5) += 2.*edge_jac*h*h*h*gmmD*DbfpN0(b)*DivbfN1(a,i);

        Ak10(a,5,b,i) += 2.*edge_jac*h*h*h*gmmD*DbfpN1(a)*DivbfN0(b,i);
        Ak10(a,i,b,5) += 2.*edge_jac*h*h*h*gmmD*DbfpN1(b)*DivbfN0(a,i);
        
        Ak11(a,5,b,i) += -2.*edge_jac*h*h*h*gmmD*DbfpN1(a)*DivbfN1(b,i);
        Ak11(a,i,b,5) += -2.*edge_jac*h*h*h*gmmD*DbfpN1(b)*DivbfN1(a,i);
      }
    }
  }

  // // s(p, q)
  for (int a = 0; a < eNN; a++)
  {
    for (int b = 0; b < eNN; b++)
    {
      Ak00(a,5,b,5) += 2.*edge_jac*h*gmmP*bfpN0(a)*bfpN0(b);
      Ak01(a,5,b,5) += -2.*edge_jac*h*gmmP*bfpN0(a)*bfpN1(b);
      Ak10(a,5,b,5) += -2.*edge_jac*h*gmmP*bfpN1(a)*bfpN0(b);
      Ak11(a,5,b,5) += 2.*edge_jac*h*gmmP*bfpN1(a)*bfpN1(b);

      Ak00(a,5,b,5) += 2.*edge_jac*h*h*h*gmmP1*DbfpN0(a)*DbfpN0(b);
      Ak01(a,5,b,5) += -2.*edge_jac*h*h*h*gmmP1*DbfpN0(a)*DbfpN1(b);
      Ak10(a,5,b,5) += -2.*edge_jac*h*h*h*gmmP1*DbfpN1(a)*DbfpN0(b);
      Ak11(a,5,b,5) += 2.*edge_jac*h*h*h*gmmP1*DbfpN1(a)*DbfpN1(b);
    }
  }

  for (int a = 0; a < numDOFs; a++) {
  if (std::isnan(Dbfu0(a)) || std::isinf(Dbfu0(a)))
      std::cout << "NaN/Inf in Dbfu0 at element " << e0.elemID << std::endl;
  if (std::isnan(Dbfu1(a)) || std::isinf(Dbfu1(a)))
      std::cout << "NaN/Inf in Dbfu1 at element " << e0.elemID << std::endl;
  }
  // 2. Zero or negative edge_jac
  if (edge_jac <= 0)
      std::cout << "Bad edge_jac: " << edge_jac << " at edge " << e0.elemID << std::endl;
  // 3. Zero h
  if (h <= 0)
    std::cout << "Bad h: " << h << " at edge " << e0.elemID << std::endl;
  
  // fillStr.addToGlobalIntegral("total_edge_length", edge_jac);
  // cout << e0.kPt << " " <<e1.kPt << endl;
  ofstream myfile;
  myfile.open("fStb0."+to_string(nS)+".csv", std::ios_base::app);
  myfile << std::setprecision(16) << x0(0) << " " << x0(1) << " " << endl;
  myfile.close();

  myfile.open("fStb1."+to_string(nS)+".csv", std::ios_base::app);
  myfile << std::setprecision(16) << x1(0) << " " << x1(1) << " " << 1 << endl;
  myfile.close();

}


// ─── previous (coarser) level, for errors between successive levels ─────────
// The background meshes are nested uniform Q2 meshes, so the coarse solution
// can be evaluated exactly at any point of the fine mesh: locate the coarse
// cell on the uniform grid, map to reference coordinates and use that
// element's nodal values (slaves already hold their extrapolated values).
struct CoarseLevel
{
  bool valid = false;
  SmartPtr<DOFsHandler> dh;
  SmartPtr<DistributedMesh> immMesh; // keeps dh's child mesh alive
  int n = 0;
  double x0 = 0., y0 = 0., hx = 1., hy = 1.;
  std::vector<int> cell2elem;
};
static CoarseLevel g_coarse;

void setCoarseLevel(SmartPtr<DOFsHandler> dh, SmartPtr<DistributedMesh> immMesh, int n)
{
  auto mesh = dh->mesh;
  double xMin = 1e300, yMin = 1e300, xMax = -1e300, yMax = -1e300;
  for (int i = 0; i < mesh->nPts(); i++)
  {
    xMin = std::min(xMin, mesh->nodeCoord(i,0));
    xMax = std::max(xMax, mesh->nodeCoord(i,0));
    yMin = std::min(yMin, mesh->nodeCoord(i,1));
    yMax = std::max(yMax, mesh->nodeCoord(i,1));
  }
  g_coarse.dh = dh;
  g_coarse.immMesh = immMesh;
  g_coarse.n = n;
  g_coarse.x0 = xMin;
  g_coarse.y0 = yMin;
  g_coarse.hx = (xMax-xMin)/n;
  g_coarse.hy = (yMax-yMin)/n;
  g_coarse.cell2elem.assign(n*n, -1);
  for (int e = 0; e < mesh->nElem(); e++)
  {
    int c = mesh->_connec->getNbor(e, 4); // centre node
    int ix = (int)floor((mesh->nodeCoord(c,0)-xMin)/g_coarse.hx);
    int iy = (int)floor((mesh->nodeCoord(c,1)-yMin)/g_coarse.hy);
    g_coarse.cell2elem[iy*n+ix] = e;
  }
  g_coarse.valid = true;
}

// Coarse velocity u, gradient G(i,J) = du_i/dx_J and pressure p of region rInt
// at x. Returns false if the coarse element is not active in that region
// (possible only where the coarse and fine interfaces differ).
bool evalCoarse(const double* x, int rInt, double u[2], double G[2][2], double& p, int& elem)
{
  const std::vector<int> rPrime = {3,5};
  auto mesh = g_coarse.dh->mesh;
  int n = g_coarse.n;
  int ix = std::min(n-1, std::max(0, (int)floor((x[0]-g_coarse.x0)/g_coarse.hx)));
  int iy = std::min(n-1, std::max(0, (int)floor((x[1]-g_coarse.y0)/g_coarse.hy)));
  elem = g_coarse.cell2elem[iy*n+ix];
  if (elem < 0 || (int)mesh->_elemFlags->getValue(1, elem, IndexType::Local)%rPrime[rInt] != 0)
    return false;

  int eNN = 9;
  std::vector<int> nds(eNN);
  for (int a = 0; a < eNN; a++)
    nds[a] = mesh->_connec->getNbor(elem, a);
  double ex0 = mesh->nodeCoord(nds[0],0), ey0 = mesh->nodeCoord(nds[0],1);
  double ex1 = mesh->nodeCoord(nds[8],0), ey1 = mesh->nodeCoord(nds[8],1);
  std::vector<double> rC = {(2.*x[0]-ex1-ex0)/(ex1-ex0), (2.*x[1]-ey1-ey0)/(ey1-ey0)};
  std::vector<std::vector<double>>& bf = mesh->_basisFunctions->computeBasisFunctionsReference(rC, mesh->_basisFunctions->getTag(elem, IndexType::Local));

  // Jacobian dx_J/dxi_K and its inverse
  double J[2][2] = {{0.,0.},{0.,0.}};
  for (int a = 0; a < eNN; a++)
    for (int K = 0; K < 2; K++)
      for (int d = 0; d < 2; d++)
        J[d][K] += mesh->nodeCoord(nds[a],d)*bf[1][2*a+K];
  double det = J[0][0]*J[1][1]-J[0][1]*J[1][0];
  double Ji[2][2] = {{J[1][1]/det, -J[0][1]/det}, {-J[1][0]/det, J[0][0]/det}}; // dxi_K/dx_J

  for (int i = 0; i < 2; i++)
  {
    u[i] = 0.;
    G[i][0] = G[i][1] = 0.;
  }
  for (int a = 0; a < eNN; a++)
  {
    double dx = bf[1][2*a]*Ji[0][0] + bf[1][2*a+1]*Ji[1][0];
    double dy = bf[1][2*a]*Ji[0][1] + bf[1][2*a+1]*Ji[1][1];
    for (int i = 0; i < 2; i++)
    {
      double v = g_coarse.dh->nodeDOFs->getValue(2*rInt+i, nds[a], IndexType::Global);
      u[i] += bf[0][a]*v;
      G[i][0] += dx*v;
      G[i][1] += dy*v;
    }
  }
  // P1 pressure from nodes 0, 1, 3 (as in LSBorder / CheckNitsche)
  double pa = g_coarse.dh->nodeDOFs->getValue(4+rInt, nds[0], IndexType::Global);
  double pb = g_coarse.dh->nodeDOFs->getValue(4+rInt, nds[1], IndexType::Global);
  double pc = g_coarse.dh->nodeDOFs->getValue(4+rInt, nds[3], IndexType::Global);
  p = pa + 0.5*(rC[0]+1.)*pb + 0.5*(rC[1]+1.)*pc;
  return true;
}

// ‖u_h − u_2h‖² and ‖∇u_h − ∇u_2h‖² contributions of region rInt at the current point
void addCoarseDiff(hiperlife::FillStructure& fillStr, const double* x, int rInt,
                   double ux, double uy, double Gxux, double Gyux, double Gxuy, double Gyuy, double jac)
{
  if (!g_coarse.valid)
    return;
  double u[2], G[2][2], p;
  int elem;
  if (!evalCoarse(x, rInt, u, G, p, elem))
  {
    fillStr.addToGlobalIntegral("dMiss", jac);
    return;
  }
  fillStr.addToGlobalIntegral("dErr", jac*((ux-u[0])*(ux-u[0]) + (uy-u[1])*(uy-u[1])));
  fillStr.addToGlobalIntegral("dGerr", jac*((Gxux-G[0][0])*(Gxux-G[0][0]) + (Gyux-G[0][1])*(Gyux-G[0][1])
                                          + (Gxuy-G[1][0])*(Gxuy-G[1][0]) + (Gyuy-G[1][1])*(Gyuy-G[1][1])));
}

// Check R0 solution
void CheckSolution0(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  const double ux_numeric = dofsI(N,0) * bf(N);
  const double uy_numeric = dofsI(N,1) * bf(N);
  const double Gxux_numeric = dofsI(N,0) * Dbf(N,0);
  const double Gxuy_numeric = dofsI(N,1) * Dbf(N,0);
  const double Gyux_numeric = dofsI(N,0) * Dbf(N,1);
  const double Gyuy_numeric = dofsI(N,1) * Dbf(N,1);

  const double ux_analytial = sin(M_PI*x(0))*cos(M_PI*x(1));
  const double Gxux_analytial = M_PI*cos(M_PI*x(0))*cos(M_PI*x(1));
  const double Gyux_analytial = -M_PI*sin(M_PI*x(0))*sin(M_PI*x(1));
  const double uy_analytial = -cos(M_PI*x(0))*sin(M_PI*x(1));
  const double Gxuy_analytial = M_PI*sin(M_PI*x(0))*sin(M_PI*x(1));
  const double Gyuy_analytial = -M_PI*cos(M_PI*x(0))*cos(M_PI*x(1));
  const double error = jac *((ux_numeric-ux_analytial)*(ux_numeric-ux_analytial)+(uy_numeric-uy_analytial)*(uy_numeric-uy_analytial));
  double Gerror = jac *((Gxux_numeric-Gxux_analytial)*(Gxux_numeric-Gxux_analytial)+(Gxuy_numeric-Gxuy_analytial)*(Gxuy_numeric-Gxuy_analytial));
  Gerror += jac *((Gyux_numeric-Gyux_analytial)*(Gyux_numeric-Gyux_analytial)+(Gyuy_numeric-Gyuy_analytial)*(Gyuy_numeric-Gyuy_analytial));
  fillStr.addToGlobalIntegral("error", error);
  fillStr.addToGlobalIntegral("Gerror", Gerror);
  addCoarseDiff(fillStr, x.data(), 0, ux_numeric, uy_numeric, Gxux_numeric, Gyux_numeric, Gxuy_numeric, Gyuy_numeric, jac);
}

// Check R1 solution
void CheckSolution1(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  const double ux_numeric = dofsI(N,2) * bf(N);
  const double uy_numeric = dofsI(N,3) * bf(N);
  const double Gxux_numeric = dofsI(N,2) * Dbf(N,0);
  const double Gxuy_numeric = dofsI(N,3) * Dbf(N,0);
  const double Gyux_numeric = dofsI(N,2) * Dbf(N,1);
  const double Gyuy_numeric = dofsI(N,3) * Dbf(N,1);

  const double ux_analytial = sin(M_PI*x(0))*cos(M_PI*x(1));
  const double Gxux_analytial = M_PI*cos(M_PI*x(0))*cos(M_PI*x(1));
  const double Gyux_analytial = -M_PI*sin(M_PI*x(0))*sin(M_PI*x(1));
  const double uy_analytial = -cos(M_PI*x(0))*sin(M_PI*x(1));
  const double Gxuy_analytial = M_PI*sin(M_PI*x(0))*sin(M_PI*x(1));
  const double Gyuy_analytial = -M_PI*cos(M_PI*x(0))*cos(M_PI*x(1));
  const double error = jac *((ux_numeric-ux_analytial)*(ux_numeric-ux_analytial)+(uy_numeric-uy_analytial)*(uy_numeric-uy_analytial));
  double Gerror = jac *((Gxux_numeric-Gxux_analytial)*(Gxux_numeric-Gxux_analytial)+(Gxuy_numeric-Gxuy_analytial)*(Gxuy_numeric-Gxuy_analytial));
  Gerror += jac *((Gyux_numeric-Gyux_analytial)*(Gyux_numeric-Gyux_analytial)+(Gyuy_numeric-Gyuy_analytial)*(Gyuy_numeric-Gyuy_analytial));
  fillStr.addToGlobalIntegral("error", error);
  fillStr.addToGlobalIntegral("Gerror", Gerror);
  addCoarseDiff(fillStr, x.data(), 1, ux_numeric, uy_numeric, Gxux_numeric, Gyux_numeric, Gxuy_numeric, Gyuy_numeric, jac);
}

// Check Interface solution
// Per-integration-point dump of the interface tractions, opened in main
// around checkSolution->FillLinearSystem() (serial only).
static std::ofstream* gBorderCSV = nullptr;

void CheckNitsche(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using namespace ttl;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i, ttl::index::j;

  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);
  auto rngR1 = range(2,3);

  double mu0 = fillStr.getRealParameter(StokesParams::mu0);
  double mu1 = fillStr.getRealParameter(StokesParams::mu1);
  int nS = fillStr.getIntParameter(StokesParams::timeStep);

  //============      Initialize variables       ===========//

  // Background
  SubFillStructure &subFill = fillStr[0];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  std::vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  wrapper<double, 2> nborCoords(subFill.nborCoords.data(), eNN, 3);

  ttl::wrapper<double, 1> bft(subFill.nborBFs(), eNN);

  tensor<double, 1> x = bft* nborCoords(all,rngCoords);

  // ===================== Values at int. points ==================== //
  // Compute jacobian
  tensor<double,2> dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf, jac, subFill);

  // Get tangent to immersed mesh at integration point
  auto immMesh = subFill.dhandDHand->mesh->_childMesh;
  std::vector<double> t(3);
  for (int ii = 0; ii < 3; ii++)
    t[ii] = immMesh->_immTangents[subFill.loc_elemID][3*subFill.kPt+ii];
  jac = Math::Norm3D(t.data());

  // Compute unitary normal
  tensor<double,1> n(2);
  n(0) = -t[1]/jac;
  n(1) = -(-t[0])/jac;

  ttl::wrapper<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN,DOF);
  const double ux0 = nborDOFs(N,0) * bft(N);
  const double uy0 = nborDOFs(N,1) * bft(N);

  const double ux1 = nborDOFs(N,2) * bft(N);
  const double uy1 = nborDOFs(N,3) * bft(N);

  tensor<double,2> nborLocCoords = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
  tensor<double,1> eC = bft*nborLocCoords;
  tensor<double,1> bf0 = {1.,0.5*(eC(0)+1.),0.5*(eC(1)+1.)};

  ttl::tensor<double,2> Id2 = Identity2;

  tensor<double,1> pf0 = {nborDOFs(0,4),nborDOFs(1,4),nborDOFs(3,4)};
  double p0 = pf0*bf0;
  tensor<double,1> pf1 = {nborDOFs(0,5),nborDOFs(1,5),nborDOFs(3,5)};
  double p1 = pf1*bf0;
  // cout << jac*((du(range(0,1),0)*n-du(range(2,3),0)*n)+(du(range(0,1),1)*n-du(range(2,3),1)*n)) << endl;
  tensor<double,2> Gu0 = product(nborDOFs(all,rngR0),dbf, {{0,0}}); // Gradient of velocities Gud(i,J) = dv_i/dX_J
  tensor<double,2> Gu1 = product(nborDOFs(all,rngR1),dbf, {{0,0}}); // Gradient of velocities Gud(i,J) = dv_i/dX_J

  double gmm0 = subFill.dhandDHand->elemAuxF->getValue("gmm0",subFill.elemID,IndexType::Local);
  double gmm1 = 1. - gmm0;
  if (fillStr.getRealParameter(StokesParams::beta)>0)
  {
    // Viscosity-weighted average, as in LSBorder
    gmm0 = mu1/(mu0+mu1);
    gmm1 = mu0/(mu0+mu1);
  }

  tensor<double,2> d0 = 0.5*(Gu0+Gu0.T());
  tensor<double,2> s0 = 2.*mu0*d0-p0*Id2;

  tensor<double,2> d1 = 0.5*(Gu1+Gu1.T());
  tensor<double,2> s1 = 2.*mu1*d1-p1*Id2;
  tensor<double,2> gs = gmm0*s0+gmm1*s1;

  const double a_ux = sin(M_PI*x(0))*cos(M_PI*x(1));
  const double a_Gxux = M_PI*cos(M_PI*x(0))*cos(M_PI*x(1));
  const double a_Gyux = -M_PI*sin(M_PI*x(0))*sin(M_PI*x(1));
  const double a_uy = -cos(M_PI*x(0))*sin(M_PI*x(1));
  const double a_Gxuy = M_PI*sin(M_PI*x(0))*sin(M_PI*x(1));
  const double a_Gyuy = -M_PI*cos(M_PI*x(0))*cos(M_PI*x(1));

  
  double a_p = sin(M_PI*x(0))*sin(M_PI*x(1));
  tensor<double,2> a_Gu = {{a_Gxux,a_Gxuy},{a_Gyux,a_Gyuy}};
  tensor<double,2> a_d = 0.5*(a_Gu+a_Gu.T());
  tensor<double,2> a_s = 2*mu0*0.5*(a_Gu+a_Gu.T())-a_p*Id2;
  tensor<double,1> t0 = s0*n;
  tensor<double,1> tmu0 = 2.*mu0*d0*n;
  tensor<double,1> tp0 = -p0*Id2*n;
  tensor<double,1> t1 = s1*n;
  // Save local length
  fillStr.addToGlobalIntegral("uErr", jac*((ux0-ux1)*(ux0-ux1)+(uy0-uy1)*(uy0-uy1)));
  // fillStr.addToGlobalIntegral("pErr", jac *(p0-p1)*(p0-p1))
  fillStr.addToGlobalIntegral("duErr", jac*((s0*n-s1*n)*(s0*n-s1*n)));
  fillStr.addToGlobalIntegral("tErr", jac*(gs*n-a_s*n)*(gs*n-a_s*n));

  // Averaged traction against the previous level, at the same point and normal
  if (g_coarse.valid)
  {
    double uc[2][2], Gc[2][2][2], pc[2];
    int elc[2];
    bool ok = evalCoarse(x.data(), 0, uc[0], Gc[0], pc[0], elc[0]) && evalCoarse(x.data(), 1, uc[1], Gc[1], pc[1], elc[1]);
    if (ok)
    {
      double g0c = g_coarse.dh->elemAuxF->getValue("gmm0", elc[0], IndexType::Global);
      if (fillStr.getRealParameter(StokesParams::beta) > 0)
        g0c = mu1/(mu0+mu1);
      double gc[2] = {g0c, 1.-g0c};
      double vmu[2] = {mu0, mu1};
      double dt[2] = {0., 0.};
      for (int i = 0; i < 2; i++)
      {
        for (int r = 0; r < 2; r++)
          for (int J = 0; J < 2; J++)
          {
            double sc = vmu[r]*(Gc[r][i][J]+Gc[r][J][i]) - (i == J ? pc[r] : 0.);
            dt[i] -= gc[r]*sc*n(J);
          }
        for (int J = 0; J < 2; J++)
          dt[i] += gs(i,J)*n(J);
      }
      fillStr.addToGlobalIntegral("dtErr", jac*(dt[0]*dt[0]+dt[1]*dt[1]));
    }
    else
      fillStr.addToGlobalIntegral("dMiss", jac);
  }
  // fillStr.addToGlobalIntegral("tErr", jac);

  // Output integration points (stream opened in main around checkSolution->FillLinearSystem())
  if (gBorderCSV)
  {
    // Same measure addToGlobalIntegral uses: sqrt(sum dGamma*|.|^2) reproduces the global errors
    double dGamma = subFill._jacobianParentElementToParameterSpace(subFill.loc_elemID)
                    * subFill.wk_sample * jac;
    tensor<double,1> ta = gs*n;     // averaged (Nitsche) traction
    tensor<double,1> te = a_s*n;    // exact traction
    (*gBorderCSV) << x(0) << "," << x(1) << "," << n(0) << "," << n(1) << ","
                  << t0(0) << "," << t0(1) << "," << t1(0) << "," << t1(1) << ","
                  << tmu0(0) << "," << tmu0(1) << "," << tp0(0) << "," << tp0(1) << ","
                  << subFill.elemID << "," << subFill.loc_elemID << "," << subFill.kPt << "," << dGamma << ","
                  << t0(0)-t1(0) << "," << t0(1)-t1(1) << ","
                  << ta(0) << "," << ta(1) << "," << te(0) << "," << te(1) << ","
                  << ta(0)-te(0) << "," << ta(1)-te(1) << ","
                  << ux0-ux1 << "," << uy0-uy1 << "," << p0 << "," << p1 << "\n";
  }
  return;
}

void LSPre(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace hiperlife::Tensor;

  SubFillStructure& subFill = fillStr[0];

  int numDOFs  = subFill.numDOFs;   // Number of degrees of freedom
  int numAuxF  = subFill.numAuxF;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  ttl::wrapper<double,2> nborAuxF(subFill.nborAuxF.data(), eNN, numAuxF);

  std::vector<double> b0 = {-1};
  std::vector<std::vector<double>>& pbf0 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b0, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

  std::vector<double> bf1 ={pbf0[0][0],pbf0[0][1],pbf0[0][2],pbf0[0][3]}; 
  std::vector<double> b1 = {1};
  std::vector<std::vector<double>>& pbf1 = subFill.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(b1, subFill.dhandDHand->mesh->_basisFunctions->getTag(subFill.elemID, IndexType::Local));

  std::vector<double> bf2 ={pbf1[0][0],pbf1[0][1],pbf1[0][2],pbf1[0][3]}; 

  // Get output
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,numDOFs);
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
  Bk(1,0) = nborAuxF(1,0);
  Bk(1,1) = nborAuxF(1,1);
  Bk(2,0) = nborAuxF(2,0);
  Bk(2,1) = nborAuxF(2,1);
  for (int a = 0; a<eNN; a++)
  {
    Ak(a,0,1,0) = bf1[a];
    Ak(a,1,1,1) = bf1[a];

    Ak(a,0,2,0) = bf2[a];
    Ak(a,1,2,1) = bf2[a];
  }
}


void genCircBspline(double r, std::vector<double> &U,std::vector<std::vector<std::vector<std::vector<double>>>> &CP, double xOff, double yOff, ElemType eTypeB,BasisFuncType bTypeB,int bfOrderB,int nPtsCircOr,SmartPtr<ParamStructure> paramStr)
{
  // Compute immersed mesh CPs position
  SmartPtr<StructMeshGenerator> preBSMesh = Create<StructMeshGenerator>();

  preBSMesh->setMesh(eTypeB, bTypeB, bfOrderB);
  
  std::vector<double> preU(nPtsCircOr+1,0);
  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
  preU[i] = preU[i-1]+1;
  }
  
  std::vector<std::vector<std::vector<std::vector<double>>>> preCP(nPtsCircOr, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
  for (int k = 0;  k < nPtsCircOr; k++)
  {
  double t = 2*M_PI*k/nPtsCircOr;
  preCP[k][0][0] = {std::cos(t),std::sin(t),0,0};
  }
  
  preBSMesh->genBsplinesClosedCurve(preU,preCP);
  // Distributed mesh
  SmartPtr<DistributedMesh> preDisBSMesh = Create<DistributedMesh>("preDisBSMesh");
  preDisBSMesh->setMesh(preBSMesh);
  preDisBSMesh->setBalanceMesh(true);
  preDisBSMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
  preDisBSMesh->setVerbosity(Verbosity::None);
  preDisBSMesh->Update();
  
  // Set Degree of Freedom handler
  SmartPtr<DOFsHandler> preDhand = Create<DOFsHandler>(preDisBSMesh);
  preDhand->setNameTag("preDhand");
  preDhand->setNumDOFs(2);
  preDhand->setDOFs({"pcx","pcy"});
  preDhand->setNodeAuxF({"x","y","dxdt","dydt"});
  preDhand->Update();


  std::vector<double> cw = {1};
  for (int i = 0; i<preDisBSMesh->nPts();i++)
  {
  double t = 2.*M_PI*double(i)/double(nPtsCircOr);
  double x = xOff;
  double y = yOff;
  for (int iw = 0; iw<cw.size(); iw++)
  {
    x += cw[iw]*cos((iw+1)*t)*r;
    y += cw[iw]*sin((iw+1)*t)*r;
  }
  preDhand->nodeAuxF->setValue(0,i,IndexType::Global,x);
  preDhand->nodeAuxF->setValue(1,i,IndexType::Global,y);
  }

  SmartPtr<HiPerProblem> preHiperProbl = Create<HiPerProblem>();
  preHiperProbl->setParameterStructure(paramStr);
  preHiperProbl->setDOFsHandlers({preDhand});
  
  // Interface integration
  preHiperProbl->setIntegration("IntegPre", {"preDhand"});
  preHiperProbl->setCubatureGauss("IntegPre", 1);
  preHiperProbl->setElementFillings("IntegPre", LSPre);

  preHiperProbl->Update();

  SmartPtr<MUMPSDirectLinearSolver> preSolver = Create<MUMPSDirectLinearSolver>();
  preSolver->setHiPerProblem(preHiperProbl);
  preSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
  preSolver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
  preSolver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Sequential);
  preSolver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
  preSolver->setConvergenceCriteria(MUMPSDirectLinearSolver::ConvergenceCriteria::Relative);
  preSolver->setTolerance(1e-8);
  preSolver->setDefaultParameters();
  preSolver->Update();

  // Solve
  preSolver->solve();
  preHiperProbl->UpdateGhosts();

  // Update Solution
  preSolver->UpdateSolution();

  for (int i = 1; i<(nPtsCircOr+1);i++)
  {
  U[i] = U[i-1]+1.;
  }

  for (int k = 0;  k < nPtsCircOr; k++)
  {  
  double x = preDhand->nodeDOFs->getValue(0,k,IndexType::Global);
  double y = preDhand->nodeDOFs->getValue(1,k,IndexType::Global);
  CP[k][0][0] = {x,y,0,0};
  }
}

#include <Eigen/Eigenvalues>
#include <complex>
#include <limits>
#include <iostream>

// Largest lambda of A x = lambda B x (A: boundary traction term of K, B: patch
// bulk viscous stiffness), robust to the near-singular directions of B:
//  1. Jacobi scaling D = diag(B)^-1/2, so the null-space threshold below is
//     relative to each DOF's own bulk control (cut fraction / element size
//     no longer spread the spectrum of B over many orders of magnitude).
//  2. The rigid modes Rm (columns, unscaled) are projected out explicitly:
//     there both A and B vanish (0/0), which a threshold only catches by luck.
//  3. On the remaining space B is reduced to its eigenvalues > relTol*max and
//     the problem becomes the symmetric Lambda^-1/2 V^T A V Lambda^-1/2:
//     no Cholesky, deterministic, exact for the reduced problem.
// Returns 0 if B has no range left. nUncontrolled counts DOFs that A sees but
// B does not (no bulk control at all -- they are dropped, so the estimate is
// not a bound for them).
double nitscheEigenEstimate(const Eigen::MatrixXd& A, const Eigen::MatrixXd& B, const Eigen::MatrixXd& Rm,
                            int& nUncontrolled, double relTol = 1e-8)
{
  int n = B.rows();
  nUncontrolled = 0;
  if (n == 0)
    return 0.;

  double maxDiagB = B.diagonal().maxCoeff();
  double maxDiagA = A.diagonal().cwiseAbs().maxCoeff();
  if (!(maxDiagB > 0.))
    return 0.;

  Eigen::VectorXd d(n), dInv(n);
  for (int i = 0; i < n; i++)
  {
    if (B(i,i) > 1e-14*maxDiagB)
    {
      d(i) = 1./sqrt(B(i,i));
      dInv(i) = sqrt(B(i,i));
    }
    else
    {
      d(i) = 0.;
      dInv(i) = 0.;
      if (fabs(A(i,i)) > 1e-12*maxDiagA)
        nUncontrolled++;
    }
  }
  Eigen::MatrixXd As = d.asDiagonal()*A*d.asDiagonal();
  Eigen::MatrixXd Bs = d.asDiagonal()*B*d.asDiagonal();

  // Orthonormal complement of the (scaled) rigid modes
  Eigen::MatrixXd Rs = dInv.asDiagonal()*Rm;
  Eigen::ColPivHouseholderQR<Eigen::MatrixXd> qr(Rs);
  qr.setThreshold(1e-10);
  int r = qr.rank();
  Eigen::MatrixXd Q = qr.householderQ();
  Eigen::MatrixXd Cc = Q.rightCols(n - r);

  Eigen::MatrixXd Bc = Cc.transpose()*Bs*Cc;
  Eigen::MatrixXd Ac = Cc.transpose()*As*Cc;
  Bc = 0.5*(Bc + Bc.transpose());
  Ac = 0.5*(Ac + Ac.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> bes(Bc);
  const Eigen::VectorXd& bEv = bes.eigenvalues();
  double bMax = bEv.maxCoeff();
  if (!(bMax > 0.))
    return 0.;
  std::vector<int> keep;
  for (int i = 0; i < bEv.size(); i++)
    if (bEv(i) > relTol*bMax)
      keep.push_back(i);
  if (keep.empty())
    return 0.;

  Eigen::MatrixXd W(Bc.rows(), keep.size());
  for (size_t j = 0; j < keep.size(); j++)
    W.col(j) = bes.eigenvectors().col(keep[j])/sqrt(bEv(keep[j]));
  Eigen::MatrixXd S = W.transpose()*Ac*W;
  S = 0.5*(S + S.transpose());

  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> ses(S, Eigen::EigenvaluesOnly);
  return ses.eigenvalues().maxCoeff();
}

// Clamp of the eigen estimate around the geometric estimate
// C_geo = 2*mu_i*|Gamma_K|/|Omega_patch|: lambda in [g_nitscheGeoLo, g_nitscheGeoHi]*C_geo.
// The upper cap is wide and only meant to catch garbage (too small a penalty
// loses coercivity); the per-call summary prints the actual lambda/C_geo range.
static const double g_nitscheGeoLo = 0.1;
static const double g_nitscheGeoHi = 1e5;

void localNitscheEstimation(SmartPtr<HiPerProblem> immHP, SmartPtr<DOFsHandler> backDHand, SmartPtr<ParamStructure> paramStr, SmartPtr<DistributedMesh> immMesh)
{
  // Distributed mesh
  SmartPtr<DistributedMesh> backMesh = backDHand->mesh;

  // Get values from paraStructure
  double mu0 = paramStr->getRealParameter(StokesParams::mu0);
  double mu1 = paramStr->getRealParameter(StokesParams::mu1);
  vector<double> vmui = {mu0,mu1};

  // Velocity DOFs of each region (ux,uy); the pressure is not part of the estimate
  int numDOFs = 2;
  int pDim = 2;
  int eNN = 9;
  int nElem = backMesh->nElem();
  tensor<double,2> Id2 = ttl::Identity2;

  // Cubature info for the boundary integration
  std::vector<Teuchos::RCP<CubatureSet>> cubaSetsB = immHP->_integ[0]->_cubaSets;

  // Linear constraints
  std::vector<std::vector<linearConstraint>>& constrReg = backMesh->_cutBFConstrRegions;

  vector<int> rTags = {3,5};

  // Element nodes and node -> elements, from the connectivity (not _adjcyNE)
  std::vector<std::vector<int>> elNds(nElem);
  std::unordered_map<int, std::vector<int>> ndEls;
  for (int iE = 0; iE < nElem; iE++)
  {
    elNds[iE].resize(eNN);
    for (int n = 0; n < eNN; n++)
    {
      elNds[iE][n] = backMesh->_connec->getNbor(iE, n);
      ndEls[elNds[iE][n]].push_back(iE);
    }
  }

  // Patches: one per cut element K of the region, made of K plus the root
  // element(s) of K's slave nodes. The roots carry the bulk that controls
  // the DOFs K's slaves are extrapolated from. Roots are shared between
  // patches, so each element's bulk enters every patch it belongs to scaled
  // by 1/(number of such patches): the patch bulks then sum to the global one
  // and the patch constants combine into a global bound. K's boundary term
  // only enters K's own patch, so l0/l1 of K is just its patch's lambda.
  for (int rInt = 0; rInt < 2; rInt++)
  {
    double mui = vmui[rInt];

    // Agg field name tag (number of roots of each cut element, for inspection)
    std::string aggTag = "Agg"+to_string(rInt);
    backDHand->elemAuxF->setValue(aggTag,0);

    // Cubature info for the velocity integration in the current region
    std::vector<Teuchos::RCP<CubatureSet>> cubaSetsR = immHP->_integ[2*rInt+1]->_cubaSets;

    // Slave node -> its constraint in this region
    std::unordered_map<int, const linearConstraint*> slaveOf;
    for (const linearConstraint& lCnt : constrReg[rInt])
      slaveOf[lCnt.slave] = &lCnt;

    // Bad (aggregated) cut element: its centre node is a slave. Never a root.
    auto isBad = [&](int iE) { return slaveOf.count(elNds[iE][4]) > 0; };

    std::vector<int> cutEls;
    for (int iE = 0; iE < nElem; iE++)
    {
      int eTag = backDHand->elemAuxF->getValue(0,iE);
      if (eTag%2 == 0 && eTag%rTags[rInt] == 0)
        cutEls.push_back(iE);
    }

    // Roots of each slave node of a bad K: the non-bad elements containing
    // the most of its masters (all tied ones). Constraints with best count
    // <= 3 are plain hanging-node constraints and need no root. Well-cut K
    // has no aggregation slaves: patch {K}.
    int nWeakRoots = 0, nNoRoots = 0;
    std::vector<std::vector<int>> AP(cutEls.size());
    std::vector<int> mEl(nElem, 0);
    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      std::set<int> patch = {K};
      std::set<int> roots;
      for (int nd : (isBad(K) ? elNds[K] : std::vector<int>{}))
      {
        auto it = slaveOf.find(nd);
        if (it == slaveOf.end())
          continue;
        const linearConstraint& lCnt = *it->second;
        std::unordered_map<int,int> count;
        for (size_t m = 0; m < lCnt.masters.size(); m++)
          for (int e : ndEls[lCnt.masters[m]])
            if (!isBad(e))
              count[e]++;
        int best = 0;
        for (auto& c : count)
          best = max(best, c.second);
        if (best <= 3)
          continue;
        if (best < 6)
          nWeakRoots++;
        for (auto& c : count)
          if (c.second == best)
            roots.insert(c.first);
      }
      if (isBad(K) && roots.empty())
        nNoRoots++;
      patch.insert(roots.begin(), roots.end());

      // Free nodes of a bad K outside its roots are controlled through some
      // other good element of the region: add it, otherwise their only bulk
      // control in the patch is K's sliver
      if (isBad(K))
      {
        std::set<int> rootNds;
        for (int e : roots)
          rootNds.insert(elNds[e].begin(), elNds[e].end());
        for (int nd : elNds[K])
        {
          if (slaveOf.count(nd) || rootNds.count(nd))
            continue;
          for (int e : ndEls[nd])
          {
            int eTag = backDHand->elemAuxF->getValue(0,e);
            if (e != K && eTag%rTags[rInt] == 0 && !isBad(e))
              patch.insert(e);
          }
        }
      }
      backDHand->elemAuxF->setValue(aggTag,K,IndexType::Global,(double)roots.size());
      AP[k].assign(patch.begin(), patch.end());
      for (int e : AP[k])
        mEl[e]++;
    }

    // Summary counters
    int nAgg = 0, nLo = 0, nHi = 0, nFallback = 0, nUncTot = 0, maxNM = 0;
    double rMin = 1e300, rMax = 0.;

    for (size_t k = 0; k < cutEls.size(); k++)
    {
      int K = cutEls[k];
      const std::vector<int>& akp = AP[k];
      if (akp.size() > 1)
        nAgg++;

      // Patch DOF nodes (masters after the constraint mapping) and, per
      // element node, its (patch node, weight) list
      std::vector<int> igNds;
      std::unordered_map<int,int> igIdx;
      auto patchIdx = [&](int nd) {
        auto it = igIdx.find(nd);
        if (it != igIdx.end())
          return it->second;
        igIdx[nd] = igNds.size();
        igNds.push_back(nd);
        return (int)igNds.size()-1;
      };
      std::unordered_map<int, std::vector<std::vector<std::pair<int,double>>>> elMap;
      for (int iE : akp)
      {
        std::vector<std::vector<std::pair<int,double>>>& mp = elMap[iE];
        mp.resize(eNN);
        for (int il = 0; il < eNN; il++)
        {
          auto it = slaveOf.find(elNds[iE][il]);
          if (it == slaveOf.end())
            mp[il].push_back({patchIdx(elNds[iE][il]), 1.});
          else
          {
            // |w|: extrapolation weights are often negative (e.g. 6, -8, 3)
            const linearConstraint& lCnt = *it->second;
            for (size_t m = 0; m < lCnt.masters.size(); m++)
              if (fabs(lCnt.weights[m]) > 1e-13)
                mp[il].push_back({patchIdx(lCnt.masters[m]), lCnt.weights[m]});
          }
        }
      }
      int nM = igNds.size();
      maxNM = max(maxNM, nM);

      // M1: patch bulk, M2: K's boundary term; DOF (node A, comp i) -> A+nM*i
      Eigen::MatrixXd M1 = Eigen::MatrixXd::Zero(nM*numDOFs, nM*numDOFs);
      Eigen::MatrixXd M2 = Eigen::MatrixXd::Zero(nM*numDOFs, nM*numDOFs);
      auto scatter = [&](Eigen::MatrixXd& M, const std::vector<std::vector<std::pair<int,double>>>& mp,
                         tensor<double,4>& Ke, double s) {
        for (int a = 0; a < eNN; a++)
          for (auto& pa : mp[a])
            for (int b = 0; b < eNN; b++)
              for (auto& pb : mp[b])
              {
                double w = s*pa.second*pb.second;
                for (int i = 0; i < numDOFs; i++)
                  for (int j = 0; j < numDOFs; j++)
                    M(pa.first+nM*i, pb.first+nM*j) += w*Ke(a,i,b,j);
              }
      };

      double APatch = 0.; // bulk measure, scaled as M1
      double LPatch = 0.; // K's boundary measure

      for (int iE : akp)
      {
        double sE = 1./mEl[iE];

        // Compute bulk integration: 2 mu eps(v):eps(u)
        for (auto info: cubaSetsR[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,4> Aku1(eNN,numDOFs,eNN,numDOFs);
          for (int a = 0 ; a < eNN; a++)
            for (int i = 0 ; i < numDOFs; i++)
              for (int b = 0 ; b < eNN; b++)
                for (int j = 0 ; j < numDOFs; j++)
                  Aku1(a,i,b,j) = 0;

          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int i = 0 ; i < 2; i++)
              for (int j = 0 ; j < 2; j++)
                Jac(i,j) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();
            double jac = Jac.det();

            for (int a = 0 ; a < eNN; a++)
            {
              for (int b = 0 ; b < eNN; b++)
              {
                Aku1(a, 0, b, 0) += wS[gpi] * jac * mui * (2*Dbf_g(a,0)*Dbf_g(b,0) + Dbf_g(a,1)*Dbf_g(b,1));
                Aku1(a, 0, b, 1) += wS[gpi] * jac * mui * (Dbf_g(a,1)*Dbf_g(b,0));
                Aku1(a, 1, b, 0) += wS[gpi] * jac * mui * (Dbf_g(a,0)*Dbf_g(b,1));
                Aku1(a, 1, b, 1) += wS[gpi] * jac * mui * (2*Dbf_g(a,1)*Dbf_g(b,1) + Dbf_g(a,0)*Dbf_g(b,0));
              }
            }
            APatch += sE*wS[gpi]*jac;
          }
          scatter(M1, elMap[iE], Aku1, sE);
        }

        // Boundary term of K only: |2 mu eps(v) n|^2
        if (iE != K)
          continue;

        for (auto info: cubaSetsB[0]->cubaInfo(iE, IndexType::Local))
        {
          std::vector<double> xS = info.xSamples;
          std::vector<double> wS = info.wSamples;
          tensor<double,4> Bku1(eNN,numDOFs,eNN,numDOFs);
          for (int a = 0 ; a < eNN; a++)
            for (int i = 0 ; i < numDOFs; i++)
              for (int b = 0 ; b < eNN; b++)
                for (int j = 0 ; j < numDOFs; j++)
                  Bku1(a,i,b,j) = 0;

          for (int gpi{}; gpi < wS.size(); gpi++)
          {
            std::vector<double> xGpi = {xS[gpi*2],xS[gpi*2+1]};
            std::vector<std::vector<double>>& bf = backMesh->_basisFunctions->computeBasisFunctionsReference(xGpi, backMesh->_basisFunctions->getTag(iE, IndexType::Local));
            tensor<double,2> Jac(2,2);
            for (int i = 0 ; i < 2; i++)
              for (int j = 0 ; j < 2; j++)
                Jac(i,j) = 0;
            tensor<double,2> Dbf(eNN,pDim);
            for (int n = 0; n < eNN; n++)
            {
              int nbor = elNds[iE][n];
              for (int d0 = 0; d0 < 2; d0++)
              {
                Dbf(n,d0) = bf[1][2*n+d0];
                for (int d1 = 0; d1 < 2; d1++)
                  Jac(d0,d1) += backMesh->nodeCoord(nbor,d1)*bf[1][2*n+d0];
              }
            }
            tensor<double,2> Dbf_g = Dbf*Jac.inv();

            // Normal and jacobian
            int nDim = 3;
            std::vector<double> t(nDim);
            for (int n = 0; n < nDim; n++)
              t[n] = immMesh->_immTangents[iE][nDim*gpi+n];
            double jac = Math::Norm3D(t.data());

            // Compute unitary normal (sign irrelevant: the term is quadratic)
            tensor<double,1> n(2);
            n(0) = -t[1]/jac;
            n(1) = t[0]/jac;

            tensor<double,1> nDbf_g = Dbf_g*n;
            tensor<double,2> Dbf_gDbf_g = Dbf_g*Dbf_g.T();

            for (int a = 0 ; a < eNN; a++)
              for (int i = 0 ; i < numDOFs; i++)
                for (int b = 0 ; b < eNN; b++)
                  for (int j = 0 ; j < numDOFs; j++)
                    Bku1(a,i,b,j) += 2.*mui*mui*wS[gpi]*jac*0.5*(nDbf_g(a)*nDbf_g(b)*Id2(i,j)+nDbf_g(a)*Dbf_g(b,i)*n(j)+Dbf_g(a,j)*n(i)*nDbf_g(b)+Dbf_gDbf_g(a,b)*n(i)*n(j));
            LPatch += wS[gpi]*jac;
          }
          scatter(M2, elMap[iE], Bku1, 1.);
        }
      }

      // Rigid modes on the patch nodes (about their centroid)
      double xc = 0., yc = 0.;
      for (int nd : igNds)
      {
        xc += backMesh->nodeCoord(nd,0)/nM;
        yc += backMesh->nodeCoord(nd,1)/nM;
      }
      Eigen::MatrixXd Rm = Eigen::MatrixXd::Zero(nM*numDOFs, 3);
      for (int A = 0; A < nM; A++)
      {
        Rm(A,0) = 1.;
        Rm(A+nM,1) = 1.;
        Rm(A,2) = -(backMesh->nodeCoord(igNds[A],1) - yc);
        Rm(A+nM,2) = backMesh->nodeCoord(igNds[A],0) - xc;
      }

      int nUnc = 0;
      double lEig = nitscheEigenEstimate(M2, M1, Rm, nUnc);
      nUncTot += nUnc;

      if (LPatch > 0. && !(APatch > 0.))
        throw runtime_error("localNitscheEstimation: cut element " + to_string(K) + " has no bulk in region "
                            + to_string(rInt) + " (patch of " + to_string(akp.size()) + " elements)");
      double Cgeo = (APatch > 0.) ? 2.*mui*LPatch/APatch : 0.;

      double lmax = lEig;
      if (Cgeo > 0.)
      {
        if (!(lEig > 0.) || !std::isfinite(lEig))
        {
          lmax = Cgeo;
          nFallback++;
        }
        else
        {
          rMin = min(rMin, lEig/Cgeo);
          rMax = max(rMax, lEig/Cgeo);
          if (lEig < g_nitscheGeoLo*Cgeo)
          {
            lmax = g_nitscheGeoLo*Cgeo;
            nLo++;
          }
          else if (lEig > g_nitscheGeoHi*Cgeo)
          {
            lmax = g_nitscheGeoHi*Cgeo;
            nHi++;
          }
        }
      }
      else if (!(lEig > 0.) || !std::isfinite(lEig))
        nFallback++; // no boundary points in K: lmax unused by LSBorder

      backDHand->elemAuxF->setValue("l"+to_string(rInt),K,IndexType::Global,lmax);
    }

    cout << "Nitsche r" << rInt << ": " << cutEls.size() << " patches (" << nAgg << " with roots, max "
         << maxNM << " nodes), lambda/Cgeo in [" << (rMin < 1e300 ? rMin : 0.) << ", " << rMax << "], clamped lo "
         << nLo << " hi " << nHi << ", fallback " << nFallback << ", weak roots " << nWeakRoots
         << ", bad without root " << nNoRoots << ", uncontrolled DOFs " << nUncTot << endl;
  }
}


// *******************************************************************//
// *******************************************************************//
// *******************************************************************//
// *****                      MAIN FUNCTION                      *****//
// *******************************************************************//
// *******************************************************************//
// *******************************************************************//

int main(int argc, char** argv)
{

  hiperlife::Init(argc, argv);


  Params p;
  try
  {
    p = parseArgs(argc, argv);
  } catch (const std::exception& e)
  {
    std::cerr << "Error: " << e.what() << "\n";
    std::cerr << "Usage: " << argv[0]
           << " --rx <val> --ry <val> --mu0 <val> --mu1 <val> --wpTh <val> --beta <val>\n";
    return 1;
  }

  std::cout << "rx=" << p.rx << " ry=" << p.ry
      << " mu0=" << p.mu0 << " mu1=" << p.mu1
      << " wpTh=" << p.wpTh  << " beta=" << p.beta << " tauMode=" << p.tauMode << "\n";
  g_tauMode = (int)p.tauMode;
  //============================ Parameters ============================//
  int nx = 100;
  int ny = nx;
  vector<int> nxt = {8, 16, 32, 64, 128};
  nxt.resize(std::max(1, std::min((int)nxt.size(), (int)p.levels)));

  SmartPtr<ParamStructure> paramStr = CreateParamStructure<StokesParams>();
  // userStr->dparam.resize(1);

  paramStr->setRealParameter(StokesParams::mu0,p.mu0);
  paramStr->setRealParameter(StokesParams::mu1,p.mu1);
  paramStr->setRealParameter(StokesParams::rx,p.rx);
  paramStr->setRealParameter(StokesParams::ry,p.ry);
  paramStr->setRealParameter(StokesParams::wpTh,p.wpTh);
  paramStr->setRealParameter(StokesParams::beta0,p.beta);


  // *******************************************************************//
  // *****            MESH CREATION            *****//
  // *******************************************************************//
  int nSteps = nxt.size();
  int bfOrder = 2;
  int timeStep = 0;
  bool ghP = 0;
  double wellPosedTh = p.wpTh;

  std::vector<double> Merr; 
  std::vector<double> GMerr; 
  std::vector<double> Kerr; 
  std::vector<double> Terr; 
  std::vector<double> nTerr;
  // Differences to the previous level (no exact solution needed): ‖u_h − u_2h‖
  std::vector<double> dMerr, dGMerr, dTMerr, dMiss;

  double beta0 = p.beta;
  // if(ghP)
  // {
  //   wellPosedTh = 0.;
  // }
  for (int nS{}; nS < nSteps; nS++)
  {
    paramStr->setIntParameter(StokesParams::timeStep,nS);
    //-------------------------- Background mesh -------------------------//
    double beta = beta0*nxt[nS]; // beta = 100/h (from 2017Badia)
    paramStr->setRealParameter(StokesParams::beta,beta);

    // Mesh generator
    SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
    back->genStructMesh(nxt[nS], nxt[nS]);
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0001;    

    SmartPtr<StructMeshGenerator> imm = Create<StructMeshGenerator>();

    ElemType eTypeB = ElemType::Line; // Element type
    int bfOrderB = 3;   // Basis function order
    BasisFuncType bTypeB = BasisFuncType::BSplines; // Basis function type
    double r = 0.7/sqrt(5.); // Radius of immersed mesh
    int nPtsCirc = 5*nxt[nS]; // Number of control points
    std::vector<std::vector<std::vector<std::vector<double>>>> CP(nPtsCirc, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(1, std::vector<double>(4))));
    std::vector<double> U(nPtsCirc+1,0);

    imm->setMesh(eTypeB, bTypeB, bfOrderB);
    genCircBspline(r,U,CP,p.rx,p.ry,eTypeB,bTypeB,bfOrderB,nPtsCirc,paramStr);
    imm->genBsplinesClosedCurve(U,CP);

  
    SmartPtr<DistributedMesh> immProva = Create<DistributedMesh>("immMeshProva");
    immProva->setMesh(imm);
    immProva->setBalanceMesh(true);
    immProva->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immProva->setVerbosity(Verbosity::None);
    immProva->Update();
    // immProva->printFileLegacyVtk("meshProva");

    // Distributed mesh
    SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->Update();


    //--------------------------- Immersed mesh --------------------------//

    // Distributed mesh
    SmartPtr<DistributedMesh> immMesh = Create<DistributedMesh>("immMesh");
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setImmersedInteriorPoints({{{0.5, 0.5, 0.0}},{{0.01,0.01,0}}});
    immMesh->setRegionTags({"Interior","Exterior"});
    immMesh->setBalanceMesh(true);
    immMesh->setIllPosThreshold(wellPosedTh);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->Update();

    // // Print meshes
    // backMesh->printFileLegacyVtk("meshBack");
    // immMesh->printFileLegacyVtk("meshImm");


    // *******************************************************************//
    // *****           DOFsHandler CREATION          *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"ux0","uy0","ux1","uy1","p0","p1"});
    backDHand->setNodeAuxF({"const","ctag","stab","pp0","pp1"});
    backDHand->setElemAuxF({"tag","WI","Agg0","gmm0","l0","GhP0","Agg1","gmm1","l1","GhP1","lE","stbP"});
    backDHand->setDofTags({"Interior","Interior","Exterior","Exterior"});
    backDHand->Update();

    // Save interior/cut/exterior flags for plotting
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
      int elemFlag = backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local);
      backDHand->elemAuxF->setValue("tag", e, IndexType::Local, elemFlag);
      vector<int> nbors = backDHand->mesh->_getElementCornerNodes(e,IndexType::Global);
      vector<int> cFlags = backMesh->_immersedCornerFlags(e, IndexType::Local);
      for (size_t n = 0; n < nbors.size(); n++) //FIXME: Only for 1st or 2nd order
      {
        if (backDHand->mesh->isNodeInPart(nbors[n]))
          backDHand->nodeAuxF->setValue("ctag", nbors[n], IndexType::Global, cFlags[n]);
      }
    }
    backDHand->UpdateGhosts();
    
    //--------------------  Pressure constraints  --------------------//
    
    backDHand->setConstraint("p0", 0.0);
    backDHand->setConstraint("p1", 0.0);

    backDHand->nodeAuxF->setValue(0,-2);
    backDHand->elemAuxF->setValue(3,1);
    std::vector<int> eNNp = {0,1,3};

    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    { 
      std::vector<int> elCornerFlags = backDHand->mesh->_immersedCornerFlags(e,IndexType::Local);
      std::vector<int> elCorners = backDHand->mesh->_getElementCornerNodes(e,IndexType::Local);
      std::vector<int> nborNode = backMesh->elemNodeNbors(e,IndexType::Global);
      
      if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%3 == 0)
      {
        std::vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
        std::vector<int> eNNp = {0,1,3};
        for (int k{}; k < 3; k++)
          backDHand->removeConstraint(4,nborNode[eNNp[k]],IndexType::Local);
      } 
      if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%5 == 0)
      {
        std::vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
        std::vector<int> eNNp = {0,1,3};
        for (int k{}; k < 3; k++)
          backDHand->removeConstraint(5,nborNode[eNNp[k]],IndexType::Local);
      } 
    }

    // Update
    backDHand->UpdateGhosts();


    // Set boundary conditions
    backDHand->setBoundaryCondition("ux1", MAxis::Xmin, 0);
    backDHand->setBoundaryCondition("ux1", MAxis::Xmax, 0);
    backDHand->setBoundaryCondition("ux1", MAxis::Ymin, [](double x){return sin(M_PI*x);});
    backDHand->setBoundaryCondition("ux1", MAxis::Ymax, [](double x){return -sin(M_PI*x);});


    backDHand->setBoundaryCondition("uy1", MAxis::Xmin, [](double x){return -sin(M_PI*x);});
    backDHand->setBoundaryCondition("uy1", MAxis::Xmax, [](double x){return sin(M_PI*x);});
    backDHand->setBoundaryCondition("uy1", MAxis::Ymin, 0);
    backDHand->setBoundaryCondition("uy1", MAxis::Ymax, 0);
    backDHand->nodeDOFs->setValue("p1", 0,IndexType::Global, 0);
    backDHand->setConstraint("p1", 0,IndexType::Global, 0);

    // backDHand->printFileLegacyVtk("dofBack", true);


    // Compute facet pairs
    std::vector<std::pair<int,int>> borderFacetPairsR0 = findBorderAdjacentPairs(backDHand, bfOrder,0);
    std::vector<std::pair<int,int>> borderFacetPairsR1 = findBorderAdjacentPairs(backDHand, bfOrder,1);

    //------------------- Face stabilization flags -------------------//
    vector<int> rPrime = {3,5,7,11};
    backDHand->elemAuxF->setValue("stbP",1);
    for (int r = 0; r < 2; r++)
    {
      for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
      {
        if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local)%rPrime[r] == 0)
        {
          std::vector<int> nborNodes = backDHand->mesh->elemNodeNbors(e,IndexType::Local);
          int prova1 = backDHand->mesh->_adjcyNE->getNumNbors(nborNodes[1],IndexType::Local);
          std::vector<int> idF = {3,5,7,11};
          std::vector<int> ndF = {5,7};
          for (int i{}; i < 2; i++)
          {
            int Fstb = backDHand->elemAuxF->getValue("stbP",e,IndexType::Local);
            std::vector<int> nborElms = backDHand->mesh->_adjcyNE->getNborList(nborNodes[ndF[i]],IndexType::Local);
            int e1 = -1;
            for (int j{0}; j < nborElms.size(); j++)
            {
              if (nborElms[j] != e)
              {
                e1 = nborElms[j];
                break;
              }
            }
            if (e1 >= 0)
            {
              if (backDHand->mesh->_elemFlags->getValue(1, e1, IndexType::Local)%rPrime[r] == 0)
              {
                backDHand->elemAuxF->setValue("stbP",e,IndexType::Local,Fstb*idF[i+2*r]);
              }
            }
          }
        }  
      }
    }

    // *******************************************************************//
    // *****          IMMERSED PROBLEM           *****//
    // *******************************************************************//
    if (true)
    {
      // Immersed HiPerProblem
      SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
      //General setters
      immHP->setParameterStructure(paramStr);
      immHP->setGlobalIntegrals({"Area","Length","uError","duError","total_edge_length"});
      immHP->setDOFsHandlers({backDHand});

      // Set integration for the border
      immHP->setIntegration("IntegBorder", {"backDHand"});
      immHP->setCubatureBorderImmersed("IntegBorder", 10);
      immHP->setElementFillings("IntegBorder", LSBorder);

      // Set integration for Region 0
      immHP->setIntegration("IntegCavityV0", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV0", 9,5,"Interior");
      immHP->setElementFillings("IntegCavityV0", LSV0);

      immHP->setIntegration("IntegCavityP0", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityP0", 4,3,"Interior");
      immHP->setElementFillings("IntegCavityP0", LSP0);

      // Set integration for Region 1
      immHP->setIntegration("IntegCavityV1", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityV1", 9,5,"Exterior");
      immHP->setElementFillings("IntegCavityV1", LSV1);

      immHP->setIntegration("IntegCavityP1", {"backDHand"});
      immHP->setCubatureCutCellConforming("IntegCavityP1", 4,3,"Exterior");
      immHP->setElementFillings("IntegCavityP1", LSP1);

      // Element face Pressure continuity
      immHP->setIntegration("IntegFaces0", {"backDHand"});
      immHP->setCubatureGauss("IntegFaces0", 1);
      immHP->setElementFillings("IntegFaces0", LSF0);

      immHP->setIntegration("IntegFaces1", {"backDHand"});
      immHP->setCubatureGauss("IntegFaces1", 1);
      immHP->setElementFillings("IntegFaces1", LSF1);

      if (ghP)
      {
        // Face stabilization
        // Region 0
        immHP->setIntegration("IntegF0",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF0", /*iPts=*/5, borderFacetPairsR0);
        immHP->setElementFillings("IntegF0", FacetStbR0);

        // Region 1
        immHP->setIntegration("IntegF1",{"backDHand"});
        immHP->setCubatureInteriorFacet("IntegF1", /*iPts=*/5, borderFacetPairsR1);
        immHP->setElementFillings("IntegF1", FacetStbR1);
      }
      

      //------------------- Pressure imm constraints -------------------//

      std::vector<double> pR = {4,5};

      for (int r = 0; r < 2; r++)
      {
        std::vector<hiperlife::linearConstraint> pLCns;
        std::vector<int> touchFlags = backMesh->_createTouchFlags(r);
        unordered_map<int, std::vector<int>> aggEls = backMesh->_findClosestFAE(touchFlags);
        for (auto itr = aggEls.begin(); itr != aggEls.end(); ++itr)
        {
          // Compute the extrapolation weights
          std::vector<int> MEls = itr->second;
          int sEl = itr->first;
          std::vector<int> sNodes = backMesh->elemNodeNbors(sEl,IndexType::Global);
          double p0 = 0.;
          double p1 = 0.;
          double p2 = 0.;
          std::vector<double> xS0 = backMesh->nodeCoords(sNodes[0],IndexType::Local);
          std::vector<int> m0{}, m1{}, m2{};
          std::vector<double> w0{}, w1{}, w2{};
          int s0 = sNodes[0];
          int s1 = sNodes[1];
          int s2 = sNodes[3];
          int nMs = MEls.size();
          for(int mEl:MEls)
          {
            // Obtain master element corners
            std::vector<int> mNodes = backMesh->elemNodeNbors(mEl,IndexType::Global);
            std::vector<double> xM0 = backMesh->nodeCoords(mNodes[0],IndexType::Local);
            std::vector<double> xM1 = backMesh->nodeCoords(mNodes[8],IndexType::Local);

            // Compute slave p0 as a function of masters p1 and p2
            m1.push_back(mNodes[1]);
            w1.push_back(1./nMs);
            m2.push_back(mNodes[3]);
            w2.push_back(1./nMs);
            double ax = 2./(xM1[0]-xM0[0]);
            double ay = 2./(xM1[1]-xM0[1]);
            double bx = -1.-ax*xM0[0];
            double by = -1.-ay*xM0[1];
            double xs = ax*xS0[0]+bx;
            double ys = ay*xS0[1]+by;
            m0.push_back(mNodes[0]);
            w0.push_back(1./nMs);
            m0.push_back(mNodes[1]);
            w0.push_back(0.5*(xs+1.)/nMs);
            m0.push_back(mNodes[3]);
            w0.push_back(0.5*(ys+1.)/nMs);
          }

          linearConstraint lcAgg0, lcAgg1, lcAgg2;
          lcAgg0.slave = s0;
          lcAgg0.masters = m0;
          lcAgg0.weights = w0;
          pLCns.push_back(lcAgg0);

          lcAgg1.slave = s1;
          lcAgg1.masters = m1;
          lcAgg1.weights = w1;
          pLCns.push_back(lcAgg1);

          lcAgg2.slave = s2;
          lcAgg2.masters = m2;
          lcAgg2.weights = w2;
          pLCns.push_back(lcAgg2);
        }

        for (linearConstraint lC :pLCns)
        {
          int iSlv = lC.slave;
          std::vector<CompHiPerIndex> mstrsV;
          CompHiPerIndex slv = CompHiPerIndex(0, pR[r], iSlv, IndexType::Global); // Get slave hiperIndex
        
          for (int mstrIdx:lC.masters)
            mstrsV.push_back(CompHiPerIndex(0, pR[r], mstrIdx, IndexType::Global)); // Get mstr hiperIndex
          
          immHP->setLinearConstraint(slv,mstrsV,lC.weights); // Set constraint
        }
      }
      immHP->Update();


      //-------------------------- Immersed solver -------------------------//
      SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
      immSOL->setHiPerProblem(immHP);
      immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
      immSOL->setDefaultParameters();
      // immSOL->setWorkSpaceMemoryIncrease(200);
      immSOL->Update();
      //---------------------------- Solve immersed ------------------------//
      // Solve
      localNitscheEstimation(immHP, backDHand, paramStr, immMesh);

      // immHP->FillLinearSystem();
      immSOL->solve();
      immSOL->UpdateSolution();
      string meshName = to_string(nS);

      //------------------  Pressure postprocess  ------------------//

      ttl::tensor<double,2> nborCoordsEl = {{-1.,-1.},{0.,-1.},{1.,-1.},{-1.,0.},{0.,0.},{1.,0.},{-1.,1.},{0.,1.},{1.,1.}};
      std::vector<int> pPstR = {3,4};
      double diffP = 0.;

      for (int i{}; i < backMesh->nElem(); i++)
      {
        std::vector<int> nborNode = backMesh->elemNodeNbors(i,IndexType::Global);

        for(int r = 0; r < 2; r++)
        {
          // cout << "HII" << endl;
          if (backDHand->mesh->_elemFlags->getValue(1, i, IndexType::Local)%rPrime[r] == 0)
          {
            std::vector<int> nborCornersNode = backMesh->_getElementCornerNodes(i,IndexType::Global);
            double a = backDHand->nodeDOFs->getValue(pR[r],nborNode[0],IndexType::Global);
            double b = backDHand->nodeDOFs->getValue(pR[r],nborNode[1],IndexType::Global);
            double c = backDHand->nodeDOFs->getValue(pR[r],nborNode[3],IndexType::Global);
            for (int j{}; j < 9; j++)
            {
              ttl::tensor<double,1> bf1 = {1.,0.5*(nborCoordsEl(j,0)+1.),0.5*(nborCoordsEl(j,1)+1.)};
              ttl::tensor<double,1> x = nborCoordsEl(j,ttl::all);
              double pp = a+0.5*b*(x(0)+1.)+0.5*c*(x(1)+1.);
              // cout << p <<", "<< pPstR[r] << "," << nborNode[j]<<  endl;
              backDHand->nodeAuxF->setValue(pPstR[r],nborNode[j],IndexType::Global,pp);
            }
          }
        }
      }
            
      // Print
      string solName = "solBack."+buildFilename(p)+"."+to_string(nS);
      backDHand->printFileLegacyVtk(solName, true);
      string immMshName = "meshImm."+buildFilename(p)+"."+to_string(nS);
      immMesh->printFileLegacyVtk(immMshName);

      double L = immHP->globalIntegral("Length");
      double A = immHP->globalIntegral("Area");
      cout << "Area: " << A << " Lenght: " << L << endl;

      SmartPtr<HiPerProblem> checkSolution = Create<HiPerProblem>();
      checkSolution->setDOFsHandlers({backDHand});
      checkSolution->setParameterStructure(paramStr);

      // Set integration for the border
      checkSolution->setIntegration("IntegBorder", {"backDHand"});
      checkSolution->setCubatureBorderImmersed("IntegBorder", 10);
      checkSolution->setElementFillings("IntegBorder", CheckNitsche);

      // Set integration for the background mesh
      checkSolution->setIntegration("Integ0", {"backDHand"});
      checkSolution->setCubatureCutCellConforming("Integ0", 9, 5,"Interior");
      checkSolution->setElementFillings("Integ0", CheckSolution0);

      // Set integration for the background mesh
      checkSolution->setIntegration("Integ1", {"backDHand"});
      checkSolution->setCubatureCutCellConforming("Integ1", 9, 5,"Exterior");
      checkSolution->setElementFillings("Integ1", CheckSolution1);

      checkSolution->setGlobalIntegrals({"error","Gerror","uErr","duErr","tErr","dErr","dGerr","dtErr","dMiss"});
      checkSolution->Update();

      // Interface traction dump: one row per interface integration point
      std::ofstream borderCSV("Border"+buildFilename(p)+"."+to_string(nS)+".csv");
      borderCSV << std::setprecision(16)
                << "x(0),x(1),nx,ny,tx0,ty0,tx1,ty1,tmux0,tmuy0,tpx0,tpy0,"
                   "backElem,immElem,kPt,dGamma,jumpTx,jumpTy,tAvgx,tAvgy,tExx,tExy,"
                   "errTAvgx,errTAvgy,jumpUx,jumpUy,p0,p1\n";
      gBorderCSV = &borderCSV;
      checkSolution->FillLinearSystem();
      gBorderCSV = nullptr;
      borderCSV.close();
      double error = checkSolution->globalIntegral("error");
      std::cout << "error: " << sqrt(error) << std::endl;
      double Gerror = checkSolution->globalIntegral("Gerror");
      std::cout << "Gerror: " << sqrt(Gerror) << std::endl;
      double Uerror = checkSolution->globalIntegral("uErr");
      std::cout << "U border error: " << sqrt(Uerror) << std::endl;
      double dUerror = checkSolution->globalIntegral("duErr");
      std::cout << "dU*n border error: " << sqrt(dUerror) << std::endl;
      double tUerr = checkSolution->globalIntegral("tErr");
      std::cout << "dU*n border error: " << sqrt(tUerr) << std::endl;

      Merr.push_back(sqrt(error));
      GMerr.push_back(sqrt(Gerror));
      Kerr.push_back(sqrt(Uerror));
      Terr.push_back(sqrt(dUerror));
      nTerr.push_back(sqrt(tUerr));

      // Against the previous level (nan on the first one)
      double nan = std::numeric_limits<double>::quiet_NaN();
      dMerr.push_back(g_coarse.valid ? sqrt(checkSolution->globalIntegral("dErr")) : nan);
      dGMerr.push_back(g_coarse.valid ? sqrt(checkSolution->globalIntegral("dGerr")) : nan);
      dTMerr.push_back(g_coarse.valid ? sqrt(checkSolution->globalIntegral("dtErr")) : nan);
      dMiss.push_back(g_coarse.valid ? checkSolution->globalIntegral("dMiss") : nan);

      // This level is the coarse one for the next
      setCoarseLevel(backDHand, immMesh, nxt[nS]);
    }
  }
  g_coarse = CoarseLevel();
  // Column headers
  cout << left
     << setw(20) << "1/h"
     << setw(20)  << "M Err"
     << setw(20)  << "GM Err"
     << setw(20) << "K Err"
     << setw(20) << "T Err"
     << setw(20) << "TM Err"
     << setw(20) << "dM Err"
     << setw(20) << "dGM Err"
     << setw(20) << "dTM Err"
     << setw(20) << "dMiss"
     << endl;

  // Separator line
  cout << string(30, '-') << endl;

  // dX at row h: ‖u_h − u_2h‖ (difference to the previous, coarser level)
  for(int nS = 0; nS < nxt.size(); nS++)
  {
  cout << left << setw(20) <<  nxt[nS] <<  setw(20) <<  Merr[nS]  << setw(20)  << GMerr[nS]  << setw(20) << Kerr[nS] << setw(20) << Terr[nS] <<  setw(20) << nTerr[nS]
       << setw(20) << dMerr[nS] << setw(20) << dGMerr[nS] << setw(20) << dTMerr[nS] << setw(20) << dMiss[nS] << endl;
  }
  hiperlife::Finalize();
  return 0;
}