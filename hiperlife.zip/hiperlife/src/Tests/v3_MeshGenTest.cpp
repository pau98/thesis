#define SOLTOL 1e-8

#include <iostream>
#include <mpi.h>
#include <tuple>

#include <Teuchos_RCP.hpp>
#include <Amesos_BaseSolver.h>
#include <AztecOO.h>
#include <Amesos.h>

#include <Epetra_LinearProblem.h>
#include <Epetra_MultiVector.h>
#include "Teuchos_XMLParameterListHelpers.hpp"

#include <BelosConfigDefs.hpp>
#include <BelosLinearProblem.hpp>
#include <BelosEpetraAdapter.hpp>
#include <BelosBlockGmresSolMgr.hpp>
#include <Ifpack_Preconditioner.h>
#include <Ifpack.h>

#include <hl_StructMeshGenerator.h>
#include <hl_Array.h>
#include <hl_Geometry.h>
#include <hl_MeshMap.h>
#include <hl_MeshMap_Trivial.h>
#include <hl_MeshMap_Boundary.h>
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_Timer.h"

#ifdef EXTRAE_PROFILING
    #include "extrae_user_events.h"
#endif

typedef double                            ST;
typedef Teuchos::ScalarTraits<ST>        SCT;
typedef SCT::magnitudeType                MT;
typedef Epetra_MultiVector                MV;
typedef Epetra_Operator                   OP;
typedef Belos::MultiVecTraits<ST,MV>     MVT;
typedef Belos::OperatorTraits<ST,MV,OP>  OPT;


using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


std::tuple<int, double, int> solve_belos(Teuchos::RCP<Epetra_LinearProblem> linProb);
std::tuple<int, double, int> solve_amesos(Teuchos::RCP<Epetra_LinearProblem> linProb);

void problem_Stokes(RCP<hiperlife::DistributedMesh> disMeshV, RCP<hiperlife::DistributedMesh> disMeshP, RCP<hiperlife::UserStructure> userStr, bool pRef);
void LHS_Stokes(RCP<hiperlife::FillStructure> fillStr);
void RHS_Stokes(RCP<hiperlife::FillStructure> fillStr);
void RHS_Stokes_source(RCP<hiperlife::FillStructure> fillStr);

void LS(RCP<hiperlife::FillStructure> fillStr);
void LS_Tran(RCP<hiperlife::FillStructure> fillStr);

static std::array<double, 3> calcSourceFlat(std::array<double, 3> xk, double sL, double p0)
{
    double fxC = 0;
    double fyC = 0;

    double x = xk[0];
    double y = xk[1];
//    double z = kCoords[2];

    double r2 = x*x+y*y;
    double expon = exp(- r2*r2 / sL / sL);

    {
        double t1 = sL * sL;
        double t2 = 1.0 / t1;
        double t6 = x * x;
        double t7 = t1 * t1;
        double t8 = 1.0 / t7;
        double t10 = y * y;
        double t11 = t6 + t10;
        double t16 = t11 * t11;
        double t24 = t16 * t11 / t7 / t1;
        double t29 = t10 * y;
        fxC = 32.0 * t2 * y * expon - 96.0 * t6 * t8 * y * t11 * expon - 64.0 * t16 * t8 * y * expon + 64.0 * t24 * y * t6 * expon - 96.0 * t29 * t8 * t11 * expon + 64.0 * t24 * t29 * expon - 4.0 * p0 * y * t11 * t2 * x * expon;
    }

    {
        double t1 = sL * sL;
        double t2 = 1.0 / t1;
        double t6 = x * x;
        double t7 = t6 * x;
        double t8 = t1 * t1;
        double t9 = 1.0 / t8;
        double t11 = y * y;
        double t12 = t6 + t11;
        double t16 = t12 * t12;
        double t24 = t16 * t12 / t8 / t1;
        fyC = -32.0 * x * t2 * expon + 96.0 * t7 * t9 * t12 * expon + 64.0 * t16 * t9 * x * expon - 64.0 * t24 * t7 * expon + 96.0 * x * t9 * t11 * t12 * expon - 64.0 * t24 * t11 * x * expon + p0 * expon - 4.0 * p0 * t11 * t12 * t2 * expon;
    }

    return {fxC, fyC, 0.0};
}


int compCubaturePoints(hiperlife::ElemType elemType)
{
    using namespace hiperlife;

    if (elemType == ElemType::Triang)
        return 3;
    if (elemType == ElemType::Square)
        return 4;
    if (elemType == ElemType::Tetrah)
        return 4;
    if (elemType == ElemType::Parallelep)
        return 8;

    return -1;
}


int main(int argc, char **argv)
{

    #ifdef EXTRAE_PROFILING
        Extrae_shutdown();
    #endif

    //Initialize
    MPI_Init(nullptr, nullptr);
    int myRank;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    double PI = acos(-1.0);

    // Reading Terminal Parameters
    Teuchos::CommandLineProcessor parser;
    parser.setDocString(
            "This example program demonstrates how to use this Teuchos::CommandLineProcessor class\n"
                    "to get options from the command-line and print this help message automatically.\n"
    );
    double bal = 0.0;
    parser.setOption("bal", &bal, "bal");
    int nx = 20;
    parser.setOption("nx", &nx, "nx");
    Teuchos::CommandLineProcessor::EParseCommandLineReturn
            parseReturn= parser.parse( argc, argv );
    if (parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED)
        return 0;
    if (parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL)
        return 1; // Error!


    //Model parameters
    //Parameters
    string withSource = "true";
    string solver = "amesos";
    double mu = 1e-5;
    RCP<UserStructure> userStr_S = rcp(new UserStructure);
    userStr_S->dparam.resize(1);
    userStr_S->dparam[0] = mu;
    userStr_S->sparam.resize(2);
    userStr_S->sparam[0] = withSource;
    userStr_S->sparam[1] = solver;

    RCP<UserStructure> userStr = rcp(new UserStructure);
    double deltat = 0.003;
    double diffu  = 0.1;
    userStr->dparam.resize(50);
    userStr->dparam[0] = deltat;
    userStr->dparam[1] = diffu;


    //Options
    bool printVtk = false;


    //######################################################################//
    //                              MAIN MESH                               //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "MESH" << endl;

    //Parameters
    int nDim = 3;
    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Square;
    int bfOrder = 2;
    int gpNumber = 12;
    if (eType == ElemType::Line)
        gpNumber = bfOrder+1;
    if (eType == ElemType::Square)
        gpNumber = int(pow(bfOrder+1,2));
    if (eType == ElemType::Parallelep)
        gpNumber = int(pow(bfOrder+1,3));

    //Generate mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setNDim(nDim);
    structMesh->setElemType(eType);
    structMesh->setBasisFuncType(bfType);
    if (bfType != BasisFuncType::SubdivSurfs)
        structMesh->setBasisFuncOrder(bfOrder);
    structMesh->genStructMesh(4);
    // structMesh->genLine(10, {0, 0, 0}, {0, 0, 1});
    // structMesh->genAnnularSector(4, 4, 0.2, 1, PI/2);
    {
        // structMesh->scale(2.0);
        // structMesh->translate(-1.0);
        // structMesh->rotateZ(acos(-1)/8);
        // structMesh->stretchElemsAsymmetricX(4.0);
        // structMesh->shearX(2.0);

        // structMesh->scaleX(2);
        // structMesh->translateX(-2.0);
        // structMesh->rotateZ(PI/20);
        // structMesh->rotateX(PI/6, {0.5, 0.5, 0.5});

        // structMesh->genStructMeshFree([](double x){return 1 + x*x;});
        // structMesh->genStructMeshFree([](double x, double y){return std::make_tuple(x,x+y);});
        // structMesh->genStructMeshFree(5, 10, [](double x, double y){return std::make_tuple(x,x*x+y);});
        // structMesh->rotate2D(PI/3);
        // structMesh->genAnnularSector(0.2, 1, 3*PI/2);
        // structMesh->stretchElemsAsymmetric(2.0, 2.0);

        // structMesh->genAnnularSector(20, 20, 0.2, 1, PI/2);
    }

    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    try
    {
        disMesh->setMesh(structMesh);
        disMesh->setBalanceMesh(true);
        disMesh->Update();

        cout << "  " << myRank << ": Distributed Mesh successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": Distributed Mesh could not be created. " << err.what() << endl;
        MPI_Finalize();
        return 0;
    }

    //Print mesh
    disMesh->printFileLegacyVtk("Mesh");

    // MPI_Finalize();
    // return 0;


    //######################################################################//
    //                       GLOBAL CONSTRAINT MESH                         //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "GLOBAL CONSTRAINT MESH" << endl;

    //Create global constraint distributed mesh
    RCP<DistributedMesh> gDisMesh = rcp(new DistributedMesh);
    try
    {
        gDisMesh->setMeshRelation(MeshRelation::GlobConstr, disMesh);
        // gDisMesh->setMasterProcessor(1);
        gDisMesh->setBalanceMesh(true);

        gDisMesh->Update();
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": Distributed Mesh could not be created. " << err.what() << endl;
        MPI_Finalize();
        return 0;
    }

    MPI_Finalize();
    return 0;

    //######################################################################//
    //                           P-REFINED MESH                             //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "P-REFINED MESH" << endl << " ";

    //p-refined mesh
    RCP<DistributedMesh> pDisMesh = rcp(new DistributedMesh);
    try
    {
        pDisMesh->setMeshRelation(MeshRelation::pRefin, disMesh);
        pDisMesh->setPRefinement(1);
        pDisMesh->setBalanceMesh(false);
        pDisMesh->Update();
        cout << "  " << myRank << ": Distributed Mesh successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": Distributed Mesh could not be created. " << err.what() << endl;

        MPI_Finalize();
        return 0;
    }

    //Print mesh
    pDisMesh->printFileLegacyVtk("pMesh");

    //Solve Stokes
    problem_Stokes(disMesh, pDisMesh, userStr_S, true);

    // MPI_Finalize();
    // return 0;



    //######################################################################//
    //                           H-REFINED MESH                             //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "H-REFINED MESH" << endl << "  ";

    //Create h-refined mesh
    RCP<DistributedMesh> hDisMesh = rcp(new DistributedMesh);
    try
    {
        hDisMesh->setMeshRelation(MeshRelation::hRefin, disMesh);
        hDisMesh->setHRefinement(1);
        hDisMesh->setBalanceMesh(false);
        hDisMesh->Update();
        cout << "  " << myRank << ": Distributed Mesh successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": Distributed Mesh could not be created. " << err.what() << endl;
        MPI_Finalize();
        return 0;
    }

    //Print mesh
    hDisMesh->printFileLegacyVtk("hMesh");

    // Solve Stokes
    problem_Stokes(hDisMesh, disMesh, userStr_S, false);


    MPI_Finalize();
    return 0;


    //######################################################################//
    //                            BOUNDARY MESH                             //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "BOUNDARY MESH" << endl;

    //Distributed boundary mesh
    RCP<DistributedMesh> bDisMesh = rcp(new DistributedMesh);
    try
    {
        bDisMesh->setMeshRelation(MeshRelation::Boundary, disMesh);
        bDisMesh->setBoundaryMesh(MAxis::Xmin);
        //bDisMesh->setBoundaryMesh({MAxis::Xmin});
        bDisMesh->setBalanceMesh(true);
        bDisMesh->Update();
        cout << "  " << myRank << ": Distributed Mesh successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": Distributed Mesh could not be created. " << err.what() << endl;

        MPI_Finalize();
        return 0;
    }

    //Print mesh
    bDisMesh->printFileLegacyVtk("bMesh");

    MPI_Finalize();
    return 0;



    //######################################################################//
    //                      H-REFINED GENERATED MESH                        //
    //######################################################################//

    //Output info
    MPI_Barrier(MPI_COMM_WORLD);
    if (myRank == 0)
        cout << endl << "H-REFINED GENERATED MESH" << endl;

    //Generate mesh
    RCP<StructMeshGenerator> hStructMesh = rcp(new StructMeshGenerator);
    hStructMesh->setNDim(nDim);
    hStructMesh->setElemType(eType);
    hStructMesh->setBasisFuncType(bfType);
    hStructMesh->setBasisFuncOrder(bfOrder);
    hStructMesh->genStructMesh(20);

    //Create distributed mesh
    RCP<DistributedMesh> hgenDisMesh = rcp(new DistributedMesh);
    try
    {
        hgenDisMesh->setMesh(hStructMesh);
        hgenDisMesh->setBalanceMesh(false);
        hgenDisMesh->Update();

        cout << "  " << myRank << ": Distributed Mesh successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << myRank << ": Distributed Mesh could not be created. " << err.what() << endl;
        MPI_Finalize();
        return 0;
    }

    //Print mesh
    hgenDisMesh->printFileLegacyVtk("hgenMesh");




    //######################################################################//
    //######################################################################//
    //######################################################################//
    //######################################################################//
    //######################################################################//
    //######################################################################//
    //######################################################################//
    //######################################################################//
    //######################################################################//


    //DOFsHandler V
    RCP<DOFsHandler> dhandV = rcp(new DOFsHandler(disMesh));
    try
    {
        dhandV->setNameTag("dhandV");
        dhandV->setNumDOFs(1);

        dhandV->Update();

        cout << dhandV->myRank() << ":   DOFsHandler successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << dhandV->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;

        MPI_Abort(dhandV->comm(), 1);
    }

    //DOFsHandler G
    RCP<DOFsHandler> dhandG = rcp(new DOFsHandler(gDisMesh));
    try
    {
        dhandG->setNameTag("dhandG");
        dhandG->setNumDOFs(1);

        dhandG->Update();

        dhandG->nodeDOFs->setValue(1.0);

        cout << dhandV->myRank() << ":   DOFsHandler successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << dhandV->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;

        MPI_Abort(dhandV->comm(), 1);
    }


    //Set initial and boundary conditions (V)
    for(int i = 0; i < dhandV->mesh->loc_nPts(); i++)
    {
        double x = dhandV->mesh->nodeCoord(i, 0, IndexType::Local);
        double y = dhandV->mesh->nodeCoord(i, 1, IndexType::Local);
        int crease = dhandV->mesh->nodeCrease(i, IndexType::Local);
        if (crease > 0)
        {
            dhandV->setConstraint(0, i, IndexType::Local, 0.0);
            if (x > 0.9999)
                dhandV->setConstraint(0, i, IndexType::Local, 1.0);
            if ((y > 0.9999) || (y < 0.0001))
                dhandV->setConstraint(0, i, IndexType::Local, x);
        }
        else
        {
            dhandV->nodeDOFs->setValue(0, i, IndexType::Local, 0.9);
        }
    }

    /*******************************************************************************/
    /************************** With mass conservation *****************************/
    /*******************************************************************************/

    //Hiperdhandanics
    RCP<HiPerProblem> hiperMech = rcp(new HiPerProblem("HiperObject"));
    hiperMech->setUserStruct(userStr);
    hiperMech->setDOFsHandlers({dhandV, dhandG});

    //Integration
    hiperMech->setIntegration("IntegVG", {"dhandV", "dhandG"}, {IntegType::Master, IntegType::GlobConstr});
    hiperMech->setCubatureGauss("IntegVG", gpNumber);
    hiperMech->setIntegration_ElemFillings("IntegVG", LS);

    //Update
    hiperMech->Update();

    //Set solver
    AztecOO lin_solver(*hiperMech->linProbl);
    lin_solver.SetAztecOption(AZ_precond, AZ_dom_decomp);
    lin_solver.SetAztecOption(AZ_solver, AZ_gmres);
    if (printVtk)
        lin_solver.SetAztecOption(AZ_output, AZ_all);
    else
        lin_solver.SetAztecOption(AZ_output, AZ_none);

    //Print initial condition
    string fname = "HiperGlobal_V.";
    string solnameV = fname + "0";
    if (printVtk)
        dhandV->printFileLegacyVtk(solnameV);

    Timer timer({"MassConv", "TransientHeat"});


    //Time loop
    double time = 0.0;
    double totTime = 100;
    int timeStep = 0;
    while ( (time < totTime) && (timeStep<20) )
    {
        timer.start("MassConv");
        //Write
        if ((hiperMech->myRank() == 0) && (printVtk))
            cout << "    Time step " + to_string(timeStep) + " " << endl;
        else
            if (timeStep == 0)
                cout << "    Time step " + to_string(timeStep) + " ";
            else
                cout << to_string(timeStep) + " ";

        //Initial guess
        dhandV->nodeDOFs0->setValue(dhandV->nodeDOFs);
        dhandG->nodeDOFs0->setValue(dhandG->nodeDOFs);
        hiperMech->UpdateGhosts();

        //Assemble
        hiperMech->FillLinearSystem();

        //Solve
        int ierr = lin_solver.Iterate(5000, 1e-8);
        if (ierr != 0)
        {
            cout << hiperMech->myRank() << ":   Solver failed!! " <<  endl;
            MPI_Abort(hiperMech->comm(), 1);
            return 0;
        }

        //Update
        hiperMech->UpdateSolution();
        timeStep++;
        time += deltat;

        //Get and print solution
        string solnameV = fname + to_string(timeStep);
        if (printVtk)
            dhandV->printFileLegacyVtk(solnameV);
        timer.end("MassConv");

    }

    /*******************************************************************************/
    /************************ Without mass conservation ****************************/
    /*******************************************************************************/

    //Hiperdhandanics
    RCP<HiPerProblem> hiperMechT = rcp(new HiPerProblem("HiperObject"));
    hiperMechT->setUserStruct(userStr);
    hiperMechT->setDOFsHandlers({dhandV, dhandG});

    //Integration
    hiperMechT->setIntegration("IntegVG", {"dhandV", "dhandG"}, {IntegType::Master, IntegType::GlobConstr});
    hiperMechT->setCubatureGauss("IntegVG", gpNumber);
    hiperMechT->setIntegration_ElemFillings("IntegVG", LS_Tran);

    //Update
    hiperMechT->Update();

    //Set solver
    AztecOO lin_solver2(*hiperMechT->linProbl);
    lin_solver2.SetAztecOption(AZ_precond, AZ_dom_decomp);
    lin_solver2.SetAztecOption(AZ_solver, AZ_gmres);
    if (printVtk)
        lin_solver2.SetAztecOption(AZ_output, AZ_all);
    else
        lin_solver2.SetAztecOption(AZ_output, AZ_none);

    //Print initial condition
    fname = "HiperGlobal_NO.";
    solnameV = fname + "0";
    if (printVtk)
        dhandV->printFileLegacyVtk(solnameV);

    //Time loop
    time = 0.0;
    totTime = 100;
    timeStep = 0;
    while ( (time < totTime) && (timeStep<20) )
    {
        timer.start("TransientHeat");
        //Write
        if ((hiperMechT->myRank() == 0) && (printVtk))
            cout << "    Time step " + to_string(timeStep) + " " << endl;
        else
            if (timeStep == 0)
                cout << "    Time step " + to_string(timeStep) + " ";
            else
                cout << to_string(timeStep) + " ";
        //Initial guess
        dhandV->nodeDOFs0->setValue(dhandV->nodeDOFs);
        dhandG->nodeDOFs0->setValue(dhandG->nodeDOFs);
        hiperMechT->UpdateGhosts();

        //Assemble
        hiperMechT->FillLinearSystem();

        //Solve
        int ierr = lin_solver2.Iterate(5000, 1e-8);
        if (ierr != 0)
        {
            cout << hiperMechT->myRank() << ":   Solver failed!! " <<  endl;
            MPI_Abort(hiperMechT->comm(), 1);
            return 0;
        }

        //Update
        hiperMechT->UpdateSolution();
        timeStep++;
        time += deltat;

        //Get and print solution
        string solnameV = fname + to_string(timeStep);
        if (printVtk)
            dhandV->printFileLegacyVtk(solnameV);
        timer.end("TransientHeat");

    }

    //Print timing
    timer.printTiming(true);

    //Finalize
    MPI_Finalize();

    return 0;
}



void problem_Stokes(RCP<hiperlife::DistributedMesh> disMeshV, RCP<hiperlife::DistributedMesh> disMeshP, RCP<hiperlife::UserStructure> userStr, bool pRef)
{
    //Initialize
    int vDof = disMeshV->_pDim;
    ElemType eType = disMeshV->_connec->elemType();
    int bfOrder = disMeshV->_bfOrder;

    //Get user structure parameters
    string withSource = userStr->sparam[0];
    string solver = userStr->sparam[1];

    /// **************************************************************//
    /// *****              MECHANICS CREATION                    *****//
    /// **************************************************************//

    RCP<DOFsHandler> dhandV = rcp(new DOFsHandler(disMeshV));
    RCP<DOFsHandler> dhandP = rcp(new DOFsHandler(disMeshP));
    try
    {
        dhandV->setNameTag("dhandV"); // Set the tag that will be used later to identify this object
        dhandV->setNumDOFs(vDof);    // Set the number of degrees of freedom of this object
        //dhandV->setNumNodeAuxF(4);   // Set the number of auxiliary degrees of freedom of this object
        dhandV->Update();            // Create the object

        dhandP->setNameTag("dhandP");     // Set the tag that will be used later to identify this object
        dhandP->setNumDOFs(1);           // Set the number of degrees of freedom of this object
        dhandP->Update();                // Create the object

        cout << dhandV->myRank() << ":  DOFsHandler for Velocity and Pressure successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << dhandV->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;
        MPI_Abort(dhandV->comm(), 1);
    }

    /// Set velocity boundary conditions
    for (int i = 0; i < disMeshV->_pDim; i++)
        dhandV->setBoundaryCondition(i, 0.0);
    if (withSource == "false")
        dhandV->setBoundaryCondition(0, hiperlife::MAxis::Ymax, 1.0);

    /// Set pressure boundary conditions
    if (dhandP->myRank() == 0)
        dhandP->setConstraint(0, 0, hiperlife::IndexType::Global, 0.0);

    /// After changing node information, it is important to update the ghost nodes
    dhandV->UpdateGhosts();
    dhandP->UpdateGhosts();

    cout <<  dhandV->myRank() << ":  Boundary conditions set!!" << endl;

    /// **************************************************************//
    /// *****           HIPERMECHANICS CREATION                  *****//
    /// **************************************************************//

    // Declare HiPerProblem
    RCP<HiPerProblem> hiperMech = rcp(new HiPerProblem("HiperObject"));

    /// Add model parameters to userStr
    hiperMech->setUserStruct(userStr);

    /// Set dhandanics in HiPerMechanics
    hiperMech->setDOFsHandlers({dhandV, dhandP});

    /// Set integration in HiPerMechanics
    Teuchos::RCP<MeshMap> mapTriv = Teuchos::rcp(new MeshMap_Trivial());
    mapTriv->setLocNItem(dhandV->mesh->loc_nElem());
    mapTriv->Update();
    if (pRef == false)
        hiperMech->setIntegration("IntegStokes", {"dhandV", "dhandP"}, {IntegType::Master, IntegType::LagrMultip}, {mapTriv, disMeshV->_mapToParent});
    if (pRef == true)
        hiperMech->setIntegration("IntegStokes", {"dhandV", "dhandP"}, {IntegType::Master, IntegType::LagrMultip}, {mapTriv, mapTriv});
    if (withSource == "false")
        hiperMech->setIntegration_ElemFillings("IntegStokes", nullptr, RHS_Stokes, LHS_Stokes);
    else
        hiperMech->setIntegration_ElemFillings("IntegStokes", nullptr, RHS_Stokes_source, LHS_Stokes);
    int gpNumber{};
    if (eType == ElemType::Line)
        gpNumber = bfOrder+1;
    if (eType == ElemType::Triang)
        gpNumber = 4;
    if (eType == ElemType::Square)
        gpNumber = int(pow(bfOrder+1,2));
    if (eType == ElemType::Parallelep)
        gpNumber = int(pow(bfOrder+1,3));
    hiperMech->setCubatureGauss("IntegStokes",  gpNumber);

    /// Update HiPerMechanics
    hiperMech->Update();

    cout <<  dhandV->myRank() << ":  HiPerProblem successfully created!!" << endl;

    /// **************************************************************//
    /// *****                FILL LINEAR SYSTEM                  *****//
    /// **************************************************************//

    Timer timer({"Fill"});


    #ifdef EXTRAE_PROFILING
        Extrae_restart();
    #endif

    for (int h = 0; h < 10; h++)
    {
        timer.start("Fill");
        hiperMech->FillLinearSystem();
        if (dhandV->myRank() == 0)
            cout << " Fill Linear System " << h << " finished!!" << endl;
        timer.end("Fill");
    }


    //Print timing
    string prefix = to_string(hiperMech->numProcs())  + "  " + to_string(dhandV->mesh->nPts()) + "  " + to_string(dhandV->mesh->_imbalancedTol) + "  " + to_string(dhandV->mesh->nElem());
    timer.printTiming(true);
    timer.printTesting(prefix);


    // /// **************************************************************//
    // /// *****                    SOLVE                           *****//
    // /// **************************************************************//

    // /// Initialize LHS
    // hiperMech->linProbl->GetLHS()->PutScalar(0.0);

    // /// Solve
    // if (solver == "belos")
    // {
    //     auto res = solve_belos(hiperMech->linProbl);
    //     if (dhandV->myRank() == 0)
    //     {
    //         if (get<0>(res) == 0)
    //             cout << "Belos OK!!!     Residual:  " << get<1>(res) << "  - Iters: " << get<2>(res) << endl;
    //         else
    //             cout << "Belos Fail!!    Residual:  " << get<1>(res) << "  - Iters: " << get<2>(res) << endl;
    //     }
    // }
    // else if (solver == "amesos")
    // {
    //     auto res = solve_amesos(hiperMech->linProbl);
    //     if (dhandV->myRank() == 0)
    //     {
    //         if (get<0>(res) == 0)
    //             cout << "Amesos OK!!!     Residual:  " << get<1>(res) << "  - Iters: " << get<2>(res) << endl;
    //         else
    //             cout << "Amesos Fail!!    Residual:  " << get<1>(res) << "  - Iters: " << get<2>(res) << endl;
    //     }

    // }

    // /// Update solution
    // hiperMech->UpdateSolution();

    // /// Print solution
    // dhandV->printFileLegacyVtk("StokesSol_Veloc");
    // dhandP->printFileLegacyVtk("StokesSol_Pres");

}

void LHS_Stokes(RCP<FillStructure> fillStr)
{
    using std::vector;

    // Velocity variables
    hiperlife::SubFillStructure& v_subFill = (*fillStr)["dhandV"];
    int v_DOF = v_subFill.numDOFs;                       // degrees of freedom
    int v_eNN  = v_subFill.eNN;                          // number of nodes of the neighborhood
    int v_nDim = v_subFill.nDim;                         // dimension of the space of the problem
    int v_pDim = v_subFill.pDim;                         // dimension of the parametrized object
    double *v_xNbors = v_subFill.nborCoords.data();        // position of the nodes (global)
    double *v_uNodes  = v_subFill.nborDOFs.data();
    double *v_bf_k  = v_subFill.getDer(0);
    double *v_dbf_k = v_subFill.getDer(1);

    // Pressure variables
    hiperlife::SubFillStructure& p_subFill = (*fillStr)["dhandP"];
    int p_DOF = p_subFill.numDOFs;                       // degrees of freedom
    int p_eNN  = p_subFill.eNN;                          // number of nodes of the neighborhood
    double *p_xNbors = p_subFill.nborCoords.data();        // position of the nodes (global)
    double *p_uNodes = p_subFill.nborDOFs.data();
    double *p_bf_k  = p_subFill.getDer(0);
    double *p_dbf_k = p_subFill.getDer(1);

    //Model parameters
    Teuchos::RCP<hiperlife::UserStructure> userStr = fillStr->userStr;
    double mu = userStr->dparam[0];

    //Jacobian and global basis functions
    double jacTMap;
    vector<double> gradGl(v_eNN*v_pDim);
    hiperlife::SGeometry::globalBasisFunctionGradient(gradGl.data(), jacTMap, v_eNN, v_pDim, v_nDim, v_xNbors, v_dbf_k);
    vector<double> kCoords(3);
    Math::MatProduct(kCoords.data(), 1, v_eNN, v_nDim, v_bf_k, v_xNbors);

    // Velocity part of the stiffness matrix
    int vN = v_DOF*v_eNN;              // size of a row/column of the K_00
    for (int i = 0; i < v_eNN; i++)
    {
        double *gradgI = &gradGl[v_pDim*i];

        for ( int j = 0; j < v_eNN; j++ )
        {
            double *gradgJ = &gradGl[v_pDim*j];

            double diagTerm = 0.0;
            for (int vk = 0; vk < v_DOF; vk++)
                diagTerm += gradgI[vk] * gradgJ[vk];

            // Indices in the local SM
            int row = i * v_DOF;
            int col = j * v_DOF;

            //Shear viscosity
            for (int vi = 0; vi < v_DOF; vi++)
            {
                for (int vj = 0; vj < v_DOF; vj++)
                {
                    double Kmat_IJ = mu * (gradgI[vj] * gradgJ[vi]);

                    if (vi == vj)
                        Kmat_IJ += mu * diagTerm;

                    fillStr->Ak(0, 0)[(row + vi)*vN + col + vj] += jacTMap * Kmat_IJ;
                }
            }
        }
    }

    // Velocity-Pressure part of the stiffness matrix
    vector<double> K_IJ(v_DOF*p_DOF, 0.0);
    for (int i = 0; i < v_eNN; i++)
    {
        double *gradgI = &gradGl[v_pDim*i];

        for ( int j = 0; j < p_eNN; j++ )
        {
            for (int vi = 0; vi < v_DOF; vi++)
                K_IJ[vi] = jacTMap * p_bf_k[j] * gradgI[vi];

            //Fill
            for (int vi = 0; vi < v_DOF; vi++)
            {
                fillStr->Ak(0, 1)[(i * v_DOF + vi)*p_DOF*p_eNN + j * p_DOF]  += K_IJ[vi];
                fillStr->Ak(1, 0)[j*v_DOF*v_eNN + i * v_DOF + vi]  += K_IJ[vi];
            }

        }
    }

    //Print Gauss points
    if (false)
    {
        //Coordinates
        vector<double> v_kCoords(3);
        vector<double> p_kCoords(3);
        Math::MatProduct(v_kCoords.data(), 1, v_eNN, v_nDim, v_bf_k, v_xNbors);
        Math::MatProduct(p_kCoords.data(), 1, p_eNN, v_nDim, p_bf_k, p_xNbors);

        //File
        string path("");
        char* pPath;
        ofstream ofile("kPts.dat", ios::app);

        //Output
        if (v_subFill.kPt == 0)
            ofile << endl;
        ofile << setprecision(4) << std::scientific << std::showpos;
        ofile << v_subFill.elemID << " " << p_subFill.elemID << " ";
        ofile << v_subFill.kPt << " " << p_subFill.kPt  << " ";
        ofile << v_kCoords[0] << " " << v_kCoords[1] << "  ";// << kCoords[2] << " ";
        ofile << p_kCoords[0] << " " << p_kCoords[1] << " ";// << kCoords[2] << " ";
        ofile << v_bf_k[0] << " " << v_bf_k[1] << " " << v_bf_k[2] << "  -  ";
        ofile << p_bf_k[0] << " " << p_bf_k[1] << " " << p_bf_k[2];
        ofile << endl;
        ofile.close();

    }

}

void RHS_Stokes(RCP<FillStructure> fillStr)
{

}

void RHS_Stokes_source(RCP<FillStructure> fillStr)
{

    // Velocity variables
    SubFillStructure& v_subFill = (*fillStr)["dhandV"];
    int v_DOF = v_subFill.numDOFs;                       // degrees of freedom
    int v_eNN  = v_subFill.eNN;                          // number of nodes of the neighborhood
    int v_nDim = v_subFill.nDim;                         // dimension of the space of the problem
    int v_pDim = v_subFill.pDim;                         // dimension of the parametrizied object
    double *v_xNbors = v_subFill.nborCoords.data();        // position of the nodes (global)
    double *v_uNodes  = v_subFill.nborDOFs.data();
    double *v_bf_k  = v_subFill.getDer(0);
    double *v_dbf_k = v_subFill.getDer(1);

    // Pressure variables
    SubFillStructure& p_subFill = (*fillStr)["dhandP"];
    int p_DOF = p_subFill.numDOFs;                       // degrees of freedom
    int p_eNN  = p_subFill.eNN;                          // number of nodes of the neighborhood
    // int p_nDim = p_subFill.nDim;                         // dimension of the space of the problem
    // int p_pDim = p_subFill.pDim;                         // dimension of the parametrizied object
    double *p_xNbors = p_subFill.nborCoords.data();        // position of the nodes (global)
    double *p_uNodes = p_subFill.nborDOFs.data();
    double *p_bf_k  = p_subFill.getDer(0);
    double *p_dbf_k = p_subFill.getDer(1);


    //MAIN OUTPUT declaration
    std::vector<double>& v_rhs_k = fillStr->_B_k[0]; // <<=== MAIN OUTPUT

    array<double, 3> kCoords{};
    double f_k_f{};

    Math::MatProduct(kCoords.data(), 1, v_eNN, v_nDim, v_bf_k, v_xNbors);
    double TMap[4], iTMap[4];
    Array::Fill(TMap,4,0.0);
    for ( int i = 0; i < v_eNN; i++ )
    {
        TMap[0] += v_xNbors[v_nDim*i+0] * v_dbf_k[v_pDim*i+0];
        TMap[1] += v_xNbors[v_nDim*i+0] * v_dbf_k[v_pDim*i+1];
        TMap[2] += v_xNbors[v_nDim*i+1] * v_dbf_k[v_pDim*i+0];
        TMap[3] += v_xNbors[v_nDim*i+1] * v_dbf_k[v_pDim*i+1];
    }
    Math::Invert2x2(iTMap, TMap);
    double jacTMap = Math::DetMat2x2(TMap);

    double sL = 0.1;
    double p0 = 1.0;
    auto fC = calcSourceFlat(kCoords, sL, p0);

    for ( int i = 0; i < v_eNN; i++ )
    {
        v_rhs_k[v_DOF*i+0] = jacTMap * v_bf_k[i] * fC[0];
        v_rhs_k[v_DOF*i+1] = jacTMap * v_bf_k[i] * fC[1];
    }

}


void LS(RCP<FillStructure> fillStr)
{

    //Model parameters
    RCP<UserStructure> userStr = fillStr->userStr;
    double deltat = userStr->dparam[0];
    double diffu  = userStr->dparam[1];

    //Variables (V)
    SubFillStructure& v_subFill = (*fillStr)["dhandV"];
    int v_DOF  = v_subFill.numDOFs;
    int v_eNN  = v_subFill.eNN;
    int v_nDim = v_subFill.nDim;
    int v_pDim = v_subFill.pDim;
    vector<double>& v_xe_nodes  = v_subFill.nborCoords;
    vector<double>& v_ue_nodes0 = v_subFill.nborDOFs0;
    double *v_bf_k  = v_subFill.getDer(0);
    double *v_dbf_k = v_subFill.getDer(1);
    int v_N = v_DOF*v_eNN;
    double vn{};
    for (int i = 0; i < v_eNN; i++)
        vn += v_ue_nodes0[i] * v_bf_k[i];

    //Variables (G)
    SubFillStructure& g_subFill = (*fillStr)["dhandG"];
    int g_DOF  = g_subFill.numDOFs;
    int g_eNN  = g_subFill.eNN;
    int g_nDim = g_subFill.nDim;
    int g_pDim = g_subFill.pDim;
    vector<double>& g_xe_nodes  = g_subFill.nborCoords;
    double *g_bf_k  = g_subFill.getDer(0);
    double *g_dbf_k = g_subFill.getDer(1);
    int g_N = g_DOF*g_eNN;

    //Map, inverse and Jacobian
    double TMap[4], iTMap[4];
    Array::Fill(TMap,4,0.0);
    for (int i = 0; i < v_eNN; i++)
    {
        TMap[0] += v_xe_nodes[v_nDim*i+0] * v_dbf_k[v_pDim*i+0];
        TMap[1] += v_xe_nodes[v_nDim*i+0] * v_dbf_k[v_pDim*i+1];
        TMap[2] += v_xe_nodes[v_nDim*i+1] * v_dbf_k[v_pDim*i+0];
        TMap[3] += v_xe_nodes[v_nDim*i+1] * v_dbf_k[v_pDim*i+1];
    }
    Math::Invert2x2(iTMap, TMap);
    double jacTMap = Math::DetMat2x2(TMap);

    //Fill VV matrix
    for (int i = 0; i < v_eNN; i++)
    {
        double *gradlI = &v_dbf_k[v_pDim*i];
        double  gradgI[2];
        Math::MatProduct(gradgI,1,v_pDim,v_pDim,gradlI,iTMap);
        for (int j = 0; j < v_eNN; j++)
        {
            double *gradlJ = &v_dbf_k[v_pDim*j];
            double  gradgJ[2];
            Math::MatProduct(gradgJ,1,v_pDim,v_pDim,gradlJ,iTMap);

            //Fill
            fillStr->Ak(0, 0)[(i*v_DOF+0)*v_N+(j*v_DOF+0)] += jacTMap * v_bf_k[i] * v_bf_k[j] / deltat;
            fillStr->Ak(0, 0)[(i*v_DOF+0)*v_N+(j*v_DOF+0)] += jacTMap * diffu * (gradgI[0]*gradgJ[0]+gradgI[1]*gradgJ[1]);
        }
    }

    //Fill VG matrix
    for (int i = 0; i < v_eNN; i++)
    {
        for (int j = 0; j < g_eNN; j++)
        {
            //Fill
            fillStr->Ak(0, 1)[(i*v_DOF+0)*g_N+(j*g_DOF+0)] += jacTMap * v_bf_k[i];
        }
    }

    //Fill GV matrix
    for (int i = 0; i < g_eNN; i++)
    {
        for (int j = 0; j < v_eNN; j++)
        {
            //Fill
            fillStr->Ak(1, 0)[(i*g_DOF+0)*v_N+(j*v_DOF+0)] += jacTMap * v_bf_k[j];
        }
    }

    //Fill RHS V
    for (int i = 0; i < v_eNN; i++)
    {
        fillStr->_B_k[0][i*v_DOF] += jacTMap * v_bf_k[i] * vn / deltat;
    }

    //Fill RHS G
    int v_numElem = v_subFill.dhandDHand->mesh->nElem();
    for (int i = 0; i < g_eNN; i++)
    {
        fillStr->_B_k[1][i*g_DOF] += jacTMap *  0.807756;
    }


    return;

}

void LS_Tran(RCP<FillStructure> fillStr)
{

    //Model parameters
    RCP<UserStructure> userStr = fillStr->userStr;
    double deltat = userStr->dparam[0];
    double diffu  = userStr->dparam[1];

    //Variables (V)
    SubFillStructure& v_subFill = (*fillStr)["dhandV"];
    int v_DOF  = v_subFill.numDOFs;
    int v_eNN  = v_subFill.eNN;
    int v_nDim = v_subFill.nDim;
    int v_pDim = v_subFill.pDim;
    vector<double>& v_xe_nodes  = v_subFill.nborCoords;
    vector<double>& v_ue_nodes0 = v_subFill.nborDOFs0;
    double *v_bf_k  = v_subFill.getDer(0);
    double *v_dbf_k = v_subFill.getDer(1);
    int v_N = v_DOF*v_eNN;
    double vn{};
    for (int i = 0; i < v_eNN; i++)
        vn += v_ue_nodes0[i] * v_bf_k[i];

    //Variables (G)
    SubFillStructure& g_subFill = (*fillStr)["dhandG"];
    int g_DOF  = g_subFill.numDOFs;
    int g_eNN  = g_subFill.eNN;
    int g_nDim = g_subFill.nDim;
    int g_pDim = g_subFill.pDim;
    vector<double>& g_xe_nodes  = g_subFill.nborCoords;
    double *g_bf_k  = g_subFill.getDer(0);
    double *g_dbf_k = g_subFill.getDer(1);
    int g_N = g_DOF*g_eNN;

    //Map, inverse and Jacobian
    double TMap[4], iTMap[4];
    Array::Fill(TMap,4,0.0);
    for (int i = 0; i < v_eNN; i++)
    {
        TMap[0] += v_xe_nodes[v_nDim*i+0] * v_dbf_k[v_pDim*i+0];
        TMap[1] += v_xe_nodes[v_nDim*i+0] * v_dbf_k[v_pDim*i+1];
        TMap[2] += v_xe_nodes[v_nDim*i+1] * v_dbf_k[v_pDim*i+0];
        TMap[3] += v_xe_nodes[v_nDim*i+1] * v_dbf_k[v_pDim*i+1];
    }
    Math::Invert2x2(iTMap, TMap);
    double jacTMap = Math::DetMat2x2(TMap);

    //Fill VV matrix
    for (int i = 0; i < v_eNN; i++)
    {
        double *gradlI = &v_dbf_k[v_pDim*i];
        double  gradgI[2];
        Math::MatProduct(gradgI,1,v_pDim,v_pDim,gradlI,iTMap);
        for (int j = 0; j < v_eNN; j++)
        {
            double *gradlJ = &v_dbf_k[v_pDim*j];
            double  gradgJ[2];
            Math::MatProduct(gradgJ,1,v_pDim,v_pDim,gradlJ,iTMap);

            //Fill
            fillStr->Ak(0, 0)[(i*v_DOF+0)*v_N+(j*v_DOF+0)] += jacTMap * v_bf_k[i] * v_bf_k[j] / deltat;
            fillStr->Ak(0, 0)[(i*v_DOF+0)*v_N+(j*v_DOF+0)] += jacTMap * diffu * (gradgI[0]*gradgJ[0]+gradgI[1]*gradgJ[1]);
        }
    }

    //Fill GG matrix
    for (int i = 0; i < g_eNN; i++)
    {
        for (int j = 0; j < g_eNN; j++)
        {
            //Fill
            fillStr->Ak(1, 1)[(i*g_DOF+0)*g_N+(j*g_DOF+0)] = 1.0;
        }
    }

    //Fill RHS V
    for (int i = 0; i < v_eNN; i++)
    {
        fillStr->_B_k[0][i*v_DOF] += jacTMap * v_bf_k[i] * vn / deltat;
    }


    return;

}


RCP<Ifpack_Preconditioner> build_precAmesos(RCP<Epetra_RowMatrix> A)
{
    Teuchos::ParameterList ifpackList;
    // allocates an IFPACK factory. No data is associated
    // to this object (only method Create()).
    Ifpack Factory;
    // create the preconditioner. For valid PrecType values,
    // please check the documentation
    std::string PrecType = "Amesos"; // incomplete LU
    //    std::string PrecType = "ILU"; // incomplete LU
    int OverlapLevel = 1; // must be >= 0. If Comm.NumProc() == 1,
    // it is ignored.
    RCP<Ifpack_Preconditioner> Prec = Teuchos::rcp( Factory.Create(PrecType, &*A, OverlapLevel) );
    assert(Prec != Teuchos::null);
    // specify parameters for ILU
    ifpackList.set("fact: level-of-fill", 1);
    // the combine mode is on the following:
    // "Add", "Zero", "Insert", "InsertAdd", "Average", "AbsMax"
    // Their meaning is as defined in file Epetra_CombineMode.h
    ifpackList.set("schwarz: combine mode", "Add");
    // sets the parameters
    Prec->SetParameters(ifpackList);
    // initialize the preconditioner. At this point the matrix must
    // have been FillComplete()'d, but actual values are ignored.
    Prec->Initialize();
    // Builds the preconditioners, by looking for the values of
    // the matrix.
    Prec->Compute();
    // Create the Belos preconditioned operator from the Ifpack preconditioner.
    // NOTE:  This is necessary because Belos expects an operator to apply the
    //        preconditioner with Apply() NOT ApplyInverse().

    return Prec;
}

std::tuple<int, double, int> solve_belos(Teuchos::RCP<Epetra_LinearProblem> linProb)
{

    DistributedClass dis;
    bool proc_verbose = dis.myRank() == 0;
    if(proc_verbose) cout << "Solver Method Start" << endl;

    auto A = Teuchos::rcpFromRef(*linProb->GetMatrix());
    auto X = Teuchos::rcpFromRef(*linProb->GetLHS());
    auto B = Teuchos::rcpFromRef(*linProb->GetRHS());


    Teuchos::ParameterList belosList;
    belosList.set("Flexible Gmres", true);           // Flexible Gmres will be used to solve this problem
    belosList.set("Num Blocks", 1000);               // Maximum number of blocks in Krylov factorization
    belosList.set("Block Size", 1);                  // Blocksize to be used by iterative solver
    belosList.set("Maximum Iterations", 100000);     // Maximum number of iterations allowed
    // belosList.set("Maximum Restarts", 1);         // Maximum number of restarts allowed
    belosList.set("Convergence Tolerance", SOLTOL);  // Relative convergence tolerance requested


    belosList.set("Verbosity", Belos::Errors + Belos::Warnings +
                  Belos::TimingDetails + Belos::StatusTestDetails );
    belosList.set("Output Frequency", -1);
    // belosList.set( "Verbosity",  );
    // Extrae_eventandcounters(1000, 0);

    //
    // *******Construct a preconditioned linear problem********
    //
    if(proc_verbose) cout << "Precond Building" << endl;
    RCP<Belos::LinearProblem<double, MV, OP > > problem = rcp( new Belos::LinearProblem<double,MV, OP>(A, X, B));
    auto Prec = build_precAmesos(A);

    RCP<Belos::EpetraPrecOp> belosPrec = rcp(new Belos::EpetraPrecOp(Prec));
    problem->setRightPrec( belosPrec );

    //
    // *******Solve the problem********
    //
    if(proc_verbose) cout << "Solver Belos" << endl;
    bool set = problem->setProblem();
    if (set == false) {
        std::cout << std::endl << "ERROR:  Belos::LinearProblem failed to set up correctly!" << std::endl;
        return make_tuple(EXIT_FAILURE, 0.0, 0);
    }

    // Create an iterative solver manager.
    RCP< Belos::SolverManager<double,MV,OP> > solver
        = rcp( new Belos::BlockGmresSolMgr<double,MV,OP>(problem, rcp(&belosList,false)));

    //Solve
    Belos::ReturnType ret = solver->solve();

    //
    // *******Compute residuals********
    //

    //
    // Compute actual residuals.
    //
    if(proc_verbose) cout << "Check Residuals" << endl;
    bool badRes = false;
    int numrhs = 1;
    std::vector<double> actual_resids( numrhs );
    std::vector<double> rhs_norm( numrhs );
    Epetra_MultiVector resid(X->Map(), numrhs);
    OPT::Apply( *A, *X, resid );
    MVT::MvAddMv( -1.0, resid, 1.0, *X, resid );
    MVT::MvNorm( resid, actual_resids );
    MVT::MvNorm( *X, rhs_norm );
    if (proc_verbose)
    {
        std::cout<< "---------- Actual Residuals (normalized) ----------"<<std::endl<<std::endl;
        for ( int i=0; i<numrhs; i++) {
            double actRes = actual_resids[i]/rhs_norm[i];
            std::cout<<"Problem "<<i<<" : \t"<< actRes << "  "<<  solver->getNumIters()  <<  std::endl;
            if (actRes > SOLTOL) badRes = true;
        }
    }


    // Check Error
    Epetra_MultiVector result(B->Map(), 1);
    linProb->GetMatrix()->Multiply(false, *X, result);
    int maxSize = result.MyLength();
    double res = 0.0;
    for (int i = 0; i < maxSize; i++)
    {
        double e = abs((*B)[0][i] - result[0][i]);
        res += e;
    }

    return make_tuple(ret, res/maxSize, solver->getNumIters());
}

std::tuple<int, double, int> solve_amesos(Teuchos::RCP<Epetra_LinearProblem> linProb)
{

     Amesos_BaseSolver *Solver;
     Amesos AmesFact;

     //    Teuchos::ParameterList list;
     RCP <Teuchos::ParameterList> list = rcp(new Teuchos::ParameterList);
     list->set("OutputLevel", 2);
     list->set("ComputeTrueResidual", true);
     list->set("ComputeVectorNorms", true);

     Solver = AmesFact.Create("Amesos_Klu", *linProb);

     Solver->setParameterList(list);

     int err = Solver->Solve();


     Solver->PrintStatus();


     Epetra_MultiVector result(linProb->GetRHS()->Map(), 1);
     linProb->GetMatrix()->Multiply(false, *linProb->GetLHS(), result);
     int maxSize = result.MyLength();
     double res = 0.0;
     for (int i = 0; i < maxSize; i++)
     {
         double e = abs((*linProb->GetRHS())[0][i] - result[0][i]);
         res += e;
     }



     return make_tuple(err, res/maxSize, 1);

 }
