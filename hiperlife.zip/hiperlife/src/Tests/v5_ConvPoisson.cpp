/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"


// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct PoissonParams
{
  enum RealParameters
  {
    force,
    beta
  };

  enum IntParameters
  {
    timeStep,
    testN,
  };

  HL_PARAMETER_LIST DefaultValues
  {
    {"force", 0.0},
    {"beta", 100.0},
    {"timeStep",0}
  };
};

bool fileExists(const std::string& filename)
{
  struct stat buf;
  if (stat(filename.c_str(), &buf) != -1)
  {
    return true;
  }
  return false;
}

void LS_backBulk1(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;

  //============      Initialize variables       ===========//
  SubFillStructure& subFill = fillStr["backDHand"];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  tensor<double,2> Dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);
  int nS = fillStr.getIntParameter(PoissonParams::timeStep);
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  ///===================== Values at int. points ====================///
  vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf[i];
  }

  ofstream myfile;
  myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
  myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 0 << endl;
  myfile.close();


  ///=====================  Fill linear system =====================///
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
  Ak *=0;
  Bk *=0;
  double f = 2.*M_PI*M_PI*cos(M_PI*x[0])*sin(M_PI*x[1]);
  if(testN == 1)
    f = 0.;
  for (int i = 0; i < eNN; i++)
  {
    Bk(i,0) += jac * bf[i]* f;

    for (int j = 0; j < eNN; j++)
    {
      /// Fill matrix
      Ak(i,0,j,0) += jac * Dbf(i,ttl::all)*Dbf(j,ttl::all);
    }
  }

  // Save local area
  fillStr.addToGlobalIntegral("Area", jac);
  // Output integration points
  if (subFill.dhandDHand->nameTag() == "backDHand")
  {
    ofstream myfile;
    if (!fileExists("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv"))
    {
      myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
      myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
      myfile.close();
    }
    myfile.open("Cut."+to_string(fillStr.getIntParameter(PoissonParams::timeStep))+".csv", std::ios_base::app);
    myfile << std::setprecision(16) << x[0] << "," << x[1] << "," << jac << endl;
    myfile.close();
  }
  return;
}

void LS_backBorder(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;

  //============      Initialize variables       ===========//
  // Parameters
  double beta = fillStr.getRealParameter(PoissonParams::beta);
  int nS = fillStr.getIntParameter(PoissonParams::timeStep);
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  // Background
  SubFillStructure& subFill = fillStr["backDHand"];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives

  // ===================== Values at int. points ==================== //
  // Compute jacobian
  vector<double> dbf(eNN*pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

  // Compute unitary normal
  vector<double> n(3, 0.0);
  n[0] = 1.;
  n[1] = -0.;

  // Compute coordinates using the back mesh
  vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf[i];
  }


  // ofstream myfile;
  // myfile.open("cubatureImm2."+to_string(nS)+".csv", std::ios_base::app);
  // // myfile.open("cubature."+to_string(subFill.dhandDHand->myRank())+".csv", std::ios_base::app);
  // // myfile << std::setprecision(16) << x[0] << " " << x[1] << " " << 1 << endl;
  // myfile << std::setprecision(16) << std::setprecision(16) << x[0] << " " << x[1] << " " << " " << n[0] << " " << n[1] << " " << t[0] << " " << t[1] << endl;
  // myfile.close();

  // Obtain Nitsche parameter from each side
  beta = 10*subFill.dhandDHand->elemAuxF->getValue("l0",subFill.elemID);

  // =====================  Fill linear system ===================== //
  double gD = cos(M_PI*x[0])*sin(M_PI*x[1]);//(x[0]-0.5)*(x[0]-0.5)+(x[1]-0.5)*(x[1]-0.5);
  // cout << gD << " " << x[0] <<  " " << x[1] <<endl;
  tensor<double,2,false> Bk(fillStr.Bk(0).data(),eNN,DOF);
  tensor<double,4,false> Ak(fillStr.Ak(0,0).data(),eNN,DOF,eNN,DOF);
  Ak *= 0;
  Bk *= 0;
  jac = sqrt(jac);
  // Nitsche symmetric
  if (true)
  {
    for (int i = 0; i < eNN; i++)
    {
      double dbfnI{};
      for (int d = 0; d < pDim; d++)
        dbfnI += dbf[pDim*i+d]*n[d];
      
      Bk(i,0) += jac * beta * bf[i]* gD;
      Bk(i,0) -= jac * gD * dbfnI;


      for (int j = 0; j < eNN; j++)
      {
        double dbfnJ{};
        for (int d = 0; d < pDim; d++)
          dbfnJ += dbf[pDim*j+d]*n[d];

        // Fill matrix
        Ak(i,0,j,0) += jac * beta * bf[i] * bf[j];
        Ak(i,0,j,0) -= jac * bf[i] * dbfnJ;
        Ak(i,0,j,0) -= jac * dbfnI * bf[j];
      }
    }
  }
  // Save local length
  fillStr.addToGlobalIntegral("Length", jac);

  return;
}

void CheckSolution0(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  double a = 0.33;
  double b = -2.1;
  double c = 7.;
  const double u_numeric = dofsI(N,0) * bf(N);
  double u_analytial = cos(M_PI*x(0))*sin(M_PI*x(1));
  if(testN == 1)
    u_analytial = a*x(0)+b*x(1)+c;
  const double error = jac * (u_numeric-u_analytial) * (u_numeric-u_analytial);
  fillStr.addToGlobalIntegral("error", error);
}

void CheckNitsche(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;
  int testN = fillStr.getIntParameter(PoissonParams::testN);

  //============      Initialize variables       ===========//
  // Parameters
  double beta = fillStr.getRealParameter(PoissonParams::beta);

  // Background
  SubFillStructure &subFill = fillStr[0];
  int DOF  = subFill.numDOFs;   // Number of degrees of freedom
  int eNN  = subFill.eNN;     // Number of neighbor nodes
  int nDim = subFill.nDim;    // Number of spatial dimensions
  int pDim = subFill.pDim;    // Number of parametric dimension
  vector<double>& coords  = subFill.nborCoords;  // Vector of node coordinates
  double* bf  = subFill.nborBFsDers(0);   // Local shape function
  double* dbf_l = subFill.nborBFsDers(1); // Local shape function derivatives
  ttl::wrapper<double, 1> bft(subFill.nborBFs(), eNN);

  // ===================== Values at int. points ==================== //
  // Compute jacobian
  tensor<double,2> dbf(eNN,pDim);
  double jac;
  GlobalBasisFunctions::gradients(dbf, jac, subFill);

  // Compute unitary normal
  tensor<double,1> n(2);
  n(0) = 1.;
  n(1) = 0.;

  // Compute coordinates using the back mesh
  vector<double> x(nDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int d = 0; d < nDim; d++)
      x[d] += coords[nDim*i+d] * bf[i];
  }
  ttl::wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOF);
  const double u0 = dofsI(N,0) * bft(N);
  tensor<double,1> du0 = dofsI(N,0) * dbf(N,i);
  double uA = cos(M_PI*x[0])*sin(M_PI*x[1]);
  double duNA = -M_PI*sin(M_PI*x[0])*sin(M_PI*x[1])*n(0)+M_PI*cos(M_PI*x[0])*cos(M_PI*x[1])*n(1);
  // Save local length
  fillStr.addToGlobalIntegral("uErr", sqrt(jac)*(u0-uA)*(u0-uA));
  fillStr.addToGlobalIntegral("duErr", sqrt(jac)*(du0*n-duNA)*(du0*n-duNA));

  return;
}

int main(int argc, char** argv)
{

  hiperlife::Init(argc, argv);

  //============================ Parameters ============================//
  int nx = 100;
  int ny = nx;
  vector<int> nxt = {4, 8, 16, 32, 64};
  // cout << "Type number of elements per side: " << endl;
  // cin >> nx;
  SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();
  // userStr->dparam.resize(1);
  double beta = 100*nx; // beta = 100*h (from 2017Badia)
  paramStr->setRealParameter(PoissonParams::beta,beta);

  int testN = -1;
  std::cout << "Enter test number: ";

  while (!(std::cin >> testN)) {
    std::cin.clear();                // Clear the error flag
    std::cin.ignore(1000, '\n');     // Discard invalid input
    std::cout << "Invalid input. Please enter an integer: ";
  }

  paramStr->setIntParameter(PoissonParams::testN,testN);


  // *******************************************************************//
  // *****            MESH CREATION            *****//
  // *******************************************************************//
  int nSteps = 5;
  int bfOrder = 2;
  int timeStep = 0;
  bool ghP = 0;
  double wellPosedTh = 0.5;

  std::vector<double> Merr; 
  std::vector<double> Kerr; 
  std::vector<double> Terr; 
  if(ghP)
  {
    wellPosedTh = 0.;
  }
  for (int nS{}; nS < nSteps; nS++)
  {
    paramStr->setIntParameter(PoissonParams::timeStep,nS);
    //-------------------------- Background mesh -------------------------//
    double beta = 100*nxt[nS]; // beta = 100/h (from 2017Badia)
    paramStr->setRealParameter(PoissonParams::beta,beta);

    // Mesh generator
    SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
    back->genStructMesh(nxt[nS], nxt[nS]);
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0001;    

  
    // Distributed mesh
    SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->Update();


    // Print meshes
    backMesh->printFileLegacyVtk("meshBack");


    // *******************************************************************//
    // *****           DOFsHandler CREATION          *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"u"});
    backDHand->setNodeAuxF({"const","ctag","stab"});
    backDHand->setElemAuxF({"tag","WI","Agg0","k0","l0","GhP0"});
    backDHand->Update();

    backDHand->UpdateGhosts();
    double a = 0.33;
    double b = -2.1;
    double c = 7.;

    switch(testN)
    {
    case 1:
      // Set boundary conditions
      backDHand->setBoundaryCondition("u", MAxis::Xmin, [=](double x){return b*x+c;});
      backDHand->setBoundaryCondition("u", MAxis::Xmax, [=](double x){return a+b*x+c;});
      backDHand->setBoundaryCondition("u", MAxis::Ymin, [=](double x){return a*x+c;});
      backDHand->setBoundaryCondition("u", MAxis::Ymax, [=](double x){return a*x+b+c;});
      break;
    case 2:
      backDHand->setBoundaryCondition("u", MAxis::Xmin, [=](double x){return sin(M_PI*x)*cos(0.);});
      backDHand->setBoundaryCondition("u", MAxis::Xmax, [=](double x){return sin(M_PI*x)*cos(M_PI);});
      backDHand->setBoundaryCondition("u", MAxis::Ymin, 0);
      backDHand->setBoundaryCondition("u", MAxis::Ymax, 0);
      break;
    case 3:
      backDHand->setBoundaryCondition("u", MAxis::Xmin, [=](double x){return sin(M_PI*x)*cos(0.);});
      backDHand->setBoundaryCondition("u", MAxis::Ymin, 0);
      backDHand->setBoundaryCondition("u", MAxis::Ymax, 0);
      break;
    default:
      throw runtime_error("Convergence Poisson:: set a test from 1 to 3");
    }

    backDHand->printFileLegacyVtk("dofBack", true);

    // *******************************************************************//
    // *****          IMMERSED PROBLEM           *****//
    // *******************************************************************//
    if (true)
    {
      // Immersed HiPerProblem
      SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
      //General setters
      immHP->setParameterStructure(paramStr);
      immHP->setGlobalIntegrals({"Area","Length","uError","duError","total_edge_length"});
      immHP->setDOFsHandlers({backDHand});

      if (testN == 3)
      {
        // Set integration for the border
        immHP->setIntegration("IntegBorder", {"backDHand"});
        immHP->_setCubatureBorderGauss_MAxis("IntegBorder",10,{MAxis::Xmax}); // XMax
        immHP->setElementFillings("IntegBorder", LS_backBorder);
      }

      // Set integration for the background mesh
      immHP->setIntegration("Integ1", {"backDHand"});
      // immHP->setCubatureCutCellNonConforming("Integ", 4, 1, 4);
      immHP->setCubatureGauss("Integ1", 9);
      immHP->setElementFillings("Integ1", LS_backBulk1);

      immHP->Update();

      //-------------------------- Immersed solver -------------------------//
      SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
      immSOL->setHiPerProblem(immHP);
      immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
      immSOL->setDefaultParameters();
      immSOL->Update();
      //---------------------------- Solve immersed ------------------------//
      // Solve
      // immHP->FillLinearSystem();
      immSOL->solve();
      immSOL->UpdateSolution();
      string meshName = to_string(nS);
      string Kname = "K"+to_string(nS)+".mm";
      const char *CKname = Kname.c_str();

      EpetraExt::RowMatrixToMatrixMarketFile(CKname, *immHP->A);
      // Print
      string solName = "solBack."+to_string(nS);
      backDHand->printFileLegacyVtk(solName, true);

      double L = immHP->globalIntegral("Length");
      double A = immHP->globalIntegral("Area");
      cout << "Area: " << A << " Lenght: " << L << endl;

      SmartPtr<HiPerProblem> checkSolution = Create<HiPerProblem>();
      checkSolution->setDOFsHandlers({backDHand});
      checkSolution->setParameterStructure(paramStr);

      if (testN == 3)
      {
        // Set integration for the border
        checkSolution->setIntegration("IntegBorder", {"backDHand"});
        checkSolution->_setCubatureBorderGauss_MAxis("IntegBorder",10,{MAxis::Xmax}); // XMax
        checkSolution->setElementFillings("IntegBorder", CheckNitsche);
      }

      // Set integration for the background mesh
      checkSolution->setIntegration("Integ0", {"backDHand"});
      checkSolution->setCubatureGauss("Integ0", 9);
      checkSolution->setElementFillings("Integ0", CheckSolution0);

      checkSolution->setGlobalIntegrals({"error","uErr","duErr"});
      checkSolution->Update();

      checkSolution->FillLinearSystem();
      double error = checkSolution->globalIntegral("error");
      std::cout << "error: " << sqrt(error) << std::endl;
      double Uerror = checkSolution->globalIntegral("uErr");
      std::cout << "U border error: " << sqrt(Uerror) << std::endl;
      double dUerror = checkSolution->globalIntegral("duErr");
      std::cout << "dU*n border error: " << sqrt(dUerror) << std::endl;

      Merr.push_back(sqrt(error));
      Kerr.push_back(sqrt(Uerror));
      Terr.push_back(sqrt(dUerror));
    }
  }
  // Column headers
    cout << left
         << setw(20) << "1/h"
         << setw(20)  << "M Err"
         << setw(20) << "K Err"
         << setw(20) << "T Err"
         << endl;

    // Separator line
    cout << string(80, '-') << endl;

  for(int nS = 0; nS < nxt.size(); nS++)
  {
    cout << left << setw(20) <<  nxt[nS] <<  setw(20) <<  Merr[nS]  << setw(20) << Kerr[nS] << setw(20) << Terr[nS]  << endl;
  }
  hiperlife::Finalize();
  return 0;
}