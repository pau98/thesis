
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_MeshLoader.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Iterative_Belos.h"
#include "hl_MultiPatchMeshGenerator.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

RCP<MultiPatchMeshGenerator> genGeom(int bfOrder, int nEr, int nEa, int nEh, int nEl, int nEc, int nEz, double L, double H, double W, double r, double c, double s);



void LS(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFsDers(0);  // Local shape function
    // double* glNa = subFill.nborBFsDers(1); // Local shape function derivatives
    double gNa[eNN*pDim], jac;
    // GlobalBasisFunctions::gradients(gNa, jac, eNN, pDim, nDim, xe_nodes.data(), glNa);
    GlobalBasisFunctions::gradients(gNa, jac, subFill);

    vector<double> x(pDim);
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d]  * Na[i];
    }

    // if (x[0] < 0.9)
    // force *= x[0];

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}

int main()
{
    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    MPI_Init(nullptr, nullptr);


    ///=============== Define parameters of the model ===============///
    double force = 0.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;

    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//

    // Remove warning by an error in unclamp nurbs
    // Implement unclamp nurbs
    // diskSquared only for nurbs
    // Quarterplatewithcircularhole only for nurbs
    // Minimize the number of repeated knot spans in surfaces of revolution

    ///====================== Mesh generation ======================///
    ///
    int bfOrder = 2;
    // Number of elements
    int nEx = 6; // Number of elements in the radial direction
    int nEy = 6; // Number of elements in the angular direction (must be even)
    int nEz = 5;  // Number of elements in z direction


    // Hole
    double r    = 0.02;  // Radius
    double s    = 0.05;  // Domain size
    double H    = 0.05;  // Domain depth



    BasisFuncType bfType = BasisFuncType::Lagrangian;
    ElemType eType = ElemType::Parallelep;


    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genSolidQuarterPlateWithCylindricalHole(nEx, nEy, nEz, s, H, r);
    // structMesh->genQuarterPlateWithCircularHole(nEx, nEy, s, s, r);
    // structMesh->genStructMesh(nEx, nEy, nEz);


    structMesh->printMesh("Mesh");


//     ///===========             Distribute mesh            ===========///
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setVerbosity(Verbosity::High);
    disMesh->setBalanceMesh(true);
    disMesh->Update();
    disMesh->printFileLegacyVtk("Mesh");

    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//
    /// **************************************************************//

    ///===========           Create DOFHandler            ===========///
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    // dofHand->setNodeAuxF(1);
    dofHand->Update();

    ///===========          Boundary conditions          ===========///


    for (int i = 0; i < disMesh->loc_nPts(); i++)
    {
        vector<double> x = disMesh->nodeCoords(i, IndexType::Local);
        // dhand->nodeDOFs->setValue(0, i, IndexType::Local, 1.0);
        // Fix left-hand side
        if (x[0] < 0.001)
        {
            dofHand->setConstraint(0, i, IndexType::Local, 1.0);
        }
        if (x[0] > 0.049)
        {
            dofHand->setConstraint(0, i, IndexType::Local, 0.0);
        }
    }
    dofHand->UpdateGhosts();



    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->setCubatureGauss("Integ", 27);
    hiperProbl->Update();


    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
    // RCP<BelosIterativeLinearSolver> solver = rcp (new BelosIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setSolver(BelosIterativeLinearSolver::Solver::BlockCG);
    // solver->setPrecond(BelosIterativeLinearSolver::Precond::Ilu);
    // solver->setDefaultParameters();
    // solver->setVerbosity(BelosIterativeLinearSolver::Verbosity::Low);
    // solver->Update();

    // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // solver->setPrecond(AztecOOIterativeLinearSolver::Precond::DomainDecomp);
    // solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver->setDefaultParameters();
    // solver->Update();

    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    // solver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General);
    //solver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Parallel);
    // solver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->setDefaultParameters();
    solver->Update();

    // RCP<Amesos2DirectLinearSolver> solver = rcp(new Amesos2DirectLinearSolver());
    // solver->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
    // solver->setHiPerProblem(hiperProbl);
    // solver->setNumericFactorization(true);
    // solver->setSymbolicFactorization(true);
    // solver->setVerbosity(Amesos2DirectLinearSolver::Verbosity::High);
    // solver->setDefaultParameters();
    // solver->Update();


    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    // {
    //     hiperProbl->FillLinearSystem();
    //     cout << *hiperProbl->A << endl;
    //     cout << *hiperProbl->rhs << endl;
    // }

    solver->solve();
    solver->UpdateSolution();

    dofHand->printFileLegacyVtk("Poisson", true);




    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}
