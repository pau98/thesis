/// C++ headers
#include <iostream>
#include <mpi.h>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// HiPerLiFE headers
#include "hl_TypeDefs.h"
#include "hl_DistributedData.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_MeshMap.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void functionValue(double &v, double *dv, double *ddv, double *dddv, double *x);
void LS_Patch(RCP<hiperlife::FillStructure> fillStr);
void LS_Check(RCP<hiperlife::FillStructure> fillStr);
void PostProcess(RCP<hiperlife::HiPerProblem> hiperProblem);

int main(int argc, char *argv[])
{
    //Initialize MPI
    MPI_Init(nullptr, nullptr);

    //Model parameters
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(3);
    string oname = "Patch";


    //Numerical parameters
    RCP<UserStructure> userNum = rcp(new UserStructure);
    userNum->dparam.resize(3);
    userNum->iparam.resize(3);
    double linTol = 1e-8;
    double resTol = 1e-6;
    double solTol = 1e-6;
    int timeImax  = 100;
    int linImax   = 5000;
    int newtImax  = 6;
    userNum->dparam[0] = linTol;
    userNum->dparam[1] = resTol;
    userNum->dparam[2] = solTol;
    userNum->iparam[0] = timeImax;
    userNum->iparam[1] = linImax;
    userNum->iparam[2] = newtImax;

    //Mesh parameters
    int nDim = 3;
    int DOF = 1;
    int AUX = 7;
    BasisFuncType bfType = BasisFuncType::BSplines;
    ElemType eType = ElemType::Square;
    if (bfType == BasisFuncType::SubdivSurfs)
        eType = ElemType::Triang;
    int bfOrder = 4;
    int gPts{};
    {
        if (eType == ElemType::Line)
            gPts = bfOrder+1;
        else if (eType == ElemType::Square)
            gPts = int(pow(bfOrder+1, 2));
        else if (eType == ElemType::Triang)
            gPts = 4;
        else if (eType == ElemType::Parallelep)
            gPts = int(pow(bfOrder+1, 3));
    }

    //Generate mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setNDim(nDim);
    structMesh->setElemType(eType);
    structMesh->setBasisFuncType(bfType);
    {
        structMesh->setBasisFuncOrder(bfOrder);
        structMesh->genStructMesh(40, 40);
        // structMesh->stretchElemsAsymmetricX(2.0);
        // structMesh->genDisk_Squared(40, 40, 1.0);
    }

    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    try
    {
        disMesh->setMesh(structMesh);
        disMesh->setBalanceMesh(false);
        disMesh->Update();

        cout << disMesh->myRank() << ":   Distributed Mesh successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << disMesh->myRank() << ":   Distributed Mesh could not be created. " << err.what() << endl;

        MPI_Finalize();
        return 0;
    }

    //Print mesh
    if (bfType == BasisFuncType::Lagrangian)
        disMesh->printFileLegacyVtk("Mesh");
    else
        disMesh->printFileLegacyCSV("Mesh");
    disMesh->printFileLegacyVtk("Mesh");

    //DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    try
    {
        dhand->setNameTag("dhand");
        dhand->setNumDOFs(DOF);
        // dhand->setNumNodeAuxF(AUX);
        dhand->setNumElemAuxF(8);

        dhand->Update();

        cout << dhand->myRank() << ":   DOFsHandler successfully created. " << endl;
    }
    catch(runtime_error& err)
    {
        cout << dhand->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;

        MPI_Finalize();
        return 0;
    }

    //Initial and boundary conditions
    for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
    {
        double x = dhand->mesh->nodeCoord(i, 0, IndexType::Local);
        double y = dhand->mesh->nodeCoord(i, 1, IndexType::Local);
        double z = dhand->mesh->nodeCoord(i, 2, IndexType::Local);
        double r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        // dhand->nodeDOFs->setValue(0, i, IndexType::Local, 1.0);
    }
    // dhand->setConstraint(0, MAxis::Xmin, 0.0);
    // dhand->setConstraint(0, MAxis::Xmax, 1.0);



    //Create hiperProblem
    RCP<HiPerProblem> hiperProblem = rcp(new HiPerProblem("HiperObject"));
    //Set user structure and HiperProblem
    hiperProblem->setUserStructure(userStr);
    hiperProblem->setDOFsHandlers({dhand});

    //Set integration
    hiperProblem->setIntegration("Integ", {"dhand"});
    hiperProblem->setCubatureGauss("Integ", gPts);
    hiperProblem->setElementFillings("Integ", LS_Patch);

    //Set global integrals
    hiperProblem->setGlobalIntegrals({"f", "df0", "df1", "ddf0", "ddf1", "ddf2", "ddf3",
                                "dddf000", "dddf001", "dddf010", "dddf011", "dddf100", "dddf101", "dddf110", "dddf111"
                                , "area"});


    //Set solver
    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProblem);
    solver->setDefaultParameters();
    solver->setMatrixType(MUMPSDirectLinearSolver::MatrixType::General); // or Symmetric
    solver->setAnalysisType(MUMPSDirectLinearSolver::AnalysisType::Parallel); // or Serial
    solver->setOrderingLibrary(MUMPSDirectLinearSolver::OrderingLibrary::Auto);
    solver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::High);
    solver->Update();

    //Update
    hiperProblem->Update();
    cout << disMesh->myRank() << ":   HiperProblem successfully created. " << endl;

    //Assemble
    hiperProblem->UpdateGhosts();
    hiperProblem->FillLinearSystem();

    //Solve the linear system
    solver->solve();

    //Update solution
    hiperProblem->UpdateSolution();
    hiperProblem->UpdateGhosts();


    //Check integrals
    hiperProblem->setElementFillings("Integ", LS_Check);
    hiperProblem->FillLinearSystem();

    //Output integral results
    if (disMesh->myRank() == 0) {
        cout << endl;
        cout << "Error: " << hiperProblem->globalIntegral("f") << endl;
        cout << "Error derivative[0]: " << hiperProblem->globalIntegral("df0") << endl;
        cout << "Error derivative[1]: " << hiperProblem->globalIntegral("df1") << endl;
        cout << "Error second derivative[0]:" << hiperProblem->globalIntegral("ddf0") << endl;
        cout << "Error second derivative[1]:" << hiperProblem->globalIntegral("ddf1") << endl;
        cout << "Error second derivative[2]:" << hiperProblem->globalIntegral("ddf2") << endl;
        cout << "Error second derivative[3]:" << hiperProblem->globalIntegral("ddf3") << endl;
        cout << "Error third derivative[0,0,0]:" << hiperProblem->globalIntegral("ddf000") << endl;
        cout << "Error third derivative[0,0,1]:" << hiperProblem->globalIntegral("ddf001") << endl;
        cout << "Error third derivative[0,1,0]:" << hiperProblem->globalIntegral("ddf010") << endl;
        cout << "Error third derivative[0,1,1]:" << hiperProblem->globalIntegral("ddf011") << endl;
        cout << "Error third derivative[1,0,0]:" << hiperProblem->globalIntegral("ddf100") << endl;
        cout << "Error third derivative[1,0,1]:" << hiperProblem->globalIntegral("ddf101") << endl;
        cout << "Error third derivative[1,1,0]:" << hiperProblem->globalIntegral("ddf110") << endl;
        cout << "Error third derivative[1,1,1]:" << hiperProblem->globalIntegral("ddf111") << endl;

        cout << "Area:" << hiperProblem->globalIntegral("area") << endl;
    }


    //Postprocess
    // if ((bfType != BasisFuncType::BSplines) && (bfType != BasisFuncType::Nurbs))
    //     PostProcess(hiperProblem);
    hiperProblem->UpdateGhosts();

    string solname_v = oname;
    dhand->printFileLegacyVtk(solname_v, true);

    //Finalize
    MPI_Finalize();
    return 0;
}

void LS_Patch(RCP<FillStructure> fillStr)
{

    //Rename variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int DOF   = subFill.numDOFs;
    int eNN   = subFill.eNN;
    int nDim  = subFill.nDim;
    int pDim  = subFill.pDim;
    double *xe_nodes  = subFill.nborCoords.data();
    double *ue_nodes  = subFill.nborDOFs.data();
    double *ue_nodes0 = subFill.nborDOFs0.data();

    //Shape functions and derivatives at Gauss points
    double* Na  = subFill.nborBFsDers(0);
    double* glNa = subFill.nborBFsDers(1);
    double* hlNa = subFill.nborBFsDers(2);
    double  jac, gNa[eNN*pDim], hNa[eNN*pDim*pDim], lapNa[eNN];
    GlobalBasisFunctions::hessians(gNa, jac, hNa, lapNa, subFill);

    //Values at integration points
    double x[pDim], phi{}, phin{}, gphi[pDim], lapphi{};
    Array::Fill(x, pDim, 0.0);
    Array::Fill(gphi, pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d]  * Na[i];
        phi  += ue_nodes[DOF*i+0]  * Na[i];
        phin += ue_nodes0[DOF*i+0] * Na[i];

        //Gradients
        for (int d = 0; d < pDim; d++)
            gphi[d] += ue_nodes[DOF*i+0] * gNa[pDim*i+d];

        //Hessians
        for (int d = 0; d < pDim; d++)
            lapphi += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+d];

    }
    double val, dval[2], ddval[4], dddval[8];
    functionValue(val, dval, ddval, dddval, x);

    //Fill
    int NNZ = DOF*eNN;
    for (int i = 0; i < eNN; i++)
    {
        //Gradients
        double gNagphi{};
        for (int d = 0; d < pDim; d++)
            gNagphi += gNa[pDim*i+d]*gphi[d];

        for (int j = 0; j < eNN; j++)
        {
            //Gradients
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            //Fill Ak
            fillStr->Ak(0, 0)[(i*DOF+0)*NNZ+(j*DOF+0)] += jac * Na[i] * Na[j];
            // fillStr->Ak(0, 0)[(i*DOF+0)*NNZ+(j*DOF+0)] += jac * Na[i] * Na[j];
        }

        //Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * val;
        // fillStr->Bk(0)[i*DOF] += jac * x[0];
    }


    return;
}

void LS_Check(RCP<FillStructure> fillStr)
{

    //Rename variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int DOF   = subFill.numDOFs;
    int eNN   = subFill.eNN;
    int nDim  = subFill.nDim;
    int pDim  = subFill.pDim;
    double *xe_nodes = subFill.nborCoords.data();
    double *ue_nodes = subFill.nborDOFs.data();

    //Shape functions and derivatives at Gauss points
    double* Na  = subFill.nborBFsDers(0);
    double* glNa = subFill.nborBFsDers(1);
    double* hlNa = subFill.nborBFsDers(2);
    double  jac, gNa[eNN*pDim], hNa[eNN*pDim*pDim], D3Na[eNN*pDim*pDim*pDim], lapNa[eNN];
    GlobalBasisFunctions::thirdGlobalDerivs(gNa, jac, hNa, lapNa, D3Na, subFill);

    //Values at integration points
    double x[pDim], phi{}, gphi[pDim], hessphi[pDim*pDim], D3phi[pDim*pDim*pDim], lapphi{};
    Array::Fill(x, pDim, 0.0);
    Array::Fill(gphi, pDim, 0.0);
    Array::Fill(hessphi, pDim*pDim, 0.0);
    Array::Fill(D3phi, pDim*pDim*pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d] * Na[i];
        phi += ue_nodes[DOF*i+0] * Na[i];

        //Gradients
        for (int d = 0; d < pDim; d++)
            gphi[d] += ue_nodes[DOF*i+0] * gNa[pDim*i+d];

        //Hessians
        for (int d = 0; d < pDim; d++)
        {
            lapphi += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+d];

            for (int k = 0; k < pDim; k++)
            {
                hessphi[d*pDim +k] += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+k];
            }
        }

        //Third derivatives
        for (int d = 0; d < pDim; d++)
            for (int k = 0; k < pDim; k++)
                for (int l = 0; l < pDim; l++)
                    D3phi[d*pDim*pDim+k*pDim+l] += ue_nodes[i] * D3Na[pDim*pDim*pDim*i+pDim*pDim*d+pDim*k+l];

    }


    //Get errors
    double val, dval[2], ddval[4], dddval[8];
    functionValue(val, dval, ddval, dddval, x);
    double fE{}, dfE[2], ddfE[4],dddfE[8];
    Array::Fill(dfE, pDim, 0.0);
    Array::Fill(ddfE, pDim*pDim, 0.0);
    Array::Fill(dddfE, pDim*pDim*pDim, 0.0);
    fE = (phi-val);
    for (int d = 0; d < pDim; d++)
        dfE[d] = gphi[d] - dval[d];
    for (int d = 0; d < pDim; d++)
        for (int k = 0; k < pDim; k++)
            ddfE[d*pDim+k] = hessphi[d*pDim+k] - ddval[d*pDim+k];
    for (int d = 0; d < pDim; d++)
        for (int k = 0; k < pDim; k++)
            for (int l = 0; l < pDim; l++) {
                dddfE[d * pDim * pDim + k * pDim + l] =
                        D3phi[d * pDim * pDim + k * pDim + l] - dddval[d * pDim * pDim + k * pDim + l];
            }

    if (abs(ddfE[0]) > 1.0)
        cout << ddfE[0] << endl;

    fillStr->addToGlobalIntegral("f", jac*abs(fE));
    fillStr->addToGlobalIntegral("df0", jac*abs(dfE[0]));
    fillStr->addToGlobalIntegral("df1", jac*abs(dfE[1]));
    fillStr->addToGlobalIntegral("ddf0", jac*abs(ddfE[0]));
    fillStr->addToGlobalIntegral("ddf1", jac*abs(ddfE[1]));
    fillStr->addToGlobalIntegral("ddf2", jac*abs(ddfE[2]));
    fillStr->addToGlobalIntegral("ddf3", jac*abs(ddfE[3]));

    fillStr->addToGlobalIntegral("dddf000", jac*abs(dddfE[0*pDim*pDim+0*pDim+0]));
    fillStr->addToGlobalIntegral("dddf001", jac*abs(dddfE[0*pDim*pDim+0*pDim+1]));
    fillStr->addToGlobalIntegral("dddf010", jac*abs(dddfE[0*pDim*pDim+1*pDim+0]));
    fillStr->addToGlobalIntegral("dddf011", jac*abs(dddfE[0*pDim*pDim+1*pDim+1]));
    fillStr->addToGlobalIntegral("dddf100", jac*abs(dddfE[1*pDim*pDim+0*pDim+0]));
    fillStr->addToGlobalIntegral("dddf101", jac*abs(dddfE[1*pDim*pDim+0*pDim+1]));
    fillStr->addToGlobalIntegral("dddf110", jac*abs(dddfE[1*pDim*pDim+1*pDim+0]));
    fillStr->addToGlobalIntegral("dddf111", jac*abs(dddfE[1*pDim*pDim+1*pDim+1]));

    fillStr->addToGlobalIntegral("area", jac);


    return;
}


void functionValue(double &v, double *dv, double *ddv, double *dddv, double *x)
{
    int type = 7;
    int d = 2; // Number of dimensions
    if (type == 0)
    {
        v = 1.0;
        dv[0] = 0.0;
        dv[1] = 0.0;
        ddv[0] = 0.0;
        ddv[1] = 0.0;
        ddv[2] = 0.0;
        ddv[3] = 0.0;
        dddv[0*d*d+0*d+0] = 0.0;
        dddv[0*d*d+0*d+1] = 0.0;
        dddv[0*d*d+1*d+0] = 0.0;
        dddv[0*d*d+1*d+1] = 0.0;
        dddv[1*d*d+0*d+0] = 0.0;
        dddv[1*d*d+0*d+1] = 0.0;
        dddv[1*d*d+1*d+0] = 0.0;
        dddv[1*d*d+1*d+1] = 0.0;
    }
    else if (type == 1)
    {
        v = x[0];
        dv[0] = 1.0;
        dv[1] = 0.0;
        ddv[0] = 0.0;
        ddv[1] = 0.0;
        ddv[2] = 0.0;
        ddv[3] = 0.0;
        dddv[0*d*d+0*d+0] = 0.0;
        dddv[0*d*d+0*d+1] = 0.0;
        dddv[0*d*d+1*d+0] = 0.0;
        dddv[0*d*d+1*d+1] = 0.0;
        dddv[1*d*d+0*d+0] = 0.0;
        dddv[1*d*d+0*d+1] = 0.0;
        dddv[1*d*d+1*d+0] = 0.0;
        dddv[1*d*d+1*d+1] = 0.0;
    }
    else if (type == 2)
    {
        v = x[0]*x[0];
        dv[0] = 2.0*x[0];
        dv[1] = 0.0;
        ddv[0] = 2.0;
        ddv[1] = 0.0;
        ddv[2] = 0.0;
        ddv[3] = 0.0;
        dddv[0*d*d+0*d+0] = 0.0;
        dddv[0*d*d+0*d+1] = 0.0;
        dddv[0*d*d+1*d+0] = 0.0;
        dddv[0*d*d+1*d+1] = 0.0;
        dddv[1*d*d+0*d+0] = 0.0;
        dddv[1*d*d+0*d+1] = 0.0;
        dddv[1*d*d+1*d+0] = 0.0;
        dddv[1*d*d+1*d+1] = 0.0;
    }
    else if (type == 3)
    {
        v = x[0]*x[1];
        dv[0] = x[1];
        dv[1] = x[0];
        ddv[0] = 0.0;
        ddv[1] = 1.0;
        ddv[2] = 1.0;
        ddv[3] = 0.0;
        dddv[0*d*d+0*d+0] = 0.0;
        dddv[0*d*d+0*d+1] = 0.0;
        dddv[0*d*d+1*d+0] = 0.0;
        dddv[0*d*d+1*d+1] = 0.0;
        dddv[1*d*d+0*d+0] = 0.0;
        dddv[1*d*d+0*d+1] = 0.0;
        dddv[1*d*d+1*d+0] = 0.0;
        dddv[1*d*d+1*d+1] = 0.0;
    }
    else if (type == 4)
    {
        v = x[0]*x[0]*x[0];
        dv[0] = 3.0*x[0]*x[0];
        dv[1] = 0.0;
        ddv[0] = 6.0*x[0];
        ddv[1] = 0.0;
        ddv[2] = 0.0;
        ddv[3] = 0.0;
        dddv[0*d*d+0*d+0] = 6.0;
        dddv[0*d*d+0*d+1] = 0.0;
        dddv[0*d*d+1*d+0] = 0.0;
        dddv[0*d*d+1*d+1] = 0.0;
        dddv[1*d*d+0*d+0] = 0.0;
        dddv[1*d*d+0*d+1] = 0.0;
        dddv[1*d*d+1*d+0] = 0.0;
        dddv[1*d*d+1*d+1] = 0.0;
    }
    else if (type == 5)
    {
        v = x[0]*x[0]*x[0]*x[0] + x[0]*x[0]*x[0]*x[1];
        dv[0] = 4.0*x[0]*x[0]*x[0] + 3.0*x[0]*x[0]*x[1];
        dv[1] = x[0]*x[0]*x[0];
        ddv[0] = 12.0*x[0]*x[0] + 6.0*x[0]*x[1];
        ddv[1] = 3.0*x[0]*x[0];
        ddv[2] = 3.0*x[0]*x[0];
        ddv[3] = 0.0;
        dddv[0*d*d+0*d+0] = 24.0*x[0] + 12.0*x[1];
        dddv[0*d*d+0*d+1] = 6.0*x[0];
        dddv[0*d*d+1*d+0] = 6.0*x[0];
        dddv[0*d*d+1*d+1] = 0.0;
        dddv[1*d*d+0*d+0] = 6.0*x[0];
        dddv[1*d*d+0*d+1] = 0.0;
        dddv[1*d*d+1*d+0] = 0.0;
        dddv[1*d*d+1*d+1] = 0.0;
    }
    else if (type == 6)
    {
        v = x[0]*x[0]*x[0]*x[0]*x[0];
        dv[0] = 5.0*x[0]*x[0]*x[0]*x[0];
        dv[1] = 0.0;
        ddv[0] = 20.0*x[0]*x[0]*x[0];
        ddv[1] = 0.0;
        ddv[2] = 0.0;
        ddv[3] = 0.0;
        dddv[0*d*d+0*d+0] = 60.0*x[0]*x[0];
        dddv[0*d*d+0*d+1] = 0.0;
        dddv[0*d*d+1*d+0] = 0.0;
        dddv[0*d*d+1*d+1] = 0.0;
        dddv[1*d*d+0*d+0] = 0.0;
        dddv[1*d*d+0*d+1] = 0.0;
        dddv[1*d*d+1*d+0] = 0.0;
        dddv[1*d*d+1*d+1] = 0.0;
    }
    else if (type == 7)
    {
        v = x[0]*x[0]*x[0] - x[1]*x[1]*x[1] - 3.0 * x[0]*x[0]*x[1] + x[1]*x[1]*x[0];
        dv[0] = 3.0*x[0]*x[0] - 6.0*x[0]*x[1] + x[1]*x[1];
        dv[1] = -3.0*x[1]*x[1] - 3.0*x[0]*x[0] + 2.0*x[1]*x[0];
        ddv[0] = 6.0*x[0] - 6.0*x[1];
        ddv[1] = - 6.0*x[0] + 2.0*x[1];
        ddv[2] = - 6.0*x[0] + 2.0*x[1];
        ddv[3] = -6.0*x[1] + 2.0*x[0];
        dddv[0*d*d+0*d+0] = 6.0;
        dddv[0*d*d+0*d+1] = -6.0;
        dddv[0*d*d+1*d+0] = -6.0;
        dddv[0*d*d+1*d+1] = 2.0;
        dddv[1*d*d+0*d+0] = -6.0;
        dddv[1*d*d+0*d+1] = 2.0;
        dddv[1*d*d+1*d+0] = 2.0;
        dddv[1*d*d+1*d+1] = -6.0;
    }
    else
    {
        throw runtime_error("This function does not exist");
    }

    return;
}

void PostProcess(RCP<hiperlife::HiPerProblem> hiperProblem)
{
    //Initialize
    auto dhand = hiperProblem->_dhands[0];
    auto mesh = dhand->mesh;
    auto adjcyEN = mesh->_adjcyEN;

    //Rename variables
    int nDim = dhand->mesh->nDim();
    int pDim = dhand->mesh->_pDim;
    int bfOrder = dhand->mesh->_bfOrder;
    int nVert = dhand->mesh->nVert();
    int DOF = dhand->numDOFs();
    vector<double> xe_nodes;
    vector<double> ue_nodes;
    vector<double> ue_nodes0;

    //Loop over nodes
    int loc_nPts = dhand->mesh->loc_nPts();
    for (int i = 0; i < loc_nPts; i++)
    {
        int ii = i + dhand->nodeAuxF->offs_nItem();

        //Get element
        vector<int> nbors = vector<int> (mesh->_adjcyNE->getNborList(i, IndexType::Local));
        int e = -1;
        for (auto ee: nbors)
        {
            if (adjcyEN->isItemInPart(ee))
            {
                e = ee;
                break;
            }
        }

        //Get coordinates and node values
        xe_nodes.resize(0);
        ue_nodes.resize(0);
        ue_nodes0.resize(0);
        int eNN = adjcyEN->getNumNbors(e, IndexType::Global);
        for (int j = 0; j < eNN; j++)
        {
            int jj = adjcyEN->getNbor(e, j, IndexType::Global);

            for (int d = 0; d < nDim; d++)
                xe_nodes.push_back(mesh->nodeCoord(jj, d));
            for (int d = 0; d < DOF; d++)
                ue_nodes.push_back(dhand->nodeDOFs->getValue(d, jj));
            for (int d = 0; d < DOF; d++)
                ue_nodes0.push_back(dhand->nodeDOFs0->getValue(d, jj));
        }

        //Get xi_samples
        vector<double> xi_samples;
        xi_samples.resize(pDim, 0.0);
        if (mesh->_basisFuncType == BasisFuncType::SubdivSurfs)
        {
            if (ii == mesh->_connec->getNbor(e, 1))
                xi_samples[0] = 1.0;
            else if (ii == mesh->_connec->getNbor(e, 2))
                xi_samples[1] = 1.0;
        }
        else if ((mesh->_basisFuncType == BasisFuncType::Lagrangian)||(mesh->_basisFuncType == BasisFuncType::BSplines))
        {
            int nn{};
            for (int n = 0; n < eNN; n++)
            {
                if (ii == mesh->_connec->getNbor(e, n))
                    break;
                nn++;
            }

            if (pDim == 1)
            {
                xi_samples[0] = -1.0 + (nn % (bfOrder+1)) * 2./bfOrder;
            }
            if (pDim == 2)
            {
                xi_samples[0] = -1.0 + (nn % (bfOrder+1)) * 2./bfOrder;
                xi_samples[1] = -1.0 + ((int) nn/(bfOrder+1)) * 2./bfOrder;
            }

        }
        // else if (mesh->_basisFuncType == BasisFuncType::BSplines)
        // {
        //     int nn{};
        //     for (int n = 0; n < eNN; n++)
        //     {
        //         if (ii == mesh->_connec->getNbor(e, n))
        //             break;
        //         nn++;
        //     }

        //     for (int d = 0; d < pDim; d++)
        //         xi_samples[d] = -1.0 + (nn % eNN_dir) * 2./bfOrder;
        // }
        else
        {
            throw runtime_error("Auxiliary printout: Basis function type not implemented");
        }

        //Get basis functions
        vector<vector<double>> BF;
        BF.resize(bfOrder+1);
        for (int i=0; i < bfOrder+1; i++)
            BF[i].resize(nVert * pow(pDim,i), 0.0);
        mesh->_basisFunctions->computeBasisFunctionsReference(BF, xi_samples, mesh->_basisFunctions->getTag(e,IndexType::Global));

        //Shape functions and derivatives at Gauss points
        double* Na  = BF[0].data();
        double* glNa = BF[1].data();
        double* hlNa = BF[2].data();
        double  jac, gNa[eNN*pDim], hNa[eNN*pDim*pDim], lapNa[eNN];
        GlobalBasisFunctions::_hessians(gNa, jac, hNa, lapNa, eNN, pDim, nDim, xe_nodes.data(), glNa, hlNa);
        if ((mesh->_basisFuncType == BasisFuncType::BSplines) || (mesh->_basisFuncType == BasisFuncType::Nurbs))
            jac *= 1.0/40.0/40.0/4.0;


        //Values at integration points
        double x[pDim], phi{}, gphi[pDim], hessphi[pDim*pDim], lapphi{};
        Array::Fill(x, pDim, 0.0);
        Array::Fill(gphi, pDim, 0.0);
        Array::Fill(hessphi, pDim*pDim, 0.0);
        for (int i = 0; i < eNN; i++)
        {
            //Values
            for (int d = 0; d < pDim; d++)
                x[d] += xe_nodes[nDim*i+d]  * Na[i];
            phi += ue_nodes[DOF*i+0] * Na[i];

            //Gradients
            for (int d = 0; d < pDim; d++)
                gphi[d] += ue_nodes[DOF*i+0] * gNa[pDim*i+d];

            //Hessians
            for (int d = 0; d < pDim; d++)
            {
                lapphi += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+d];
                for (int k = 0; k < pDim; k++)
                {
                    hessphi[d*pDim +k] += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+k];
                }
            }

        }

        // //Save auxiliary
        // for (int d = 0; d < pDim; d++)
        //     nborAuxF[i*AUX] = gphi[d];
        // for (int d = 0; d < pDim; d++)
        //     for (int k = 0; k < pDim; k++)
        //         nborAuxF[2+d*pDim+k] = hessphi[d*pDim+k];

        //Get errors
        double val, dval[2], ddval[4], dddval[8];
        functionValue(val, dval, ddval, dddval, x);
        double fE{}, dfE[2], ddfE[4];
        Array::Fill(dfE, pDim, 0.0);
        Array::Fill(ddfE, pDim*pDim, 0.0);
        fE = (phi-val);
        for (int d = 0; d < pDim; d++)
            dfE[d] = gphi[d] - dval[d];
        for (int d = 0; d < pDim; d++)
            for (int k = 0; k < pDim; k++)
                ddfE[d*pDim+k] = hessphi[d*pDim+k] - ddval[d*pDim+k];

        //Get auxiliary values of interest
        dhand->nodeAuxF->setValue(0, i, IndexType::Local, fE);
        dhand->nodeAuxF->setValue(1, i, IndexType::Local, dfE[0]);
        dhand->nodeAuxF->setValue(2, i, IndexType::Local, dfE[1]);
        dhand->nodeAuxF->setValue(3, i, IndexType::Local, ddfE[0]);
        dhand->nodeAuxF->setValue(4, i, IndexType::Local, ddfE[1]);
        dhand->nodeAuxF->setValue(5, i, IndexType::Local, ddfE[2]);
        dhand->nodeAuxF->setValue(6, i, IndexType::Local, ddfE[3]);


    }

}
