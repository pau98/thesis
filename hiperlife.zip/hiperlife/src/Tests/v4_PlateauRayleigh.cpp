/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_ConsistencyCheck.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);

double deltat = 1.E0;

int main()
{
    MPI_Init(nullptr, nullptr);

    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(ElemType::Triang, BasisFuncType::Linear, 1);
    structMesh->setPeriodicBoundaryCondition({Axis::Xaxis,Axis::Yaxis});
    structMesh->genRectangle(100,100,1.0,10.0);
    structMesh->transformFree([](double theta,double z,double h){double x=cos(2*M_PI*theta); double  y=sin(2*M_PI*theta);return std::make_tuple(x, y, z);});

    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->setElementLocatorEngine(ElementLocatorEngine::Octree);
    disMesh->Update();
    
    for(int i = 0; i < disMesh->loc_nPts(); i++)
    {
        int maxis = disMesh->nodeMAxis(i,IndexType::Local);
        if(maxis%3==0)
            disMesh->_nodeData()->setValue(1,i,IndexType::Local, 0.0);        
        if(maxis%2==0)
            disMesh->_nodeData()->setValue(1,i,IndexType::Local, 0.0);
    }

    RCP<DistributedMesh> gloDisMesh  = rcp(new DistributedMesh);
    gloDisMesh->setMeshRelation(MeshRelation::GlobConstr, disMesh);
    gloDisMesh->setBalanceMesh(false);
    gloDisMesh->setElementLocatorEngine(ElementLocatorEngine::Octree);
    gloDisMesh->Update();

    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setDOFs({"ux","uy","uz"});
    dofHand->setNodeAuxF({"vx","vy","vz"});
    dofHand->Update();

    RCP<DOFsHandler> gloDHand = rcp(new DOFsHandler(gloDisMesh));
    gloDHand->setNameTag("gloDHand");
    gloDHand->setDOFs({"P"});
    gloDHand->Update();

    // for(int i = 0; i < disMesh->loc_nPts(); i++)
    // {
    //     auto x = disMesh->nodeCoords(i,IndexType::Local);

    //     dofHand->nodeDOFs->setValue(0,i,IndexType::Local, 0.0001*cos(M_PI*x[2]));
    //     dofHand->nodeDOFs->setValue(1,i,IndexType::Local, 0.0001*cos(M_PI*x[2]));
    // }
    // dofHand->UpdateGhosts();
    // gloDHand->nodeDOFs->setValue(1);
    // gloDHand->UpdateGhosts();

    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setDOFsHandlers({dofHand,gloDHand});
    hiperProbl->setIntegration("Integ", {"dofHand","gloDHand"});
    // hiperProbl->setElementFillings("Integ", ConsistencyCheck<LS>);
    hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->setConsistencyCheckTolerance(1.E-5);
    hiperProbl->setConsistencyCheckDelta(1.E-5);
    hiperProbl->Update();

    RCP<AmesosDirectLinearSolver> solver = rcp ( new AmesosDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setDefaultParameters();
    solver->Update();

    RCP<NewtonRaphsonNonlinearSolver> nonlinsolver = rcp ( new NewtonRaphsonNonlinearSolver());
    nonlinsolver->setLinearSolver(solver);
    nonlinsolver->setLineSearch(false);
    nonlinsolver->setResTolerance(1.E-8);
    nonlinsolver->setSolTolerance(1.E-8);
    nonlinsolver->setMaxNumIterations(10);
    nonlinsolver->setPrintIntermInfo(true);
    nonlinsolver->Update();

    int nSteps = 100;
    dofHand->printFileLegacyVtk("sol"+to_string(0),false);

    dofHand->nodeDOFs0->setValue(dofHand->nodeDOFs);
    for(int i = 0; i < nSteps; i++)
    {
        if(disMesh->myRank()==0)
        {
            cout << i << " of " << nSteps << endl;
            cout << "    dt=" << deltat << endl;
        }

        nonlinsolver->solve();

        if(nonlinsolver->converged())
        {
            if(disMesh->myRank()==0)
                cout << "     Converged..." << endl;
            for(int i = 0; i < disMesh->loc_nPts(); i++)
            {
                for(int n = 0; n < 3; n++)
                {
                    double u = dofHand->nodeDOFs->getValue(n,i,IndexType::Local);
                    double u0 = dofHand->nodeDOFs0->getValue(n,i,IndexType::Local);
                    dofHand->nodeAuxF->setValue(n,i,IndexType::Local, (u-u0)/deltat);
                }
            }
            dofHand->nodeDOFs0->setValue(dofHand->nodeDOFs);
            gloDHand->nodeDOFs0->setValue(gloDHand->nodeDOFs);

            dofHand->UpdateGhosts();
            gloDHand->UpdateGhosts();
            
            dofHand->printFileLegacyVtk("sol"+to_string(i),true);

            if(nonlinsolver->numberOfIterations()<5)
                deltat *= 1.01;
        }            
        else
        {
            if(disMesh->myRank()==0)
                cout << "     Not converged..." << endl;

            dofHand->nodeDOFs->setValue(dofHand->nodeDOFs0);
            gloDHand->nodeDOFs->setValue(gloDHand->nodeDOFs0);

            deltat *= 0.99;
            i--;
        }
    }

    MPI_Finalize();
    return 0;
}

void LS(RCP<FillStructure> fillStr)
{
#if __cplusplus >= 201402L
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int eNN  = subFill.eNN;   

    SubFillStructure& subFillP = (*fillStr)["gloDHand"];
    double P = subFillP.nborDOFs[0];

    tensor<double,2,false> nborCoords(subFill.nborCoords.data(),eNN,3);  
    tensor<double,2,false> nborDOFs0(subFill.nborDOFs0.data(),eNN,3);  
    tensor<double,2,false> nborDOFs(subFill.nborDOFs.data(),eNN,3);  
    tensor<double,1,false> bf(subFill.nborBFsDers(0),eNN);        
    tensor<double,2,false> Dbf(subFill.nborBFsDers(1),eNN,2); 

    tensor<double,4,false> A00(fillStr->Ak(0,0).data(),eNN,3,eNN,3);
    tensor<double,2,false> A01(fillStr->Ak(0,1).data(),eNN,3);
    tensor<double,2,false> A10(fillStr->Ak(1,0).data(),eNN,3);
    tensor<double,2,false> B0(fillStr->Bk(0).data(),eNN,3);
    double& B1 = fillStr->Bk(1)[0];

    using index::a, index::b;
    using index::A, index::B, index::C;
    using index::i, index::j, index::k, index::l, index::m;

    tensor<double,1> x0 = bf(a) * (nborCoords(a,A)+nborDOFs0(a,A));
    tensor<double,2> Dx0 = Dbf(a,i) * (nborCoords(a,A)+nborDOFs0(a,A));
    tensor<double,2> metric0 = Dx0(i,A) * Dx0(j,A);
    tensor<double,2> imetric0 = metric0.inv();
    double jac0 = sqrt(metric0.det());
    tensor<double,1> normal0 = antisym3D(A,B,C) * Dx0(0,B) * Dx0(1,C);
    normal0 /= normal0.norm();

    tensor<double,1> x = bf(a) * (nborCoords(a,A)+nborDOFs(a,A));
    tensor<double,2> Dx =  Dbf(a,i) * (nborCoords(a,A)+nborDOFs(a,A));
    tensor<double,2> metric = Dx(i,A) * Dx(j,A);
    tensor<double,2> imetric = metric.inv();
    double jac = sqrt(metric.det());
    tensor<double,1> normal = antisym3D(A,B,C) * Dx(0,B) * Dx(1,C);
    normal /= normal.norm();

    tensor<double,2> rodt = metric - metric0;
    tensor<double,2> rodt_C0C0 = imetric0 * rodt * imetric0;

    tensor<double,4> dmetric(eNN,3,2,2);
    dmetric(a,A,i,j) = Dbf(a,i) * Dx(j,A) + Dx(i,A) * Dbf(a,j);
    tensor<double,4> dmetric_C0C0(eNN,3,2,2);
    dmetric_C0C0(a,A,j,k) = imetric0(j,l) * dmetric(a,A,l,m) * imetric0(m,k);
    tensor<double,4> dimetric(eNN,3,2,2);
    dimetric(a,A,j,k)=(-imetric(j,l)) * dmetric(a,A,l,m) * imetric(m,k);
    tensor<double,2> djac = ((0.5*jac) * imetric(i,j)) * dmetric(a,A,i,j);
    tensor<double,3> dnormal = (-Dbf(a,j)) * imetric(j,k)  * normal(A) * Dx(k,B);

    tensor<double,4> ddmetric(eNN,eNN,2,2);
    ddmetric(a,b,i,j) = Dbf(a,i) * Dbf(b,j) +  Dbf(a,j) * Dbf(b,i);
    tensor<double,4> ddjac(eNN,3,eNN,3);
    ddjac(a,A,b,B) =   djac(b,B) * ((0.5*imetric(i,j)) * dmetric(a,A,i,j))
                     + ((0.5*jac) * dimetric(b,B,i,j)) * dmetric(a,A,i,j)
                     + ((0.5*jac) * imetric(i,j)) * ddmetric(a,b,i,j) * Identity3(A,B) ;
                     
    double tension = 1.0 * deltat;
    double viscosity = 1.0;
    double friction = 1.E-1;

    B0 = tension * djac;
    B0(a,A) += (viscosity * jac0) * dmetric(a,A,i,j) * rodt_C0C0(i,j);
    B0(a,A) += (friction * jac0) * bf(a) * (x-x0)(A);
    B0(a,A) += deltat * P * jac * bf(a) * normal(A);
    B1 = deltat * jac * (x-x0) * normal;

    A00 = tension * ddjac;
    A00(a,A,b,B) += friction * jac0 * bf(a) * bf(b) * Identity3(A,B);
    A00(a,A,b,B) += viscosity * jac0 * ( (ddmetric(a,b,i,j) * rodt_C0C0(i,j)) * Identity3(A,B)
                                        + dmetric(a,A,i,j) *  dmetric_C0C0(b,B,i,j));
    A00(a,A,b,B) += deltat * P * (djac(b,B) * bf(a) * normal(A) + jac * bf(a) * dnormal(b,B,A));
    A01(a,A) = deltat * jac * bf(a) * normal(A);
    A10(a,A) = deltat * (djac(a,A) * ((x-x0) * normal) + jac * bf(a) * normal(A) + jac * (x-x0)(B)* dnormal(a,A,B));
#else
    std::cout << "This example only works with c++14 or newer" << std::endl;
#endif
}
