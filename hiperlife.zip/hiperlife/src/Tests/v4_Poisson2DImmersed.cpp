/// C++ headers
#include <iostream>
#include <fstream>
#include <mpi.h>
#include <cmath>
#include <unistd.h>
#include <chrono>

/// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_MultiPatchMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"

void Domain(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void Nitsche(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void computeL2Error(int numElements, int levelOfRefinement);
double analyticalSolution(double x, double y);
double bodyForce(double x, double y);

int main()
{
    // Get starting timepoint
    auto start = std::chrono::high_resolution_clock::now();

    MPI_Init(nullptr, nullptr);

    int myRank{};
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    for (int j = 6; j < 7; ++j)
    {
        for (int i = 2; i < 7; ++i)
        {
            computeL2Error(pow(2, i), j);
        }
    }

    MPI_Finalize();

    // Get ending timepoint
    auto stop = std::chrono::high_resolution_clock::now();

    // Get duration. Substart timepoints to
    // get duration. To cast it to proper unit
    // use duration cast method
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(stop - start);

    cout << "Time taken by function: "
         << duration.count() << " seconds" << endl;
    return 0;
}

void computeL2Error(int numElements, int epsilon)
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;

    int i = 1;
    while (0 == i)
        sleep(5);

    /// **************************************************************//
    /// *****                 Parameters                         *****//
    /// **************************************************************//
    double domainLength = 0.5 + pow(2,-epsilon);
    ElemType elemType = ElemType::Square;
    BasisFuncType bfType = BasisFuncType::BSplines;
    // int numBackElem{4};
    int numImmElem{4 * numElements};
    int bfOrder{3};
    set<MAxis> ax = {MAxis::Xmin, MAxis::Xmax, MAxis::Ymin, MAxis::Ymax};
    double h = 1. / static_cast<double>(numElements);
    double lambda{1000. / h};                            // Nitsche's parameter
    RCP<UserStructure> userStr = rcp(new UserStructure); // New user structure
    userStr->a_aux.resize(1);
    userStr->a_aux[0] = lambda;

    ///====================== Mesh generation ======================///
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(elemType, bfType, bfOrder);
    structMesh->setNDim(3);
    structMesh->genSquare(numElements, 1.);

    //Distributed mesh
    RCP<DistributedMesh> disBackMesh = rcp(new DistributedMesh);
    disBackMesh->setMesh(structMesh);
    disBackMesh->setBalanceMesh(true);
    disBackMesh->Update();
    disBackMesh->printFileLegacyVtk("backMesh");

    //--------------------------- Immersed mesh --------------------------//
    RCP<StructMeshGenerator> immersedMesh = rcp(new StructMeshGenerator);
    immersedMesh->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    immersedMesh->genSquareLine(numImmElem, domainLength);
    immersedMesh->translate((1. - domainLength) / 2., (1. - domainLength) / 2., 0.0);

    // RCP<StructMeshGenerator> immersedMesh2 = rcp(new StructMeshGenerator);
    // immersedMesh2->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    // immersedMesh2->genCircle(50, 0.2);
    // immersedMesh2->translate(0.5, 0.5, 0.0);

    // RCP<MultiPatchMeshGenerator> mpatch = rcp(new MultiPatchMeshGenerator);
    // mpatch->setMeshes({immersedMesh, immersedMesh2}, MultiPatchConnectivity::LinearConstraints, 0.000001);
    // mpatch->Update();

    // immersedMesh->genCircle(4, 0.5/sqrt(2));
    // immersedMesh->rotate2D(M_PI / 180 * 45);
    // immersedMesh->translate(0.5, 0.5, 0.0);

    // immersedMesh->genPolygonalCurve("../../meshes/fish.csv", true);
    // immersedMesh->scale(0.4);
    // immersedMesh->translate(0.5, 0.51, 0.0);

    // immersedMesh->genPolygonalCurve("../../meshes/violin.csv", true);
    // immersedMesh->scale(0.91);
    // immersedMesh->translate(0.5, 0.5, 0.0);

    //Distributed mesh
    RCP<DistributedMesh> disImmMesh = rcp(new DistributedMesh);
    disImmMesh->setMesh(immersedMesh);
    disImmMesh->setMeshRelation(MeshRelation::Immersed, disBackMesh);
    disImmMesh->setImmersedInteriorPoints({{0.5, 0.5, 0.0}});
    disImmMesh->setBalanceMesh(true);
    disImmMesh->Update();
    disImmMesh->printFileLegacyVtk("meshImm");

    /// **************************************************************//
    /// *****               DOFsHANDLER CREATION                 *****//
    /// **************************************************************//
    RCP<DOFsHandler> dofHandBack = rcp(new DOFsHandler(disBackMesh));
    dofHandBack->setNameTag("dofHandBack");
    dofHandBack->setNumDOFs(1);
    dofHandBack->Update();

    dofHandBack->setConstraint(0, 0.0);
    for (int e = 0; e < dofHandBack->mesh->loc_nElem(); e++)
    {
        if (dofHandBack->mesh->_elemFlags->getValue(1, e, IndexType::Local) != 0)
        {
            vector<int> nbors = dofHandBack->mesh->_connec->getNborList(e, IndexType::Local);
            for (auto n : nbors)
            {
                if (dofHandBack->mesh->isNodeInPart(n))
                {
                    dofHandBack->removeConstraint(0, n, IndexType::Global);
                }
            }
        }
    }

    dofHandBack->UpdateGhosts();
    dofHandBack->printFileLegacyVtk("dofHand", true);

    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHandBack});

    hiperProbl->setIntegration("Integ", {"dofHandBack"});
    int nGaussPts = pow(ceil(static_cast<double>(2 * bfOrder + 1) / 2.), 2);
    hiperProbl->setCubatureCutCellNonConforming("Integ", nGaussPts, nGaussPts, 3);
    hiperProbl->setElementFillings("Integ", Domain);

    hiperProbl->setIntegration("BorderInteg", {"dofHand"});
    hiperProbl->setCubatureBorderImmersed("BorderInteg", 7);
    hiperProbl->setElementFillings("BorderInteg", Nitsche);

    hiperProbl->setGlobalIntegrals({"L2E", "Area", "BorderLength"});

    hiperProbl->Update();

    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//

    //===========               Set solver               ===========//
    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    solver->setDefaultParameters();
    solver->Update();

    // RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setTolerance(1.E-8);
    // solver->setMaxNumIterations(500);
    // solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    // solver->setDefaultParameters();
    // solver->Update();

    ofstream myfile;
    myfile.open("cubature_" + to_string(hiperProbl->myRank()) + ".csv", std::ofstream::out | std::ofstream::trunc);
    myfile.close();

    solver->solve();
    solver->UpdateSolution();

    dofHandBack->printFileLegacyVtk("solBack", true);

    //Create timer
    RCP<Timer> _timer = Teuchos::rcp(new Timer({"filling"}));

    //Fill linear system
    _timer->start("filling");
    hiperProbl->FillLinearSystem();
    _timer->end("filling");
    _timer->printTiming();

    double error = sqrt(hiperProbl->globalIntegral("L2E"));

    if (hiperProbl->myRank() == 0)
    {
        cout.precision(15);
        cout << "L2 error      = \t" << error << endl;

        std::ofstream writeOut("L2Errors.csv", std::ios::app);
        assert(writeOut.is_open());
        writeOut.precision(12);
        writeOut << numElements << "\t"
                 << log10(h) << "\t"
                 << hiperProbl->globalIntegral("Volume") << "\t"
                 << lambda << "\t"
                 << hiperProbl->globalIntegral("BorderLength") << "\t"
                 << log10(error) << endl;
    }
    // Export stiffness matrix
    string matName = "A" + to_string(epsilon) + ".mm";
    EpetraExt::RowMatrixToMatrixMarketFile(matName.c_str(), *hiperProbl->A, "LHS", "Left hand side matrix");
}

//===============================================================================

void Domain(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;                                              // Number of neighbor nodes
    int nDim = subFill.nDim;                                            // Number of spatial dimensions
    int pDim = subFill.pDim;                                            // Number of parametric dimension
    int numDOFs = subFill.numDOFs;                                      // Number of degrees of freedom per node
    tensor<double, 1, false> bf(subFill.nborBasisFunctions(), eNN);            // Basis functions
    tensor<double, 2> Dbf_g(eNN, pDim);                                 // Derivatives of basis functions wrt x and y global coordinates
    tensor<double, 2, false> nborCoords(subFill.nborCoords.data(), eNN, nDim); // Coordinates for each node
    tensor<double, 2, false> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);  // DOF values at the nodes
    double jac;                                                         // Jacobian (differential of line/area/volume)
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}}); // Global coordinates (x,y,z)

    //===========              Finding Force              ==========//
    double force = bodyForce(coords(0), coords(1));

    ofstream myfile;
    myfile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    myfile << std::setprecision(16) << coords(0) << " " << coords(1) << " " << 0 << " " << 0 << " " << 0 << endl;
    myfile.close();

    //===================   Filling Ak and Bk  =====================//
    tensor<double, 2, false> Ak(fillStr->Ak(0, 0).data(), eNN, eNN);
    tensor<double, 1, false> Bk(fillStr->Bk(0).data(), eNN);
    Ak += product(Dbf_g, Dbf_g, {{1, 1}}) * jac;
    Bk += bf * force * jac;

    ///============          Calculate Errors         ===================///
    double uExact = analyticalSolution(coords(0), coords(1));
    tensor<double, 1> uFEM = product(nborDOFs, bf, {{0, 0}});
    double L2error = (uExact - uFEM(0)) * (uExact - uFEM(0)) * jac;
    fillStr->addToGlobalIntegral("L2E", L2error);
    fillStr->addToGlobalIntegral("Area", jac);
}

//===============================================================================

void Nitsche(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //===========          Initialize variables           ==========//
    SubFillStructure &subFill = (*fillStr)[0];
    int eNN = subFill.eNN;                                                        // Number of neighbor nodes
    int nDim = subFill.nDim;                                                      // Number of spatial dimensions
    int pDim = subFill.pDim;                                                      // Number of parametric dimension
    int numDOFs = subFill.numDOFs;                                                // Number of degrees of freedom per node
    tensor<double, 1, false> bf(subFill.nborBasisFunctions(), eNN);                      // Basis functions
    tensor<double, 2, false> Dbf_l(subFill.nborBasisFunctionsDerivatives(1), eNN, pDim); // Local derivatives of the bf
    tensor<double, 2> Dbf_g(eNN, pDim);                                           // Derivatives of basis functions wrt x and y global coordinates
    tensor<double, 2, false> nborCoords(subFill.nborCoords.data(), eNN, nDim);           // Coordinates for each node
    tensor<double, 2, false> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);            // DOF values at the nodes
    double jac;                                                                   // Jacobian (differential of line/area/volume)
    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);
    tensor<double, 1> coords = product(nborCoords, bf, {{0, 0}}); // Global coordinates (x,y,z)
    double lambda{fillStr->userStr->a_aux[0]};

    //===========              Finding Force              ==========//
    double u0 = analyticalSolution(coords(0), coords(1));

    //===========              Normal Vector              ==========//
    //Get tangent to immersed mesh at integration point
    auto immMesh = subFill.dhandDHand->mesh->_childMesh;
    std::vector<double> t(3);
    for (int n = 0; n < nDim; n++)
        t[n] = immMesh->_immTangents[subFill.loc_elemID][nDim * subFill.kPt + n];
    jac = Math::Norm3D(t.data());

    //Compute unitary normal
    std::vector<double> n(3, 0.0);
    // normals for square ???
    n[0] = -t[1] / jac;
    n[1] = t[0] / jac;

    // normals for circle ???
    // n[0] = t[1] / jac;
    // n[1] = -t[0] / jac;

    tensor<double, 1> NDbf_g(eNN); // Normal derivative
    NDbf_g(all) = n[0] * Dbf_g(all, 0) + n[1] * Dbf_g(all, 1);

    ofstream myfile;
    myfile.open("cubature_" + to_string(subFill.dhandDHand->myRank()) + ".csv", std::ios_base::app);
    myfile << std::setprecision(16) << coords(0) << " " << coords(1) << " " << 1 << " " << n[0] << " " << n[1] << endl;
    myfile.close();

    //======================   Output  =============================//
    tensor<double, 2, false> Ak(fillStr->Ak(0, 0).data(), eNN, eNN);
    tensor<double, 1, false> Bk(fillStr->Bk(0).data(), eNN);
    Ak -= outer(NDbf_g, bf) * jac;
    Ak -= outer(bf, NDbf_g) * jac;
    Ak += lambda * outer(bf, bf) * jac;
    Bk -= u0 * NDbf_g * jac;
    Bk += lambda * u0 * bf * jac;

    ///============          Calculate Errors         ===================///
    tensor<double, 1> uFEM = product(nborDOFs, bf, {{0, 0}});
    double L2error = (u0 - uFEM(0)) * (u0 - uFEM(0)) * jac;
    fillStr->addToGlobalIntegral("L2E", L2error);
    fillStr->addToGlobalIntegral("BorderLength", jac);
}

double analyticalSolution(double x, double y)
{
    double f = 10;
    return (x * y + sin(M_PI * f * x) * sin(M_PI * f * y));
}

double bodyForce(double x, double y)
{
    double f = 10;
    return (2 * f * f * M_PI * M_PI * sin(M_PI * f * x) * sin(M_PI * f * y));
}
