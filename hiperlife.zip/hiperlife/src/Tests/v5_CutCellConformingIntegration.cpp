// C++ headers
#include <mpi.h>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_Core.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"


using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(hiperlife::FillStructure& fillStr)
{
    using namespace std;

    // Initialize
    SubFillStructure& subFill = fillStr[0];
    int eNN  = subFill.eNN;                 // Number of neighbor nodes
    int pDim = subFill.pDim;                // Number of parametric dimension

    // Compute jacobian
    vector<double> dbf(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(dbf.data(), jac, subFill);

    // Save local area
    fillStr.addToGlobalIntegral("Area", jac);

    return;
}

int testArea_immersedBoundary(int nEx, int nEy, int nEside, double theta)
{
    // *******************************************************************//
    // *****                      MESH CREATION                      *****//
    // *******************************************************************//

    //-------------------------- Background mesh -------------------------//
    // Mesh generator
    RCP<StructMeshGenerator> back = rcp(new StructMeshGenerator);
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    back->genStructMesh(nEx, nEy);

    // Distributed mesh
    RCP<DistributedMesh> backMesh = rcp(new DistributedMesh);
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->Update();


    //--------------------------- Immersed mesh --------------------------//
    // Mesh generator
    RCP<StructMeshGenerator> imm = rcp(new StructMeshGenerator);
    imm->setMesh(ElemType::Line, BasisFuncType::Lagrangian, 1);
    imm->genSquareLine(nEside, 0.5);
    imm->translateXY(-0.25, -0.25);
    imm->rotate2D(theta);
    imm->translateXY(0.5, 0.5);

    // Distributed mesh
    RCP<DistributedMesh> immMesh = rcp(new DistributedMesh);
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedBoundary, backMesh);
    immMesh->setImmersedInteriorPoints({{0.01, 0.01, 0.0}});
    immMesh->setBalanceMesh(true);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->Update();


    // *******************************************************************//
    // *****                   DOFsHandler CREATION                  *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    RCP<DOFsHandler> backDHand = rcp(new DOFsHandler(backMesh));
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"u"});
    backDHand->Update();

    // Freeze exterior elements
    backDHand->setConstraint(0, 0.0);
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
        if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local) != 0)
        {
            vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
            for (auto n: nbors)
            {
                if (backDHand->mesh->isNodeInPart(n))
                {
                    backDHand->removeConstraint(0, n, IndexType::Global);
                }
            }
        }
    }

    // *******************************************************************//
    // *****                    IMMERSED PROBLEM                     *****//
    // *******************************************************************//

    // Immersed HiPerProblem
    RCP<HiPerProblem> immHP = rcp(new HiPerProblem);
    immHP->setDOFsHandlers({backDHand});
    immHP->setGlobalIntegrals({"Area"});
    immHP->setIntegration("Integ", {"backDHand"});
    immHP->setCubatureCutCellConforming("Integ", 4, 2);
    immHP->setElementFillings("Integ", LS);
    immHP->Update();

    // Compute area
    immHP->FillLinearSystem();
    double A = immHP->globalIntegral("Area");
    if (abs(0.75-A) > 1e-8)
        return 1;
    else
        return 0;
}

int testArea_immersedMesh(int nEx, int nEy, int nEside, double theta)
{
    // *******************************************************************//
    // *****                      MESH CREATION                      *****//
    // *******************************************************************//

    //-------------------------- Background mesh -------------------------//
    // Mesh generator
    RCP<StructMeshGenerator> back = rcp(new StructMeshGenerator);
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    back->genStructMesh(nEx, nEy);

    // Distributed mesh
    RCP<DistributedMesh> backMesh = rcp(new DistributedMesh);
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->Update();


    //--------------------------- Immersed mesh --------------------------//
    // Mesh generator
    RCP<StructMeshGenerator> imm = rcp(new StructMeshGenerator);
    imm->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    imm->genSquare(nEside, 0.5);
    imm->translateXY(-0.25, -0.25);
    imm->rotate2D(theta);
    imm->translateXY(0.5, 0.5);

    // Distributed mesh
    RCP<DistributedMesh> immMesh = rcp(new DistributedMesh);
    immMesh->setMesh(imm);
    immMesh->setMeshRelation(MeshRelation::ImmersedMesh, backMesh);
    immMesh->setImmersedInteriorPoints({{0.01, 0.01, 0.0}});
    immMesh->setBalanceMesh(true);
    immMesh->setVerbosity(Verbosity::None);
    immMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    immMesh->Update();


    // *******************************************************************//
    // *****                   DOFsHandler CREATION                  *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    RCP<DOFsHandler> backDHand = rcp(new DOFsHandler(backMesh));
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"u"});
    backDHand->Update();

    // Freeze exterior elements
    backDHand->setConstraint(0, 0.0);
    for (int e = 0; e < backDHand->mesh->loc_nElem(); e++)
    {
        if (backDHand->mesh->_elemFlags->getValue(1, e, IndexType::Local) != 0)
        {
            vector<int> nbors = backDHand->mesh->_connec->getNborList(e, IndexType::Local);
            for (auto n: nbors)
            {
                if (backDHand->mesh->isNodeInPart(n))
                {
                    backDHand->removeConstraint(0, n, IndexType::Global);
                }
            }
        }
    }

    // *******************************************************************//
    // *****                    IMMERSED PROBLEM                     *****//
    // *******************************************************************//

    // Immersed HiPerProblem
    RCP<HiPerProblem> immHP = rcp(new HiPerProblem);
    immHP->setDOFsHandlers({backDHand});
    immHP->setGlobalIntegrals({"Area"});
    immHP->setIntegration("Integ", {"backDHand"});
    immHP->setCubatureCutCellConforming("Integ", 4, 2);
    immHP->setElementFillings("Integ", LS);
    immHP->Update();

    // Compute area
    immHP->FillLinearSystem();
    double A = immHP->globalIntegral("Area");
    if (abs(0.75-A) > 1e-8)
        return 1;
    else
        return 0;
}

int main(int argc, char **argv)
{
    // Initialize
    hiperlife::Init(argc, argv);

    // Test (immersedBoundary)
    for (int e = 5; e < 11; e++)
    {
        for (int eS = 2; eS < 11; eS++)
        {
            for (int i = 0; i < 81; i++)
            {
                // Coincident meshes don't work so far (remove powers of 2)
                if (i == 0 and (e & (e - 1)) == 0)
                    continue;

                // Output
                if (VerboseRank())
                {
                    cout << "Testing CubatureCutCellConforming integration using immersedBoundary ";
                    cout << "Parameters: " << e << ", " << eS << ", " << i;
                }

                // Test
                double theta = i/81.0 * M_PI/2.0;
                int err = testArea_immersedBoundary(e, e, eS, theta);

                // Check output
                if (err == 1)
                {
                    if (VerboseRank())
                    {
                        cout << "   ** Test failed **" << endl;
                    }
                    hiperlife::Finalize();
                    return 1;
                }
                else
                {
                    if (VerboseRank())
                    {
                        cout << "   ** Test Passed **" << endl;
                    }
                }
            }
        }
    }

    // Test (immersedMesh)
    for (int e = 5; e < 11; e++)
    {
        for (int eS = 2; eS < 11; eS++)
        {
            for (int i = 0; i < 81; i++)
            {
                // Coincident meshes don't work so far (remove powers of 2)
                if (i == 0 and (e & (e - 1)) == 0)
                    continue;

                // Output
                if (VerboseRank())
                {
                    cout << "Testing CubatureCutCellConforming integration using immersedMesh ";
                    cout << "Parameters: " << e << ", " << eS << ", " << i;
                }

                // Test
                double theta = i/81.0 * M_PI/2.0;
                int err = testArea_immersedMesh(e, e, eS, theta);

                // Check output
                if (err == 1)
                {
                    if (VerboseRank())
                    {
                        cout << "   ** Test failed **" << endl;
                    }
                    hiperlife::Finalize();
                    return 1;
                }
                else
                {
                    if (VerboseRank())
                    {
                        cout << "   ** Test Passed **" << endl;
                    }
                }
            }
        }
    }

    // Finalize
    hiperlife::Finalize();
    return 0;
}
