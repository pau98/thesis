
// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_Tensor.h"
#include "hl_TypeDefs.h"
#include "hl_ParamStructure.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_ConsistencyCheck.h"

#include "hl_FillStructure.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"

using namespace hiperlife;

struct Params
{
    enum RealParameters
    {
        deltat,
        kappa,
        mu,
        pullR
    };

    HL_PARAMETER_LIST DefaultValues{
            {"deltat", 1e-2},
            {"kappa", 0.05},
            {"mu", 1.0},
            {"pullR", 0.1},
    };
};

void LS(hiperlife::FillStructure& fillStr)
{
    using namespace hiperlife::Tensor;

    // Get parameters
    const double deltat = fillStr.getRealParameter(Params::deltat);
    const double kappa  = fillStr.getRealParameter(Params::kappa);
    const double mu     = fillStr.getRealParameter(Params::mu);
    const double pullR  = fillStr.getRealParameter(Params::pullR);

    // Rename variables
    SubFillStructure& subFill = fillStr[0];
    int nDOFs = subFill.numDOFs;   // Number of degrees of freedom
    int eNN   = subFill.eNN;       // Number of neighbor nodes
    int nDim  = subFill.nDim;      // Number of parametric dimension
    int pDim  = subFill.pDim;      // Number of parametric dimension
    wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, nDOFs);
    wrapper<double,2> nborDOFs0(subFill.nborDOFs0.data(), eNN, nDOFs);
    wrapper<double,2> nborCoords(subFill.nborCoords.data(), eNN, nDim);
    wrapper<double,4> Ak(fillStr.Ak(0,0).data(), eNN, nDOFs, eNN, nDOFs);
    wrapper<double,2> Bk(fillStr.Bk(0).data(), eNN, nDOFs);

    // Shape functions and derivatives at Gauss points
    wrapper<double,1> bf(subFill.nborBFs(), eNN);
    tensor<double,2> gbf(eNN, pDim);
    double jac;
    GlobalBasisFunctions::gradients(gbf, jac, subFill);
    tensor<double,2>   Id = Identity(pDim);
    tensor<double,3>  bbf = outer(bf, Id);                 // eNN x nDOFs x nDOFs
    tensor<double,4> gbbf = outer(gbf, Id);                // eNN x pDim  x nDOFs x nDOFs

    // Values at integration points
    tensor<double,1> x  = bf*nborCoords;                   // nDim
    tensor<double,1> u  = bf*nborDOFs;                     // nDOFs
    tensor<double,1> u0 = bf*nborDOFs0;                    // nDOFs
    tensor<double,2> gu = product(nborDOFs, gbf, {{0,0}}); // nDOFs x pDim

    // Velocity difference
    tensor<double,1> v  = (u-u0)/deltat;
    tensor<double,1> vs = pullR * x(range(0, pDim-1));
    tensor<double,1> vd = v-vs;

    // Fill linear system: Energy
    double energy = 0.5*kappa*product(gu, gu, {{0,0},{1,1}});
    Bk += jac * kappa*product(gbf,gu,{{1,1}});
    Ak += jac * kappa*product(gbbf, gbbf,{{1,1}, {2,2}});

    // Fill linear system: Dissipation (linear friction)
    double dissipation = deltat*0.5*mu*vd*vd;
    Bk += jac * mu*outer(bf, vd);
    Ak += jac * mu/deltat*product(bbf, bbf, {{2,2}});

    //Save global integral
    fillStr.addToGlobalIntegral("Energy", jac*(energy + dissipation));

    return;
}

int main(int argc, char** argv)
{
    using namespace hiperlife;
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    // Initialize MPI
    hiperlife::Init(argc, argv);

    // Time-related parameters
    double maxDeltat = 1e3;
    int maxSteps     = 500;
    double maxTime   = 1000.0;
    double stepFactor = 0.98;
    int nSave = 1;

    // Model parameters

    // Other
    string solNamePrefix = "Friction";

    // Put parameters in the user structure
    SmartPtr<ParamStructure> paramStr = CreateParamStructure<Params>();

    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Create a line structured mesh
    SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();
    structMesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    structMesh->genStructMesh(30);
    // structMesh->translateX(-0.5);
    // structMesh->translateXY(-0.5, -0.5);

    // Distribute the mesh among all the processors
    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//

    // Create the main DOFsHandler
    SmartPtr<DOFsHandler> dhand = Create<DOFsHandler>(disMesh);
    dhand->setNameTag("dhand");
    dhand->setDOFs({"ux", "uy"});
    dhand->setNodeAuxF({"vx", "vy", "vsx", "vsy"});
    dhand->setElemAuxF({"Energy"});
    dhand->Update();

    // Set boundary and initial conditions for the DOFs
    dhand->setBoundaryCondition("ux", MAxis::Xmin, 0.0);
    dhand->setBoundaryCondition("uy", MAxis::Ymin, 0.0);
    // dhand->setInitialCondition("ux", 0.0);
    // dhand->setInitialCondition("ux", [=](double x, double y){return pullR*x;});
    // dhand->setInitialCondition("uy", [=](double x, double y){return pullR*y;});
    // dhand->setInitialCondition("uy", 0.0);
    dhand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//

    // Main hiperproblem
    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();
    hiperProbl->setParameterStructure(paramStr);
    hiperProbl->setDOFsHandlers({dhand});
    // hiperProbl->setConsistencyDOFs("dhand", {"ux"});
    hiperProbl->setConsistencyDOFs("dhand", {"ux", "uy"});
    hiperProbl->setConsistencyCheckType(ConsistencyCheckType::Hessian, "Energy");
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setElementFillings("Integ", ConsistencyCheck<LS>);
    //hiperProbl->setElementFillings("Integ", LS);
    hiperProbl->setCubatureGauss("Integ", 4);
    hiperProbl->setGlobalIntegrals({"Energy"}, true);
    hiperProbl->Update();


    // **************************************************************//
    // *****                  SOLVER CREATION                   *****//
    // **************************************************************//

    // Linear solver for the main hiperproblem
    SmartPtr<MUMPSDirectLinearSolver> linSolver = Create<MUMPSDirectLinearSolver>();
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // Non-linear solver for the main hiperproblem
    SmartPtr<NewtonRaphsonNonlinearSolver> nonLinSolver = Create<NewtonRaphsonNonlinearSolver>();
    nonLinSolver->setLinearSolver(linSolver);
    nonLinSolver->setConvRelTolerance(true);
    nonLinSolver->setMaxNumIterations(10);
    nonLinSolver->setResTolerance(1e-8);
    nonLinSolver->setSolTolerance(1e-8);
    // nonLinSolver->setLineSearch(true);
    // nonLinSolver->setLineSearchEnergyMethod("Energy");
    // nonlinSolver->setLineSearch_step(0.95);
    // // nonlinSolver->setLineSearch_minDecrease(0.000001);
    nonLinSolver->setResMaximum(1e7);
    nonLinSolver->setSolMaximum(1e7);
    nonLinSolver->setConvRelTolerance(true);
    nonLinSolver->setPrintSummary(false);
    nonLinSolver->setPrintIntermInfo(true);
    nonLinSolver->Update();


    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    // Print initial condition
    dhand->nodeDOFs0->setValue(dhand->nodeDOFs);
    string solName = solNamePrefix + ".0";
    dhand->printFileVtk(solName, true, 0.0);

    // Open file to write global integrals and write headers
    ofstream gIntegFile;
    gIntegFile.open ("globalIntegrals.csv");
    gIntegFile << "TS time deltat";
    for (auto g: hiperProbl->globalIntegralNames())
        gIntegFile << " " << g;
    gIntegFile << endl;

    // Initialize
    double& deltat = paramStr->getRealParameter(Params::deltat);
    double time{deltat};
    int timeStep{1};
    while (timeStep <= maxSteps and time < maxTime)
    {
        // Print info
        if (hiperProbl->myRank() == 0)
            cout << endl << endl << "TS: " << timeStep << " Time " << time  << " of time " << maxTime <<  " with deltat " << deltat << endl;

        // Initial guess
        dhand->nodeDOFs->setValue(dhand->nodeDOFs0);
        hiperProbl->UpdateGhosts();

        // Solve
        bool converged = nonLinSolver->solve();

        // Check convergence
        if (converged)
        {
            // Print results
            if (timeStep%nSave == 0)
            {
                solName = solNamePrefix + "." + to_string(timeStep);
                dhand->printFileVtk(solName, true, time);
            }

            // Save solution
            dhand->nodeDOFs0->setValue(dhand->nodeDOFs);
            dhand->nodeDOFs0->UpdateGhosts();

            // Update time variables
            timeStep++;
            deltat /= stepFactor;
            if (deltat >= maxDeltat)
                deltat = maxDeltat;
            time += deltat;

            // Write time data and global integrals
            if (hiperProbl->myRank() == 0)
            {
                gIntegFile << timeStep << " " << time << " " << deltat;
                for (auto g: hiperProbl->globalIntegrals())
                    gIntegFile  << " " << g;
                gIntegFile << endl;
            }
        }
        else
        {
            if (stepFactor == 1.0)
                break;

            // Correct time-step size
            deltat *= stepFactor;
        }

        // Check steady-state
        if (deltat < 1.e-14)
            break;
    }


    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    //Close file
    gIntegFile.close();

    MPI_Finalize();
    return 0;
}
