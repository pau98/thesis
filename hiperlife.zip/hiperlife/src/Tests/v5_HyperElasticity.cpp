/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <EpetraExt_RowMatrixOut.h>
#include <EpetraExt_MultiVectorOut.h>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_Parser.h"
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include <hl_MultiPatchMeshGenerator.h>
#include "hl_StructMeshGenerator.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include <ad.h>



// Eigen headers
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
using hiperlife::Tensor::tensor;
using Teuchos::RCP;
using namespace hiperlife;


struct HyElParams
{
  enum RealParameters
  {
    force,
    beta,
    mu0,
    lambda0,
    mu1,
    lambda1
  };

  enum IntParameters
  {
    timeStep,
  };

  HL_PARAMETER_LIST DefaultValues
  {
    {"force", 0.0},
    {"beta", 100.0},
    {"timeStep",0},
    {"k0",10.},
    {"k1",0.01},
    {"mu0",1.},
    {"mu1",1.},
    {"lambda0",1.},
    {"lambda1",1.}
  };
};

bool fileExists(const std::string& filename)
{
  struct stat buf;
  if (stat(filename.c_str(), &buf) != -1)
  {
    return true;
  }
  return false;
}

vector<double> bodyForce(double x,double y)
{
  double sx  = sin(M_PI*x);
  double cx = cos(M_PI*x);
  double sy  = sin(M_PI*y);
  double cy = cos(M_PI*y);
  double sxy = sin(M_PI*(x + y));
  double cxy = cos(M_PI*(x + y));
  double J   = 1. + M_PI*sxy/5.;
  double lnJ = log(J);

  double denom = (M_PI*sxy + 5.)*(M_PI*sxy + 5.);
  vector<double> b(2);

  b[0] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sx*cy + 5.)*(lnJ - 1.)*cxy - (M_PI*sx*cy + 5.)*cxy - M_PI*(lnJ - 1.)*sy*cx*cxy + M_PI*sy*cx*cxy) / denom;

  b[1] = M_PI*M_PI* ((2./5.)*(M_PI*sxy + 5.)*(M_PI*sxy + 5.)* sx*sy + (M_PI*sy*cx + 5.)*(lnJ - 1.)*cxy - (M_PI*sy*cx + 5.)*cxy - M_PI*(lnJ - 1.)*sx*cy*cxy + M_PI*sx*cy*cxy) / denom;

  return b;
}

inline void tensorToVoigt(tensor<double,1>& A_v, tensor<double,2> A)
{
  int n = A.shape()[0];
  if (n == 1)
  {
    A_v(0) = A(0,0);
  }
  else if (n == 2)
  {
    A_v(0) = A(0,0);
    A_v(1) = A(1,1);
    A_v(2) = A(0,1);
  }
  else if (n == 3)
  {
    A_v(0) = A(0,0);
    A_v(1) = A(1,1);
    A_v(2) = A(2,2);
    A_v(3) = A(0,1);
    A_v(4) = A(0,2);
    A_v(5) = A(1,2);
  }
  else
  {
    throw runtime_error("tensorToVoigt: working for 1D, 2D and 3D.");
  }
}

inline void tendot4oo(tensor<double,2> bb, tensor<double,2>& aa)
{
  // *************************************************************************
  // a =  b o b (b packed)
  // []_abcd = 0.5*(C^-1_ac*C^-1_bd + C^-1_ad*C^-1_bc)
  // *************************************************************************

  int n = bb.shape()[0];
  if (n == 1)
  {
    aa(0,0) = 0.5*(bb(0,0)*bb(0,0) + bb(0,0)*bb(0,0));
  }
  else if (n == 2)
  {
    tensor<int,2> ks{{0,2}, {2,1}};
    for (int i = 0; i < 2; i++)
      for (int j = 0; j < 2; j++)
        for (int k = 0; k < 2; k++)
          for (int l = 0; l < 2; l++)
            aa(ks(i,j), ks(k,l)) = 0.5*(bb(i,k)*bb(j,l) + bb(i,l)*bb(j,k));
  }
  else if (n == 3)
  {
    tensor<int,2> ks{{0,3,4}, {3,1,5}, {4,5,2}};
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++)
        for (int k = 0; k < 3; k++)
          for (int l = 0; l < 3; l++)
            aa(ks(i,j), ks(k,l)) = 0.5*(bb(i,k)*bb(j,l) + bb(i,l)*bb(j,k));
  }
  else
  {
    throw runtime_error("tensorToVoigt: working for 1D, 2D and 3D.");
  }
}

// Constitutive models
void constitutiveModel_Coupled_NeoHookean(tensor<double,1>& S_v, tensor<double,2>& S, tensor<double,2>& D, double& W, tensor<double,2> F, map<string, double>& params)
{
  using namespace hiperlife::Tensor;

  //***********************************************************
  // [0] Initialize
  //***********************************************************

  // Parameters
  double mu = params.at("mu");
  double lm = params.at("lambda");

  // Dimensions
  int pDim = F.shape()[0];
  int nVoi{0};
  if (pDim == 1)
    nVoi = 1;
  else if (pDim == 2)
    nVoi = 3;
  else if (pDim == 3)
    nVoi = 6;


  //***********************************************************
  // [1] Compute jacobian, right Cauchy def tensor and inverse
  //***********************************************************

  // Jacobian
  double J = F.det();

  // Inverse of the right Cauchy-Green tensor (tensor and voigt notation)
  tensor<double,2> Finv = F.inv();
  tensor<double,2> Cinv = Finv*Finv.T(); //This seems to introduce less error than C.inv()
  tensor<double,1> Cinv_v(nVoi);
  tensorToVoigt(Cinv_v, Cinv);

  // Compute Cinv(x)Cinv => []_abcd=Cinv_ab*Cinv_cd
  tensor<double,2> CinvCinv = outer(Cinv_v, Cinv_v);

  // Compute Cinv(·)Cinv => []_abcd=0.5(Cinv_ac*Cinv_bd+Cinv_ad*Cinv_bc) [Eq. 6.165]
  tensor<double,2> Cinv_Cinv(nVoi,nVoi);
  tendot4oo(Cinv, Cinv_Cinv);


  //***********************************************************
  // [2] Compute 2nd Piola-Kirchhoff stress tensor
  //***********************************************************

  // Energy
  tensor<double,2> C = F.T()*F;
  W = 0.5*lm*log(J)*log(J) - mu*log(J) + 0.5*mu*(trace(C)-pDim);
  // W = 0.5*lm*(J-1.0)*(J-1.0) - mu*log(J) + 0.5*mu*(trace(C)-2.0); // Wiki

  // Stress tensor
  tensor<double,2> Id = Identity(pDim);
  S = mu*Id + (lm*log(J)-mu)*Cinv;
  // S = mu*Id + 2.0*(lm*J*(J-1.0)-mu)*Cinv; // Wiki
  tensorToVoigt(S_v, S);

  //***********************************************************
  // [3] Compute elasticity tensor
  //***********************************************************

  // Elasticity tensor
  D = lm*CinvCinv + 2.0*(mu-lm*log(J))*Cinv_Cinv;
  // D = 4.0*(2.0*lm*J*J-lm*J)*CinvCinv - 4.0*(lm*J*(J-1.0)-mu)*Cinv_Cinv; // Wiki
    
}

void LSV0(hiperlife::FillStructure& fillStr)
{
  using namespace std;
  using namespace hiperlife;
  using hiperlife::Tensor::tensor;
  using namespace ttl;
  using namespace autodiff;
  double mu0 = fillStr.getRealParameter(HyElParams::mu0);
  double ns = fillStr.getIntParameter(HyElParams::timeStep);
  double lm0 = fillStr.getRealParameter(HyElParams::lambda0);
  auto rngCoords = range(0,1);
  auto rngR0 = range(0,1);
  // Parameters
  map<string, double> params{{"mu",  fillStr.getRealParameter(HyElParams::mu0)},
                             {"lambda", fillStr.getRealParameter(HyElParams::lambda0)}};

  double deltat = 1.;

  //----------------------------------------------------------------//
  // ------------------------- INPUT DATA --------------------------//
  //----------------------------------------------------------------//
  
  //--------------------------Velocity-related----------------------//
  // Dimensions
  SubFillStructure& subFill = fillStr[0];
  int pDim = subFill.pDim;        //  pDim = 2
  int eNN  = subFill.eNN;         //  eNN = 9
  int numDOFs = subFill.numDOFs;  //  numDOFs = 3
  
  // Shape functions and derivatives at Gauss points
  double jac{};
  ttl::wrapper<double,2> nborCoords3(subFill.nborCoords.data(), eNN, 3);
  tensor<double,2> nborCoords = nborCoords3(all,rngCoords);
  ttl::wrapper<double,2> nborDOFs(subFill.nborDOFs.data(), eNN, numDOFs);
  ttl::tensor<double,1,false>  bf(subFill.nborBFs(), eNN);
  ttl::tensor<double,2> Dbf_g(eNN,pDim);
  GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

  //----------------------------------------------------------------------------------//
  // ------------------------------- OUTPUT DATA -------------------------------------//
  //----------------------------------------------------------------------------------//


  //-------------------------------- EQUATIONS ---------------------------------------//
  //----------------------------------------------------------------------------------//

  ttl::tensor<double,1> x = bf*nborCoords;
  ttl::tensor<double,1> dofsT = bf*nborDOFs;
  ttl::tensor<double,1> u = {dofsT(0),dofsT(1)};
  double uu = sqrt((-x(1)+0.5)*(-x(1)+0.5)+(x(0)+0.3)*(x(0)+0.3));

  ttl::tensor<double,1> f(2);
  std::vector<double> b = bodyForce(x(0),x(1));
  f(0) = b[0];
  f(1) = b[1];

  tensor<double,2> Id2 = Identity2;
    
  auto rayleighian = [=](std::vector<dual2nd> nborDOFs_vec) -> dual2nd
  {
    //***********************************************************
    // Initialize
    //***********************************************************

    // Rearrange DOFs  // FIXME: I don't think this is the fastest way
    tensor<dual2nd,2> nborDOFsd(eNN, numDOFs);
    for (int i = 0; i < eNN; i++)
    {
      for (int d = 0; d < numDOFs; d++)
      {
        nborDOFsd(i, d) = nborDOFs_vec[i*numDOFs+d];
      }
    }
    tensor<dual2nd,1> dofsd = bf*nborDOFsd;
    tensor<dual2nd,1> u0d = dofsd(rngR0);

    tensor<dual2nd,2> nborx = nborDOFsd(all,rngR0)+nborCoords;
    tensor<dual2nd,2> Fd = product(nborx, Dbf_g, {{0,0}}); // dx/dchi
    dual2nd Jd = Fd.det(); // J = det(Fd)

    // Elastic
    // Right Cauchy-Green tensor and inverse (background)
    tensor<dual2nd,2> Cd = Fd.T()*Fd;
    tensor<dual2nd,2> Fd_i = Fd.inv();
    tensor<dual2nd,2> Cd_i = Fd_i*Fd_i.T();

    // Energy and 2nd Piola-Kirchhoff stress tensor (background)
    dual2nd W = 0.5*lm0*log(Jd)*log(Jd) - mu0*log(Jd) + 0.5*mu0*(trace(Cd)-pDim);
    dual2nd ray = jac*W-jac*f*u0d;
    return(ray);
  };

  
  // Compute nborDOFs as dual2nd type
  std::vector<dual2nd> dofs(eNN*numDOFs);
  for (int i = 0; i < eNN*numDOFs; i++)
  {
    dofs.at(i) = subFill.nborDOFs.at(i);
  }

  // Compute rayleighian, jacobian, and hessian
  dual2nd ray;
  std::vector<double> Jac(eNN*numDOFs);
  std::vector<double> Hes((eNN*numDOFs)*(eNN*numDOFs));
  hessian(rayleighian, wrt(dofs), at(dofs), ray, Jac, Hes);

  // Rearrange into Bk and Ak
  int n0 = eNN*numDOFs;
  for (int i = 0; i < n0; i++)
  {
    fillStr.Bk(0).at(i) = Jac[i];
  }

  for (int i = 0; i < n0; i++)
  {
    for (int j = 0; j < n0; j++)
    {
      fillStr.Ak(0,0).at(i*n0+j) = Hes[i*n0+j];
    }
  }
  
  ttl::wrapper<double,2> Bkt(fillStr.Bk(0).data(), eNN,   numDOFs);     // 9 * 2
  
  ttl::wrapper<double,4> Akt(fillStr.Ak(0,0).data(), eNN,   numDOFs,   eNN,   numDOFs);      // 9 * 2 * 9 * 2

  // Coordinates
  auto rng = range(0,1);

  // Deformation gradient G = dx/dchi (from chi to x)
  tensor<double,2> F = product(nborDOFs(all,rng), Dbf_g, {{0,0}})+Identity2;
  
  // Constitutive model
  double W{};
  int nVoi = 3;
  tensor<double, 1> S_v(nVoi);
  tensor<double, 2> S(pDim, pDim), C_v(nVoi, nVoi);
  constitutiveModel_Coupled_NeoHookean(S_v, S, C_v, W, F, params);

  // B0 tensor
  tensor<double,3> B0(nVoi, eNN, pDim);
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
      B0(i,a,all) = F(all,i)*Dbf_g(a,i);
  }
  if (pDim == 2)
  {
    for (int a = 0; a < eNN; a++)
      B0(2,a,all) = F(all,1)*Dbf_g(a,0) + F(all,0)*Dbf_g(a,1);
  }


  // if(ns == 4 & fabs(F.det()-1.)>1e-10)
  //   cout << F.det() << " " << x << endl;

  // Geometric stiffness matrix
  tensor<double, 2> kg(eNN, eNN);
  kg = Dbf_g*(S*Dbf_g.T());

  // Geometric stiffness tensor
  tensor<double,2> Id = Identity(pDim);
  tensor<double,4> Kgeo(eNN, pDim, eNN, pDim);
  tensor<double,4> Kgeo2(eNN, pDim, eNN, pDim);
  for (int i = 0; i < eNN; i++)
  {
    for (int j = 0; j < eNN; j++)
      Kgeo2(i,all,j,all) = kg(i,j)*Id;
  }
  for (int a = 0; a < eNN; a++)
  {
    for (int i = 0; i < pDim; i++)
    {
      for (int b = 0; b < eNN; b++)
      {
        for (int j = 0; j < pDim; j++)
        {
          if (i == j)
            Kgeo(b,j,a,i) = kg(a,b);
          else
            Kgeo(b,j,a,i) = 0.;
        }
      }
    }
  }

  //***********************************************************
  // Fill linear system
  //***********************************************************
  
  tensor<double,4> Kmat = jac*product(B0,C_v,{{0,0}})*B0;

  // Internal stresses
  tensor<double,2> Bk0(eNN,numDOFs);
  tensor<double,4> Ak0(eNN,numDOFs,eNN,numDOFs);

  Bk0 *=0;
  Ak0 *=0;
  double dEner = jac*W;
  Bk0(all,rng) += jac*(S_v*B0);
  Ak0(all,rng,all,rng) += jac*(B0.transpose({1,2,0})*C_v*B0 + Kgeo);

  // for (int a = 0; a<eNN; a++)
  //   for (int i = 0; i<numDOFs; i++)
  //   {
  //     if (fabs(Bk0(a,i)-Bkt(a,i)) > 1e-10)
  //       cout << "B error("<<a<<","<<i<<"): "<< fabs(Bk0(a,i)-Bkt(a,i))<< " " <<Bk0(a,i)<< " " << Bkt(a,i) << endl;
  //     for (int b = 0; b<eNN; b++)
  //       for (int j = 0; j<numDOFs; j++)
  //       {
  //         if (fabs(Ak0(a,i,b,j)-Akt(a,i,b,j)) > 1e-8)
  //           cout << "A error("<<a<<","<<i<<","<<b<<","<<j<<"): "<<fabs(Ak0(a,i,b,j)-Akt(a,i,b,j))<<" "<< Ak0(a,i,b,j) << " "<<Akt(a,i,b,j) <<endl;
  //       }
  
  //   }
      
  // Output integration points
  ofstream myfile;
  if (!fileExists("Cut.csv"))
  {
    myfile.open("Cut.csv", std::ios_base::app);
    myfile << "x(0)" << "," << "x(1)" << "," << "jac" << endl;
    myfile.close();
  }
  myfile.open("Cut.csv", std::ios_base::app);
  myfile << std::setprecision(16) << x(0) << "," << x(1) << "," << jac << endl;
  myfile.close();
  fillStr.addToGlobalIntegral("Ray", static_cast<double>(ray));

}

void CheckSolution0(hiperlife::FillStructure& fillStr)
{
  using namespace hiperlife;
  using ttl::tensor, ttl::wrapper;
  using ttl::index::N, ttl::index::i;

  SubFillStructure &subFill = fillStr[0];
  int nDim = subFill.nDim;
  int pDim = subFill.pDim;
  int eNN = subFill.eNN;
  int DOFs = subFill.numDOFs;

  tensor<double, 2> Dbf(eNN, pDim);
  double jac;
  GlobalBasisFunctions::gradients(Dbf, jac, subFill);

  wrapper<double, 2> dofsI(subFill.nborDOFs.data(), eNN,DOFs);
  wrapper<double, 2> coordsI(subFill.nborCoords.data(), eNN, nDim);
  wrapper<double, 1> bf(subFill.nborBFs(), eNN);
  tensor<double, 1> x(nDim);
  x = coordsI(N, i) * bf(N);

  const double u_numeric = dofsI(N,0) * bf(N);
  const double u_analytial = sin(M_PI*x(0))*cos(M_PI*x(1));//(x(0)-0.5)*(x(0)-0.5)+(x(1)-0.5)*(x(1)-0.5);
  const double error = jac * abs(u_numeric-u_analytial);
  fillStr.addToGlobalIntegral("error", error);
}

// *******************************************************************//
// *******************************************************************//
// *******************************************************************//
// *****                      MAIN FUNCTION                      *****//
// *******************************************************************//
// *******************************************************************//
// *******************************************************************//

int main(int argc, char** argv)
{

  hiperlife::Init(argc, argv);

  //============================ Parameters ============================//
  int nx = 100;
  int ny = nx;
  vector<int> nxt = {8, 16, 32, 64, 128};

  SmartPtr<ParamStructure> paramStr = CreateParamStructure<HyElParams>();
  // userStr->dparam.resize(1);
  double beta = 100*nx; // beta = 100*h (from 2017Badia)
  paramStr->setRealParameter(HyElParams::beta,beta);



  // *******************************************************************//
  // *****                      MESH CREATION                      *****//
  // *******************************************************************//
  int nSteps = nxt.size();
  int bfOrder = 2;
  int timeStep = 0;
  bool ghP = 0;
  double wellPosedTh = 0.5;
  if(ghP)
  {
    wellPosedTh = 0.;
  }
  for (int nS{}; nS < nSteps; nS++)
  {
    paramStr->setIntParameter(HyElParams::timeStep,nS);
    //-------------------------- Background mesh -------------------------//
    double beta = 100.*nxt[nS]; // beta = 100/h (from 2017Badia)
    paramStr->setRealParameter(HyElParams::beta,beta);

    // Mesh generator
    SmartPtr<StructMeshGenerator> back = Create<StructMeshGenerator>();
    back->setMesh(ElemType::Square, BasisFuncType::Lagrangian, bfOrder);
    back->genStructMesh(nxt[nS], nxt[nS]);
    // Mesh refinement
    double c0 = 0.5;
    double r0 = 0.3;
    double eps = 0.0001;        

    // Distributed mesh
    SmartPtr<DistributedMesh> backMesh = Create<DistributedMesh>("backMesh");
    backMesh->setMesh(back);
    backMesh->setBalanceMesh(true);
    backMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    backMesh->setVerbosity(Verbosity::None);
    backMesh->Update();


    // Print meshes
    backMesh->printFileLegacyVtk("meshBack");


    // *******************************************************************//
    // *****                   DOFsHandler CREATION                  *****//
    // *******************************************************************//

    //----------------------- Background DOFsHandler ---------------------//
    SmartPtr<DOFsHandler> backDHand = Create<DOFsHandler>(backMesh);
    backDHand->setNameTag("backDHand");
    backDHand->setDOFs({"ux0","uy0"});
    backDHand->setNodeAuxF({"const","ctag","stab"});
    backDHand->setElemAuxF({"tag","WI","Agg0","gmm0","l0","GhP0","Agg1","gmm1","l1","GhP1","lE","stbP"});
    backDHand->Update();

    backDHand->UpdateGhosts();
    
    // Set boundary conditions
    for (int i{}; i < backMesh->nPts(); i++)
    {
      std::vector<double> x = backMesh->nodeCoords(i,IndexType::Global);
      backDHand->nodeDOFs->setValue(0,i,IndexType::Local, 0.2*sin(M_PI*x[0])*sin(M_PI*x[1]));
      backDHand->nodeDOFs->setValue(1,i,IndexType::Local, 0.2*sin(M_PI*x[0])*sin(M_PI*x[1]));
      // if (backMesh->nodeCrease(i,IndexType::Global) > 0)
      {
        if (x[0]>0.9999 || x[0]<0.001 || x[1]>0.9999 || x[1]<0.001)
        {
          {
            backDHand->setConstraint(0,i,IndexType::Global,0.);
            backDHand->nodeDOFs->setValue(0,i,IndexType::Global,0.);

            backDHand->setConstraint(1,i,IndexType::Global,0.);
            backDHand->nodeDOFs->setValue(1,i,IndexType::Global,0.);
          }
        }
        // if (x[1]>0.999)
        // {
        //   backDHand->nodeDOFs->setValue(1,i,IndexType::Global,0.02);
        //   backDHand->setConstraint(1,i,IndexType::Global,0.);
        // }

        
        // if (x[1]<0.001)
        // {
        //   backDHand->nodeDOFs->setValue(1,i,IndexType::Global,0.);
        //   backDHand->setConstraint(1,i,IndexType::Global,0.);
        // }
      }
    }

    backDHand->printFileLegacyVtk("dofBack", true);

    // *******************************************************************//
    // *****                    IMMERSED PROBLEM                     *****//
    // *******************************************************************//
    if (true)
    {
      // Immersed HiPerProblem
      SmartPtr<HiPerProblem> immHP = Create<HiPerProblem>();
      //General setters
      immHP->setParameterStructure(paramStr);
      immHP->setGlobalIntegrals({"Area","Length","uError","duError","total_edge_length","Ray"});
      immHP->setDOFsHandlers({backDHand});

      // Set integration for Region 0
      immHP->setIntegration("IntegCavityV0", {"backDHand"});
      immHP->setCubatureGauss("IntegCavityV0", 9);
      immHP->setElementFillings("IntegCavityV0", LSV0);
      
      immHP->Update();
      cout << "HP done "<< endl;
      //-------------------------- Immersed solver -------------------------//
      SmartPtr<MUMPSDirectLinearSolver> immSOL = Create<MUMPSDirectLinearSolver>();
      immSOL->setHiPerProblem(immHP);
      immSOL->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
      immSOL->setDefaultParameters();
      // immSOL->setWorkSpaceMemoryIncrease(200);
      immSOL->Update();

      //------------------ Non-linear solver creation ------------------//

      SmartPtr<NewtonRaphsonNonlinearSolver> nonLinSolver = Create<NewtonRaphsonNonlinearSolver>();
      nonLinSolver->setLinearSolver(immSOL);
      nonLinSolver->setConvRelTolerance(true);
      nonLinSolver->setMaxNumIterations(50);
      nonLinSolver->setResTolerance(1e-6);
      nonLinSolver->setSolTolerance(1e-8);
      nonLinSolver->setResMaximum(1e5);
      nonLinSolver->setSolMaximum(1e5);
      nonLinSolver->setExitRelMaximum(true);
      nonLinSolver->setLineSearch(false);
      // nonLinSolver->setLineSearchEnergyMethod("Ray");
      nonLinSolver->setPrintSummary(false);
      nonLinSolver->setPrintIntermInfo(true);
      nonLinSolver->Update();

      //---------------------------- Solve immersed ------------------------//
      // Solve

              bool converged = nonLinSolver->solve();

      // for (int nt = 0; nt < 5; nt++)
      // {
      //   // Set boundary conditions
      //   for (int i{}; i < backMesh->nPts(); i++)
      //   {
      //     std::vector<double> x = backMesh->nodeCoords(i,IndexType::Global);
      //     // if (backMesh->nodeCrease(i,IndexType::Global) > 0)
      //     {
      //       if (x[0]>0.9999 || x[0]<0.001 || x[1]>0.9999 || x[1]<0.001)
      //       {
      //         {
      //           backDHand->setConstraint(0,i,IndexType::Global,0.);
      //           backDHand->nodeDOFs->setValue(0,i,IndexType::Global,0.);

      //           // backDHand->setConstraint(1,i,IndexType::Global,0.);
      //           // backDHand->nodeDOFs->setValue(1,i,IndexType::Global,0.);
      //         }
      //       }
      //       if (x[1]>0.999)
      //       {
      //         backDHand->nodeDOFs->setValue(1,i,IndexType::Global,0.02*(nt+1));
      //         backDHand->setConstraint(1,i,IndexType::Global,0.);
      //       }

            
      //       if (x[1]<0.001)
      //       {
      //         backDHand->nodeDOFs->setValue(1,i,IndexType::Global,0.);
      //         backDHand->setConstraint(1,i,IndexType::Global,0.);
      //       }
      //     }
      //   }

      //   // immHP->FillLinearSystem();
      //   bool converged = nonLinSolver->solve();
      // }
      immHP->UpdateGhosts();


      string meshName = to_string(nS);

                  
      // Print
      string solName = "solBack."+to_string(nS);
      backDHand->printFileLegacyVtk(solName, true);
      
      SmartPtr<HiPerProblem> checkSolution = Create<HiPerProblem>();
      checkSolution->setDOFsHandlers({backDHand});
      checkSolution->setParameterStructure(paramStr);

      // Set integration for the background mesh
      checkSolution->setIntegration("Integ0", {"backDHand"});
      checkSolution->setCubatureGauss("Integ0", 9);
      checkSolution->setElementFillings("Integ0", CheckSolution0);

      checkSolution->setGlobalIntegrals({"error","uErr","duErr"});
      checkSolution->Update();

      checkSolution->FillLinearSystem();
      double error = checkSolution->globalIntegral("error");
      std::cout << "error: " << error << std::endl;
      double Uerror = checkSolution->globalIntegral("uErr");
      std::cout << "U border error: " << sqrt(Uerror) << std::endl;
      double dUerror = checkSolution->globalIntegral("duErr");
      std::cout << "dU*n border error: " << sqrt(dUerror) << std::endl;

    }
  }

  hiperlife::Finalize();
  return 0;
}