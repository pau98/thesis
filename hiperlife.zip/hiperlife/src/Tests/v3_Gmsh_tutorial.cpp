/*
 **************************************************************************************************
    hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Copyright (c) 2018 Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
 **************************************************************************************************
    hiperlife is under GNU General Public License ("GPL").
    GNU General Public License ("GPL") copyright permissions statement:
    This file is part of hiperlife, hiperlife is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by the Free Software Foundation,
    either version 3 of the License, or (at your option) any later version.
    hiperlife is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along with this program.
    If not, see <http://www.gnu.org/licenses/>.
 **************************************************************************************************
 */


////////////////////////////////////////////////////////////////////////
///                                                                  ///
///                       ###     ###   ######                       ///
///                       ###     ###   ######                       ///
///                       ###     ###   ######                       ///
///                       ###########   ######                       ///
///                       ###########   ######                       ///
///                       ###     ###   ######                       ///
///                       ###     ###                                ///
///                       ###     ###                                ///
///                                                                  ///
///                        hiperlife Tutorials                       ///
///                                                                  ///
////////////////////////////////////////////////////////////////////////
///                                                                  ///
/// The aim of this tutorial is to show the basic structure of       ///
///   hiperlife by solving Poisson's equation:                       ///
///   Δu = f                                                         ///
///                                                                  ///
////////////////////////////////////////////////////////////////////////



/// C++ headers

#include <vector>


#include <iostream>        // C++ header that defines the standard
// input/output stream objects
#include <mpi.h>           // C++ header that defines MPI objects

/// Trilinos headers
#include <Teuchos_RCP.hpp> // Trilinos header that defines RCP objects
//   (Smart reference counting pointer class
//   for automatic garbage collection)

/// hiperlife headers
#include "hl_TypeDefs.h"        // hiperlife header that defines
//   different data types used
//   throughout the library
#include "hl_Geometry.h"        // hiperlife header that defines
#include "hl_SurfLagrParam.h"
//   auxiliary geometric-related

#include "hl_StructMeshGenerator.h"

#include "hl_DistributedMesh.h" // hiperlife header that defines
//   distributed mesh objects
#include "hl_FillStructure.h"   // hiperlife header that defines
//   objects to fill the matrix and
//   vector of the problem
#include "hl_DOFsHandler.h"       // hiperlife header that defines
//   DOFHandler objects
#include "hl_HiPerProblem.h"  // hiperlife header that defines
#include "hl_UnstructGmshMeshGenerator.h"



#include <gmsh.h>



using namespace std;


namespace factory = gmsh::model::geo;



/// Function that fills the elemental linear system of the problem. It
///   is declared here but implemented at the bottom.
void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr);


/// Different geometries to be meshed, created by the user
void createRectangle();
void createCircle();
void createPlate();



/// In this first tutorial everything is implemented inside the main
///   function
int main()
{
    using namespace std;
    using Teuchos::rcp;
    using Teuchos::RCP;
    using namespace hiperlife;


    //namespace Gmsh=hiperlife::DistributedClass::MeshCreator::UnstructGmshMeshGenerator;

    /// The code is structured following this pattern:
    ///
    ///   Basis                          Boundary conditions+--+
    /// functions+--+                                          |
    ///             |                                          |
    ///     +-------v-------+    +-----------------+    +------v-----+
    ///     |               |    |                 |    |            |
    ///     |  MeshCreator  +----> DistributedMesh +---> DOFsHandler |
    ///     |               |    |                 |    |            |
    ///     +---------------+    +-----------------+    +------+-----+
    ///                                                        |
    ///                                                        |
    ///                                                        |
    ///               Cubature+                        +-------v------+
    ///                       +---->Integration+       |              |
    ///      Elemental filling+                |       |              |
    ///                                        +-------> HiPerProblem |
    ///                                        |       |              |
    ///                                  Solver+       |              |
    ///                                                +-------+------+
    ///                                                        |
    ///                                                        |
    ///                                                   +----v----+
    ///                                                   |  SOLVE  |
    ///                                                   +---------+
    ///

    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//

    /// In this first part of the code we initialize several objects
    ///   and/or variables that will be used later on in the code. In
    ///   our case we initialize the MPI and the parameters of the
    ///   model. Note that the MPI code *MUST* be initialized here at
    ///   the beginning. Other objects/variables like the parameters of
    ///   the model could be initialized later on.


    ///=========== Initialize the MPI execution environment ==========///
    ///
    /// This function has two input parameters which we do not need,
    ///   so we pass null pointers (nullptr)
    MPI_Init(nullptr, nullptr);
    /// Note that MPI MUST be initialized before calling any other
    ///   object, so a good practice is to always do it at the beginning
    ///   of the main function.


    ///=============== Define parameters of the model ===============///
    ///
    /// Save the parameters into double data type variables
    double force = 1.0;     // Forcing
    ///
    /// Now we create a new hiperlife object called UserStructure. This
    ///   is a container of user-defined parameters that can be easily
    ///   accessed at different points of the code (eg. when filling the
    ///   elemental matrix or vector)
    ///
    /// The creation of an UserStructure object is as follows (note that
    ///   the creation of every object of hiperlife follows the same
    ///   structure)
    ///
    ///               Name of the
    ///                 object
    ///                    |
    ///  Pointer to data   |          Pointer to new
    /// type UserStructure |       UserStructure object
    ///______|_______    __|__     __________|________
    RCP<UserStructure> userStr = rcp(new UserStructure);
    ///\      |                    |   \       \
	/// \     |                    |    \       \-> Object of type
    ///  \  Object                 |     \          UserStructure
    ///   \  type               Pointer   \
	///    \                               \-> Operator new
    ///     \-> Pointer to
    ///         object
    ///
    /// This UserStructure allows a number of data types such as doubles
    ///   or integers (see documentation for available data types). Any
    ///   user variable can be stored into predefined vectors. In this
    ///   case we want to store one double so we resize the
    ///   UserStructure vector "dparam" (d stands for double here) to
    ///   one,
    userStr->dparam.resize(1);
    ///   and then we store our parameter into the first component of
    ///   the vector.
    userStr->dparam[0] = force;
    /// Note that we are using the arrow operator from c++ (->) to
    ///   access individual members of the object. In this case we are
    ///   accessing member "dparam" from the UserStructure "userStr".
    ///
    /// Our userStr object will be later given to the HiPerProblem
    ///   object (the object that handles all the problem; see below).


    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//

    /// Next, we create a mesh for our computational domain. This
    ///   process has two steps: mesh generation and mesh
    ///   distribution. In the first step we generate a mesh either in
    ///   serial or in parallel, depending on the chosen method. In the
    ///   second one we generate all the structures related to the mesh
    ///   and distribute them among the processors.

    ///====================== Mesh generation ======================///
    ///
    /// Currently, hiperlife can generate a mesh in three different
    ///   ways: loading a vtk file, using GMSH or using
    ///   HiPerLiFe own libraries for structured meshes. In this
    ///   tutorial we will show how to use GMSH inside HiPerLiFe.
    ///   The first step is to declare a new "UnstructGmshMeshGenerator"
    ///    object which we name "Gmsh".



    RCP<UnstructGmshMeshGenerator> Gmsh = rcp(new UnstructGmshMeshGenerator);

    Gmsh->setBasisFuncType(BasisFuncType::SubdivSurfs);

    Gmsh->setBasisFuncOrder(2);

    Gmsh->setElemType(ElemType::Triang);



    /// **************************************************************//
    /// *****          PRE-DEFINED GENERATORS                    *****//
    /// **************************************************************//


    //Gmsh->genSquare(1,0.1);

    //Gmsh->genRegularPoly(6,1,0.1);

     Gmsh->genCircle(1,0.1);

     // Gmsh->genSphereTri(1,0.1);



    /// **************************************************************//
    /// *****          USER DEFINED GENERATORS                   *****//
    /// **************************************************************//


   // Gmsh->genFreeOnePatchMesh(createRectangle);

    //  Gmsh->genFreeOnePatchMesh(createCircle);

     //  Gmsh->genFreeOnePatchMesh(createPlate);


    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);



    disMesh->setMesh(Gmsh);



    disMesh->setBalanceMesh(true);




    disMesh->Update();





    /// **************************************************************//
    /// *****               DOFsHANDLER CREATION                 *****//
    /// **************************************************************//

    /// Now, we create a class that contains our distributed mesh and
    ///   includes the degrees of freedom and auxiliary variables. We
    ///   also set the boundary conditions of our problem.

    ///===========           Create DOFHandler            ===========///
    ///
    /// The object is created using the regular procedure, but now we
    ///   construct it with the distributed mesh "disMesh":
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    /// Then, we set a name for the DOFHandler ("dofHand"), which will
    ///   be useful later in the code,
    dofHand->setNameTag("dofHand");
    ///   and we set the number of degrees of freedom (fields of
    ///   unknowns). In our case, as we are solving a scalar PDE, this
    ///   number is one.
    dofHand->setNumDOFs(1);
    /// Finally, we update the object (recall that the actual
    ///   computation is performed through this instruction).
    dofHand->Update();
    /// Note that a DOFHandler can contain several degrees of freedom,
    ///   as in a reaction diffusion system. Also, we can have several
    ///   DOFHandlers for the same problem, for instance in Stokes flow
    ///   we need one DOFHandler with two degrees of freedom for the
    ///   velocities and another one with just on degree of freedom for
    ///   the pressure, each one of them with a different mesh (see
    ///   tutorial).

    ///===========          Boundary conditions          ===========///
    ///
    /// Boundary conditions can be added in a number of different ways
    ///   in hiperlife. Here, we are going to use the function
    ///   setBoundaryCondition in three different ways. Other ways of
    ///   imposing BC are shown in other tutorials.

    /// First, we are going to initialize all boundary condition to
    ///   zero. To do this, we can use setBoundaryCondition with two
    ///   arguments: the number of degree of freedom to which we are a
    ///   applying the condition (in this case we only have one) and the
    ///   value at the boundary:
//    dofHand->setBoundaryCondition(0, 0.0);

   dofHand->setBoundaryCondition(0, 1.0);



   // if ( dofHand->myRank() == 0)
          //dofHand->setConstraint(0,0,IndexType::Local,1.0);




    /// Then, we are going to fix the value at the right-hand side of
    ///   our domain to one. This may be achieved using the same
    ///   function, but this time with three arguments: the number of
    ///   degree of freedom, the edge and the value. To specify the edge
    ///   we use the enum class MAxis. In our case, as we want to impose
    ///   the BC at those nodes whose x coordinate is maximum we use
    ///   Xmax:
//    dofHand->setBoundaryCondition(0, MAxis::Xmax, 1.0);
    /// A third way of imposing boundary conditions with the same
    ///   function is through lambda functions. In this case we have
    ///   three arguments which are the number of degree of freedom, the
    ///   edge and the lambda function, respectively. To show how it
    ///   works we are going to impose a linear and a quadratic boundary
    ///   condition from zero to one on the bottom and top edges
    ///   respectively.
//    dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x){return x;});
//    dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});

    /// Finally, after changing the information at the nodes, we need to
    ///   update the ghost nodes so that all the neighbor processors now
    ///   the changes. This is done with the function:
    dofHand->UpdateGhosts();



    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//

    /// The last object we are going to create is the HiPerProblem
    ///   object. It contains the UserStructure and the DOFHandlers (in
    ///   the present case just one) and includes, among other things,
    ///   the integration rules and structures for every DOFHandler and
    ///   the solver.
    ///
    /// We initialize the object and name it "hiperProbl", give it the
    ///   UserStructure and the DOFHandler. Note that the last one is
    ///   given as a vector of one component, as this function can
    ///   receive several DOFHandlers
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStruct(userStr);
    hiperProbl->setDOFsHandlers({dofHand});

    ///===========            Set integration             ===========///
    ///
    /// The next step is to set the integrations. This includes setting
    ///   the type of integration, the cubature and the elemental
    ///   matrices and vectors for each integration (only one
    ///   integration in our case).
    /// In short, in hiperlife setting the integration type means to
    ///   establish the relation between different DOFHandlers. For
    ///   instance, one DOFHandler may be a "Master" and a second one
    ///   its Lagrange multiplier. Their use is shown in other
    ///   tutorials. Here, as we only have one DOFHandler its
    ///   integration type can only be "Master". We set it through the
    ///   function setIntegration, which has three arguments: a name for
    ///   the integration (useful when there are more than one), a
    ///   vector of DOFHandlers (one in our case) and the integration
    ///   type (Master).
    hiperProbl->setIntegration("Integ", {"dofHand"}, {IntegType::Master});
    /// Then we set the type of cubature through the function
    ///   setIntegration_CubatureStd. Again, it takes three arguments:
    ///   the name of the integration, the name of the cubature and the
    ///   number of integration points per element. Here, we use a
    ///   Gaussian cubature. We refer the user to the documentation for
    ///   other cubature types.
    hiperProbl->setIntegration_CubatureStd("Integ", "CubatureGauss", 12);
    /// The last set of the integration is to specify the name of the
    ///   function(s) for the elemental filling of the matrices and
    ///   vectors. This is performed through the function
    ///   setIntegration_ElemFillings which takes two arguments: the
    ///   name of the integration and the name of a function that fills
    ///   both the matrix and the vector of the linear problem (LS in
    ///   this case)
    hiperProbl->setIntegration_ElemFillings("Integ", LS);
    /// Note that the filling of the linear system can be also given
    ///   through two separate functions, the matrix and the right-hand
    ///   side vector. In this case the same function may be used with a
    ///   null pointer in the second argument and two extra arguments
    ///   with the function names, eg:
    ///   setIntegration_ElemFillings("Integ", nullptr, M, RHS);

    ///===========               Set solver               ===========///
    ///
    /// Currently, hiperlife works with all linear and non-linear
    ///   solvers of Trilinos. A number of them can be set directly in
    ///   the HiPerProblem, while the remaining can be easily included
    ///   indirectly (as shown in other tutorials). In this case we are
    ///   going to use AztecOO's linear solvers, which we set through
    ///   the following instruction:
    hiperProbl->setSolver(PDEType::Linear, LinSolverType::AztecOO);
    /// Then, we can set the preconditioner (Jacobi), the solver
    ///   (conjugate gradients), the tolerance (1^-8), the maximum
    ///   number of iterations (5000) and how much output we want to see
    ///   (all). Other options can also be set (see documentation).
    hiperProbl->setSolverOptions({{"precond", "ls"}});
    hiperProbl->setSolverOptions({{"solver", "cg"}});
    hiperProbl->setSolverOptions({{"tol", "1e-8"}});
    hiperProbl->setSolverOptions({{"max_iter", "5000"}});
    hiperProbl->setSolverOptions({{"output", "all"}});

    ///===========                 Update                ===========///
    ///
    /// The final step is to update the HiPerProblem
    hiperProbl->Update();



    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//

    /// Now that we have set and update all the classes we can solve the
    ///   HiPerProblem. But first, we have to fill the linear system,
    ///   that is, construct the matrix and right-hand side vector:
    hiperProbl->FillLinearSystem();
    ///
    /// The actual solving is performed trough the function solve as
    ///   follows:
    auto status = hiperProbl->Solve();
    ///
    /// Note that the solver returns a set of variables, which we stored
    ///   in "status". They contain information about the solver, which
    ///   we can output to the terminal.
    cout << status << endl;

    /// Finally, we can update the values of the nodes through the
    ///   instruction:
    hiperProbl->UpdateSolution();

    /// The results can be printed to a file either in HiPerLiFe's own
    ///   format
    dofHand->printFile("Poisson");
    /// or/and as vtk
    dofHand->printFileLegacyVtk("Poisson");
    /// for visualization purposes.


    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}



/// **************************************************************//
/// *****     USER DEFINED FUNCTIONS FOR MESH GENERATION     *****//
/// **************************************************************//



void createRectangle()
{

    double lc = 1e-1;

    double a = 2;
    double b = 1;


    //First the points are defined, with a relative mesh size
    factory::addPoint(0, 0, 0, lc/10, 1);
    factory::addPoint(a, 0,  0, lc, 2);
    factory::addPoint(a, b, 0, lc, 3);
    factory::addPoint(0,  b, 0, lc, 4);

    // The API to create lines with the built-in kernel follows the same
    // conventions: the first 2 arguments are point tags, the last (optional one)
    // is the line tag.
    factory::addLine(1, 2, 1);
    factory::addLine(3, 2, 2);
    factory::addLine(3, 4, 3);
    factory::addLine(4, 1, 4);

    // The philosophy to construct curve loops and surfaces is similar: the first
    // argument is now a vector of integers.
    factory::addCurveLoop({4, 1, -2, 3}, 1);
    factory::addPlaneSurface({1}, 1);


}



void createCircle()
{

    //the generation of a circle follows the same philosophy of the rectangle
    double r = 1;
    double lc = 1e-1;

    factory::addPoint(-r, 0, 0, lc, 1);

    factory::addPoint(0, -r, 0, lc, 2);
    factory::addPoint(r, 0, 0, lc, 3);
    factory::addPoint(0, r, 0, lc, 4);
    factory::addPoint(0, 0, 0, lc, 5);

    factory::addCircleArc(1, 5, 2, 1);
    factory::addCircleArc(2, 5, 3, 2);
    factory::addCircleArc(3, 5, 4, 3);
    factory::addCircleArc(4, 5, 1, 4);

    factory::addCurveLoop({1,2,3,4}, 1);

    factory::addPlaneSurface({1}, 1);


}

void createPlate()
{

    //This function generates a quarter of a plate with a hole defined by an ellipsoidal arc

    double lc = 1e-1;


    factory::addPoint(0, 0, 0, lc, 1);
    factory::addPoint(0,0.1, 0, lc/10, 2);
    factory::addPoint(0, 1, 0, lc, 3);
    factory::addPoint(1, 1, 0, lc, 4);
    factory::addPoint(1, 0, 0, lc, 5);
    factory::addPoint(0.3, 0, 0, lc/10, 6);

    factory:: addLine(2, 3, 1);
    factory:: addLine(3, 4, 2);
    factory:: addLine(4, 5, 3);
    factory:: addLine(5, 6, 4);

    factory::addEllipseArc(6,1,2,2,5);


    //Be careful to define the boundary in a counterclockwise order
    //factory::addCurveLoop({1,2,3,4,5}, 1); !!!Wrong!!!
    factory::addCurveLoop({-5,-4,-3,-2,-1}, 1);

    factory::addPlaneSurface({1}, 1);

}






void LS(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;


    SubFillStructure& subFill = (*fillStr)["dofHand"];
    /// which we use to declare the variables:
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& nborCoords  = subFill.nborCoords;  // Vector of node coordinates
    double* bf  = subFill.getDer(0);  // Local shape function
    double* dbf_l = subFill.getDer(1); // Local shape function derivatives


    double x[3]={}; //Position in Euclidean space of the Gauss point
    for (int i = 0; i < eNN; i++)
    {
        for ( int n = 0; n < nDim; n++ )
        {
            x[n] += nborCoords[i*nDim+n] * bf[i];
        }
    }

    double g_cc[4]={};  //Metric tensor (covariant components cc)
    double xu[3]={};    //Tangent vector 1
    double xv[3]={};    //Tangent vector 2
    SurfLagrParam::MetricTensor(g_cc, xu, xv, eNN, nborCoords.data(),dbf_l);

    double g_CC[4]={};  //Inverse of the metric tensor (contravariant components)
    Math::Invert2x2(g_CC, g_cc); //Compute the inverse

    double jac = sqrt(Math::DetMat2x2(g_cc)); //Calculate the jacobian



    double strength = fillStr->userStr->dparam[0];

  // double source = strength * x[1]*cos(3.0*M_PI*x[0]); //Generate a source

    double source = strength * exp(-(x[0]*x[0]+x[1]*x[1])/0.1); //Generate a source

    ///=====================  Fill linear system =====================///
    ///
    /// We loop through the neighboring nodes to fill both the matrix
    ///   and the right-hand side at the same time
    for (int i = 0; i < eNN; i++)
    {
        double* dbf_lI_c = &dbf_l[pDim*i]; //Pointer to the local gradients of the basis functions of node I

        double dbf_lI_C[2]={}; //Compute g^{ab} dbf_lI_c_b
        Math::MatProduct(dbf_lI_C, 2, 2, 1, g_CC, dbf_lI_c);

        for (int j = 0; j < eNN; j++)
        {
            double* dbf_lJ_c = &dbf_l[pDim*j]; //Pointer to the local gradients of the basis functions of node I

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * Math::Dot2D(dbf_lI_C, dbf_lJ_c);
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * bf[i] * source; //Add source
    }

    return;
}
