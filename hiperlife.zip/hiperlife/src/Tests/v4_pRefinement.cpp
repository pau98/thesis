
// C++ headers
#include <iostream>
#include <iterator>
#include <mpi.h>
#include <fstream>

// Trilinos headers
#include <Teuchos_RCP.hpp>

// HiPerLiFE headers
#include "hl_StructMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_PredefinedElementFillings.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_ConsistencyCheck.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_NonlinearSolver_NewtonRaphson.h"
#include "hl_TimeIterator.h"

#include "hl_GlobalBasisFunctions.h"
#include "hl_Array.h"
#include "hl_TypeDefs.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


enum class Model
{
    Undefined,
    Poisson,
    AllenCahn
};


int main()
{
    // **************************************************************//
    // *****                 INITIALIZATION                     *****//
    // **************************************************************//

    MPI_Init(nullptr, nullptr);
    cout << endl;

    // ElemType _eType = ElemType::Square;
    // for (int i = 1; i < 4; i++)
    // {
    //     vector<int> vtk2hl = vtkReordering(_eType, BasisFuncType::Lagrangian, i, true);
    //     // vector<int> hl2vtk = vtkReordering(_eType, BasisFuncType::Lagrangian, i, true);
    //     vector<int> nType_vtk = elemNodeTypeVtk(_eType, BasisFuncType::Lagrangian, i);
    //     for (auto n: nType_vtk)
    //         cout << n << " ";
    //     cout << endl;

    //     vector<int> nType(nType_vtk.size());
    //     for (int i = 0; i < nType_vtk.size(); i++)
    //         nType[i] = nType_vtk[vtk2hl[i]];
    //     for (auto n: nType)
    //         cout << n << " ";
    //     cout << endl;

    //     vector<int> numNType = numElemNodeType(_eType, BasisFuncType::Lagrangian, i);
    //     for (auto n: numNType)
    //         cout << n << " ";
    //     cout << endl;

    //     cout << endl;

    // }

    // MPI_Finalize();
    // return 0;

    // Define model
    Model model = Model::Poisson;

    // Define parameters of the model
    RCP<UserStructure> userStr = rcp(new UserStructure);
    if (model == Model::Poisson)
    {
        userStr->Poisson.source = [](double x, double y, double z){return x*x*10.0;};
    }
    else
    {
        userStr->AllenCahn.epsilon2 = 0.00005;
        // userStr->AllenCahn.constantMobility = 1.0;
        userStr->AllenCahn.mobility = [](double c)->vector<double>
        {
            return {c*(1.-c), 1.-2.*c, -2.};
        };
        // userStr->AllenCahn.doubleWell = [](double c)->vector<double>
        // {
        //     return {(c*c)*(1.0-c)*(1.0-c)/4.0,
        //             c*(1.0-c)*(1.0-2.0*c)/2.0,
        //             (1.0-6.0*c+6.0*c*c)/2.0};
        // };
        userStr->AllenCahn.doubleWell = [](double c)->vector<double>
        {
            return {0,
                    log(c)-log(1.-c) - 6.0*c + 3.0,
                    1.0/(c*(1.0-c)) - 2.0*3.0};
        };
    }

    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Mesh
    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    // if (model == Model::Poisson)
    // {
    //     mesh->genStructMesh(81);
    //     // mesh->genCircularArc(4, 1.0, M_PI/2);
    //     // mesh->genAnnularSector(3,3,0.2,1.0,M_PI/2);
    //     // mesh->_pRefinedMesh(1);
    //     // mesh->printMesh("a");
    // }
    // else
    {
        mesh->genStructMesh(10);
        mesh->threeRefine([](double x, double y, double z){
                              double d = sqrt((x-0.5)*(x-0.5)+(y-0.5)*(y-0.5));
                              // double d1 = sqrt((x-0.5)*(x-0.5)/2+(y-0.5)*(y-0.5));
                              // double d2 = sqrt((x-0.5)*(x-0.5)/1.8+(y-0.5)*(y-0.5));
                              // if (d2 > 0.22 and d1 < 0.26)
                              //     return 3;
                              if (d > 0.2 and d < 0.3)
                                  return 4;
                              if (d < 0.3)
                                  return 1;
                              return 0;
                          });
        // mesh->genStructMesh(1);
        // map<int,int> levels;
        // levels[1] = 1;
        // mesh->threeRefine(levels);
        // mesh->printMesh("a");
    }

    cout << "dismesh" << endl;

    // Pressure distributed mesh
    RCP<DistributedMesh> disMeshP = rcp(new DistributedMesh);
    disMeshP->setMesh(mesh);
    disMeshP->setBalanceMesh(false);
    disMeshP->Update();
    disMeshP->printFileLegacyVtk("MeshP");

    cout << "p-refined dismesh" << endl;
    // Main p-refined distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    // disMesh->setMesh(mesh);
    disMesh->setMeshRelation(MeshRelation::pRefin, disMeshP);
    disMesh->setPRefinement(1);
    // disMesh->setMeshRelation(MeshRelation::hRefin, disMeshP);
    // disMesh->setHRefinement(1);
    disMesh->setBalanceMesh(false);
    disMesh->setVerbosity(Verbosity::Extreme);
    disMesh->Update();
    cout << "print" << endl;
    disMesh->printFileLegacyVtk("Mesh");

    MPI_Finalize();
    return 0;


    // **************************************************************//
    // *****               DOFHANDLER CREATION                  *****//
    // **************************************************************//

    // Create DOFHandler
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMeshP));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    // Boundary conditions
    if (model == Model::Poisson)
    {
        dofHand->setBoundaryCondition(0, 0.0);
        dofHand->setBoundaryCondition(0, MAxis::Xmin, -1.0);
        dofHand->setBoundaryCondition(0, MAxis::Xmax, 1.0);
        dofHand->setBoundaryCondition(0, MAxis::Ymin, [](double x){return x;});
        dofHand->setBoundaryCondition(0, MAxis::Ymax, [](double x){return x*x;});
    }
    else
    {
        dofHand->setInitialCondition(0, [=](double x, double y){
                                            // double r = ((double) rand()/(RAND_MAX))*2.0-1.0;
                                            // return 0.63+0.05*r;
                                            double d = sqrt((x-0.5)*(x-0.5)/2+(y-0.5)*(y-0.5));
                                            double u = 0.5-0.5*tanh((d-0.25)/(sqrt(2*userStr->AllenCahn.epsilon2)));
                                            return 0.8*u+0.1;//*(0.63+0.05*r);
                                        });
    }
    dofHand->UpdateGhosts();


    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ", pow(mesh->_bfOrder+1, mesh->_pDim));
    if (model == Model::Poisson)
        hiperProbl->setElementFillings("Integ", PredefinedElementFillings::Poisson);
    else
        hiperProbl->setElementFillings("Integ", PredefinedElementFillings::AllenCahn);
    hiperProbl->Update();


    // **************************************************************//
    // *****                  SOLVER CREATION                   *****//
    // **************************************************************//

    // RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    // solver->setHiPerProblem(hiperProbl);
    // solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    // solver->setDefaultParameters();
    // solver->Update();

    RCP<AztecOOIterativeLinearSolver> solver = rcp(new AztecOOIterativeLinearSolver());
    solver->setHiPerProblem(hiperProbl);
    solver->setTolerance(1.E-8);
    solver->setMaxNumIterations(500);
    solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    solver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilu);
    solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::Extreme);
    solver->setDefaultParameters();
    solver->Update();

    // Non-linear solver
    RCP<NewtonRaphsonNonlinearSolver> nonlinSolver = rcp (new NewtonRaphsonNonlinearSolver());
    nonlinSolver->setLinearSolver(solver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-8);
    nonlinSolver->setSolTolerance(1.E-8);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();

    // Time iterator
    RCP<TimeIterator> tIterator = rcp(new TimeIterator);
    // tIterator->setLinearSolver(solver);
    tIterator->setNonlinearSolver(nonlinSolver);
    tIterator->setTimeStepSize(1e-5);
    tIterator->setStopCriteria(2000, 1e3, 1e-6);
    tIterator->setTimeSteppingScheme(TimeSteppingScheme::AdaptiveLinear);
    tIterator->setLinearStepFactor(1.01, 0.5);
    tIterator->setMaximumTimeStepSize(0.1);
    tIterator->setPrintToFile(PrintToFileMethod::LegacyVtk, 10, "AllenCahn");
    // tIterator->setPrintRestart(10, "restart");
    // tIterator->setPostprocess(1, [=](){dhand->printFileLegacyVtk("HeatEq" + to_string(tIterator->timeStep()));});
    tIterator->Update();


    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    if (model == Model::Poisson)
    {
        bool status = solver->solve();
        solver->UpdateSolution();

        dofHand->printFile("Poisson");
        dofHand->printFileLegacyVtk("Poisson", true);
    }
    else
    {
        solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::None);
        tIterator->Iterate();
    }

    // **************************************************************//
    // *****                    FINALIZE                        *****//
    // **************************************************************//

    MPI_Finalize();
    return 0;
}
