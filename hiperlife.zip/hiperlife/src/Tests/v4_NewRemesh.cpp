
/// C++ headers
#include <iostream>
#include <mpi.h>
#include <fstream>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_Math.h"
#include "hl_Remesher.h"

#include "hl_HiPerProblem.h"
#include <hl_LinearSolver_Direct_MUMPS.h>
#include "hl_Geometry.h"
#include "hl_SurfLagrParam.h"
#include "hl_Tensor.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

using namespace std;


void LS_GEOM(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace hiperlife;
    using Teuchos::RCP;

    auto& subFill = (*fillStr)[0];

    int numDOFs  = subFill.numDOFs;
    int eNN      = subFill.eNN;
    vector<double>& nborCoords  = subFill.nborCoords;

    RCP<UserStructure> userStr   = fillStr->userStr;

    //MAIN OUTPUT declaration
    auto& Ak  = fillStr->Ak(0, 0); // <<=== MAIN OUTPUT
    auto& Bk  = fillStr->Bk(0);    // <<=== MAIN OUTPUT

    int N_e = numDOFs*eNN;
    //------------------------------------------------------------------------------------

    // Get the value of the basis functions and derivatives at the Gauss point k
    double *bf  = subFill.nborBFs();
    double *dbf = subFill.nborBFsGrads();

    double x[3];
    double metric[4];
    double e1[3], e2[3];
    Math::MatTMult(x, 3, eNN, 1, nborCoords.data(), bf);
    SurfLagrParam::MetricTensor(metric,e1,e2,eNN,nborCoords.data(),dbf);
    double jac = sqrt(Math::DetMat2x2(metric));



    int shapeType = fillStr->userStr->iparam[0];
    double z = x[2];

    double targetx[3];
    double r = Math::Norm3D(x);
    Math::AX(x, 3 , 1.0/r);

    double fr = sqrt(x[0]*x[0] + x[1]*x[1]);
    shapeType=2;
    if (shapeType == 1) //Ellipsoid
        z = x[2] * 0.75;
    else if (shapeType == 2) //Red blood cell
        z = x[2] * 0.4 * (1.0-0.7*cos(1.5*M_PI*fr));
    else if (shapeType == 3) //spacecraft
        z = x[2] * 0.7 * (1.0+0.1*cos(2.0*M_PI*x[1]/r));

    targetx[0] = x[0];
    targetx[1] = x[1];
    targetx[2] = z;

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            //Add submatrix to elemental matrix
            for (int n = 0; n < numDOFs; n++)
                Ak[(numDOFs*i+n)*N_e + numDOFs*j + n] = jac * bf[i] * bf[j];
        }

        //Add submatrix to elemental matrix
        for (int n = 0; n < numDOFs; n++)
            Bk[numDOFs*i + n] = jac * bf[i] * targetx[n];

    }
}

void InitializeNodalValues(Teuchos::RCP<hiperlife::DistributedMesh> disMesh, int shapeType)
{
    // Parameters
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->iparam.resize(1);
    userStr->iparam[0] = shapeType;

    RCP<DOFsHandler> posDHand = rcp(new DOFsHandler(disMesh));
    posDHand->setNameTag("posDHand");
    posDHand->setDOFs({"x", "y", "z"});
    posDHand->Update();

    // Hiperproblem
    RCP<HiPerProblem> prehp = rcp(new HiPerProblem("HiPerProblem"));
    prehp->setUserStructure(userStr);
    prehp->setDOFsHandlers({posDHand});
    prehp->setIntegration("LeastSq", {"premech"});
    prehp->setCubatureGauss("LeastSq", 3);
    prehp->setElementFillings("LeastSq", LS_GEOM);
    prehp->Update();

    // Solver
    RCP<MUMPSDirectLinearSolver> solver = rcp(new MUMPSDirectLinearSolver());
    solver->setHiPerProblem(prehp);
    solver->setDefaultParameters();
    solver->Update();

    // Solve
    solver->solve();

    // Update
    solver->UpdateSolution();
    posDHand->UpdateGhosts();

    // Update mesh coordinates
    // for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
    {
        disMesh->_nodeData->setValue(posDHand->nodeDOFs);
        // x[1] = dhand->mesh->nodeCoord(i, 'y', IndexType::Local);
    }
    disMesh->_nodeData->UpdateGhosts();
}

int main()
{
    // Initialize
    MPI_Init(nullptr, nullptr);
    cout << endl;

    // // Create mesh
    // RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    // mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // mesh->genStructMesh(40);

    // RCP<UnstructVtkMeshGenerator> mesh = rcp(new UnstructVtkMeshGenerator);
    // mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // mesh->genSphere([](double x[3]){return 0.1;});
    // // mesh->genPlane([](double x[3]){return 0.1;});

    RCP<MeshLoader> mesh = rcp(new MeshLoader);
    mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
    // mesh->loadMesh("../meshes/cell.vtk", MeshType::Parallel);
    // mesh->loadMesh("../meshes/circle_n3.vtk", MeshType::Parallel);
    mesh->loadMesh("/home/guille/simulations/meshes/sphere_n3.vtk", MeshType::Parallel);

    // Distribute the mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    // DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"DOF_0"});
    // dhand->setDOFs({"d", "r"});
    // dhand->setNodeAuxF({"a", "b", "c"});
    dhand->Update();

    // Set initial conditions
    dhand->setInitialCondition(0, [](double x, double y, double z) { return x*y; });
    // dhand->nodeDOFs->setValue(0, 0.0);
    // dhand->nodeDOFs->setValue(1, 1.0);
    // dhand->nodeAuxF->setValue(0, 2.0);
    // dhand->nodeAuxF->setValue(1, 3.0);
    // dhand->nodeAuxF->setValue(2, 4.0);
    dhand->UpdateGhosts();

    // Output dofs
    dhand->printFileLegacyVtk("dhand", true);


    // Remesh
    Timer timer({"Serial", "Parallel", "Parallel2"});
    if (true)
    {
        timer.start("Serial");
        RCP<Remesher> remesher = rcp(new Remesher);
        remesher->setDOFsHandler(dhand, {"DOF_0"});
        remesher->setRemeshMethod(RemeshMethod::Serial, 0.005/2);
        remesher->setDefaultParameters();
        remesher->Update();
        // remesher->newDOFsHands(dofHand0);
        // dofHand0->printFileLegacyVtk("newMesh");
        timer.end("Serial");

        // RCP<DOFsHandler> dhand2;
        // remesher->newDOFsHands(dhand2);
        // dhand2->printFileVtk("dhand_serial", false);
    }

    if (disMesh->myRank() == 0)
        cout << endl << endl;
    if (true)
    {
        timer.start("Parallel");
        RCP<Remesher> remesher = rcp(new Remesher);
        remesher->setDOFsHandler(dhand, {"DOF_0"});
        // remesher->setRemeshMethod(RemeshMethod::Parallel, [](double f){return 2.3*f;});
        remesher->setRemeshMethod(RemeshMethod::Parallel, 0.005/2);
        remesher->setDefaultParameters();
        remesher->Update();
        timer.end("Parallel");

        // RCP<DOFsHandler> dhand2;
        // remesher->newDOFsHands(dhand2);
        // dhand2->printFileVtk("dhand_parallel", false);
    }

    // // Set initial conditions
    // dhand->setInitialCondition("d", [](double x, double y, double z)
    //                                     {
    //                                         return (1-x)*y*3;
    //                                     });
    // dhand->UpdateGhosts();
    // dhand->printFileLegacyVtk("test", true);

    // dhand->UpdateGhosts();
    // if (true)
    // {
    //     timer.start("Parallel2");
    //     RCP<Remesher> remesher = rcp(new Remesher);
    //     remesher->setDOFsHandler(dhand, {"d"});
    //     remesher->setRemeshMethod(RemeshMethod::Parallel, 0.005);
    //     remesher->setDefaultParameters();
    //     remesher->Update();
    //     timer.end("Parallel2");
    // }


    timer.printTiming();






    // Finalize
    MPI_Finalize();
    return 0;


    if (false)
    {
        // Create mesh
        RCP<StructMeshGenerator> p_mesh = rcp(new StructMeshGenerator);
        p_mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
        p_mesh->genStructMesh(2);

        // Distribute the mesh
        RCP<DistributedMesh> p_disMesh = rcp(new DistributedMesh);
        p_disMesh->setMesh(p_mesh);
        p_disMesh->setBalanceMesh(true);
        p_disMesh->Update();

        // Share coordinates
        cout << "Sharing coordinates" << endl;
        vector<vector<double>> coords(p_disMesh->nPts(), vector<double>(3));
        for (int i = 0; i < p_disMesh->nPts(); i++)
        {
            // Get node coordinates in new mesh
            int p_new = p_disMesh->nodePartition(i);
            if (p_disMesh->isNodeInPart(i))
                coords[i] = p_disMesh->nodeCoords(i);
            MPI_Bcast(coords[i].data(), 3, MPI_DOUBLE, p_new, p_disMesh->comm());
        }

        // Interpolate
        vector<vector<double>> fields = dhand->interpolateDOFs(vector<int>{0}, coords);
        // for (int n = 0; n < fields.size(); n++)
        // {
        //     cout << n << " : ";
        //     for (auto f: fields[n])
        //         cout << f << " ";
        //     cout << endl;
        // }

        // Finalize
        MPI_Finalize();
        return 0;

    }

    // Timer timer({"1", "2"});

    // timer.start("1");
    // for (int i = 0; i < 1000000; i++)
    //     dhand->interpolateField(dhand->nodeDOFs, 0, 0, {0.25, 0.25}, IndexType::Local);
    // timer.end("1");

    // timer.start("2");
    // for (int i = 0; i < 1000000; i++)
    //     dhand->interpolateField2(dhand->nodeDOFs, 0, 0, {0.25, 0.25}, IndexType::Local);
    // timer.end("2");

    // timer.printTiming();

    // vector<RCP<FieldStruct>> fieldStructs = {dhand->nodeDOFs};
    // vector<vector<int>> fields = {{0}};
    // vector<double> xCoords = {0.5, 0.6, 0.0};
    // vector<vector<double>> xCoords2 = {{0.5, 0.6, 0.0}, {0.3, 0.4, 0.0}};
    // vector<double> rCoords = {0.5, 0.6};
    // vector<vector<double>> rCoords2 = {{0.25, 0.3}, {0.2,0.2}};
    // int elem = 1;
    // vector<int> elems = {0,1};
    // vector<int> fields2 = {0,1};

    // {
    //     vector<double> x0 = dhand->interpolateField2(dhand->nodeDOFs, 0, xCoords);
    //     cout << "1: ";
    //     for (auto v: x0)
    //         cout << v << " ";
    //     vector<double> x1 = dhand->interpolateField2(dhand->nodeAuxF, 2, xCoords);
    //     cout << "x: ";
    //     for (auto v: x1)
    //         cout << v << " ";
    //     cout << endl;
    // }
    // {
    //     vector<vector<double>> x0 = dhand->interpolateField2(dhand->nodeDOFs, {0,1}, xCoords);
    //     cout << "2: ";
    //     for (auto x: x0)
    //     {
    //         for (auto c: x)
    //             cout << c << " ";
    //         cout << endl;
    //     }
    //     vector<vector<double>> x1 = dhand->interpolateField2(dhand->nodeAuxF, {0,2}, xCoords);
    //     for (auto x: x1)
    //     {
    //         for (auto c: x)
    //             cout << c << " ";
    //         cout << endl;
    //     }
    // }
    // {
    //     vector<vector<double>> x0 = dhand->interpolateField2(dhand->nodeDOFs, {0,1}, xCoords2);
    //     cout << "3: ";
    //     for (auto x: x0)
    //     {
    //         for (auto c: x)
    //             cout << c << " ";
    //         cout << endl;
    //     }
    //     vector<vector<double>> x1 = dhand->interpolateField2(dhand->nodeAuxF, {0,2}, xCoords2);
    //     for (auto x: x1)
    //     {
    //         for (auto c: x)
    //             cout << c << " ";
    //         cout << endl;
    //     }
    // }
    // {
    //     vector<vector<double>> x0 = dhand->interpolateField2({dhand->nodeDOFs,dhand->nodeAuxF}, {{0,1},{0,2}}, xCoords);
    //     cout << "4: ";
    //     for (auto x: x0)
    //     {
    //         for (auto c: x)
    //             cout << c << " ";
    //         cout << endl;
    //     }
    //     vector<vector<double>> x1 = dhand->interpolateField2({dhand->nodeDOFs,dhand->nodeAuxF}, {{0,1},{0,2}}, xCoords2);
    //     cout << "4: ";
    //     for (auto x: x1)
    //     {
    //         for (auto c: x)
    //             cout << c << " ";
    //         cout << endl;
    //     }
    // }

    // vector<double> x = {0,0,0,0};
    // vector<double> y = {1,2};
    // // x[1] = *y.data();
    // x.
    // for (auto xx: x)
    //     cout << xx << " ";
    // cout << endl;

    // dhand->interpolateField2(dhand->nodeDOFs, 0, xCoords2);
    // dhand->interpolateField2(dhand->nodeDOFs, fields2, xCoords);
    // dhand->interpolateField2(dhand->nodeDOFs, fields2, xCoords2);
    // dhand->interpolateField2(dhand->nodeDOFs, fields2, xCoords);

    // cout << dhand->interpolateField2(dhand->nodeDOFs, 0, elem, rCoords, IndexType::Local) << endl;
    // cout << dhand->interpolateField2(dhand->nodeDOFs, 1, elem, rCoords, IndexType::Local) << endl;
    // cout << dhand->interpolateField2(dhand->nodeAuxF, 0, elem, rCoords, IndexType::Local) << endl;
    // cout << dhand->interpolateField2(dhand->nodeAuxF, 1, elem, rCoords, IndexType::Local) << endl;
    // cout << dhand->interpolateField2(dhand->nodeAuxF, 2, elem, rCoords, IndexType::Local) << endl;

    // {
    //     cout << endl;
    //     vector<double> vals0 = dhand->interpolateField2(dhand->nodeDOFs, {0,1}, elem, rCoords, IndexType::Local);
    //     cout << vals0[0] << " " << vals0[1] << endl;
    //     vector<double> vals1 = dhand->interpolateField2(dhand->nodeAuxF, {0,2}, elem, rCoords, IndexType::Local);
    //     cout << vals1[0] << " " << vals1[1] << endl;
    // }
    // {
    //     cout << endl;
    //     vector<double> vals0 = dhand->interpolateField2(dhand->nodeDOFs, 1, elems, rCoords2, IndexType::Local);
    //     cout << vals0[0] << " " << vals0[1] << endl;
    //     vector<double> vals1 = dhand->interpolateField2(dhand->nodeAuxF, 1, elems, rCoords2, IndexType::Local);
    //     cout << vals1[0] << " " << vals1.at(1) << endl;
    // }
    // {
    //     cout << endl;
    //     vector<double> vals0 = dhand->interpolateField2(dhand->nodeDOFs, {0,1}, elems, rCoords2, IndexType::Local);
    //     for (auto v: vals0)
    //         cout << v << " ";
    //     cout << endl;
    //     vector<double> vals1 = dhand->interpolateField2(dhand->nodeAuxF, {0,2}, elems, rCoords2, IndexType::Local);
    //     for (auto v: vals1)
    //         cout << v << " ";
    //     cout << endl;
    // }
    // {
    //     cout << endl;
    //     vector<double> vals0 = dhand->interpolateField2({dhand->nodeDOFs,dhand->nodeAuxF}, {{0,1},{0,2}}, elem, rCoords, IndexType::Local);
    //     for (auto v: vals0)
    //         cout << v << " ";
    //     cout << endl;
    // }

    // // Finalize
    // MPI_Finalize();
    // return 0;
}
