/// C++ headers
#include <iostream>

/// hiperlife headers
#include "hl_Core.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_GlobalBasisFunctions.h"

using namespace hiperlife;

void ElementFilling(FillStructure& fillStr);

static const double TEST_CYL_RADIUS = 1.0;
static const double TEST_CYL_HEIGHT = 3.0;

SmartPtr<MeshCreator> GenerateMeshCreator(bool removeCreases)
{
    SmartPtr<UnstructVtkMeshGenerator> meshCreator = Create<UnstructVtkMeshGenerator>();;

    const double h = 0.05;
    meshCreator->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs,2);
    meshCreator->genCylinder(TEST_CYL_RADIUS, TEST_CYL_HEIGHT, false, [h](double x[3]){ return h;});

    if(removeCreases)
    {
        std::fill(meshCreator->_creases.begin(), meshCreator->_creases.end(), 0);
        std::fill(meshCreator->_glob_creases.begin(), meshCreator->_glob_creases.end(), 0);
    }

    return meshCreator;
}

double TestCreases(bool removeMeshCreatorCreases, bool generateDisMeshCrease)
{
    SmartPtr<MeshCreator> mesh = GenerateMeshCreator(removeMeshCreatorCreases);

    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(mesh);
    disMesh->setElementLocatorEngine(ElementLocatorEngine::BoundingVolumeHierarchy);
    disMesh->setBalanceMesh(true);
    if (generateDisMeshCrease)
        disMesh->setGenerateCreases(generateDisMeshCrease);
    disMesh->Update();
    disMesh->printFileLegacyVtk("disMesh_creases.vtk");

    SmartPtr<DOFsHandler> field = Create<DOFsHandler>(disMesh);
    field->setNameTag("field");
    field->setNumDOFs(3);
    field->Update();

    SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();
    hiperProbl->setDOFsHandlers({field});
    hiperProbl->setIntegration("Integ", {"field"});
    hiperProbl->setCubatureGauss("Integ", 3);
    hiperProbl->setElementFillings("Integ", ElementFilling);
    hiperProbl->setGlobalIntegrals({"errorCoords", "estimatedH", "area"});
    hiperProbl->Update();

    hiperProbl->FillLinearSystem();

    return hiperProbl->globalIntegral("area");
}

int main(int argc, char **argv)
{
    hiperlife::Init(argc, argv);
    double test1;

    /// test 1: mesh creator creases
    {
        if (VerboseRank()) std::cout << "Testing creases generator: mesh creator creases." << std::endl;
        const double areaComp = TestCreases(false, false);
        const double areaTest = 2.0 * M_PI * TEST_CYL_RADIUS * TEST_CYL_HEIGHT;
        const double errorArea = abs(areaComp - areaTest) / areaTest;
        test1 = areaComp;

        if (errorArea < 5e-2) {
            if (VerboseRank()) std::cout << "   ** Test passed **" << std::endl;
        } else {
            if (VerboseRank()) std::cout << "   ** Test failed **" << std::endl;
            hiperlife::Finalize();
            return 1;
        }
    }

    /// test 2: no creases (disabled in parallel for problems in the exception management)
    if(hiperlife::NumProcs() == 1)
    {
        try {
            if (VerboseRank()) std::cout << "Testing creases generator: no creases. Expected exception" << std::endl;
            TestCreases(true, false);

            if (VerboseRank()) std::cout << "   ** Test failed **" << std::endl;
            hiperlife::Finalize();
            return 1;
        } catch (const std::exception& e) {
            if (VerboseRank()) std::cout << "   ** Test passed **" << std::endl;
        }
    }

    /// test 3: distributed mesh creases
    {
        if (VerboseRank()) std::cout << "Testing creases generator: distributed mesh creases." << std::endl;
        const double areaComp = TestCreases(true, true);
        const double compTest13 = abs(areaComp - test1);
        if (compTest13 < 1e-8) {
            if (VerboseRank()) std::cout << "   ** Test passed **" << std::endl;
        } else {
            if (VerboseRank()) std::cout << "   ** Test failed **" << std::endl;
            hiperlife::Finalize();
            return 1;
        }
    }

    /// everything is ok
    hiperlife::Finalize();
    return 0;
}


void ElementFilling(FillStructure& fillStr)
{
    using namespace hiperlife;
    using ttl::tensor, ttl::wrapper;
    using ttl::index::I, ttl::index::a, ttl::index::b, ttl::index::i;

    SubFillStructure& subFill = fillStr[0];

    wrapper<double, 2> Dbf(subFill.nborBFsGrads(), subFill.eNN, subFill.pDim);
    wrapper<double, 2> nborCoords(subFill.nborCoords.data(), subFill.eNN, subFill.nDim);

    tensor<double, 2> Dx  = Dbf(I,a) * nborCoords(I,i);
    tensor<double, 2> metric = Dx(a,i) * Dx(b,i);
    double jac = sqrt(metric.det());

    fillStr.addToGlobalIntegral("area", jac);
}
