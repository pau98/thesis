
/// C++ headers
#include <ios>
#include <iostream>
#include <mpi.h>
#include <fstream>
#include <numeric>

/// Trilinos headers
#include <Teuchos_RCP.hpp>
#include <Teuchos_CommandLineProcessor.hpp>
#include <stdexcept>
/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_ConfigFile.h"
#include "hl_BasicMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_StructMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Iterative_AztecOO.h"
#include "hl_LinearSolver_Direct_Amesos2.h"
#include "hl_LinearSolver_Direct_MUMPS.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_SurfLagrParam.h"
#include "hl_LocMongeParam.h"
#include "hl_Tensor.h"


using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


struct SolveOptions
{
        int solver{0};
        int nElem{500};
        int symmetric{0};
        int matrixOnHost{0};
        int anType{2};
        int ordLibrary{7};

        //Other options
        string meshName = "P";
        bool printMat   = false;
        int myRank;
};

double solveAztecOO(RCP<HiPerProblem> hiperProbl, SolveOptions opt)
{
    //Reset solution
    for (int i = 0; i < hiperProbl->sol->MyLength(); i++)
        (*hiperProbl->sol)[0][i] = 0.0;

    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
    RCP<AztecOOIterativeLinearSolver> linSolver = rcp(new AztecOOIterativeLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setTolerance(1.E-8);
    linSolver->setMaxNumIterations(500);
    linSolver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
    linSolver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::DomainDecomp);
    linSolver->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::Ilut);
    linSolver->setDefaultParameters();
    linSolver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    linSolver->Update();

    //Print matrix and rhs to file
    if (opt.printMat == true)
    {
        hiperProbl->FillLinearSystem();

        //========================= Matrix =========================//
        string name = "AP." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout_a(name);
        fout_a.precision(15);
        fout_a << scientific << *hiperProbl->A << endl;
        fout_a.close();

        //========================== RHS ==========================//
        name = "BP." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout_b(name);
        fout_b.precision(15);
        fout_b << *hiperProbl->rhs << endl;
        fout_b.close();
    }

    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    linSolver->solve();
    linSolver->UpdateSolution();

    //Print solution to file
    if (opt.printMat == true)
    {
        string name = "XP." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout(name);
        fout.precision(15);
        fout << *hiperProbl->sol << endl;
        fout.close();
    }

    // //Print solution
    // hiperProbl->UpdateSolution();
    // hiperProbl->_dhands[0]->printFileLegacyVtk("sol_"+opt.meshName+"_it", true);

    return linSolver->time(AztecOOIterativeLinearSolver::TimerName::Solver);
}

double solveAmesos2(RCP<HiPerProblem> hiperProbl, SolveOptions opt)
{
    //Reset solution
    for (int i = 0; i < hiperProbl->sol->MyLength(); i++)
        (*hiperProbl->sol)[0][i] = 0.0;

    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
    RCP<Amesos2DirectLinearSolver> linSolver = rcp (new Amesos2DirectLinearSolver());
    linSolver->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setNumericFactorization(true);
    linSolver->setSymbolicFactorization(true);
    linSolver->setVerbosity(Amesos2DirectLinearSolver::Verbosity::High);
    linSolver->setDefaultParameters();
    linSolver->Update();

    //Print matrix and rhs to file
    if (opt.printMat == true)
    {
        if (hiperProbl->myRank() == 0)
            cout << "Filling linear system" << endl;
        hiperProbl->FillLinearSystem();

        //========================= Matrix =========================//
        if (hiperProbl->myRank() == 0)
            cout << "Outputting matrix" << endl;

        // MatrixMarket format; serial
        // EpetraExt::RowMatrixToMatrixMarketFile("A2.mm", *hiperProbl_u->A, "LHS", "Left hand side matrix");
        // EpetraExt::MultiVectorToMatrixMarketFile("X2.mm", *hiperProbl_u->sol, "Sol", "Solution vector");
        // EpetraExt::MultiVectorToMatrixMarketFile("B2.mm", *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // MatrixMarket format; parallel
        // string name = "A2" + to_string(hiperProbl_u->myRank()) + ".mm";
        // EpetraExt::RowMatrixToMatrixMarketFile(name.c_str(), *hiperProbl_u->A, "LHS", "Left hand side matrix");

        // hl format
        string name = "A" + opt.meshName + "." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout_a(name);
        fout_a.precision(15);
        fout_a << scientific << *hiperProbl->A << endl;
        fout_a.close();

        //========================== RHS ==========================//
        if (hiperProbl->myRank() == 0)
            cout << "Outputting rhs" << endl;
        // MatrixMarket format; serial
        // EpetraExt::MultiVectorToMatrixMarketFile("B2.mm", *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // MatrixMarket format; parallel
        // name = "B2" + to_string(hiperProbl_u->myRank()) + ".mm";
        // EpetraExt::MultiVectorToMatrixMarketFile(name.c_str(), *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // hl format
        name = "B" + opt.meshName + "." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout_b(name);
        fout_b.precision(15);
        fout_b << *hiperProbl->rhs << endl;
        fout_b.close();
    }


    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    linSolver->solve();

    linSolver->UpdateSolution();

    //Print solution to file
    if (opt.printMat == true)
    {
        if (hiperProbl->myRank() == 0)
            cout << "Outputting solution" << endl;

        // MatrixMarket format; serial
        // EpetraExt::MultiVectorToMatrixMarketFile("X2.mm", *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // MatrixMarket format; parallel
        // name = "X2" + to_string(hiperProbl_u->myRank()) + ".mm";
        // EpetraExt::MultiVectorToMatrixMarketFile(name.c_str(), *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // hl format
        string name = "X" + opt.meshName + "." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout(name);
        fout.precision(15);
        fout << *hiperProbl->sol << endl;
        fout.close();
    }


    // //Print solution
    // hiperProbl->UpdateSolution();
    // hiperProbl->_dhands[0]->printFileLegacyVtk("sol_"+opt.meshName+"_mumps", true);

    return linSolver->time(Amesos2DirectLinearSolver::TimerName::SymbolicFactorization)
        + linSolver->time(Amesos2DirectLinearSolver::TimerName::NumericFactorization)
        + linSolver->time(Amesos2DirectLinearSolver::TimerName::Solver);

}

double solveMUMPS(RCP<HiPerProblem> hiperProbl, SolveOptions opt)
{
    //Reset solution
    for (int i = 0; i < hiperProbl->sol->MyLength(); i++)
        (*hiperProbl->sol)[0][i] = 0.0;

    /// **************************************************************//
    /// *****                  SOLVER CREATION                   *****//
    /// **************************************************************//
    RCP<MUMPSDirectLinearSolver> linSolver = rcp(new MUMPSDirectLinearSolver());
    linSolver->setHiPerProblem(hiperProbl);
    linSolver->setMatrixType(static_cast<MUMPSDirectLinearSolver::MatrixType>(opt.symmetric));
    linSolver->setAnalysisType(static_cast<MUMPSDirectLinearSolver::AnalysisType>(opt.anType));
    linSolver->setOrderingLibrary(static_cast<MUMPSDirectLinearSolver::OrderingLibrary>(opt.ordLibrary));
    linSolver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
    linSolver->setDefaultParameters();
    linSolver->Update();

    //Print matrix and rhs to file
    if (opt.printMat == true)
    {
        if (hiperProbl->myRank() == 0)
            cout << "Filling linear system" << endl;
        hiperProbl->FillLinearSystem();

        //========================= Matrix =========================//
        if (hiperProbl->myRank() == 0)
            cout << "Outputting matrix" << endl;

        // MatrixMarket format; serial
        // EpetraExt::RowMatrixToMatrixMarketFile("A2.mm", *hiperProbl_u->A, "LHS", "Left hand side matrix");
        // EpetraExt::MultiVectorToMatrixMarketFile("X2.mm", *hiperProbl_u->sol, "Sol", "Solution vector");
        // EpetraExt::MultiVectorToMatrixMarketFile("B2.mm", *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // MatrixMarket format; parallel
        // string name = "A2" + to_string(hiperProbl_u->myRank()) + ".mm";
        // EpetraExt::RowMatrixToMatrixMarketFile(name.c_str(), *hiperProbl_u->A, "LHS", "Left hand side matrix");

        // hl format
        string name = "A" + opt.meshName + "." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout_a(name);
        fout_a.precision(15);
        fout_a << scientific << *hiperProbl->A << endl;
        fout_a.close();

        //========================== RHS ==========================//
        if (hiperProbl->myRank() == 0)
            cout << "Outputting rhs" << endl;
        // MatrixMarket format; serial
        // EpetraExt::MultiVectorToMatrixMarketFile("B2.mm", *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // MatrixMarket format; parallel
        // name = "B2" + to_string(hiperProbl_u->myRank()) + ".mm";
        // EpetraExt::MultiVectorToMatrixMarketFile(name.c_str(), *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // hl format
        name = "B" + opt.meshName + "." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout_b(name);
        fout_b.precision(15);
        fout_b << *hiperProbl->rhs << endl;
        fout_b.close();
    }


    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//
    linSolver->solve();
    linSolver->UpdateSolution();

    //Print solution to file
    if (opt.printMat == true)
    {
        if (hiperProbl->myRank() == 0)
            cout << "Outputting solution" << endl;

        // MatrixMarket format; serial
        // EpetraExt::MultiVectorToMatrixMarketFile("X2.mm", *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // MatrixMarket format; parallel
        // name = "X2" + to_string(hiperProbl_u->myRank()) + ".mm";
        // EpetraExt::MultiVectorToMatrixMarketFile(name.c_str(), *hiperProbl_u->rhs, "RHS", "Right hand side vector");

        // hl format
        string name = "X" + opt.meshName + "." + to_string(hiperProbl->numProcs()) + "." + to_string(hiperProbl->myRank()) + ".hl";
        std::ofstream fout(name);
        fout.precision(15);
        fout << *hiperProbl->sol << endl;
        fout.close();
    }

    // //Print solution
    // hiperProbl->UpdateSolution();
    // hiperProbl->_dhands[0]->printFileLegacyVtk("sol_"+opt.meshName+"_mumps", true);

    return linSolver->time(MUMPSDirectLinearSolver::TimerName::SolverCreation)+
        linSolver->time(MUMPSDirectLinearSolver::TimerName::Solver);

}


class faceMesh
{
    public:
        int faceType = 0;
        int nDim     = 3;
        int nVert    = 3;
        int nPts     = {};
        int nElem    = {};
        int DOF      = 3;
        int gDOF     = 7;
        int gAux     = 6;

        std::vector<int>    nBorFaces     = {};
        std::vector<int>    connec        = {};
        std::vector<double> x_nodes       = {};
        std::vector<int>    idN_creases   = {};
        std::vector<std::vector< std::pair<int,int>>> masterNodes = {};
        std::vector<std::vector< double >> masterNodesPerFlag = {};
        std::vector<bool> cn_nodes = {};

        Teuchos::RCP<hiperlife::FieldStruct> nodeDOFs = Teuchos::null;
        Teuchos::RCP<hiperlife::FieldStruct> auxF     = Teuchos::null;
        Teuchos::RCP<hiperlife::FieldStruct> gDOFS    = Teuchos::null;
        Teuchos::RCP<hiperlife::FieldStruct> auxV     = Teuchos::null;

        std::vector<double> u_nodes;
        std::vector<double> globalU;
        std::vector<double> globalV;

        void loadMesh( std::string fileName , int setConstraintflag);
        void saveMesh( string fileName );

};

class tissueMesh: public hiperlife::DistributedData
{

    public:

        int setConstraintflag        = 1;
        int setLinearConstraintsflag = 1;
        int restartflag              = 0;
        std::vector<faceMesh> meshes = {};

        void loadMesh( std::string fileName, int setConstraintflag, int setLinearConstraintsflag, int restartflag);
        void saveMesh( string fileName );

        faceMesh* operator [] (int i)
        {
            return &(meshes[i]);
        }

        void Update ()
        {
            generateDistMeshes();
            generateMechanics();
            updated = true;
        }
        Teuchos::RCP<hiperlife::HiPerProblem> generateHiPerMechanics(Teuchos::RCP<hiperlife::UserStructure> userStr, int gPts=1);

        std::vector<Teuchos::RCP<hiperlife::DistributedMesh>> disMeshes;
        std::vector<Teuchos::RCP<hiperlife::DOFsHandler>>       mechs;

        void saveVTK(string filename);

        void outputInfo ( );

    private:

        void generateDistMeshes();
        void generateMechanics();

        bool updated = false;

};

void LS_K (Teuchos::RCP<hiperlife::FillStructure> fillStr);
void LS_K_pp (Teuchos::RCP<hiperlife::FillStructure> fillStr);
int VertexModelSolver (std::vector<double>& dparam, std::vector<int>& iparam, Teuchos::RCP<hiperlife::HiPerProblem> hiperMech, int solverflag);
int VertexModelSolver_LineSearch (std::vector<double>& dparam, std::vector<int>& iparam, Teuchos::RCP<hiperlife::HiPerProblem> hiperMech, int solverflag);
void UpdateNodalForcesfromRHS(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech , double deltat);
void GetAveragePKStressfromNodes(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech, double* avgPK);
void GetSumofNodalForces(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech, double* Fsumlocal);
double Getloadstep(double t, double pull_begin, double pull_end, double push_begin, double push_end, int loadcase, double push_mag, double pull_mag);
std::tuple<int, int, double> linesearch_bisection(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech);
std::tuple<int, int, double> linesearch_backtracking(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech);

inline std::string first_numberstring(std::string const & str)
{

    std::size_t const n = str.find_first_of("0123456789");

    if (n != std::string::npos)

    {

        std::size_t const m = str.find_first_not_of("0123456789", n);

        return str.substr(n, m != std::string::npos ? m-n : m);

    }

    return std::string();

}


inline void CalcdGIGRef( double* dGIGRef, double* iTI, double &p_kI, double* Voigt )
{
    for ( int n = 0; n < 3; n++ )
    {
        for (int a = 0; a < 2; a++)
        {
            for (int b = 0; b < 2; b++)
            {
                dGIGRef[4 * n + 2 * a + b] = 0.0;
                for (int c = 0; c < 2; c++)
                {
                    for (int d = 0; d < 2; d++)
                    {
                        dGIGRef[4 * n + 2 * a + b] += iTI[2 * a + c] * iTI[2 * b + d] * p_kI * Voigt[4 * n + 2 * c + d];
                    }
                }
            }
        }
    }
}

inline void JacobianGradient (double *dJ, double *dp_k, double *phi_1, double *phi_2, double *normal)
{
    int j;
    double cross1[3], cross2[3];

    //cross1 = x_{,1} x n  (3D vector)
    hiperlife::Math::Cross(cross1, phi_1, normal);
    //cross2 = x_{,2} x n (3D vector)
    hiperlife::Math::Cross(cross2, phi_2, normal);


    // dJ = p_{,1}(x_{,2} x n) - p_{,2}(x_{,1} x n)
    hiperlife::Array::Fill3D(dJ, 0.0);
    hiperlife::Math::AXPY(dJ, 3, dp_k[0], cross2);
    hiperlife::Math::AXPY(dJ, 3,-dp_k[1], cross1);

    return;
}

inline void NormalGradient (double *dnormal, double *dp_k, double *phi_1, double *phi_2, double *normal, double J, double *dJ)
{
    double Iphi_1[9], Iphi_2[9];

    hiperlife::Array::Fill(dnormal, 9, 0.0);

    hiperlife::Math::AXPY(&dnormal[0], 3, -normal[0]/J, dJ);
    hiperlife::Math::AXPY(&dnormal[3], 3, -normal[1]/J ,dJ);
    hiperlife::Math::AXPY(&dnormal[6], 3, -normal[2]/J ,dJ);

    Iphi_1[0] =  0.0;
    Iphi_1[1] = -phi_1[2];
    Iphi_1[2] =  phi_1[1];

    Iphi_1[3] =  phi_1[2];
    Iphi_1[4] =  0.0;
    Iphi_1[5] = -phi_1[0];

    Iphi_1[6] = -phi_1[1];
    Iphi_1[7] =  phi_1[0];
    Iphi_1[8] =  0.0;

    Iphi_2[0] =  0.0;
    Iphi_2[1] = -phi_2[2];
    Iphi_2[2] =  phi_2[1];

    Iphi_2[3] =  phi_2[2];
    Iphi_2[4] =  0.0;
    Iphi_2[5] = -phi_2[0];

    Iphi_2[6] = -phi_2[1];
    Iphi_2[7] =  phi_2[0];
    Iphi_2[8] =  0.0;

    hiperlife::Math::AXPY(dnormal, 9, -dp_k[0]/J, Iphi_2);
    hiperlife::Math::AXPY(dnormal, 9,  dp_k[1]/J, Iphi_1);
}

inline void NormalHessian (double *ddnormal, double *dp_kI, double *dp_kJ, double J, double *dJI, double *dJJ, double *ddJ, double *normal, double *dnormalI, double *dnormalJ )
{
    double aux;

    hiperlife::Array::Fill(ddnormal, 27, 0.0);

    aux = -1.0/J * normal[0];
    hiperlife::Math::AXPY(&ddnormal[0], 9, aux, ddJ);
    aux = -1.0/J * normal[1];
    hiperlife::Math::AXPY(&ddnormal[9], 9, aux, ddJ);
    aux = -1.0/J * normal[2];
    hiperlife::Math::AXPY(&ddnormal[18], 9,aux,ddJ);

    aux = -1.0/J * dnormalI[0];
    hiperlife::Math::AXPY(&ddnormal[0], 3, aux, dJJ);
    aux = -1.0/J * dnormalI[1];
    hiperlife::Math::AXPY(&ddnormal[3], 3, aux, dJJ);
    aux = -1.0/J * dnormalI[2];
    hiperlife::Math::AXPY(&ddnormal[6], 3, aux, dJJ);

    aux = -1.0/J * dnormalI[3];
    hiperlife::Math::AXPY(&ddnormal[9], 3, aux, dJJ);
    aux = -1.0/J * dnormalI[4];
    hiperlife::Math::AXPY(&ddnormal[12], 3, aux, dJJ);
    aux = -1.0/J * dnormalI[5];
    hiperlife::Math::AXPY(&ddnormal[15], 3, aux, dJJ);

    aux = -1.0/J * dnormalI[6];
    hiperlife::Math::AXPY(&ddnormal[18], 3, aux, dJJ);
    aux = -1.0/J * dnormalI[7];
    hiperlife::Math::AXPY(&ddnormal[21], 3, aux, dJJ);
    aux = -1.0/J * dnormalI[8];
    hiperlife::Math::AXPY(&ddnormal[24], 3, aux, dJJ);

    aux = -1.0/J * dJI[0];
    hiperlife::Math::AXPY(&ddnormal[0], 3, aux, &dnormalJ[0]);
    aux = -1.0/J * dJI[1];
    hiperlife::Math::AXPY(&ddnormal[3], 3, aux, &dnormalJ[0]);
    aux = -1.0/J * dJI[2];
    hiperlife::Math::AXPY(&ddnormal[6], 3, aux, &dnormalJ[0]);

    aux = -1.0/J * dJI[0];
    hiperlife::Math::AXPY(&ddnormal[9], 3, aux, &dnormalJ[3]);
    aux = -1.0/J * dJI[1];
    hiperlife::Math::AXPY(&ddnormal[12], 3, aux, &dnormalJ[3]);
    aux = -1.0/J * dJI[2];
    hiperlife::Math::AXPY(&ddnormal[15], 3, aux, &dnormalJ[3]);

    aux = -1.0/J * dJI[0];
    hiperlife::Math::AXPY(&ddnormal[18], 3, aux, &dnormalJ[6]);
    aux = -1.0/J * dJI[1];
    hiperlife::Math::AXPY(&ddnormal[21], 3, aux, &dnormalJ[6]);
    aux = -1.0/J * dJI[2];
    hiperlife::Math::AXPY(&ddnormal[24], 3, aux, &dnormalJ[6]);


    aux = 1.0/J * ( dp_kI[0] * dp_kJ[1] - dp_kI[1] * dp_kJ[0] );
    ddnormal[5]  += aux;
    ddnormal[7]  -= aux;
    ddnormal[11] -= aux;
    ddnormal[15] += aux;
    ddnormal[19] += aux;
    ddnormal[21] -= aux;
}

inline void JacobianHessian (double *ddJ, double *dp_kI, double *dp_kJ, double *phi_1, double *phi_2, double *normal, double *dnormalJ)
{
    double aux[3];
    double Inormal[9];
    double cross1[9], cross2[9];

    hiperlife::Array::Fill(ddJ, 9, 0.0);

    Inormal[0] =  0.0;
    Inormal[1] = -normal[2];
    Inormal[2] =  normal[1];

    Inormal[3] =  normal[2];
    Inormal[4] =  0.0;
    Inormal[5] = -normal[0];

    Inormal[6] = -normal[1];
    Inormal[7] =  normal[0];
    Inormal[8] =  0.0;

    hiperlife::Math::AXPY(ddJ, 9, dp_kI[1]*dp_kJ[0]-dp_kI[0]*dp_kJ[1], Inormal);

    aux[0] = dnormalJ[0]; aux[1] = dnormalJ[3]; aux[2] = dnormalJ[6];
    hiperlife::Math::Cross(&cross1[0], phi_1, aux);
    hiperlife::Math::Cross(&cross2[0], phi_2, aux);
    aux[0] = dnormalJ[1]; aux[1] = dnormalJ[4]; aux[2] = dnormalJ[7];
    hiperlife::Math::Cross(&cross1[3], phi_1, aux);
    hiperlife::Math::Cross(&cross2[3], phi_2, aux);
    aux[0] = dnormalJ[2]; aux[1] = dnormalJ[5]; aux[2] = dnormalJ[8];
    hiperlife::Math::Cross(&cross1[6], phi_1, aux);
    hiperlife::Math::Cross(&cross2[6], phi_2, aux);

    hiperlife::Math::AXPY(ddJ, 9,  dp_kI[0], cross2);
    hiperlife::Math::AXPY(ddJ, 9, -dp_kI[1], cross1);

}

// Calculate the product of dN with a vector u: dN.u
inline void NormalGradientU (double *udn, double *dp_k, double *phi_1, double *phi_2, double *normal, double iJac, double *u)
{
    int j;
    double dJ[3];
    double cross1[3], cross2[3];

    hiperlife::Array::Fill3D(udn, 0.0);

    JacobianGradient(dJ, dp_k, phi_1, phi_2, normal);

    // cross1 = x_{,1} x u
    hiperlife::Math::Cross(cross1, phi_1, u);
    // cross2 = x_{,2} x u
    hiperlife::Math::Cross(cross2, phi_2, u);

    // udn = -iJac * ( u·n·dJ - ( p_{,1} x_{,2} x u - p_{,2} x_{,1} x u) )
    hiperlife::Math::AXPY(udn, 3, -iJac*hiperlife::Math::Dot3D(u, normal), dJ);
    hiperlife::Math::AXPY(udn, 3,  iJac*dp_k[0],                cross2);
    hiperlife::Math::AXPY(udn, 3, -iJac*dp_k[1],                cross1);

}

// Calculate the derivative of the metric tensor with respect to a node coordinates
inline void MetricGradient  (double *dg, double *dp_k, double *phi_1, double *phi_2)
{

    // dg_{ab} = p_{,a} x_{,b} + p_{,b} x_{,a} (12 components, 2x2 tensor and 3 spatial components)
    for (int j = 0; j < 3; j++)
    {
        dg[4*j+0]   = 2.0 * dp_k[0] * phi_1[j];
        double aux  = dp_k[0] * phi_2[j] + dp_k[1] * phi_1[j];
        dg[4*j+1]   = aux;
        dg[4*j+2]   = aux;
        dg[4*j+3]   = 2.0 * dp_k[1] * phi_2[j];
    }

}

// Calculate the derivative of the metric tensor with respect to a node coordinates
inline void MetricHessian(double *ddg, double *dp_kI, double *dp_kJ)
{
    // dg_{ab} = p_{,a} p_{,b} + p_{,b} p_{,a} (should have 3*3*4 components but they are 3 diagonal blocks that are equal + 0's)
    ddg[0]   = 2.0 * dp_kI[0] * dp_kJ[0];
    double aux = dp_kI[0] * dp_kJ[1] + dp_kI[1] * dp_kJ[0];
    ddg[1]   = aux;
    ddg[2]   = aux;
    ddg[3]   = 2.0 * dp_kI[1] * dp_kJ[1];
}

// gwt optogenetic activation magnitude
inline double getOptoActivationAMP(double yval,double xactivlow, double xactivhigh, double activwindowlow, double activwindowhigh)
{
    double activAMP = 1.0;
    if (yval > activwindowlow && yval < activwindowhigh) // region of activation
    {
        // Evaluate the activity amplitude
        if (yval > xactivlow && yval <= xactivlow + 5.0) // increase apical contractility within a given pattern
        {
            activAMP = 1.0 + 4.0 * (yval - xactivlow)/5.0;
        }
        else if (yval > xactivlow + 5.0 && yval <= xactivhigh - 5.0)
        {
            activAMP = 5.0;
        }
        else if (yval > xactivhigh - 5.0 && yval <= xactivhigh)
        {
            activAMP = 5.0 - 4.0 * (yval - (xactivhigh - 5.0))/5.0;
        }
        else
        {
            activAMP = 1.0;
        }
    }
    return activAMP;
}

void faceMesh::loadMesh(string fileName, int setConstraintflag)
{
    ifstream infile(fileName);
    if(!infile.is_open())
        throw runtime_error("loadFaceMesh: The input file (" + fileName + ") does not exist.");

    string line;


    getline(infile, line);
    faceType  = stoi(line);

    if ( faceType > 6 or faceType < 0 )
        throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has a incorrent face ID (" + to_string(faceType) + ".");


    getline(infile, line);

    std::istringstream iss(line);
    vector<string> tokens{istream_iterator<string>{iss},
                          istream_iterator<string>{}};
    for ( auto t: tokens)
        nBorFaces.push_back(stoi(t));
    getline(infile, line);
    nPts  = stoi(line);
    getline(infile, line);
    nElem = stoi(line);

    x_nodes.resize(nPts*nDim);
    cn_nodes.resize(nPts*nDim);

    for ( int i = 0; i < nPts; i++ )
    {
        getline(infile, line);

        if ( infile )
        {
            if (line.empty())
                throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has a blank line.");

            std::istringstream iss(line);
            vector<string> tokens{istream_iterator<string>{iss},
                                  istream_iterator<string>{}};

            if (tokens.size() != nDim)
                throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                    ") has a line with an inconsistent number of nodal coordinates.");

            for ( int n = 0; n < nDim; n++)
                x_nodes[nPts*n+i] = stod(tokens[n]);
        }
        else
            throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has finished before the end of reading. Inconsistent data has been provided.");
    }

    for ( int e = 0; e < nElem; e++ )
    {
        getline(infile, line);

        if ( infile )
        {
            if (line.empty())
                throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has a blank line.");

            std::istringstream iss(line);
            vector<string> tokens{istream_iterator<string>{iss},
                                  istream_iterator<string>{}};

            if (tokens.size() != nVert)
                throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                    ") has a line with an inconsistent number of nodes per element.");

            for ( int n = 0; n < nVert; n++)
                connec.push_back(stoi(tokens[n]));
        }
        else
            throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has finished before the end of reading. Inconsistent data has been provided.");
    }

    masterNodes.resize(nPts*nDim); // Storing separately for each DOF
    masterNodesPerFlag.resize(nPts*nDim); // For storing the periodic BC flags
    for (int i = 0; i < nPts; i++)
    {
        for (int dof = 0; dof < nDim; dof++)
        {
            getline(infile, line);

            if (infile)
            {
                if (line.empty())
                    continue;

                std::istringstream iss(line);
                vector<string> tokens{istream_iterator<string>{iss},
                                      istream_iterator<string>{}};

                if (tokens.size() % 3 != 0)
                {
                    cout << fileName << ":"<< tokens.size() << "," << line.empty() << ", [" << line << "]" << endl;
                    throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                        ") has a line with an inconsistent number of inputs for LC.");
                }

                for (int n = 0; n < tokens.size() / 3; n++)
                {
                    masterNodes[nPts*dof + i].push_back({stoi(tokens[3 * n]), stoi(tokens[3 * n + 1])});
                    masterNodesPerFlag[nPts*dof + i].push_back(stod(tokens[3 * n + 2]));
                }
            }
            else
            {
                throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                    ") has finished before the end of reading. Inconsistent data has been provided.");
            }
        }
    }

    for ( int i = 0; i < nPts; i++ )
    {
        getline(infile, line);

        if ( infile )
        {
            if (line.empty())
                throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has a blank line.");

            std::istringstream iss(line);
            vector<string> tokens{istream_iterator<string>{iss},
                                  istream_iterator<string>{}};

            if (tokens.size() != nDim)
                throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                    ") has a line with an inconsistent number of constraints.");

            for ( int n = 0; n < nDim; n++)
                cn_nodes[nPts*n+i] = bool(stoi(tokens[n]));
        }
        else
            throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has finished before the end of reading. Inconsistent data has been provided.");
    }


    idN_creases.resize(nPts);
    fill(idN_creases.begin(),idN_creases.end(),0);

    getline(infile, line);

    if ( bool(infile) )
    {
        for ( int i = 0; i < nPts; i++ )
        {
            if ( i > 0 )
                getline(infile, line);

            if ( infile )
            {
                if (line.empty())
                    throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has a blank line.");

                std::istringstream iss(line);
                vector<string> tokens{istream_iterator<string>{iss},
                                      istream_iterator<string>{}};

                if (tokens.size() != DOF )
                    throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                        ") has a line with an inconsistent number of nodal coordinates.");

                for ( int n = 0; n < DOF; n++)
                    u_nodes.push_back(stod(tokens[n]));
            }
            else
                throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has finished before the end of reading. Inconsistent data has been provided.");

        }

        getline(infile, line);
        if ( infile )
        {
            if (line.empty())
                throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has a blank line.");

            std::istringstream iss(line);
            vector<string> tokens{istream_iterator<string>{iss},
                                  istream_iterator<string>{}};

            if (tokens.size() != gDOF )
                throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                    ") has a line with an inconsistent number of nodal coordinates.");

            for ( int n = 0; n < gDOF; n++)
                globalU.push_back(stod(tokens[n]));
        }
        else
            throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has finished before the end of reading. Inconsistent data has been provided.");

        getline(infile, line);
        if ( infile )
        {
            if (line.empty())
                throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has a blank line.");

            std::istringstream iss(line);
            vector<string> tokens{istream_iterator<string>{iss},
                                  istream_iterator<string>{}};

            if (tokens.size() != gAux )
                throw runtime_error("loadFaceMesh: The input file (" + fileName +
                                    ") has a line with an inconsistent number of nodal coordinates.");

            for ( int n = 0; n < gAux; n++)
                globalV.push_back(stod(tokens[n]));
        }
        else
            throw runtime_error("loadFaceMesh: The input file (" + fileName + ") has finished before the end of reading. Inconsistent data has been provided.");
    }

}

void tissueMesh::loadMesh( string fileName , int _setConstraintflag, int _setLinearConstraintsflag, int _restartflag)
{
    int nFaces=0;
    string infoFileName = fileName + "_info.txt";

    ifstream inInfoFile(infoFileName);

    string line;
    getline(inInfoFile, line);
    nFaces = stoi(line);

    setNItem(nFaces);
    DistributedData::Update();

    setConstraintflag        = _setConstraintflag;
    setLinearConstraintsflag = _setLinearConstraintsflag;
    restartflag              = _restartflag;

    for ( int n = 0; n < nFaces; n++ )
    {
        if ( isItemInPart(n) )
        {
            faceMesh fmesh;
            fmesh.loadMesh(fileName + "_" + to_string(n)+".txt", setConstraintflag);

            meshes.push_back(fmesh);

        }
    }
}

void faceMesh::saveMesh(string fileName)
{
    ofstream outfile(fileName);



    if(!outfile.is_open())
        throw runtime_error("loadFaceMesh: The output file (" + fileName + ") cannot be opened.");

    outfile << faceType << endl;

    for ( auto nbor: nBorFaces)
        outfile << nbor << " ";
    outfile << endl;

    outfile << nPts << endl;
    outfile << nElem << endl;

    for ( int i = 0; i < nPts; i++ )
    {
        for ( int n = 0; n < nDim; n++)
            outfile << x_nodes[nPts*n+i] << " ";
        outfile << endl;
    }

    for ( int e = 0; e < nElem; e++ )
    {
        for ( int n = 0; n < nVert; n++)
            outfile << connec[e*nVert+n] << " ";
        outfile << endl;
    }

    for ( int i = 0; i < nPts; i++ )
    {
        for (int dof=0; dof < nDim; dof++)
        {
            int nMasters = masterNodes[nPts*dof + i].size();

            for (int j=0; j < nMasters; j++)
            {
                outfile << masterNodes[nPts*dof + i][j].first << " " << masterNodes[nPts*dof + i][j].second << " " << masterNodesPerFlag[nPts*dof + i][j] << " ";
            }

            outfile << endl;
        }
    }

    for ( int i = 0; i < nPts; i++ )
    {

        for ( int n = 0; n < nDim; n++)
            outfile << cn_nodes[nPts*n+i] << " ";
        outfile << endl;
    }

    for ( int i = 0; i < nPts; i++ )
    {
        for ( int n = 0; n < DOF; n++)
            outfile << nodeDOFs->getValue(n,i,IndexType::Global) << " ";
        outfile << endl;
    }

    for ( int n = 0; n < gDOF; n++)
        outfile << gDOFS->getValue(n,0,IndexType::Global) << " ";
    outfile << endl;

    for ( int n = 0; n < gAux; n++)
        outfile << auxV->getValue(n,0,IndexType::Global) << " ";

}

void tissueMesh::saveMesh( string fileName )
{
    string infoFileName = fileName + "_info.txt";

    ofstream outInfoFile(infoFileName);
    outInfoFile << nItem() << endl;

    for ( int n = 0; n < loc_nItem(); n++ )
            meshes[n].saveMesh(fileName + "_" + to_string(n+offs_nItem())+".txt");
}

void tissueMesh::outputInfo ( )
{
    for ( int n = 0; n < loc_nItem(); n++ )
    {
        auto mesh = meshes[n];

        cout << "My Rank: " << myRank() << endl;
        cout << "Local Face ID: " << n << " " << "Global Face ID " << n+offs_nItem() << endl;
        cout << "nPts:" << mesh.nPts << ", nElem:" << mesh.nElem << endl;

        cout << "nbors:" << " ";
        for ( auto nbor : mesh.nBorFaces )
            cout << nbor << " ";
        cout << endl;

        cout << "coords:" << " " << endl;
        for ( int i = 0; i < mesh.nPts; i++ )
            cout << "Node " << i << ": " << mesh.x_nodes[mesh.nPts*0+i] << " "<< mesh.x_nodes[mesh.nPts*1+i] << " "<< mesh.x_nodes[mesh.nPts*2+i] << endl;
        cout << endl;


        cout << "connec:" << " " << endl;
        for ( int i = 0; i < mesh.nElem; i++ )
            cout << "Elem " << i << ": " << mesh.connec[mesh.nVert*i+0] << " "<< mesh.connec[mesh.nVert*i+1] << " "<< mesh.connec[mesh.nVert*i+2] << endl;
        cout << endl;

        cout << "masters:" << " " << endl;
        for ( int i = 0; i < mesh.nPts; i++ )
        {
            cout << "Node " << i << " has " << mesh.masterNodes[i].size() << " masters: ";
            for (auto g: mesh.masterNodes[i])
                cout << "Face ID " << g.first << " Node ID "<< g.second << ", ";
            cout << endl;
        }

        cout << endl;
        cout << endl;
    }
}

void tissueMesh::generateDistMeshes()
{
    for (int i = 0; i < nItem(); i++)
    {
        //Generate basic mesh
        RCP<BasicMeshGenerator> _mesh = rcp(new BasicMeshGenerator);
        _mesh->setMesh(ElemType::Triang, BasisFuncType::Linear, 1);
        _mesh->setMeshType(MeshType::Sequential);
        if (isItemInPart(i))
        {
            faceMesh *fmesh = &meshes[locIdx(i)];
            _mesh->setLocNPts(fmesh->nPts);
            _mesh->setLocNElem(fmesh->nElem);
            _mesh->setDistCoords(fmesh->x_nodes);
            _mesh->setDistConnec(fmesh->connec);
            _mesh->setDistCreases(fmesh->idN_creases);
            _mesh->_eflags.resize(fmesh->nElem);
        }

        //Distribute the mesh
        RCP<DistributedMesh> _disMesh = rcp(new DistributedMesh);
        _disMesh->setMesh(_mesh);
        _disMesh->setBalanceMesh(false);
        _disMesh->Update();
        //Save it in vector
        disMeshes.push_back(_disMesh);
    }
}

void tissueMesh::generateMechanics() // Now called DOFsHandler
{
    int  DOF = 3;
    int gDOF = 7;

    for ( int i = 0; i < nItem(); i++)
    {
        RCP<DOFsHandler> _mech = rcp(new DOFsHandler(disMeshes[i]));

        if ( isItemInPart(i))
        {
            int locI = locIdx(i);

            switch ( meshes[locI].faceType )
            {
                case 0:
                    _mech->setNameTag("apical"+to_string(i));
                    break;
                case 1:
                    _mech->setNameTag("basal"+to_string(i));
                    break;
                case 2:
                    _mech->setNameTag("lateral"+to_string(i));
                    break;
                case 3:
                    _mech->setNameTag("lL"+to_string(i));
                    break;
                case 4:
                    _mech->setNameTag("lR"+to_string(i));
                    break;
                case 5:
                    _mech->setNameTag("lB"+to_string(i));
                    break;
                case 6:
                    _mech->setNameTag("lT"+to_string(i));
                    break;
            }
        }
        _mech->setNumDOFs(DOF);
        _mech->setNumNodeAuxF(3);   // to store the nodal forces
        _mech->Update();

        RCP<DistributedMesh> _gloMesh  = rcp(new DistributedMesh);
        _gloMesh->setMeshRelation(MeshRelation::GlobConstr, disMeshes[i]);
        _gloMesh->setMasterProcessor(getItemPartition(i));
        _gloMesh->setBalanceMesh(false);
        _gloMesh->Update();

        RCP<DOFsHandler> _gmech = rcp(new DOFsHandler(_gloMesh));
        _gmech->setNameTag("gcons"+to_string(i));
        _gmech->setNumDOFs(gDOF);
        _gmech->setNumNodeAuxF(7); // to store the local-monge basis // not sure why 7 and not 6 (basis vector 3D components)
        _gmech->Update();

        if(isItemInPart(i))
        {
            int locI      = locIdx(i);

            meshes[locI].nodeDOFs =  _mech->nodeDOFs;
            meshes[locI].auxF     =  _mech->nodeAuxF;
            meshes[locI].gDOFS    = _gmech->nodeDOFs;
            meshes[locI].auxV     = _gmech->nodeAuxF;

            // Read from input files to do a restart
            if ( meshes[locI].u_nodes.size() > 0 )
            {
                for ( int j = 0; j < meshes[locI].nPts; j++ )
                {
                    for ( int n = 0; n < meshes[locI].DOF; n++ )
                    {
                        meshes[locI].nodeDOFs->setValue(n,j,IndexType::Local,meshes[locI].u_nodes[j*DOF+n]);
                    }
                }
            }
            if ( meshes[locI].globalU.size() > 0 )
            {
                for ( int n = 0; n < meshes[locI].gDOF; n++ )
                {
                    meshes[locI].gDOFS->setValue(n,0,IndexType::Local,meshes[locI].globalU[n]);
                }
            }
            if ( meshes[locI].globalV.size() > 0 )
            {
                for ( int n = 0; n < meshes[locI].gAux; n++ )
                {
                    meshes[locI].auxV->setValue(n,0,IndexType::Local,meshes[locI].globalV[n]);
                }
            }

            int loc_nPts = meshes[locI].nPts;

            // If not a restart, initialize the DOFs and local-Monge basis to the default values
            if (restartflag == 0)
            {
                //FIXME: move this to a function!
                //Calculate basis
                int n0e = disMeshes[i]->_connec->getNbor(0, 0, IndexType::Local);
                int n1e = disMeshes[i]->_connec->getNbor(0, 1, IndexType::Local);
                int n2e = disMeshes[i]->_connec->getNbor(0, 2, IndexType::Local);

                vector<double> x0e = disMeshes[i]->nodeCoords(n0e);
                vector<double> x1e = disMeshes[i]->nodeCoords(n1e);
                vector<double> x2e = disMeshes[i]->nodeCoords(n2e);

                double g1e[3] = {};
                double g2e[3] = {};

                Array::Copy(g1e, 3, x1e.data());
                Math::AXPY(g1e, 3, -1.0, x0e.data());
                Array::Copy(g2e, 3, x2e.data());
                Math::AXPY(g2e, 3, -1.0, x0e.data());

                Math::AX(g1e, 3, 1.0 / Math::Norm3D(g1e));

                Math::AXPY(g2e, 3, -Math::Dot3D(g2e, g1e), g1e);
                Math::AX(g2e, 3, 1.0 / Math::Norm3D(g2e));

                for (int n = 0; n < 3; n++) {
                    _gmech->nodeAuxF->setValue(0 + n, 0, IndexType::Global, g1e[n]);
                    _gmech->nodeAuxF->setValue(3 + n, 0, IndexType::Global, g2e[n]);
                }

                _gmech->nodeDOFs->setValue(0, 0, IndexType::Local, 0.0);  // Cell pressure
                _gmech->nodeDOFs->setValue(1, 0, IndexType::Local, 1.0);  // C0
                _gmech->nodeDOFs->setValue(2, 0, IndexType::Local, 0.03); // Initial cortical density

                _gmech->nodeDOFs->setValue(3, 0, IndexType::Local, 1.0); //G11
                _gmech->nodeDOFs->setValue(4, 0, IndexType::Local, 0.0); //G12
                _gmech->nodeDOFs->setValue(5, 0, IndexType::Local, 1.0); //G22

                _gmech->nodeDOFs->setValue(6, 0, IndexType::Local, 0.0); // Lumen pressure

                // Initialize nodeDOFs and nodeAUX values
                for (int j = 0; j < loc_nPts; j++) {
                    vector<double> x = _mech->mesh->nodeCoords(j, IndexType::Global);
                    _mech->nodeDOFs->setValue(0, j, IndexType::Global, x[0]);
                    _mech->nodeDOFs->setValue(1, j, IndexType::Global, x[1]);
                    _mech->nodeDOFs->setValue(2, j, IndexType::Global, x[2]);

                    // to store nodal forces
                    _mech->nodeAuxF->setValue(0, j, IndexType::Global, 1.0);
                    _mech->nodeAuxF->setValue(1, j, IndexType::Global, 1.0);
                    _mech->nodeAuxF->setValue(2, j, IndexType::Global, 1.0);
                }
            }

			//~ cout << "i : " << i << ", loc_nPts : " << loc_nPts << ", locI : " << locI << ", meshes[locI].cn_nodes[meshes[locI].nPts : " << meshes[locI].cn_nodes[meshes[locI].nPts] << endl;

            // Set dirichlet constraints
            for ( int j = 0; j < loc_nPts; j++ )
            {
                if (setConstraintflag == 1)
                {
                    for ( int n = 0; n < meshes[locI].nDim; n++ )
                    {
                        if ( meshes[locI].cn_nodes[meshes[locI].nPts*n+j] > 0)
                        {
                            _mech->setConstraint(n, j, IndexType::Local, 0.0); // n = DOF, j = local node index (of that face/mesh i)
                        }
                    }
                }
            }
        }

        _mech->nodeDOFs0->setValue(_mech->nodeDOFs);
        _gmech->nodeDOFs0->setValue(_gmech->nodeDOFs);

        _mech->UpdateGhosts();
        _gmech->UpdateGhosts();

        mechs.push_back(_mech); // for nodes DOFs (nodes position)
        mechs.push_back(_gmech); // for global DOFs (density, pressure, etc.)
    }
}

void tissueMesh::saveVTK(string filename)
{
    std::vector<int>  offNodes;
    std::vector<int> goffNodes;

    offNodes.resize(loc_nItem()+1);
    goffNodes.resize(loc_nItem()+1); // global offset

    int loc_nPts{};
    int loc_nElem{};

    int n = 0;
    offNodes[0] = 0;
    for ( int i = 0; i < loc_nItem(); i++ )
        offNodes[i+1] = offNodes[i] + meshes[i].nPts;

    loc_nPts = offNodes[loc_nItem()];

    DistributedData partoffNodes;
    partoffNodes.setLocNItem(loc_nPts);
    partoffNodes.Update();

    for ( int i = 0; i < loc_nItem()+1; i++ )
        goffNodes[i] = offNodes[i] + partoffNodes.offs_nItem();

    vector<int> sconnec={};
    vector<double> sx_nodes={};
    vector<int> screases={};
    vector<double> su_nodes={};


    sx_nodes.resize(loc_nPts*meshes[0].nDim);

    for ( int i = 0; i < loc_nItem(); i++ )
    {
        auto _mesh        = meshes[i];
        auto _connec      = _mesh.connec;
        auto _x_nodes     = _mesh.x_nodes;
        auto _idN_creases = _mesh.idN_creases;
        int  _nVert       = _mesh.nVert;
        int  _nDim        = _mesh.nDim;
        int  _nPts        = _mesh.nPts;
        int  _nElem       = _mesh.nElem;

        loc_nElem += _nElem;
        for ( int e = 0; e < _nElem; e++ )
        {
            for ( int n = 0; n < _nVert; n++)
                sconnec.push_back(_connec[e*_nVert+n]+goffNodes[i]);
        }

        for ( int j = 0; j <_nPts; j++ )
        {
            for ( int n = 0; n < _nDim; n++ )
                sx_nodes[loc_nPts*n+j+offNodes[i]] = _x_nodes[_nPts*n+j];

        }

        screases.insert(screases.end(), _idN_creases.begin(), _idN_creases.end());
    }

    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);

    RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
    mesh->setMesh(ElemType::Triang,BasisFuncType::Linear,1);

    mesh->setNDim(meshes[0].nDim);
    mesh->_loc_nPts  = loc_nPts;
    mesh->_loc_nElem = loc_nElem;

    mesh->_connec   = sconnec;
    mesh->_x_nodes  = sx_nodes;
    mesh->_creases  = screases;
    mesh->_eflags.resize(loc_nElem);

    int sum_nElem;
    Barrier();
    MPI_Allreduce(&loc_nElem, &sum_nElem, 1, MPI_INT, MPI_SUM, _comm);

    mesh->_nPts  = 1;
    mesh->_nElem = sum_nElem;
    mesh->_nVert = 1;
    mesh->_pDim  = 2;

    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(false);
    disMesh->Update();

//    cout << disMesh->myRank() << ": " << meshes[0].DOF << endl;

    // Generate dummy mechanics
    RCP<DOFsHandler> mech = rcp(new DOFsHandler(disMesh));
    mech->setNumDOFs(meshes[0].DOF);
    mech->setNumNodeAuxF(14);
    mech->Update();

    for ( int i = 0; i < loc_nItem(); i++ )
    {
        auto _mesh        = meshes[i];
        int  _nPts        = _mesh.nPts;
        int  _DOF         = _mesh.DOF;

        for ( int j = 0; j <_nPts; j++ )
        {
			// writting the nodes deformed coordinates in the dummy mechanics
            for ( int n = 0; n < _DOF; n++ )
            {
                double val = meshes[i].nodeDOFs->getValue(n,j,IndexType::Global);
                mech->nodeDOFs->setValue(n,j+goffNodes[i],IndexType::Global,val);
            }

			// writting the global DOF in the dummy mechanics
            for ( int n = 0; n < 3; n++ )
            {
                double val = meshes[i].gDOFS->getValue(n, 0, IndexType::Local);
                mech->nodeAuxF->setValue(n, j + goffNodes[i], IndexType::Global,val);
            }

			// writting the auxiliary field (nodal forces) in the dummy mechanics
            for ( int n = 0; n < 3; n++ )
            {
                double val = meshes[i].auxF->getValue(n, j, IndexType::Local);
                mech->nodeAuxF->setValue(3 + n, j + goffNodes[i], IndexType::Global,val);
            }

            double G11 = meshes[i].gDOFS->getValue(0+3, 0, IndexType::Local);
            double G12 = meshes[i].gDOFS->getValue(1+3, 0, IndexType::Local);
            double G22 = meshes[i].gDOFS->getValue(2+3, 0, IndexType::Local);

            double lumpressure = meshes[i].gDOFS->getValue(6, 0, IndexType::Local);

			// writting the basis vector in the dummy mechanics
            double e1[3];
            e1[0] = meshes[i].auxV->getValue(0,0,IndexType::Global);
            e1[1] = meshes[i].auxV->getValue(1,0,IndexType::Global);
            e1[2] = meshes[i].auxV->getValue(2,0,IndexType::Global);
            double e2[3];
            e2[0] = meshes[i].auxV->getValue(3,0,IndexType::Global);
            e2[1] = meshes[i].auxV->getValue(4,0,IndexType::Global);
            e2[2] = meshes[i].auxV->getValue(5,0,IndexType::Global);

            double activAMP = meshes[i].auxV->getValue(6,0,IndexType::Global);

			// writting the auxiliary field metric tensor component in the dummy mechanics
            double GXX = G11 * e1[0] * e1[0] + G12 * (e1[0] * e2[0]+ e2[0] * e1[0]) + G22 *  e2[0] * e2[0];
            double GXY = G11 * e1[0] * e1[1] + G12 * (e1[0] * e2[1]+ e2[0] * e1[1]) + G22 *  e2[0] * e2[1];
            double GXZ = G11 * e1[0] * e1[2] + G12 * (e1[0] * e2[2]+ e2[0] * e1[2]) + G22 *  e2[0] * e2[2];
            double GYY = G11 * e1[1] * e1[1] + G12 * (e1[1] * e2[1]+ e2[1] * e1[1]) + G22 *  e2[1] * e2[1];
            double GYZ = G11 * e1[1] * e1[2] + G12 * (e1[1] * e2[2]+ e2[1] * e1[2]) + G22 *  e2[1] * e2[2];
            double GZZ = G11 * e1[2] * e1[2] + G12 * (e1[2] * e2[2]+ e2[2] * e1[2]) + G22 *  e2[2] * e2[2];

            mech->nodeAuxF->setValue(6 , j + goffNodes[i], IndexType::Global, GXX);
            mech->nodeAuxF->setValue(7 , j + goffNodes[i], IndexType::Global, GXY);
            mech->nodeAuxF->setValue(8 , j + goffNodes[i], IndexType::Global, GXZ);
            mech->nodeAuxF->setValue(9 , j + goffNodes[i], IndexType::Global, GYY);
            mech->nodeAuxF->setValue(10, j + goffNodes[i], IndexType::Global, GYZ);
            mech->nodeAuxF->setValue(11, j + goffNodes[i], IndexType::Global, GZZ);

            mech->nodeAuxF->setValue(12, j + goffNodes[i], IndexType::Global, lumpressure);
            mech->nodeAuxF->setValue(13, j + goffNodes[i], IndexType::Global, activAMP);
        }
    }


    // mech->printFileLegacyVtk(filename,true);
    // mech->printFile(filename,TextMode,true);
}

RCP<HiPerProblem> tissueMesh::generateHiPerMechanics(RCP<UserStructure> userStr, int gPts)
{
    if ( !updated )
        throw runtime_error("tissueMesh has not been previously updated. Can't generate HiPerProblem out of nothing!");

    RCP<HiPerProblem> hiperMech = rcp(new HiPerProblem("HiperObject"));
    hiperMech->setUserStructure(userStr);
    hiperMech->setDOFsHandlers(mechs);

    for ( int i = 0; i < nItem(); i++)
    {
        string integName = "Integ"+to_string(i);

        hiperMech->setIntegration(integName, {mechs[2*i+0]->nameTag(),mechs[2*i+1]->nameTag()});
        //hiperMech->setIntegration_CubatureStd(integName, "CubatureGauss", gPts);
        hiperMech->setCubatureGauss(integName, gPts);
        if (setConstraintflag == 1)
        {
            hiperMech->setElementFillings(integName, LS_K);
            hiperMech->setGlobalIntegrals({"avgF00","avgF01","avgF10","avgF11","avgF22","RefVol","SurfEnerg","delRay"});
        }
        else if (setConstraintflag == 0)
        {
            // Postprocessing hipermech: uses LS_K_pp to get correct forces for creep loading condition
            hiperMech->setGlobalIntegrals({"avgF00","avgF01","avgF10","avgF11","avgF22","RefVol","SurfEnerg","delRay"});
            hiperMech->setElementFillings(integName, LS_K_pp);
        }
    }

    int loc_nFaces = loc_nItem();

    // Setting linear constraints (master-slave)
    for (int n = 0; n < loc_nFaces; n++)
    {
        int loc_nPts = meshes[n].nPts;

        for (int i = 0; i < loc_nPts; i++)
        {
            int nMasters = 0;
            int nDim     = meshes[n].nDim;

            for (int dof = 0; dof < nDim; dof++)
            {
                nMasters = (meshes[n].masterNodes[loc_nPts*dof + i].size());

                if (nMasters > 0)
                {
                    double weight = 1.0 / nMasters;

                    for (int masterID = 0; masterID < nMasters; masterID++)
                    {
                        auto master = meshes[n].masterNodes[loc_nPts*dof + i][masterID];
                        int face = master.first;
                        int node = master.second;
                        double perval = meshes[n].masterNodesPerFlag[loc_nPts*dof + i][masterID];
                        // If generating the postprocessing hipermechanics and simulating a periodic box, then do not
                        // set any linear constraints to be able to get the nodal forces from which the tissue tension
                        // is calculated. In any other scenario, set the linear constraints.
                        if (setLinearConstraintsflag == 1)
                        {
                            hiperMech->setLinearConstraint({2 * (n + offs_nItem()), dof, i, IndexType::Global},
                                                           {2 * face, dof, node, IndexType::Global}, weight);
                        }
                    }
                }
            }
        }

        // Set cell pressures and bulk concentration to be the same for all faces belonging to the same cell
        int minNBorface = *min_element(meshes[n].nBorFaces.begin(), meshes[n].nBorFaces.end());
        int face = n + offs_nItem();

        if (face > minNBorface)
        {
            hiperMech->setLinearConstraint({2 * (n + offs_nItem()) + 1, 0, 0, IndexType::Global},
                                           {2 * minNBorface + 1, 0, 0, IndexType::Global});
            hiperMech->setLinearConstraint({2 * (n + offs_nItem()) + 1, 1, 0, IndexType::Global},
                                           {2 * minNBorface + 1, 1, 0, IndexType::Global});
        }

        // Set lumen pressure to be the same as defined in the gmech of the 0th face
        if (face > 0)
        {
            hiperMech->setLinearConstraint({2 * (n + offs_nItem()) + 1, 6, 0, IndexType::Global},
                                           {1, 6, 0, IndexType::Global});
        }
    }

    hiperMech->Update();
    hiperMech->UpdateGhosts();

    return hiperMech;
}

void LS_K (Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    //------------------------------------------------------------------
    // [1] INPUT definition

    //[1.1] Load main subfill structure:
    // Main DOFS:
    // 0, 1, 2: position of the deformed mesh
    // 3: actin density
    // 4,5,6: components of the reference metric tensor
    SubFillStructure& subFill = (*fillStr)[0];

    int nDim  = subFill.nDim;
    int DOF   = subFill.numDOFs;                    //Number of degrees of freedom (3)
    int eNN   = subFill.eNN;                        //Number of neighbors to the element (3 Linear Elements)
    int pDim  = subFill.pDim;                       //Parametric dimension (2)
    double *xe_nodes  = subFill.nborCoords.data();  //Reference surface positions
    double *ue_nodes  = subFill.nborDOFs.data();    //Degrees of freedom
    double *ue_nodes0 = subFill.nborDOFs0.data();   //Degrees of freedom of previous time-step

    int N_k = DOF*eNN; //Row size

    double *fe_nodes  = subFill.nborAuxF.data();  // Auxillary data defined on the nodes

    //FIXME: reverse map?
    std::map<std::string,int>::const_iterator it;
    string key = {};
    for (it = fillStr->_dhandsTagIdx.begin(); it != fillStr->_dhandsTagIdx.end(); ++it)
    {
        if (it->second == 0) // 0 - points to the master mechanics, 1 - points to the global mechanics
        {
            key = it->first;
            break;
        }
    }

    // Extract the faceID from the key string
    int faceID = std::atoi(first_numberstring(key).c_str());

    //[1.1] Load global constraint subfill structure with 1 DOF (internal pressure)
    SubFillStructure& g_subFill = (*fillStr)[1];
    int gDOF   = g_subFill.numDOFs; 				//Number of degrees of freedom (7)
    int geNN   = g_subFill.eNN;
    int gN_k   = geNN * gDOF;
    double *g_ue_nodes  = g_subFill.nborDOFs.data();
    double *g_ue_nodes0 = g_subFill.nborDOFs0.data();
    double *g_ae_nodes  = g_subFill.nborAuxF.data(); //Degrees of freedom of previous time-step

    double pressure = g_ue_nodes[0];

    double conc0 = g_ue_nodes0[1];
    double conc  = g_ue_nodes[1];

    double dens0 = g_ue_nodes0[2];
    double dens  = g_ue_nodes[2];

    double lumpressure = g_ue_nodes[6]; // Lumen pressure

    //[1.1] Load basis functions and derivatives
    double *p_k  = subFill.nborBFsDers(0);
    double *dp_k = subFill.nborBFsDers(1);

    //[1.2] Load model parameters
    vector<double>   dparam = fillStr->userStr->dparam;
    double deltat    = dparam[0];
    double mu        = dparam[1];
    double lambda    = dparam[2];
    double kp        = dparam[3] * deltat;
    double kd        = dparam[4] * deltat;
    double bVisc     = dparam[5];
    double lame1     = dparam[6] * deltat;
    double lame2     = dparam[7] * deltat;
    double eta_f     = dparam[11];
    double eta_f_basal = dparam[18];

    vector<double> sigma_e  = {0.0, 0.0, 0.0, 0.0}; // applied stress
    sigma_e[0]       = dparam[12];
    sigma_e[1]       = dparam[13];
    sigma_e[2]       = dparam[14];
    sigma_e[3]       = dparam[15];

    double memb_thresh_high = dparam[16];
    double memb_thresh_low  = dparam[19];
    double memb_lam         = dparam[17];

    double vdomedot         = dparam[20];
    double xactivlow        = dparam[21];
    double xactivhigh       = dparam[22];
    double activAMP         = dparam[23];
    double activwindowlow   = dparam[24];
    double activwindowhigh  = dparam[25];

    double penaltyCoeff     = dparam[26];

    vector<int>   iparam = fillStr->userStr->iparam;
    int creepleftflag   = iparam[0];
    int creeprightflag  = iparam[1];
    int creeptopflag    = iparam[2];
    int creepbottomflag = iparam[3];

    double activ{};
    int    facetag   = 0;

    switch(key[0])
    {
        case 'a':
            activ = dparam[8] * deltat;
            facetag = 0;
            break;
        case 'b':
            activ = dparam[9] * deltat;
            facetag = 1;
            eta_f = eta_f_basal; // friction on basal surface
            break;
        case 'l':
            activ = dparam[10] * deltat;
            facetag = 2;
            break;
    }

    // Determine which boundary does the lateral face belong to?
    int    boundarytag = -1; // for apical and basal should remain unchanged
    switch(key[1])
    {
        case 'T':
            boundarytag = 0;
            break;
        case 'B':
            boundarytag = 1;
            break;
        case 'L':
            boundarytag = 2;
            break;
        case 'R':
            boundarytag = 3;
            break;
    }

    if(fillStr->userStr->bparam[faceID])
    {
		eta_f = 100;
		//~ // cout << " eta_f has been changed to : " << eta_f << ", for faceTag : " << facetag << ", and ID : " << faceID << endl;
	}

    //------------------------------------------------------------------
    // [2] OUTPUT definition
    std::vector<double>& rhs_k    = fillStr->Bk(0);   // <<=== MAIN OUTPUT
    std::vector<double>& g_rhs_k  = fillStr->Bk(1);   // <<=== MAIN OUTPUT
    std::vector<double>& Kmat_k   = fillStr->Ak(0,0); // <<=== MAIN OUTPUT
    std::vector<double>& Qmat_k   = fillStr->Ak(0,1); // <<=== MAIN OUTPUT
    std::vector<double>& Rmat_k   = fillStr->Ak(1,0); // <<=== MAIN OUTPUT
    std::vector<double>& Lmat_k   = fillStr->Ak(1,1); // <<=== MAIN OUTPUT

    //----------
    //Deformed
    double  x[3] = {};
    double e1[3] = {};
    double e2[3] = {};
    double  f[3] = {};

    for ( int i = 0; i < eNN; i++ )
    {
        for ( int n = 0; n < nDim; n++ )
        {
            x[n]  +=         p_k[i] * ue_nodes[DOF*i+n];
            e1[n] += dp_k[pDim*i+0] * ue_nodes[DOF*i+n];
            e2[n] += dp_k[pDim*i+1] * ue_nodes[DOF*i+n];

            f[n]  +=         p_k[i] * fe_nodes[DOF*i+n];
        }
    }

	//~ if (x[2] < -0.01 && facetag ==1 )
		//~ {
			//~ eta_f = 1;
			//~ // vdomedot = 0;
		//~ }

    //Metric tensor
    double Ip[4];
    Ip[0] = Math::Dot3D(e1,e1);
    Ip[1] = Math::Dot3D(e1,e2);
    Ip[2] = Ip[1];
    Ip[3] = Math::Dot3D(e2,e2);

    double det = Math::DetMat2x2(Ip);
    double J   = sqrt(det);

    //Inverse
    double iIp[4];
    Math::Invert2x2(iIp,Ip);

    double normal[3];
    Math::Cross(normal,e1,e2);
    Math::AX(normal,nDim,1.0/J);

    double xn = Math::Dot3D(x,normal);

    //----------
    //Previous time-step
    double  x0[3] = {};
    double e10[3] = {};
    double e20[3] = {};

    for ( int i = 0; i < eNN; i++ )
    {
        for ( int n = 0; n < nDim; n++ )
        {
            x0[n]  +=         p_k[i] * ue_nodes0[DOF*i+n];
            e10[n] += dp_k[pDim*i+0] * ue_nodes0[DOF*i+n];
            e20[n] += dp_k[pDim*i+1] * ue_nodes0[DOF*i+n];
        }
    }

    //Metric tensor
    double Ip0[4];
    Ip0[0] = Math::Dot3D(e10,e10);
    Ip0[1] = Math::Dot3D(e10,e20);
    Ip0[2] = Ip0[1];
    Ip0[3] = Math::Dot3D(e20,e20);

    double det0 = Math::DetMat2x2(Ip0);
    double J0   = sqrt(det0);

    //Inverse
    double iIp0[4];
    Math::Invert2x2(iIp0,Ip0);

    double normal0[3];
    Math::Cross(normal0,e10,e20);
    Math::AX(normal0,nDim,1.0/J0);

    double x0n0 = Math::Dot3D(x0,normal0);


    //----------
    //Reference
    double  xR[3] = {};
    double e1R[3] = {};
    double e2R[3] = {};

    for ( int i = 0; i < eNN; i++ )
    {
        for ( int n = 0; n < nDim; n++ )
        {
            xR[n]  +=         p_k[i] * xe_nodes[nDim*i+n];
            e1R[n] += dp_k[pDim*i+0] * xe_nodes[nDim*i+n];
            e2R[n] += dp_k[pDim*i+1] * xe_nodes[nDim*i+n];
        }
    }


    double  xminusx0[3] = {};
    for (int i = 0; i < nDim; i++)
		xminusx0[i] = x[i] - x0[i];

    //Metric tensor
    double IpR[4];
    IpR[0] = Math::Dot3D(e1R,e1R);
    IpR[1] = Math::Dot3D(e1R,e2R);
    IpR[2] = IpR[1];
    IpR[3] = Math::Dot3D(e2R,e2R);

    double detR = Math::DetMat2x2(IpR);
    double JR   = sqrt(detR);

    //Inverse
    double iIpR[4];
    Math::Invert2x2(iIpR,IpR);

    double normalR[3];
    Math::Cross(normalR,e1R,e2R);
    Math::AX(normalR,nDim,1.0/JR);

    double xRnR = Math::Dot3D(xR,normalR);

    //----------
    //Rate-of-deformation
    double d[4]    = {};
    double d_Cc[4] = {};
    double d_CC[4] = {};

    Array::Copy(d,4,Ip);
    Math::AXPY(d,4, -1.0, Ip0);

    Math::MatProduct(d_Cc,2,2,2,iIp0,d);
    Math::MatProduct(d_CC,2,2,2,d_Cc,iIp0);

    double trd = (J-J0)/J0;

    double T[4]={};
    double iT[4]={};
    double GRef[4]={};
    double iGRef[4]={};
    double GRef0[4]={};
    double iGRef0[4]={};
    double dGRef[4]={};
    double Voigt[12]={};
    double dG_GRef[12]={}, dG_GRef_Cc[12]={}, dG_GRef_cc[12]={};
    Voigt[4*0+2*0+0] = 1.0; Voigt[4*1+2*0+0] = 0.0; Voigt[4*2+2*0+0] = 0.0;
    Voigt[4*0+2*0+1] = 0.0; Voigt[4*1+2*0+1] = 1.0; Voigt[4*2+2*0+1] = 0.0;
    Voigt[4*0+2*1+0] = 0.0; Voigt[4*1+2*1+0] = 1.0; Voigt[4*2+2*1+0] = 0.0;
    Voigt[4*0+2*1+1] = 0.0; Voigt[4*1+2*1+1] = 0.0; Voigt[4*2+2*1+1] = 1.0;

    double *g1e = &g_ae_nodes[0];
    double *g2e = &g_ae_nodes[3];

    LocMongeParam::matChangeBasis(T, g1e, g2e, e1R, e2R);
    Math::Invert2x2(iT,T);

    double one = 1.0;
    CalcdGIGRef( dG_GRef, iT, one, Voigt );

    Math::AXPY(GRef,4,g_ue_nodes[3],&dG_GRef[4*0]);
    Math::AXPY(GRef,4,g_ue_nodes[4],&dG_GRef[4*1]);
    Math::AXPY(GRef,4,g_ue_nodes[5],&dG_GRef[4*2]);

    Math::AXPY(GRef0,4,g_ue_nodes0[3],&dG_GRef[4*0]);
    Math::AXPY(GRef0,4,g_ue_nodes0[4],&dG_GRef[4*1]);
    Math::AXPY(GRef0,4,g_ue_nodes0[5],&dG_GRef[4*2]);

    Math::Invert2x2(iGRef,GRef);
    Math::Invert2x2(iGRef0,GRef0);

    Array::Copy(dGRef,4,GRef);
    Math::AXPY(dGRef,4,-1.0,GRef0);

    // increase apical contractility within a given pattern, need to store them for visualization in cortical density
    //~ if (facetag == 0)
    //~ {
        //~ activAMP = getOptoActivationAMP(xR[1],xactivlow,xactivhigh,activwindowlow,activwindowhigh);
        //~ activ    = activAMP * dparam[8] * deltat;
    //~ }

    //Elasticity invariants
    double inva1 = Math::Dot(4,GRef,Ip);
    double sqrtdetG = sqrt(Math::DetMat2x2(GRef));
    double inva2 = sqrtdetG * J;
    double inva22 = inva2*inva2;

    //NeoHookean
    double ener              = lame1 * ( inva1/inva2 - 2.0 ) + lame2 * (inva2-1.0) * (inva2-1.0) ;
    double dinva1_Ener       = lame1 /inva2;
    double dinva2_Ener       = -lame1 * inva1/inva22 + 2.0 * lame2 * (inva2-1.0);
    double ddinva1_Ener      = 0.0;
    double ddinva2_Ener      = 2.0 * lame1 * inva1/(inva2*inva22) + 2.0 * lame2;
    double dinva1dinva2_Ener = -lame1 /inva22;

    //Free energy at the previous timestep
    double inva10    = Math::Dot(4,GRef0,Ip0);
    double sqrtdetG0 = sqrt(Math::DetMat2x2(GRef0));
    double inva20    = sqrtdetG0 * J0;
    double ener0     = lame1 * ( inva10/inva20 - 2.0 ) + lame2 * (inva20-1.0) * (inva20-1.0) ;

    // Global integrations
    // average strain
    fillStr->addToGlobalIntegral("avgF00", x[0] * normalR[0] * JR);
    fillStr->addToGlobalIntegral("avgF01", x[0] * normalR[1] * JR);
    fillStr->addToGlobalIntegral("avgF10", x[1] * normalR[0] * JR);
    fillStr->addToGlobalIntegral("avgF11", x[1] * normalR[1] * JR);
    fillStr->addToGlobalIntegral("avgF22", x[2] * normalR[2] * JR);

    // Reference volume of the cell
    fillStr->addToGlobalIntegral("RefVol", xRnR/3.0 * JR);

    // Active surface energy
    fillStr->addToGlobalIntegral("SurfEnerg", activ*dens0*J/deltat);

    // Incremental Rayleighian, R*deltat
    double delRay = 0;

    // Active power
    delRay += activ*dens0*trd*J0/deltat;

    // Elastic (Need to have F(X) - F(X0))
    delRay += ener * J0 * dens0/deltat - ener0 * J0 * dens0/deltat;

    // Dissipative
    delRay += 0.5 * bVisc * J0 * dens0 * Math::Dot(4,dGRef,dG_GRef_cc)/deltat;

    // Surface friction
    double  v[3] = {};
    Array::Copy(v,3,x);
    Math::AXPY(v,3,-1.0,x0);
    //delRay += 0.5 * J0 * eta_f * Math::Dot(3,v,v)/deltat;

    fillStr->addToGlobalIntegral("delRay", delRay);


    /////////////////////////////////// FILLING THE RHS ///////////////////////////////////


    for ( int i = 0; i < eNN; i++ ) {

        double dxI_Ip[4 * 3] = {}, dxI_Ip_Cc[4 * 3] = {}, dxI_Ip_CC[4 * 3] = {};
        MetricGradient(dxI_Ip, &dp_k[2 * i], e1, e2);

        Math::MatProduct(&dxI_Ip_Cc[0], 2, 2, 2, iIp0, &dxI_Ip[0]);
        Math::MatProduct(&dxI_Ip_Cc[4], 2, 2, 2, iIp0, &dxI_Ip[4]);
        Math::MatProduct(&dxI_Ip_Cc[8], 2, 2, 2, iIp0, &dxI_Ip[8]);

        Math::MatProduct(&dxI_Ip_CC[0], 2, 2, 2, &dxI_Ip_Cc[0], iIp0);
        Math::MatProduct(&dxI_Ip_CC[4], 2, 2, 2, &dxI_Ip_Cc[4], iIp0);
        Math::MatProduct(&dxI_Ip_CC[8], 2, 2, 2, &dxI_Ip_Cc[8], iIp0);

        double dxI_J[3] = {};
        JacobianGradient(dxI_J, &dp_k[2 * i], e1, e2, normal);

        //[1] Shear dissipation
        double dxI_dd[3] = {};
        dxI_dd[0] = 2.0 * Math::Dot(4, &dxI_Ip[0], d_CC);
        dxI_dd[1] = 2.0 * Math::Dot(4, &dxI_Ip[4], d_CC);
        dxI_dd[2] = 2.0 * Math::Dot(4, &dxI_Ip[8], d_CC);

        //FIXME: d is twice d, rescale these terms
        Math::AXPY(&rhs_k[DOF * i], nDim, J0 * mu * dens0, dxI_dd);

        //[2] Dilatation dissipation
        Math::AXPY(&rhs_k[DOF * i], nDim, lambda * trd * dens0, dxI_J);

        //[3] Tension power
        Math::AXPY(&rhs_k[DOF * i], nDim, activ * dens0, dxI_J);

        //[4] Volume constraint
        double dxI_normal[3 * 3] = {};
        double xdxI_normal[3] = {};
        NormalGradient(dxI_normal, &dp_k[2 * i], e1, e2, normal, J, dxI_J);
        NormalGradientU(xdxI_normal, &dp_k[2 * i], e1, e2, normal, 1.0 / J, x);

        Math::AXPY(&rhs_k[DOF * i], nDim, deltat * pressure * J * p_k[i], normal);
        Math::AXPY(&rhs_k[DOF * i], nDim, deltat * pressure * J, xdxI_normal);
        Math::AXPY(&rhs_k[DOF * i], nDim, deltat * pressure * xn, dxI_J);

        //[7] Elasticity (dens0 + kp * conc0 - kd*rho)
        rhs_k[DOF * i + 0] += J0 * dens0 * dinva1_Ener * Math::Dot(4, GRef, &dxI_Ip[0]);
        rhs_k[DOF * i + 1] += J0 * dens0 * dinva1_Ener * Math::Dot(4, GRef, &dxI_Ip[4]);
        rhs_k[DOF * i + 2] += J0 * dens0 * dinva1_Ener * Math::Dot(4, GRef, &dxI_Ip[8]);

        rhs_k[DOF * i + 0] += J0 * dens0 * dinva2_Ener * sqrtdetG * dxI_J[0];
        rhs_k[DOF * i + 1] += J0 * dens0 * dinva2_Ener * sqrtdetG * dxI_J[1];
        rhs_k[DOF * i + 2] += J0 * dens0 * dinva2_Ener * sqrtdetG * dxI_J[2];

        //[8] Surface friction dissipation
        rhs_k[DOF * i + 0] += J0 * eta_f * (x[0] - x0[0]) * p_k[i];
        rhs_k[DOF * i + 1] += J0 * eta_f * (x[1] - x0[1]) * p_k[i];
        rhs_k[DOF * i + 2] += J0 * eta_f * (x[2] - x0[2]) * p_k[i];

        //[9] External power input through tractions only on the desired surfaces
        if ( (boundarytag == 2 && creepleftflag>0) || (boundarytag == 3 && creeprightflag>0) || (boundarytag == 0 && creeptopflag>0) || (boundarytag == 1 && creepbottomflag>0) )
        {
            rhs_k[DOF * i + 0] += -J0 * deltat * (sigma_e[0] * normal0[0] + sigma_e[1] * normal0[1]) * p_k[i];
            rhs_k[DOF * i + 1] += -J0 * deltat * (sigma_e[2] * normal0[0] + sigma_e[3] * normal0[1]) * p_k[i];
        }

        // [10] Membrane elasticity
        // higher threshold
        if (J/JR > memb_thresh_high)
        {
                // Divide by JR^2 for covariance
                rhs_k[DOF * i + 0] += memb_lam * 3 * (J - memb_thresh_high*JR) * (J - memb_thresh_high*JR) * dxI_J[0] /JR/JR;
                rhs_k[DOF * i + 1] += memb_lam * 3 * (J - memb_thresh_high*JR) * (J - memb_thresh_high*JR) * dxI_J[1] /JR/JR;
                rhs_k[DOF * i + 2] += memb_lam * 3 * (J - memb_thresh_high*JR) * (J - memb_thresh_high*JR) * dxI_J[2] /JR/JR;
        }

        // lower threshold
	    if (J/JR < memb_thresh_low)
	    {
                // Divide by JR^2 for covariance
                rhs_k[DOF * i + 0] -= memb_lam * 3 * (J - memb_thresh_low*JR) * (J - memb_thresh_low*JR) * dxI_J[0] /JR/JR;
                rhs_k[DOF * i + 1] -= memb_lam * 3 * (J - memb_thresh_low*JR) * (J - memb_thresh_low*JR) * dxI_J[1] /JR/JR;
                rhs_k[DOF * i + 2] -= memb_lam * 3 * (J - memb_thresh_low*JR) * (J - memb_thresh_low*JR) * dxI_J[2] /JR/JR;
		}

        //~ // [11] Luminal pressure, only on basal cell faces, working against cell pressure on basal surface
        // Implemented as a Lagrangian multiplier
        // Note the -ve sign as basal surface normal points towards the luminal cavity
        if (facetag == 1)
        {
            Math::AXPY(&rhs_k[DOF * i], nDim, -deltat * lumpressure * J * p_k[i], normal);
            Math::AXPY(&rhs_k[DOF * i], nDim, -deltat * lumpressure * J, xdxI_normal);
            Math::AXPY(&rhs_k[DOF * i], nDim, -deltat * lumpressure * xn, dxI_J);
        }


        // Implementing penalty when dome deflates to touch substrate (only for z for the time being)
        //~ if (fillStr->userStr->bparam[faceID])
        //~ // if (facetag == 1)
        //~ {

			//~ rhs_k[DOF * i + 0] += deltat *penaltyCoeff * p_k[i] * J * xminusx0[0];
			//~ rhs_k[DOF * i + 1] += deltat *penaltyCoeff * p_k[i] * J * xminusx0[1];
			//~ rhs_k[DOF * i + 2] += deltat *penaltyCoeff * p_k[i] * J * xminusx0[2];

			//~ rhs_k[DOF * i + 0] += deltat * 0.5*penaltyCoeff * Math::Dot3D(xminusx0, xminusx0) * dxI_J[0];
			//~ rhs_k[DOF * i + 1] += deltat * 0.5*penaltyCoeff * Math::Dot3D(xminusx0, xminusx0) * dxI_J[1];
			//~ rhs_k[DOF * i + 2] += deltat * 0.5*penaltyCoeff * Math::Dot3D(xminusx0, xminusx0) * dxI_J[2];

			// Math::AXPY(&rhs_k[DOF * i], nDim, deltat *0.5*penaltyCoeff* 2 * p_k[i] * J, xminusx0);
			// Math::AXPY(&rhs_k[DOF * i], nDim, deltat * 0.5*penaltyCoeff* Math::Dot3D(xminusx0, xminusx0), dxI_J);
		//~ }


    /////////////////////////////////// FILLING K_MAT ///////////////////////////////////


        for (int j = 0; j < eNN; j++)
        {
            double Kmat_IJ[9] = {};

            double dxJ_Ip [4*3]={};
            MetricGradient(dxJ_Ip, &dp_k[2 * j], e1, e2);

            double dxJ_J[3]={};
            JacobianGradient(dxJ_J,&dp_k[2 * j], e1, e2, normal);

            double dxIdxJ_Ip[4]={};
            MetricHessian(dxIdxJ_Ip,&dp_k[2 * i], &dp_k[2 * j]);

            double dxJ_normal[9]={};
            double dxIdxJ_J[9]={};
            NormalGradient(dxJ_normal, &dp_k[2 * j], e1, e2, normal, J, dxJ_J);
            JacobianHessian(dxIdxJ_J, &dp_k[2 * i], &dp_k[2 * j], e1, e2, normal, dxJ_normal);

            double dxIdxJ_normal[27]={};
            NormalHessian(dxIdxJ_normal, &dp_k[2 * i], &dp_k[2 * j], J, dxI_J, dxJ_J, dxIdxJ_J, normal, dxI_normal, dxJ_normal);

            //[1] Shear dissipation
            for (int n = 0; n < nDim; n++)
            {
                for (int m = 0; m < nDim; m++)
                    Kmat_IJ[DOF * n + m] +=  J0 * 2.0 * mu * dens0 * Math::Dot(4,&dxI_Ip_CC[4*n],&dxJ_Ip[4*m]);
                Kmat_IJ[DOF * n + n] += J0 * 2.0 * mu * dens0 *  Math::Dot(4,dxIdxJ_Ip,d_CC);
            }

            //[2] Dilatation dissipation
            for (int n = 0; n < nDim; n++)
            {
                for (int m = 0; m < nDim; m++)
                {
                    Kmat_IJ[DOF * n + m] += lambda * dens0 * dxI_J[n] * dxJ_J[m]/J0;
                    Kmat_IJ[DOF * n + m] += lambda * dens0 * trd * dxIdxJ_J[nDim * n + m];
                }
            }

            //[3] Tension power
            for (int n = 0; n < nDim; n++)
                for (int m = 0; m < nDim; m++)
                    Kmat_IJ[DOF * n + m] += activ * dens0 * dxIdxJ_J[nDim * n + m];

            //[4] Volume constraint
            double xdxJ_normal[3]={};
            NormalGradientU(xdxJ_normal,&dp_k[2 * j], e1, e2, normal, 1.0 / J, x);

            double xdxIdxJ_normal[9] = {};
            Math::AXPY(xdxIdxJ_normal, 9, x[0], &dxIdxJ_normal[0]);
            Math::AXPY(xdxIdxJ_normal, 9, x[1], &dxIdxJ_normal[9]);
            Math::AXPY(xdxIdxJ_normal, 9, x[2], &dxIdxJ_normal[18]);

            for (int n = 0; n < nDim; n++)
            {
                for (int m = 0; m < nDim; m++)
                {
                    Kmat_IJ[DOF * n + m] += deltat * pressure * dxJ_J[m] * p_k[i] * normal[n];
                    Kmat_IJ[DOF * n + m] += deltat * pressure * J * p_k[i] * dxJ_normal[n * nDim + m];

                    Kmat_IJ[DOF * n + m] += deltat * pressure * J * p_k[j] * dxI_normal[m * nDim + n];
                    Kmat_IJ[DOF * n + m] += deltat * pressure * xdxI_normal[n] * dxJ_J[m];
                    Kmat_IJ[DOF * n + m] += deltat * pressure * J * xdxIdxJ_normal[n * nDim + m];

                    Kmat_IJ[DOF * n + m] += deltat * pressure * xdxJ_normal[m] * dxI_J[n];
                    Kmat_IJ[DOF * n + m] += deltat * pressure * dxI_J[n] * p_k[j] * normal[m];
                    Kmat_IJ[DOF * n + m] += deltat * pressure * xn * dxIdxJ_J[n * nDim + m];
                }
            }

            //[7] Elasticity
            for (int n = 0; n < nDim; n++)
            {
                for (int m = 0; m < nDim; m++)
                {
                    Kmat_IJ[DOF * n + m] += J0 * dens0 * ddinva1_Ener * Math::Dot(4,GRef,&dxI_Ip[4*n])  * Math::Dot(4,GRef,&dxJ_Ip[4*m]);
                    Kmat_IJ[DOF * n + m] += J0 * dens0 * dinva1dinva2_Ener * Math::Dot(4,GRef,&dxI_Ip[4*n]) * sqrtdetG * dxJ_J[m];
                    Kmat_IJ[DOF * n + m] += J0 * dens0 * dinva2_Ener * sqrtdetG * dxIdxJ_J[n * nDim + m];
                    Kmat_IJ[DOF * n + m] += J0 * dens0 * ddinva2_Ener * sqrtdetG * dxI_J[n] * sqrtdetG * dxJ_J[m];
                    Kmat_IJ[DOF * n + m] += J0 * dens0 * dinva1dinva2_Ener * sqrtdetG * dxI_J[n] *  Math::Dot(4,GRef,&dxJ_Ip[4*m]);
                }

                Kmat_IJ[DOF * n + n] += J0 * dens0 * dinva1_Ener * Math::Dot(4,GRef,dxIdxJ_Ip);
            }

            //[8] Surface friction dissipation
            for (int n = 0; n < nDim; n++)
            {
                //if (n == 2) // only in z-direction
                Kmat_IJ[DOF * n + n] += J0 * eta_f * p_k[i] * p_k[j];
            }

            // [10] Membrane elasticity
            // higher threshold
            if (J/JR > memb_thresh_high)
            {
                    for (int n = 0; n < nDim; n++) {
                        for (int m = 0; m < nDim; m++) {
                            Kmat_IJ[DOF * n + m] += memb_lam * 6 * (J - memb_thresh_high * JR) * dxJ_J[m] * dxI_J[n]/JR/JR;
                            Kmat_IJ[DOF * n + m] += memb_lam * 3 * (J - memb_thresh_high * JR) * (J - memb_thresh_high * JR) *
                                                    dxIdxJ_J[nDim * n + m]/JR/JR;
                        }
                    }
            }
            // lower threshold
			if (J/JR < memb_thresh_low)
            {
                    for (int n = 0; n < nDim; n++) {
                        for (int m = 0; m < nDim; m++) {
                            Kmat_IJ[DOF * n + m] -= memb_lam * 6 * (J - memb_thresh_low*JR) * dxJ_J[m] * dxI_J[n]/JR/JR;
                            Kmat_IJ[DOF * n + m] -= memb_lam * 3 * (J - memb_thresh_low*JR) * (J - memb_thresh_low*JR) *
                                                    dxIdxJ_J[nDim * n + m]/JR/JR;
                        }
                    }
            }

            // [11] Luminal pressure
            if (facetag == 1)
            {
                for (int n = 0; n < nDim; n++)
                {
                    for (int m = 0; m < nDim; m++)
                    {
                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * dxJ_J[m] * p_k[i] * normal[n];
                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * J * p_k[i] * dxJ_normal[n * nDim + m];

                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * J * p_k[j] * dxI_normal[m * nDim + n];
                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * xdxI_normal[n] * dxJ_J[m];
                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * J * xdxIdxJ_normal[n * nDim + m];

                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * xdxJ_normal[m] * dxI_J[n];
                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * dxI_J[n] * p_k[j] * normal[m];
                        Kmat_IJ[DOF * n + m] -= deltat * lumpressure * xn * dxIdxJ_J[n * nDim + m];
                    }
                }
            }

            //~ // Implementing penalty when dome deflates to touch substrate
            //~ if (fillStr->userStr->bparam[faceID])
            // if (facetag == 1)
            //~ {
				//~ for (int n = 0; n < nDim; n++) {
					//~ for (int m = 0; m < nDim; m++) {
						//~ Kmat_IJ[DOF * n + m] += deltat *penaltyCoeff * p_k[i] *  p_k[j] *  J;
						//~ Kmat_IJ[DOF * n + m] += deltat *penaltyCoeff * xminusx0[n]* p_k[i] * dxI_J[n];
						//~ Kmat_IJ[DOF * n + m] += deltat *penaltyCoeff * xminusx0[m]* p_k[j] * dxI_J[m];
						//~ Kmat_IJ[DOF * n + m] += deltat *0.5*penaltyCoeff* Math::Dot3D(xminusx0,xminusx0) * dxIdxJ_J[nDim * n + m];
						//~ }
					//~ }

			//~ }

            // FILL term of K_e[i,j]
            for (int n = 0; n < DOF; n++)
                for (int m = 0; m < DOF; m++)
                    Kmat_k[(i * DOF + n) * N_k + j * DOF + m] += Kmat_IJ[n * DOF + m];
        }


    /////////////////////////////////// FILLING Q_MAT and R_MAT ///////////////////////////////////


        //[4] Volume constraint
        Qmat_k[(DOF * i + 0) * gDOF + 0] += deltat * J * p_k[i] * normal[0];
        Qmat_k[(DOF * i + 1) * gDOF + 0] += deltat * J * p_k[i] * normal[1];
        Qmat_k[(DOF * i + 2) * gDOF + 0] += deltat * J * p_k[i] * normal[2];

        Qmat_k[(DOF * i + 0) * gDOF + 0] += deltat * J * xdxI_normal[0];
        Qmat_k[(DOF * i + 1) * gDOF + 0] += deltat * J * xdxI_normal[1];
        Qmat_k[(DOF * i + 2) * gDOF + 0] += deltat * J * xdxI_normal[2];

        Qmat_k[(DOF * i + 0) * gDOF + 0] += deltat * xn * dxI_J[0];
        Qmat_k[(DOF * i + 1) * gDOF + 0] += deltat * xn * dxI_J[1];
        Qmat_k[(DOF * i + 2) * gDOF + 0] += deltat * xn * dxI_J[2];


        Rmat_k[0 * N_k + DOF*i + 0] += deltat * J * p_k[i] * normal[0];
        Rmat_k[0 * N_k + DOF*i + 1] += deltat * J * p_k[i] * normal[1];
        Rmat_k[0 * N_k + DOF*i + 2] += deltat * J * p_k[i] * normal[2];

        Rmat_k[0 * N_k + DOF*i + 0] += deltat * J * xdxI_normal[0];
        Rmat_k[0 * N_k + DOF*i + 1] += deltat * J * xdxI_normal[1];
        Rmat_k[0 * N_k + DOF*i + 2] += deltat * J * xdxI_normal[2];

        Rmat_k[0 * N_k + DOF*i + 0] += deltat * xn * dxI_J[0];
        Rmat_k[0 * N_k + DOF*i + 1] += deltat * xn * dxI_J[1];
        Rmat_k[0 * N_k + DOF*i + 2] += deltat * xn * dxI_J[2];


        //[7] Elasticity
        for (int n = 0; n < nDim; n++)
        {
            for (int m = 0; m < nDim; m++)
            {
                Qmat_k[(DOF * i + n) * gDOF + m + 3] += J0 * dens0 * dinva1_Ener * Math::Dot(4,&dxI_Ip[4*n],&dG_GRef[4*m]);
                Qmat_k[(DOF * i + n) * gDOF + m + 3] += J0 * dens0 * ddinva1_Ener * Math::Dot(4,GRef,&dxI_Ip[4*n]) * Math::Dot(4,Ip,&dG_GRef[4*m]);
                Qmat_k[(DOF * i + n) * gDOF + m + 3] += J0 * dens0 * dinva1dinva2_Ener * Math::Dot(4,GRef,&dxI_Ip[4*n]) * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*m]);
                Qmat_k[(DOF * i + n) * gDOF + m + 3] += J0 * dens0 * (ddinva2_Ener * inva2 + dinva2_Ener) * sqrtdetG * dxI_J[n] * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*m]);
                Qmat_k[(DOF * i + n) * gDOF + m + 3] += J0 * dens0 * dinva1dinva2_Ener * sqrtdetG * dxI_J[n]  * Math::Dot(4,Ip,&dG_GRef[4*m]);

                Rmat_k[(n + 3) * N_k + DOF*i + m]    += J0 * dens0 * dinva1_Ener * Math::Dot(4,&dxI_Ip[4*m],&dG_GRef[4*n]);
                Rmat_k[(n + 3) * N_k + DOF*i + m]    += J0 * dens0 * ddinva1_Ener * Math::Dot(4,GRef,&dxI_Ip[4*m]) * Math::Dot(4,Ip,&dG_GRef[4*n]);
                Rmat_k[(n + 3) * N_k + DOF*i + m]    += J0 * dens0 * dinva1dinva2_Ener * Math::Dot(4,GRef,&dxI_Ip[4*m]) * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*n]);
                Rmat_k[(n + 3) * N_k + DOF*i + m]    += J0 * dens0 * (ddinva2_Ener * inva2 + dinva2_Ener) * sqrtdetG * dxI_J[m] * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*n]);
                Rmat_k[(n + 3) * N_k + DOF*i + m]    += J0 * dens0 * dinva1dinva2_Ener * sqrtdetG * dxI_J[m]  * Math::Dot(4,Ip,&dG_GRef[4*n]);
            }
        }

        //[6] Conc
        for (int n = 0; n < nDim; n++)
            Rmat_k[1 * N_k + DOF*i + n] += conc * (p_k[i] * normal[n] * J + xdxI_normal[n] * J + xn * dxI_J[n])/3.0 + dens *  dxI_J[n];

        //[6] Density
        for (int n = 0; n < nDim; n++)
            Rmat_k[2 * N_k + DOF*i + n] += dens * dxI_J[n];

        // [11] Luminal pressure
        if (facetag == 1)
        {
            Qmat_k[(DOF * i + 0) * gDOF + 6] -= deltat * J * p_k[i] * normal[0];
            Qmat_k[(DOF * i + 1) * gDOF + 6] -= deltat * J * p_k[i] * normal[1];
            Qmat_k[(DOF * i + 2) * gDOF + 6] -= deltat * J * p_k[i] * normal[2];

            Qmat_k[(DOF * i + 0) * gDOF + 6] -= deltat * J * xdxI_normal[0];
            Qmat_k[(DOF * i + 1) * gDOF + 6] -= deltat * J * xdxI_normal[1];
            Qmat_k[(DOF * i + 2) * gDOF + 6] -= deltat * J * xdxI_normal[2];

            Qmat_k[(DOF * i + 0) * gDOF + 6] -= deltat * xn * dxI_J[0];
            Qmat_k[(DOF * i + 1) * gDOF + 6] -= deltat * xn * dxI_J[1];
            Qmat_k[(DOF * i + 2) * gDOF + 6] -= deltat * xn * dxI_J[2];


            Rmat_k[6 * N_k + DOF*i + 0] -= deltat * J * p_k[i] * normal[0];
            Rmat_k[6 * N_k + DOF*i + 1] -= deltat * J * p_k[i] * normal[1];
            Rmat_k[6 * N_k + DOF*i + 2] -= deltat * J * p_k[i] * normal[2];

            Rmat_k[6 * N_k + DOF*i + 0] -= deltat * J * xdxI_normal[0];
            Rmat_k[6 * N_k + DOF*i + 1] -= deltat * J * xdxI_normal[1];
            Rmat_k[6 * N_k + DOF*i + 2] -= deltat * J * xdxI_normal[2];

            Rmat_k[6 * N_k + DOF*i + 0] -= deltat * xn * dxI_J[0];
            Rmat_k[6 * N_k + DOF*i + 1] -= deltat * xn * dxI_J[1];
            Rmat_k[6 * N_k + DOF*i + 2] -= deltat * xn * dxI_J[2];
        }

    }


    /////////////////////////////////// FILLING G_RHS and L_MAT///////////////////////////////////


    //[4] Volume constraint
    g_rhs_k[0] += deltat * ( xn*J - x0n0*J0 );

    // [11] Luminal pressure, deltat * deltat * lumpressure * (Vdomedot - Vdomeincreaserate)
    if (facetag == 1)
    {
        g_rhs_k[6] -= deltat * ( xn*J - x0n0*J0 );
    }

    // constant term corresponsing to rate of luminal volume increase. Added only once
    if (faceID == 0 && subFill.elemID==0 && subFill.kPt== 0)
    {
        g_rhs_k[6] -=  deltat * deltat * vdomedot/ subFill.wk_sample;
    }


    //[6] Conc
    g_rhs_k[1] += conc * xn*J/3.0 + dens * J - conc0 * x0n0*J0/3.0 - dens0*J0;

    //[6] Density
    g_rhs_k[2] += J0 * ( dens*J/J0 - dens0 - kp * conc + kd * dens );

    Lmat_k[gDOF * 1 + 1] += xn*J/3.0;
    Lmat_k[gDOF * 1 + 2] += J;

    //[6] Density
    Lmat_k[gDOF * 2 + 2] += J0 * (J/J0 + kd);
    Lmat_k[gDOF * 2 + 1] -= J0 * kp;

//    LocMongeParam::matChangeBasis(TI, g1eI, g2eI, e1R, e2R);
//    Math::Invert2x2(iTI,TI);
//    CalcdGIGRef( dGIGRef, iTI, one, Voigt );

    double dG_iGRef[12], MauxI[4];
    Math::MatProduct(MauxI,2,2,2,iGRef,&dG_GRef[4*0]);
    Math::MatProduct(&dG_iGRef[4*0],2,2,2,MauxI,iGRef);
    Math::MatProduct(MauxI,2,2,2,iGRef,&dG_GRef[4*1]);
    Math::MatProduct(&dG_iGRef[4*1],2,2,2,MauxI,iGRef);
    Math::MatProduct(MauxI,2,2,2,iGRef,&dG_GRef[4*2]);
    Math::MatProduct(&dG_iGRef[4*2],2,2,2,MauxI,iGRef);
    Math::AX(dG_iGRef,12,-1.0);

    // [7] Elasticity
    g_rhs_k[3] += J0 * dens0 * dinva1_Ener * Math::Dot(4,Ip,&dG_GRef[4*0]);
    g_rhs_k[4] += J0 * dens0 * dinva1_Ener * Math::Dot(4,Ip,&dG_GRef[4*1]);
    g_rhs_k[5] += J0 * dens0 * dinva1_Ener * Math::Dot(4,Ip,&dG_GRef[4*2]);

    g_rhs_k[3] += J0 * dens0 * dinva2_Ener * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*0]);
    g_rhs_k[4] += J0 * dens0 * dinva2_Ener * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*1]);
    g_rhs_k[5] += J0 * dens0 * dinva2_Ener * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*2]);

    for (int n = 0; n < nDim; n++)
    {
        for (int m = 0; m < nDim; m++)
        {
            Lmat_k[gDOF * (n + 3) + m + 3] += J0 * dens0 * ddinva1_Ener * Math::Dot(4, Ip, &dG_GRef[4 * n]) * Math::Dot(4, Ip, &dG_GRef[4 * m]);
            Lmat_k[gDOF * (n + 3) + m + 3] += J0 * dens0 * dinva1dinva2_Ener * Math::Dot(4, Ip, &dG_GRef[4 * n]) * inva2 * 0.5 *  Math::Dot(4, iGRef, &dG_GRef[4 * m]);
            Lmat_k[gDOF * (n + 3) + m + 3] += J0 * dens0 * dinva2_Ener * inva2 * 0.5 * Math::Dot(4, &dG_GRef[4 * n], &dG_iGRef[4 * m]);
            Lmat_k[gDOF * (n + 3) + m + 3] += J0 * dens0 * (ddinva2_Ener * inva2 + dinva2_Ener) * 0.5 * Math::Dot(4, iGRef, &dG_GRef[4 * n]) * inva2 * 0.5 * Math::Dot(4, iGRef, &dG_GRef[4 * m]);
            Lmat_k[gDOF * (n + 3) + m + 3] += J0 * dens0 * dinva1dinva2_Ener * inva2 * 0.5 * Math::Dot(4, iGRef, &dG_GRef[4 * n]) * Math::Dot(4, Ip, &dG_GRef[4 * m]);
        }
    }

    //[8] Remodeling
    Math::MatProduct(&dG_GRef_Cc[4*0],2,2,2,iGRef0,&dG_GRef[4*0]); // GRef0
    Math::MatProduct(&dG_GRef_Cc[4*1],2,2,2,iGRef0,&dG_GRef[4*1]);
    Math::MatProduct(&dG_GRef_Cc[4*2],2,2,2,iGRef0,&dG_GRef[4*2]);

    Math::MatProduct(&dG_GRef_cc[4*0],2,2,2,&dG_GRef_Cc[4*0],iGRef0);
    Math::MatProduct(&dG_GRef_cc[4*1],2,2,2,&dG_GRef_Cc[4*1],iGRef0);
    Math::MatProduct(&dG_GRef_cc[4*2],2,2,2,&dG_GRef_Cc[4*2],iGRef0);

    g_rhs_k[3] += bVisc * J0 * dens0 * Math::Dot(4,dGRef,&dG_GRef_cc[4*0]);
    g_rhs_k[4] += bVisc * J0 * dens0 * Math::Dot(4,dGRef,&dG_GRef_cc[4*1]);
    g_rhs_k[5] += bVisc * J0 * dens0 * Math::Dot(4,dGRef,&dG_GRef_cc[4*2]);

    for (int n = 0; n < nDim; n++)
        for (int m = 0; m < nDim; m++)
            Lmat_k[gDOF * (n + 3) + m + 3] += bVisc * J0 * dens0 * Math::Dot(4,&dG_GRef_cc[4*n],&dG_GRef[4*m]);

}


void UpdateNodalForcesfromRHS(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech , double deltat)
{
    hiperMech->UpdateGhosts();

    int  hpIdx = 0;
    auto nodalforces = hiperMech->rhs;

    for (int mecID = 0; mecID < hiperMech->_dhands.size(); mecID++)
    {
        auto mec = hiperMech->_dhands[mecID];

        for (int i = 0; i < mec->mesh->loc_nPts(); i++)
        {
            for (int dof = 0; dof < mec->numDOFs(); dof++)
            {
                if (mecID % 2 == 0) {
                    //cout << mec->nameTag() << ": DOFs = " <<  mec->getNumDOFs() << endl;
                    const double value = (*nodalforces)[0][hpIdx]/deltat; // force has a deltat
                    mec->nodeAuxF->setValue(dof, i, IndexType::Local, value);
                    //cout << "F[" << dof << ", " << i << "] = " << value << endl;
                }
                hpIdx++;
            }
        }
    }

    hiperMech->UpdateGhosts();
}

void GetAveragePKStressfromNodes(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech, double* Psumlocal)
{
    hiperMech->UpdateGhosts();
    //auto nodalforces = hiperMech->rhs;

    for (int mecID = 0; mecID < hiperMech->_dhands.size(); mecID++)
    {
        auto mec = hiperMech->_dhands[mecID];
        for (int i = 0; i < mec->mesh->loc_nPts(); i++)
        {
            for (int dofI = 0; dofI < 2; dofI++)
            {
                for (int dofJ = 0; dofJ < 2; dofJ++) {
                    if (mecID % 2 == 0)
                    {
                        double FiI = mec->nodeAuxF->getValue(dofI, i, IndexType::Local);
                        double XiJ = mec->mesh->nodeCoord(i, dofJ, IndexType::Local);

                        Psumlocal[2 * dofI + dofJ] += FiI * XiJ;
                    }
                }
            }
        }
    }
}

void GetSumofNodalForces(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech, double* Fsumlocal)
{
    hiperMech->UpdateGhosts();
    auto nodalforces = hiperMech->rhs;

    for (int mecID = 0; mecID < hiperMech->_dhands.size(); mecID++)
    {
        auto mec = hiperMech->_dhands[mecID];
        for (int i = 0; i < mec->mesh->loc_nPts(); i++)
        {
            for (int dofI = 0; dofI < 3; dofI++)
            {
                    if (mecID % 2 == 0)
                    {
                        double FiI = mec->nodeAuxF->getValue(dofI, i, IndexType::Local);

                        Fsumlocal[dofI] += FiI;
                    }
            }
        }
    }
}

double Getloadstep(double t, double pull_begin, double pull_end,
                   double push_begin, double push_end, int loadcase, double push_mag, double pull_mag)
{
    double incr = 0.0;
    switch (loadcase)
    {
        case 1:
            // push then pull
            if (t > push_begin and t < push_end)
            {
                incr = (t - push_begin) * -push_mag/(push_end - push_begin);
            }
            else if (t >= push_end and t <= pull_begin)
            {
                incr = -push_mag;
            }
            else if (t > pull_begin and t < pull_end)
            {
                incr = -push_mag + (t - pull_begin)* (pull_mag + push_mag)/(pull_end - pull_begin);
            }
            else if (t >= pull_end)
            {
                incr = pull_mag;
            }
            else
            {
                incr = 0.0;
            }
            break;
        case 2:
            // pull then push
            if (t > pull_begin and t < pull_end)
            {
                incr = (t - pull_begin) * pull_mag/(pull_end - pull_begin);
            }
            else if (t >= pull_end and t <= push_begin)
            {
                incr = pull_mag;
            }
            else if (t > push_begin and t < push_end)
            {
                incr = pull_mag + (t - push_begin) * -(push_mag + pull_mag)/(push_end - push_begin);
            }
            else if (t >= push_end)
            {
                incr = -push_mag;
            }
            else
            {
                incr = 0.0;
            }
            break;
        case 3:
            // Only pull
            if (t > pull_begin and t < pull_end)
            {
                incr = (t - pull_begin)* pull_mag/(pull_end - pull_begin);
            } else if (t > pull_end)
            {
                incr = pull_mag;
            }
            else
            {
                incr = 0.0;
            }
            break;
            // Only push
        case 4:
            if (t > push_begin and t < push_end)
            {
                incr = (t - push_begin)* -push_mag/(push_end - push_begin);
            } else if (t > push_end)
            {
                incr = -push_mag;
            }
            else
            {
                incr = 0.0;
            }
            break;
    }


    return incr;
}

void LS_K_pp (Teuchos::RCP<hiperlife::FillStructure> fillStr)
{

    //------------------------------------------------------------------
    // [1] INPUT definition

    //[1.1] Load main subfill structure:
    // Main DOFS:
    // 0, 1, 2: position of the deformed mesh
    // 3: actin density
    // 4,5,6: components of the reference metric tensor
    SubFillStructure& subFill = (*fillStr)[0];

    int nDim  = subFill.nDim;
    int DOF   = subFill.numDOFs;                  //Number of degrees of freedom (7)
    int eNN   = subFill.eNN;                      //Number of neighbors to the element (3 LE)
    int pDim  = subFill.pDim;                     //Parametric dimension (2)
    double *xe_nodes  = subFill.nborCoords.data();  //Reference surface positions
    double *ue_nodes  = subFill.nborDOFs.data();  //Degrees of freedom
    double *ue_nodes0 = subFill.nborDOFs0.data(); //Degrees of freedom of previous time-step

    int N_k = DOF*eNN; //Row size

    double *fe_nodes  = subFill.nborAuxF.data();  // Auxillary data defined on the nodes

    //FIXME: reverse map?
    std::map<std::string,int>::const_iterator it;
    string key = {};
    for (it = fillStr->_dhandsTagIdx.begin(); it != fillStr->_dhandsTagIdx.end(); ++it)
    {
        if (it->second == 0) // 0 - points to the master mechanics, 1 - points to the global mechanics
        {
            key = it->first;
            break;
        }
    }
    // Extract the faceID from the key string
    int faceID = std::atoi(first_numberstring(key).c_str());

    //[1.1] Load global constraint subfill structure with 1 DOF (internal pressure)
    SubFillStructure& g_subFill = (*fillStr)[1];
    int gDOF   = g_subFill.numDOFs;
    int geNN   = g_subFill.eNN;
    int gN_k   = geNN * gDOF;
    double *g_ue_nodes  = g_subFill.nborDOFs.data();
    double *g_ue_nodes0 = g_subFill.nborDOFs0.data();
    double *g_ae_nodes  = g_subFill.nborAuxF.data(); //Degrees of freedom of previous time-step

    double pressure = g_ue_nodes[0];

    double conc0 = g_ue_nodes0[1];
    double conc  = g_ue_nodes[1];

    double dens0 = g_ue_nodes0[2];
    double dens  = g_ue_nodes[2];

    double Lx0   = g_ue_nodes0[6]; // Box size, x
    double Lx    = g_ue_nodes[6];

    double Ly0   = g_ue_nodes0[7]; // Box size, y

    //[1.1] Load basis functions and derivatives
    double *p_k  = subFill.nborBFsDers(0);
    double *dp_k = subFill.nborBFsDers(1);

    //[1.2] Load model parameters
    vector<double>   dparam = fillStr->userStr->dparam;
    double deltat    = dparam[0];
    double mu        = dparam[1];
    double lambda    = dparam[2];
    double kp        = dparam[3] * deltat;
    double kd        = dparam[4] * deltat;
    double bVisc     = dparam[5];
    double lame1     = dparam[6] * deltat;
    double lame2     = dparam[7] * deltat;
    double eta_f     = dparam[11];
    double eta_f_basal = dparam[18];
    vector<double> sigma_e  = {0.0, 0.0, 0.0, 0.0}; // applied stress
    sigma_e[0]       = dparam[12];
    sigma_e[1]       = dparam[13];
    sigma_e[2]       = dparam[14];
    sigma_e[3]       = dparam[15];
    double memb_thresh_high = dparam[16];
    double memb_thresh_low = dparam[19];
    double memb_lam    = dparam[17];
    double sigx_per    = dparam[20] * deltat;
    double sigy_per    = dparam[21] * deltat;

    double activ{};
    int    facetag   = 0;

    switch(key[0])
    {
        case 'a':
            activ = dparam[8] * deltat;
            facetag = 0;
            break;
        case 'b':
            activ = dparam[9] * deltat;
            facetag = 1;
            eta_f = eta_f_basal; // friction on basal surface
            break;
        case 'l':
            activ = dparam[10] * deltat;
            facetag = 2;
            //eta_f = 0.0; // No friction along lateral surfaces
            break;
    }

    // Determine which boundary does the lateral face belong to?
    int    boundarytag = -1; // for apical and basal should remain unchanged
    switch(key[1])
    {
        case 'T':
            boundarytag = 0;
            break;
        case 'B':
            boundarytag = 1;
            break;
        case 'L':
            boundarytag = 2;
            break;
        case 'R':
            boundarytag = 3;
            break;
    }

    //cout << "Boundary tag:" << boundarytag << endl;

    //------------------------------------------------------------------
    // [2] OUTPUT definition

    std::vector<double>& rhs_k    = fillStr->Bk(0); // <<=== MAIN OUTPUT
    std::vector<double>& g_rhs_k  = fillStr->Bk(1); // <<=== MAIN OUTPUT
    std::vector<double>& Kmat_k   = fillStr->Ak(0,0); // <<=== MAIN OUTPUT
    std::vector<double>& Qmat_k   = fillStr->Ak(0,1); // <<=== MAIN OUTPUT
    std::vector<double>& Rmat_k   = fillStr->Ak(1,0); // <<=== MAIN OUTPUT
    std::vector<double>& Lmat_k   = fillStr->Ak(1,1); // <<=== MAIN OUTPUT

    //----------
    //Deformed
    double  x[3] = {};
    double e1[3] = {};
    double e2[3] = {};
    double  f[3] = {};

    for ( int i = 0; i < eNN; i++ )
    {
        for ( int n = 0; n < nDim; n++ )
        {
            x[n]  +=         p_k[i] * ue_nodes[DOF*i+n];
            e1[n] += dp_k[pDim*i+0] * ue_nodes[DOF*i+n];
            e2[n] += dp_k[pDim*i+1] * ue_nodes[DOF*i+n];

            f[n]  +=         p_k[i] * fe_nodes[DOF*i+n];
        }
    }

    //Metric tensor
    double Ip[4];
    Ip[0] = Math::Dot3D(e1,e1);
    Ip[1] = Math::Dot3D(e1,e2);
    Ip[2] = Ip[1];
    Ip[3] = Math::Dot3D(e2,e2);

    double det = Math::DetMat2x2(Ip);
    double J   = sqrt(det);

    //Inverse
    double iIp[4];
    Math::Invert2x2(iIp,Ip);

    double normal[3];
    Math::Cross(normal,e1,e2);
    Math::AX(normal,nDim,1.0/J);

    double xn = Math::Dot3D(x,normal);

    //----------
    //Previous time-step
    double  x0[3] = {};
    double e10[3] = {};
    double e20[3] = {};

    for ( int i = 0; i < eNN; i++ )
    {
        for ( int n = 0; n < nDim; n++ )
        {
            x0[n]  +=         p_k[i] * ue_nodes0[DOF*i+n];
            e10[n] += dp_k[pDim*i+0] * ue_nodes0[DOF*i+n];
            e20[n] += dp_k[pDim*i+1] * ue_nodes0[DOF*i+n];
        }
    }

    //Metric tensor
    double Ip0[4];
    Ip0[0] = Math::Dot3D(e10,e10);
    Ip0[1] = Math::Dot3D(e10,e20);
    Ip0[2] = Ip0[1];
    Ip0[3] = Math::Dot3D(e20,e20);

    double det0 = Math::DetMat2x2(Ip0);
    double J0   = sqrt(det0);

    //Inverse
    double iIp0[4];
    Math::Invert2x2(iIp0,Ip0);

    double normal0[3];
    Math::Cross(normal0,e10,e20);
    Math::AX(normal0,nDim,1.0/J0);

    double x0n0 = Math::Dot3D(x0,normal0);

    //----------
    //Reference
    double  xR[3] = {};
    double e1R[3] = {};
    double e2R[3] = {};

    for ( int i = 0; i < eNN; i++ )
    {
        for ( int n = 0; n < nDim; n++ )
        {
            xR[n]  +=         p_k[i] * xe_nodes[nDim*i+n];
            e1R[n] += dp_k[pDim*i+0] * xe_nodes[nDim*i+n];
            e2R[n] += dp_k[pDim*i+1] * xe_nodes[nDim*i+n];
        }
    }

    //Metric tensor
    double IpR[4];
    IpR[0] = Math::Dot3D(e1R,e1R);
    IpR[1] = Math::Dot3D(e1R,e2R);
    IpR[2] = IpR[1];
    IpR[3] = Math::Dot3D(e2R,e2R);

    double detR = Math::DetMat2x2(IpR);
    double JR   = sqrt(detR);

    //Inverse
    double iIpR[4];
    Math::Invert2x2(iIpR,IpR);

    double normalR[3];
    Math::Cross(normalR,e1R,e2R);
    Math::AX(normalR,nDim,1.0/JR);

    double xRnR = Math::Dot3D(xR,normalR);

    //----------
    //Rate-of-deformation
    double d[4]    = {};
    double d_Cc[4] = {};
    double d_CC[4] = {};

    Array::Copy(d,4,Ip);
    Math::AXPY(d,4, -1.0, Ip0);

    Math::MatProduct(d_Cc,2,2,2,iIp0,d);
    Math::MatProduct(d_CC,2,2,2,d_Cc,iIp0);

    double trd = (J-J0)/J0;

    double T[4]={};
    double iT[4]={};
    double GRef[4]={};
    double iGRef[4]={};
    double GRef0[4]={};
    double iGRef0[4]={};
    double dGRef[4]={};
    double Voigt[12]={};
    double dG_GRef[12]={}, dG_GRef_Cc[12]={}, dG_GRef_cc[12]={};
    Voigt[4*0+2*0+0] = 1.0; Voigt[4*1+2*0+0] = 0.0; Voigt[4*2+2*0+0] = 0.0;
    Voigt[4*0+2*0+1] = 0.0; Voigt[4*1+2*0+1] = 1.0; Voigt[4*2+2*0+1] = 0.0;
    Voigt[4*0+2*1+0] = 0.0; Voigt[4*1+2*1+0] = 1.0; Voigt[4*2+2*1+0] = 0.0;
    Voigt[4*0+2*1+1] = 0.0; Voigt[4*1+2*1+1] = 0.0; Voigt[4*2+2*1+1] = 1.0;

    double *g1e = &g_ae_nodes[0];
    double *g2e = &g_ae_nodes[3];

    LocMongeParam::matChangeBasis(T, g1e, g2e, e1R, e2R);
    Math::Invert2x2(iT,T);

    double one = 1.0;
    CalcdGIGRef( dG_GRef, iT, one, Voigt );

    Math::AXPY(GRef,4,g_ue_nodes[3],&dG_GRef[4*0]);
    Math::AXPY(GRef,4,g_ue_nodes[4],&dG_GRef[4*1]);
    Math::AXPY(GRef,4,g_ue_nodes[5],&dG_GRef[4*2]);

    Math::AXPY(GRef0,4,g_ue_nodes0[3],&dG_GRef[4*0]);
    Math::AXPY(GRef0,4,g_ue_nodes0[4],&dG_GRef[4*1]);
    Math::AXPY(GRef0,4,g_ue_nodes0[5],&dG_GRef[4*2]);

    Math::Invert2x2(iGRef,GRef);
    Math::Invert2x2(iGRef0,GRef0);

    Array::Copy(dGRef,4,GRef);
    Math::AXPY(dGRef,4,-1.0,GRef0);

    //Elasticity invariants
    double inva1 = Math::Dot(4,GRef,Ip);
    double sqrtdetG = sqrt(Math::DetMat2x2(GRef));
    double inva2 = sqrtdetG * J;
    double inva22 = inva2*inva2;

    //NeoHookean
    double ener              = lame1 * ( inva1/inva2 - 2.0 ) + lame2 * (inva2-1.0) * (inva2-1.0) ;
    double dinva1_Ener       = lame1 /inva2;
    double dinva2_Ener       = -lame1 * inva1/inva22 + 2.0 * lame2 * (inva2-1.0);
    double ddinva1_Ener      = 0.0;
    double ddinva2_Ener      = 2.0 * lame1 * inva1/(inva2*inva22) + 2.0 * lame2;
    double dinva1dinva2_Ener = -lame1 /inva22;

    //Free energy at the previous timestep
    double inva10    = Math::Dot(4,GRef0,Ip0);
    double sqrtdetG0 = sqrt(Math::DetMat2x2(GRef0));
    double inva20    = sqrtdetG0 * J0;
    double ener0     = lame1 * ( inva10/inva20 - 2.0 ) + lame2 * (inva20-1.0) * (inva20-1.0) ;

    // Global integrations
    // average strain
    fillStr->addToGlobalIntegral("avgF00", x[0] * normalR[0] * JR);
    fillStr->addToGlobalIntegral("avgF01", x[0] * normalR[1] * JR);
    fillStr->addToGlobalIntegral("avgF10", x[1] * normalR[0] * JR);
    fillStr->addToGlobalIntegral("avgF11", x[1] * normalR[1] * JR);
    fillStr->addToGlobalIntegral("avgF22", x[2] * normalR[2] * JR);

    // Reference volume of the cell
    fillStr->addToGlobalIntegral("RefVol", xRnR/3.0 * JR);

    // Active surface energy
    fillStr->addToGlobalIntegral("SurfEnerg", activ*dens0*J/deltat);

    // Incremental Rayleighian, R*deltat
    double delRay = 0;

    // Active power
    delRay += activ*dens0*trd*J0/deltat;

    // Elastic (Need to have F(X) - F(X0))
    delRay += ener * J0 * dens0/deltat - ener0 * J0 * dens0/deltat;

    // Dissipative
    delRay += 0.5 * bVisc * J0 * dens0 * Math::Dot(4,dGRef,dG_GRef_cc)/deltat;

    // Surface friction
    double  v[3] = {};
    Array::Copy(v,3,x);
    Math::AXPY(v,3,-1.0,x0);
    //delRay += 0.5 * J0 * eta_f * Math::Dot(3,v,v)/deltat;

    fillStr->addToGlobalIntegral("delRay", delRay);

    for ( int i = 0; i < eNN; i++ ) {

        double dxI_Ip[4 * 3] = {}, dxI_Ip_Cc[4 * 3] = {}, dxI_Ip_CC[4 * 3] = {};
        MetricGradient(dxI_Ip, &dp_k[2 * i], e1, e2);

        Math::MatProduct(&dxI_Ip_Cc[0], 2, 2, 2, iIp0, &dxI_Ip[0]);
        Math::MatProduct(&dxI_Ip_Cc[4], 2, 2, 2, iIp0, &dxI_Ip[4]);
        Math::MatProduct(&dxI_Ip_Cc[8], 2, 2, 2, iIp0, &dxI_Ip[8]);

        Math::MatProduct(&dxI_Ip_CC[0], 2, 2, 2, &dxI_Ip_Cc[0], iIp0);
        Math::MatProduct(&dxI_Ip_CC[4], 2, 2, 2, &dxI_Ip_Cc[4], iIp0);
        Math::MatProduct(&dxI_Ip_CC[8], 2, 2, 2, &dxI_Ip_Cc[8], iIp0);

        double dxI_J[3] = {};
        JacobianGradient(dxI_J, &dp_k[2 * i], e1, e2, normal);

        //[1] Shear dissipation
        double dxI_dd[3] = {};
        dxI_dd[0] = 2.0 * Math::Dot(4, &dxI_Ip[0], d_CC);
        dxI_dd[1] = 2.0 * Math::Dot(4, &dxI_Ip[4], d_CC);
        dxI_dd[2] = 2.0 * Math::Dot(4, &dxI_Ip[8], d_CC);

        //FIXME: d is twice d, rescale these terms
        Math::AXPY(&rhs_k[DOF * i], nDim, J0 * mu * dens0, dxI_dd);

        //[2] Dilatation dissipation
        Math::AXPY(&rhs_k[DOF * i], nDim, lambda * trd * dens0, dxI_J);

        //[3] Tension power
        Math::AXPY(&rhs_k[DOF * i], nDim, activ * dens0, dxI_J);

        //[4] Volume constraint
        double dxI_normal[3 * 3] = {};
        double xdxI_normal[3] = {};
        NormalGradient(dxI_normal, &dp_k[2 * i], e1, e2, normal, J, dxI_J);
        NormalGradientU(xdxI_normal, &dp_k[2 * i], e1, e2, normal, 1.0 / J, x);

        Math::AXPY(&rhs_k[DOF * i], nDim, deltat * pressure * J * p_k[i], normal);
        Math::AXPY(&rhs_k[DOF * i], nDim, deltat * pressure * J, xdxI_normal);
        Math::AXPY(&rhs_k[DOF * i], nDim, deltat * pressure * xn, dxI_J);

        //[7] Elasticity (dens0 + kp * conc0 - kd*rho)
        rhs_k[DOF * i + 0] += J0 * dens0 * dinva1_Ener * Math::Dot(4, GRef, &dxI_Ip[0]);
        rhs_k[DOF * i + 1] += J0 * dens0 * dinva1_Ener * Math::Dot(4, GRef, &dxI_Ip[4]);
        rhs_k[DOF * i + 2] += J0 * dens0 * dinva1_Ener * Math::Dot(4, GRef, &dxI_Ip[8]);

        rhs_k[DOF * i + 0] += J0 * dens0 * dinva2_Ener * sqrtdetG * dxI_J[0];
        rhs_k[DOF * i + 1] += J0 * dens0 * dinva2_Ener * sqrtdetG * dxI_J[1];
        rhs_k[DOF * i + 2] += J0 * dens0 * dinva2_Ener * sqrtdetG * dxI_J[2];

        //[8] Surface friction dissipation (only in out of plane direction)
        rhs_k[DOF * i + 0] += J0 * eta_f * (x[0] - x0[0]) * p_k[i];
        rhs_k[DOF * i + 1] += J0 * eta_f * (x[1] - x0[1]) * p_k[i];
        rhs_k[DOF * i + 2] += J0 * eta_f * (x[2] - x0[2]) * p_k[i];

        // Don't add external power to be able to calculate correctly the nodal forces for mean stress calculation
        //[9] External power input through tractions only on the desired surfaces
//        if (boundarytag == 2 || boundarytag == 3 || boundarytag == 0 || boundarytag == 1) {
//            rhs_k[DOF * i + 0] += -J0 * deltat * (sigma_e[0] * normal0[0] + sigma_e[1] * normal0[1]) * p_k[i];
//            rhs_k[DOF * i + 1] += -J0 * deltat * (sigma_e[2] * normal0[0] + sigma_e[3] * normal0[1]) * p_k[i];
//        }

        // [10] Membrane elasticity
        // higher threshold
        if (J/JR > memb_thresh_high)
        {
                // Divide by JR^2 for covariance
                rhs_k[DOF * i + 0] += memb_lam * 3 * (J - memb_thresh_high*JR) * (J - memb_thresh_high*JR) * dxI_J[0] /JR/JR;
                rhs_k[DOF * i + 1] += memb_lam * 3 * (J - memb_thresh_high*JR) * (J - memb_thresh_high*JR) * dxI_J[1] /JR/JR;
                rhs_k[DOF * i + 2] += memb_lam * 3 * (J - memb_thresh_high*JR) * (J - memb_thresh_high*JR) * dxI_J[2] /JR/JR;
        }

        // lower threshold
        if (J/JR < memb_thresh_low)
        {
                // Divide by JR^2 for covariance
                rhs_k[DOF * i + 0] -= memb_lam * 3 * (J - memb_thresh_low*JR) * (J - memb_thresh_low*JR) * dxI_J[0] /JR/JR;
                rhs_k[DOF * i + 1] -= memb_lam * 3 * (J - memb_thresh_low*JR) * (J - memb_thresh_low*JR) * dxI_J[1] /JR/JR;
                rhs_k[DOF * i + 2] -= memb_lam * 3 * (J - memb_thresh_low*JR) * (J - memb_thresh_low*JR) * dxI_J[2] /JR/JR;
		}

    }
    g_rhs_k[0] += deltat * ( xn*J - x0n0*J0 );

    //[6] Conc
    g_rhs_k[1] += conc * xn*J/3.0 + dens * J - conc0 * x0n0*J0/3.0 - dens0*J0;

    //[6] Density
    g_rhs_k[2] += J0 * ( dens*J/J0 - dens0 - kp * conc + kd * dens );

//    LocMongeParam::matChangeBasis(TI, g1eI, g2eI, e1R, e2R);
//    Math::Invert2x2(iTI,TI);
//    CalcdGIGRef( dGIGRef, iTI, one, Voigt );

    double dG_iGRef[12], MauxI[4];
    Math::MatProduct(MauxI,2,2,2,iGRef,&dG_GRef[4*0]);
    Math::MatProduct(&dG_iGRef[4*0],2,2,2,MauxI,iGRef);
    Math::MatProduct(MauxI,2,2,2,iGRef,&dG_GRef[4*1]);
    Math::MatProduct(&dG_iGRef[4*1],2,2,2,MauxI,iGRef);
    Math::MatProduct(MauxI,2,2,2,iGRef,&dG_GRef[4*2]);
    Math::MatProduct(&dG_iGRef[4*2],2,2,2,MauxI,iGRef);
    Math::AX(dG_iGRef,12,-1.0);

    // [7] Elasticity
    g_rhs_k[3] += J0 * dens0 * dinva1_Ener * Math::Dot(4,Ip,&dG_GRef[4*0]);
    g_rhs_k[4] += J0 * dens0 * dinva1_Ener * Math::Dot(4,Ip,&dG_GRef[4*1]);
    g_rhs_k[5] += J0 * dens0 * dinva1_Ener * Math::Dot(4,Ip,&dG_GRef[4*2]);

    g_rhs_k[3] += J0 * dens0 * dinva2_Ener * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*0]);
    g_rhs_k[4] += J0 * dens0 * dinva2_Ener * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*1]);
    g_rhs_k[5] += J0 * dens0 * dinva2_Ener * inva2 * 0.5 * Math::Dot(4,iGRef,&dG_GRef[4*2]);

    //[8] Remodeling
    Math::MatProduct(&dG_GRef_Cc[4*0],2,2,2,iGRef0,&dG_GRef[4*0]); // GRef0
    Math::MatProduct(&dG_GRef_Cc[4*1],2,2,2,iGRef0,&dG_GRef[4*1]);
    Math::MatProduct(&dG_GRef_Cc[4*2],2,2,2,iGRef0,&dG_GRef[4*2]);

    Math::MatProduct(&dG_GRef_cc[4*0],2,2,2,&dG_GRef_Cc[4*0],iGRef0);
    Math::MatProduct(&dG_GRef_cc[4*1],2,2,2,&dG_GRef_Cc[4*1],iGRef0);
    Math::MatProduct(&dG_GRef_cc[4*2],2,2,2,&dG_GRef_Cc[4*2],iGRef0);

    g_rhs_k[3] += bVisc * J0 * dens0 * Math::Dot(4,dGRef,&dG_GRef_cc[4*0]);
    g_rhs_k[4] += bVisc * J0 * dens0 * Math::Dot(4,dGRef,&dG_GRef_cc[4*1]);
    g_rhs_k[5] += bVisc * J0 * dens0 * Math::Dot(4,dGRef,&dG_GRef_cc[4*2]);
    g_rhs_k[5] += bVisc * J0 * dens0 * Math::Dot(4,dGRef,&dG_GRef_cc[4*2]);

}

std::tuple<int, int, double> linesearch_bisection(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech)
{
    // Get s0 = DelU^T * R(U_n) = -RHS^T * LHS
    int ierr = 0;
    double s0{}, sn{}, rn{};
    auto LHS = Teuchos::rcpFromRef(*hiperMech->linProbl->GetLHS());
    auto RHS = Teuchos::rcpFromRef(*hiperMech->linProbl->GetRHS());
    RHS->Dot(*LHS, &s0);
    s0 = s0 * -1.0;
    if (hiperMech->myRank() == 0)
    {
        cout << "s0 = " << s0 << endl;
        if (s0 > 0.0)
        {
            cout << "    *** Positive s0 ****" << endl;
        }
    }

    double sL, sU;
    double alpha, alpha_prev, Delalpha, alphaL, alphaU, alphaMaxp, AMP;

    alpha        = 1.0;     // Initialize line search parameter
    alpha_prev   = 0.0;     // Initialize line search parameter
    alphaMaxp    = alpha;   // Maximum value
    AMP          = 5.0;     // Amplification factor
    alphaU       = 5.0;     // Upper bound

    // Modify the search direction if s0 is positive beyond the threshold
    if (s0 > 0.0)
    {
        if ( hiperMech->myRank() == 0 )
            std::cout << "Line-search: positive s0: Reversing the direction of search" << std::endl;
        alpha  = -1.0;
        alphaL = -1.0;    // Lower bound
        alphaU =  0.0;    // Upper bound
        sU     = s0;
    }
    else
    {
        alphaL =  0.0;    // Lower bound
        alphaU = 1.0;    // Upper bound
        sL     = s0;
    }

    Delalpha = alpha - alpha_prev;     // Initialize increment in line-search parameter

    // Line-search loop
    int l;
    for (l = 0; l < 10; l++)
    {
        alpha_prev = alpha;

        // Update DOFs using increment in alpha
        hiperMech->AddSolutionToDOFs(-Delalpha);
        hiperMech->UpdateGhosts();

        // Evaluate the residual for the updated DOFs
        hiperMech->FillLinearSystem();

        // Get sn
        auto RHSn = Teuchos::rcpFromRef(*hiperMech->linProbl->GetRHS());
        RHSn->Dot(*LHS, &sn);
        sn = sn * -1.0;

        // Get the ratio
        rn = sn / s0;

        // Avoid iteration if NR step satisfies the condition
        if (abs(rn) < 0.5)
        {
            if (hiperMech->myRank() == 0)
            {
                cout << "Using the NR step as [ " << l << " ]:|r_n| = " << abs(rn) << endl;
            }
            break;
        }

        // *********************   Bisection method ************************
        // initialize sU
        if (l == 0)
        {
            if (s0 > 0.0)
            {
                sL = sn;
            }
            else
            {
                sU = sn;
            }

            if (sL * sU > 0)
            {
                if (hiperMech->myRank() == 0)
                    cout << "sL =" << sL << ", and sU =" << sU
                         << " has the same sign, Bijection would not work" << endl;
            }
        }

        // Update lower and upper bounds
        if (l > 0)
        {
            if (sn * sL < 0 && sn * sU > 0)
            {
                alphaU = alpha;
                sU = sn;
            }

            if (sn * sU < 0 && sn * sL > 0)
            {
                alphaL = alpha;
                sL = sn;
            }

            if (sn * sU > 0 && sn * sL > 0)
            {
                alphaL = alpha;
                sL = sn;
                break; // the root lies outside of the window
            }
        }

        // Using Bisection method update alpha
        alpha = (alphaU + alphaL) / 2.0;

        // ********************* Bisection method ************************

        // Change in alpha
        Delalpha = alpha - alpha_prev;

        if (hiperMech->myRank() == 0)
        {
            cout << "       [LSiter-" << l << "] : |r_n| = " << abs(rn) << ", [alphaL, alphaU] = [" << alphaL << "," << alphaU << "],   [sL, sU] = [" << sL
                 << "," << sU << "]" << endl;
        }

        if (abs(rn) < 0.5)
            break;

        if (std::isnan(alpha) || std::isnan(sn))
        {
            if (hiperMech->myRank() == 0)
                std::cout << "ERROR:Line-search:Error computing alpha, Getting NAN" << std::endl;
            ierr = 1; // reduce the loadstep
            break;
        }
    }
    return make_tuple(ierr, l, alpha_prev);
}

std::tuple<int, int, double> linesearch_backtracking(Teuchos::RCP<hiperlife::HiPerProblem> hiperMech)
{
    int ierr = 0;
    int LSiterMAX = 40;

    double s0{}, phi0{}, phin{};
    auto LHS = Teuchos::rcpFromRef(*hiperMech->linProbl->GetLHS());
    auto RHS = Teuchos::rcpFromRef(*hiperMech->linProbl->GetRHS());

    // Calcualte: phi(0) = 1/2 * || Residual(U)||^2
    RHS->Dot(*RHS, &phi0);
    phi0 = 0.5 * phi0;

    // Calculate: s0 = phi'(0) = -phi(0)
    s0 = - phi0;
    if (hiperMech->myRank() == 0)
        cout << "              s0 = " << s0 << endl;

    double alpha, alpha_prev, Delalpha, alpha_MIN, rho, c;

    alpha      = 1.0;     // Start with the NR increment (backtracking)
    alpha_prev = 0.0;     // Initialize line search parameter
    alpha_MIN  = 1E-5;    // Smallest allowed step size
    rho        = 0.5;
    c          = 1e-4;
    int l = 0;

    // Abort if s0 is positive
    if (s0 > 0.0)
    {
        if ( hiperMech->myRank() == 0 )
            std::cout << "************Line-search: positive s0, aborting search" << std::endl;
        ierr = 1;
    }

    if (ierr == 0)
    {
        // Backtracking line-search loop
        for (l = 0; l < LSiterMAX; l++)
        {
            // Change in alpha
            Delalpha = alpha - alpha_prev;

            // Store last step alpha
            alpha_prev = alpha;

            // Update DOFs using increment in alpha
            hiperMech->AddSolutionToDOFs(-Delalpha);
            hiperMech->UpdateGhosts();

            // Evaluate the residual for the updated DOFs
            hiperMech->FillLinearSystem();

            // Get energy function at alpha, phi(alpha)
            RHS->Dot(*RHS, &phin); // Energy is half the norm of the residual
            phin = 0.5 * phin;

            // Check for convergence
            double lalpha = phi0 + c * alpha * s0;
            if (phin <= lalpha || abs(s0) < 1.0E-10)
            {
                if (hiperMech->myRank() == 0)
                {
                    cout << "           ** Satisfied the sufficient decrease condition at LS iteration **" <<  endl;
                    cout << "           [LSiter-" << l << "] : alpha = " << alpha << ", phin = " << phin << ", l(alpha)" << lalpha << endl;
                }
                break;
            }

            // Check if alpha becomes less than the minimum allowed
            if (alpha < alpha_MIN)
            {
                if (hiperMech->myRank() == 0)
                    std::cout << "**ERROR:Line-search:alpha less than alpha_MIN:" << alpha << std::endl;
                ierr = 1;
                break;
            }

            if (std::isnan(alpha) || std::isnan(s0))
            {
                if (hiperMech->myRank() == 0)
                    std::cout << "**ERROR:Line-search:Error computing alpha, Getting NAN" << std::endl;
                ierr = 1; // reduce the loadstep
                break;
            }

            // Update status
            if (hiperMech->myRank() == 0)
            {
                cout << "           [LSiter-" << l << "] : alpha = " << alpha << ", phin = " << phin << ", l(alpha)" << lalpha << endl;
            }

            // Update alpha
            alpha = alpha * rho;
        }
    }

    if (l == LSiterMAX)
    {
        ierr = 1;
        cout << "**ERROR: Line search maximum iterations reached without convergence" << endl;
    }
    return make_tuple(ierr, l, alpha_prev);
}


//@{
/** Tensor product between two arrays of size 1xN, result of size NxN */
template <class T>
inline static void TensProd ( T *Mat, int N, const T *wa1, const T *wa2 )
{
    int i, j, id;
    T val;
    for (i=0; i<N; i++)
    {
        val   = wa1[i];
        id    = i*N; // row index
        for (j=0; j<N; j++)
            Mat[id+j]  = val * wa2[j];
    }
    return;
}

/**
 * Vector times Matrix: y = x M
 * The size of the matrix M is NrxNc, and the input vector x is 1xNr
 * The output vector y have a size 1xNc
 * the matrix M is stored by ROWS.
 * M = [m00 m01...m0(Nc-1) m10 m11...m1(Nc-1) ... ... m(Nr-1)0 ... m(Nr-1)(Nc-1)]
 */
template <class T>
static void VxM_Row ( T *y, int Nr, int Nc, const T *x, const T *Mat )
{
    int i, j;
    T val;
    for (i=0; i<Nc; i++)
    {
        val = 0.0;
        for (j=0; j<Nr; j++)
            val += Mat[j*Nc+i]*x[j];
        y[i] = val;
    }
}

/**
 * Matrix times vector: y = M x
 * The size of the matrix M is NrxNc, and the input vector x is Ncx1
 * The output vector y have a size Nrx1
 * the matrix M is stored by ROWS.
 * M = [m00 m01...m0(N-1) m10 m11...m1(N-1) ... ... m(N-1)0 ... m(N-1)(N-1)]
 */
template <class T>
static void MxV_Row ( T *y, int Nr, int Nc, const T *Mat, const T *x )
{
    int i, j, id;
    T val;
    for (i=0; i<Nr; i++)
    {
        id  = i*Nc;
        val = 0.0;
        for (j=0; j<Nc; j++)
            val += Mat[id+j]*x[j];
        y[i] = val;
    }
}



//@{
/** Matrix Multiplication of a FULL matrix 2x2 */
template <class T>
inline static void MatMultSquare2D ( T *Mat, const T *Mat1, const T *Mat2  )
{
    Mat[0] = Mat1[0]*Mat2[0] + Mat1[1]*Mat2[2];
    Mat[1] = Mat1[0]*Mat2[1] + Mat1[1]*Mat2[3];
    Mat[2] = Mat1[2]*Mat2[0] + Mat1[3]*Mat2[2];
    Mat[3] = Mat1[2]*Mat2[1] + Mat1[3]*Mat2[3];
    return;
}
//@}
//@{
/** Matrix Multiplication of a FULL matrix 3x3 */
template <class T>
inline static void MatMultSquare3D ( T *Mat, const T *Mat1, const T *Mat2  )
{
    Mat[0] = Mat1[0]*Mat2[0] + Mat1[1]*Mat2[3] + Mat1[2]*Mat2[6];
    Mat[1] = Mat1[0]*Mat2[1] + Mat1[1]*Mat2[4] + Mat1[2]*Mat2[7];
    Mat[2] = Mat1[0]*Mat2[2] + Mat1[1]*Mat2[5] + Mat1[2]*Mat2[8];
    Mat[3] = Mat1[3]*Mat2[0] + Mat1[4]*Mat2[3] + Mat1[5]*Mat2[6];
    Mat[4] = Mat1[3]*Mat2[1] + Mat1[4]*Mat2[4] + Mat1[5]*Mat2[7];
    Mat[5] = Mat1[3]*Mat2[2] + Mat1[4]*Mat2[5] + Mat1[5]*Mat2[8];
    Mat[6] = Mat1[6]*Mat2[0] + Mat1[7]*Mat2[3] + Mat1[8]*Mat2[6];
    Mat[7] = Mat1[6]*Mat2[1] + Mat1[7]*Mat2[4] + Mat1[8]*Mat2[7];
    Mat[8] = Mat1[6]*Mat2[2] + Mat1[7]*Mat2[5] + Mat1[8]*Mat2[8];
    return;
}
//@}
//@{
/** Matrix Transposition of a FULL matrix 3x3 */
template <class T>
inline static void MatTranspose3D ( T *Mat, const T *Mat1  )
{
    Mat[0] = Mat1[0];    Mat[1] = Mat1[3];    Mat[2] = Mat1[6];
    Mat[3] = Mat1[1];    Mat[4] = Mat1[4];    Mat[5] = Mat1[7];
    Mat[6] = Mat1[2];    Mat[7] = Mat1[5];    Mat[8] = Mat1[8];
    return;
}
//@}

//________________________________________________________________________________________
//                                   MEMBRANE
//

// The Membrane strain-displacement force to the node I is computed
// Fmem_I = n^T . (deps / dU^I) = n^T.M^I
void ForceMem (double *Fmem, double *dp_s, double *phi_1, double *phi_2, double *n )
{
    double  p_1, p_2;

    // gradient of the basis functions of the sample point xi_s(k) in the parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];

    // - - -
    Fmem[0] = p_1*phi_1[0]*n[0] + p_2*phi_2[0]*n[1] + (p_2*phi_1[0] + p_1*phi_2[0])*n[2];
    Fmem[1] = p_1*phi_1[1]*n[0] + p_2*phi_2[1]*n[1] + (p_2*phi_1[1] + p_1*phi_2[1])*n[2];
    Fmem[2] = p_1*phi_1[2]*n[0] + p_2*phi_2[2]*n[1] + (p_2*phi_1[2] + p_1*phi_2[2])*n[2];

    return;
}

// The Membrane strain-displacement matrix is filled
// The gradient of the membrane strain-displacement to the node 'I' is computed
// Grad Mem_I = (deps / dP^I) = M^I
void MFilled (double *M, double *dp_s, double *phi_1, double *phi_2)
{
    double  p_1, p_2;

    // gradient and Hessian components of the basis functions of the sample point xi_s(k)
    // in the local parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];

    // - - -
    // Membrane strain matrix for the node rowI
    M[0] = p_1*phi_1[0];
    M[1] = p_1*phi_1[1];
    M[2] = p_1*phi_1[2];

    M[3] = p_2*phi_2[0];
    M[4] = p_2*phi_2[1];
    M[5] = p_2*phi_2[2];

    M[6] = p_2*phi_1[0] + p_1*phi_2[0];
    M[7] = p_2*phi_1[1] + p_1*phi_2[1];
    M[8] = p_2*phi_1[2] + p_1*phi_2[2];

    return;
}


//
// Membrane strain-displacement matrix is filled, Transposition is enforced
void MFilled_T (double *M_T, double *dp_s, double *phi_1, double *phi_2)
{
    double  p_1, p_2;

    // gradient and Hessian components of the basis functions of the sample point xi_s(k)
    // in the local parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];

    // - - -
    // Membrane strain matrix for the node rowI, transpose
    M_T[0] = p_1*phi_1[0];
    M_T[1] = p_2*phi_2[0];
    M_T[2] = p_2*phi_1[0] + p_1*phi_2[0];

    M_T[3] = p_1*phi_1[1];
    M_T[4] = p_2*phi_2[1];
    M_T[5] = p_2*phi_1[1] + p_1*phi_2[1];

    M_T[6] = p_1*phi_1[2];
    M_T[7] = p_2*phi_2[2];
    M_T[8] = p_2*phi_1[2] + p_1*phi_2[2];

    return;
}

// Second order derivative of the Membrane Potential Energy Density
// The Membrane strain-displacement hessian to the nodes 'ab' is computed
// HessMem_ab = v.n Id  +  (dn / dP^b) (deps / dP^a)
//
// where:
// vec    = [pa_1 * pb_1, pa_2 * pb_2, pa_1 * pb_2 + pa_2 * pb_1]
// Ma^T C = (dn   / dP^a)
// Mb     = (deps / dP^b)
void HessMem(double *Hmem,
              double *dp_a, double *dp_b, double *n,
              double *Ma_TxC, double *Mb)
{
    double  pa_1, pa_2, pb_1, pb_2, vn;

    // gradient of the basis functions of the sample point xi_s(k) in the parametric space
    pa_1  = dp_a[0];        // components (xi_1,xi_2) of the gradient
    pa_2  = dp_a[1];
    pb_1  = dp_b[0];        // components (xi_1,xi_2) of the gradient
    pb_2  = dp_b[1];


    //        |Hmem0  Hmem1  Hmem2|
    //        |                   |
    // Hmem = |Hmem3  Hmem4  Hmem5|
    //        |                   |
    //        |Hmem6  Hmem7  Hmem8|

    //MCM = MI_T*C*MJ
    MatMultSquare3D(Hmem, Ma_TxC, Mb);

    //
    //scalar product of: vec.n Id
    vn   = pa_1*pb_1*n[0] + pa_2*pb_2*n[1] + (pa_1*pb_2 + pa_2*pb_1)*n[2];

    Hmem[0] += vn;
    Hmem[4] += vn;
    Hmem[8] += vn;

    return;
}

//________________________________________________________________________________________
//                                   BENDING
//

// The Bending strain-displacement force, where the inputs Acp, Bcp, pt, tp are defined as:
// Acp[0,1,2] = Cross(phi_11, phi_2)
// Acp[3,4,5] = Cross(phi_22, phi_2)
// Acp[6,7,8] = Cross(phi_12, phi_2)
//
// Bcp[0,1,2] = Cross(phi_1, phi_11)
// Bcp[3,4,5] = Cross(phi_1, phi_22)
// Bcp[6,7,8] = Cross(phi_1, phi_12)
//
// pt = Cross(phi_2,     t)
// tp = Cross(   t, phi_1)
void ForceBen (double *Fben,
                double iJ, double *dp_s, double *hp_s,
                double *t, double *m, double *sp,
                double *Acp, double *Bcp, double *pt, double *tp)
{
    int    i;
    double p_1, p_2;
    double p_11, p_22, p_12;
    double val;

    // gradient and Hessian components of the basis functions of the sample point xi_s(k)
    // in the parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];
    p_11 = hp_s[0];     // components (xi_1,xi_2) of the Hessian
    p_12 = hp_s[1];
    p_22 = hp_s[3];

    //
    // Bending strain force
    for (i=0; i<3; i++)
    {
        val     = p_1*pt[i]+ p_2*tp[i];
        Fben[i] = (-p_11*t[i] + iJ* (p_1*Acp[0+i] + p_2*Bcp[0+i] + val*sp[0]))*m[0] +
                  (-p_22*t[i] + iJ* (p_1*Acp[3+i] + p_2*Bcp[3+i] + val*sp[1]))*m[1] +
                  (-p_12*t[i] + iJ* (p_1*Acp[6+i] + p_2*Bcp[6+i] + val*sp[2]))*m[2]*2.0;
    }

    return;
}


//
// Linear thin-shell: Bending strain-displacement matrix is filled
// The gradient of the bending strain-displacement to the node 'I' is computed
// Grad Ben_I = (drho / dP^I) = B^I
void BFilled (double *B,
               double iJ, double *dp_s, double *hp_s,
               double *phi_1, double *phi_2,
               double *phi_11, double *phi_22, double *phi_12,
               double *t, double *sp)
{
    double p_1, p_2, p_11, p_22, p_12;
    double phit[3], tphi[3];
    double cp[3], cp11[3], cp22[3], cp12[3];

    // gradient and Hessian components of the basis functions of the sample point xi_s(k)
    // in the parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];
    p_11 = hp_s[0];     // components (xi_1,xi_2) of the Hessian
    p_12 = hp_s[1];
    p_22 = hp_s[3];

    //
    // Bending strain matrix for the node rowI
    // pa_1 (phi_2 x t) + pa_2 (t x phi_1) = DJ
    Math::Cross (phit, phi_2,     t);
    Math::Cross (tphi,     t, phi_1);
    Math::AXPBY (tphi, 3, p_1, p_2, phit); //y = a*x + b*y

    //cp: cross product
    // pa_1 (phi_11 x phi_2) + pa_2 (phi_1 x phi_11)
    Math::Cross (cp,   phi_11, phi_2 );
    Math::Cross (cp11, phi_1,  phi_11);
    Math::AXPBY (cp11, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_22 x phi_2) + pa_2 (phi_1 x phi_22)
    Math::Cross (cp,   phi_22, phi_2 );
    Math::Cross (cp22, phi_1,  phi_22);
    Math::AXPBY (cp22, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_12 x phi_2) + pa_2 (phi_1 x phi_12)
    Math::Cross (cp,   phi_12, phi_2 );
    Math::Cross (cp12, phi_1,  phi_12);
    Math::AXPBY (cp12, 3, p_1, p_2, cp); //y = a*x + b*y

    // Cirak
    B[0] =  -p_11*t[0] + iJ * (cp11[0] + sp[0]*tphi[0]);
    B[1] =  -p_11*t[1] + iJ * (cp11[1] + sp[0]*tphi[1]);
    B[2] =  -p_11*t[2] + iJ * (cp11[2] + sp[0]*tphi[2]);
    B[3] =  -p_22*t[0] + iJ * (cp22[0] + sp[1]*tphi[0]);
    B[4] =  -p_22*t[1] + iJ * (cp22[1] + sp[1]*tphi[1]);
    B[5] =  -p_22*t[2] + iJ * (cp22[2] + sp[1]*tphi[2]);
    B[6] = (-p_12*t[0] + iJ * (cp12[0] + sp[2]*tphi[0])) * 2.0;
    B[7] = (-p_12*t[1] + iJ * (cp12[1] + sp[2]*tphi[1])) * 2.0;
    B[8] = (-p_12*t[2] + iJ * (cp12[2] + sp[2]*tphi[2])) * 2.0;

    return;
}

//
// Linear thin-shell: Bending strain-displacement matrix is filled, Transposition is enforced
void BFilled_T (double *B_T,
                 double iJ, double *dp_s, double *hp_s,
                 double *phi_1, double *phi_2,
                 double *phi_11, double *phi_22, double *phi_12,
                 double *t, double *sp)
{
    double p_1, p_2, p_11, p_22, p_12;
    double phit[3], tphi[3];
    double cp[3], cp11[3], cp22[3], cp12[3];

    // gradient and Hessian components of the basis functions of the sample point xi_s(k)
    // in the parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];
    p_11 = hp_s[0];     // components (xi_1,xi_2) of the Hessian
    p_12 = hp_s[1];
    p_22 = hp_s[3];

    //
    // Bending strain matrix for the node rowI, transpose
    // DJ = pa_1 (phi_2 x t) + pa_2 (t x phi_1)
    Math::Cross (phit, phi_2,     t);
    Math::Cross (tphi,     t, phi_1);
    Math::AXPBY (tphi, 3, p_1, p_2, phit); //y = a*x + b*y

    //cp: cross product
    // pa_1 (phi_11 x phi_2) + pa_2 (phi_1 x phi_11)
    Math::Cross (cp,   phi_11, phi_2 );
    Math::Cross (cp11, phi_1,  phi_11);
    Math::AXPBY (cp11, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_22 x phi_2) + pa_2 (phi_1 x phi_22)
    Math::Cross (cp,   phi_22, phi_2 );
    Math::Cross (cp22, phi_1,  phi_22);
    Math::AXPBY (cp22, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_12 x phi_2) + pa_2 (phi_1 x phi_12)
    Math::Cross (cp,   phi_12, phi_2 );
    Math::Cross (cp12, phi_1,  phi_12);
    Math::AXPBY (cp12, 3, p_1, p_2, cp); //y = a*x + b*y

    //Cirak
    B_T[0] =  -p_11*t[0] + iJ * (cp11[0] + sp[0]*tphi[0]);
    B_T[1] =  -p_22*t[0] + iJ * (cp22[0] + sp[1]*tphi[0]);
    B_T[2] = (-p_12*t[0] + iJ * (cp12[0] + sp[2]*tphi[0])) * 2.0;
    B_T[3] =  -p_11*t[1] + iJ * (cp11[1] + sp[0]*tphi[1]);
    B_T[4] =  -p_22*t[1] + iJ * (cp22[1] + sp[1]*tphi[1]);
    B_T[5] = (-p_12*t[1] + iJ * (cp12[1] + sp[2]*tphi[1])) * 2.0;
    B_T[6] =  -p_11*t[2] + iJ * (cp11[2] + sp[0]*tphi[2]);
    B_T[7] =  -p_22*t[2] + iJ * (cp22[2] + sp[1]*tphi[2]);
    B_T[8] = (-p_12*t[2] + iJ * (cp12[2] + sp[2]*tphi[2])) * 2.0;

    return;
}

// NONLINEAR thin-shell: The Bending strain-displacement matrix is filled
void BFilled   (double *F, double *DJ, double *B, double *W ,
		 double iJ, double *dp_s, double *hp_s,
                 double *phi_1, double *phi_2,
                 double *phi_11, double *phi_22, double *phi_12,
                 double *t, double *sp, double *m)
{
    double p_1, p_2, p_11, p_22, p_12;
    double pt[3];
    double cp[3], cp11[3], cp22[3], cp12[3];

    // gradient and Hessian components of the basis functions of the sample point xi_s(k)
    // in the parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];
    p_11 = hp_s[0];     // components (xi_1,xi_2) of the Hessian
    p_12 = hp_s[1];
    p_22 = hp_s[3];

    //
    // Bending strain matrix for the node rowI
    // DJ = pa_1 (phi_2 x t) + pa_2 (t x phi_1)
    Math::Cross (pt, phi_2,     t);
    Math::Cross (DJ,     t, phi_1);
    Math::AXPBY (DJ, 3, p_1, p_2, pt); //y = a*x + b*y

    //cp: cross product
    // pa_1 (phi_11 x phi_2) + pa_2 (phi_1 x phi_11)
    Math::Cross (cp,   phi_11, phi_2 );
    Math::Cross (cp11, phi_1,  phi_11);
    Math::AXPBY (cp11, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_22 x phi_2) + pa_2 (phi_1 x phi_22)
    Math::Cross (cp,   phi_22, phi_2 );
    Math::Cross (cp22, phi_1,  phi_22);
    Math::AXPBY (cp22, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_12 x phi_2) + pa_2 (phi_1 x phi_12)
    Math::Cross (cp,   phi_12, phi_2 );
    Math::Cross (cp12, phi_1,  phi_12);
    Math::AXPBY (cp12, 3, p_1, p_2, cp); //y = a*x + b*y

    // Cirak
    B[0] =  -p_11*t[0] + iJ * (cp11[0] + sp[0]*DJ[0]);
    B[1] =  -p_11*t[1] + iJ * (cp11[1] + sp[0]*DJ[1]);
    B[2] =  -p_11*t[2] + iJ * (cp11[2] + sp[0]*DJ[2]);
    B[3] =  -p_22*t[0] + iJ * (cp22[0] + sp[1]*DJ[0]);
    B[4] =  -p_22*t[1] + iJ * (cp22[1] + sp[1]*DJ[1]);
    B[5] =  -p_22*t[2] + iJ * (cp22[2] + sp[1]*DJ[2]);
    B[6] = (-p_12*t[0] + iJ * (cp12[0] + sp[2]*DJ[0])) * 2.0;
    B[7] = (-p_12*t[1] + iJ * (cp12[1] + sp[2]*DJ[1])) * 2.0;
    B[8] = (-p_12*t[2] + iJ * (cp12[2] + sp[2]*DJ[2])) * 2.0;

    //Bending Force
    VxM_Row(F, 3, 3, m, B);

    pt[0] = phi_1[0];
    pt[1] = phi_1[1];
    pt[2] = phi_1[2];

    Math::AXPBY (pt, 3, -p_1, p_2, phi_2); //y = a*x + b*y
    W[0] =    0.0;          W[1] = -pt[2];          W[2] =  pt[1];
    W[3] =  pt[2];          W[4] =    0.0;          W[5] = -pt[0];
    W[6] = -pt[1];          W[7] =  pt[0];          W[8] =    0.0;
    return;
}


//
// NONLINEAR thin-shell: Bending strain-displacement matrix is filled, Transposition is enforced
void BFilled_T (double *F, double *DJ, double *B_T, double *W_T,
                 double iJ, double *dp_s, double *hp_s,
                 double *phi_1, double *phi_2,
                 double *phi_11, double *phi_22, double *phi_12,
                 double *t, double *sp, double *m)
{
    double p_1, p_2, p_11, p_22, p_12;
    double pt[3];
    double cp[3], cp11[3], cp22[3], cp12[3];

    // gradient and Hessian components of the basis functions of the sample point xi_s(k)
    // in the parametric space
    p_1  = dp_s[0];     // components (xi_1,xi_2) of the gradient
    p_2  = dp_s[1];
    p_11 = hp_s[0];     // components (xi_1,xi_2) of the Hessian
    p_12 = hp_s[1];
    p_22 = hp_s[3];

    //
    // Bending strain matrix for the node rowI, transpose

    //Jacobian Derivative: pa,1 (phi,2 x t) + pa,2 (t x phi,1)
    Math::Cross (pt, phi_2,     t);
    Math::Cross (DJ,     t, phi_1);
    Math::AXPBY (DJ, 3, p_1, p_2, pt); //y = a*x + b*y

    //cp: cross product
    // pa_1 (phi_11 x phi_2) + pa_2 (phi_1 x phi_11)
    Math::Cross (cp,   phi_11, phi_2 );
    Math::Cross (cp11, phi_1,  phi_11);
    Math::AXPBY (cp11, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_22 x phi_2) + pa_2 (phi_1 x phi_22)
    Math::Cross (cp,   phi_22, phi_2 );
    Math::Cross (cp22, phi_1,  phi_22);
    Math::AXPBY (cp22, 3, p_1, p_2, cp); //y = a*x + b*y

    // pa_1 (phi_12 x phi_2) + pa_2 (phi_1 x phi_12)
    Math::Cross (cp,   phi_12, phi_2 );
    Math::Cross (cp12, phi_1,  phi_12);
    Math::AXPBY (cp12, 3, p_1, p_2, cp); //y = a*x + b*y

    //Cirak
    B_T[0] =  -p_11*t[0] + iJ * (cp11[0] + sp[0]*DJ[0]);
    B_T[1] =  -p_22*t[0] + iJ * (cp22[0] + sp[1]*DJ[0]);
    B_T[2] = (-p_12*t[0] + iJ * (cp12[0] + sp[2]*DJ[0])) * 2.0;
    B_T[3] =  -p_11*t[1] + iJ * (cp11[1] + sp[0]*DJ[1]);
    B_T[4] =  -p_22*t[1] + iJ * (cp22[1] + sp[1]*DJ[1]);
    B_T[5] = (-p_12*t[1] + iJ * (cp12[1] + sp[2]*DJ[1])) * 2.0;
    B_T[6] =  -p_11*t[2] + iJ * (cp11[2] + sp[0]*DJ[2]);
    B_T[7] =  -p_22*t[2] + iJ * (cp22[2] + sp[1]*DJ[2]);
    B_T[8] = (-p_12*t[2] + iJ * (cp12[2] + sp[2]*DJ[2])) * 2.0;

    //Bending Force
    MxV_Row(F, 3, 3, B_T, m);

    pt[0] = phi_1[0];
    pt[1] = phi_1[1];
    pt[2] = phi_1[2];

    Math::AXPBY (pt, 3, -p_1, p_2, phi_2); //y = a*x + b*y
    W_T[0] =    0.0;            W_T[1] =  pt[2];            W_T[2] = -pt[1];
    W_T[3] = -pt[2];            W_T[4] =    0.0;            W_T[5] =  pt[0];
    W_T[6] =  pt[1];            W_T[7] = -pt[0];            W_T[8] =    0.0;
    return;
}

//Hessian for the Bending Potential Energy Density
void HessBen ( double *Hben,
                double iJ, double *dp_a, double *hp_a, double *dp_b, double *hp_b,
                double *sp, double *m, double *DW,
                double *Ba_TxC, double *Bb, double *Wa_T, double *Wb,
                double *DJa, double *DJb, double *Fa, double *Fb)
{
    double  spm, cb, ca;
    double  pa_1 , pa_2 , pb_1 , pb_2;
    double  pa_11, pa_12, pa_22;
    double  pb_11, pb_12, pb_22;

    double FxDJ_ab[9], DJxF_ab[9], DJxDJ_ab[9], WW[9];

    // gradient of the basis functions of the sample point xi_s(k) in the parametric space
    pa_1  = dp_a[0];        // components (xi_1,xi_2) of the gradient
    pa_2  = dp_a[1];
    pb_1  = dp_b[0];        // components (xi_1,xi_2) of the gradient
    pb_2  = dp_b[1];

    pa_11 = hp_a[0];        // components (xi_1,xi_2) of the Hessian
    pa_12 = hp_a[1];
    pa_22 = hp_a[3];

    pb_11 = hp_b[0];        // components (xi_1,xi_2) of the Hessian
    pb_12 = hp_b[1];
    pb_22 = hp_b[3];

    //        |Hben0  Hben1  Hben2|
    //        |                   |
    // Hben = |Hben3  Hben4  Hben5|
    //        |                   |
    //        |Hben6  Hben7  Hben8|

    //BCB = BI_T*C*BJ
    MatMultSquare3D(Hben, Ba_TxC, Bb);

    // FxDJ_ab
    TensProd (FxDJ_ab, 3, Fa, DJb);
    Math::AXPY (Hben, 9, -iJ, FxDJ_ab);  //y = a*x + y
    // DJxF_ab;
    TensProd (DJxF_ab, 3, DJa, Fb);
    Math::AXPY (Hben, 9, -iJ, DJxF_ab);

    // DJxDJ_ab
    TensProd (DJxDJ_ab, 3, DJa, DJb);
    // scalar product of (t.phi_11, t.phi_22, 2 t.phi_12).m
    spm = sp[0]*m[0] + sp[1]*m[1] + 2.0*sp[2]*m[2];
    Math::AXPY (Hben, 9, -iJ*iJ*spm, DJxDJ_ab);

    // -iJ pb_ab Wa_T - iJ pa_ab W_b
    ca = -iJ*(pa_11*m[0] + pa_22*m[1] + 2.0*pa_12*m[2]);
    cb = -iJ*(pb_11*m[0] + pb_22*m[1] + 2.0*pb_12*m[2]);
    Math::AXPY (Hben, 9, cb, Wa_T);
    Math::AXPY (Hben, 9, ca, Wb  );

    // iJ^2 [(t.phi_11, t.phi_22, 2 t.phi_12).m] Wa_T*Wb
    MatMultSquare3D(WW, Wa_T, Wb);

    Math::AXPY(Hben, 9, iJ*iJ*spm, WW);

    // -iJ (-pa_1 pb_2+pa_2 pb_1) DW
    Math::AXPY(Hben, 9, -iJ*(-pa_1*pb_2 + pa_2*pb_1), DW);
    return;
}

// This function fill the RHS contribution of a THIN-SHELL at each element in a imposed displacement case
void LinearShellGradientByElement(RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //Initialize
    SubFillStructure& subFill = (*fillStr)["dofHand_u"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes

    //Fill rhs
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < DOF; d++)
            fillStr->Bk(0)[i*DOF+d] += 0.0;
    }

    return;
}


// This function fill the elemental full system matrix for a LINEAR thin-shell Kmat,
// which is symmetric and then only is needed to fill the upper part.
// The linear thin-shell model is that from Kirchhoff-Love assumptions.
void LinearShellHessianByElement(RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //auxiliary variables
    bool    passAux = false;
    int     i, j, k, iD, jD, iD2, jD2;
    int     iDOF, jDOF;
    double  w_k, Mcte, Bcte, mw_k, bw_k, Wv_k;

    // Material and Geometrical parameters for a Shell
    double  E          = 0.0;   //Young's modulus
    double  nu         = 0.0;   //Poisson's ratio
    double  hh         = 0.0;   //thickness of the thin shell

    int     tDim       = 2;     //embedded dimension
    int     nDim       = 3;     //spatial dimension where the data points are living

    //INPUTS declaration
    int     DOF        = 0;     //number of degrees of freedom of the physical variable at each node
    int     eNN        = 0;     //number of nearest neighbors to each element (also to each Gauss point)
    double  *dp_e      = NULL;  //Gradients of the basis functions for all Gauss points in an element (2D)
    double  *hp_e      = NULL;  //Hessians of the basis functions for all Gauss points in an element (2D)
    double  *xe_nodRef = NULL;  //REFERENCE nearest nodes (control points) coordinates (3D)
    double  *df_samples= NULL;  //phase field degradation function at each Gauss point

    //Intermediate auxiliary variables
    int     N_e        = 0;     //number of rows of the stiffness matrix in an element
    double   jac0      = 0.0;   //Jacobian in the middle reference surface at the Gauss point xi_k
    double  iJac0      = 0.0;   //Jacobian inverse in the middle reference surface at the Gauss point xi_k
    double  iDet0      = 0.0;   //inverse of the determinant of the metric tensor in the reference surface

    double  a11_, a22_, a12_;

    double  Ip0 [4];    //first fundamental form, or metric tensor g
    double  phi0_1[3];  //gradient of the mapping in the parametrical direction xi_1
    double  phi0_2[3];  //gradient of the mapping in the parametrical direction xi_2
    //double  Ip0_[4];  //inverse of the metric tensor

    double  IIp0 [4];   //second fundamental form, or curvature tensor 'kappa'
    double  phi0_11[3]; //Hessian of the mapping in the parametrical direction (xi_1,xi_1)
    double  phi0_22[3]; //Hessian of the mapping in the parametrical direction (xi_2,xi_2)
    double  phi0_12[3]; //Hessian of the mapping in the parametrical direction (xi_1,xi_2)
    double  t0[3];      //normal to the middle surface in the reference configuration
    double  C [9];      //Elasticity tensor in Voigt's notation
    double  sp[3];      //store the scalar product between the normal and the phi0_{alpha,beta}

    double  Ma_T[9], Mb[9], Ma_TxC[9], MCM[9]; //membrane auxiliary matrices
    double  Ba_T[9], Bb[9], Ba_TxC[9], BCB[9]; //bending auxiliary matrices

    double  *dp_k      = NULL;  //Gradients at the Gauss point xi_k
    double  *hp_k      = NULL;  //Hessians at the Gauss point xi_k


    // --------------------------------------------
    //INPUT definition
    SubFillStructure& subFill = (*fillStr)["dofHand_u"];
    DOF       = subFill.numDOFs;   //Number of degrees of freedom
    eNN       = subFill.eNN;       //Number of neighbor nodes
    nDim      = subFill.nDim;      //Number of spatial dimensions
    tDim      = subFill.pDim;      //Number of parametric dimensions

    xe_nodRef = subFill.nborCoords.data();  // Vector of node coordinates
    dp_k      = subFill.nborBFsDers(1); //Local shape function derivatives
    hp_k      = subFill.nborBFsDers(2); //Local shape function hessians

    // passAux   = fillStr->userStr->passAux;
    E         = fillStr->userStr->dparam[0];
    nu        = fillStr->userStr->dparam[1];
    hh        = fillStr->userStr->dparam[3];

    // df_samples= fillStr->ae_samples; //<== INPUT

    //Differential geometry
    //Curvatures: normals, Jacobian, and fundamental forms are computed at the sample (Gauss) point
    SurfLagrParam::Curvatures (IIp0, Ip0, t0, phi0_1, phi0_2, phi0_11, phi0_22, phi0_12,
                                eNN, xe_nodRef, dp_k, hp_k);

    N_e  = eNN*DOF; //number of nonzeros elements by row in the stiffness Matrix

    //Jacobian of the middle reference surface
    jac0  = sqrt(ABS(Ip0[0]*Ip0[3] - Ip0[1]*Ip0[2]));
    iJac0 = 1.0 / jac0;

    //variables initialization
    Mcte = hh*E/(1.0-nu*nu);
    Bcte = hh*hh*Mcte/12.0;

    //Gauss quadrature weight: w_g * Jac_g
    w_k = jac0;
    // if (passAux == true)
    // {
    //     Wv_k = df_samples[k];
    //     w_k  = w_k*Wv_k;
    // }
    mw_k    = Mcte*w_k;
    bw_k    = Bcte*w_k;

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    //C Matrix in Voigt's notation

    //First Fundamental Form in the covariant basis Ip[k] = [E F; F G]_k
    //Inverse of the metric tensor
    iDet0 =  iJac0*iJac0;
    a11_  =  iDet0*Ip0[3];
    a22_  =  iDet0*Ip0[0];
    a12_  = -iDet0*Ip0[1];

    //     | C[0] C[1] C[2] |
    // C = | C[3] C[4] C[5] |           Elasticity tensor
    //     | C[6] C[7] C[8] |
    C[0]  = a11_*a11_;  C[1] = nu*a11_*a22_+ (1.0-nu)*a12_*a12_;
    C[2]  = a11_*a12_;  C[3] = C[1];
    C[4]  = a22_*a22_;  C[5] = a12_*a22_;
    C[6]  = C[2];       C[7] = C[5];
    C[8]  = 0.5 * ((1.0-nu)*a11_*a22_ + (1.0+nu)*a12_*a12_);

    //sp: scalar product
    sp[0] = -IIp0[0]; //t0.phi0_11
    sp[1] = -IIp0[3]; //t0.phi0_22
    sp[2] = -IIp0[1]; //t0.phi0_12


    // loop on the kNN neighbors of the k-th Gauss points
    for (i=0; i<eNN; i++)
    {
        // Indexes settings
        iD    = i*tDim;
        iD2   = iD*tDim;
        iDOF  = i*DOF;

        //[1]
        //First the diagonal terms are computed

        //[1.a] membrane
        //Membrane strain-displacement gradient matrix
        MFilled_T (Ma_T, &dp_k[iD], phi0_1, phi0_2);
        //Ma_TxC = Ma_T*C
        MatMultSquare3D (Ma_TxC, Ma_T, C);

        //Ma = (Ma_T)^T
        MatTranspose3D  (Mb, Ma_T);
        //MCM = Ma_T*C*Mb
        MatMultSquare3D (MCM, Ma_TxC, Mb);

        //[1.b] bending
        //Bending strain-displacement gradient matrix
        BFilled_T (Ba_T, iJac0, &dp_k[iD], &hp_k[iD2],
                    phi0_1, phi0_2, phi0_11, phi0_22, phi0_12, t0, sp);
        //Ba_TxC = Ba_T*C
        MatMultSquare3D (Ba_TxC, Ba_T, C);
        //Ba = (Ba_T)^T
        MatTranspose3D  (Bb, Ba_T);
        //BCB = Ba_T*C*Bb
        MatMultSquare3D (BCB, Ba_TxC, Bb);

        //[1.c]
        //Now the result is stored in BCB
        Math::AXPBY (BCB, 9, mw_k, bw_k, MCM);   //X = a*X + b*Y

        // FILL DIAGONAL term of K_e[i,i]
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+0)] += BCB[0];
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+1)] += BCB[1];
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+2)] += BCB[2];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+0)] += BCB[3];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+1)] += BCB[4];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+2)] += BCB[5];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+0)] += BCB[6];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+1)] += BCB[7];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+2)] += BCB[8];


        //the following terms after the diagonal
        for (j=i+1; j<eNN; j++)
        {
            // x of the variable evaluated in the node j
            // Indexes settings
            jD    = j*tDim;
            jD2   = jD*tDim;
	    jDOF  = j*DOF;

            //[2.a] membrane
            //Membrane strain-displacement gradient matrix
            MFilled (Mb, &dp_k[jD], phi0_1, phi0_2);
            //MCM = Ma_T*C*Mb
            MatMultSquare3D (MCM, Ma_TxC, Mb);

            //[2.b] bending
            //Bending strain-displacement gradient matrix
            BFilled (Bb, iJac0, &dp_k[jD], &hp_k[jD2],
                      phi0_1, phi0_2, phi0_11, phi0_22, phi0_12, t0, sp);
            //BCB = Ba_T*C*Bb
            MatMultSquare3D (BCB, Ba_TxC, Bb);

            //[2.c] Now the result is stored in BCB
            Math::AXPBY (BCB, 9, mw_k, bw_k, MCM);

            // FILL NON DIAGONAL term of K_e[i,j]
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+0)] += BCB[0];
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+1)] += BCB[1];
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+2)] += BCB[2];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+0)] += BCB[3];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+1)] += BCB[4];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+2)] += BCB[5];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+0)] += BCB[6];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+1)] += BCB[7];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+2)] += BCB[8];

            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+0)] += BCB[0];
            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+1)] += BCB[3];
            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+2)] += BCB[6];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+0)] += BCB[1];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+1)] += BCB[4];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+2)] += BCB[7];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+0)] += BCB[2];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+1)] += BCB[5];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+2)] += BCB[8];
        }//end for in j
    }//end for in i

    return;
}

// This function computes the Energy gradient contribution at each element in a surface case
// Geometrically NONLINEAR thin-shell elasticity coupled with a phase field describing
// a fracture (optionally, check passAux).
void ShellGradientByElement (RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //auxiliary variables
    bool   passAux = false;
    int    i, j, k, iD, iD2;
    double w_k;
    double Mcte, Bcte, mw_k, bw_k, eneMem, eneBen;

    //INPUTS declaration
    int    tDim      = 2;     //dimension of the parametric space
    int    nDim      = 0;     //spatial dimension where the data points are living
    int    DOF       = 0;     //number of degrees of freedom of the physical variable at each node
    int    eNN       = 0;     //number of nearest neighbors to each element (also to each Gauss point)

    // Material and Geometrical parameters for a Shell
    double E         = 0.0;   //Young's modulus
    double nu        = 0.0;   //Poisson's ratio
    double hh        = 0.0;   //thickness of the thin shell

    double *xe_nodRef = NULL;  //REFERENCE nearest nodes (control points) coordinates (3D)
    double *xe_nodDef = NULL;  //CONVECTED coordinates for the nearest neighbor of Gauss point (3D)
    double *ue_nodes  = NULL;  //convected deformation at each DOF of xe_nodes

    //Intermediate auxiliary variables
    double *dp_k      = NULL;  //Gradients at the Gauss point xi_k
    double *hp_k      = NULL;  //Hessians at the Gauss point xi_k
    double *df_samples= NULL;  //phase field degradation function at each Gauss point

    //Intermediate auxiliary variables
    int     N_e        = 0;     //number of rows of the stiffness matrix in an element
    double jac0       = 0.0;   //Jacobian on the middle reference surface at the Gauss point xi_k
    double iJac0      = 0.0;   //Jacobian inverse on the middle reference surface at the Gauss point xi_k
    double iDet0      = 0.0;   //inverse of the determinant of the metric tensor in the reference surface
    double a11_, a22_, a12_;

    double jac        = 0.0;     //Jacobian on the middle convected surface at the Gauss point xi_k
    double iJac       = 0.0;     //Jacobian inverse on the middle convected surface at the Gauss point xi_k

    double Ip0 [4],   Ip[4];     //first fundamental form, or metric tensor g
    double phi0_1[3], phi_1[3];  //gradient of the mapping in the parametric direction xi_1
    double phi0_2[3], phi_2[3];  //gradient of the mapping in the parametric direction xi_2

    double IIp0 [4],   IIp [4];   //second fundamental form, or curvature tensor 'kappa'
    double phi0_11[3], phi_11[3]; //Hessian of the mapping in the parametric direction (xi_1,xi_1)
    double phi0_22[3], phi_22[3]; //Hessian of the mapping in the parametric direction (xi_2,xi_2)
    double phi0_12[3], phi_12[3]; //Hessian of the mapping in the parametric direction (xi_1,xi_2)
    double t0[3],      t[3];      //normal to the middle surface in the reference configuration
    double C[9];                  //Elasticity tensor in Voigt's notation
    double eps[3], nStress[3];    //membrane strain/stress tensor in Voigt's notation
    double rho[3], mStress[3];    //bending strain/stress tensor in Voigt's notation

    double sp[3];                 //store the scalar product between the normal and the phi0_{alpha,beta}

    double Acp[9], Bcp[9];        //auxiliary matrix containing cross products among Dphi and Hphi
    double pt [3],  tp[3];        //auxiliary vector to store cross products of Dphi and t
    double Fmem[3];               //Membrane forces: n^T . grad(eps)
    double Fben[3];               //Bending forces : m^T . grad(rho)

    //MAIN OUTPUT declaration
    double energy_e   = 0.0;      //thin-shell energy contribution at a the present element

    // --------------------------------------------
    //Initialize
    SubFillStructure& subFill = (*fillStr)["dofHand_u"];

    //INPUT definition and variables initialization
    nDim      = subFill.nDim;
    DOF       = subFill.numDOFs;
    eNN       = subFill.eNN;
    tDim      = subFill.pDim;      //Number of parametric dimensions

    xe_nodRef = subFill.nborCoords.data();  // Vector of node coordinates
    ue_nodes  = subFill.nborDOFs.data();
    dp_k      = subFill.nborBFsDers(1); //Local shape function derivatives
    hp_k      = subFill.nborBFsDers(2); //Local shape function hessians

    // passAux   = fillStr->userStr->passAux;
    E         = fillStr->userStr->dparam[0];
    nu        = fillStr->userStr->dparam[1];
    hh        = fillStr->userStr->dparam[3];

    N_e       = eNN*DOF; //number of nonzeros elements by row in the stiffness Matrix
    Mcte      = hh*E/(1.0-nu*nu);
    Bcte      = hh*hh*Mcte/12.0;

    //passAux   = subFill.userStr->passAux;
    //df_samples= subFill.ae_samples; //<== INPUT

    //Convected configuration: x_def = x0 + u
    xe_nodDef = ue_nodes;
    if (subFill.kPt == 0)
        Math::AXPY(xe_nodDef, N_e, 1.0, xe_nodRef);  //y=a*x+y

    //variables initialization
    energy_e  = 0.0; //energy of the element

    //Differential Geometry
    //Curvatures: normals, Jacobian, and fundamental forms are computed at the sample (Gauss) point
    //Reference configuration
    SurfLagrParam::Curvatures (IIp0, Ip0, t0, phi0_1, phi0_2, phi0_11, phi0_22, phi0_12,
                                eNN, xe_nodRef, dp_k, hp_k);

    // Deformed configuration:  x = u + x0
    SurfLagrParam::Curvatures (IIp, Ip, t, phi_1, phi_2, phi_11, phi_22, phi_12,
                                eNN, xe_nodDef, dp_k, hp_k);

    //Jacobian of the middle reference surface
    jac0  = sqrt(ABS(Ip0[0]*Ip0[3] - Ip0[1]*Ip0[2]));
    iJac0 = 1.0 / jac0;

    jac   = sqrt(ABS(Ip[0]*Ip[3] - Ip[1]*Ip[2]));
    iJac  = 1.0 / jac;

    //Gauss quadrature weight: w_g * Jac_g
    w_k   = jac0;

    //--------------------------------------------------------------------------------
    //Hessian system matrix of the thin-shell elasticity (matrix in Voigt's notation)
    // if (passAux == true)
    // {
    //    w_k  = w_k*df_samples[k];
    // }
    mw_k    = Mcte*w_k;
    bw_k    = Bcte*w_k;

    //First Fundamental Form in the covariant basis Ip[k] = [E F; F G]_k
    //Inverse of the metric tensor
    iDet0 =  iJac0*iJac0;
    a11_  =  iDet0*Ip0[3];
    a22_  =  iDet0*Ip0[0];
    a12_  = -iDet0*Ip0[1];

    //     | C[0] C[1] C[2] |
    // C = | C[3] C[4] C[5] |           Elasticity tensor
    //     | C[6] C[7] C[8] |
    C[0]  = a11_*a11_;  C[1] = nu*a11_*a22_+ (1.0-nu)*a12_*a12_;
    C[2]  = a11_*a12_;  C[3] = C[1];
    C[4]  = a22_*a22_;  C[5] = a12_*a22_;
    C[6]  = C[2];       C[7] = C[5];
    C[8]  = 0.5 * ((1.0-nu)*a11_*a22_ + (1.0+nu)*a12_*a12_);

    //sp: scalar product
    sp[0] = -IIp[0]; //t0.phi0_11
    sp[1] = -IIp[3]; //t0.phi0_22
    sp[2] = -IIp[1]; //t0.phi0_12

    //--------------------------------------------------------------------------------
    // GREEN-LAGRANGE strain tensor   E = eps + rho

    // membrane strain tensor
    // eps_ab = 0.5 * (phi,a . phi,b - phi0,a . phi0,b)
    eps[0]  = (Ip[0] - Ip0[0]) * 0.5;
    eps[1]  = (Ip[3] - Ip0[3]) * 0.5;
    eps[2]  = (Ip[1] - Ip0[1]);

    // bending strain tensor
    // rho_ab = phi0,ab . t0 - phi,ab . t  = II - II0
    rho[0]  = (IIp[0] - IIp0[0]);
    rho[1]  = (IIp[3] - IIp0[3]);
    rho[2]  = (IIp[1] - IIp0[1]) * 2.0;

    //--------------------------------------------------------------------------------
    // Stress tensors
    // membrane stress tensor: n = h * C * eps
    MxV_Row(nStress, 3, 3, C, eps);

    // bending stress tensor:  m = (h^3)/12 * C * rho
    MxV_Row(mStress, 3, 3, C, rho);

    //--------------------------------------------------------------------------------
    // Energy density contribution of the Gauss point k
    // EneDen = EDmem + EDben = 0.5 (eps.n + rho.m)
    eneMem    = 0.5 * Math::Dot3D(eps, nStress) * Mcte;
    eneBen    = 0.5 * Math::Dot3D(rho, mStress) * Bcte;
    energy_e += (eneMem + eneBen)*w_k;

    //--------------------------------------------------------------------------------
    // Shell Energy Gradient loop on the eNN neighbors of the k-th Gauss points

    // Acp = [Cross(phi_11, phi_2); Cross(phi_22, phi_2); Cross(phi_12, phi_2)]
    Math::Cross(&Acp[0], phi_11, phi_2);
    Math::Cross(&Acp[3], phi_22, phi_2);
    Math::Cross(&Acp[6], phi_12, phi_2);

    // Bcp = [Cross(phi_1, phi_11); Cross(phi_1, phi_22); Cross(phi_1, phi_12)]
    Math::Cross(&Bcp[0], phi_1, phi_11);
    Math::Cross(&Bcp[3], phi_1, phi_22);
    Math::Cross(&Bcp[6], phi_1, phi_12);

    Math::Cross(pt, phi_2,     t);
    Math::Cross(tp,     t, phi_1);

    //Fill rhs
    for (i = 0; i < eNN; i++)
    {
        // Indexes settings
        iD   = i*tDim;
        iD2  = iD*tDim;

        // F_mem(I) = n^T Ma
        ForceMem (Fmem, &dp_k[iD], phi_1, phi_2, nStress);

        // F_ben(I) = m^T Ba
        ForceBen (Fben, iJac, &dp_k[iD], &hp_k[iD2],
                   t, mStress, sp, Acp, Bcp, pt, tp);

        // FILL the Energy Gradient: thin-shell elasticity + cohesion
        fillStr->Bk(0)[i*DOF+0] += Fmem[0]*mw_k + Fben[0]*bw_k;
        fillStr->Bk(0)[i*DOF+1] += Fmem[1]*mw_k + Fben[1]*bw_k;
        fillStr->Bk(0)[i*DOF+2] += Fmem[2]*mw_k + Fben[2]*bw_k;
    }

    fillStr->addToGlobalIntegral("Elastic_Energy", energy_e);

    return;
}


// This function fill the elemental full system matrix for a NONLINEAR thin-shell Kmat,
// which is symmetric and then only is needed to fill the upper part.
// The geometrical nonlinear thin-shell model is that from Kirchhoff-Love assumptions.
void ShellHessianByElement (RCP<hiperlife::FillStructure> fillStr)
{
    //auxiliary variables
    bool    passAux = false;
    int     i, j, k, iD, jD, iD2, jD2;
    int     iDOF, jDOF;
    double  w_k, Mcte, Bcte, mw_k, bw_k, Wv_k;

    // Material and Geometrical parameters for a Shell
    double  E          = 0.0;     //Young's modulus
    double  nu         = 0.0;     //Poisson's ratio
    double  hh         = 0.0;     //thickness of the thin shell

    int     tDim       = 2;       //embedded dimension
    int     nDim       = 3;       //spatial dimension where the data points are living

    //INPUTS declaration
    int     DOF        = 0;        //number of degrees of freedom of the physical variable at each node
    int     eNN        = 0;        //number of nearest neighbors to each element (also to each Gauss point)

    double  *xe_nodRef = NULL;     //REFERENCE nearest nodes (control points) coordinates (3D)
    double  *xe_nodDef = NULL;     //CONVECTED coordinates for the nearest neighbor of Gauss point (3D)
    double  *ue_nodes  = NULL;     //convected displacement values at each nearest neighbor of the Gauss points
    double  *df_samples= NULL;     //phase field degradation function at each Gauss point

    //Intermediate auxiliary variables
    int     N_e        = 0;        //number of rows of the stiffness matrix in an element
    int     NNZ_e      = 0;        //number of Non Zeros of the stiffness matrix in an element
    double  jac0       = 0.0;      //Jacobian in the middle reference surface at the Gauss point xi_k
    double  iJac0      = 0.0;      //Jacobian inverse on the middle reference surface at the Gauss point xi_k
    double  iDet0      = 0.0;      //inverse of the determinant of the metric tensor in the reference surface
    double  spm        = 0.0;      //scalar product of (t.phi_11,t.phi_22,2t.phi_12).m
    double  iJac       = 0.0;      //Jacobian inverse on the middle convected surface at the Gauss point xi_k
    double  a11_, a22_, a12_;

    double  Ip0 [4],   Ip[4];      //first fundamental form, or metric tensor g
    double  phi0_1[3], phi_1[3];   //gradient of the mapping in the parametric direction xi_1
    double  phi0_2[3], phi_2[3];   //gradient of the mapping in the parametric direction xi_2
    //double  Ip0_[4];               //inverse of the metric tensor

    double  IIp0 [4],   IIp [4];   //second fundamental form, or curvature tensor 'kappa'
    double  phi0_11[3], phi_11[3]; //Hessian of the mapping in the parametric direction (xi_1,xi_1)
    double  phi0_22[3], phi_22[3]; //Hessian of the mapping in the parametric direction (xi_2,xi_2)
    double  phi0_12[3], phi_12[3]; //Hessian of the mapping in the parametric direction (xi_1,xi_2)
    double  t0[3],      t[3];      //normal to the middle surface in the reference configuration
    double  C[9];                  //Elasticity tensor in Voigt's notation
    double  eps[3], nStress[3];    //membrane strain tensor in Voigt's notation
    double  rho[3], mStress[3];    //bending strain tensor in Voigt's notation
    double  sp[3];      //store the scalar product between the normal and the phi0_{alpha,beta}
    double  mp[3];      //vector matrix product, m^T phi_ab
    double  DW[9];      //antisymmetric matrix

    //auxiliary force vectors and membrane/bending matrices for each node I, J
    double  FbenI[3], FbenJ[3]; //Bending forces
    double  DJacI[3], DJacJ[3]; //Jacobian gradient
    double  MI_T[9], MJ[9], MI_TxC[9], Hmem[9]; //membrane auxiliary matrices
    double  BI_T[9], BJ[9], BI_TxC[9], WI_T[9], WJ[9], Hben[9]; //bending auxiliary matrices

    double *dp_k;      //Gradients at the Gauss point xi_k
    double *hp_k;      //Hessians at the Gauss point xi_k

    // --------------------------------------------
    //Initialize
    SubFillStructure& subFill = (*fillStr)["dofHand_u"];

    //INPUT definition and variables initialization
    nDim      = subFill.nDim;
    DOF       = subFill.numDOFs;
    eNN       = subFill.eNN;
    tDim      = subFill.pDim;      //Number of parametric dimensions

    xe_nodRef = subFill.nborCoords.data();  // Vector of node coordinates
    ue_nodes  = subFill.nborDOFs.data();
    dp_k      = subFill.nborBFsDers(1); //Local shape function derivatives
    hp_k      = subFill.nborBFsDers(2); //Local shape function hessians

    // passAux   = fillStr->userStr->passAux;
    E         = fillStr->userStr->dparam[0];
    nu        = fillStr->userStr->dparam[1];
    hh        = fillStr->userStr->dparam[3];

    //passAux   = subFill.userStr->passAux;
    //df_samples= subFill.ae_samples; //<== INPUT

    N_e       = eNN*DOF; //number of nonzeros elements by row in the stiffness Matrix
    Mcte      = hh*E/(1.0-nu*nu);
    Bcte      = hh*hh*Mcte/12.0;

    //Convected configuration: x_def = x0 + u
    xe_nodDef = ue_nodes;
    if (subFill.kPt == 0)
        Math::AXPY(xe_nodDef, N_e, 1.0, xe_nodRef);  //y=a*x+y

    // --------------------------------------------
    //Differential Geometry
    //Curvatures: normals, Jacobian, and fundamental forms are computed at the sample (Gauss) point
    //Reference configuration
    SurfLagrParam::Curvatures (IIp0, Ip0, t0, phi0_1, phi0_2, phi0_11, phi0_22, phi0_12,
                                eNN, xe_nodRef, dp_k, hp_k);

    // Deformed configuration:  x = u + x0
    SurfLagrParam::Curvatures (IIp, Ip, t, phi_1, phi_2, phi_11, phi_22, phi_12,
                                eNN, xe_nodDef, dp_k, hp_k);

    //df_samples= fillStr->ae_samples;

    //Jacobian of the middle reference surface
    jac0  = sqrt(ABS(Ip0[0]*Ip0[3] - Ip0[1]*Ip0[2]));
    iJac0 = 1.0 / jac0;

    //Jacobian inverse of the middle convected surface
    iJac  = 1.0 / sqrt(ABS(Ip[0]*Ip[3] - Ip[1]*Ip[2]));

    //Gauss quadrature weight: w_g * Jac_g
    w_k = jac0;
    // if (passAux == true)
    // {
    //     Wv_k = df_samples[k];
    //     w_k  = w_k*Wv_k;
    // }
    mw_k    = Mcte*w_k;
    bw_k    = Bcte*w_k;

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    //C Matrix in Voigt's notation

    //First Fundamental Form in the covariant basis Ip[k] = [E F; F G]_k
    //Inverse of the metric tensor
    iDet0 =  iJac0*iJac0;
    a11_  =  iDet0*Ip0[3];
    a22_  =  iDet0*Ip0[0];
    a12_  = -iDet0*Ip0[1];

    //     | C[0] C[1] C[2] |
    // C = | C[3] C[4] C[5] |           Elasticity tensor
    //     | C[6] C[7] C[8] |
    C[0]  = a11_*a11_;  C[1] = nu*a11_*a22_+ (1.0-nu)*a12_*a12_;
    C[2]  = a11_*a12_;  C[3] = C[1];
    C[4]  = a22_*a22_;  C[5] = a12_*a22_;
    C[6]  = C[2];       C[7] = C[5];
    C[8]  = 0.5 * ((1.0-nu)*a11_*a22_ + (1.0+nu)*a12_*a12_);

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    // GREEN-LAGRANGE strain tensor   E = eps + rho
    //
    // membrane strain tensor
    // eps_ab = 0.5 * (phi,a . phi,b - phi0,a . phi0,b)
    eps[0] = (Ip[0] - Ip0[0]) * 0.5;
    eps[1] = (Ip[3] - Ip0[3]) * 0.5;
    eps[2] = (Ip[1] - Ip0[1]);

    // bending strain tensor
    // rho_ab = phi0,ab . t0 - phi,ab . t  = II - II0
    rho[0] = (IIp[0] - IIp0[0]);
    rho[1] = (IIp[3] - IIp0[3]);
    rho[2] = (IIp[1] - IIp0[1]) * 2.0;

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    // Stress tensors
    // membrane stress tensor: n = h * C * eps
    MxV_Row(nStress, 3, 3, C, eps);
    // bending stress tensor:  m = (h^3)/12 * C * rho
    MxV_Row(mStress, 3, 3, C, rho);

    //
    //mp: vector matrix product, m^T phi_ab
    mp[0]  = mStress[0]*phi_11[0] + mStress[1]*phi_22[0] + 2.0*mStress[2]*phi_12[0];
    mp[1]  = mStress[0]*phi_11[1] + mStress[1]*phi_22[1] + 2.0*mStress[2]*phi_12[1];
    mp[2]  = mStress[0]*phi_11[2] + mStress[1]*phi_22[2] + 2.0*mStress[2]*phi_12[2];

    //sp: scalar product (- kappa : second fund. form)
    sp[0]  = -IIp[0]; //t.phi_11
    sp[1]  = -IIp[3]; //t.phi_22
    sp[2]  = -IIp[1]; //t.phi_12

    // scalar product of (t.phi_11,t.phi_22,2t.phi_12).m
    spm  = sp[0]*mStress[0] + sp[1]*mStress[1] + 2.0*sp[2]*mStress[2];
    Math::AXPY(mp, 3, -spm, t);
    DW[0]  =    0.0;       DW[1]  = -mp[2];        DW[2]  =  mp[1];
    DW[3]  =  mp[2];       DW[4]  =    0.0;        DW[5]  = -mp[0];
    DW[6]  = -mp[1];       DW[7]  =  mp[0];        DW[8]  =    0.0;

    // loop on the eNN neighbors of the k-th Gauss points
    for (i=0; i<eNN; i++)
    {
        // Indexes settings
        iD    = i*tDim;
        iD2   = iD*tDim;
        iDOF  = i*DOF;

        //[1.a] membrane
        //Membrane strain-displacement gradient matrix
        MFilled_T (MI_T, &dp_k[iD], phi_1, phi_2);
        //MI_TxC = MI_T*C
        MatMultSquare3D (MI_TxC, MI_T, C);
        //MI = (MI_T)^T
        MatTranspose3D (MJ, MI_T);
        //Hessian for the Membrane Potential Energy Density
        HessMem (Hmem, &dp_k[iD], &dp_k[iD], nStress, MI_TxC, MJ);

        //[1.b] bending
        //Bending strain-displacement gradient matrix
        BFilled_T (FbenI, DJacI, BI_T, WI_T,
                    iJac, &dp_k[iD], &hp_k[iD2],
                    phi_1, phi_2, phi_11, phi_22, phi_12, t, sp, mStress);
        //BI_TxC = BI_T*C
        MatMultSquare3D(BI_TxC, BI_T, C);
        //BI = (BI_T)^T
        MatTranspose3D (BJ, BI_T);
        //WI = (WI_T)^T
        MatTranspose3D (WJ, WI_T);

        //Hessian for the Bending Potential Energy Density
        HessBen (Hben,
                  iJac, &dp_k[iD], &hp_k[iD2], &dp_k[iD], &hp_k[iD2],
                  sp, mStress, DW,
                  BI_TxC, BJ, WI_T, WJ, DJacI, DJacI, FbenI, FbenI);

        //[1.c]
        //Now the result is stored in Hben
        Math::AXPBY (Hben, 9, mw_k, bw_k, Hmem); //X = a*X + b*Y

        // FILL DIAGONAL term of K_e[i,i]
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+0)] += Hben[0];
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+1)] += Hben[1];
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+2)] += Hben[2];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+0)] += Hben[3];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+1)] += Hben[4];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+2)] += Hben[5];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+0)] += Hben[6];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+1)] += Hben[7];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+2)] += Hben[8];

        //the following terms after the diagonal
        for (j=i+1; j<eNN; j++)
        {
            // x of the variable evaluated in the node j
            // Indexes settings
            jD    = j*tDim;
            jD2   = jD*tDim;
            jDOF  = j*DOF;

            //[2.a] membrane
            //Membrane strain-displacement gradient matrix
            MFilled (MJ, &dp_k[jD], phi_1, phi_2);
            //Hessian for the Membrane Potential Energy Density
            HessMem (Hmem, &dp_k[iD], &dp_k[jD], nStress, MI_TxC, MJ);

            //[2.b] bending
            //Bending strain-displacement gradient matrix
            BFilled (FbenJ, DJacJ, BJ, WJ,
                      iJac, &dp_k[jD], &hp_k[jD2],
                      phi_1, phi_2, phi_11, phi_22, phi_12, t, sp, mStress);

            //Hessian for the Bending Potential Energy Density
            HessBen (Hben,
                      iJac, &dp_k[iD], &hp_k[iD2], &dp_k[jD], &hp_k[jD2],
                      sp, mStress, DW,
                      BI_TxC, BJ, WI_T, WJ, DJacI, DJacJ, FbenI, FbenJ);

            //Now the result is stored in Hben
            Math::AXPBY (Hben, 9, mw_k, bw_k, Hmem);   //Y = a*X + b*Y

            // FILL NON DIAGONAL term of K_e[i,j]
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+0)] += Hben[0];
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+1)] += Hben[1];
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+2)] += Hben[2];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+0)] += Hben[3];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+1)] += Hben[4];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+2)] += Hben[5];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+0)] += Hben[6];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+1)] += Hben[7];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+2)] += Hben[8];

            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+0)] += Hben[0];
            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+1)] += Hben[3];
            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+2)] += Hben[6];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+0)] += Hben[1];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+1)] += Hben[4];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+2)] += Hben[7];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+0)] += Hben[2];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+1)] += Hben[5];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+2)] += Hben[8];
        }//end for in j
    }//end for in i

    return;
}


// This function computes the Energy gradient contribution at each element in a surface case
// Geometrically NONLINEAR thin-shell elasticity coupled with a phase field describing
// a fracture (optionally, check passAux).
void ShellSystem (RCP<hiperlife::FillStructure> fillStr)
{
    using namespace std;
    using namespace hiperlife;

    //auxiliary variables
    bool   passAux = false;
    int    i, j, k;
    int    iD, iD2, jD, jD2;
    int    iDOF, jDOF;
    double w_k;
    double Mcte, Bcte, mw_k, bw_k, eneMem, eneBen;

    //INPUTS declaration
    int    tDim      = 2;     //dimension of the parametric space
    int    nDim      = 0;     //spatial dimension where the data points are living
    int    DOF       = 0;     //number of degrees of freedom of the physical variable at each node
    int    eNN       = 0;     //number of nearest neighbors to each element (also to each Gauss point)

    // Material and Geometrical parameters for a Shell
    double E         = 0.0;   //Young's modulus
    double nu        = 0.0;   //Poisson's ratio
    double hh        = 0.0;   //thickness of the thin shell

    double *dp_e      = NULL;  //Gradients of the basis functions for all Gauss points in an element (2D)
    double *hp_e      = NULL;  //Hessians of the basis functions for all Gauss points in an element (2D)
    double *xe_nodRef = NULL;  //REFERENCE nearest nodes (control points) coordinates (3D)
    double *xe_nodDef = NULL;  //CONVECTED coordinates for the nearest neighbor of Gauss point (3D)
    double *ue_nodes  = NULL;  //convected deformation at each DOF of xe_nodes

    //Intermediate auxiliary variables
    double *dp_k      = NULL;  //Gradients at the Gauss point xi_k
    double *hp_k      = NULL;  //Hessians at the Gauss point xi_k
    double *df_samples= NULL;  //phase field degradation function at each Gauss point

    //Intermediate auxiliary variables
    int     N_e        = 0;     //number of rows of the stiffness matrix in an element
    double jac0       = 0.0;   //Jacobian on the middle reference surface at the Gauss point xi_k
    double iJac0      = 0.0;   //Jacobian inverse on the middle reference surface at the Gauss point xi_k
    double iDet0      = 0.0;   //inverse of the determinant of the metric tensor in the reference surface
    double a11_, a22_, a12_;

    double jac        = 0.0;     //Jacobian on the middle convected surface at the Gauss point xi_k
    double iJac       = 0.0;     //Jacobian inverse on the middle convected surface at the Gauss point xi_k
    double spm        = 0.0;     //scalar product of (t.phi_11,t.phi_22,2t.phi_12).m

    double Ip0 [4],   Ip[4];     //first fundamental form, or metric tensor g
    double phi0_1[3], phi_1[3];  //gradient of the mapping in the parametric direction xi_1
    double phi0_2[3], phi_2[3];  //gradient of the mapping in the parametric direction xi_2

    double IIp0 [4],   IIp [4];   //second fundamental form, or curvature tensor 'kappa'
    double phi0_11[3], phi_11[3]; //Hessian of the mapping in the parametric direction (xi_1,xi_1)
    double phi0_22[3], phi_22[3]; //Hessian of the mapping in the parametric direction (xi_2,xi_2)
    double phi0_12[3], phi_12[3]; //Hessian of the mapping in the parametric direction (xi_1,xi_2)
    double t0[3],      t[3];      //normal to the middle surface in the reference configuration
    double C[9];                  //Elasticity tensor in Voigt's notation
    double eps[3], nStress[3];    //membrane strain/stress tensor in Voigt's notation
    double rho[3], mStress[3];    //bending strain/stress tensor in Voigt's notation

    double sp[3];                 //store the scalar product between the normal and the phi0_{alpha,beta}
    double mp[3];                 //vector matrix product, m^T phi_ab
    double DW[9];                 //antisymmetric matrix

    double Acp[9], Bcp[9];        //auxiliary matrix containing cross products among Dphi and Hphi
    double pt [3],  tp[3];        //auxiliary vector to store cross products of Dphi and t
    double Fmem[3];               //Membrane forces: n^T . grad(eps)
    double Fben[3];               //Bending forces : m^T . grad(rho)



    //auxiliary force vectors and membrane/bending matrices for each node I, J
    double  FbenI[3], FbenJ[3];   //Bending forces
    double  DJacI[3], DJacJ[3];   //Jacobian gradient
    double  MI_T[9], MJ[9];       //Membrane auxiliary matrices
    double  MI_TxC[9], Hmem[9];   //...
    double  BI_T[9], BJ[9];       //Bending auxiliary matrices
    double  BI_TxC[9], WI_T[9];   //...
    double  WJ[9], Hben[9];       //...

    //MAIN OUTPUT declaration
    double energy_e   = 0.0;      //thin-shell energy contribution at a the present element

    // --------------------------------------------
    //Initialize
    SubFillStructure& subFill = (*fillStr)["dofHand_u"];

    //INPUT definition and variables initialization
    nDim      = subFill.nDim;
    DOF       = subFill.numDOFs;
    eNN       = subFill.eNN;
    tDim      = subFill.pDim;      //Number of parametric dimensions

    xe_nodRef = subFill.nborCoords.data();  // Vector of node coordinates
    ue_nodes  = subFill.nborDOFs.data();
    dp_k      = subFill.nborBFsDers(1); //Local shape function derivatives
    hp_k      = subFill.nborBFsDers(2); //Local shape function hessians

    // passAux   = fillStr->userStr->passAux;
    E         = fillStr->userStr->dparam[0];
    nu        = fillStr->userStr->dparam[1];
    hh        = fillStr->userStr->dparam[3];

    //passAux   = subFill.userStr->passAux;
    //df_samples= subFill.ae_samples; //<== INPUT

    N_e       = eNN*DOF; //number of nonzeros elements by row in the stiffness Matrix
    Mcte      = hh*E/(1.0-nu*nu);
    Bcte      = hh*hh*Mcte/12.0;
    energy_e  = 0.0; //energy of the element

    //Convected configuration: x_def = x0 + u
    xe_nodDef = ue_nodes;
    if (subFill.kPt == 0)
        Math::AXPY(xe_nodDef, N_e, 1.0, xe_nodRef);  //y=a*x+y

    // --------------------------------------------
    //Differential Geometry
    //Curvatures: normals, Jacobian, and fundamental forms are computed at the sample (Gauss) point
    //Reference configuration
    SurfLagrParam::Curvatures (IIp0, Ip0, t0, phi0_1, phi0_2, phi0_11, phi0_22, phi0_12,
                                eNN, xe_nodRef, dp_k, hp_k);


    // Deformed configuration:  x = u + x0
    SurfLagrParam::Curvatures (IIp, Ip, t, phi_1, phi_2, phi_11, phi_22, phi_12,
                                eNN, xe_nodDef, dp_k, hp_k);


    //Jacobian of the middle reference surface
    jac0  = sqrt(ABS(Ip0[0]*Ip0[3] - Ip0[1]*Ip0[2]));
    iJac0 = 1.0 / jac0;

    jac   = sqrt(ABS(Ip[0]*Ip[3] - Ip[1]*Ip[2]));
    iJac  = 1.0 / jac;

    //Gauss quadrature weight: w_g * Jac_g
    w_k   = jac0;

    //--------------------------------------------------------------------------------
    //Hessian system matrix of the thin-shell elasticity (matrix in Voigt's notation)
    // if (passAux == true)
    // {
    //    w_k  = w_k*df_samples[k];
    // }
    mw_k    = Mcte*w_k;
    bw_k    = Bcte*w_k;

    //First Fundamental Form in the covariant basis Ip[k] = [E F; F G]_k
    //Inverse of the metric tensor
    iDet0 =  iJac0*iJac0;
    a11_  =  iDet0*Ip0[3];
    a22_  =  iDet0*Ip0[0];
    a12_  = -iDet0*Ip0[1];

    //     | C[0] C[1] C[2] |
    // C = | C[3] C[4] C[5] |           Elasticity tensor
    //     | C[6] C[7] C[8] |
    C[0]  = a11_*a11_;  C[1] = nu*a11_*a22_+ (1.0-nu)*a12_*a12_;
    C[2]  = a11_*a12_;  C[3] = C[1];
    C[4]  = a22_*a22_;  C[5] = a12_*a22_;
    C[6]  = C[2];       C[7] = C[5];
    C[8]  = 0.5 * ((1.0-nu)*a11_*a22_ + (1.0+nu)*a12_*a12_);

    //sp: scalar product
    sp[0] = -IIp[0]; //t0.phi0_11
    sp[1] = -IIp[3]; //t0.phi0_22
    sp[2] = -IIp[1]; //t0.phi0_12

    //--------------------------------------------------------------------------------
    // GREEN-LAGRANGE strain tensor   E = eps + rho

    // membrane strain tensor
    // eps_ab = 0.5 * (phi,a . phi,b - phi0,a . phi0,b)
    eps[0]  = (Ip[0] - Ip0[0]) * 0.5;
    eps[1]  = (Ip[3] - Ip0[3]) * 0.5;
    eps[2]  = (Ip[1] - Ip0[1]);

    // bending strain tensor
    // rho_ab = phi0,ab . t0 - phi,ab . t  = II - II0
    rho[0]  = (IIp[0] - IIp0[0]);
    rho[1]  = (IIp[3] - IIp0[3]);
    rho[2]  = (IIp[1] - IIp0[1]) * 2.0;

    //--------------------------------------------------------------------------------
    // Stress tensors
    // membrane stress tensor: n = h * C * eps
    MxV_Row(nStress, 3, 3, C, eps);

    // bending stress tensor:  m = (h^3)/12 * C * rho
    MxV_Row(mStress, 3, 3, C, rho);

    //
    //mp: vector matrix product, m^T phi_ab
    mp[0]  = mStress[0]*phi_11[0] + mStress[1]*phi_22[0] + 2.0*mStress[2]*phi_12[0];
    mp[1]  = mStress[0]*phi_11[1] + mStress[1]*phi_22[1] + 2.0*mStress[2]*phi_12[1];
    mp[2]  = mStress[0]*phi_11[2] + mStress[1]*phi_22[2] + 2.0*mStress[2]*phi_12[2];

    // scalar product of (t.phi_11,t.phi_22,2t.phi_12).m
    spm  = sp[0]*mStress[0] + sp[1]*mStress[1] + 2.0*sp[2]*mStress[2];
    Math::AXPY(mp, 3, -spm, t);
    DW[0]  =    0.0;       DW[1]  = -mp[2];        DW[2]  =  mp[1];
    DW[3]  =  mp[2];       DW[4]  =    0.0;        DW[5]  = -mp[0];
    DW[6]  = -mp[1];       DW[7]  =  mp[0];        DW[8]  =    0.0;

    //--------------------------------------------------------------------------------
    // Energy density contribution of the Gauss point k
    // EneDen = EDmem + EDben = 0.5 (eps.n + rho.m)
    eneMem    = 0.5 * Math::Dot3D(eps, nStress) * Mcte;
    eneBen    = 0.5 * Math::Dot3D(rho, mStress) * Bcte;
    energy_e += (eneMem + eneBen)*w_k;

    //--------------------------------------------------------------------------------
    // Shell Energy Gradient loop on the eNN neighbors of the k-th Gauss points

    // Acp = [Cross(phi_11, phi_2); Cross(phi_22, phi_2); Cross(phi_12, phi_2)]
    Math::Cross(&Acp[0], phi_11, phi_2);
    Math::Cross(&Acp[3], phi_22, phi_2);
    Math::Cross(&Acp[6], phi_12, phi_2);

    // Bcp = [Cross(phi_1, phi_11); Cross(phi_1, phi_22); Cross(phi_1, phi_12)]
    Math::Cross(&Bcp[0], phi_1, phi_11);
    Math::Cross(&Bcp[3], phi_1, phi_22);
    Math::Cross(&Bcp[6], phi_1, phi_12);

    Math::Cross(pt, phi_2,     t);
    Math::Cross(tp,     t, phi_1);

    //Fill rhs
    for (i = 0; i < eNN; i++)
    {
        // Indexes settings
        iD   = i*tDim;
        iD2  = iD*tDim;
        iDOF  = i*DOF;

        // F_mem(I) = n^T Ma
        ForceMem (Fmem, &dp_k[iD], phi_1, phi_2, nStress);

        // F_ben(I) = m^T Ba
        ForceBen (Fben, iJac, &dp_k[iD], &hp_k[iD2],
                   t, mStress, sp, Acp, Bcp, pt, tp);

        // FILL the Energy Gradient: thin-shell elasticity
        fillStr->Bk(0)[iDOF+0] += Fmem[0]*mw_k + Fben[0]*bw_k;
        fillStr->Bk(0)[iDOF+1] += Fmem[1]*mw_k + Fben[1]*bw_k;
        fillStr->Bk(0)[iDOF+2] += Fmem[2]*mw_k + Fben[2]*bw_k;

        // ----------------------------------------------------------
        //Full Stiffness Matrix / Tangent
        //[1.a] membrane
        //Membrane strain-displacement gradient matrix
        MFilled_T (MI_T, &dp_k[iD], phi_1, phi_2);
        //MI_TxC = MI_T*C
        MatMultSquare3D (MI_TxC, MI_T, C);
        //MI = (MI_T)^T
        MatTranspose3D (MJ, MI_T);
        //Hessian for the Membrane Potential Energy Density
        HessMem (Hmem, &dp_k[iD], &dp_k[iD], nStress, MI_TxC, MJ);

        //[1.b] bending
        //Bending strain-displacement gradient matrix
        BFilled_T (FbenI, DJacI, BI_T, WI_T,
                    iJac, &dp_k[iD], &hp_k[iD2],
                    phi_1, phi_2, phi_11, phi_22, phi_12, t, sp, mStress);
        //BI_TxC = BI_T*C
        MatMultSquare3D(BI_TxC, BI_T, C);
        //BI = (BI_T)^T
        MatTranspose3D (BJ, BI_T);
        //WI = (WI_T)^T
        MatTranspose3D (WJ, WI_T);

        //Hessian for the Bending Potential Energy Density
        HessBen (Hben,
                  iJac, &dp_k[iD], &hp_k[iD2], &dp_k[iD], &hp_k[iD2],
                  sp, mStress, DW,
                  BI_TxC, BJ, WI_T, WJ, DJacI, DJacI, FbenI, FbenI);

        //[1.c]
        //Now the result is stored in Hben
        Math::AXPBY (Hben, 9, mw_k, bw_k, Hmem); //X = a*X + b*Y

        // FILL DIAGONAL term of K_e[i,i]
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+0)] += Hben[0];
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+1)] += Hben[1];
        fillStr->Ak(0, 0)[(iDOF+0)*N_e+(iDOF+2)] += Hben[2];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+0)] += Hben[3];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+1)] += Hben[4];
        fillStr->Ak(0, 0)[(iDOF+1)*N_e+(iDOF+2)] += Hben[5];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+0)] += Hben[6];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+1)] += Hben[7];
        fillStr->Ak(0, 0)[(iDOF+2)*N_e+(iDOF+2)] += Hben[8];

        //the following terms after the diagonal
        for (j=i+1; j<eNN; j++)
        {
            // x of the variable evaluated in the node j
            // Indexes settings
            jD    = j*tDim;
            jD2   = jD*tDim;
            jDOF  = j*DOF;

            //[2.a] membrane
            //Membrane strain-displacement gradient matrix
            MFilled (MJ, &dp_k[jD], phi_1, phi_2);
            //Hessian for the Membrane Potential Energy Density
            HessMem (Hmem, &dp_k[iD], &dp_k[jD], nStress, MI_TxC, MJ);

            //[2.b] bending
            //Bending strain-displacement gradient matrix
            BFilled (FbenJ, DJacJ, BJ, WJ,
                      iJac, &dp_k[jD], &hp_k[jD2],
                      phi_1, phi_2, phi_11, phi_22, phi_12, t, sp, mStress);

            //Hessian for the Bending Potential Energy Density
            HessBen (Hben,
                      iJac, &dp_k[iD], &hp_k[iD2], &dp_k[jD], &hp_k[jD2],
                      sp, mStress, DW,
                      BI_TxC, BJ, WI_T, WJ, DJacI, DJacJ, FbenI, FbenJ);

            //Now the result is stored in Hben
            Math::AXPBY (Hben, 9, mw_k, bw_k, Hmem);   //Y = a*X + b*Y

            // FILL NON DIAGONAL term of K_e[i,j]
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+0)] += Hben[0];
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+1)] += Hben[1];
            fillStr->Ak(0, 0)[(iDOF+0)*N_e+(jDOF+2)] += Hben[2];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+0)] += Hben[3];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+1)] += Hben[4];
            fillStr->Ak(0, 0)[(iDOF+1)*N_e+(jDOF+2)] += Hben[5];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+0)] += Hben[6];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+1)] += Hben[7];
            fillStr->Ak(0, 0)[(iDOF+2)*N_e+(jDOF+2)] += Hben[8];

            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+0)] += Hben[0];
            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+1)] += Hben[3];
            fillStr->Ak(0, 0)[(jDOF+0)*N_e+(iDOF+2)] += Hben[6];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+0)] += Hben[1];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+1)] += Hben[4];
            fillStr->Ak(0, 0)[(jDOF+1)*N_e+(iDOF+2)] += Hben[7];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+0)] += Hben[2];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+1)] += Hben[5];
            fillStr->Ak(0, 0)[(jDOF+2)*N_e+(iDOF+2)] += Hben[8];
        }//end for in j
    }//end for in i

    fillStr->addToGlobalIntegral("Elastic_Energy", energy_e);
    return;
}



// This function checks the extension of a filename and return an error value.
// Also could give a message with the kind of problem
int CheckFilename(bool verbose, const char *input_name, const char *input_extension)
{
    const char * ch_ptr;

    ch_ptr = std::strrchr (input_name, '.');
    if (ch_ptr == NULL)
    {
        if (verbose == true)
            printf("ERROR::No extension in input filename : %s\n", input_name);
        return 1;
    }

    if (input_extension != NULL)
    {
        if (std::strncmp(input_extension, ch_ptr, ch_ptr - input_extension) != 0)
        {
            if (verbose == true)
            {
                printf("ERROR::The extension '%s' of the input filename is wrong\n", ch_ptr);
                printf("     ::It should be '%s'\n", input_extension);
            }
            return 2;
        }
    }
    return 0;
}

// This function checks the extension of a filename and give an error value and message if
// describing what happened
int CheckFilename(const char *input_name, const char *input_extension)
{
    return CheckFilename(true, input_name, input_extension);
}


//Usage example:
int Usage()
{
    printf("Usage: HlmShellPhaseField config_filename                               \n");
    printf("This program computes small/finite deformations of brittle thin shells. \n");
    printf("The fracture mechanism in brittle thin shells is modeled by using phase field.\n");

    printf("INPUT FILES\n");
    printf("\tmeshRef_filename =  mesh.vtk  #Control mesh filename for the reference configuration \n");
    printf("\tdispl_filename   = displ.pts  #Control points with imposed displacements \n");
    printf("\tshellOut_filename= tsOut.txt  #Selected results from the simulation e.g. reaction forces \n");
    printf("\tmeshSeed_filename= Def00.vtk  #Initial displacement and phase field (optional) \n");
    printf("\tedmaxIn_filename =  hmed.pts  #Initial historical MAX elastic energy density at each Gauss point (optional) \n");

    printf("INPUT PARAMETERS\n");
    printf("Geometrical and material inputs:                                       \n");
    printf("\thh       = 0.0    #thickness of the thin shell                       \n");
    printf("\tE        = 0.0    #Young's modulus                                   \n");
    printf("\tnu       = 0.0    #Poisson's ratio                                   \n");
    printf("\tGc       = 1.0    #Critical Energy Release rate\n");

    printf("Numerical inputs:                                                      \n");
    printf("\tele      = 1.0    #A positive regularization parameter that modulates the size of the fracture zone\n");
    printf("\tgPts     =  3     #Number of Gauss-Legendre points for each element  \n");
    printf("\tNSTEPS   =  200   #Number of steps to reach the maximum prescribed displacement\n");
    printf("\tMAXITER  = 1000   #Maximum number of iterations\n");
    printf("\tSOLTOL_u = 1E+0   #Tolerance for the displacement field in the incremental loop\n");
    printf("\tSOLTOL_v = 1E-2   #Tolerance for the pahse field in the incremental loop\n");
    printf("\tmaxDispl = 0.0    #Maximum allowed displacement for the constrained nodes\n");
    printf("\teta_k    = 1E-6   #A positive regularization constant to avoid the singularity of disappearing elastic energy density when the phase-field parameter is zero\n");

    printf("Initital displacement and phase-field inputs:                                                          \n");
    printf("\tiSave    =   0    #Actual increment put into disk                    \n");
    printf("\tdispl    = 0.0    #Initial displacement                              \n");
    printf("\tDX       = 0.0    #Desired starting increment                        \n");

    printf("Optional inputs:                                                       \n");
    printf("\tbndNodes_filename=   bnd.vtk  #Nodes IDs for the boundary curves where the reaction forces are computed  \n");
    printf("\torder2nd  = false  #Phase field order model (if false then 4th order)\n");
    printf("\tverbose   = true   #Display information explaining what is being done\n");
    printf("\tnSave     =    1   #Number of jumped increments between disk writings\n");

    printf("\nUsage example:                                                       \n");
    printf("HlmShellPhaseField pipes.cfg                                           \n");
    return 1;
}


void LS_poisson(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFsDers(0);  // Local shape function
    // double* glNa = subFill.nborBFsDers(1); // Local shape function derivatives
    double gNa[eNN*pDim], jac;
    // GlobalBasisFunctions::gradients(gNa, jac, eNN, pDim, nDim, xe_nodes.data(), glNa);
    GlobalBasisFunctions::gradients(gNa, jac, subFill);

    vector<double> x(pDim);
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d]  * Na[i];
    }

    // if (x[0] < 0.9)
        // force *= x[0];

    ///=====================  Fill linear system =====================///
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;
        }

        /// Fill RHS
        fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;
    }

    return;
}

void LS_cahnHilliard(RCP<FillStructure> fillStr)
{
    //Parameters
    double deltat   = fillStr->userStr->dparam[0];
    double mobility = fillStr->userStr->dparam[1];
    double epsilon2 = fillStr->userStr->dparam[2];

    //Rename variables
    SubFillStructure& subFill = (*fillStr)["dhand"];
    int DOF   = subFill.numDOFs;
    int eNN   = subFill.eNN;
    int nDim  = subFill.nDim;
    int pDim  = subFill.pDim;
    double *xe_nodes  = subFill.nborCoords.data();
    double *ue_nodes  = subFill.nborDOFs.data();
    double *ue_nodes0 = subFill.nborDOFs0.data();

    //Shape functions and derivatives at Gauss points
    double jac;
    double* Na = subFill.nborBFsDers(0);
    vector<double> gNa(eNN*pDim), hNa(eNN*pDim*pDim), lapNa(eNN);
    GlobalBasisFunctions::hessians(gNa.data(), jac, hNa.data(), lapNa.data(), subFill);

    //Values at integration points
    vector<double> x(pDim), gphi(pDim);
    double phi{}, phin{}, lapphi{};
    Array::Fill(x.data(), pDim, 0.0);
    Array::Fill(gphi.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        //Values
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d] * Na[i];
        phi  += ue_nodes[DOF*i+0]  * Na[i];
        phin += ue_nodes0[DOF*i+0] * Na[i];

        //Gradients
        for (int d = 0; d < pDim; d++)
            gphi[d] += ue_nodes[DOF*i+0] * gNa[pDim*i+d];

        //Hessians
        for (int d = 0; d < pDim; d++)
            lapphi += ue_nodes[i] * hNa[pDim*pDim*i+pDim*d+d];
    }

    //Double well and derivatives
    double    W = (phi*phi)*(1.0-phi)*(1.0-phi)/4.0;
    double   dW = phi*(1.0-phi)*(1.0-2.0*phi)/2.0;
    double  ddW = (1.0-6.0*phi+6.0*phi*phi)/2.0;
    double dddW = (-1.0+2.0*phi)*3.0;

    //Fill
    for (int i = 0; i < eNN; i++)
    {
        //Gradient of basis function times gradient of phase-field variable
        double gNagphi{};
        for (int d = 0; d < pDim; d++)
            gNagphi += gNa[pDim*i+d]*gphi[d];

        for (int j = 0; j < eNN; j++)
        {
            //Product of the gradient of basis functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            //Fill Ak
            fillStr->Ak(0, 0)[i*eNN+j] += jac * Na[i] * Na[j] / deltat;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * dddW * Na[j] * gNagphi;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * ddW * gNagNb;
            fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * epsilon2 * lapNa[i] * lapNa[j];
        }

        //Fill RHS
        fillStr->Bk(0)[i] += jac * Na[i] * (phi-phin) / deltat;
        fillStr->Bk(0)[i] += jac * mobility * ddW * gNagphi;
        fillStr->Bk(0)[i] += jac * mobility * epsilon2 * lapNa[i] * lapphi;
    }

    //Add to global integral
    fillStr->addToGlobalIntegral("ChemicalFreeEnergy", jac*W);
    fillStr->addToGlobalIntegral("SurfaceFreeEnergy", jac*0.5*epsilon2*Math::SNorm(pDim, gphi.data()));
    fillStr->addToGlobalIntegral("GinzburgLandauFreeEnergy", jac*(W + 0.5*epsilon2*Math::SNorm(pDim, gphi.data())));
    fillStr->addToGlobalIntegral("Mass", jac*phi);

    return;
}


void LS_GEOM(Teuchos::RCP<hiperlife::FillStructure> fillStr)
{
    using namespace hiperlife;
    using Teuchos::RCP;

    auto& subFill = (*fillStr)[0];

    int numDOFs  = subFill.numDOFs;
    int eNN      = subFill.eNN;
    vector<double>& nborCoords  = subFill.nborCoords;

    RCP<UserStructure> userStr   = fillStr->userStr;

    //MAIN OUTPUT declaration
    auto& Ak  = fillStr->Ak(0, 0); // <<=== MAIN OUTPUT
    auto& Bk  = fillStr->Bk(0);    // <<=== MAIN OUTPUT

    int N_e = numDOFs*eNN;
    //------------------------------------------------------------------------------------

    // Get the value of the basis functions and derivatives at the Gauss point k
    double *bf  = subFill.nborBFsDers(0);
    double *dbf = subFill.nborBFsDers(1);

    double x[3];
    double metric[4];
    double e1[3], e2[3];
    Math::MatTMult(x, 3, eNN, 1, nborCoords.data(), bf);
    SurfLagrParam::MetricTensor(metric,e1,e2,eNN,nborCoords.data(),dbf);
    double jac = sqrt(Math::DetMat2x2(metric));




    int shapeType = fillStr->userStr->iparam[0];
    double z = x[2];

    double targetx[3];
    double r = Math::Norm3D(x);
    Math::AX(x, 3 , 1.0/r);

    double fr = sqrt(x[0]*x[0] + x[1]*x[1]);

    if (shapeType == 1) //Ellipsoid
        z = x[2] * 0.75;
    else if (shapeType == 2) //Red blood cell
        z = x[2] * 0.4 * (1.0-0.4*cos(1.15*M_PI*fr));
    else if (shapeType == 3) //spacecraft
        z = x[2] * 0.7 * (1.0+0.1*cos(2.0*M_PI*x[1]/r));

    targetx[0] = 100.0 * x[0];
    targetx[1] = 100.0 * x[1];
    targetx[2] = 100.0 * z;

    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            //Add submatrix to elemental matrix
            for (int n = 0; n < numDOFs; n++)
                Ak[(numDOFs*i+n)*N_e + numDOFs*j + n] = jac * bf[i] * bf[j];
        }

        //Add submatrix to elemental matrix
        for (int n = 0; n < numDOFs; n++)
            Bk[numDOFs*i + n] = jac * bf[i] * targetx[n];

    }
}

void InitializeNodalValues(Teuchos::RCP<hiperlife::DOFsHandler> posDHand, int shapeType)
{
    using namespace std;
    using namespace hiperlife;
    using Teuchos::rcp;
    using Teuchos::RCP;

    RCP<UserStructure> userStr = rcp(new UserStructure);      //User structure
    userStr->iparam.resize(1);
    userStr->iparam[0] = shapeType;

    RCP<HiPerProblem> prehp = rcp(new HiPerProblem("HiPerProblem"));
    prehp->setUserStructure(userStr);

    prehp->setDOFsHandlers({posDHand});
    prehp->setGlobalIntegrals({"OrigVol", "OrigArea", "LSVol", "LSArea"});
    prehp->setIntegration("LeastSq", {"premech"});

    prehp->setCubatureGauss("LeastSq", 3);
    prehp->setElementFillings("LeastSq", LS_GEOM);

    prehp->Update();

    RCP<Amesos2DirectLinearSolver> linSolver = rcp (new Amesos2DirectLinearSolver());
    linSolver->setHiPerProblem(prehp);
    linSolver->setSolver(Amesos2DirectLinearSolver::Solver::Mumps);
    linSolver->setNumericFactorization(true);
    linSolver->setSymbolicFactorization(true);
    linSolver->setUseTranspose(false);
    linSolver->Update();

    linSolver->solve();

    linSolver->UpdateSolution();
    posDHand->UpdateGhosts();

}

void LS_viscous(RCP<FillStructure> fillStr)
{

    using namespace hiperlife;
    using namespace hiperlife::Tensor;

    //------------------------------------------------------------------
    // [2] Input variables

    //[1.1] Positions
    auto& subFill = (*fillStr)["posDHand"];
    int nDim = subFill.nDim;
    int pDim = subFill.pDim;
    int eNN  = subFill.eNN;
    int numDOFs = subFill.numDOFs;

    tensor<double,2,false> nborDOFs0(subFill.nborDOFs0.data(),eNN,numDOFs);
    tensor<double,2,false> nborDOFs(subFill.nborDOFs.data(),eNN,numDOFs);

    tensor<double,1,false>   bf(subFill.nborBFsDers(0),eNN);
    tensor<double,2,false>  Dbf(subFill.nborBFsDers(1),eNN,pDim);
    tensor<double,3,false> DDbf(subFill.nborBFsDers(2),eNN,pDim,pDim);

    //[1.2] Tensions
    auto& t_subFill = (*fillStr)["tenDHand"];
    int t_eNN  = t_subFill.eNN;

    tensor<double,1,false> t_nborDOFs(t_subFill.nborDOFs.data(),t_eNN);

    tensor<double,1,false> t_bf(t_subFill.nborBFsDers(0),t_eNN);

    //[1.3] Global constraints
    auto& g_subFill = (*fillStr)["gloDHand"];
    int g_numDOFs = g_subFill.numDOFs;

    tensor<double,1,false> gDOFs(g_subFill.nborDOFs.data(),g_numDOFs);
    double pressure = gDOFs(0);
    tensor<double,1> F = gDOFs(range(1,3));
    tensor<double,1> L = gDOFs(range(4,6));

    //[1.4] Parameters
    double deltat = fillStr->userStr->dparam[2];
    double kappa  = fillStr->userStr->dparam[0] * deltat;
    double mu     = fillStr->userStr->dparam[1];

    //OUTPUTS
    tensor<double,2,false> Bp(fillStr->Bk(0).data(),eNN,numDOFs);
    tensor<double,1,false> Bt(fillStr->Bk(1).data(),t_eNN);
    tensor<double,1,false> Bg(fillStr->Bk(2).data(),g_numDOFs);

    tensor<double,4,false> App(fillStr->Ak(0,0).data(),eNN,numDOFs,eNN,numDOFs);
    tensor<double,3,false> Apt(fillStr->Ak(0,1).data(),eNN,numDOFs,t_eNN);
    tensor<double,3,false> Apg(fillStr->Ak(0,2).data(),eNN,numDOFs,g_numDOFs);
    tensor<double,3,false> Atp(fillStr->Ak(1,0).data(),t_eNN,eNN,numDOFs);
    tensor<double,3,false> Agp(fillStr->Ak(2,0).data(),g_numDOFs,eNN,numDOFs);


    //------------------------------------------------------------------
    // [2] Compute variables

    //[2.1] Previous time-step
    tensor<double,1> xu_n(nDim);
    tensor<double,1> xv_n(nDim);
    tensor<double,1> normal_n(nDim);
    tensor<double,2> metric_n(pDim,pDim);
    SurfLagrParam::Normal(normal_n, metric_n, xu_n, xv_n, eNN, nborDOFs0, Dbf);

    tensor<double,1> x_n = bf * nborDOFs0;
    tensor<double,2> imetric_n = metric_n.inv();
    double jac_n = sqrt(metric_n.det());

    double xnormal_n = x_n * normal_n;

    //[2.2] Current time-step
    tensor<double,1> xu(nDim);
    tensor<double,1> xv(nDim);
    tensor<double,1> xuu(nDim);
    tensor<double,1> xuv(nDim);
    tensor<double,1> xvv(nDim);
    tensor<double,1> normal(nDim);
    tensor<double,2> metric(pDim,pDim);
    tensor<double,2> curva(pDim,pDim);
    tensor<double,3> christsym(pDim,pDim,pDim);
    SurfLagrParam::ChristoffelSymbols(christsym, curva, metric, normal, xu, xv, xuu, xvv, xuv, eNN, nborDOFs, Dbf, DDbf);

    tensor<double,1> x =  bf * nborDOFs;
    tensor<double,2> imetric = metric.inv();
    double jac       = sqrt(metric.det());
    double meancurva = product(imetric,curva,{{0,0},{1,1}});

    double xnormal = x * normal;

    tensor<double,2> rodt    = metric-metric_n;
    tensor<double,2> rodt_CnCn = imetric_n * rodt * imetric_n;

    //[2.3] Other variables
    double tr_rodt = (jac - jac_n)/jac_n;

    double tension = (t_nborDOFs * t_bf) * deltat;

    //------------------------------------------------------------------
    // [3] Energies and dissipations

    //[3.1] Shear dissipation
    double dissipation = jac_n * mu * product(rodt, rodt_CnCn,{{0,0},{1,1}});
    //[3.2] Helfrich energy
    double helfrich    = 0.5 * jac * kappa * meancurva * meancurva;
    //[3.3] Rayleighian
    double rayleighian = helfrich + dissipation;

    //[3.4] Add contributions to global integrals
    fillStr->addToGlobalIntegral("Rayleighian",rayleighian);
    fillStr->addToGlobalIntegral("Helfrich",helfrich);
    fillStr->addToGlobalIntegral("Dissipation",dissipation);
    fillStr->addToGlobalIntegral("Trd",jac_n * tr_rodt);

    //------------------------------------------------------------------
    // [4] Right-hand sides

    tensor<double,4> d_metric(eNN,numDOFs,pDim,pDim);
    SurfLagrParam::d_Metric(d_metric,Dbf,xu,xv);

    tensor<double,4> d_metric_CC  = product(product(d_metric,imetric,{{2,0}}),imetric,{{2,0}});
    tensor<double,4> d_metric_CnCn = product(product(d_metric,imetric_n,{{2,0}}),imetric_n,{{2,0}});

    tensor<double,4> d_imetric = -1.0 * d_metric_CC;

    tensor<double,2> d_jac(eNN,numDOFs);
    SurfLagrParam::d_Jac(d_jac,Dbf,xu,xv,normal);

    tensor<double,3> d_normal(eNN,numDOFs,nDim);
    SurfLagrParam::d_Normal(d_normal,Dbf,xu,xv,normal,jac,d_jac);

    tensor<double,4> d_curva(eNN,numDOFs,pDim,pDim);
    SurfLagrParam::d_Curva(d_curva,DDbf,xuu,xuv,xvv,normal,d_normal);

    tensor<double,2> d_meancurva = product(imetric,d_curva,{{0,2},{1,3}}) + product(curva,d_imetric,{{0,2},{1,3}});

    //[4.1] Dissipation
    Bp += 0.5 * jac_n * mu * product(rodt_CnCn,d_metric,{{0,2},{1,3}});

    //[4.2] Helfrich energy
    Bp += 0.5 * kappa * (d_jac * meancurva * meancurva + (2.0 * jac * meancurva) * d_meancurva);

    //[4.3] Tension
    Bp += tension * d_jac;
    Bt += (jac_n * tr_rodt * deltat) * t_bf;

    //[4.4] Volume constraint
    Bp    += pressure/3.0 * (d_jac * xnormal + jac * (d_normal * x) + jac * outer(bf,normal));
    Bg(0) += (jac * xnormal - jac_n*xnormal_n)/3.0;

    //[4.5] Rigid body
    //[4.5.1] Translations
    Bp += jac_n * outer(bf,F);
    Bg(range(1,3)) += jac_n * (x-x_n);

    //[4.5.2] Rotations
    Bp             += jac_n * outer(bf, antisym3D * x_n) * L;
    Bg(range(4,6)) += jac_n * ((x-x_n) * antisym3D * x_n) ;

    //------------------------------------------------------------------
    // [5] Matrix

    tensor<double,6> dd_metric(eNN,numDOFs,eNN,numDOFs,pDim,pDim);
    SurfLagrParam::dd_Metric(dd_metric,Dbf);

    tensor<double,6> dd_metric_CC  = product(product(dd_metric,imetric,{{4,0}}),imetric,{{4,0}});

    tensor<double,6> dd_imetric = -1.0 * dd_metric_CC - product(product(d_metric,d_imetric,{{2,2}}).transpose({0,1,3,4,5,2}),imetric,{{5,0}}) - product(product(d_metric,imetric,{{2,0}}),d_imetric,{{2,2}}).transpose({0,1,3,4,2,5});

    tensor<double,4> dd_jac(eNN,numDOFs,eNN,numDOFs);
    SurfLagrParam::dd_Jac(dd_jac,Dbf,xu,xv,normal,d_normal);

    tensor<double,5> dd_normal(eNN,numDOFs,eNN,numDOFs,nDim);
    SurfLagrParam::dd_Normal (dd_normal, Dbf, jac, d_jac, dd_jac, normal, d_normal);

    tensor<double,6> dd_curva(eNN,numDOFs,eNN,numDOFs,pDim,pDim);
    SurfLagrParam::dd_Curva(dd_curva, DDbf, xuu, xuv, xvv, d_normal, dd_normal);

    tensor<double,4> dd_meancurva = product(imetric,dd_curva,{{0,4},{1,5}}) + product(d_imetric,d_curva,{{2,2},{3,3}})+ product(d_curva,d_imetric,{{2,2},{3,3}}) + product(curva,dd_imetric,{{0,4},{1,5}});

    //[5.1] Dissipation
    App += 0.5 * jac_n * mu * (product(d_metric_CnCn,d_metric,{{2,2},{3,3}}) + product(rodt_CnCn,dd_metric,{{0,4},{1,5}}));

    //[5.2] Helfrich energy
    App += 0.5 * kappa * (dd_jac * meancurva * meancurva + (2.0 * jac * meancurva) * dd_meancurva + (2.0 * meancurva) * outer(d_jac,d_meancurva) +  (2.0 * meancurva) * outer(d_meancurva,d_jac) + (2.0 * jac) * outer(d_meancurva,d_meancurva));

    //[5.3] Tension
    App += tension * dd_jac;
    Apt += outer(d_jac,t_bf) * deltat;

    //[5.4] Volume constraint
    App += pressure/3.0 * (dd_jac * xnormal + outer(d_jac,d_normal*x) + outer(d_jac,outer(bf,normal)) + outer(d_normal*x,d_jac) + outer(outer(bf,normal),d_jac) + jac * dd_normal * x + jac * outer(d_normal,bf).transpose({0,1,3,2}) + jac * outer(bf,d_normal.transpose({2,0,1})));
    Apg(all,all,0) += 1.0/3.0 * (d_jac * xnormal + jac * d_normal * x + jac * outer(bf,normal));

    //[5.5] Rigid body
    //[5.5.1] Translations
    Apg(all,0,1) += jac_n * bf;
    Apg(all,1,2) += jac_n * bf;
    Apg(all,2,3) += jac_n * bf;

    //[5.5.1] Rotations
    Apg(all,all,range(4,6)) += jac_n * outer(bf, antisym3D * x_n);

    Atp = Apt.transpose({2,0,1});
    Agp = Apg.transpose({2,0,1});
}


void poisson(SolveOptions opt)
{
    //Define mesh name
    opt.meshName = "P";

    ///=============== Define parameters of the model ===============///
    double force = 0.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;


    /// **************************************************************//
    /// *****                   MESH CREATION                    *****//
    /// **************************************************************//
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
    structMesh->genStructMesh(opt.nElem);

    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    /// **************************************************************//
    /// *****               DOFHANDLER CREATION                  *****//
    /// **************************************************************//
    RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
    dofHand->setNameTag("dofHand");
    dofHand->setNumDOFs(1);
    dofHand->Update();

    dofHand->setBoundaryCondition(0, MAxis::Xmin, [](double x){return 0.0;});
    dofHand->setBoundaryCondition(0, MAxis::Xmax, [](double x){return 1.0;});
    dofHand->UpdateGhosts();


    /// **************************************************************//
    /// *****               HIPERPROBLEM CREATION                *****//
    /// **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dofHand});
    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setElementFillings("Integ", LS_poisson);
    hiperProbl->setCubatureGauss("Integ", 9);
    hiperProbl->Update();

    /// **************************************************************//
    /// *****                SOLVE HIPERPROBLEM                  *****//
    /// **************************************************************//

    double time{};
    if (opt.solver == 0)
        time = solveAztecOO(hiperProbl, opt);
    else if (opt.solver == 1)
        time = solveAmesos2(hiperProbl, opt);
    else if (opt.solver == 2)
        time = solveMUMPS(hiperProbl, opt);

    if (hiperProbl->myRank() == 0)
        cout << endl << "Summary: Poisson " << opt.nElem << " " << hiperProbl->numProcs() << " " << time << endl << endl;

}

void cahnHilliard(SolveOptions opt)
{
    //Define mesh name
    opt.meshName = "C";

    //Mesh parameters
    BasisFuncType bfType = BasisFuncType::BSplines;
    ElemType eType = ElemType::Square;
    int bfOrder = 2;
    int gPts = pow(bfOrder+1, computePDim(eType));

    //Model parameters
    double deltat   = 1.E-7;
    double mobility = 1.0;
    double epsilon2 = 0.00005;

    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(3);
    userStr->dparam[0] = deltat;
    userStr->dparam[1] = mobility;
    userStr->dparam[2] = epsilon2;

    //Time parameters
    string oname = "CahnHilliard.";
    double maxTime  = 10000000;
    double maxNStep = 1;
    double maxDelt  = 10000000;
    double stepFactor = 0.95;
    int nSave = 20;

    //Generate mesh
    RCP<StructMeshGenerator> structMesh = rcp(new StructMeshGenerator);
    structMesh->setMesh(eType, bfType, bfOrder);
    structMesh->genStructMesh(opt.nElem);

    //Create distributed mesh
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(structMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

    //DOFsHandler
    RCP<DOFsHandler> dhand = rcp(new DOFsHandler(disMesh));
    dhand->setNameTag("dhand");
    dhand->setDOFs({"rho"});
    dhand->Update();

    //Initial and boundary conditions
    for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
    {
        double r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        dhand->nodeDOFs0->setValue(0, i, IndexType::Local, 0.6+0.3*r);
    }
    dhand->UpdateGhosts();

    //Create HiPerProblem
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    hiperProbl->setUserStructure(userStr);
    hiperProbl->setDOFsHandlers({dhand});
    hiperProbl->setIntegration("Integ", {"dhand"});
    hiperProbl->setCubatureGauss("Integ", gPts);
    hiperProbl->setElementFillings("Integ", LS_cahnHilliard);
    hiperProbl->setGlobalIntegrals({"ChemicalFreeEnergy", "SurfaceFreeEnergy", "GinzburgLandauFreeEnergy", "Mass"});
    hiperProbl->Update();


    //Initial guess
    dhand->nodeDOFs->setValue(dhand->nodeDOFs0);
    hiperProbl->UpdateGhosts();

    //Solve
    double time{};
    if (opt.solver == 0)
        time = solveAztecOO(hiperProbl, opt);
    else if (opt.solver == 1)
        time = solveAmesos2(hiperProbl, opt);
    else if (opt.solver == 2)
        time = solveMUMPS(hiperProbl, opt);

    if (hiperProbl->myRank() == 0)
        cout << endl << "Summary: CH " << opt.nElem << " " << hiperProbl->numProcs() << " " << time << endl << endl;
}

void viscous(SolveOptions opt)
{
    //Define mesh name
    opt.meshName = "I";

    //Other options
    bool printVtk   = false;
    int maxNSteps = 500;

    // Parameters of the model
    double kappa = 1.E0;
    double mu    = 1.E1;

    // Time related parameters
    double deltat  = 1.E1;

    //Put parameters in UserStructure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(3);
    userStr->dparam[0] = kappa; //bending rigidity
    userStr->dparam[1] = mu;
    userStr->dparam[2] = deltat;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    // Mesh generator
    RCP<UnstructVtkMeshGenerator> unstructMesh = rcp(new UnstructVtkMeshGenerator);
    try
    {
        if (opt.nElem < 500)
            throw runtime_error("The number of elements cannot be smaller than 500.");
        unstructMesh->setBasisFuncType(BasisFuncType::SubdivSurfs);
        unstructMesh->setElemType(ElemType::Triang);
        unstructMesh->genSphere([=](double x[3]){(void) x; return 20.0/double(opt.nElem);});
    }
    catch (runtime_error& err)
    {
        cout << ": MeshGenerator could not be created " << err.what() << endl;
        MPI_Finalize();
        return;
    }

    // Distribute mesh
    RCP<DistributedMesh> tensDisMesh  = rcp(new DistributedMesh);
    tensDisMesh->setMesh(unstructMesh);
    tensDisMesh->setBalanceMesh(true);
    tensDisMesh->Update();

    RCP<DistributedMesh> posDisMesh = rcp(new DistributedMesh);
    posDisMesh->setHRefinement(1);
    posDisMesh->setMeshRelation(MeshRelation::hRefin, tensDisMesh);
    posDisMesh->setBalanceMesh(true);
    posDisMesh->Update();

    RCP<DistributedMesh> gloDisMesh  = rcp(new DistributedMesh);
    gloDisMesh->setMeshRelation(MeshRelation::GlobConstr, posDisMesh);
    gloDisMesh->setBalanceMesh(false);
    gloDisMesh->Update();



    // **************************************************************//
    // *****               DOFHANDLER CREATION                  *****//
    // **************************************************************//
    RCP<DOFsHandler> posDHand = rcp(new DOFsHandler(posDisMesh));
    try
    {
        posDHand->setNameTag("posDHand");
        posDHand->setNumDOFs(3);
        posDHand->Update();
    }
    catch(runtime_error& err)
    {
        cout << ": DOFHandler could not be created " << err.what() << endl;
        MPI_Finalize();
        return;
    }

    InitializeNodalValues(posDHand, 3);
    posDHand->nodeDOFs0->setValue(posDHand->nodeDOFs);
    posDHand->UpdateGhosts();

    RCP<DOFsHandler> tenDHand = rcp(new DOFsHandler(tensDisMesh));
    try
    {
        tenDHand->setNameTag("tenDHand");
        tenDHand->setNumDOFs(1);
        tenDHand->Update();
    }
    catch(runtime_error& err)
    {
        cout << ": DOFHandler could not be created " << err.what() << endl;
        MPI_Finalize();
        return;
    }

    tenDHand->nodeDOFs->setValue(0.0);

    RCP<DOFsHandler> gloDHand = rcp(new DOFsHandler(gloDisMesh));
    try
    {
        gloDHand->setNameTag("gloDHand");
        gloDHand->setNumDOFs(7);
        gloDHand->Update();
    }
    catch (runtime_error& err)
    {
        cout << ": DOFHandler could not be created " << err.what() << endl;
        MPI_Finalize();
        return;
    }
    gloDHand->nodeDOFs->setValue(0.0);

    //Post-processing handler (for output and visualization)
    RCP<DOFsHandler> ppHand = rcp(new DOFsHandler(posDisMesh));
    ppHand->setNameTag("ppHand");
    ppHand->setDOFs({"Vx","Vy","Vz","tension", "pressure"});
    ppHand->setNodeAuxF({"x","y","z"});
    ppHand->Update();

    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
    try
    {
        // Set UserStructure
        hiperProbl->setUserStructure(userStr);
        hiperProbl->setConsistencyCheckDelta(1.E-4);
        hiperProbl->setConsistencyCheckTolerance(1.E-4);

        // Set DOFHandler
        hiperProbl->setDOFsHandlers({posDHand, tenDHand, gloDHand});

        // Set Integration
        hiperProbl->setIntegration("Integ", {"posDHand", "tenDHand", "gloDHand"});
        hiperProbl->setCubatureGauss("Integ", 3);
        hiperProbl->setElementFillings("Integ", LS_viscous);

        hiperProbl->setGlobalIntegrals({"Rayleighian", "Helfrich", "Dissipation", "Trd"});
        // Update
        hiperProbl->Update();
    }
    catch (runtime_error& err)
    {
        cout << ": HiPerProblem could not be created " << err.what() << endl;
        MPI_Finalize();
        return;
    }


    // **************************************************************//
    // *****                 SOLVERS' CREATION                  *****//
    // **************************************************************//

    //Prepare for solver
    posDHand->nodeDOFs0->setValue(posDHand->nodeDOFs);
    tenDHand->nodeDOFs0->setValue(tenDHand->nodeDOFs);
    gloDHand->nodeDOFs0->setValue(gloDHand->nodeDOFs);
    hiperProbl->UpdateGhosts();

    //Solve
    double time{};
    if (opt.solver == 0)
        time = solveAztecOO(hiperProbl, opt);
    else if (opt.solver == 1)
        time = solveAmesos2(hiperProbl, opt);
    else if (opt.solver == 2)
        time = solveMUMPS(hiperProbl, opt);

    if (hiperProbl->myRank() == 0)
        cout << endl << "Summary: Viscous " << opt.nElem << " " << hiperProbl->numProcs() << " " << time << endl << endl;
}

void vertex(SolveOptions opt)
{
    //Define mesh name
    opt.meshName = "V";

    // Default set of parameters
    int    gPts      = 1;
    double deltat    = 0.01;

    int dynamicTimeStepFlag     = 0;
    int periodicboxflag         = 0;
    int perturbseedbucklingflag = 0;
    int changeTensionRatioFlag = 0;

    double mu        = 0.0;
    double lambda    = 0.0;
    double kp        = 1.0;
    double kd        = 1.0;
    double ConcInit  = 0.03;
    double constbulkflag = 1;
    double bvisc     = 0.1;
    double lame1     = 1.0;
    double lame2     = 1.0;
    double activA    = 1.E0;
    double activB    = 1.E0;
    double activL    = 0.3;
    double eta_f     = 1.0E-07;
    double eta_f_basal = 1.0E-07;

    // Applied deformation
    double DelF00    = 0.0;
    double DelF01    = 0.0;
    double DelF10    = 0.0;
    double DelF11    = 0.0;

    // External traction
    double sigma_e_00    = 0.0;
    double sigma_e_01    = 0.0;
    double sigma_e_10    = 0.0;
    double sigma_e_11    = 0.0;

    int creepleftflag    = 0;
    int creeprightflag   = 0;
    int creeptopflag     = 0;
    int creepbottomflag  = 0;

    // Re-stiffening parameters
    double memb_thresh_high = 5.0;
    double memb_thresh_low  = 0.1;
    double memb_lam         = 0.03;

    // Buckling simulation parameters
    int    loadcase        = 1;
    double tcycle          = 100.0;
    double tequi           = 50.0;
    double pull_begin      = 0.0;
    double pull_stretchduration = 50.0;
    double push_stretchduration = 50.0;
    double push_begin      = 50.0;
    double totalTime       = 350.0;
    double deltat_max      = 0.1;
    double push_mag        = 1.0;
    double pull_mag        = 1.0;

    int    MAXITER    = 5;
    int    AZMAXITER  = 5000;
    double SOLTOL     = 1.E-8;
    double RESTOL     = 1.E-8;
    double AZSOLTOL   = 1.E-8;
    int    solverflag = 0; // 0 - iterative, 1 - direct solver
    int    nResSteps  = 50;
    bool   linesearch = true;

    // dome volume increase dynamics
    double domeInflrate        = 10;//200.0;
    double domeDeflrate            = 0;
    double activwindowlow  = 10;//-5.0;
    double activwindowhigh = 50;//5.0;
    double pulsestart      = 0;//-25;
    double pulsedist       = 10;//20;

    // Model parameters and solver options are read from a configuration file
    ConfigFile config("VM_"+to_string(opt.nElem)+"/VMconfig.cfg");

    config.readInto(gPts, "gPts");
    config.readInto(deltat, "deltat");
    config.readInto(dynamicTimeStepFlag,     "dynamicTimeStepFlag");
    config.readInto(periodicboxflag,         "periodicboxflag");
    config.readInto(perturbseedbucklingflag, "perturbseedbucklingflag");
    config.readInto(changeTensionRatioFlag, "changeTensionRatioFlag");

    // Material parameters
    config.readInto(lambda, "lambda");
    config.readInto(kp, "kp");
    config.readInto(kd, "kd");
    config.readInto(ConcInit, "ConcInit");
    config.readInto(constbulkflag, "constbulkflag");
    config.readInto(bvisc, "bvisc");
    config.readInto(lame1, "lame1");
    config.readInto(lame2, "lame2");
    config.readInto(activA, "activA");
    config.readInto(activB, "activB");
    config.readInto(activL, "activL");
    config.readInto(eta_f, "eta_f");
    config.readInto(eta_f_basal, "eta_f_basal");

    // Applied deformation
    config.readInto(DelF00, "DelF00");
    config.readInto(DelF01, "DelF01");
    config.readInto(DelF10, "DelF10");
    config.readInto(DelF11, "DelF11");

    // External traction
    config.readInto(sigma_e_00, "sigma_e_00");
    config.readInto(sigma_e_01, "sigma_e_01");
    config.readInto(sigma_e_10, "sigma_e_10");
    config.readInto(sigma_e_11, "sigma_e_11");

    config.readInto(creepleftflag, "creepleftflag");
    config.readInto(creeprightflag, "creeprightflag");
    config.readInto(creeptopflag, "creeptopflag");
    config.readInto(creepbottomflag, "creepbottomflag");

    // Re-stiffening parameters
    config.readInto(memb_thresh_high, "memb_thresh_high");
    config.readInto(memb_thresh_low, "memb_thresh_low");
    config.readInto(memb_lam, "memb_lam");

    // Buckling simulation parameters
    config.readInto(loadcase, "loadcase");
    config.readInto(tequi, "tequi");
    config.readInto(tcycle, "tcycle");
    config.readInto(pull_begin, "pull_begin");
    config.readInto(pull_stretchduration, "pull_stretchduration");
    config.readInto(push_stretchduration, "push_stretchduration");
    config.readInto(push_begin, "push_begin");
    config.readInto(totalTime, "totalTime");
    config.readInto(deltat_max, "deltat_max");
    config.readInto(push_mag, "push_mag");
    config.readInto(pull_mag, "pull_mag");

    // Solver parameters
    config.readInto(MAXITER, "MAXITER");
    config.readInto(AZMAXITER, "AZMAXITER");
    config.readInto(SOLTOL, "SOLTOL");
    config.readInto(RESTOL, "RESTOL");
    config.readInto(AZSOLTOL, "AZSOLTOL");
    config.readInto(solverflag, "solverflag");
    config.readInto(nResSteps, "nResSteps");

    // Dome inflation parameters
    config.readInto(domeInflrate, "domeInflrate");
    config.readInto(domeDeflrate, "domeDeflrate");
    config.readInto(activwindowlow, "activwindowlow");
    config.readInto(activwindowhigh, "activwindowhigh");
    config.readInto(pulsestart, "pulsestart");
    config.readInto(pulsedist, "pulsedist");

    // ---------------------------------------------------------------------------
    // ----------- Read mesh from input files and generate tissuemesh ------------
    // ---------------------------------------------------------------------------

    // Check if it is a restart simulation
    int     restart = 0;
    int     nSaveinit = 0, stepbegin = 0;
    double  simTimeinit{0.0}, loadValinit{0.0}, deltatinit{0.0}, havginit{0.0};
    // if (argc == 3)
    // {
    //     if (stod(argv[2]) == 1)
    //     {
    //         restart     = 1;

    //         // Read run parameters from restartinfo file (need to check for errors)
    //         string resinfoFileName = "restart_info.txt";
    //         ifstream inInfoFile(resinfoFileName);

    //         string line;
    //         getline(inInfoFile, line);
    //         nSaveinit   = stoi(line);

    //         getline(inInfoFile, line);
    //         stepbegin   = stoi(line);

    //         getline(inInfoFile, line);
    //         simTimeinit = stod(line);

    //         getline(inInfoFile, line);
    //         loadValinit = stod(line);

    //         getline(inInfoFile, line);
    //         deltatinit = stod(line);

    //         if (world_rank  == 0)
    //         {
    //             cout << "-------------------------------" << endl;
    //             cout << "Restarting the simulation:"      << endl;
    //             cout << "nSave       = " << nSaveinit     << endl;
    //             cout << "stepbegin   = " << stepbegin     << endl;
    //             cout << "simTimeinit = " << simTimeinit   << endl;
    //             cout << "loadValinit = " << loadValinit   << endl;
    //             cout << "deltatinit  = " << deltatinit    << endl;
    //             cout << "-------------------------------" << endl;
    //         }
    //     }
    // }

    Timer timer({"total"});
    timer.start("total");

    if( opt.myRank == 0 )
        cout << "Generating tissuemesh..." << endl;
    tissueMesh tissuemesh;

    int setConstraintsflag = 1;
    int setLinearConstraintsflag = 1;

    if (restart == 0)
    {
        tissuemesh.loadMesh("VM_"+to_string(opt.nElem)+"/vertexmesh", setConstraintsflag, setLinearConstraintsflag, restart);
    }
    else
    {
        tissuemesh.loadMesh("VM_"+to_string(opt.nElem)+"/vertexmesh_"+to_string(stepbegin), setConstraintsflag, setLinearConstraintsflag, restart);
    }
    tissuemesh.Update();

    if( opt.myRank == 0 )
        cout << "Finished generating tissuemesh..." << endl;

    setConstraintsflag = 0; // setting costraint flag to 0 for post-processing (calculating nodal forces)
    if (periodicboxflag == 1)
    {
        setLinearConstraintsflag = 0; // No linear consrtaints when simulating the periodic box
    }
    else
    {
        setLinearConstraintsflag = 1;
    }

    tissueMesh pptissuemesh;
    if (restart == 0)
    {
        pptissuemesh.loadMesh("VM_"+to_string(opt.nElem)+"/vertexmesh", setConstraintsflag, setLinearConstraintsflag, restart);
    }
    else
    {
        pptissuemesh.loadMesh("VM_"+to_string(opt.nElem)+"/vertexmesh_"+to_string(stepbegin), setConstraintsflag, setLinearConstraintsflag, restart);
    }
    pptissuemesh.Update();

    if( opt.myRank == 0 )
        cout << "Finished generating pptissuemesh..." << endl;

    // Write initial loaded mesh
    if( tissuemesh.myRank() == 0 )
        cout << "writing initial output file..." << endl;
    // pptissuemesh.saveVTK("InitialMesh");
    if( tissuemesh.myRank() == 0 )
        cout << "Finished writing initial output file..." << endl;

    // ---------------------------------------------------------------------------
    // --------------- Generate user structure and HiPerProblem ----------------
    // ---------------------------------------------------------------------------

    // Assign parameters in a user structure
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(27);
    userStr->iparam.resize(4);


    if (restart == 1)
    {
        deltat  = deltatinit;
    }
    userStr->dparam[0]  = deltat;
    userStr->dparam[1]  = mu;
    userStr->dparam[2]  = lambda;
    userStr->dparam[3]  = kp;
    userStr->dparam[4]  = kd;
    userStr->dparam[5]  = bvisc;
    userStr->dparam[6]  = lame1;
    userStr->dparam[7]  = lame2;
    userStr->dparam[8]  = activA;
    userStr->dparam[9]  = activB;
    userStr->dparam[10] = activL;
    userStr->dparam[11] = eta_f;
    userStr->dparam[18] = eta_f_basal;
    userStr->dparam[12] = sigma_e_00;
    userStr->dparam[13] = sigma_e_01;
    userStr->dparam[14] = sigma_e_10;
    userStr->dparam[15] = sigma_e_11;
    userStr->dparam[16] = memb_thresh_high;
    userStr->dparam[19] = memb_thresh_low;
    userStr->dparam[17] = memb_lam;
    userStr->dparam[20] = 0.0;
    userStr->dparam[26] = 0.0; // penalty coeff

    userStr->iparam[0]  = creepleftflag;
    userStr->iparam[1]  = creeprightflag;
    userStr->iparam[2]  = creeptopflag;
    userStr->iparam[3]  = creepbottomflag;

    // vector containing the information about the mesh having touched the substrate
    userStr->bparam.resize(tissuemesh.nItem());
    for (int i = 0; i < tissuemesh.nItem(); i++)
        userStr->bparam[i] = false;



    RCP<HiPerProblem> hiperMech   = tissuemesh.generateHiPerMechanics(userStr,gPts);
    RCP<HiPerProblem> pphiperMech = pptissuemesh.generateHiPerMechanics(userStr,gPts);

    // If not restarting, initialize cortical density and bulk concentration to desired values
    for (int i = 0; i < tissuemesh.nItem(); i++)
    {
        if (tissuemesh.isItemInPart(i))
        {
            if (restart == 0)
            {
                tissuemesh.mechs[2 * i + 1]->nodeDOFs->setValue(1, 0, IndexType::Local, ConcInit);
                tissuemesh.mechs[2 * i + 1]->nodeDOFs->setValue(2, 0, IndexType::Local, kp * ConcInit / kd);
            }

            // Fixed luminal pressure
            //tissuemesh.mechs[2 * i + 1]->setConstraint(6, 0, IndexType::Local, 0.0);

            // Use fixed bulk concentration, need to be implemented even if not restarting
            if (constbulkflag == 1)
            {
                tissuemesh.mechs[2 * i + 1]->setConstraint(1, 0, IndexType::Local, 0.0);
                // Fixing the cortical density as well for simple model
                // tissuemesh.mechs[2 * i + 1]->setConstraint(2, 0, IndexType::Local, 0.0);
            }

            //~ // Constraining everything for testing
            //~ tissuemesh.mechs[2 * i + 1]->setConstraint(0, 0, IndexType::Local, 0.0);
            //~ tissuemesh.mechs[2 * i + 1]->setConstraint(1, 0, IndexType::Local, 0.0);
            //~ tissuemesh.mechs[2 * i + 1]->setConstraint(2, 0, IndexType::Local, 0.0);
            //~ tissuemesh.mechs[2 * i + 1]->setConstraint(3, 0, IndexType::Local, 0.0);
            //~ tissuemesh.mechs[2 * i + 1]->setConstraint(4, 0, IndexType::Local, 0.0);
            //~ tissuemesh.mechs[2 * i + 1]->setConstraint(5, 0, IndexType::Local, 0.0);
            //~ tissuemesh.mechs[2 * i + 1]->setConstraint(6, 0, IndexType::Local, 0.0);
        }
    }

    // If viscoelasticity is not used, fix Gs
    for (int i=0; i <tissuemesh.nItem(); i++)
    {
        if (tissuemesh.isItemInPart(i))
        {
            if (bvisc == 0.0)
            {
                if (tissuemesh.myRank() == 0)
                {
                    cout << "No visco-elasticity as bvisc is" << bvisc << endl;
                    cout << "Fixing Gs" << endl;
                }

                // Fix Gs
                tissuemesh.mechs[2 * i + 1]->setConstraint(3,0,IndexType::Local,0.0);
                tissuemesh.mechs[2 * i + 1]->setConstraint(4,0,IndexType::Local,0.0);
                tissuemesh.mechs[2 * i + 1]->setConstraint(5,0,IndexType::Local,0.0);
            }
        }
    }

    //Set parameter
    double stepFactor = 0.90;

    //double parameters for NR
    std::vector<double> dparamNR;
    dparamNR.resize(4);
    dparamNR[0] = SOLTOL;
    dparamNR[1] = RESTOL;
    dparamNR[2] = AZSOLTOL;

    //Integer parameters for NR
    std::vector<int> iparamNR;
    iparamNR.resize(3);
    iparamNR[0] = MAXITER;
    iparamNR[1] = AZMAXITER;

    if (tissuemesh.myRank() == 0)
    {
        ofstream fp_td;
        string Fdatafilename = "TimeData.txt";
        if (restart == 1)
        {
            fp_td.open(Fdatafilename, ofstream::app); // Append data if restarting
        }
        else
        {
            fp_td.open(Fdatafilename, ofstream::trunc);
        }
        fp_td.close();

        Fdatafilename = "AvgStressStrainData.txt";
        if (restart == 1)
        {
            fp_td.open(Fdatafilename, ofstream::app); // Append data if restarting
        }
        else
        {
            fp_td.open(Fdatafilename, ofstream::trunc);
        }
        fp_td.close();
    }

    double pull_end        = pull_begin + pull_stretchduration;
    double push_end        = push_begin + push_stretchduration;

    // Imposed total deformation gradient on the boundary
    vector<double> Id     = {1.0, 0.0, 0.0, 1.0}; // Identity
    vector<double> Fapp   = {0.0, 0.0, 0.0, 0.0}; // Stores the total imposed deformation on the tissue
    vector<double> Fincr  = {DelF00, DelF01, DelF10, DelF11}; // total increment in F to be imposed

    // Initial Fill
    hiperMech->UpdateGhosts();
    hiperMech->FillLinearSystem();

    int    nSave    = nSaveinit;
    double simTime  = simTimeinit;
    double loadVal  = loadValinit;

    double tSimuc, tSimucpdeltatc, loadIncr;


    double xPosOfNode, yPosOfNode, zPosOfNode, luminalPressure;
    double radiusFromCenter;
    bool constraintsHaveChanged = false;
    bool startConstrainingMesh = false;
    bool pleaseCout = true;
    bool Error22 = false;
    int nBasalMeshSticking = 0;

    if( tissuemesh.myRank() == 0 )
        cout << "Starting simulation loop..." << endl;


    ////////////////////////////////////////////////////////////// Time -Loop //////////////////////////////////////////////////////////////
    double time{};
    {
        pleaseCout = true;

        //~ ////////////// DOME INFLATION /////////////////

        // Stop dome inflation after tequi
        if (simTime <= tequi )
            userStr->dparam[20] = domeInflrate;

        if (simTime > tequi )
            userStr->dparam[20] = 0.0;

        // Deflate Dome after tequi
        if (simTime > tequi + 10 && simTime < 2*tequi + 10) // && !Error22 && nBasalMeshSticking < 27) // && luminalPressure < 0.01 )
        {
            userStr->dparam[20] = domeDeflrate;
            startConstrainingMesh = true;
        }


        //~ ////////////// DOME INFLATION /////////////////

        if (tissuemesh.myRank() == 0)
            cout << "**** NOTE: Dome volume rate of change = " << userStr->dparam[20] << endl;

        if (tissuemesh.myRank() == 0)
            cout << "Luminal pressure= " << tissuemesh.mechs[1]->nodeDOFs->getValue(6, 0, IndexType::Local) << endl;

        //~ // Simulating fixing to substrate when dome deflates by fixing the basal nodes
        if (startConstrainingMesh)
        {


            for (int mecID = 0; mecID < hiperMech->_dhands.size(); mecID++)
            {
                if (mecID % 2 == 0) // get  only node positions (first DofHandler)
                {
                    auto mec = hiperMech->_dhands[mecID];
                    int meshID = mecID/2;
                    int meshIDloc = tissuemesh.locIdx(meshID);

                    if (tissuemesh.isItemInPart(meshID) && tissuemesh.meshes[meshIDloc].faceType == 1)
                    {
                        int nNodesToConstrain = 0;


                        for (int j = 0; j < mec->mesh->loc_nPts(); j++)
                        {
                            zPosOfNode = tissuemesh.mechs[mecID]->nodeDOFs->getValue(2, j, IndexType::Local);
                            if (zPosOfNode < 0.01 && tissuemesh.meshes[meshIDloc].faceType == 1)
                            {
                                nNodesToConstrain++;
                            }

                        }

                        if (nNodesToConstrain ==  mec->mesh->loc_nPts())
                        {
                            userStr->bparam[meshID] = true;
                        }

                    }

                }
            }

        }

        // For convergence purposes, we make friction very high at the beginning
        if (simTime < 0.1)
        {
            userStr->dparam[11] = 0.05;
            userStr->dparam[18] = 0.05;

            if (tissuemesh.myRank() == 0)
                cout << "**** NOTE: Using higher friction for initial steps, eta_f = " << userStr->dparam[11] << endl;
        }
        else
        {
            userStr->dparam[11] = eta_f;
            userStr->dparam[18] = eta_f_basal;
        }

        //~ ////////////// Changing lateral active tension /////////////////
        if (simTime > tequi + 5 && changeTensionRatioFlag)
        {
            userStr->dparam[10] = 2;
            if (tissuemesh.myRank() == 0)
                cout << "**** NOTE: Gamma_l has been changed to " << userStr->dparam[10] <<  " for all cells." << endl;
        }
        //~ ////////////// Changing lateral active tension /////////////////


        Timer timerstep({"Step","Prep","Fill","PreCond","Solver","PostProc"});
        timerstep.start("Step");

        timerstep.start("Prep");

        // Step time inside the cycle
        tSimuc         = fmod(simTime - tequi, tcycle);
        tSimucpdeltatc = fmod(simTime + deltat - tequi, tcycle);

        // Get the load increment to be imposed
        double incr_begin = Getloadstep(tSimuc,pull_begin,pull_end,push_begin,push_end,loadcase,push_mag,pull_mag);
        double incr_end   = Getloadstep(tSimucpdeltatc,pull_begin,pull_end,push_begin,push_end,loadcase,push_mag,pull_mag);
        loadIncr = (incr_end - incr_begin);

        double xactivelow, xactivehigh, activAMP;
        if (simTime > tequi)
        {
            //~ xactivelow  = pulsestart + pulsedist*(loadVal + loadIncr);
            //~ xactivehigh = xactivelow + 20.0;

            //~ activAMP    = 1.0;// + 4.0 * (loadVal + loadIncr);
        }
        else
        {
            // Don't do anything
            xactivelow  = -500;
            xactivehigh = -500;
            activAMP    = 1.0;
        }
        userStr->dparam[21] = xactivelow;
        userStr->dparam[22] = xactivehigh;
        userStr->dparam[23] = activAMP;
        userStr->dparam[24] = activwindowlow;
        userStr->dparam[25] = activwindowhigh;

        // Update previous timestep solution
        for (int i = 0; i < tissuemesh.nItem(); i++)
        {
            tissuemesh.mechs[2 * i + 0]->nodeDOFs0->setValue(tissuemesh.mechs[2 * i + 0]->nodeDOFs);
            tissuemesh.mechs[2 * i + 1]->nodeDOFs0->setValue(tissuemesh.mechs[2 * i + 1]->nodeDOFs);
        }

        // ---------------------------------------------------------------------------
        // ----------- Incrementing boundary conditions on dirichlet nodes -----------
        // ---------------------------------------------------------------------------

        // Store the master increments in the incrDOFs
        auto incrDOFs = hiperMech->linProbl->GetLHS();
        incrDOFs->PutScalar(0.0);
        int  hpIdx    = 0;

        for (int mecID = 0; mecID < hiperMech->_dhands.size(); mecID++) // going through all dofHandlers (DOF and gDOF)
        {
            auto mec = hiperMech->_dhands[mecID];

            for (int j = 0; j < mec->mesh->loc_nPts(); j++) // getting the number of points in that mechanics (which is equivalent the number of point in the mesh)
            {
                for (int dof = 0; dof < mec->numDOFs(); dof++) // getting to the degree of freedom of that dofHandlerS (3 for DOF and more for gDOF)
                {
                    if (mecID % 2 == 0)
                    {
                        //~ cout << "mecID : " << mecID << ", j : " << j << ", dof " << dof << endl;
                        int meshID = mecID/2;
                        int meshIDloc = tissuemesh.locIdx(meshID);
                        int loc_nPts  = tissuemesh.meshes[meshIDloc].nPts;

                        if (tissuemesh.isItemInPart(meshID))
                        {
                            // Get X
                            vector<double> X = {0.0, 0.0, 0.0};
                            X[0] = tissuemesh.mechs[mecID]->mesh->nodeCoord(j, 0, IndexType::Global);
                            X[1] = tissuemesh.mechs[mecID]->mesh->nodeCoord(j, 1, IndexType::Global);
                            X[2] = tissuemesh.mechs[mecID]->mesh->nodeCoord(j, 2, IndexType::Global);

                            // get increment value
                            vector<double> x_incr = {0.0, 0.0, 0.0};
                            x_incr[0] = loadIncr * (Fincr[0] * X[0] + Fincr[1] * X[1]);
                            x_incr[1] = loadIncr * (Fincr[2] * X[0] + Fincr[3] * X[1]);
                            x_incr[2] = 0.0;

                            // Apply the affine deformation if the node is flagged as dirichlet
                            if (tissuemesh.meshes[meshIDloc].cn_nodes[loc_nPts * dof + j] > 0)
                            {
                                (*incrDOFs)[0][hpIdx] = x_incr[dof];
                            }
                            else
                            {
                                (*incrDOFs)[0][hpIdx] = 0.0;
                            }
                        }
                    }
                    else
                    {
                        int meshID = mecID/2;
                        if (tissuemesh.isItemInPart(meshID))
                            (*incrDOFs)[0][hpIdx] = 0.0;
                    }
                    hpIdx++;
                }
            }
        }

        // Update nodeDOFs of slaves nodes following the linear constraints involving dirichlet masters
        hiperMech->linProbl->SetLHS(incrDOFs);
        hiperMech->AddSolutionToDOFs(1.0);

        timerstep.end("Prep");

        // Update and fill linear system
        timerstep.start("Fill");
        hiperMech->UpdateGhosts();
        hiperMech->FillLinearSystem();
        timerstep.end("Fill");


        //Solve
        double time{};
        if (opt.solver == 0)
            time = solveAztecOO(hiperMech, opt);
        else if (opt.solver == 1)
            time = solveAmesos2(hiperMech, opt);
        else if (opt.solver == 2)
            time = solveMUMPS(hiperMech, opt);

        if (hiperMech->myRank() == 0)
            cout << endl << "Summary: Vertex " << opt.nElem << " " << hiperMech->numProcs() << " " << time << endl << endl;
    }
}

void shells(SolveOptions opt)
{
    //Define mesh name
    opt.meshName = "S";

    //Other options
    string meshName = opt.meshName+to_string(opt.nElem);
    bool printVtk   = false;
    string model    = "Linear";

    cout << scientific;

    //=============== Define parameters of the model ===============//
    double E    = 1.E07;   //Young's modulus
    double nu   = 0.3  ;   //Poisson's ratio
    double hh   = 0.01;    //thickness of the thin-shell

    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(4);
    userStr->dparam[0] = E;
    userStr->dparam[1] = nu;
    userStr->dparam[2] = 0.0;
    userStr->dparam[3] = hh;


    // **************************************************************//
    // *****                   MESH CREATION                    *****//
    // **************************************************************//

    //====================== Mesh generation ======================//
    RCP<MeshLoader> loadedMesh = rcp(new MeshLoader);
    loadedMesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
    // loadedMesh->loadLegacyVtk("tubes_n1.vtk");
    loadedMesh->loadLegacyVtk("../../../meshes/cylinder_n" + to_string(opt.nElem) + ".vtk", MeshType::Sequential);

    //===========             Distribute mesh            ===========//
    RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
    disMesh->setMesh(loadedMesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();


    // **************************************************************//
    // *****               DOFsHANDLER CREATION                 *****//
    // **************************************************************//
    if (disMesh->myRank() == 0)
        cout << "Creating DOFsHandler" << endl;

    //===========           Create DOFHandler            ===========//
    RCP<DOFsHandler> dofHand_u = rcp(new DOFsHandler(disMesh));
    dofHand_u->setNameTag("dofHand_u");
    dofHand_u->setDOFs({"ux", "uy", "uz"});
    dofHand_u->Update();

    //===========          Boundary conditions          ===========//
    for (int i = 0; i < dofHand_u->mesh->loc_nPts(); i++)
    {
        int crease = dofHand_u->mesh->nodeCrease(i, hiperlife::IndexType::Local);
        if (crease > 0)
        {
            double x = disMesh->nodeCoord(i, 'x', IndexType::Local);
            double y = disMesh->nodeCoord(i, 'y', IndexType::Local);
            double z = disMesh->nodeCoord(i, 'z', IndexType::Local);
            if (z < 0.1)
            {
                dofHand_u->setConstraint("ux", i, IndexType::Local, 0.0);
                dofHand_u->setConstraint("uy", i, IndexType::Local, 0.0);
                dofHand_u->setConstraint("uz", i, IndexType::Local, 0.0);
            }
            else if (z > 0.1)
            {
                if (model == "Linear")
                {
                    dofHand_u->setConstraint("uz", i, IndexType::Local, 0.001);
                }
                else
                {
                    dofHand_u->setConstraint("uz", i, IndexType::Local, 0.0);
                    dofHand_u->nodeDOFs0->setValue("uz", i, IndexType::Local, 0.001);
                }
            }
        }
    }
    dofHand_u->UpdateGhosts();

    // **************************************************************//
    // *****               HIPERPROBLEM CREATION                *****//
    // **************************************************************//
    if (disMesh->myRank() == 0)
        cout << "Creating hiperProblem" << endl;
    RCP<HiPerProblem> hiperProbl_u = rcp(new HiPerProblem);
    hiperProbl_u->setUserStructure(userStr);
    hiperProbl_u->setDOFsHandlers({dofHand_u});
    hiperProbl_u->setIntegration("Integ", {"dofHand_u"});
    hiperProbl_u->setCubatureGauss("Integ", 3);
    hiperProbl_u->setGlobalIntegrals({"Elastic_Energy"});
    if (model == "Linear")
        hiperProbl_u->setElementFillings("Integ", nullptr, LinearShellGradientByElement, LinearShellHessianByElement);
    else
        hiperProbl_u->setElementFillings("Integ", nullptr, ShellGradientByElement, ShellHessianByElement);
    // hiperProbl_u->setElementFillings("Integ", ShellSystem);
    hiperProbl_u->Update();


    // **************************************************************//
    // *****                SOLVE HIPERPROBLEM                  *****//
    // **************************************************************//

    //Solve
    double time{};
    if (opt.solver == 0)
        time = solveAztecOO(hiperProbl_u, opt);
    else if (opt.solver == 1)
        time = solveAmesos2(hiperProbl_u, opt);
    else if (opt.solver == 2)
        time = solveMUMPS(hiperProbl_u, opt);

    if (hiperProbl_u->myRank() == 0)
        cout << endl << "Summary: ThinShells " << opt.nElem << " " << hiperProbl_u->numProcs() << " " << time << endl << endl;
}


int main(int argc, char *argv[])
{

    /// **************************************************************//
    /// *****                 INITIALIZATION                     *****//
    /// **************************************************************//
    MPI_Init(nullptr, nullptr);
    int myRank;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    //Options
    SolveOptions opt;
    opt.myRank = myRank;

    //Command-line parameters
    Teuchos::CommandLineProcessor parser;
    parser.setDocString("Get options from the command-line and print this help message automatically.\n");
    int problem{};
    parser.setOption("problem", &problem, "problem.");
    parser.setOption("solver", &opt.solver, "solver.");
    parser.setOption("nElem", &opt.nElem, "nElem.");
    parser.setOption("symmetric", &opt.symmetric, "symmetric.");
    parser.setOption("matrixOnHost", &opt.matrixOnHost, "matrixOnHost.");
    parser.setOption("anType", &opt.anType, "anType.");
    parser.setOption("ordLibrary", &opt.ordLibrary, "ordLibrary.");
    Teuchos::CommandLineProcessor::EParseCommandLineReturn
        parseReturn= parser.parse(argc, argv);
    if (parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED)
        return 0;
    if (parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL)
        return 1;

    //Checks
    if (problem < 1 or problem > 5)
        throw runtime_error("Problem not defined");
    if (opt.solver < 0 or opt.solver > 2)
        throw runtime_error("Solver not defined");

    //Other options
    opt.printMat = false;


    /// **************************************************************//
    /// *****                     SOLVE                          *****//
    /// **************************************************************//

    if (problem == 1)
        poisson(opt);
    else if (problem == 2)
        cahnHilliard(opt);
    else if (problem == 3)
        viscous(opt);
    else if (problem == 4)
        vertex(opt);
    else if (problem == 5)
        shells(opt);

    /// **************************************************************//
    /// *****                    FINALIZE                        *****//
    /// **************************************************************//

    MPI_Finalize();
    return 0;
}
