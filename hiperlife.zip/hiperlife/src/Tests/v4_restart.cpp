
/// C++ headers
#include <iostream>
#include <mpi.h>

/// Trilinos headers
#include <Teuchos_RCP.hpp>

/// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_GlobalBasisFunctions.h"
#include "hl_StructMeshGenerator.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_LinearSolver_Direct_MUMPS.h"

using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;

void LS(RCP<hiperlife::FillStructure> fillStr);
void LS_dummy(RCP<hiperlife::FillStructure> fillStr);

/// In this first tutorial everything is implemented inside the main
///   function
int main()
{

    MPI_Init(nullptr, nullptr);
    int myRank;
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

    ///=============== Define parameters of the model ===============///
    double force = 10.0;     // Forcing
    RCP<UserStructure> userStr = rcp(new UserStructure);
    userStr->dparam.resize(1);
    userStr->dparam[0] = force;
    int DOF = 2;

    //First pass
    if (false)
    {
        if (myRank == 0)
            cout << endl << endl << "SOLVE 1" << endl;
        ///====================== Mesh generation ======================///
        ///
        RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
        mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 2);
        mesh->genStructMesh(40);
        // mesh->genStructMesh(5,13,7);
        // mesh.genTorusSolidSector(5, 13, 7, 0.5, 1.0, M_PI/3.2);
        // mesh.genQuarterPlateWithCircularHole(50, 50, 1.0, 0.3);
        // mesh.genAnnularSector(10, 10, 0.2, 1.0, M_PI/2);
        // mesh.genTorusSolidQuarter(5, 13, 7, 0.5, 1.0);

        // MeshLoader mesh;
        // mesh->setMesh(ElemType::Triang, BasisFuncType::SubdivSurfs, 2);
        // mesh->loadMesh("../meshes/circle_n3.vtk");

        ///===========             Distribute mesh            ===========///
        RCP<DistributedMesh> disMesh = rcp(new DistributedMesh);
        disMesh->setMesh(mesh);
        disMesh->setBalanceMesh(true);
        disMesh->Update();
        disMesh->printFileLegacyVtk("Mesh");

        ///===========           Create DOFsHandler           ===========///
        RCP<DOFsHandler> dofHand = rcp(new DOFsHandler(disMesh));
        dofHand->setNameTag("dofHand");
        // dofHand->setNumDOFs(DOF);
        dofHand->setDOFs({"d0", "d1"});
        // dofHand->setNumNodeAuxF(3);
        dofHand->setNodeAuxF({"a0", "a1", "a2"});
        // dofHand->setNumElemAuxF(1);
        dofHand->setElemAuxF({"e0"});
        dofHand->Update();

        ///===========          Boundary conditions          ===========///
        for (int d = 0; d < DOF; d++)
        {
            dofHand->setBoundaryCondition(d, MAxis::Xmin, -1.0);
            dofHand->setBoundaryCondition(d, MAxis::Xmax, 1.0);
        }
        for (int i = 0; i < dofHand->mesh->loc_nPts(); i++)
        {
            double x = dofHand->mesh->nodeCoord(i, 0, IndexType::Local);
            double y = dofHand->mesh->nodeCoord(i, 1, IndexType::Local);
            if (dofHand->numNodeAuxF() > 0)
            {
                dofHand->nodeAuxF->setValue(0, i, IndexType::Local, x);
                dofHand->nodeAuxF->setValue(1, i, IndexType::Local, y);
                dofHand->nodeAuxF->setValue(2, i, IndexType::Local, x*y);
            }
        }
        if (dofHand->numElemAuxF() > 0)
        {
            for (int e = 0; e < dofHand->mesh->loc_nElem(); e++)
            {
                // int el = dofHand->mesh->_elemFlags->getValue(0, e, IndexType::Local);
                dofHand->elemAuxF->setValue(0, e, IndexType::Local, e);
            }
        }
        dofHand->UpdateGhosts();

        ///===========              Hiperproblem              ===========///
        RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
        hiperProbl->setUserStructure(userStr);
        hiperProbl->setDOFsHandlers({dofHand});
        hiperProbl->setIntegration("Integ", {"dofHand"});
        hiperProbl->setCubatureGauss("Integ", 4);
        hiperProbl->setElementFillings("Integ", LS);
        hiperProbl->setGlobalIntegrals({"Area"});
        hiperProbl->Update();


        ///===========                  Solver                  ===========///
        RCP<MUMPSDirectLinearSolver> solver = rcp (new MUMPSDirectLinearSolver());
        solver->setHiPerProblem(hiperProbl);
        solver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
        solver->setDefaultParameters();
        solver->Update();


        ///===========                  Print                 ===========///
        dofHand->printFile("Poisson.0", OutputMode::Text, true);
        dofHand->printFileLegacyVtk("Poisson.0", true);

        ///===========                  Solve                 ===========///
        hiperProbl->FillLinearSystem();
        solver->solve();
        solver->UpdateSolution();

        if (hiperProbl->myRank() == 0)
            cout << scientific << std::setprecision(16) << "Area = " << hiperProbl->globalIntegral("Area") << endl;

        dofHand->printFile("Poisson.1", OutputMode::Text, true);
        dofHand->printFileLegacyVtk("Poisson.1", true);
    }

    //Restart
    if (false)
    {
        if (myRank == 0)
            cout << endl << endl << "RESTART 1" << endl;

        userStr->dparam[0] = 10.0;
        ///===========           Create DOFHandler            ===========///
        RCP<DOFsHandler> dofHand = rcp(new DOFsHandler("dofHand"));
        dofHand->setFilePrefix("Poisson.1");
        dofHand->Update();

        ///===========              Hiperproblem              ===========///
        RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
        hiperProbl->setUserStructure(userStr);
        hiperProbl->setDOFsHandlers({dofHand});
        hiperProbl->setIntegration("Integ", {"dofHand"});
        hiperProbl->setCubatureGauss("Integ", 4);
        hiperProbl->setElementFillings("Integ", LS);
        hiperProbl->setGlobalIntegrals({"Area"});
        hiperProbl->Update();

        ///===========                  Solver                  ===========///
        RCP<MUMPSDirectLinearSolver> solver = rcp (new MUMPSDirectLinearSolver());
        solver->setHiPerProblem(hiperProbl);
        solver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::None);
        solver->setDefaultParameters();
        solver->Update();

        ///===========                  Print                 ===========///
        dofHand->printFile("Poisson.2", OutputMode::Text, true);
        dofHand->printFileLegacyVtk("Poisson.2", true);

        ///===========                  Solve                 ===========///
        hiperProbl->FillLinearSystem();
        solver->solve();
        solver->UpdateSolution();

        if (hiperProbl->myRank() == 0)
            cout << scientific << std::setprecision(16) << "Area = " << hiperProbl->globalIntegral("Area") << endl;

        dofHand->printFile("Poisson.3", OutputMode::Text, true);
        dofHand->printFileLegacyVtk("Poisson.3", true);
    }


    //Test with mesh relations
    if (true)
    {
        if (myRank == 0)
            cout << endl << endl << "CREATE DOFsHANDLERs with MeshRelations 2" << endl;

        ///====================== Mesh generation ======================///
        RCP<UnstructVtkMeshGenerator> mesh = rcp(new UnstructVtkMeshGenerator);
        mesh->setBasisFuncType(BasisFuncType::SubdivSurfs);
        mesh->setElemType(ElemType::Triang);
        mesh->genSphere([](double x[3]){(void) x; return 4.0;});

        // RCP<StructMeshGenerator> mesh = rcp(new StructMeshGenerator);
        // mesh->setMesh(ElemType::Triang, BasisFuncType::Lagrangian, 1);
        // mesh->genStructMesh(4);


        ///===========             Distribute mesh            ===========///
        RCP<DistributedMesh> tensDisMesh  = rcp(new DistributedMesh);
        tensDisMesh->setMesh(mesh);
        tensDisMesh->setBalanceMesh(true);
        tensDisMesh->Update();
        tensDisMesh->printFileLegacyVtk("unstruct");

        RCP<DistributedMesh> posDisMesh = rcp(new DistributedMesh);
        posDisMesh->setHRefinement(1);
        posDisMesh->setMeshRelation(MeshRelation::hRefin, tensDisMesh);
        posDisMesh->setBalanceMesh(true);
        posDisMesh->Update();

        RCP<DistributedMesh> gloDisMesh  = rcp(new DistributedMesh);
        gloDisMesh->setMeshRelation(MeshRelation::GlobConstr, tensDisMesh);
        gloDisMesh->setBalanceMesh(false);
        gloDisMesh->Update();
        gloDisMesh->printFileLegacyVtk("gloDHand");

        ///===========           Create DOFsHandler           ===========///
        RCP<DOFsHandler> tenDHand = rcp(new DOFsHandler(tensDisMesh));
        tenDHand->setNameTag("tenDHand");
        tenDHand->setNumDOFs(1);
        tenDHand->Update();
        tenDHand->nodeDOFs->setValue(0.0);
        tenDHand->printFile("tenDHand", OutputMode::Text, true);
        tenDHand->printFileLegacyVtk("tenDHand", true);

        // RCP<DOFsHandler> posDHand = rcp(new DOFsHandler(posDisMesh));
        // posDHand->setNameTag("posDHand");
        // posDHand->setNumDOFs(3);
        // posDHand->Update();
        // posDHand->nodeDOFs->setValue(posDisMesh->_nodeData);
        // posDHand->nodeDOFs0->setValue(posDHand->nodeDOFs);
        // posDHand->UpdateGhosts();
        // posDHand->printFile("posDHand", OutputMode::Text, true);

        RCP<DOFsHandler> gloDHand = rcp(new DOFsHandler(gloDisMesh));
        gloDHand->setNameTag("gloDHand");
        gloDHand->setNumDOFs(7);
        gloDHand->Update();
        gloDHand->nodeDOFs->setValue(10.0);
        gloDHand->printFile("gloDHand", OutputMode::Text, true);
        gloDHand->printFileLegacyVtk("gloDHand", true);
    }

    if (true)
    {
        if (myRank == 0)
            cout << endl << endl << "READ DOFsHANDLERs with MeshRelations 2" << endl;

        ///===========           Create DOFsHandler           ===========///
        RCP<DOFsHandler> tenDHand = rcp(new DOFsHandler());
        tenDHand->setFilePrefix("tenDHand");
        tenDHand->Update();
        tenDHand->printFileLegacyVtk("tenDHand2", true);

        // RCP<DOFsHandler> posDHand = rcp(new DOFsHandler());
        // posDHand->setFilePrefix("posDHand");
        // posDHand->Update();
        // // posDHand->mesh->setMeshRelation(MeshRelation::hRefin, tenDHand->mesh);

        RCP<DOFsHandler> gloDHand = rcp(new DOFsHandler());
        gloDHand->setFilePrefix("gloDHand");
        gloDHand->Update();
        gloDHand->printFileLegacyVtk("gloDHand2", true);

        ///===========              Hiperproblem              ===========///
        // RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
        // hiperProbl->setDOFsHandlers({posDHand, tenDHand});
        // hiperProbl->setIntegration("Integ", {"posDHand", "tenDHand"});
        // hiperProbl->setCubatureGauss("Integ", 3);
        // hiperProbl->setElementFillings("Integ", LS_dummy);
        // hiperProbl->Update();

        // RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
        // hiperProbl->setDOFsHandlers({posDHand, tenDHand, gloDHand});
        // hiperProbl->setIntegration("Integ", {"posDHand", "tenDHand", "gloDHand"});
        // hiperProbl->setCubatureGauss("Integ", 3);
        // hiperProbl->setElementFillings("Integ", LS_dummy);
        // hiperProbl->Update();

        RCP<HiPerProblem> hiperProbl = rcp(new HiPerProblem);
        hiperProbl->setDOFsHandlers({tenDHand, gloDHand});
        hiperProbl->setIntegration("Integ", {"posDHand", "gloDHand"});
        hiperProbl->setCubatureGauss("Integ", 3);
        hiperProbl->setElementFillings("Integ", LS_dummy);
        hiperProbl->Update();
    }

    ///===========                 Finalize                ===========///
    MPI_Finalize();
    return 0;
}

void LS(RCP<FillStructure> fillStr)
{

    ///===========          Initialize variables           ==========///
    double force = fillStr->userStr->dparam[0];
    SubFillStructure& subFill = (*fillStr)["dofHand"];
    int DOF  = subFill.numDOFs;   // Number of degrees of freedom
    int eNN  = subFill.eNN;       // Number of neighbor nodes
    int nDim = subFill.nDim;      // Number of spatial dimensions
    int pDim = subFill.pDim;      // Number of parametric dimension
    vector<double>& xe_nodes  = subFill.nborCoords;  // Vector of node coordinates
    double* Na  = subFill.nborBFsDers(0);  // Local shape function
    double* glNa = subFill.nborBFsDers(1); // Local shape function derivatives
    vector<double> gNa(eNN*pDim);
    double jac;
    GlobalBasisFunctions::gradients(gNa.data(), jac, subFill);

    vector<double> x(pDim);
    Array::Fill(x.data(), pDim, 0.0);
    for (int i = 0; i < eNN; i++)
    {
        for (int d = 0; d < pDim; d++)
            x[d] += xe_nodes[nDim*i+d]  * Na[i];
    }

    ///=====================  Fill linear system =====================///
    double N_e = DOF*eNN;
    for (int i = 0; i < eNN; i++)
    {
        for (int j = 0; j < eNN; j++)
        {
            /// Compute the product of the gradient of the basis
            /// functions
            double gNagNb{};
            for (int d = 0; d < pDim; d++)
                gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];

            /// Fill matrix
            for (int d = 0; d < DOF; d++)
                fillStr->Ak(0, 0)[(i*DOF+d)*N_e+j*DOF+d] += jac * gNagNb;
        }

        /// Fill RHS
        for (int d = 0; d < DOF; d++)
            fillStr->Bk(0)[i*DOF+d] += jac * Na[i] * force;
    }

    fillStr->addToGlobalIntegral("Area", jac);

    return;
}

void LS_dummy(RCP<FillStructure> fillStr)
{
    (void) fillStr;
}
