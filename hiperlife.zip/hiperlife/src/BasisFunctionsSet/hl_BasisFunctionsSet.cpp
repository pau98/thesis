/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <vector>
#include <algorithm>
#include <functional>

#include <Teuchos_RCP.hpp>

#include "hl_CubatureInfo.h"
#include "hl_BasisFunctionsSet.h"
#include "hl_CubatureSet.h"
#include "hl_AdjcyENStruct.h"
#include "hl_BasisFunctions.h"
#include "hl_CubatureSet.h"

using namespace std;

using Teuchos::rcp;
using Teuchos::RCP;


namespace hiperlife
{

    void BasisFunctionsSet::_setComplexTypes()
    {
        // Locate all possible combinations between BF types and Cuba types
        pair<int, int> tmpPair(-1, -1);
        for (int e = 0; e < _adjcyEN->loc_nElem(); e++)
        {
            for (auto ctag: _cubaSet->cubaTag(e, IndexType::Local))
            {
                //Create pair (bfTag, cubaTag)
                tmpPair.first  = _BF->getTag(e, IndexType::Local);
                tmpPair.second = ctag;

                //Add to complexTypes if not already there
                auto cTypeIter = std::find(_complexTypes.begin(), _complexTypes.end(), tmpPair);
                if (cTypeIter == _complexTypes.end())
                    _complexTypes.push_back(pair<int, int>(tmpPair));
            }
        }

        //Sort complexTypes
        std::sort(_complexTypes.begin(), _complexTypes.end());
    }

    void BasisFunctionsSet::_setBfsTags()
    {
        // Locate all possible combinations between BF types and Cuba types
        pair<int, int> tmpPair(-1, -1);
        for (int e = 0; e < _adjcyEN->loc_nElem(); e++)
        {
            for (auto ctag: _cubaSet->cubaTag(e, IndexType::Local))
            {
                tmpPair.first = _BF->getTag(e, IndexType::Local);
                tmpPair.second = ctag;

                auto iter = std::find(_complexTypes.begin(), _complexTypes.end(), tmpPair);

                if (iter == _complexTypes.end())
                    throw runtime_error("BasisFunctionsSet::_setBfsTags: Tags cannot be found.");

                int index = std::distance(_complexTypes.begin(), iter);

                _bfsTags[e].push_back(index);
            }
        }
    }

    void BasisFunctionsSet::_saveBfsInfo(int type)
    {
        auto it = _complexTypes.begin();
        std::advance(it, type);

        //Initialize bf-related variables
        int bfTag   = it->first;
        int nNbo = _BF->getNumNbors(bfTag);
        int oDer = _BF->orderDers();

        //Initialize cubature-related variables
        int cubaTag = it->second;
        CubatureInfo& cubaInfo = _cubaSet->cubaInfo(cubaTag);
        int iPts = cubaInfo.iPts;
        int pDim = cubaInfo.pDim;

        //Compute vector sizes
        int iptSize{0};
        for (int d = 0; d <= oDer; d++)
            iptSize = iptSize * pDim + 1;
        iptSize = iptSize * nNbo;
        int totalSize = iptSize * iPts;

        //Save info
        _iPtSize[type] = iptSize;
        _bfsInfo[type].resize(totalSize);
        vector<double> xsamples(pDim);
        for (int ipt = 0; ipt < iPts; ipt++)
        {
            //Get ref. coordinates of the integration point
            for (int i = 0; i < pDim; i++)
                xsamples[i] = cubaInfo.xSamples[ipt * pDim + i];

            //Get basis function values
            vector<vector<double>>& bfElemRef =
                _BF->computeBasisFunctionsReference(xsamples, bfTag);

            //Store basis function values
            int n = ipt * iptSize;
            for (auto vec: bfElemRef)
            {
                for (auto bf: vec)
                {
                    _bfsInfo[type][n] = bf;
                    n++;
                }
            }
        }
    }

    void BasisFunctionsSet::Update()
    {
        //Set complexTypes (possible combinations of (bfTag, cubaTag))
        _setComplexTypes();

        //Set basis function set tags
        _bfsTags.resize(_adjcyEN->loc_nElem());
        // _BFTags = rcp(new Epetra_IntVector(_adjcyEN->_adjcyElemNodes->RowMap()));
        // _BFTags->PutValue(-1);
        _setBfsTags();

        //Save main info
        int numTypes = _complexTypes.size();
        _bfsInfo.resize(numTypes);
        _iPtSize.resize(numTypes);
        for (int t = 0; t < numTypes; t++)
            _saveBfsInfo(t);

        // //Reserve memory for auxVector
        // unsigned int maxSize = 0;
        // for (auto vec : _bfsInfo)
        //     if (vec.size() > maxSize)
        //         maxSize = vec.size();
        // _auxVector.reserve(maxSize);
    }


    int BasisFunctionsSet::bfsTag(int e, int cuba, IndexType idxtype)
    {
        int e_loc;
        if (idxtype == IndexType::Global)
            e_loc = _BF->_adjcyEN->_adjcyElemNodes->LRID(e);
        else
            e_loc = e;

        return _bfsTags[e_loc][cuba];
    }

    int BasisFunctionsSet::intPtSize(int e, int cuba, IndexType idxtype)
    {
        int tag = bfsTag(e, cuba, idxtype);
        return _iPtSize[tag];
    }

    double* BasisFunctionsSet::basisFunctionRef(int e, int cuba, IndexType idxtype, int ipt)
    {
        int tag = bfsTag(e, cuba, idxtype);
        return &_bfsInfo[tag][ipt * _iPtSize[tag]];
    }


    // // FIXME Save in different / template version
    // int Pow(int x, int p)
    // {
    //     if (p == 0) return 1;
    //     if (p == 1) return x;

    //     int tmp = Pow(x, p/2);
    //     if (p%2 == 0)
    //         return tmp * tmp;
    //     else
    //         return x * tmp * tmp;
    // }


    // std::vector<double>& BasisFunctionsSet::getRefBFElem(int e, IndexType idxtype)
    // {
    //     int tag = bfsTag(e, 0, idxtype);
    //     return _bfsInfo[tag];
    // }


    // double* BasisFunctionsSet::getRefDers(int e, int cuba, IndexType idxtype, int ipt, int order)
    // {
    //     int tag = bfsTag(e, cuba, idxtype);

    //     int nNbo = _BF->getNumNbors(tag);


    //     auto it = _complexTypes.begin();
    //     std::advance(it, tag);

    //     int cubaTag = it->second;

    //     CubatureInfo& cubaInfo = _cubaSet->cubaInfo(cubaTag);

    //     // all ders for a ipts and nbor
    //     int j_ipt{0};
    //     for (int d = 0; d < order; d++)
    //         j_ipt = j_ipt * cubaInfo.pDim + 1;

    //     j_ipt = j_ipt * nNbo;


    //     // return getBFIntPt(e, idxtype, ipt) + sizeof(double) * j_ipt;
    //     return &_bfsInfo[tag][ipt * _iPtSize[tag] + j_ipt];
    // }

    // double* BasisFunctionsSet::getRefNborDers(int e, int cuba, IndexType idxtype, int ipt, int order, int nbor)
    // {
    //     int tag = bfsTag(e, cuba, idxtype);

    //     int nNbo = _BF->getNumNbors(tag);

    //     auto it = _complexTypes.begin();
    //     std::advance(it, tag);

    //     int cubaTag = it->second;

    //     CubatureInfo& cubaInfo = _cubaSet->cubaInfo(cubaTag);

    //     // all ders for a ipts and nbor
    //     int j_ipt{0};
    //     int j_der = Pow(cubaInfo.pDim, order);

    //     for (int d = 0; d < order; d++)
    //         j_ipt = j_ipt * cubaInfo.pDim + 1;

    //     j_ipt = j_ipt * nNbo + j_der * nbor;


    //     // return getBFIntPt(e, idxtype, ipt) + sizeof(double) * j_ipt;
    //     return &_bfsInfo[tag][ipt * _iPtSize[tag] + j_ipt];
    // }


    // double* BasisFunctionsSet::getRefNborDersIdx(int e, int cuba, IndexType idxtype, int ipt, int order, int nbor, int idx)
    // {
    //     return getRefNborDers(e, cuba, idxtype, ipt, order, nbor) + sizeof(double) *idx;
    // }

//     std::vector<double>& BasisFunctionsSet::getBFElem(int e, IndexType idxtype)
//     {

//         cout << __FILE__ << "::" << __LINE__ << ":  This function is not working!!!" << endl;
//         throw bad_function_call();


//         int e_loc;

//         if (idxtype == IndexType::Global)
//             e_loc = _BF->_adjcyEN->_adjcyElemNodes->LRID(e);
//         else
//             e_loc = e;

//         int type = _BFTags[e_loc][0];
//         int oDer = _BF->orderDers();

//         vector<int>& sort = _BF->_adjcyEN->getSortingList(e_loc, IndexType::Local);
//         int nNbors = sort.size();

// //         int nNbors = _BF->getNumNbors(type);
// //         cout <<"Check:   " << nNbors << "  " << sort.size() << endl;

//         auto it = _complexTypes.begin();
//         std::advance(it, type);

//         int cubaTag = it->second;

//         CubatureInfo&
//         cubaInfo = _cubaSet->cubaInfo(cubaTag);
//         int iPts = cubaInfo.iPts;
//         int pDim = cubaInfo.pDim;

//         // all ders for a ipts and nbor
//         int totalSize{0};
//         vector<int> dSize(oDer+1);
//         vector<int> dOffs(oDer+1);


//         for (int d = 0; d <= oDer; d++)
//         {
//             dOffs[d] = totalSize * nNbors;
//             totalSize = totalSize * cubaInfo.pDim + 1;
//             dSize[d] = Pow(pDim, d);
//         }

//         totalSize = totalSize * nNbors *  iPts;

//         _auxVector.resize(totalSize);


//         int j = 0;
//         for (int ipt = 0; ipt < iPts; ipt++)
//         {
//             for (int der = 0; der <= oDer; der++)
//             {
//                 double* allInfo = getRefDers(e_loc, IndexType::Local, ipt, der);

//                 for (int nbor = 0; nbor < nNbors; nbor++)
//                 {
//                     int idx = sort[nbor];

//                     for (int idxder = 0; idxder < dSize[der]; idxder++)
//                     {
//                         _auxVector[j] = allInfo[idx * dSize[der] + idxder];

//                         j++;
//                     }

//                 }
//             }
//         }


//         return _auxVector;
//     }


}
