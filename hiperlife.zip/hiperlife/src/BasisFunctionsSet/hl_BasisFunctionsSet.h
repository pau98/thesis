/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef BASISFUNCTIONSSET_H
#define BASISFUNCTIONSSET_H

#include <vector>

#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_CubatureSet.h"
#include "hl_DistributedClass.h"
#include "hl_BasisFunctions.h"


namespace hiperlife
{
    /*!
     * \class BasisFunctionsSet
     * \brief Class that stores sets of basis functions
     *
     * It allows to save important information during initialization
     *
    */
    class BasisFunctionsSet
    {
        public:
            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects
             * can be created from temporal objects through move constructors.
             *  @{ */
            BasisFunctionsSet() = default;
            BasisFunctionsSet(BasisFunctionsSet&& other) = default;
            BasisFunctionsSet(const BasisFunctionsSet& other) = delete;
            ~BasisFunctionsSet() = default;
            // Operators
            BasisFunctionsSet& operator=(const BasisFunctionsSet& other) = delete;
            BasisFunctionsSet& operator=(BasisFunctionsSet&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate this object and,
             * in fact, several can be incompatible between each other.
             *  @{*/
            void setAdjcyEN(Teuchos::RCP<AdjcyENStruct> adjcy){_adjcyEN = adjcy;};
            void setCubaSet(Teuchos::RCP<CubatureSet> cubaSet){_cubaSet = cubaSet;};
            void setBasisFunctions(Teuchos::RCP<BasisFunctions> basisfunc){_BF = basisfunc;};
            void Update();
            /** @} */ // end of object creation


            /** @name Information access methods
            *  @{*/
            int bfsTag(int e, int cuba, IndexType idxtype);
            int intPtSize(int e, int cuba, IndexType idxtype);
            double* basisFunctionRef(int e, int cuba, IndexType idxtype, int ipt);

            // std::vector<double>& getRefBFElem(int e, IndexType idxtype);
            // double* getRefDers(int e, int cuba, IndexType idxtype, int ipt, int order);
            // double* getRefNborDers(int e, int cuba, IndexType idxtype, int ipt, int order, int nbor);
            // double* getRefNborDersIdx(int e, int cuba, IndexType idxtype, int ipt, int order, int nbor, int idx);

            // std::vector<double>& getBFElem(int e, IndexType idxtype);
            /** @} */ // end of information access methods


        private:

            //Main variables
            std::vector<std::vector<double>> _bfsInfo;
            std::vector<std::vector<int>> _bfsTags;
            // Teuchos::RCP<Epetra_IntVector> _BFTags;

            //Aux variables
            Teuchos::RCP<AdjcyENStruct> _adjcyEN;
            Teuchos::RCP<CubatureSet> _cubaSet;
            Teuchos::RCP<BasisFunctions> _BF;
            std::vector<std::pair<int, int>> _complexTypes;
            std::vector<int> _iPtSize;  // size of a ipts of type i
            // std::vector<double> _auxVector;

            //Aux functions
            void _setComplexTypes();
            void _setBfsTags();
            void _saveBfsInfo(int type);

    };

}


#endif // BASISFUNCTIONSSET_H
