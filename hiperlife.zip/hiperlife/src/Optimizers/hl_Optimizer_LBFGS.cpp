/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


//
//#include "hl_Optimizer_LBFGS.h"
//
//// The L-BFGS Method is a Q-N (Quasi-Newton) Method.
//// L-BFGS means Limited Memory Broyden-Fletcher-Goldfarb-Shanno
//// The basic idea of BFGS is to approximate the Jacobian Matrix by using a "tangent" matrix.
//// The main characteristics of such approximation are:
////  - The inverse of the Jacobian Matrix is approximated (inverse Q-N equation).
////  - The rank of updating matrix is two (positive definition and symmetry are hereditary)
//// The steps of the L-BFGS algorithm are the following:
//
//namespace hiperlife
//{
//    LBFGSOptimizer::LBFGSOptimizer()
//    {
//        this->LSIZE = 7;
//        this->RESTOL = 1.0e-6;
//        this->SOLTOL = 1.0e-6;
//        this->FUNTOL = 1.0e-6;
//        this->MAXITER = 100;
//        this->nIterShow = 100;
//        this->iter = 0;
//        this->showNewIter = false;
//        this->NShort = 0;
//
//        this->NLong = 0;
//        this->evalFlag = false;
//
//        //OUTPUT
//        this->ierr = 0;
//
//        this->funVal = 0.0;  //main output 1 from this->fun(fillStr)
//    }
//
//
//    void LBFGSOptimizer::Update() {
//        int i;
//
//        if (this->CheckSettings() != 0) {
//            printf("ERROR:xcmLimitedMemory-BFGS settings are wrong !!\n");
//            this->ierr = 1;
//            return;
//        }
//
//        return;
//    }
//
//// the settings are checked to avoid inconsistencies
//    int LBFGSOptimizer::CheckSettings() {
//        int i, j;
//        int nLongi, cumulative;
//
//
//        if (this->LSIZE < 1) {
//            printf("ERROR::The parameter L either is not set or it is not bigger than 1\n");
//            return 1;
//        }
//
//        //if( epsg<0||epsf<0||epsx<0||maxits<0 )
//        if (this->SOLTOL < EPSILON) {
//            printf("ERROR::SOLTOL is to xcmall (%e) you must increase it\n", this->SOLTOL);
//            return 1;
//        }
//        if (this->RESTOL < EPSILON) {
//            printf("ERROR::RESTOL is to xcmall (%e) you must increase it\n", this->RESTOL);
//            return 1;
//        }
//        if (this->FUNTOL < EPSILON) {
//            printf("ERROR::FUNTOL is to xcmall (%e) you must increase it\n", this->FUNTOL);
//            return 1;
//        }
//        if (this->MAXITER < 1) {
//            printf("ERROR::MAXITER is to xcmall (%d) you must increase it\n", this->MAXITER);
//            return 1;
//        }
//
//
//        this->Clear();
//        return 0;
//    }
//
////
//// External call for computing the solution
////
//    bool LBFGSOptimizer::solve( )
//    {
//
//        using Teuchos::RCP;
//        using Teuchos::rcp;
//
//        _loc_nItem = 0;
//        for(int i = 0; i < _hpproblem->loc_nItem(); i++ )
//        {
//            auto chpidx = _hpproblem->getCompHiPerIndex(i);
//            bool  constr = _hpproblem->_dhands[chpidx.dhand]->constrFlag(chpidx.idof,chpidx.index,chpidx.idxType) > 0;
//            bool lconstr = _hpproblem->isDOFLinearlyConstraint(i,IndexType::Local);
//            if ( !constr and !lconstr )
//            {
//                _loc_nItem++;
//            }
//        }
//
//        DistributedSrcData::UpdateDistData();
//
//        _vec_map = Epetra_Map(-1, _hpproblem->loc_nItem(), 0, epComm());
//        _vecShort = rcp(new Epetra_FEVector(_vec_map));
//
//
//        // The short vector is initialized
//        // The long vector is reduced considering the type of tag (idN_const)
//        _vecShort->PutScalar(0.0);
//        for(int i = 0, k = 0; i < _hpproblem->loc_nItem(); i++ )
//        {
//            auto chpidx = _hpproblem->getCompHiPerIndex(i);
//            bool  constr = _hpproblem->_dhands[chpidx.dhand]->constrFlag(chpidx.idof,chpidx.index,chpidx.idxType) > 0;
//            bool lconstr = _hpproblem->isDOFLinearlyConstraint(i,IndexType::Local);
//            if ( !constr and !lconstr )
//            {
//                int glok = k + offs_nItem();
//                double  val = _hpproblem->_dhands[chpidx.dhand]->nodeDOFs->getValue(chpidx.idof,chpidx.index,chpidx.idxType);
//
//                _vecShort->SumIntoGlobalValues(1,&glok,&val);
//
//                k++;
//            }
//        }
//        _vecShort->GlobalAssemble();
//
//        // The LBFGS solver is called
//        this->lbfgsMinimize(_vecShort);
//
//        // The short vector is converted to the the long vector
//        _hpproblem->sol->PutScalar(0.0);
//        for(int i = 0, k = 0; i < _hpproblem->loc_nItem(); i++ )
//        {
//            auto chpidx = _hpproblem->getCompHiPerIndex(i);
//            bool  constr = _hpproblem->_dhands[chpidx.dhand]->constrFlag(chpidx.idof,chpidx.index,chpidx.idxType) > 0;
//            bool lconstr = _hpproblem->isDOFLinearlyConstraint(i,IndexType::Local);
//            if ( !constr and !lconstr )
//            {
//                int glok = k + offs_nItem();
//                double val = (*_vecShort)[0][k];
//
//                _hpproblem->sol->SumIntoGlobalValues(1,&glok,&val);
//
//                k++;
//            }
//        }
//        _vecShort->GlobalAssemble();
//
//        _hpproblem->AddSolutionToDOFs();
//
//        return true; //FIXME return whether it has converged or not
//    }
//
////
//// u: actual position for the new configuration
//// f: value of the energy for the new configuration
//// g: value of the energy gradient in the new configuration
//    void LBFGSOptimizer::funGrad(ap::real_1d_array u, double &fval, ap::real_1d_array &g) {
//        register int i, k, nLongi, cumulative;
//        double *u_short_;
//        double *srhsi;
//
//        // [1] -------------------------------------------------------------------------------
//        // The short vector is converted to the the long vector
//        u_short_ = u.getcontent();
//
//        for (i = 0, k = 0; i < this->NLong; i++) {
//            if (this->idN_const[i] == 0) {
//                this->u_long[i] = u_short_[k];
//                k++;
//            }
//        }
//
//        // [2] -------------------------------------------------------------------------------
//        // Linear constraints are imposed if any through an external function on the 'u-variables'
//        if (this->linCons == true)
//            this->linConsVars(this->mechV[0]);
//
//
//        // [3] -------------------------------------------------------------------------------
//        // Objective function and its gradient is evaluated
//        if (this->evalFlag == true) {
//            for (i = 0; i < this->nMech; i++)
//                this->evalV[i]->Evaluator();
//        }
//
//        //Compute the Energy and its Gradient for the actual configuration (iteration ITER)
//        for (i = 0; i < this->nMech; i++)
//            this->srhsV[i]->RightHandSideFilled();
//
//        // Energy or objective function value
//        this->funVal = 0.0;
//        for (i = 0; i < this->nMech; i++)
//            this->funVal += this->srhsV[i]->GetFunctionValue();
//
//        //gradient of the objective function
//        if (this->nMech == 1) {
//            this->gradLong = this->srhsV[0]->GetRightHandSide();
//        } else {
//            cumulative = 0;
//            for (i = 0; i < this->nMech; i++) {
//                nLongi = this->mechV[i]->GetNodeDegreesOfFreedom() * this->mechV[i]->GetNumberOfNodePoints();
//                srhsi = this->srhsV[i]->GetRightHandSide();
//                for (k = 0; k < nLongi; k++)
//                    this->gradLong[cumulative + k] = srhsi[k];
//                cumulative += nLongi;
//            }
//        }
//
//        // [4] -------------------------------------------------------------------------------
//        // Linear constraints if any are imposed on the long gradient
//        if (this->linCons == true)
//            this->linConsGrad(this->srhsV[0]);
//
//        // [5] -------------------------------------------------------------------------------
//        // The long gradient vector is reduced to the short one considering the type of tag (idN_const)
//        for (i = 0, k = 0; i < this->NLong; i++) {
//            //free variable checking
//            if (this->idN_const[i] == 0) {
//                this->gradShort[k] = this->gradLong[i];
//                k++;
//            }
//        }
//
//        //pass info to the L-BFGS minimizer routines
//        fval = this->funVal;
//        g.setcontent(1, this->NShort, this->gradShort);
//        return;
//    }
//
//
///*************************************************************************
//        LIMITED MEMORY BFGS METHOD FOR LARGE SCALE OPTIMIZATION
//                        JORGE NOCEDAL
//
//C     This subroutine solves the unconstrained minimization problem
//C
//C                      min F(x),    x= (x1,x2,...,xN),
//C
//C      using the limited memory BFGS method. The routine is especially
//C      effective on problems involving a large number of variables. In
//C      a typical iteration of this method an approximation Hk to the
//C      inverse of the Hessian is obtained by applying M BFGS updates to
//C      a diagonal matrix Hk0, using information from the previous M steps.
//C      The user specifies the number M, which determines the amount of
//C      storage required by the routine. The user may also provide the
//C      diagonal matrices Hk0 if not satisfied with the default choice.
//C      The algorithm is described in "On the limited memory BFGS method
//C      for large scale optimization", by D. Liu and J. Nocedal,
//C      Mathematical Programming B 45 (1989) 503-528.
//C
//C      The user is required to calculate the function value F and its
//C      gradient G. In order to allow the user complete control over
//C      these computations, reverse  communication is used. The routine
//C      must be called repeatedly under the control of the parameter
//C      IFLAG.
//C
//C      The steplength is determined at each iteration by means of the
//C      line search routine MCVSRCH, which is a slight modification of
//C      the routine CSRCH written by More' and Thuente.
//
//The subroutine minimizes function F(x) of N arguments by  using  a  quasi-
//Newton method (LBFGS scheme) which is optimized to use  a  minimum  amount
//of memory.
//
//The subroutine generates the approximation of an inverse Hessian matrix by
//using information about the last M steps of the algorithm  (instead of N).
//It lessens a required amount of memory from a value  of  order  N^2  to  a
//value of order 2*N*L.
//
//This subroutine uses the FuncGrad subroutine which calculates the value of
//the function F and gradient G in point X. The programmer should define the
//FuncGrad subroutine by himself.  It  should  be  noted that the subroutine
//doesn't need to waste time for memory allocation of array G,  because  the
//memory is allocated in calling the subroutine. Setting a dimension of array
//G  each  time  when  calling  a  subroutine  will excessively slow down an
//algorithm.
//
//The programmer could also redefine the LBFGSNewIteration subroutine  which
//is called on each new step. The current point X, the function value F  and
//the  gradient  G  are  passed  into  this  subroutine. It is reasonable to
//redefine the subroutine for better debugging, for  example,  to  visualize
//the solution process.
//
//Input parameters:
//    N   -   problem dimension. N>0
//    L   -   number of corrections in the BFGS scheme of Hessian
//            approximation update. Recommended value:  3<=L<=7. The xcmaller
//            value causes worse convergence, the bigger will  not  cause  a
//            considerably better convergence, but will cause a fall in  the
//            performance. L<=N.
//    X   -   initial solution approximation.
//            Array whose index ranges from 1 to N.
//    EpsG -  positive number which  defines  a  precision  of  search.  The
//            subroutine finishes its work if the condition ||G|| < EpsG  is
//            satisfied, where ||.|| means Euclidian norm, G - gradient, X -
//            current approximation.
//    EpsF -  positive number which  defines  a  precision  of  search.  The
//            subroutine finishes its work if on iteration  number  k+1  the
//            condition |F(k+1)-F(k)| <= EpsF*max{|F(k)|, |F(k+1)|, 1}    is
//            satisfied.
//    EpsX -  positive number which  defines  a  precision  of  search.  The
//            subroutine finishes its work if on iteration number k+1    the
//            condition |X(k+1)-X(k)| <= EpsX is fulfilled.
//    MaxIts- maximum number of iterations. If MaxIts=0, the number of
//            iterations is unlimited.
//
//Output parameters:
//    X   -   solution approximation. Array whose index ranges from 1 to N.
//    Info-   a return code:
//                    * -1 wrong parameters were specified,
//                    * 0 interrupted by user,
//                    * 1 relative function decreasing is less or equal to EpsF,
//                    * 2 step is less or equal EpsX,
//                    * 4 gradient norm is less or equal to EpsG,
//                    * 5 number of iterations exceeds MaxIts.
//
//FuncGrad routine description. User-defined.
//Input parameters:
//    X   -   array whose index ranges from 1 to N.
//
//Output parameters:
//    F   -   function value at X.
//    G   -   function gradient.
//            Array whose index ranges from 1 to N.
//The memory for array G has already been allocated in the calling subroutine,
//and it isn't necessary to allocate it in the FuncGrad subroutine.
//
//Copyright (c) 1980-2007, Jorge Nocedal.
//
//Contributors:
//    * Sergey Bochkanov (ALGLIB project). Translation from FORTRAN to
//    pseudocode.
//
//This software is freely available for educational or commercial  purposes.
//We expect that all publications describing work using this software  quote
//at least one of the references given below:
//    * J. Nocedal. Updating  Quasi-Newton  Matrices  with  Limited  Storage
//    (1980), Mathematics of Computation 35, pp. 773-782.
//    * D.C. Liu and J. Nocedal. On the  Limited  Memory  Method  for  Large
//    Scale  Optimization  (1989),  Mathematical  Programming  B,  45,  3,
//    pp. 503-528.
//
//*************************************************************************/
//    void LBFGSOptimizer::lbfgsMinimize(Teuchos::RCP<Epetra_FEVector> x) {
//
//        using Teuchos::RCP;
//        using Teuchos::rcp;
//
//
//        RCP<Epetra_FEVector> w;
//        RCP<Epetra_FEVector> x0;
//        RCP<Epetra_FEVector> tx;
//        RCP<Epetra_FEVector> g;
//        RCP<Epetra_FEVector> diag;
//        RCP<Epetra_FEVector> ta;
//
//        int jerr = 0;    //local error identification variable
//        int iend = 0;    //termination loop variable
//
//        int nfun, point, ispt, iypt;
//        int maxfev, bound, npt, cp, i;
//        int nfev, inmc, iycn, iscn;
//
//        double f, f0, tf, v, gnorm;
//        double ftol, xtol, gtol;
//        double ys, yy, sq, yr, beta;
//        double stp1, stp, stpmin, stpmax;
//
//        // W     is a DOUBLE PRECISION array of length N(2M+1)+2M used as
//        //       workspace for LBFGS. This array must not be altered by the
//        //       user.
//        Epetra_Map vec_map_w(-1, _hpproblem->loc_nItem() * (2 * LSIZE + 1) + 2 * LSIZE, 0, epComm());
//        w = rcp(new Epetra_FEVector(vec_map_w));
//
//        //  G    is a DOUBLE PRECISION array of length N. Before initial
//        //       entry and on a re-entry with IFLAG=1, it must be set by
//        //       the user to contain the components of the gradient G at
//        //       the point X.
//        Epetra_Map vec_map(-1, _hpproblem->loc_nItem(), 0, epComm());
//        g = rcp(new Epetra_FEVector(vec_map));
//        x0 = rcp(new Epetra_FEVector(vec_map));
//        tx = rcp(new Epetra_FEVector(vec_map));
//        //  DIAG    is a DOUBLE PRECISION array of length N.
//        //          then on initial entry or on re-entry with IFLAG=2, DIAG
//        //          it must be set by the user to contain the values of the
//        //          diagonal matrix Hk0.
//        //  Restriction: all elements of DIAG  must be positive.
//        diag = rcp(new Epetra_FEVector(vec_map));
//        ta = rcp(new Epetra_FEVector(vec_map));
//
////        _funGrad(x, f, g);
//
//        f0 = f;
//        npt = 0;
//        ierr = 0;
//        nfun = 1;
//        point = 0;
//        iter = 0;
//
//
//        diag->PutScalar(1.0);
//
//        xtol = 100.0 * EPSILON;
//
//        //Wolfe conditions, see http://en.wikipedia.org/wiki/Wolfe_conditions
//        //(1) Armijo rule, it ensures that the step length k-th decreases f 'sufficiently'
//        ftol = 1.e-04;  //Nocedal gives c1 = 1.e-4
//        //(2) Curvature condition, it ensures that the slope has been reduced sufficiently
//        // GTOL is a DOUBLE PRECISION variable with default value 0.9, which
//        //  controls the accuracy of the line search routine MCSRCH. If the
//        //  function and gradient evaluations are inexpensive with respect
//        //  to the cost of the iteration (which is sometimes the case when
//        //  solving very large problems) it may be advantageous to set GTOL
//        //  to a xcmall value. A typical xcmall value is 0.1.
//        // Restriction:  GTOL should be greater than 1e-04.
//        gtol = 0.01;    //Nocedal gives c2 = 0.9
//
//        // STPMIN and STPMAX are non-negative DOUBLE PRECISION variables which
//        //  specify lower and uper bounds for the step in the line search.
//        //  Their default values are 1.D-20 and 1.D+20, respectively. These
//        //  values need not be modified unless the exponents are too large
//        //  for the machine being used, or unless the problem is extremely
//        //  badly scaled (in which case the exponents should be increased).
//        stpmin = EPSILON;     //pow(10.0,-20.0);
//        stpmax = INFINITY;    //pow(10.0, 20.0);  //that seems to be the minimum/maximum of the ALPHA's value
//
//        //  THE WORK VECTOR W IS DIVIDED AS FOLLOWS:
//        //  ---------------------------------------
//        //  THE FIRST N LOCATIONS ARE USED TO STORE THE GRADIENT AND OTHER TEMPORARY INFORMATION.
//        //  LOCATIONS (N+1)...(N+L) STORE THE SCALARS RHO.
//        //  LOCATIONS (N+L+1)...(N+2L) STORE THE NUMBERS ALPHA USED IN THE FORMULA THAT COMPUTES H*G.
//        //  LOCATIONS (N+2L+1)...(N+2L+NL) STORE THE LAST M SEARCH STEPS.
//        //  LOCATIONS (N+2L+NL+1)...(N+2L+2NL) STORE THE LAST 'L' GRADIENT DIFFERENCES.
//        //
//        //  THE SEARCH STEPS AND GRADIENT DIFFERENCES ARE STORED IN A
//        //  CIRCULAR ORDER CONTROLLED BY THE PARAMETER POINT.
//        ispt = _loc_nItem + 2 * this->LSIZE; // L = 'L'-BFGS
//        iypt = ispt + _loc_nItem * this->LSIZE;
//
//        w->PutScalar(0.0);
//        for (i = 1; i <= _loc_nItem; i++)
//        {
//            int idx = ispt + i;
//            double val = -(*g)[0][i] * (*diag)[0][i];
//            w->SumIntoGlobalValues(1,&idx,&val);
//        }
//        w->GlobalAssemble();
//
//        g->Norm2(&gnorm);
//        stp1 = 1.0 / gnorm;
//        maxfev = 20;
//
//        while (iend == 0) {
//            jerr = 0;
//
//            // L-BFGS Algorithm --------------------------------------------------------------
////            ap::vmove(x0.getvector(1, this->NShort), x.getvector(1, this->NShort));
//            (*x) = (*x0);
//
//            this->iter = this->iter + 1;
//            bound = this->iter - 1;
//            if (this->iter != 1)
//            {
//                if (this->iter > this->LSIZE)
//                {
//                    bound = this->LSIZE;
//                }
//                ys =
//                ys = this->dot(this->NShort, w, iypt + npt + 1, w, ispt + npt + 1);
//                yy = this->dot(this->NShort, w, iypt + npt + 1, w, iypt + npt + 1);
//                for (i = 1; i <= this->NShort; i++)
//                {
//                    diag(i) = ys / yy;
//                }
//
//                //  COMPUTE -H*G USING THE FORMULA GIVEN IN: Nocedal, J. 1980,
//                //  "Updating quasi-Newton matrices with limited storage",
//                //  Mathematics of Computation, Vol.24, No.151, pp. 773-782.
//                cp = point;
//                if (point == 0) {
//                    cp = this->LSIZE;
//                }
//                w(this->NShort + cp) = 1 / ys;
//                for (i = 1; i <= this->NShort; i++) {
//                    w(i) = -g(i);
//                }
//                cp = point;
//                for (i = 1; i <= bound; i++) {
//                    cp = cp - 1;
//                    if (cp == -1) {
//                        cp = this->LSIZE - 1;
//                    }
//                    sq = this->dot(this->NShort, w, ispt + cp * this->NShort + 1, w, 1);
//                    inmc = this->NShort + this->LSIZE + cp + 1;
//                    iycn = iypt + cp * this->NShort;
//                    w(inmc) = w(this->NShort + cp + 1) * sq;
//                    this->axpy(this->NShort, -w(inmc), w, iycn + 1, w, 1);
//                }
//                for (i = 1; i <= this->NShort; i++) {
//                    w(i) = diag(i) * w(i);
//                }
//                for (i = 1; i <= bound; i++) {
//                    yr = this->dot(this->NShort, w, iypt + cp * this->NShort + 1, w, 1);
//                    beta = w(this->NShort + cp + 1) * yr;
//                    inmc = this->NShort + this->LSIZE + cp + 1;
//                    beta = w(inmc) - beta;
//                    iscn = ispt + cp * this->NShort;
//                    this->axpy(this->NShort, beta, w, iscn + 1, w, 1);
//                    cp = cp + 1;
//                    if (cp == this->LSIZE) {
//                        cp = 0;
//                    }
//                }
//
//                // STORE THE NEW SEARCH DIRECTION
//                for (i = 1; i <= this->NShort; i++) {
//                    w(ispt + point * this->NShort + i) = w(i);
//                }
//            }
//
//            //  OBTAIN THE ONE-DIMENSIONAL MINIMIZER OF THE FUNCTION
//            //  BY USING THE LINE SEARCH ROUTINE MCSRCH
//            nfev = 0;
//            stp = 1;
//            if (this->iter == 1) {
//                stp = stp1;
//            }
//            for (i = 1; i <= this->NShort; i++) {
//                w(i) = g(i);
//            }
//            this->mcsrch(this->NShort, x, f, g, w, ispt + point * this->NShort + 1, stp,
//                         ftol, xtol, maxfev, jerr, nfev, diag, gtol, stpmin, stpmax);
//            if (jerr == 0) {
//                printf("ERROR::L-BFGS:mcsrch line search algorithm fails\n");
//                this->ierr = -1;
//                iend = 1;
//            } else {
//                jerr = 0;
//                nfun = nfun + nfev;
//
//                // COMPUTE THE NEW STEP AND GRADIENT CHANGE
//                npt = point * this->NShort;
//                for (i = 1; i <= this->NShort; i++) {
//                    w(ispt + npt + i) = stp * w(ispt + npt + i);
//                    w(iypt + npt + i) = g(i) - w(i);
//                }
//                point = point + 1;
//                if (point == this->LSIZE) {
//                    point = 0;
//                }
//
//                // ERRORS and CONVERGENCE VERIFICATION ------------------------------------------
//
//                // number of iterations
//                if (this->iter >= this->MAXITER) {
//                    //printf("ERROR::LBFGS fails maximum number of iterations reached ITER=%d\n", this->iter);
//                    jerr = 5;
//                }
//
//                //solution: tx = x0-x
//                ap::vmove(tx.getvector(1, this->NShort), x0.getvector(1, this->NShort));
//                ap::vsub(tx.getvector(1, this->NShort), x.getvector(1, this->NShort));
//                v = sqrt(this->dot(this->NShort, tx, 1, tx, 1)); //|x0-x|
//                v = v / MAX(1.0, sqrt(this->dot(this->NShort, x0, 1, x0, 1)));
//                if (jerr == 0 && (std::isnan(v) == 1 || std::isinf(v) == 1)) //solution
//                {
//                    printf("ERROR::LBFGS fails |x_old-x|/|x_old|=%f\n", v);
//
//                    printf("\t tx . tx = %f\n", this->dot(this->NShort, tx, 1, tx, 1));
//                    printf("\t x0 . x0 = %f\n", this->dot(this->NShort, x0, 1, x0, 1));
//                    printf("\t  x . x  = %f\n", this->dot(this->NShort, x, 1, x, 1));
//                    jerr = 6;
//                }
//
//                //function gradient (residue)
//                gnorm = xcmMath::Norm(this->NShort, this->gradShort);
//                gnorm = gnorm / MAX(1.0, xcmMath::Norm(this->NLong, this->gradLong));
//                if (jerr == 0 && (std::isnan(gnorm) == 1 || std::isinf(gnorm) == 1)) //gradient norm
//                {
//                    printf("ERROR::LBFGS fails |grad_S|/|grad_L|   =%f\n", gnorm);
//                    jerr = 7;
//                }
//
//                //function value
//                tf = MAX(ABS(f0), MAX(ABS(f), 1.0));
//                if (jerr == 0 && (std::isnan(f0 - f) == 1 || std::isinf(f0 - f) == 1)) //function value
//                {
//                    printf("ERROR::LBFGS fails (f0-f)=%f\n", f0 - f);
//                    jerr = 8;
//                }
//
//                //convergence criteria is verified: solution, gradient norm value and function
//                if (jerr == 0 && v <= this->SOLTOL && gnorm <= this->RESTOL && ABS(f0 - f) <= this->FUNTOL * tf) {
//                    //copy x to u_short, and g to gradShort
//                    int ii;
//                    double *x_aux = x.getcontent();
//                    double *g_aux = g.getcontent();
//                    for (ii = 0; ii < this->NShort; ii++) {
//                        this->u_short[ii] = x_aux[ii];
//                        this->gradShort[ii] = g_aux[ii];
//                    }
//                    jerr = 3;
//                }
//
//                //If convergence is reached exit loop
//                if (jerr > 0) {
//                    if (this->showNewIter == true)
//                        printf("### Iter=%4d   |dx|=%16.8e   (f-f0)=%16.8e    |grad|=%12.4e\n",
//                               this->iter, v, (f0 - f) / tf, gnorm);
//                    iend = 1;
//                    this->errSOL = v;
//                    this->errFUN = (f0 - f) / tf;
//                    this->errRES = gnorm;
//
//                    if (jerr == 3)
//                        this->ierr = 0;
//                    else
//                        this->ierr = jerr;
//                } else {
//
//                    if (this->showNewIter == true) {
//                        if (this->iter % this->nIterShow == 0) {
//                            printf("Old energy=%10.4e   New energy=%10.4e   Gradient=[S:%10.4e  L:%10.4e]\n",
//                                   f0, f, xcmMath::Norm(this->NShort, this->gradShort),
//                                   xcmMath::Norm(this->NLong, this->gradLong));
//                        }
//
//                        this->ShowNewIteration(v, (f0 - f) / tf, gnorm);
//                    }
//
//                    f0 = f;
//                    ap::vmove(x0.getvector(1, this->NShort), x.getvector(1, this->NShort));
//                }
//            }//end IF jerr==-1
//        }//end WHILE
//        return;
//    }
//
//
//    void LBFGSOptimizer::axpy(const int &n, const double &da,
//                                    const ap::real_1d_array &dx, int sx,
//                                    ap::real_1d_array &dy, int sy) {
//        ap::vadd(dy.getvector(sy, sy + n - 1), dx.getvector(sx, sx + n - 1), da);
//    }
//
//
//    double LBFGSOptimizer::dot(const int &n,
//                                     const ap::real_1d_array &dx, int sx,
//                                     const ap::real_1d_array &dy, int sy) {
//        return ap::vdotproduct(dx.getvector(sx, sx + n - 1), dy.getvector(sy, sy + n - 1));
//    }
//
//
///*************************************************************************
////              SUBROUTINE MCSRCH
////
////    A slight modification of the subroutine CSRCH of More' and Thuente.
////    The changes are to allow reverse communication, and do not affect
////    the performance of the routine.
////
////    THE PURPOSE OF MCSRCH IS TO FIND A STEP WHICH SATISFIES
////    A SUFFICIENT DECREASE CONDITION AND A CURVATURE CONDITION.
////
////    AT EACH STAGE THE SUBROUTINE UPDATES AN INTERVAL OF
////    UNCERTAINTY WITH ENDPOINTS STX AND STY. THE INTERVAL OF
////    UNCERTAINTY IS INITIALLY CHOSEN SO THAT IT CONTAINS A
////    MINIMIZER OF THE MODIFIED FUNCTION
////
////   F(X+STP*S) - F(X) - FTOL*STP*(GRADF(X)'S).
////
////    IF A STEP IS OBTAINED FOR WHICH THE MODIFIED FUNCTION
////    HAS A NONPOSITIVE FUNCTION VALUE AND NONNEGATIVE DERIVATIVE,
////    THEN THE INTERVAL OF UNCERTAINTY IS CHOSEN SO THAT IT
////    CONTAINS A MINIMIZER OF F(X+STP*S).
////
////    THE ALGORITHM IS DESIGNED TO FIND A STEP WHICH SATISFIES
////    THE SUFFICIENT DECREASE CONDITION
////
////    F(X+STP*S) .LE. F(X) + FTOL*STP*(GRADF(X)'S),
////
////    AND THE CURVATURE CONDITION
////
////    ABS(GRADF(X+STP*S)'S)) .LE. GTOL*ABS(GRADF(X)'S).
////
////    IF FTOL IS LESS THAN GTOL AND IF, FOR EXAMPLE, THE FUNCTION
////    IS BOUNDED BELOW, THEN THERE IS ALWAYS A STEP WHICH SATISFIES
////    BOTH CONDITIONS. IF NO STEP CAN BE FOUND WHICH SATISFIES BOTH
////    CONDITIONS, THEN THE ALGORITHM USUALLY STOPS WHEN ROUNDING
////    ERRORS PREVENT FURTHER PROGRESS. IN THIS CASE STP ONLY
////    SATISFIES THE SUFFICIENT DECREASE CONDITION.
////
////    THE SUBROUTINE STATEMENT IS
////
////       SUBROUTINE MCSRCH(N,X,F,G,S,STP,FTOL,XTOL, MAXFEV,INFO,NFEV,WA)
////    WHERE
////
////      N IS A POSITIVE INTEGER INPUT VARIABLE SET TO THE NUMBER
////  OF VARIABLES.
////
////      X IS AN ARRAY OF LENGTH N. ON INPUT IT MUST CONTAIN THE
////  BASE POINT FOR THE LINE SEARCH. ON OUTPUT IT CONTAINS
////  X + STP*S.
////
////      F IS A VARIABLE. ON INPUT IT MUST CONTAIN THE VALUE OF F
////  AT X. ON OUTPUT IT CONTAINS THE VALUE OF F AT X + STP*S.
////
////      G IS AN ARRAY OF LENGTH N. ON INPUT IT MUST CONTAIN THE
////  GRADIENT OF F AT X. ON OUTPUT IT CONTAINS THE GRADIENT
////  OF F AT X + STP*S.
////
////      S IS AN INPUT ARRAY OF LENGTH N WHICH SPECIFIES THE
////  SEARCH DIRECTION.
////
////      STP IS A NONNEGATIVE VARIABLE. ON INPUT STP CONTAINS AN
////  INITIAL ESTIMATE OF A SATISFACTORY STEP. ON OUTPUT
////  STP CONTAINS THE FINAL ESTIMATE.
////
////      FTOL AND GTOL ARE NONNEGATIVE INPUT VARIABLES. (In this reverse
////  communication implementation GTOL is defined in a COMMON
////  statement.) TERMINATION OCCURS WHEN THE SUFFICIENT DECREASE
////  CONDITION AND THE DIRECTIONAL DERIVATIVE CONDITION ARE
////  SATISFIED.
////
////      XTOL IS A NONNEGATIVE INPUT VARIABLE. TERMINATION OCCURS
////  WHEN THE RELATIVE WIDTH OF THE INTERVAL OF UNCERTAINTY
////  IS AT MOST XTOL.
////
////      STPMIN AND STPMAX ARE NONNEGATIVE INPUT VARIABLES WHICH
////  SPECIFY LOWER AND UPPER BOUNDS FOR THE STEP. (In this reverse
////  communication implementatin they are defined in a COMMON
////  statement).
////
////      MAXFEV IS A POSITIVE INTEGER INPUT VARIABLE. TERMINATION
////  OCCURS WHEN THE NUMBER OF CALLS TO FCN IS AT LEAST
////  MAXFEV BY THE END OF AN ITERATION.
////
////      INFO IS AN INTEGER OUTPUT VARIABLE SET AS FOLLOWS:
////
////  INFO = 0  IMPROPER INPUT PARAMETERS.
////
////  INFO =-1  A RETURN IS MADE TO COMPUTE THE FUNCTION AND GRADIENT.
////
////  INFO = 1  THE SUFFICIENT DECREASE CONDITION AND THE
////            DIRECTIONAL DERIVATIVE CONDITION HOLD.
////
////  INFO = 2  RELATIVE WIDTH OF THE INTERVAL OF UNCERTAINTY
////            IS AT MOST XTOL.
////
////  INFO = 3  NUMBER OF CALLS TO FCN HAS REACHED MAXFEV.
////
////  INFO = 4  THE STEP IS AT THE LOWER BOUND STPMIN.
////
////  INFO = 5  THE STEP IS AT THE UPPER BOUND STPMAX.
////
////  INFO = 6  ROUNDING ERRORS PREVENT FURTHER PROGRESS.
////            THERE MAY NOT BE A STEP WHICH SATISFIES THE
////            SUFFICIENT DECREASE AND CURVATURE CONDITIONS.
////            TOLERANCES MAY BE TOO SMALL.
////
////      NFEV IS AN INTEGER OUTPUT VARIABLE SET TO THE NUMBER OF
////  CALLS TO FCN.
////
////      WA IS A WORK ARRAY OF LENGTH N.
////
////    SUBPROGRAMS CALLED
////
////      MCSTEP
////
////      FORTRAN-SUPPLIED...ABS,MAX,MIN
////
////    ARGONNE NATIONAL LABORATORY. MINPACK PROJECT. JUNE 1983
////    JORGE J. MORE', DAVID J. THUENTE
//*************************************************************************/
//    void LBFGSOptimizer::mcsrch(const int &n,
//                                      ap::real_1d_array &x,
//                                      double &f,
//                                      ap::real_1d_array &g,
//                                      const ap::real_1d_array &s,
//                                      int sstart,
//                                      double &stp,
//                                      const double &ftol,
//                                      const double &xtol,
//                                      const int &maxfev,
//                                      int &info,
//                                      int &nfev,
//                                      ap::real_1d_array &wa,
//                                      const double &gtol,
//                                      const double &stpmin,
//                                      const double &stpmax) {
//        int iend = 0;
//        int infoc, j;
//        bool brackt, stage1;
//        double dg, dgm, dginit, dgtest, dgx, dgxm, dgy, dgym;
//        double finit, ftest1, fm, fx, fxm, fy, fym;
//        double p5, p66;
//        double stx, sty, stmin, stmax;
//        double width, width1;
//        double xtrapf;
//        double zero;
//        double mytemp;
//
//        sstart = sstart - 1;
//        p5 = 0.5;
//        p66 = 0.66;
//        xtrapf = 4.0;
//        zero = 0.0;
//
//        infoc = 1;
//        info = 0;
//
//        //     CHECK THE INPUT PARAMETERS FOR ERRORS.
//        if (n <= 0 || stp <= 0 || ftol < 0 || gtol < zero || xtol < zero || stpmin < zero || stpmax < stpmin ||
//            maxfev <= 0) {
//            printf("ERROR::L-BFGS:LINE SEARCH -  Bad input parameters 1\n");
//            return;
//        }
//
//        //     COMPUTE THE INITIAL GRADIENT IN THE SEARCH DIRECTION
//        //     AND CHECK THAT S IS A DESCENT DIRECTION.
//        this->funGrad(x, f, g);
//        dginit = 0.0;
//        for (j = 1; j <= n; j++) {
//            dginit += g(j) * s(j + sstart);
//        }
//        if (dginit >= 0.0) {
//            printf("ERROR::L-BFGS:LINE SEARCH -  THE SEARCH DIRECTION IS NOT A DESCENT DIRECTION d.g0=%12.4e\n",
//                   dginit);
//            return;
//        }
//
//        //     INITIALIZE LOCAL VARIABLES.
//        brackt = false;
//        stage1 = true;
//        nfev = 0;
//        finit = f;
//        dgtest = ftol * dginit;
//        width = stpmax - stpmin;
//        width1 = width / p5;
//        for (j = 1; j <= n; j++) {
//            wa(j) = x(j);
//        }
//
//        //    THE VARIABLES STX, FX, DGX CONTAIN THE VALUES OF THE STEP,
//        //    FUNCTION, AND DIRECTIONAL DERIVATIVE AT THE BEST STEP.
//        //    THE VARIABLES STY, FY, DGY CONTAIN THE VALUE OF THE STEP,
//        //    FUNCTION, AND DERIVATIVE AT THE OTHER ENDPOINT OF
//        //    THE INTERVAL OF UNCERTAINTY.
//        //    THE VARIABLES STP, F, DG CONTAIN THE VALUES OF THE STEP,
//        //    FUNCTION, AND DERIVATIVE AT THE CURRENT STEP.
//        stx = 0;
//        fx = finit;
//        dgx = dginit;
//        sty = 0;
//        fy = finit;
//        dgy = dginit;
//
//        //     START OF ITERATION.
//        while (iend == 0) {
//            //  SET THE MINIMUM AND MAXIMUM STEPS TO CORRESPOND
//            //  TO THE PRESENT INTERVAL OF UNCERTAINTY.
//            if (brackt) {
//                if (stx < sty) {
//                    stmin = stx;
//                    stmax = sty;
//                } else {
//                    stmin = sty;
//                    stmax = stx;
//                }
//            } else {
//                stmin = stx;
//                stmax = stp + xtrapf * (stp - stx);
//            }
//
//            //  FORCE THE STEP TO BE WITHIN THE BOUNDS STPMAX AND STPMIN.
//            if (stp > stpmax) {
//                stp = stpmax;
//            }
//            if (stp < stpmin) {
//                stp = stpmin;
//            }
//
//            //  IF AN UNUSUAL TERMINATION IS TO OCCUR THEN LET
//            //  STP BE THE LOWEST POINT OBTAINED SO FAR.
//            if (((((brackt && (stp <= stmin || stp >= stmax)) || nfev >= (maxfev - 1))
//                  || infoc == 0) || brackt) && ((stmax - stmin) <= xtol * stmax)) {
//                stp = stx;
//            }
//
//            //  EVALUATE THE FUNCTION AND GRADIENT AT STP
//            //  AND COMPUTE THE DIRECTIONAL DERIVATIVE.
//            //  We return to main program to obtain F and G.
//            for (j = 1; j <= n; j++) {
//                x(j) = wa(j) + stp * s(j + sstart);
//            }
//            this->funGrad(x, f, g);
//            info = 0;
//            nfev = nfev + 1;
//            dg = 0;
//            for (j = 1; j <= n; j++) {
//                dg = dg + g(j) * s(j + sstart);
//            }
//            ftest1 = finit + stp * dgtest;
//
//            //  TEST FOR CONVERGENCE.
//            if ((brackt && (stp <= stmin || stp >= stmax)) || infoc == 0) {
//                //ROUNDING ERRORS PREVENT FURTHER PROGRESS.
//                //THERE MAY NOT BE A STEP WHICH SATISFIES THE
//                //SUFFICIENT DECREASE AND CURVATURE CONDITIONS.
//                //TOLERANCES MAY BE TOO SMALL.
//                info = 6;
//            }
//            if (stp == stpmax && f <= ftest1 && dg <= dgtest) {
//                //THE STEP IS AT THE UPPER BOUND STPMAX.
//                info = 5;
//            }
//            if (stp == stpmin && (f > ftest1 || dg >= dgtest)) {
//                //THE STEP IS AT THE LOWER BOUND STPMIN.
//                info = 4;
//            }
//            if (nfev >= maxfev) {
//                //NUMBER OF CALLS TO FCN HAS REACHED MAXFEV.
//                info = 3;
//            }
//            if (brackt && (stmax - stmin) <= xtol * stmax) {
//                //RELATIVE WIDTH OF THE INTERVAL OF UNCERTAINTY IS AT MOST XTOL.
//                info = 2;
//            }
//            if (f <= ftest1 && ABS(dg) <= -gtol * dginit) {
//                //THE SUFFICIENT DECREASE CONDITION AND THE DIRECTIONAL DERIVATIVE CONDITION HOLD.
//                info = 1;
//            }
//
//            //  CHECK FOR TERMINATION.
//            if (info != 0) {
//                iend = 1;
//            } else {
//                //  IN THE FIRST STAGE WE SEEK A STEP FOR WHICH THE MODIFIED
//                //  FUNCTION HAS A NONPOSITIVE VALUE AND NONNEGATIVE DERIVATIVE.
//                mytemp = ftol;
//                if (gtol < ftol) {
//                    mytemp = gtol;
//                }
//                if (stage1 && f <= ftest1 && dg >= mytemp * dginit) {
//                    stage1 = false;
//                }
//
//
//                if (stage1 && f <= fx && f > ftest1) {
//                    //  DEFINE THE MODIFIED FUNCTION AND DERIVATIVE VALUES.
//                    fm = f - stp * dgtest;
//                    fxm = fx - stx * dgtest;
//                    fym = fy - sty * dgtest;
//                    dgm = dg - dgtest;
//                    dgxm = dgx - dgtest;
//                    dgym = dgy - dgtest;
//
//                    //  CALL CSTEP TO UPDATE THE INTERVAL OF UNCERTAINTY
//                    //  AND TO COMPUTE THE NEW STEP.
//                    this->mcstep(stx, fxm, dgxm, sty, fym, dgym, stp, fm, dgm, brackt, stmin, stmax, infoc);
//
//                    //  RESET THE FUNCTION AND GRADIENT VALUES FOR F.
//                    fx = fxm + stx * dgtest;
//                    fy = fym + sty * dgtest;
//                    dgx = dgxm + dgtest;
//                    dgy = dgym + dgtest;
//                } else {
//                    //  CALL MCSTEP TO UPDATE THE INTERVAL OF UNCERTAINTY
//                    //  AND TO COMPUTE THE NEW STEP.
//                    this->mcstep(stx, fx, dgx, sty, fy, dgy, stp, f, dg, brackt, stmin, stmax, infoc);
//                }
//
//                //  FORCE A SUFFICIENT DECREASE IN THE SIZE OF THE
//                //  INTERVAL OF UNCERTAINTY.
//                if (brackt) {
//                    if (ABS(sty - stx) >= p66 * width1) {
//                        stp = stx + p5 * (sty - stx);
//                    }
//                    width1 = width;
//                    width = ABS(sty - stx);
//                }
//            }//end if info!=0
//        }//end while
//
//    }//END OF SUBROUTINE MCSRCH.
//
///*************************************************************************
////
////               SUBROUTINE MCSTEP
////
////THE PURPOSE OF MCSTEP IS TO COMPUTE A SAFEGUARDED STEP FOR
////A LINESEARCH AND TO UPDATE AN INTERVAL OF UNCERTAINTY FOR
////A MINIMIZER OF THE FUNCTION.
////
////THE PARAMETER STX CONTAINS THE STEP WITH THE LEAST FUNCTION
////VALUE. THE PARAMETER STP CONTAINS THE CURRENT STEP. IT IS
////ASSUMED THAT THE DERIVATIVE AT STX IS NEGATIVE IN THE
////DIRECTION OF THE STEP. IF BRACKT IS SET TRUE THEN A
////MINIMIZER HAS BEEN BRACKETED IN AN INTERVAL OF UNCERTAINTY
////WITH ENDPOINTS STX AND STY.
////
////THE SUBROUTINE STATEMENT IS
////
////  SUBROUTINE MCSTEP(STX,FX,DX,STY,FY,DY,STP,FP,DP,BRACKT,
////             STPMIN,STPMAX,INFO)
////
////WHERE
////
////  STX, FX, AND DX ARE VARIABLES WHICH SPECIFY THE STEP,
////    THE FUNCTION, AND THE DERIVATIVE AT THE BEST STEP OBTAINED
////    SO FAR. THE DERIVATIVE MUST BE NEGATIVE IN THE DIRECTION
////    OF THE STEP, THAT IS, DX AND STP-STX MUST HAVE OPPOSITE
////    SIGNS. ON OUTPUT THESE PARAMETERS ARE UPDATED APPROPRIATELY.
////
////  STY, FY, AND DY ARE VARIABLES WHICH SPECIFY THE STEP,
////    THE FUNCTION, AND THE DERIVATIVE AT THE OTHER ENDPOINT OF
////    THE INTERVAL OF UNCERTAINTY. ON OUTPUT THESE PARAMETERS ARE
////    UPDATED APPROPRIATELY.
////
////  STP, FP, AND DP ARE VARIABLES WHICH SPECIFY THE STEP,
////    THE FUNCTION, AND THE DERIVATIVE AT THE CURRENT STEP.
////    IF BRACKT IS SET TRUE THEN ON INPUT STP MUST BE
////    BETWEEN STX AND STY. ON OUTPUT STP IS SET TO THE NEW STEP.
////
////  BRACKT IS A LOGICAL VARIABLE WHICH SPECIFIES IF A MINIMIZER
////    HAS BEEN BRACKETED. IF THE MINIMIZER HAS NOT BEEN BRACKETED
////    THEN ON INPUT BRACKT MUST BE SET FALSE. IF THE MINIMIZER
////    IS BRACKETED THEN ON OUTPUT BRACKT IS SET TRUE.
////
////  STPMIN AND STPMAX ARE INPUT VARIABLES WHICH SPECIFY LOWER
////    AND UPPER BOUNDS FOR THE STEP.
////
////  INFO IS AN INTEGER OUTPUT VARIABLE SET AS FOLLOWS:
////    IF INFO = 0,1,2,3,4, THEN THE STEP HAS BEEN COMPUTED
////    ACCORDING TO ONE OF THE FIVE CASES BELOW. OTHERWISE
////    INFO = 0, AND THIS INDICATES IMPROPER INPUT PARAMETERS.
////
////SUBPROGRAMS CALLED
////
////  FORTRAN-SUPPLIED ... ABS,MAX,MIN,SQRT
////
////ARGONNE NATIONAL LABORATORY. MINPACK PROJECT. JUNE 1983
////JORGE J. MORE', DAVID J. THUENTE
//*************************************************************************/
//    void LBFGSOptimizer::mcstep(double &stx,
//                                      double &fx,
//                                      double &dx,
//                                      double &sty,
//                                      double &fy,
//                                      double &dy,
//                                      double &stp,
//                                      const double &fp,
//                                      const double &dp,
//                                      bool &brackt,
//                                      const double &stmin,
//                                      const double &stmax,
//                                      int &info) {
//        bool bound;
//        double gamma, p, q, r, s;
//        double sgnd, stpc, stpf, stpq, theta;
//
//        info = 0;
//        //     CHECK THE INPUT PARAMETERS FOR ERRORS.
//        if (((brackt && (stp <= MIN(stx, sty) || stp >= MAX(stx, sty)))
//             || dx * (stp - stx) >= 0) || stmax < stmin) {
//            return;
//        }
//
//        //     DETERMINE IF THE DERIVATIVES HAVE OPPOSITE SIGN.
//        if (dx > 0.0)
//            sgnd = dp;
//        else
//            sgnd = -dp;
//        //sgnd = dp*(dx/ABS(dx));
//
//        //     FIRST CASE. A HIGHER FUNCTION VALUE.
//        //     THE MINIMUM IS BRACKETED. IF THE CUBIC STEP IS CLOSER
//        //     TO STX THAN THE QUADRATIC STEP, THE CUBIC STEP IS TAKEN,
//        //     ELSE THE AVERAGE OF THE CUBIC AND QUADRATIC STEPS IS TAKEN.
//        if (fp > fx) {
//            info = 1;
//            bound = true;
//            theta = 3.0 * (fx - fp) / (stp - stx) + dx + dp;
//            s = MAX(ABS(theta), MAX(ABS(dx), ABS(dp)));
//            gamma = s * sqrt(ap::sqr(theta / s) - dx / s * (dp / s));
//            if (stp < stx) {
//                gamma = -gamma;
//            }
//            p = gamma - dx + theta;
//            q = gamma - dx + gamma + dp;
//            r = p / q;
//            stpc = stx + r * (stp - stx);
//            stpq = stx + dx / ((fx - fp) / (stp - stx) + dx) / 2.0 * (stp - stx);
//            if (ABS(stpc - stx) < ABS(stpq - stx)) {
//                stpf = stpc;
//            } else {
//                stpf = stpc + (stpq - stpc) / 2.0;
//            }
//            brackt = true;
//        } else {
//            //     SECOND CASE. A LOWER FUNCTION VALUE AND DERIVATIVES OF
//            //     OPPOSITE SIGN. THE MINIMUM IS BRACKETED. IF THE CUBIC
//            //     STEP IS CLOSER TO STX THAN THE QUADRATIC (SECANT) STEP,
//            //     THE CUBIC STEP IS TAKEN, ELSE THE QUADRATIC STEP IS TAKEN.
//            if (sgnd < 0) {
//                info = 2;
//                bound = false;
//                theta = 3.0 * (fx - fp) / (stp - stx) + dx + dp;
//                s = MAX(ABS(theta), MAX(ABS(dx), ABS(dp)));
//                gamma = s * sqrt(ap::sqr(theta / s) - dx / s * (dp / s));
//                if (stp > stx) {
//                    gamma = -gamma;
//                }
//                p = gamma - dp + theta;
//                q = gamma - dp + gamma + dx;
//                r = p / q;
//                stpc = stp + r * (stx - stp);
//                stpq = stp + dp / (dp - dx) * (stx - stp);
//                if (ABS(stpc - stp) > ABS(stpq - stp)) {
//                    stpf = stpc;
//                } else {
//                    stpf = stpq;
//                }
//                brackt = true;
//            } else {
//                //    THIRD CASE. A LOWER FUNCTION VALUE, DERIVATIVES OF THE
//                //    SAME SIGN, AND THE MAGNITUDE OF THE DERIVATIVE DECREASES.
//                //    THE CUBIC STEP IS ONLY USED IF THE CUBIC TENDS TO INFINITY
//                //    IN THE DIRECTION OF THE STEP OR IF THE MINIMUM OF THE CUBIC
//                //    IS BEYOND STP. OTHERWISE THE CUBIC STEP IS DEFINED TO BE
//                //    EITHER STPMIN OR STPMAX. THE QUADRATIC (SECANT) STEP IS ALSO
//                //    COMPUTED AND IF THE MINIMUM IS BRACKETED THEN THE THE STEP
//                //    CLOSEST TO STX IS TAKEN, ELSE THE STEP FARTHEST AWAY IS TAKEN.
//                if (ABS(dp) < ABS(dx)) {
//                    info = 3;
//                    bound = true;
//                    theta = 3.0 * (fx - fp) / (stp - stx) + dx + dp;
//                    s = MAX(ABS(theta), MAX(ABS(dx), ABS(dp)));
//                    gamma = s * sqrt(MAX(double(0), ap::sqr(theta / s) - dx / s * (dp / s)));
//                    if (stp > stx) {
//                        gamma = -gamma;
//                    }
//                    p = gamma - dp + theta;
//                    q = gamma + (dx - dp) + gamma;
//                    r = p / q;
//                    if (r < 0 && gamma != 0) {
//                        stpc = stp + r * (stx - stp);
//                    } else {
//                        if (stp > stx) {
//                            stpc = stmax;
//                        } else {
//                            stpc = stmin;
//                        }
//                    }
//                    stpq = stp + dp / (dp - dx) * (stx - stp);
//                    if (brackt) {
//                        if (ABS(stp - stpc) < ABS(stp - stpq)) {
//                            stpf = stpc;
//                        } else {
//                            stpf = stpq;
//                        }
//                    } else {
//                        if (ABS(stp - stpc) > ABS(stp - stpq)) {
//                            stpf = stpc;
//                        } else {
//                            stpf = stpq;
//                        }
//                    }
//                } else {
//                    //    FOURTH CASE. A LOWER FUNCTION VALUE, DERIVATIVES OF THE
//                    //    SAME SIGN, AND THE MAGNITUDE OF THE DERIVATIVE DOES
//                    //    NOT DECREASE. IF THE MINIMUM IS NOT BRACKETED, THE STEP
//                    //    IS EITHER STPMIN OR STPMAX, ELSE THE CUBIC STEP IS TAKEN.
//                    info = 4;
//                    bound = false;
//                    if (brackt) {
//                        theta = 3.0 * (fp - fy) / (sty - stp) + dy + dp;
//                        s = MAX(ABS(theta), MAX(ABS(dy), ABS(dp)));
//                        gamma = s * sqrt(ap::sqr(theta / s) - dy / s * (dp / s));
//                        if (stp > sty) {
//                            gamma = -gamma;
//                        }
//                        p = gamma - dp + theta;
//                        q = gamma - dp + gamma + dy;
//                        r = p / q;
//                        stpc = stp + r * (sty - stp);
//                        stpf = stpc;
//                    } else {
//                        if (stp > stx) {
//                            stpf = stmax;
//                        } else {
//                            stpf = stmin;
//                        }
//                    }
//                }
//            }
//        }
//
//        //    UPDATE THE INTERVAL OF UNCERTAINTY. THIS UPDATE DOES NOT
//        //    DEPEND ON THE NEW STEP OR THE CASE ANALYSIS ABOVE.
//        if (fp > fx) {
//            sty = stp;
//            fy = fp;
//            dy = dp;
//        } else {
//            if (sgnd < 0.0) {
//                sty = stx;
//                fy = fx;
//                dy = dx;
//            }
//            stx = stp;
//            fx = fp;
//            dx = dp;
//        }
//
//        //     COMPUTE THE NEW STEP AND SAFEGUARD IT.
//        stpf = MIN(stmax, stpf);
//        stpf = MAX(stmin, stpf);
//        stp = stpf;
//        if (brackt && bound) {
//            if (sty > stx) {
//                stp = MIN(stx + 0.66 * (sty - stx), stp);
//            } else {
//                stp = MAX(stx + 0.66 * (sty - stx), stp);
//            }
//        }
//    }
//
//
//    void LBFGSOptimizer::ShowNewIteration(double dx, double f, double gnorm) {
//        if (this->iter % this->nIterShow == 0)
//            printf("==> Iter=%4d   |dx|=%16.8e   (f-f0)=%16.8e    |grad|=%12.4e\n",
//                   this->iter, dx, f, gnorm);
//
//        return;
//    }
//
//}
