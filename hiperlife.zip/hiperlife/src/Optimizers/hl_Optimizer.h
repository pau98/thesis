/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef OPTIMIZER_H
#define OPTIMIZER_H

#include <Teuchos_RCP.hpp>
#include <Epetra_LinearProblem.h>

#include <hl_Timer.h>
#include <hl_HiPerProblem.h>
#include <hl_DistributedSrcData.h>

namespace hiperlife
{
    /*!
    * \class NonlinearSolver
    * \brief Model virtual class for linear solvers
    *
    * Every other Linear Solver inherits from this class.
    *
   */
    class Optimizer : public DistributedSrcData
    {
        public:
            /** @name Constructor / Destructor / Operator
            *  @{ */

            NonlinearSolver() = default;
            NonlinearSolver(NonlinearSolver &&other) = default;
            NonlinearSolver& operator=(NonlinearSolver&& other) = default;

            NonlinearSolver& operator=(const NonlinearSolver& other) = delete;
            NonlinearSolver(const NonlinearSolver& other) = delete;
            /** @} */ // end of constructors

            /** \name Solve Method
             * \brief return \ref boolean indicating convergence
             *
            *  @{ */
            virtual bool solve() = 0;
            /** @} */ // end solve

            /** \name Output Method
             * \brief return \ref print on screen the status of the solver
             *
            *  @{ */
            virtual void output(std::ostream& out) = 0;
            /** @} */ // end solve

            void setNumMaxIterations(int maxIter)
            {
                _maxIter = maxIter;
            }

            void setResTolerance(double resTol)
            {
                _resTol = resTol;
            }
            void setSolTolerance(double solTol)
            {
                _solTol = solTol;
            }
            void setFunTolerance(double funTol)
            {
                _solTol = solTol;
            }

            virtual void Update() = 0;

        protected:
            Teuchos::RCP<Epetra_LinearProblem> _linearProblem = Teuchos::null;
            Teuchos::RCP<Timer> _timer;

            int   _maxIter{};
            double _resTol{};
            double _solTol{};
            double _funTol{};

            Teuchos::RCP<HiPerProblem> _hpproblem;
    };
}


#endif //OPTIMIZER_H
