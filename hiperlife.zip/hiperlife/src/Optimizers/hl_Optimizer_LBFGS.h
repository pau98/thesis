/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


//#ifndef OPTIMIZERLBFGS_H
//#define OPTIMIZERLBFGS_H
//
//#include "Epetra_FEVector.h"
//
//#include "hl_Optimizer.h"
//
///** \brief class L-BFGS permits to solve non linear systems
//*
//*         LIMITED MEMORY BFGS METHOD FOR LARGE SCALE OPTIMIZATION \n
//*                           JORGE NOCEDAL
//*
//\verbatim
//C     This subroutine solves the unconstrained minimization problem
//C
//C                      min F(x),    x= (x1,x2,...,xN),
//C
//C      using the limited memory BFGS method. The routine is especially
//C      effective on problems involving a large number of variables. In
//C      a typical iteration of this method an approximation Hk to the
//C      inverse of the Hessian is obtained by applying M BFGS updates to
//C      a diagonal matrix Hk0, using information from the previous M steps.
//C      The user specifies the number M, which determines the amount of
//C      storage required by the routine. The user may also provide the
//C      diagonal matrices Hk0 if not satisfied with the default choice.
//C      The algorithm is described in "On the limited memory BFGS method
//C      for large scale optimization", by D. Liu and J. Nocedal,
//C      Mathematical Programming B 45 (1989) 503-528.
//C
//C      The user is required to calculate the function value F and its
//C      gradient G. In order to allow the user complete control over
//C      these computations, reverse  communication is used. The routine
//C      must be called repeatedly under the control of the parameter
//C      IFLAG.
//C
//C      The steplength is determined at each iteration by means of the
//C      line search routine MCVSRCH, which is a slight modification of
//C      the routine CSRCH written by More' and Thuente.
//\endverbatim
//
//* The subroutine minimizes function F(x) of N arguments by  using  a  quasi-
//* Newton method (LBFGS scheme) which is optimized to use  a  minimum  amount
//* of memory.
//*
//* The subroutine generates the approximation of an inverse Hessian matrix by
//* using information about the last M steps of the algorithm  (instead of N).
//* It lessens a required amount of memory from a value  of  order  N^2  to  a
//* value of order 2*N*L.
//
//* This subroutine uses the FuncGrad subroutine which calculates the value of
//* the function F and gradient G in point X. The programmer should define the
//* FuncGrad subroutine by himself.  It  should  be  noted that the subroutine
//* doesn't need to waste time for memory allocation of array G,  because  the
//* memory is allocated in calling the subroutine. Setting a dimension of array
//* G  each  time  when  calling  a  subroutine  will excessively slow down an
//* algorithm.
//*
//* The programmer could also redefine the LBFGSNewIteration subroutine  which
//* is called on each new step. The current point X, the function value F  and
//* the  gradient  G  are  passed  into  this  subroutine. It is reasonable to
//* redefine the subroutine for better debugging, for  example,  to  visualize
//* the solution process.
//*/
//namespace hiperlife
//{
//    class LBFGSOptimizer : public Optimizer
//    {
//        public :
//
//        /** Value of the parameter L ("L"-BFGS) in order to limit the memory for vectors v and w.
//            * The default value is L=7. However we observed that L=5 gives good results at
//            * lower cost.
//            *
//            * In cases where the stencil is too big (approx. 100-200) eg. when local max-entropy
//            * is used to solve 4-th PDE's a L=100 gives better results.\n
//            * NOTE: Of course You must take care of the amount of memory to be allocated.
//            * If N<=10e6 with 4Gb of RAM there is no problem.
//            *
//            * \param LSIZE number of corrections in the BFGS scheme of Hessian
//            approximation update. Recommended value:  3<=L<=7. The smaller
//            value causes worse convergence, the bigger will  not  cause  a
//            considerably better convergence, but will cause a fall in  the
//            performance. LSIZE<=N.
//        */
//        void setLimitedMemorySize(int LSIZE) { this->LSIZE = LSIZE; }
//
//        /** Show the result in each iteration */
//        void setShowIntermediateResults() { this->showNewIter = true; }
//
//        /** Show the result after some number of iterations */
//        void setShowIntermediateResults(int nIterShow) {
//            this->nIterShow = nIterShow;
//            this->showNewIter = true;
//        }
//
//        /** Return the current value of the function which is minimized. */
//        double getFunctionValue() const { return this->funVal; }
//
//        /** Return the norm for the current value of the function gradient (SHORT). */
//        double getGradientFunctionNorm() const { return xcmMath::Norm(this->NShort, this->gradShort); }
//
//        /** Return the norm for the current value of the solution (SHORT). */
//        double getSolutionNorm() const { return xcmMath::Norm(this->NShort, this->u_short); }
//
//        /** Final relative error reached in the solution is returned |x(i)-x(i-1)|) */
//        double getErrorSolutionNorm() { return this->errSOL; }
//
//        /** Final error reached in the function gradient is returned  |G_S(i)|/max(1,|G_L(i)|) */
//        double getErrorResidueNorm() { return this->errRES; }
//
//        /** Final error reached in the function value is returned  |F(i)-F(i-1)|/max(1,\F(i-1)\) */
//        double getErrorFunctionValue() { return this->errFUN; }
//
//        /** Get the info of the L-BFGS algorithm:
//         *   -3 ComputeSolution() function in L-BFGS class is called before Update() \n
//         *   -2 ic_tag was not set in the fillStr declaration \n
//         *   -1 wrong parameters have been specified (lbfgsMinimize), \n
//         *
//         *    0 relative function decreasing<=FUNTOL and step<=SOLTOL and gradient norm<=RESTOL \n
//         *
//         *    1 Bad input settings defined in the L-BFGS object
//         *    5 number of iterations exceeds MAXITER. \n
//         *    6 error solution value |x_old-x| is NaN or inf \n
//         *    7 fails |grad| is NaN or inf \n
//         *    8 error function value (f_old-f) is NaN or inf \n
//         */
//        int GetError() { return this->ierr; }
//
//        /** The number of iterations for computing the solution of the system */
//        int getNumberOfIterations() { return this->iter; }
//
//        /** Bring this algorithm's outputs up-to-date. */
//        virtual void Update();
//
//    protected:
//        /** @name Outputs from this LBFGS Quasi-Newton solver */
//        //@{
//        int    NLong;      ///< length of the total number of variables (fixed and free)  [LBFGS]
//        double funVal;     ///< function value at the present  [LBFGS]
//        //@}
//
//
//        bool evalFlag;   ///< Indicates if \b funEval function has been defined
//        bool showNewIter;
//        int ierr;
//        int iter;
//        int nIterShow;
//        int LSIZE;       ///< Value of the parameter L ("L"-BFGS). The default value is L=7
//        int MAXITER;     ///< Maximum number of iteration allowed. The default value is 100
//        double SOLTOL;      ///< positive number which defines the tolerance for the convergence of x
//        double RESTOL;      ///< positive number which defines the tolerance for the convergence of x's gradient
//        double FUNTOL;      ///< positive number which defines the tolerance for the convergence of the function to minimize
//
//        double errSOL;
//        double errFUN;
//        double errRES;
//
//        Epetra_Map _vec_map;
//        Teuchos::RCP<Epetra_FEVector> _vecShort;
//
//        double EPSILON{};
//
//        /** Check if the parameters and the data of the nodes are set. */
//        int CheckSettings();
//
//        /**
//        Copyright (c) 1980-2007, Jorge Nocedal.
//
//        Contributors:
//        * Sergey Bochkanov (ALGLIB project). Translation from FORTRAN to
//        pseudocode.
//
//        This software is freely available for educational or commercial  purposes.
//        We expect that all publications describing work using this software  quote
//        at least one of the references given below: \n
//        * J. Nocedal. Updating  Quasi-Newton  Matrices  with  Limited  Storage
//        (1980), Mathematics of Computation 35, pp. 773-782.\n
//        * D.C. Liu and J. Nocedal. On the  Limited  Memory  Method  for  Large
//        Scale  Optimization  (1989),  Mathematical  Programming  B,  45,  3,
//        pp. 503-528.
//        */
//
//        /** Compute at each iteration the Energy and its Gradient for the actual configuration (iteration ITER)
//            * \param x   actual position for the new configuration
//            * \param f   value of the energy for the new configuration
//            * \param g   value of the energy gradient in the new configuration */
//        void funGrad(ap::real_1d_array x, double &f, ap::real_1d_array &g);
//
//        /** L-BFGS main function.
//            *
//            * The subroutine minimizes function F(x) of N arguments by  using  a  quasi-Newton
//            * method (LBFGS scheme) which is optimized to use a minimum amount of memory. */
//        void LBFGSOptimizer::lbfgsMinimize(Teuchos::RCP<Epetra_FEVector> x);
//
//        /** */
//        void axpy(const int &n,
//                  const double &da,
//                  const ap::real_1d_array &dx,
//                  int sx,
//                  ap::real_1d_array &dy,
//                  int sy);
//
//        /** dot product */
//        double dot(const int &n,
//                   const ap::real_1d_array &dx,
//                   int sx,
//                   const ap::real_1d_array &dy,
//                   int sy);
//
//        /** A slight modification of the subroutine CSRCH of More' and Thuente.
//        * The changes are to allow reverse communication, and do not affect
//        * the performance of the routine.
//        *
//        * THE PURPOSE OF MCSRCH IS TO FIND A STEP WHICH SATISFIES
//        * A SUFFICIENT DECREASE CONDITION AND A CURVATURE CONDITION.
//        *
//        * AT EACH STAGE THE SUBROUTINE UPDATES AN INTERVAL OF
//        * UNCERTAINTY WITH ENDPOINTS STX AND STY. THE INTERVAL OF
//        * UNCERTAINTY IS INITIALLY CHOSEN SO THAT IT CONTAINS A
//        * MINIMIZER OF THE MODIFIED FUNCTION
//        *
//        *      F(X+STP*S) - F(X) - FTOL*STP*(GRADF(X)'S).
//        *
//        * IF A STEP IS OBTAINED FOR WHICH THE MODIFIED FUNCTION
//        * HAS A NONPOSITIVE FUNCTION VALUE AND NONNEGATIVE DERIVATIVE,
//        * THEN THE INTERVAL OF UNCERTAINTY IS CHOSEN SO THAT IT
//        * CONTAINS A MINIMIZER OF F(X+STP*S).
//        *
//        * THE ALGORITHM IS DESIGNED TO FIND A STEP WHICH SATISFIES
//        * THE SUFFICIENT DECREASE CONDITION
//        *
//        *       F(X+STP*S) .LE. F(X) + FTOL*STP*(GRADF(X)'S),
//        *
//        * AND THE CURVATURE CONDITION
//        *
//        *       ABS(GRADF(X+STP*S)'S)) .LE. GTOL*ABS(GRADF(X)'S).
//        *
//        * IF FTOL IS LESS THAN GTOL AND IF, FOR EXAMPLE, THE FUNCTION
//        * IS BOUNDED BELOW, THEN THERE IS ALWAYS A STEP WHICH SATISFIES
//        * BOTH CONDITIONS. IF NO STEP CAN BE FOUND WHICH SATISFIES BOTH
//        * CONDITIONS, THEN THE ALGORITHM USUALLY STOPS WHEN ROUNDING
//        * ERRORS PREVENT FURTHER PROGRESS. IN THIS CASE STP ONLY
//        * SATISFIES THE SUFFICIENT DECREASE CONDITION.
//        *
//        * THE SUBROUTINE STATEMENT IS
//        *
//        *    SUBROUTINE MCSRCH(N,X,F,G,S,STP,FTOL,XTOL, MAXFEV,INFO,NFEV,WA)
//        * WHERE
//        *
//        *   N IS A POSITIVE INTEGER INPUT VARIABLE SET TO THE NUMBER
//        *     OF VARIABLES.
//        *
//        *   X IS AN ARRAY OF LENGTH N. ON INPUT IT MUST CONTAIN THE
//        *     BASE POINT FOR THE LINE SEARCH. ON OUTPUT IT CONTAINS
//        *     X + STP*S.
//        *
//        *   F IS A VARIABLE. ON INPUT IT MUST CONTAIN THE VALUE OF F
//        *     AT X. ON OUTPUT IT CONTAINS THE VALUE OF F AT X + STP*S.
//        *
//        *   G IS AN ARRAY OF LENGTH N. ON INPUT IT MUST CONTAIN THE
//        *     GRADIENT OF F AT X. ON OUTPUT IT CONTAINS THE GRADIENT
//        *     OF F AT X + STP*S.
//        *
//        *   S IS AN INPUT ARRAY OF LENGTH N WHICH SPECIFIES THE
//        *     SEARCH DIRECTION.
//        *
//        *   STP IS A NONNEGATIVE VARIABLE. ON INPUT STP CONTAINS AN
//        *     INITIAL ESTIMATE OF A SATISFACTORY STEP. ON OUTPUT
//        *     STP CONTAINS THE FINAL ESTIMATE.
//        *
//        *   FTOL AND GTOL ARE NONNEGATIVE INPUT VARIABLES. (In this reverse
//        *     communication implementation GTOL is defined in a COMMON
//        *     statement.) TERMINATION OCCURS WHEN THE SUFFICIENT DECREASE
//        *     CONDITION AND THE DIRECTIONAL DERIVATIVE CONDITION ARE
//        *     SATISFIED.
//        *
//        *   XTOL IS A NONNEGATIVE INPUT VARIABLE. TERMINATION OCCURS
//        *     WHEN THE RELATIVE WIDTH OF THE INTERVAL OF UNCERTAINTY
//        *     IS AT MOST XTOL.
//        *
//        *   STPMIN AND STPMAX ARE NONNEGATIVE INPUT VARIABLES WHICH
//        *     SPECIFY LOWER AND UPPER BOUNDS FOR THE STEP. (In this reverse
//        *     communication implementatin they are defined in a COMMON
//        *     statement).
//        *
//        *   MAXFEV IS A POSITIVE INTEGER INPUT VARIABLE. TERMINATION
//        *     OCCURS WHEN THE NUMBER OF CALLS TO FCN IS AT LEAST
//        *     MAXFEV BY THE END OF AN ITERATION.
//        *
//        *   INFO IS AN INTEGER OUTPUT VARIABLE SET AS FOLLOWS:
//        *
//        *     INFO = 0  IMPROPER INPUT PARAMETERS.
//        *
//        *     INFO =-1  A RETURN IS MADE TO COMPUTE THE FUNCTION AND GRADIENT.
//        *
//        *     INFO = 1  THE SUFFICIENT DECREASE CONDITION AND THE
//        *               DIRECTIONAL DERIVATIVE CONDITION HOLD.
//        *
//        *     INFO = 2  RELATIVE WIDTH OF THE INTERVAL OF UNCERTAINTY
//        *               IS AT MOST XTOL.
//        *
//        *     INFO = 3  NUMBER OF CALLS TO FCN HAS REACHED MAXFEV.
//        *
//        *     INFO = 4  THE STEP IS AT THE LOWER BOUND STPMIN.
//        *
//        *     INFO = 5  THE STEP IS AT THE UPPER BOUND STPMAX.
//        *
//        *     INFO = 6  ROUNDING ERRORS PREVENT FURTHER PROGRESS.
//        *               THERE MAY NOT BE A STEP WHICH SATISFIES THE
//        *               SUFFICIENT DECREASE AND CURVATURE CONDITIONS.
//        *               TOLERANCES MAY BE TOO SMALL.
//        *
//        *   NFEV IS AN INTEGER OUTPUT VARIABLE SET TO THE NUMBER OF
//        *     CALLS TO FCN.
//        *
//        *   WA IS A WORK ARRAY OF LENGTH N.
//        *
//        * SUBPROGRAMS CALLED
//        *   MCSTEP
//        *
//        * ARGONNE NATIONAL LABORATORY. MINPACK PROJECT. JUNE 1983
//        * JORGE J. MORE', DAVID J. THUENTE */
//        void mcsrch(const int &n,
//                    ap::real_1d_array &x,
//                    double &f,
//                    ap::real_1d_array &g,
//                    const ap::real_1d_array &s,
//                    int sstart,
//                    double &stp,
//                    const double &ftol,
//                    const double &xtol,
//                    const int &maxfev,
//                    int &info,
//                    int &nfev,
//                    ap::real_1d_array &wa,
//                    const double &gtol,
//                    const double &stpmin,
//                    const double &stpmax);
//
//        /** THE PURPOSE OF \b MCSTEP IS TO COMPUTE A SAFEGUARDED STEP FOR
//        * A LINESEARCH AND TO UPDATE AN INTERVAL OF UNCERTAINTY FOR
//        * A MINIMIZER OF THE FUNCTION.
//        *
//        * THE PARAMETER STX CONTAINS THE STEP WITH THE LEAST FUNCTION
//        * VALUE. THE PARAMETER STP CONTAINS THE CURRENT STEP. IT IS
//        * ASSUMED THAT THE DERIVATIVE AT STX IS NEGATIVE IN THE
//        * DIRECTION OF THE STEP. IF BRACKT IS SET TRUE THEN A
//        * MINIMIZER HAS BEEN BRACKETED IN AN INTERVAL OF UNCERTAINTY
//        * WITH ENDPOINTS STX AND STY.
//        *
//        * THE SUBROUTINE STATEMENT IS
//        *
//        *   SUBROUTINE MCSTEP(STX,FX,DX,STY,FY,DY,STP,FP,DP,BRACKT,
//        *                    STPMIN,STPMAX,INFO)
//        *
//        * WHERE
//        *
//        *   STX, FX, AND DX ARE VARIABLES WHICH SPECIFY THE STEP,
//        *     THE FUNCTION, AND THE DERIVATIVE AT THE BEST STEP OBTAINED
//        *     SO FAR. THE DERIVATIVE MUST BE NEGATIVE IN THE DIRECTION
//        *     OF THE STEP, THAT IS, DX AND STP-STX MUST HAVE OPPOSITE
//        *     SIGNS. ON OUTPUT THESE PARAMETERS ARE UPDATED APPROPRIATELY.
//        *
//        *   STY, FY, AND DY ARE VARIABLES WHICH SPECIFY THE STEP,
//        *     THE FUNCTION, AND THE DERIVATIVE AT THE OTHER ENDPOINT OF
//        *     THE INTERVAL OF UNCERTAINTY. ON OUTPUT THESE PARAMETERS ARE
//        *     UPDATED APPROPRIATELY.
//        *
//        *   STP, FP, AND DP ARE VARIABLES WHICH SPECIFY THE STEP,
//        *     THE FUNCTION, AND THE DERIVATIVE AT THE CURRENT STEP.
//        *     IF BRACKT IS SET TRUE THEN ON INPUT STP MUST BE
//        *     BETWEEN STX AND STY. ON OUTPUT STP IS SET TO THE NEW STEP.
//        *
//        *   BRACKT IS A LOGICAL VARIABLE WHICH SPECIFIES IF A MINIMIZER
//        *     HAS BEEN BRACKETED. IF THE MINIMIZER HAS NOT BEEN BRACKETED
//        *     THEN ON INPUT BRACKT MUST BE SET FALSE. IF THE MINIMIZER
//        *     IS BRACKETED THEN ON OUTPUT BRACKT IS SET TRUE.
//        *
//        *   STPMIN AND STPMAX ARE INPUT VARIABLES WHICH SPECIFY LOWER
//        *     AND UPPER BOUNDS FOR THE STEP.
//        *
//        *   INFO IS AN INTEGER OUTPUT VARIABLE SET AS FOLLOWS:
//        *     IF INFO = 0,1,2,3,4, THEN THE STEP HAS BEEN COMPUTED
//        *     ACCORDING TO ONE OF THE FIVE CASES BELOW. OTHERWISE
//        *     INFO = 0, AND THIS INDICATES IMPROPER INPUT PARAMETERS.
//        *
//        * ARGONNE NATIONAL LABORATORY. MINPACK PROJECT. JUNE 1983
//        * JORGE J. MORE', DAVID J. THUENTE        */
//        void mcstep(double &stx,
//                    double &fx,
//                    double &dx,
//                    double &sty,
//                    double &fy,
//                    double &dy,
//                    double &stp,
//                    const double &fp,
//                    const double &dp,
//                    bool &brackt,
//                    const double &stmin,
//                    const double &stmax,
//                    int &info);
//
//        /** */
//        void ShowNewIteration(double dx, double f, double gnorm);
//
//        /** Constructor */
//        LBFGSOptimizer(void);
//
//        /** Destructor */
//        virtual ~LBFGSOptimizer();
//    };
//}
//
//#endif // __xcmLimitedMemoryBFGS_h
