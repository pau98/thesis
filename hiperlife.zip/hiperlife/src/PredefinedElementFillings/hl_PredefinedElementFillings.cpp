/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include "hl_GlobalBasisFunctions.h"

#include "hl_PredefinedElementFillings.h"

using namespace std;

namespace hiperlife
{
    namespace PredefinedElementFillings
    {
        namespace //anonymous namespace for private functions
        {
            void _Laplace(RCP<FillStructure> fillStr)
            {
                //Initialize variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN  = subFill.eNN;         // Number of neighbor nodes
                int pDim = subFill.pDim;        // Number of parametric dimension

                // Shape functions and derivatives at Gauss points
                double jac;
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Fill linear system
                for (int i = 0; i < eNN; i++)
                {
                    for (int j = 0; j < eNN; j++)
                    {
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        fillStr->Ak(0, 0)[i*eNN+j] += jac * gbfgbf;
                    }
                }

                return;
            }

            void _Poisson(RCP<FillStructure> fillStr)
            {
                //Initialize variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN  = subFill.eNN;         // Number of neighbor nodes
                int pDim = subFill.pDim;        // Number of parametric dimension
                int nDim = subFill.nDim;        // Number of spatial dimensions

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Compute coordinates
                vector<double> x(nDim);
                for (int i = 0; i < eNN; i++)
                    for (int n = 0; n < nDim; n++)
                        x[n] += subFill.nborCoords[nDim*i+n]*bf[i];

                // Compute body force
                double s = fillStr->paramStr->Poisson.source(x[0], x[1], x[2]);

                // Fill linear system
                for (int i = 0; i < eNN; i++)
                {
                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i]*s;

                    // Fill matrix
                    for (int j = 0; j < eNN; j++)
                    {
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        fillStr->Ak(0, 0)[i*eNN+j] += jac * gbfgbf;
                    }
                }

                return;
            }

            void _Poisson_constantSource(RCP<FillStructure> fillStr)
            {
                //Initialize variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN  = subFill.eNN;         // Number of neighbor nodes
                int pDim = subFill.pDim;        // Number of parametric dimension

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Fill linear system
                for (int i = 0; i < eNN; i++)
                {
                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i]*fillStr->paramStr->Poisson.constantSource;

                    // Fill matrix
                    for (int j = 0; j < eNN; j++)
                    {
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        fillStr->Ak(0, 0)[i*eNN+j] += jac * gbfgbf;
                    }
                }

                return;
            }

            void _TransientDiffusion(RCP<FillStructure> fillStr)
            {
                // Rename parameters
                double deltat = fillStr->paramStr->time.deltat;
                double diff   = fillStr->paramStr->TransientDiffusion.diffusionCoefficient;

                //Initialize variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN  = subFill.eNN;         // Number of neighbor nodes
                int pDim = subFill.pDim;        // Number of parametric dimension
                int nDim = subFill.nDim;        // Number of spatial dimensions
                double* nborDOFs0 = subFill.nborDOFs0.data();

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Compute coordinates
                vector<double> x(nDim);
                for (int i = 0; i < eNN; i++)
                    for (int n = 0; n < nDim; n++)
                        x[n] += subFill.nborCoords[nDim*i+n]*bf[i];

                // Compute source
                double source = fillStr->paramStr->TransientDiffusion.source(x[0], x[1], x[2]);

                // Compute value at previous time step
                double u0{};
                for (int i = 0; i < eNN; i++)
                    u0 += nborDOFs0[i] * bf[i];

                // Fill linear system
                for (int i = 0; i < eNN; i++)
                {
                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i]*(u0/deltat + source);

                    // Fill matrix
                    for (int j = 0; j < eNN; j++)
                    {
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        fillStr->Ak(0, 0)[i*eNN+j] += jac * (bf[i]*bf[j]/deltat + diff*gbfgbf);
                    }
                }

                return;
            }

            void _TransientDiffusion_constantSource(RCP<FillStructure> fillStr)
            {
                // Rename parameters
                double deltat = fillStr->paramStr->time.deltat;
                double diff   = fillStr->paramStr->TransientDiffusion.diffusionCoefficient;
                double source = fillStr->paramStr->TransientDiffusion.constantSource;

                //Initialize variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN  = subFill.eNN;         // Number of neighbor nodes
                int pDim = subFill.pDim;        // Number of parametric dimension
                double* nborDOFs0 = subFill.nborDOFs0.data();

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Compute value at previous time step
                double u0{};
                for (int i = 0; i < eNN; i++)
                    u0 += nborDOFs0[i] * bf[i];

                // Fill linear system
                for (int i = 0; i < eNN; i++)
                {
                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i]*(u0/deltat + source);

                    // Fill matrix
                    for (int j = 0; j < eNN; j++)
                    {
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        fillStr->Ak(0, 0)[i*eNN+j] += jac * (bf[i]*bf[j]/deltat + diff*gbfgbf);
                    }
                }

                return;
            }

            void _LinearElasticity(RCP<FillStructure> fillStr)
            {
                // Rename parameters
                double mu     = fillStr->paramStr->linearElasticity.mu;
                double lambda = fillStr->paramStr->linearElasticity.lambda;

                // Rename variables
                SubFillStructure& subFill = (*fillStr)[0];
                int numDOFs = subFill.numDOFs; // Number of degrees of freedom
                int eNN     = subFill.eNN;     // Number of neighbor nodes
                int pDim    = subFill.pDim;    // Number of parametric dimensions

                // Shape functions and derivatives at Gauss points
                double jac;
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Fill RHS if there is a body force
                if (fillStr->paramStr->linearElasticity.bodyForce != nullptr)
                {
                    // Rename parameters
                    int nDim   = subFill.nDim;    // Number of spatial dimensions
                    double* bf = subFill.nborBFs();

                    // Compute coordinates
                    vector<double> x(nDim);
                    for (int i = 0; i < eNN; i++)
                        for (int n = 0; n < nDim; n++)
                            x[n] += subFill.nborCoords[nDim*i+n]*bf[i];

                    // Compute body force
                    vector<double> f = fillStr->paramStr->linearElasticity.bodyForce(x[0], x[1], x[2]);

                    // Fill RHS
                    for (int i = 0; i < eNN; i++)
                    {
                        for (int d = 0; d < numDOFs; d++)
                            fillStr->Bk(0)[numDOFs*i+d] += jac * bf[i]*f[d];
                    }
                }

                // Fill matrix
                double N_e = numDOFs*eNN;
                for (int i = 0; i < eNN; i++)
                {
                    for (int j = 0; j < eNN; j++)
                    {
                        double gbfgbf{};
                        for (int p = 0; p < pDim; p++)
                            gbfgbf += gbf[pDim*i+p]*gbf[pDim*j+p];

                        for (int d = 0; d < numDOFs; d++)
                            fillStr->Ak(0, 0)[(numDOFs*i+d)*N_e + numDOFs*j+d] += jac * mu*gbfgbf;

                        for (int a = 0; a < pDim; a++)
                            for (int b = 0; b < pDim; b++)
                                fillStr->Ak(0, 0)[(numDOFs*i+a)*N_e + numDOFs*j+b] += jac * (lambda*gbf[pDim*i+a]*gbf[pDim*j+b]
                                                                                             + mu*gbf[pDim*i+b]*gbf[pDim*j+a]);
                    }
                }

                return;
            }

            void _AllenCahn_constantMobility(RCP<FillStructure> fillStr)
            {
                // Parameters
                double deltat   = fillStr->paramStr->time.deltat;
                double mobility = fillStr->paramStr->AllenCahn.constantMobility;
                double epsilon2 = fillStr->paramStr->AllenCahn.epsilon2;

                // Rename variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN   = subFill.eNN;
                int pDim  = subFill.pDim;
                double *nborDOFs  = subFill.nborDOFs.data();
                double *nborDOFs0 = subFill.nborDOFs0.data();

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Values at integration points
                double c{}, c0{};
                vector<double> gc(pDim);
                for (int i = 0; i < eNN; i++)
                {
                    // Values
                    c  += nborDOFs[i]  * bf[i];
                    c0 += nborDOFs0[i] * bf[i];

                    // Gradients
                    for (int d = 0; d < pDim; d++)
                        gc[d] += nborDOFs[i] * gbf[pDim*i+d];
                }

                // Derivatives of the double well
                vector<double> doubleWell = fillStr->paramStr->AllenCahn.doubleWell(c);
                double  dW = doubleWell[1];
                double ddW = doubleWell[2];

                // Fill
                for (int i = 0; i < eNN; i++)
                {
                    // Gradient of basis function times gradient of phase-field variable
                    double gbfgc{};
                    for (int d = 0; d < pDim; d++)
                        gbfgc += gbf[pDim*i+d]*gc[d];

                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i] * (c-c0) / deltat;
                    fillStr->Bk(0)[i] += jac * mobility * bf[i] * dW;
                    fillStr->Bk(0)[i] += jac * mobility * epsilon2 * gbfgc;

                    for (int j = 0; j < eNN; j++)
                    {
                        // Product of the gradient of basis functions
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        // Fill Ak
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * bf[i] * bf[j] / deltat;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * bf[i] * ddW * bf[j];
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * epsilon2 * gbfgbf;
                    }
                }

                return;
            }

            void _AllenCahn(RCP<FillStructure> fillStr)
            {
                // Parameters
                double deltat   = fillStr->paramStr->time.deltat;
                double epsilon2 = fillStr->paramStr->AllenCahn.epsilon2;

                // Rename variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN   = subFill.eNN;
                int pDim  = subFill.pDim;
                double *nborDOFs  = subFill.nborDOFs.data();
                double *nborDOFs0 = subFill.nborDOFs0.data();

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim);
                GlobalBasisFunctions::gradients(gbf.data(), jac, subFill);

                // Values at integration points
                double c{}, c0{};
                vector<double> gc(pDim);
                for (int i = 0; i < eNN; i++)
                {
                    // Values
                    c  += nborDOFs[i]  * bf[i];
                    c0 += nborDOFs0[i] * bf[i];

                    // Gradients
                    for (int d = 0; d < pDim; d++)
                        gc[d] += nborDOFs[i] * gbf[pDim*i+d];
                }

                // Derivatives of the double well
                vector<double> doubleWell = fillStr->paramStr->AllenCahn.doubleWell(c);
                double  dW = doubleWell[1];
                double ddW = doubleWell[2];

                // Mobility and derivatives
                vector<double> mobility = fillStr->paramStr->AllenCahn.mobility(c);
                double   mob = mobility[0];
                double  dmob = mobility[1];
                double ddmob = mobility[2];

                // Fill
                for (int i = 0; i < eNN; i++)
                {
                    // Gradient of basis function times gradient of phase-field variable
                    double gbfgc{}, gcgc{};
                    for (int d = 0; d < pDim; d++)
                    {
                        gbfgc += gbf[pDim*i+d]*gc[d];
                        gcgc  += gc[d]*gc[d];
                    }

                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i] * (c-c0) / deltat;
                    fillStr->Bk(0)[i] += jac * bf[i] * mob * dW;
                    fillStr->Bk(0)[i] += jac * epsilon2 * mob * gbfgc;
                    fillStr->Bk(0)[i] += jac * epsilon2 * bf[i] * dmob * gcgc;

                    for (int j = 0; j < eNN; j++)
                    {
                        // Product of the gradient of basis functions
                        double gbfgbf{}, gbfgcj{};
                        for (int d = 0; d < pDim; d++)
                        {
                            gbfgcj += gbf[pDim*j+d]*gc[d];
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];
                        }
                        // Fill Ak
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * bf[i] * bf[j] / deltat;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * bf[i] * bf[j] * (dmob*dW + mob*ddW);
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * epsilon2 * (dmob*bf[j]*gbfgc + mob*gbfgbf);
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * epsilon2 * bf[i] * (ddmob*bf[j]*gcgc + dmob*2.0*gbfgcj);
                    }
                }

                return;
            }

            void _Biharmonic(RCP<FillStructure> fillStr)
            {
                // Initialize variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN  = subFill.eNN;         // Number of neighbor nodes
                int pDim = subFill.pDim;        // Number of parametric dimension

                // Shape functions and derivatives at Gauss points
                double jac;
                vector<double> hbf(eNN*pDim*pDim), gbf(eNN*pDim), lapbf(eNN);
                GlobalBasisFunctions::hessians(gbf.data(), jac, hbf.data(), lapbf.data(), subFill);

                // Fill linear system
                for (int i = 0; i < eNN; i++)
                    for (int j = 0; j < eNN; j++)
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * lapbf[i]*lapbf[j];

                return;
            }

            void _TransientBiharmonic(RCP<FillStructure> fillStr)
            {
                //Parameters
                double deltat  = fillStr->paramStr->time.deltat;

                // Initialize variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN  = subFill.eNN;         // Number of neighbor nodes
                int pDim = subFill.pDim;        // Number of parametric dimension
                double* nborDOFs0 = subFill.nborDOFs0.data();

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> hbf(eNN*pDim*pDim), gbf(eNN*pDim), lapbf(eNN);
                GlobalBasisFunctions::hessians(gbf.data(), jac, hbf.data(), lapbf.data(), subFill);

                // Compute value at previous time step
                double u0{};
                for (int i = 0; i < eNN; i++)
                    u0 += nborDOFs0[i] * bf[i];

                // Fill linear system
                for (int i = 0; i < eNN; i++)
                {
                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i]*u0/deltat;

                    // Fill matrix
                    for (int j = 0; j < eNN; j++)
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * (bf[i]*bf[j]/deltat + lapbf[i]*lapbf[j]);
                }

                return;
            }

            void _CahnHilliard_constantMobility(RCP<FillStructure> fillStr)
            {
                // Parameters
                double deltat   = fillStr->paramStr->time.deltat;
                double mobility = fillStr->paramStr->CahnHilliard.constantMobility;
                double epsilon2 = fillStr->paramStr->CahnHilliard.epsilon2;

                // Rename variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN   = subFill.eNN;
                int pDim  = subFill.pDim;
                double *nborDOFs  = subFill.nborDOFs.data();
                double *nborDOFs0 = subFill.nborDOFs0.data();

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim), hbf(eNN*pDim*pDim), lapbf(eNN);
                GlobalBasisFunctions::hessians(gbf.data(), jac, hbf.data(), lapbf.data(), subFill);

                // Values at integration points
                double c{}, c0{}, lapc{};
                vector<double> gc(pDim);
                for (int i = 0; i < eNN; i++)
                {
                    // Values
                    c  += nborDOFs[i]  * bf[i];
                    c0 += nborDOFs0[i] * bf[i];

                    // Gradients
                    for (int d = 0; d < pDim; d++)
                        gc[d] += nborDOFs[i] * gbf[pDim*i+d];

                    // Hessians
                    for (int d = 0; d < pDim; d++)
                        lapc += nborDOFs[i] * hbf[pDim*pDim*i+pDim*d+d];
                }

                // Derivatives of the double well
                vector<double> doubleWell = fillStr->paramStr->CahnHilliard.doubleWell(c);
                double  ddW = doubleWell[2];
                double dddW = doubleWell[3];

                // Fill
                for (int i = 0; i < eNN; i++)
                {
                    // Gradient of basis function times gradient of phase-field variable
                    double gbfgc{};
                    for (int d = 0; d < pDim; d++)
                        gbfgc += gbf[pDim*i+d]*gc[d];

                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i] * (c-c0) / deltat;
                    fillStr->Bk(0)[i] += jac * mobility * ddW * gbfgc;
                    fillStr->Bk(0)[i] += jac * mobility * epsilon2 * lapbf[i] * lapc;

                    for (int j = 0; j < eNN; j++)
                    {
                        // Product of the gradient of basis functions
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        // Fill Ak
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * bf[i] * bf[j] / deltat;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * dddW * bf[j] * gbfgc;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * ddW * gbfgbf;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * mobility * epsilon2 * lapbf[i] * lapbf[j];
                    }
                }

                return;
            }

            void _CahnHilliard(RCP<FillStructure> fillStr)
            {
                // Parameters
                double deltat   = fillStr->paramStr->time.deltat;
                double epsilon2 = fillStr->paramStr->CahnHilliard.epsilon2;

                // Rename variables
                SubFillStructure& subFill = (*fillStr)[0];
                int eNN   = subFill.eNN;
                int pDim  = subFill.pDim;
                double *nborDOFs  = subFill.nborDOFs.data();
                double *nborDOFs0 = subFill.nborDOFs0.data();

                // Shape functions and derivatives at Gauss points
                double jac;
                double* bf = subFill.nborBFs();
                vector<double> gbf(eNN*pDim), hbf(eNN*pDim*pDim), lapbf(eNN);
                GlobalBasisFunctions::hessians(gbf.data(), jac, hbf.data(), lapbf.data(), subFill);

                // Values at integration points
                double c{}, c0{}, lapc{};
                vector<double> gc(pDim);
                for (int i = 0; i < eNN; i++)
                {
                    // Values
                    c  += nborDOFs[i]  * bf[i];
                    c0 += nborDOFs0[i] * bf[i];

                    // Gradients
                    for (int d = 0; d < pDim; d++)
                        gc[d] += nborDOFs[i] * gbf[pDim*i+d];

                    // Hessians
                    for (int d = 0; d < pDim; d++)
                        lapc += nborDOFs[i] * hbf[pDim*pDim*i+pDim*d+d];
                }

                // Derivatives of the double well
                vector<double> doubleWell = fillStr->paramStr->CahnHilliard.doubleWell(c);
                double  ddW = doubleWell[2];
                double dddW = doubleWell[3];

                // Mobility and derivatives
                vector<double> mobility = fillStr->paramStr->CahnHilliard.mobility(c);
                double   mob = mobility[0];
                double  dmob = mobility[1];
                double ddmob = mobility[2];

                // Fill
                for (int i = 0; i < eNN; i++)
                {
                    // Gradient of basis function times gradient of phase-field variable
                    double gbfgc{};
                    for (int d = 0; d < pDim; d++)
                        gbfgc += gbf[pDim*i+d]*gc[d];

                    // Fill RHS
                    fillStr->Bk(0)[i] += jac * bf[i] * (c-c0) / deltat;
                    fillStr->Bk(0)[i] += jac * mob * ddW * gbfgc;
                    fillStr->Bk(0)[i] += jac * epsilon2 * mob * lapbf[i] * lapc;
                    fillStr->Bk(0)[i] += jac * epsilon2 * dmob * gbfgc * lapc;

                    for (int j = 0; j < eNN; j++)
                    {
                        // Product of the gradient of basis functions
                        double gbfgbf{};
                        for (int d = 0; d < pDim; d++)
                            gbfgbf += gbf[pDim*i+d]*gbf[pDim*j+d];

                        // Fill Ak
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * bf[i] * bf[j] / deltat;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * dmob * bf[j] * ddW * gbfgc;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * mob * dddW * bf[j] * gbfgc;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * mob * ddW * gbfgbf;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * epsilon2 * dmob * bf[j] * lapbf[i] * lapc;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * epsilon2 * mob * lapbf[i] * lapbf[j];
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * epsilon2 * ddmob * bf[j] * gbfgc * lapc;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * epsilon2 * dmob * gbfgbf * lapc;
                        fillStr->Ak(0, 0)[i*eNN+j] += jac * epsilon2 * dmob * gbfgc * lapbf[j];
                    }
                }

                return;
            }
        }

        elemMatRHS Laplace(Teuchos::RCP<ParamStructure> u)
        {
            (void) u;
            return _Laplace;
        }

        elemMatRHS Poisson(Teuchos::RCP<ParamStructure> u)
        {
            if (u == Teuchos::null)
                throw runtime_error("PredefinedElementFillings::Poisson: The user structure has not been set in the hiperproblem.");
            if (std::isnan(u->Poisson.constantSource) and u->Poisson.source == nullptr)
                throw runtime_error("PredefinedElementFillings::Poisson: No source defined, neither constant nor non-constant");

            if (u->Poisson.source == nullptr)
                return _Poisson_constantSource;
            else
                return _Poisson;
        }

        elemMatRHS TransientDiffusion(Teuchos::RCP<ParamStructure> u)
        {
            if (u == Teuchos::null)
                throw runtime_error("PredefinedElementFillings::TransientDiffusion: The user structure has not been set in the hiperproblem.");
            if (std::isnan(u->TransientDiffusion.constantSource) and u->TransientDiffusion.source == nullptr)
                throw runtime_error("PredefinedElementFillings::TransientDiffusion: No source defined in the user structure, neither constant nor non-constant.");
            if (!std::isnan(u->TransientDiffusion.constantSource) and u->TransientDiffusion.source != nullptr)
                throw runtime_error("PredefinedElementFillings::TransientDiffusion: Both constant and non-constant sources ahave been defined the user structure. Please define just one.");
            if (std::isnan(u->TransientDiffusion.diffusionCoefficient))
                throw runtime_error("PredefinedElementFillings::TransientDiffusion: The diffusion coefficient has not been defined in the user structure.");


            if (u->TransientDiffusion.source == nullptr)
                return _TransientDiffusion_constantSource;
            else
                return _TransientDiffusion;
        }

        elemMatRHS LinearElasticity(Teuchos::RCP<ParamStructure> u)
        {
            if (u == Teuchos::null)
                throw runtime_error("PredefinedElementFillings::LinearElasticity: The user structure has not been set in the hiperproblem.");
            if (std::isnan(u->linearElasticity.mu) or std::isnan(u->linearElasticity.lambda))
                throw runtime_error("PredefinedElementFillings::LinearElasticity: mu and/or lambda not defined in the user structure.");

            return _LinearElasticity;
        }

        elemMatRHS Biharmonic(Teuchos::RCP<ParamStructure> u)
        {
            (void) u;
            return _Biharmonic;
        }

        elemMatRHS AllenCahn(Teuchos::RCP<ParamStructure> u)
        {
            if (u == Teuchos::null)
                throw runtime_error("PredefinedElementFillings::AllenCahn: The user structure has not been set in the hiperproblem.");
            if (std::isnan(u->AllenCahn.epsilon2))
                throw runtime_error("PredefinedElementFillings::AllenCahn: epsilon squared has not been defined in the user structure.");
            if (std::isnan(u->AllenCahn.constantMobility) and u->AllenCahn.mobility == nullptr)
                throw runtime_error("PredefinedElementFillings::AllenCahn: No mobility has been defined in the user structure, neither constant nor non-constant.");
            if (!std::isnan(u->AllenCahn.constantMobility) and u->AllenCahn.mobility != nullptr)
                throw runtime_error("PredefinedElementFillings::AllenCahn: Both constant and non-constant mobilities have been defined in the user structure. Please define just one.");
            if (u->AllenCahn.doubleWell == nullptr)
                throw runtime_error("PredefinedElementFillings::AllenCahn: The double well and its derivatives have not been defined in the user structure.");
            vector<double> w = u->AllenCahn.doubleWell(0.25);
            if (w.size() != 3)
                throw runtime_error("PredefinedElementFillings::AllenCahn: The function doubleWell should return a vector with three elements: the double well and its 1st and 2nd derivatives (in that order).");

            if (u->AllenCahn.mobility != nullptr)
            {
                vector<double> m = u->AllenCahn.mobility(0.25);
                if (m.size() != 3)
                    throw runtime_error("PredefinedElementFillings::AllenCahn: The function mobility should return a vector with two elements: the mobility and its first and second derivative (in that order).");

                return _AllenCahn;
            }
            else
            {
                return _AllenCahn_constantMobility;
            }
        }

        elemMatRHS TransientBiharmonic(Teuchos::RCP<ParamStructure> u)
        {
            if (u == Teuchos::null)
                throw runtime_error("PredefinedElementFillings::TransientBiharmonic: The user structure has not been set in the hiperproblem.");

            return _TransientBiharmonic;
        }

        elemMatRHS CahnHilliard(Teuchos::RCP<ParamStructure> u)
        {
            if (u == Teuchos::null)
                throw runtime_error("PredefinedElementFillings::CahnHilliard: The user structure has not been set in the hiperproblem.");
            if (std::isnan(u->CahnHilliard.epsilon2))
                throw runtime_error("PredefinedElementFillings::CahnHilliard: epsilon squared has not been defined in the user structure.");
            if (std::isnan(u->CahnHilliard.constantMobility) and u->CahnHilliard.mobility == nullptr)
                throw runtime_error("PredefinedElementFillings::CahnHilliard: No mobility has been defined in the user structure, neither constant nor non-constant.");
            if (!std::isnan(u->CahnHilliard.constantMobility) and u->CahnHilliard.mobility != nullptr)
                throw runtime_error("PredefinedElementFillings::CahnHilliard: Both constant and non-constant mobilities have been defined in the user structure. Please define just one.");
            if (u->CahnHilliard.doubleWell == nullptr)
                throw runtime_error("PredefinedElementFillings::CahnHilliard: The double well and its derivatives have not been defined in the user structure.");
            vector<double> w = u->CahnHilliard.doubleWell(0.25);
            if (w.size() != 4)
                throw runtime_error("PredefinedElementFillings::CahnHilliard: The function doubleWell should return a vector with four elements: the double well and its 1st, 2nd and 3rd derivatives (in that order).");

            if (u->CahnHilliard.mobility != nullptr)
            {
                vector<double> m = u->CahnHilliard.mobility(0.25);
                if (m.size() != 3)
                    throw runtime_error("PredefinedElementFillings::CahnHilliard: The function mobility should return a vector with two elements: the mobility and its first and second derivatives (in that order).");

                return _CahnHilliard;
            }
            else
            {
                return _CahnHilliard_constantMobility;
            }
        }

    } // namespace PredefinedElementFillings
} // namespace hiperlife
