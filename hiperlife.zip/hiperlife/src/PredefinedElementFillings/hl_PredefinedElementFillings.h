/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HL_PREELEMFILL_H
#define HL_PREELEMFILL_H

#include "hl_ParamStructure.h"
#include "hl_FillStructure.h"

using Teuchos::RCP;

namespace hiperlife
{
    namespace PredefinedElementFillings
    {
        typedef void (*elemMatRHS)(Teuchos::RCP<FillStructure>);

        /*! \brief Laplace's equation
         * \f$ \Delta u = 0 \f$
         * \param u Degree of freedom
         */
        elemMatRHS Laplace(Teuchos::RCP<ParamStructure>);

        /*! \brief Poisson's equation
         *  \f$ \Delta u + f(\boldsymbol{x}) = 0 \f$
         * \param u Degree of freedom
         * \param \f$ f(\boldsymbol{x}) \f$ Source term that depends on the spatial coordinates. Defined in the user structure through the lambda function <em>userStructure->Poisson.source<\em>. Eg userStr->Poisson.source = [](double x, double y, double z){return x*y*z;}. Alternatively, one can specify a constant source using <em>userStructure->Poisson.constantSource<\em>
         */
        elemMatRHS Poisson(Teuchos::RCP<ParamStructure>);

        /*! \brief Transient diffusion equation
         *  \f$ \frac{\partial u}{\partial t} = \Delta u + f(\boldsymbol{x})\f$
         * \param u Degree of freedom
         * \param \f$ f(\boldsymbol{x}) \f$ Source term that depends on the spatial coordinates. Defined in the user structure through the lambda function <em>userStructure->TransientDiffusion.source<\em>. Eg userStr->TransientDiffusion.source = [](double x, double y, double z){return x*y*z;}. Alternatively, one can specify a constant source using <em>userStructure->TransientDiffusion.constantSource<\em>
         */
        elemMatRHS TransientDiffusion(Teuchos::RCP<ParamStructure>);

        /*! \brief Linear elasticity equations
         *  \f$ (\lambda+\mu)\nabla(\nabla\cdot\mathbf{u})+\mu\nabla^2\mathbf{u}+\mathbf{f(\boldsymbol{x})}=0 \f$
         * \param \mathbf{u} Displacements set in the DOFsHandler. It works for 1, 2 and 3D
         * \param \lambda First Lamè parameter
         * \param \mu Second Lamè parameter
         * \param \f$ F(\boldsymbol{x}) \f$ 3D body force that depends on the spatial coordinates. Defined in the user structure through the lambda function <em>userStructure->linearElasticity.bodyForce<\em>. Eg userStr->linearElasticity.bodyForce = [](double x, double y, double z){return {x, -y, 0};}.
         */
        elemMatRHS LinearElasticity(Teuchos::RCP<ParamStructure>);

        /*! \brief Allen-Cahn equation
         *  \f$ \frac{\partial c}{\partial t} = - M(c)(\mu(c)-\epsilon^2\Delta c) \f$
         * \param c Degree of freedom
         * \param \f$ M(c) \f$ Mobility. Defined in the user structure (both the mobility and its 1st and 2nd derivatives wrt to c) through the lambda function <em>userStructure->AllenCahn.mobility<\em>. Eg userStr->AllenCahn.mobility = [](double c)->vector<double>{return {c*(1-c), 1-2*c, -2};}. Alternatively, one can specify a constant mobility using <em>userStructure->AllenCahn.constantMobility<\em>
         * \param \f$ \mu(c) \f$ Chemical potential or derivative of the double well. Defined by the user using the user structure through the lambda function <em>userStructure->AllenCahn.doubleWell<\em>. The user has to specify the equation for the double well, as well as its 1st and 2nd derivatives. Eg userStr->AllenCahn.doubleWell = [](double c)->vector<double>{return {(c*c)*(1.0-c)*(1.0-c)/4.0, c*(1.0-c)*(1.0-2.0*c)/2.0, (1.0-6.0*c+6.0*c*c)/2.0;}. The implementation of the weak form only needs the first and second derivatives.
         * \param \f$ \epsilon \f$ Positive parameter proportional to the interface thickness. Defined by its squared vale through the user structure with <em>userStructure->AllenCahn.epsilon2<\em>.
         */
        elemMatRHS AllenCahn(Teuchos::RCP<ParamStructure>);

        /*! \brief Biharmonic equation
         *  \f$ \Delta^2 u = 0 \f$
         * \param u Degree of freedom
         */
        elemMatRHS Biharmonic(Teuchos::RCP<ParamStructure>);

        /*! \brief Transient biharmonic equation
         *  \f$ \frac{\partial u}{\partial t} = \Delta^2 u \f$
         * \param u Degree of freedom
         */
        elemMatRHS TransientBiharmonic(Teuchos::RCP<ParamStructure>);

        /*! \brief Cahn-Hilliard equation
         *  \f$ \frac{\partial c}{\partial t} = \nabla \cdot (M(c)\nabla(\mu(c)-\epsilon^2\Delta c)) \f$
         * \param c Degree of freedom
         * \param \f$ M(c) \f$ Mobility. Defined in the user structure (both the mobility and its 1st and 2nd derivatives wrt to c) through the lambda function <em>userStructure->CahnHilliard.mobility<\em>. Eg userStr->CahnHilliard.mobility = [](double c)->vector<double>{return {c*(1-c), 1-2*c, -2.0};}. Alternatively, one can specify a constant mobility using <em>userStructure->CahnHilliard.constantMobility<\em>
         * \param \f$ \mu(c) \f$ Chemical potential or derivative of the double well. Defined by the user using the user structure through the lambda function <em>userStructure->CahnHilliard.doubleWell<\em>. The user has to specify the equation for the double well, as well as its 1st, 2nd and 3rd derivatives. Eg userStr->CahnHilliard.doubleWell = [](double c)->vector<double>{return {(c*c)*(1.0-c)*(1.0-c)/4.0, c*(1.0-c)*(1.0-2.0*c)/2.0, (1.0-6.0*c+6.0*c*c)/2.0, (-1.0+2.0*c)*3.0};}. The implementation of the weak form only needs the second and third derivatives.
         * \param \f$ \epsilon \f$ Positive parameter proportional to the interface thickness. Defined by its squared vale through the user structure with <em>userStructure->CahnHilliard.epsilon2<\em>.
         */
        elemMatRHS CahnHilliard(Teuchos::RCP<ParamStructure>);

    } // namespace PredefinedElementFillings
} // namespace hiperlife
#endif
