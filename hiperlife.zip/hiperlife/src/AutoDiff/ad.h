/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ad_h
#define ad_h

// C++ includes
#include <algorithm>
#include <cmath>
#include <functional>
#include <sstream>
#include <tuple>
#include <type_traits>
#include <utility>

// autodiff includes
#include "ad_numbertraits.h"
#include "ad_vectortraits.h"
#include "ad_classtraits.h"
#include "ad_meta.h"
#include "ad_dual.h"
#include "ad_derivative.h"
#include "ad_gradient.h"

#endif //ad_h
