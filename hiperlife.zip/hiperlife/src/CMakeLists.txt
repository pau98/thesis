# #Show info
message(STATUS "hiperlife install directory: ${HPLFE_INSTALL_DIR}")

#set(CMAKE_C_COMPILER ${MPI_C_COMPILER} CACHE INTERNAL "")
#set(CMAKE_CXX_COMPILER ${MPI_CXX_COMPILER} CACHE INTERNAL "")

include_directories(${MPI_CXX_COMPILER_INCLUDE_DIRS})


#Set installation paths

set(MPI_LIB ${MPI_C_LIB})

#Set library
set(HPLFE_LIBRARIES CACHE INTERNAL "HPLFE_LIBRARIES")
set(CMAKE_CXX_FLAGS "-fpermissive")
find_package(Eigen3 3.3 REQUIRED NO_MODULE)

#Define a precompiler variable to the source code of hiperlife
add_definitions(-DHPLFE_ROOT_DIR="${CMAKE_CURRENT_LIST_DIR}")
add_definitions(-DDEBUG=1) # FIXME Only add that in debug mode

#Set include directories
message(STATUS "Configuring hiperlife modules")
file(GLOB HPLFE_INC_DIRS LIST_DIRECTORIES true ${HPLFE_SOURCE_DIR}/*)
list(REMOVE_ITEM HPLFE_INC_DIRS ${HPLFE_SOURCE_DIR}/CMakeLists.txt)
list(REMOVE_ITEM HPLFE_INC_DIRS ${HPLFE_TESTS_DIR})
# list(REMOVE_ITEM HPLFE_INC_DIRS ${HPLFE_POSTPROC_DIR}) //FIXME: Not sure about commenting this line. I did it because POSTPROC is now a library also, as it is needed for the GUI
list(REMOVE_ITEM HPLFE_INC_DIRS ${HPLFE_GUI_DIR})
#
# #Include dirs
# include_directories(SYSTEM ${MPI_BASE_PATH}/include)
include_directories(SYSTEM "${Trilinos_INCLUDE_DIRS}")
set(HPLFE_INCLUDE_DIRS ${HPLFE_INC_DIRS} CACHE INTERNAL "Hiperlife include directories")

#Include VTK
if(VTK_FOUND)
  message(STATUS "Hiperlife includes vtk: ${VTK_INCLUDE_DIRS}")
  include_directories(SYSTEM ${VTK_INCLUDE_DIRS})
endif()

if(MUMPS_FOUND)
  message(STATUS "Hiperlife includes MUMPS: ${MUMPS_INCLUDE_DIRS}")
  include_directories(SYSTEM ${MUMPS_INCLUDE_DIRS})
else()
  message(STATUS "Mumps disabled in hiperlife")
endif()

include_directories(
   ${HPLFE_INC_DIRS}
   ${HPLFE_INCLUDE_DIRS_BUILD_TREE_CXX}
   ${HPLFE_INCLUDE_DIRS_SYSTEM}
)
add_subdirectory(${HPLFE_SOURCE_DIR}/Core)
add_subdirectory(${HPLFE_SOURCE_DIR}/Utils)
add_subdirectory(${HPLFE_SOURCE_DIR}/AdjcyLists)
add_subdirectory(${HPLFE_SOURCE_DIR}/Fields)
add_subdirectory(${HPLFE_SOURCE_DIR}/BasisFunctions)
add_subdirectory(${HPLFE_SOURCE_DIR}/AutoDiff)
add_subdirectory(${HPLFE_SOURCE_DIR}/Tensor)
add_subdirectory(${HPLFE_SOURCE_DIR}/MeshCreator)
add_subdirectory(${HPLFE_SOURCE_DIR}/MeshMap)
add_subdirectory(${HPLFE_SOURCE_DIR}/Cubature)
add_subdirectory(${HPLFE_SOURCE_DIR}/CubatureSet)
add_subdirectory(${HPLFE_SOURCE_DIR}/BasisFunctionsSet)
add_subdirectory(${HPLFE_SOURCE_DIR}/DistributedMesh)
add_subdirectory(${HPLFE_SOURCE_DIR}/IO)
add_subdirectory(${HPLFE_SOURCE_DIR}/DOFsHandler)
add_subdirectory(${HPLFE_SOURCE_DIR}/Integration)
add_subdirectory(${HPLFE_SOURCE_DIR}/HiPerProblem)
add_subdirectory(${HPLFE_SOURCE_DIR}/LinearSolvers)
add_subdirectory(${HPLFE_SOURCE_DIR}/NonlinearSolvers)
#add_subdirectory(${HPLFE_SOURCE_DIR}/Optimizers)
add_subdirectory(${HPLFE_SOURCE_DIR}/ModelUtils)
add_subdirectory(${HPLFE_SOURCE_DIR}/PostProc)
add_subdirectory(${HPLFE_SOURCE_DIR}/Remesher)
add_subdirectory(${HPLFE_SOURCE_DIR}/TimeIterator)
add_subdirectory(${HPLFE_SOURCE_DIR}/PredefinedElementFillings)
add_subdirectory(${HPLFE_SOURCE_DIR}/ThirdParty)

#Compile GUI
if(BUILD_GUI)
  add_subdirectory(${HPLFE_SOURCE_DIR}/Gui)
endif()

add_custom_target(hiperlife)
add_dependencies(hiperlife ${HPLFE_LIBRARIES})

#Compile tests
if(BUILD_TESTS)
  set(TESTS_INSTALL_DIR ${HPLFE_INSTALL_DIR}/tests/)
  add_subdirectory(${HPLFE_SOURCE_DIR}/Tests)
endif()
