/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DOFSHANDLER_H
#define DOFSHANDLER_H

#include <string>

#include <Teuchos_RCP.hpp>

#include "hl_DistributedMesh.h"
#include "hl_FieldStruct.h"

namespace hiperlife
{

    /*!
     * \class DOFsHandler
     * \brief Class that contains all the basic material for solving problems
     * using Finite Elements.
     *
     * It contains a DistributedMesh object that deals with the structures
     * needed for generate a mesh in distributed memory. Also, it contains
     * structure for the DoFs, constraints and the Linear Algebra objects to
     * actually solve the problem.
     *
     * The information needed for creating the object needs given via the
     * class setters and then Update function will generate the object.
     * Afterwords, the constraints and the ghost structures and LA
     * objected needs to be created before actually using it.
     *
    */

    class DOFsHandler : public DistributedClass
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            DOFsHandler(std::string tag ="DOFsHandler", MPI_Comm comm = MPI_COMM_WORLD) : DistributedClass(tag, comm) {}
            DOFsHandler(DOFsHandler&& other) = default;
            DOFsHandler(const DOFsHandler& other) = delete;
            ~DOFsHandler() = default;

            DOFsHandler(Teuchos::RCP<DistributedMesh>);

            DOFsHandler& operator=(const DOFsHandler& other) = delete;
            DOFsHandler& operator=(DOFsHandler&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a DOFsHandler object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the number of degrees of freedom of our system. */
            void setNumDOFs(int dofs);
            /*! \brief Sets the number of degrees of freedom of our system. */
            void setDOFs(std::vector<std::string> tags);
            /*! \brief Gets the number of degrees of freedom of our system. */
            int numDOFs() const {return nodeDOFs->numFlds();}
            /*! \brief Sets the number of auxiliary fields you want to create. */
            void setNumNodeAuxF(int auxflds);
            /*! \brief Sets the number of auxiliary fields you want to create. */
            void setNodeAuxF(std::vector<std::string> tags);
            /*! \brief Gets the number of auxiliar degrees of freedom of our system. */
            int numNodeAuxF() const {return (nodeAuxF==Teuchos::null)?(0):(nodeAuxF->numFlds());}
            /*! \brief Sets the number of auxiliary fields you want to create. */
            void setNumElemAuxF(int auxflds);
            /*! \brief Sets the number of auxiliary fields you want to create. */
            void setElemAuxF(std::vector<std::string> tags);
            /*! \brief Gets the number of auxiliar degrees of freedom of our system. */
            int numElemAuxF() const {return (elemAuxF==Teuchos::null)?(0):(elemAuxF->numFlds());}
            /*! \brief Sets the vtk legacy file from which the object will be created. */
            void setFilePrefix(std::string prefix, OutputMode mode = OutputMode::Undefined)
            {
                _tmp_filePrefix = std::string(prefix); _tmp_outputmode = mode;
            }
            /*! \brief Sets the vtk legacy file from which the object will be created. */
            void setLegacyFileName(std::string filename) { _tmp_legFileName = filename;}
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update();
            /** @} */ // end of object creation



            /** @name Constrain management and boundary conditions
             *  @{
             */
            /*! \brief Set a constraint value at one point for one dof given by a tag.*/
            void setConstraint(int dof, int idx, IndexType idxtype, double value);
            /*! \brief Set a constraint value at one point for one dof given by a tag.*/
            void setConstraint(std::string tag, int idx, IndexType idxtype, double value){setConstraint(nodeDOFs->index(tag), idx, idxtype, value);};
            /*! \brief Set a constraint value at every point for one dof.*/
            void setConstraint(int dof, double value);
            /*! \brief Set a constraint value at every point for one dof given by a tag.*/
            void setConstraint(std::string tag, double value){setConstraint(nodeDOFs->index(tag), value);};

            /*! \brief Set a constraint value at one point of the boundary for one dof.*/
            void setBoundaryCondition(int dof, int idx, IndexType idxtype, double value);
            /*! \brief Set a constraint value at one point of the boundary for one dof given by a tag.*/
            void setBoundaryCondition(std::string tag, int idx, IndexType idxtype, double value){setBoundaryCondition(nodeDOFs->index(tag), idx, idxtype, value);};
            /*! \brief Set a constraint value at one axis for one dof.*/
            void setBoundaryCondition(int dof, MAxis ax, double value);
            /*! \brief Set a constraint value at one axis for one dof given by a tag.*/
            void setBoundaryCondition(std::string tag, MAxis ax, double value){setBoundaryCondition(nodeDOFs->index(tag), ax, value);};
            /*! \brief Set a constraint function at one axis for one dof in 2D.*/
            void setBoundaryCondition(int dof, MAxis ax, std::function<double(double)> f);
            /*! \brief Set a constraint function at one axis for one dof given by a tag in 2D.*/
            void setBoundaryCondition(std::string tag, MAxis ax, std::function<double(double)> f){setBoundaryCondition(nodeDOFs->index(tag), ax, f);};
            /*! \brief Set a constraint function at one axis for one dof in 3D.*/
            void setBoundaryCondition(int dof, MAxis ax, std::function<double(double, double)> f);
            /*! \brief Set a constraint function at one axis for one dof given by a tag in 3D.*/
            void setBoundaryCondition(std::string tag, MAxis ax, std::function<double(double, double)> f){setBoundaryCondition(nodeDOFs->index(tag), ax, f);};
            /*! \brief Set a constraint value at every axis for one dof.*/
            void setBoundaryCondition(int dof, double value);
            /*! \brief Set a constraint value at every axis for one dof given by a tag.*/
            void setBoundaryCondition(std::string tag, double value){setBoundaryCondition(nodeDOFs->index(tag), value);};
            /*! \brief Set a constraint value at every axis for every dof.*/
            void setBoundaryCondition(double value);


            /*! \brief Remove a constraint at one point for one dof.*/
            void removeConstraint(int dof, int idx, IndexType idxtype);
            /*! \brief Remove a constraint at one point for one dof given by a tag.*/
            void removeConstraint(std::string tag, int idx, IndexType idxtype){removeConstraint(nodeDOFs->index(tag), idx, idxtype);};
            /*! \brief Remove a constraint for one dof.*/
            void removeConstraint(int dof);
            /*! \brief Remove a constraint for one dof given by a tag.*/
            void removeConstraint(std::string tag){removeConstraint(nodeDOFs->index(tag));};

            /*! \brief Remove a boundary condition at one axis for one dof.*/
            void removeBoundaryCondition(int dof, MAxis ax);
            /*! \brief Remove a boundary condition at one axis for one dof given by a tag.*/
            void removeBoundaryCondition(std::string tag, MAxis ax){removeBoundaryCondition(nodeDOFs->index(tag), ax);};

            /*! \brief Returns if a dof is constrained in a given point.*/
            bool constrFlag(int dof, int idx, IndexType idxtype)
            {
                double constr = flagConstr->getValue(dof, idx, idxtype);
                return (constr>0.0)? true : false;
            }
            /*! \brief Returns if a dof (given by a tag) is constrained at a given point.*/
            bool constrFlag(std::string tag, int idx, IndexType idxtype){return constrFlag(nodeDOFs->index(tag), idx, idxtype);}

            /*! \brief Returns the value of the constraint of a dof in a given point.
             * It does not check if the point is actually constrain
             */
            double constrValue(int dof, int idx, IndexType idxtype)
            {
                return valuConstr->getValue(dof, idx, idxtype);
            }
            /*! \brief Returns the value of the constraint of a dof (given by a tag) at a given point.
             * It does not check if the point is actually constrain
             */
            double constrValue(std::string tag, int idx, IndexType idxtype){return constrValue(nodeDOFs->index(tag), idx, idxtype);};
            /** @} */ // end of Constrain Management



            /** @name Imposition of initial conditions
            *  @{
            */
            /*! \brief Set an initial condition at one point for one dof.*/
            void setInitialCondition(int dof, int idx, IndexType idxtype, double value);
            /*! \brief Set an initial condition at one point for one dof given by a tag.*/
            void setInitialCondition(std::string tag, int idx, IndexType idxtype, double value){setInitialCondition(nodeDOFs->index(tag), idx, idxtype, value);};
            /*! \brief Set initial condition value for one dof.*/
            void setInitialCondition(int dof, double value);
            /*! \brief Set initial condition value for one dof given by a tag.*/
            void setInitialCondition(std::string tag, double value){setInitialCondition(nodeDOFs->index(tag), value);};
            /*! \brief Set an initial condition function for one dof in 1D.*/
            void setInitialCondition(int dof, std::function<double(double)> f);
            /*! \brief Set an initial condition function for one dof (given by a tag) in 1D.*/
            void setInitialCondition(std::string tag, std::function<double(double)> f){setInitialCondition(nodeDOFs->index(tag), f);};
            /*! \brief Set an initial condition function for one dof in 2D.*/
            void setInitialCondition(int dof, std::function<double(double, double)> f);
            /*! \brief Set an initial condition function for one dof (given by a tag) in 2D.*/
            void setInitialCondition(std::string tag, std::function<double(double, double)> f){setInitialCondition(nodeDOFs->index(tag), f);};
            /*! \brief Set an initial condition function for one dof in 3D.*/
            void setInitialCondition(int dof, std::function<double(double, double, double)> f);
            /*! \brief Set an initial condition function for one dof (given by a tag) in 3D.*/
            void setInitialCondition(std::string tag, std::function<double(double, double, double)> f){setInitialCondition(nodeDOFs->index(tag), f);};
            /** @} */ // end of Imposition of initial conditions



            /** @name Field interpolation from reference coordinates
             *  @{
             */
            /*! \brief Returns the interpolated values at several points of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vector of integers that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the points
            * \param rCoords reference coordinates of the points
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<std::vector<double>> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<int>> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global);
            /*! \brief Returns the interpolated values at one points of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vector of integers that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the point
            * \param rCoords reference coordinates of the point
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<double> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<int>> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<int> elems = {elem};
                std::vector<std::vector<double>> rCoords_v = {rCoords};
                return interpolateField(fieldStrs, fields, elems, rCoords_v, type)[0];
            }

            /*! \brief Returns the interpolated values at several points of several fields in one field structure
            * \param fieldStr field structure containing the data to be interpolated
            * \param fields vector of integers that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the points
            * \param rCoords reference coordinates of the points
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<std::vector<double>> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<int> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<int>> fields_v = {fields};
                return interpolateField(fieldStrs, fields_v, elems, rCoords, type);
            }
            std::vector<std::vector<double>> interpolateDOFs(std::vector<int> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs, fields, elems, rCoords, type);}
            std::vector<std::vector<double>> interpolateDOFs0(std::vector<int> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs0, fields, elems, rCoords, type);}
            std::vector<std::vector<double>> interpolateAuxF(std::vector<int> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeAuxF, fields, elems, rCoords, type);}

            /*! \brief Returns the interpolated values at one point of several fields in one field structure
            * \param fieldStr field structure containing the data to be interpolated
            * \param fields vector of integers that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the point
            * \param rCoords reference coordinates of the point
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<double> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<int> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<int>> fields_v = {fields};
                std::vector<int> elems = {elem};
                std::vector<std::vector<double>> rCoords_v = {rCoords};
                return interpolateField(fieldStrs, fields_v, elems, rCoords_v, type)[0];
            }
            std::vector<double> interpolateDOFs(std::vector<int> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs, fields, elem, rCoords, type);}
            std::vector<double> interpolateDOFs0(std::vector<int> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs0, fields, elem, rCoords, type);}
            std::vector<double> interpolateAuxF(std::vector<int> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeAuxF, fields, elem, rCoords, type);}

            /*! \brief Returns the interpolated value at one point of a fields in one field structure
            * \param fieldStr field structure containing the data to be interpolated
            * \param field integer that identifies the field of the fieldStr to be interpolated
            * \param idx element id of the point
            * \param rCoords reference coordinates of the point
            * \param type specifies whether idx is a Local or a Global element number
            */
            double interpolateField(Teuchos::RCP<FieldStruct> fieldStr, int field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<int>> fields = {{field}};
                std::vector<int> elems = {elem};
                std::vector<std::vector<double>> rCoords_v = {rCoords};
                return interpolateField(fieldStrs, fields, elems, rCoords_v, type)[0][0];
            }
            double interpolateDOFs(int field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs, field, elem, rCoords, type);}
            double interpolateDOFs0(int field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs0, field, elem, rCoords, type);}
            double interpolateAuxF(int field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeAuxF, field, elem, rCoords, type);}


            /*! \brief Returns the interpolated values at several points of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vectors of integers that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the points
            */
            std::vector<std::vector<double>> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<int>> fields, std::vector<std::vector<double>> xCoords);
            /*! \brief Returns the interpolated values at one point of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vectors of integers that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the point
            */
            std::vector<double> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<int>> fields, std::vector<double> xCoords)
            {
                std::vector<std::vector<double>> xCoords_v = {xCoords};
                return interpolateField(fieldStrs, fields, xCoords_v)[0];
            }
            /*! \brief Returns the interpolated values at several points of several fields in
              the specified field structure
            * \param fieldStrs field structure containing the data to be interpolated
            * \param fields vectors of integers that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the points
            */
            std::vector<std::vector<double>> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<int> fields, std::vector<std::vector<double>> xCoords)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<int>> fields_v = {fields};
                return interpolateField(fieldStrs, fields_v, xCoords);
            }
            std::vector<std::vector<double>> interpolateDOFs(std::vector<int> fields, std::vector<std::vector<double>> xCoords){return interpolateField(nodeDOFs, fields, xCoords);}
            std::vector<std::vector<double>> interpolateDOFs0(std::vector<int> fields, std::vector<std::vector<double>> xCoords){return interpolateField(nodeDOFs0, fields, xCoords);}
            std::vector<std::vector<double>> interpolateAuxF(std::vector<int> fields, std::vector<std::vector<double>> xCoords){return interpolateField(nodeAuxF, fields, xCoords);}

            /*! \brief Returns the interpolated values at several points of several fields in a field structure
            * \param fieldStrs field structure containing the data to be interpolated
            * \param fields vectors of integers that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the points
            */
            std::vector<double> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<int> fields, std::vector<double> xCoords)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<int>> fields_v = {fields};
                std::vector<std::vector<double>> xCoords_v = {xCoords};
                return interpolateField(fieldStrs, fields_v, xCoords_v)[0];
            }
            std::vector<double> interpolateDOFs(std::vector<int> fields, std::vector<double> xCoords){return interpolateField(nodeDOFs, fields, xCoords);}
            std::vector<double> interpolateDOFs0(std::vector<int> fields, std::vector<double> xCoords){return interpolateField(nodeDOFs0, fields, xCoords);}
            std::vector<double> interpolateAuxF(std::vector<int> fields, std::vector<double> xCoords){return interpolateField(nodeAuxF, fields, xCoords);}

            /*! \brief Returns the interpolated value at a point of a fields in a field structure
            * \param fieldStrs field structure containing the data to be interpolated
            * \param field integer that identifies the field of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the point
            */
            double interpolateField(Teuchos::RCP<FieldStruct> fieldStr, int field, std::vector<double> xCoords)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<int>> fields_v = {{field}};
                std::vector<std::vector<double>> xCoords_v = {xCoords};
                return interpolateField(fieldStrs, fields_v, xCoords_v)[0][0];
            }
            double interpolateDOFs(int field, std::vector<double> xCoords){return interpolateField(nodeDOFs, field, xCoords);}
            double interpolateDOFs0(int field, std::vector<double> xCoords){return interpolateField(nodeDOFs0, field, xCoords);}
            double interpolateAuxF(int field, std::vector<double> xCoords){return interpolateField(nodeAuxF, field, xCoords);}

            // TAGS
            /*! \brief Returns the interpolated values at several points of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vector of tags that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the points
            * \param rCoords reference coordinates of the points
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<std::vector<double>> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<std::string>> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<std::vector<int>> fieldsId(fields.size());
                for (size_t i = 0; i < fields.size(); i++)
                {
                    for (size_t f = 0; f < fields[i].size(); f++)
                        fieldsId[i].push_back(fieldStrs[i]->index(fields[i][f]));
                }
                return interpolateField(fieldStrs, fieldsId, elems, rCoords, type);
            }
            /*! \brief Returns the interpolated values at one points of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vector of tags that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the point
            * \param rCoords reference coordinates of the point
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<double> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<std::string>> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<int> elems = {elem};
                std::vector<std::vector<double>> rCoords_v = {rCoords};
                return interpolateField(fieldStrs, fields, elems, rCoords_v, type)[0];
            }

            /*! \brief Returns the interpolated values at several points of several fields in one field structure
            * \param fieldStr field structure containing the data to be interpolated
            * \param fields vector of tags that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the points
            * \param rCoords reference coordinates of the points
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<std::vector<double>> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<std::string> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<std::string>> fields_v = {fields};
                return interpolateField(fieldStrs, fields_v, elems, rCoords, type);
            }
            std::vector<std::vector<double>> interpolateDOFs(std::vector<std::string> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs, fields, elems, rCoords, type);}
            std::vector<std::vector<double>> interpolateDOFs0(std::vector<std::string> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs0, fields, elems, rCoords, type);}
            std::vector<std::vector<double>> interpolateAuxF(std::vector<std::string> fields, std::vector<int> elems, std::vector<std::vector<double>> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeAuxF, fields, elems, rCoords, type);}

            /*! \brief Returns the interpolated values at one point of several fields in one field structure
            * \param fieldStr field structure containing the data to be interpolated
            * \param fields vector of tags that identify the fields of the fieldStr to be interpolated
            * \param idx element id of the point
            * \param rCoords reference coordinates of the point
            * \param type specifies whether idx is a Local or a Global element number
            */
            std::vector<double> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<std::string> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<std::string>> fields_v = {fields};
                std::vector<int> elems = {elem};
                std::vector<std::vector<double>> rCoords_v = {rCoords};
                return interpolateField(fieldStrs, fields_v, elems, rCoords_v, type)[0];
            }
            std::vector<double> interpolateDOFs(std::vector<std::string> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs, fields, elem, rCoords, type);}
            std::vector<double> interpolateDOFs0(std::vector<std::string> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs0, fields, elem, rCoords, type);}
            std::vector<double> interpolateAuxF(std::vector<std::string> fields, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeAuxF, fields, elem, rCoords, type);}

            /*! \brief Returns the interpolated value at one point of a fields in one field structure
            * \param fieldStr field structure containing the data to be interpolated
            * \param field tag that identifies the field of the fieldStr to be interpolated
            * \param idx element id of the point
            * \param rCoords reference coordinates of the point
            * \param type specifies whether idx is a Local or a Global element number
            */
            double interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::string field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<std::string>> fields = {{field}};
                std::vector<int> elems = {elem};
                std::vector<std::vector<double>> rCoords_v = {rCoords};
                return interpolateField(fieldStrs, fields, elems, rCoords_v, type)[0][0];
            }
            double interpolateDOFs(std::string field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs, field, elem, rCoords, type);}
            double interpolateDOFs0(std::string field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeDOFs0, field, elem, rCoords, type);}
            double interpolateAuxF(std::string field, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global){return interpolateField(nodeAuxF, field, elem, rCoords, type);}


            /*! \brief Returns the interpolated values at several points of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vectors of tags that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the points
            */
            std::vector<std::vector<double>> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<std::string>> fields, std::vector<std::vector<double>> xCoords)
            {
                std::vector<std::vector<int>> fieldsId(fields.size());
                for (size_t i = 0; i < fields.size(); i++)
                {
                    for (size_t f = 0; f < fields[i].size(); f++)
                        fieldsId[i].push_back(fieldStrs[i]->index(fields[i][f]));
                }
                return interpolateField(fieldStrs, fieldsId, xCoords);
            }
            /*! \brief Returns the interpolated values at one point of several fields in
              the specified field structures
            * \param fieldStrs vector of field structures containing the data to be interpolated
            * \param fields vectors of tags that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the point
            */
            std::vector<double> interpolateField(std::vector<Teuchos::RCP<FieldStruct>> fieldStrs, std::vector<std::vector<std::string>> fields, std::vector<double> xCoords)
            {
                std::vector<std::vector<double>> xCoords_v = {xCoords};
                return interpolateField(fieldStrs, fields, xCoords_v)[0];
            }
            /*! \brief Returns the interpolated values at several points of several fields in
              the specified field structure
            * \param fieldStrs field structure containing the data to be interpolated
            * \param fields vectors of tags that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the points
            */
            std::vector<std::vector<double>> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<std::string> fields, std::vector<std::vector<double>> xCoords)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<std::string>> fields_v = {fields};
                return interpolateField(fieldStrs, fields_v, xCoords);
            }
            std::vector<std::vector<double>> interpolateDOFs(std::vector<std::string> fields, std::vector<std::vector<double>> xCoords){return interpolateField(nodeDOFs, fields, xCoords);}
            std::vector<std::vector<double>> interpolateDOFs0(std::vector<std::string> fields, std::vector<std::vector<double>> xCoords){return interpolateField(nodeDOFs0, fields, xCoords);}
            std::vector<std::vector<double>> interpolateAuxF(std::vector<std::string> fields, std::vector<std::vector<double>> xCoords){return interpolateField(nodeAuxF, fields, xCoords);}

            /*! \brief Returns the interpolated values at several points of several fields in a field structure
            * \param fieldStrs field structure containing the data to be interpolated
            * \param fields vectors of tags that identify the fields of the fieldStr to be interpolated
            * \param xCoords vectors of coordinates of the points
            */
            std::vector<double> interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::vector<std::string> fields, std::vector<double> xCoords)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<std::string>> fields_v = {fields};
                std::vector<std::vector<double>> xCoords_v = {xCoords};
                return interpolateField(fieldStrs, fields_v, xCoords_v)[0];
            }
            std::vector<double> interpolateDOFs(std::vector<std::string> fields, std::vector<double> xCoords){return interpolateField(nodeDOFs, fields, xCoords);}
            std::vector<double> interpolateDOFs0(std::vector<std::string> fields, std::vector<double> xCoords){return interpolateField(nodeDOFs0, fields, xCoords);}
            std::vector<double> interpolateAuxF(std::vector<std::string> fields, std::vector<double> xCoords){return interpolateField(nodeAuxF, fields, xCoords);}

            /*! \brief Returns the interpolated value of a field
            * \param fieldStr field structure containing the data to be interpolated
            * \param field tag the identifies the field of the fieldStr to be interpolated
            * \param xCoords vector of coordinates of the point
            */
            double interpolateField(Teuchos::RCP<FieldStruct> fieldStr, std::string field, std::vector<double> xCoords)
            {
                std::vector<Teuchos::RCP<FieldStruct>> fieldStrs = {fieldStr};
                std::vector<std::vector<std::string>> fields_v = {{field}};
                std::vector<std::vector<double>> xCoords_v = {xCoords};
                return interpolateField(fieldStrs, fields_v, xCoords_v)[0][0];
            }
            /*! \brief Returns the interpolated value of a DOF
            * \param field tag the identifies the DOF to be interpolated
            * \param xCoords vector of coordinates of the point
            */
            double interpolateDOFs(std::string field, std::vector<double> xCoords){return interpolateField(nodeDOFs, field, xCoords);}
            /*! \brief Returns the interpolated value of a DOF0
            * \param field tag the identifies the DOF0 to be interpolated
            * \param xCoords vector of coordinates of the point
            */
            double interpolateDOFs0(std::string field, std::vector<double> xCoords){return interpolateField(nodeDOFs0, field, xCoords);}
            /*! \brief Returns the interpolated value of an auxiliary node field
            * \param field tag the identifies the AuxF to be interpolated
            * \param xCoords vector of coordinates of the point
            */
            double interpolateAuxF(std::string field, std::vector<double> xCoords){return interpolateField(nodeAuxF, field, xCoords);}
            /** @} */ // end of Field interpolation



            /** @name Ghost management
            *  @{
            */
            /*! \brief Update the information of the ghost points
             * Setting the argument to true, create the importing structures.
             * This is done during DOFsHandler Update and should not be used by the user.
             */
            void UpdateGhosts(bool genImporters = false);
            /** @} */ // end of Ghost management



            /** @name Information access methods
            *  @{
            */
            /*! \brief Update the information of the ghosts points
             * Setting the argument to true, create the importing structures.
             * This is done during DOFsHandler Update and should not be used by the user.
             */
            int hiperIdx(int dof, int idx, IndexType type = IndexType::Global);
            void locHiperIdx(int dof, int idx, IndexType type = IndexType::Global);
            int offs_hiperItem(int part = -1) const;
            /** @} */ // end of information access methods



            /** @name I/O
             *  @{
             */
            void outFullData(std::ostream& os, OutputMode mode, bool printAux) const;
            /*! \brief Prints all the DOFsHandler information in hiperlife's own format.
            * \param file_prefix name prefix of the output file, a '.hl' extension will be added.
            * \param mode OutputMode of the data (either text or binary)
            * \param printAux If true, all the auxiliary fields will be printed.
            * \param Time Simulation time.
            * \param globalData Vector of global data
            */
            int printFile(std::string test_prefix, OutputMode mode = OutputMode::Text, bool printAux = false, double time = -1.0, std::vector<double> globalData = {});
            /*! \brief Prints a legacy vtk file with all the DOFsHandler information.
            * This is here for compatibility reasons and for small problems. Don't us it
            * when computing big systems.
            * \param file_prefix name prefix of the output file, a '.vtk' extension will be added.
            * \param printAux If true, all the auxiliary fields will be printed.
            */
            int printFileLegacyVtk(std::string file_prefix, bool printAux = false);

            /*! \brief Prints vtk files (vtu/vtm) with all the DOFsHandler information.
            * \param file_prefix name prefix of the output file, a '.vtu'/'.vtm' extension will be added.
            * \param printAux If true, all the auxiliary fields will be printed.
            */
#ifdef HL_VTK
            int printFileVtk(std::string file_prefix, bool printAux, double time = -1.0, std::vector<double> globalData = {}, std::vector<std::string> globalDataNames = {});
#endif
            /*! \brief Prints a legacy csv file with all the DOFsHandler information.
            * This is here for compatibility reasons and for small problems. Don't use it
            * when computing big systems.
            * \param file_prefix name prefix of the output file, a '.csv' extension will be added.
            * \param printAux If true, all the auxiliary fields will be printed.
            */
            int printFileLegacyCSV(std::string file_prefix, bool printAux = false);
            /** @} */ // end of I/O



            /** @name Expert users and developers only
             *  @{ */
            // Mesh data structures
            Teuchos::RCP<DistributedMesh> mesh  = Teuchos::null;

            // DOFs data structures
            Teuchos::RCP<FieldStruct> nodeDOFs  = Teuchos::null;
            Teuchos::RCP<FieldStruct> nodeDOFs0 = Teuchos::null;
            Teuchos::RCP<FieldStruct> nodeAuxF  = Teuchos::null;
            Teuchos::RCP<FieldStruct> elemAuxF  = Teuchos::null;

            // Constraints data structures
            Teuchos::RCP<FieldStruct> flagConstr = Teuchos::null;
            Teuchos::RCP<FieldStruct> valuConstr = Teuchos::null;

            std::vector<int> _offs_HiperProbl;
            bool subDOFsHandler{false};
            void computeOffsHiperProbl(int partDHandOffset);

            // Methods for update ghosts of different structures separately
            void UpdateConstrainGhosts(bool genImporters = false);
            void UpdateDOFsGhosts(bool genImporters = false);
            void UpdateDOFs0Ghosts(bool genImporters = false);
            void UpdateAuxFGhosts(bool genImporters = false);

            // Immersed
            void setDofTags(std::vector<std::string> dofTags) {_dofTags = dofTags;};
            std::vector<std::string> _getDofTags() {return _dofTags;};
            /** @} */ // end of Expert users and developers only


        private:
            int _stdIntPts{};
            BasisFuncType _temp_basisFuncType;

            std::string _tmp_legFileName;
            std::string _tmp_filePrefix;
            OutputMode _tmp_outputmode{OutputMode::Undefined};
            std::istream* _tmp_istream{nullptr};

            std::string _stdFile(std::string prefix);
            void _updateFile();
            void _updateIStream();
            void _update_new();
            void _update_legVtkFile();

            std::vector<std::vector<std::string>> _fieldNames(bool printAux);

            // Immersed
            std::vector<std::string> _dofTags{};
            void _freezeExtElements();
    };
}

#endif // DOFSHANDLER_H
