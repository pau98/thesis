/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <fstream>

#include "hl_LoadDOFsHandler.h"
#include "hl_LoadMesh.h"
#include "hl_DistributedMesh.h"

#include "hl_DOFsHandler.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    DOFsHandler::DOFsHandler(Teuchos::RCP<DistributedMesh> inputMesh) : mesh(inputMesh)
    {
    }

    void DOFsHandler::setNumDOFs(int dofs)
    {
        nodeDOFs = rcp(new FieldStruct("nodeDOFs", _comm));
        nodeDOFs0 = rcp(new FieldStruct("nodeDOFs0", _comm));

        nodeDOFs->setNFlds(dofs);
        nodeDOFs0->setNFlds(dofs);
    }

    void DOFsHandler::setDOFs(std::vector<std::string> tags)
    {
        nodeDOFs = rcp(new FieldStruct("nodeDOFs", _comm));
        nodeDOFs0 = rcp(new FieldStruct("nodeDOFs0", _comm));

        nodeDOFs->setNFlds(tags);
        nodeDOFs0->setNFlds(tags);
    }

    void DOFsHandler::setNumNodeAuxF(int dofs)
    {
        if (dofs <= 0)
            return;

        nodeAuxF = rcp(new FieldStruct("nodeAuxF", _comm));
        nodeAuxF->setNFlds(dofs);
    }

    void DOFsHandler::setNodeAuxF(std::vector<std::string> tags)
    {
        if (tags.size() <= 0)
            return;

        nodeAuxF = rcp(new FieldStruct("nodeAuxF", _comm));
        nodeAuxF->setNFlds(tags);
    }

    void DOFsHandler::setNumElemAuxF(int dofs)
    {
        if (dofs <= 0)
            return;

        elemAuxF = rcp(new FieldStruct("elemAuxF", _comm));
        elemAuxF->setNFlds(dofs);
    }

    void DOFsHandler::setElemAuxF(std::vector<std::string> tags)
    {
        if (tags.size() <= 0)
            return;

        elemAuxF = rcp(new FieldStruct("elemAuxF", _comm));
        elemAuxF->setNFlds(tags);
    }


    void DOFsHandler::Update()
    {
        _classTag = "DOFsHandler";
        if (_nameTag == "DistributedClass")
            _nameTag = "DOFsHandler";

        if (_tmp_legFileName == "" && mesh != null)
            _update_new();
        else if (_tmp_filePrefix != "" && mesh == null)
            _updateFile();
        else if (_tmp_legFileName != "" && mesh == null)
            _update_legVtkFile();
        else
            throw runtime_error("DOFsHandler:Update: We cannot choose a right way of creating DOFsHandler object. \n\
            Please check that and rerun. Goodbye!");


        // Create DoF Structure
        Epetra_BlockMap map = mesh->_graph->_adjcyNodeNode->RowMap();


        UpdateGhosts(true);

        // Immersed-> Freeze exterior elements
        if(_dofTags.size() != 0)
            _freezeExtElements();

    }

    void DOFsHandler::_freezeExtElements()
    {
        std::vector<int> intTags = {3,5,7};
        std::vector<std::string> dofTags = _getDofTags();
        std::vector<std::string> regionTags = mesh->_regionTags();
        std::vector<int> dofIntTags(dofTags.size());
        for(int tag{}; tag < dofTags.size(); tag++)
        {
            auto it = find(regionTags.begin(), regionTags.end(), dofTags[tag]);
            dofIntTags[tag] = intTags[it-regionTags.begin()];
        }

        // Freeze exterior elements
        for(int i{}; i < dofTags.size(); i++)
            setConstraint(i, 0.0);
        for (int e = 0; e < mesh->loc_nElem(); e++)
        {
            for(int i{}; i < dofTags.size(); i++)
            {
                if (mesh->_elemFlags->getValue(1, e, IndexType::Local)%dofIntTags[i] == 0)
                {
                    vector<int> nbors = mesh->_connec->getNborList(e, IndexType::Local);
                    for (auto n: nbors)
                    {
                        if (mesh->isNodeInPart(n))
                        {
                            removeConstraint(i, n, IndexType::Global);
                            // nodeAuxF->setValue("const", n, IndexType::Global, intTags[i]);
                        }
                    }
                }
            }
        }
    }

    void DOFsHandler::_update_new()
    {

        if (mesh == null)
            throw runtime_error("DOFsHandler::Update: Mesh is not set");

        mesh->setNameTag("DisMesh");

        // Create DoF Structure
        Epetra_BlockMap map = mesh->_graph->_adjcyNodeNode->RowMap();

        nodeDOFs->setBlockMap(map);
        nodeDOFs->Update();

        nodeDOFs0->setBlockMap(map);
        nodeDOFs0->Update();


        flagConstr = rcp(new FieldStruct("flagConstr", _comm));
        flagConstr->setBlockMap(map);
        flagConstr->genDefaultTags(*this, numDOFs(), "flagConstr");
        flagConstr->Update();
        flagConstr->setValue(-1.0);

        valuConstr = rcp(new FieldStruct("valuConstr", _comm));
        valuConstr->setBlockMap(map);
        valuConstr->genDefaultTags(*this, numDOFs(), "valuConstr");
        valuConstr->Update();

        if (nodeAuxF != Teuchos::null)
        {
            if (nodeAuxF->numFlds() != 0)
            {
                nodeAuxF->setBlockMap(map);
                nodeAuxF->Update();
            }
        }

        if (elemAuxF != Teuchos::null)
        {
            if (elemAuxF->numFlds() != 0)
            {
                auto map = rcp(new Epetra_BlockMap(mesh->nElem(), mesh->loc_nElem(), 1, 0, *_epComm));

                elemAuxF->setBlockMap(mesh->_adjcyEN->_adjcyElemNodes->Map());
                elemAuxF->Update();
            }
        }

    }

    void DOFsHandler::_update_legVtkFile()
    {
            ifstream infile(_tmp_legFileName);
            if(!infile.is_open())
                throw runtime_error("DOFsHandler::_update_legVtkFile: The input file (" + _tmp_legFileName + ") does not exist.\n Please check it and rerun. Goodbye!");
            infile.close();

            DOFsHandlerParameters dhandPars(_tmp_legFileName);

            int nPts{}, nElem{};
            int nVert = dhandPars.nVert;
            int *connec, *iCreases;
            double *xNodes;
            loadMesh(nPts, nElem, nVert, connec, xNodes, iCreases, _tmp_legFileName, "legacyVtk");


            mesh = rcp(new DistributedMesh("DisMesh", _comm));

            // Equivalent to DistributedMesh::UpdateBasic()
            mesh->setElemType(ElemType::Triang);
            mesh->setNElem(dhandPars.nElem);
            mesh->setGlobConnec(connec);

            mesh->setNPts(dhandPars.nPts);
            mesh->setNDim(dhandPars.nDim);

            mesh->setGlobCoords(xNodes);
            mesh->setGlobCreases(iCreases);
            mesh->setBalanceMesh(true);

            mesh->setBasisFuncType(_temp_basisFuncType);

            mesh->_graph->setLocNPts(dhandPars.proc_nPts[_myRank]);
            mesh->_connec->setLocNElem(dhandPars.proc_nElem[_myRank]);

            // Finishing the Mesh Update
            mesh->UpdateBasic();
            mesh->UpdateComplete();

            double *globFields;
            vector<string> labels(dhandPars.numDOFs);
            for (int i = 0; i< dhandPars.numDOFs; i++)
                labels[i] = "DOF_" + to_string(i);

            loadFields(globFields, labels, nPts, _tmp_legFileName, "legacyVtk");

            Epetra_BlockMap map = mesh->_graph->_adjcyNodeNode->RowMap();
            int numDOFs = dhandPars.numDOFs;


            nodeDOFs = rcp(new FieldStruct("nodeDOFs", _comm));
            nodeDOFs->setBlockMap(map);
            nodeDOFs->setGlobFields(globFields);
            nodeDOFs->setNFlds(numDOFs);
            nodeDOFs->Update();

            nodeDOFs0 = rcp(new FieldStruct("nodeDOFs0", _comm));
            nodeDOFs0->setBlockMap(map);
            nodeDOFs0->setNFlds(numDOFs);
            nodeDOFs0->Update();

            flagConstr = rcp(new FieldStruct("flagConstr", _comm));
            flagConstr->setBlockMap(map);
            flagConstr->setNFlds(numDOFs);
            flagConstr->Update();
            flagConstr->setValue(-1.0);

            valuConstr = rcp(new FieldStruct("valuConstr", _comm));
            valuConstr->setBlockMap(map);
            valuConstr->setNFlds(numDOFs);
            valuConstr->Update();

            // if (_numNodeAuxF != 0)
            // {
            //     nodeAuxF = rcp(new FieldStruct("nodeAuxF", _comm));
            //     nodeAuxF->setBlockMap(map);
            //     nodeAuxF->setNFlds(_numNodeAuxF);
            //     nodeAuxF->Update();
            // }

    }

    void DOFsHandler::UpdateConstrainGhosts(bool genImporters)
    {
        if (genImporters == false)
        {
            flagConstr->UpdateGhosts();
            valuConstr->UpdateGhosts();
        }
        else
        {
            vector<int>& listGhosts = mesh->listGhosts();
            flagConstr->UpdateGhosts(listGhosts);
            valuConstr->UpdateGhosts(listGhosts);
        }
    }

    void DOFsHandler::UpdateDOFsGhosts(bool genImporters)
    {
        if (genImporters == false)
        {
            nodeDOFs->UpdateGhosts();
        }
        else
        {
            vector<int>& listGhosts = mesh->listGhosts();
            nodeDOFs->UpdateGhosts(listGhosts);
        }
    }

    void DOFsHandler::UpdateDOFs0Ghosts(bool genImporters)
    {
        if (genImporters == false)
        {
            nodeDOFs0->UpdateGhosts();
        }
        else
        {
            vector<int>& listGhosts = mesh->listGhosts();
            nodeDOFs0->UpdateGhosts(listGhosts);
        }
    }

    void DOFsHandler::UpdateAuxFGhosts(bool genImporters)
    {

        if (nodeAuxF != null)
        {
            if (genImporters == false)
            {
                nodeAuxF->UpdateGhosts();
            }
            else
            {
                vector<int>& listGhosts = mesh->listGhosts();
                nodeAuxF->UpdateGhosts(listGhosts);
            }
        }

        if (elemAuxF != null)
        {
            if (genImporters == false)
            {
                elemAuxF->UpdateGhosts();
            }
            else
            {
//                vector<int>& listGhosts = mesh->listGhosts();
                elemAuxF->UpdateGhosts({});
            }
        }

    }

    void DOFsHandler::UpdateGhosts(bool genImporters)
    {
        UpdateConstrainGhosts(genImporters);
        UpdateDOFsGhosts(genImporters);
        UpdateDOFs0Ghosts(genImporters);
        UpdateAuxFGhosts(genImporters);
    }


    void DOFsHandler::setConstraint(int dof, int idx, IndexType idxtype, double value)
    {
        flagConstr->setValue(dof, idx, idxtype, 1.0);
        valuConstr->setValue(dof, idx, idxtype, value);
    }

    void DOFsHandler::setConstraint(int dof, double value)
    {
        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            setConstraint(dof, i, IndexType::Local, value);
        }
    }


    void DOFsHandler::setBoundaryCondition(int dof, int idx, IndexType idxtype, double value)
    {
        if (idxtype == IndexType::Local)
        {
            int crease = mesh->nodeCrease(idx, idxtype);
            if (crease > 0)
                setConstraint(dof, idx, idxtype, value);
        }
        else
        {
            if (mesh->isNodeInPart(idx))
            {
                int loc_idx = mesh->_graph->locIdx(idx);
                int crease = mesh->nodeCrease(loc_idx, idxtype);
                if (crease > 0)
                    setConstraint(dof, loc_idx, idxtype, value);
            }
        }
    }

    void DOFsHandler::setBoundaryCondition(int dof, MAxis ax, double value)
    {
        //Get max or min axis
        int myMAxis = getMAxis(ax);

        //Checks
        int myPDim = getAxis(ax) + 1;
        if (myPDim > mesh->_pDim)
            throw std::runtime_error("setBoundaryCondition: MAxis is greater than pDim.");

        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            int axis = mesh->nodeMAxis(i, IndexType::Local);
            if (axis % myMAxis == 0)
                setConstraint(dof, i, IndexType::Local, value);
        }
    }

    void DOFsHandler::setBoundaryCondition(int dof, MAxis ax, std::function<double(double)> f)
    {
        //Get max or min axis and axis
        int myMAxis = getMAxis(ax);
        int myAxis = getAxis(ax);

        //Checks
        int myPDim = myAxis + 1;
        if (myPDim > mesh->_pDim)
            throw std::runtime_error("setBoundaryCondition: MAxis is greater than pDim.");

        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            int axis = mesh->nodeMAxis(i, IndexType::Local);
            if (axis % myMAxis == 0)
            {
                double chi;
                if (myAxis == 0)
                    chi = mesh->nodeCoord(i, 1, IndexType::Local);
                else
                    chi = mesh->nodeCoord(i, 0, IndexType::Local);
                setConstraint(dof, i, IndexType::Local, f(chi));
            }
        }

    }

    void DOFsHandler::setBoundaryCondition(int dof, MAxis ax, std::function<double(double, double)> f)
    {
        //Get max or min axis and axis
        int myMAxis = getMAxis(ax);
        int myAxis = getAxis(ax);

        //Checks
        int myPDim = myAxis + 1;
        if (myPDim > mesh->_pDim)
            throw std::runtime_error("setBoundaryCondition: MAxis is greater than pDim.");

        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            int axis = mesh->nodeMAxis(i, IndexType::Local);
            if (axis % myMAxis == 0)
            {
                double chi, eta;
                if (myAxis == 0)
                {
                    chi = mesh->nodeCoord(i, 1, IndexType::Local);
                    eta = mesh->nodeCoord(i, 2, IndexType::Local);
                }
                else if (myAxis == 1)
                {
                    chi = mesh->nodeCoord(i, 0, IndexType::Local);
                    eta = mesh->nodeCoord(i, 2, IndexType::Local);
                }
                else if (myAxis == 2)
                {
                    chi = mesh->nodeCoord(i, 0, IndexType::Local);
                    eta = mesh->nodeCoord(i, 1, IndexType::Local);
                }
                setConstraint(dof, i, IndexType::Local, f(chi, eta));
            }
        }
    }

    void DOFsHandler::setBoundaryCondition(int dof, double value)
    {
        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            int crease = mesh->nodeCrease(i, IndexType::Local);
            if (crease > 0)
                setConstraint(dof, i, IndexType::Local, value);
        }
    }

    void DOFsHandler::setBoundaryCondition(double value)
    {
        //Loop over dofs
        for (int d = 0; d < numDOFs(); d++)
        {
            setBoundaryCondition(d, value);
        }
    }


    void DOFsHandler::removeConstraint(int dof, int idx, IndexType idxtype)
    {
        flagConstr->setValue(dof, idx, idxtype, -1.0);
    }

    void DOFsHandler::removeConstraint(int dof)
    {
        flagConstr->setValue(dof, -1.0);
    }


    void DOFsHandler::removeBoundaryCondition(int dof, MAxis ax)
    {
        //Get max or min axis
        int myMAxis = getMAxis(ax);

        //Checks
        int myPDim = getAxis(ax) + 1;
        if (myPDim > mesh->_pDim)
            throw std::runtime_error("removeBoundaryCondition: MAxis is greater than pDim.");

        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            int axis = mesh->nodeMAxis(i, IndexType::Local);
            if (axis % myMAxis == 0)
                removeConstraint(dof, i, IndexType::Local);
        }
    }


    void DOFsHandler::setInitialCondition(int dof, int idx, IndexType idxtype, double value)
    {
        nodeDOFs->setValue(dof, idx, idxtype, value);
    }

    void DOFsHandler::setInitialCondition(int dof, double value)
    {
        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            setInitialCondition(dof, i, IndexType::Local, value);
        }
    }

    void DOFsHandler::setInitialCondition(int dof, std::function<double(double)> f)
    {
        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            double x = mesh->nodeCoord(i, 0, IndexType::Local);
            setInitialCondition(dof, i, IndexType::Local, f(x));
        }
    }

    void DOFsHandler::setInitialCondition(int dof, std::function<double(double, double)> f)
    {
        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            double x = mesh->nodeCoord(i, 0, IndexType::Local);
            double y = mesh->nodeCoord(i, 1, IndexType::Local);
            setInitialCondition(dof, i, IndexType::Local, f(x, y));
        }
    }

    void DOFsHandler::setInitialCondition(int dof, std::function<double(double, double, double)> f)
    {
        //Loop over points
        for (int i = 0; i < mesh->loc_nPts(); i++)
        {
            double x = mesh->nodeCoord(i, 0, IndexType::Local);
            double y = mesh->nodeCoord(i, 1, IndexType::Local);
            double z = mesh->nodeCoord(i, 2, IndexType::Local);
            setInitialCondition(dof, i, IndexType::Local, f(x, y, z));
        }
    }


    vector<vector<double>> DOFsHandler::interpolateField(vector<RCP<FieldStruct>> fieldStrs, vector<vector<int>> fields, vector<int> elems, vector<vector<double>> rCoords, IndexType type)
    {
        // Check
        if (fieldStrs.size() != fields.size())
            throw runtime_error("DOFsHandler::interpolateField: Number of fieldStrs and fields don't match.");

        // Resize for all fields
        for (size_t s = 0; s < fieldStrs.size(); s++)
        {
            if (fields[s].size() == 0)
            {
                fields[s].resize(fieldStrs[s]->numFlds());
                std::iota(fields[s].begin(), fields[s].end(), 0);
            }
        }

        // Initialize
        int tot_nFields{};
        for (auto f: fields)
            tot_nFields += f.size();
        vector<vector<double>> values(elems.size(), vector<double>(tot_nFields, 0.0));

        // Interpolate
        for (size_t n = 0; n < elems.size(); n++)
        {
            // Initialize
            int elem = elems[n];

            // Compute basis functions at rCoords
            int tag = mesh->_basisFunctions->getTag(elem, type);
            vector<vector<double>> BF = mesh->_basisFunctions->computeBasisFunctionsReference(rCoords[n], tag, 0);

            // Compute interpolation
            int eNN = mesh->_adjcyEN->getNumNbors(elem, type);
            vector<int> nbors = mesh->_adjcyEN->getNborList(elem, type);
            int k{};
            for (size_t s = 0; s < fieldStrs.size(); s++)
            {
                for (size_t f = 0; f < fields[s].size(); f++)
                {
                    for (int i = 0; i < eNN; i++)
                        values[n][k] += fieldStrs[s]->getValue(fields[s][f], nbors[i])*BF[0][i];
                    k++;
                }
            }
        }

        return values;
    }

    vector<vector<double>> DOFsHandler::interpolateField(vector<RCP<FieldStruct>> fieldStrs, vector<vector<int>> fields, vector<vector<double>> xCoords)
    {
        // Check
        if (mesh->elementLocator() == Teuchos::null)
            throw runtime_error("DOFsHandler::interpolateField: The element locator is empty.");

        // Initialize
        int nPoints = xCoords.size();

        // Search elements in partition
        vector<int> elems;
        vector<vector<double>> rCoords;
        vector<double> dists = mesh->searchElement(elems, rCoords, xCoords);

        // Get (processor) location of the min distances
        struct distsAndProcs
        {
             double dist;
             int rank;
        };
        distsAndProcs * out = new distsAndProcs[nPoints];
        distsAndProcs * in  = new distsAndProcs[nPoints];
        for (int n = 0; n < nPoints; n++)
        {
            out[n].dist = dists[n];
            out[n].rank = _myRank;
        }
        MPI_Allreduce(out, in, nPoints, MPI_DOUBLE_INT, MPI_MINLOC, comm());

        // Interpolate fields locally
        int tot_nFields{};
        for (auto f: fields)
            tot_nFields += f.size();
        vector<vector<double>> values(nPoints, vector<double>(tot_nFields, 0.0));
        for (int n = 0; n < nPoints; n++)
        {
            // Check
            if (in[n].dist < 0.0)
                throw runtime_error("DOFsHandler::interpolateField: Error finding point. Element not found.");

            // Interpolate
            if (_myRank == in[n].rank)
                values[n] = interpolateField(fieldStrs, fields, elems[n], rCoords[n], IndexType::Global);
        }

        // Share interpolation //FIXME:: We are doing a loop, is there a more efficient way?
        for (int n = 0; n < nPoints; n++)
            MPI_Bcast(values[n].data(), tot_nFields, MPI_DOUBLE, in[n].rank, comm());

        // Delete
        delete[] out;
        delete[] in;

        // FIXME:: For some reason i dont understand, the next option is slower
        ////////////////////////////////////////////////////////////////////////////////////////////////
        // // Interpolate fields locally
        // int tot_nFields{};
        // for (auto f: fields)
        //     tot_nFields += f.size();
        // vector<vector<double>> values(nPoints, vector<double>(tot_nFields, 0.0));
        // for (int n = 0; n < nPoints; n++)
        // {
        //     if (mesh->isElemInPart(elems[n]))
        //     {
        //     // // Check
        //     // if (in[n].dist < 0.0)
        //     //     throw runtime_error("DOFsHandler::interpolateField: Error finding point. Element not found.");

        //     // // Interpolate
        //     // if (_myRank == in[n].rank)
        //         values[n] = interpolateField(fieldStrs, fields, elems[n], rCoords[n], IndexType::Global);
        //     }
        // }

        // // Share interpolation //FIXME:: We are doing a loop, is there a more efficient way?
        // for (int n = 0; n < nPoints; n++)
        //     MPI_Bcast(values[n].data(), tot_nFields, MPI_DOUBLE, mesh->elemPartition(elems[n]), comm());
        ////////////////////////////////////////////////////////////////////////////////////////////////

        return values;
    }


    vector<vector<std::string>> DOFsHandler::_fieldNames(bool printAux)
    {
        //Get node tags
        vector<vector<std::string>> vFieldNames(3);
        vector<std::string> nodeTags = nodeDOFs->tags();
        if (nodeTags[0] != "Field_0")
        {
            vFieldNames[0] = nodeTags;
        }
        else
        {
            for (int i = 0; i < numDOFs(); i++)
                vFieldNames[0].push_back("DOF_" + to_string(i));
        }

        //Get node auxiliary tags
        if ((printAux == true) and (numNodeAuxF() > 0))
        {
            vector<std::string> auxTags;
            auxTags = nodeAuxF->tags();
            if (auxTags[0] != "Field_0")
            {
                vFieldNames[1] = auxTags;
            }
            else
            {
                for (int i = 0; i < numNodeAuxF(); i++)
                    vFieldNames[1].push_back("AUX_" + to_string(i));
            }
        }

        //Get element auxiliary tags
        if ((printAux == true) and (numElemAuxF() > 0))
        {
            vector<std::string> auxTags;
            auxTags = elemAuxF->tags();
            if (auxTags[0] != "Field_0")
            {
                vFieldNames[2] = auxTags;
            }
            else
            {
                for (int i = 0; i < numElemAuxF(); i++)
                    vFieldNames[2].push_back("AUX_" + to_string(i));
            }
        }

        return vFieldNames;
    }

    int DOFsHandler::printFileLegacyVtk(string file_prefix, bool printAux)
    {
        //Print
        if (printAux == false or (numNodeAuxF() == 0 and numElemAuxF() == 0))
            mesh->_printFileLegacyVtk(file_prefix, {&*nodeDOFs->_data}, _fieldNames(printAux));
        else if (printAux == true and numNodeAuxF() > 0 and numElemAuxF() == 0)
            mesh->_printFileLegacyVtk(file_prefix, {&*nodeDOFs->_data, &*nodeAuxF->_data}, _fieldNames(printAux));
        else if (printAux == true and numNodeAuxF() == 0 and numElemAuxF() > 0)
            mesh->_printFileLegacyVtk(file_prefix, {&*nodeDOFs->_data, nullptr, &*elemAuxF->_data}, _fieldNames(printAux));
        else if (printAux == true and numNodeAuxF() > 0 and numElemAuxF() > 0)
            mesh->_printFileLegacyVtk(file_prefix, {&*nodeDOFs->_data, &*nodeAuxF->_data, &*elemAuxF->_data}, _fieldNames(printAux));

        return 0;
    }

#ifdef HL_VTK
    int DOFsHandler::printFileVtk(string file_prefix, bool printAux, double time, std::vector<double> globalData, std::vector<std::string> globalNames)
    {
        if (time>=0)
        {
            globalNames.push_back("time");
            globalData.push_back(time);
        }

        // if (printAux == false or (numNodeAuxF() == 0 and numElemAuxF() == 0))
        // {
        //     mesh->_printFileVtk(file_prefix, {nodeDOFs}, _fieldNames(printAux), globalData, globalNames);
        // }
        // else
        // {
        //     if (printAux == true and numNodeAuxF() > 0 and numElemAuxF() == 0)
        //         mesh->_printFileVtk(file_prefix, {nodeDOFs, nodeAuxF}, _fieldNames(printAux), globalData, globalNames);
        //     else if (printAux == true and numNodeAuxF() == 0 and numElemAuxF() > 0)
        //         mesh->_printFileVtk(file_prefix, {nodeDOFs, nullptr, elemAuxF}, _fieldNames(printAux), globalData, globalNames);
        //     else if (printAux == true and numNodeAuxF() > 0 and numElemAuxF() > 0)
        //         mesh->_printFileVtk(file_prefix, {nodeDOFs, nodeAuxF, elemAuxF}, _fieldNames(printAux), globalData, globalNames);

        // }

        if (printAux == true)
            mesh->_printFileVtk(file_prefix, {nodeDOFs, nodeAuxF, elemAuxF}, _fieldNames(printAux), globalData, globalNames);
        else
            mesh->_printFileVtk(file_prefix, {nodeDOFs}, _fieldNames(printAux), globalData, globalNames);

        return 0;
    }
#endif

    int DOFsHandler::printFileLegacyCSV(string file_prefix, bool printAux)
    {
        //Print
        if (printAux == false or numNodeAuxF() == 0)
            mesh->_printFileLegacyCSV(file_prefix, {&*nodeDOFs->_data}, _fieldNames(printAux));
        else
            mesh->_printFileLegacyCSV(file_prefix, {&*nodeDOFs->_data, &*nodeAuxF->_data}, _fieldNames(printAux));

        return 0;
    }

    void DOFsHandler::computeOffsHiperProbl(int partDHandOffset)
    {
        int loc_offset = partDHandOffset;
        _offs_HiperProbl.resize(_numProcs);

        MPI_Allgather(&loc_offset, 1, MPI_INT, _offs_HiperProbl.data(), 1, MPI_INT, _comm);
    }

    int DOFsHandler::hiperIdx(int dof, int node, IndexType type)
    {
        if(type == IndexType::Local)
        {
            // The node is always in the calling partition
            int locIdx = numDOFs() * node + dof;

            return offs_hiperItem() + locIdx;
        }
        else
        {
            // We proceed without making assumptions of the node partition
            int part = mesh->_graph->getItemPartition(node);
            int n_locIdx = node - mesh->_graph->offs_nItem(part);
            int locIdx = numDOFs() * n_locIdx + dof;

            return offs_hiperItem(part) + locIdx;
        }

    }

    void DOFsHandler::locHiperIdx(int dof, int idx, IndexType type)
    {
        (void)dof; (void)idx; (void)type;
        clog << "DOFsHandler::locHiperIdx: Not implemented" << endl;
        throw bad_function_call();
    }

    int DOFsHandler::offs_hiperItem(int part) const
    {
        int ret_p = (part==-1)?_myRank:part;

        return _offs_HiperProbl[ret_p];
    }

}
