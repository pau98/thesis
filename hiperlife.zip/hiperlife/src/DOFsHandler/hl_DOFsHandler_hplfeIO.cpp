/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iomanip>
#include <iostream>
#include <ostream>
#include <istream>
#include <fstream>
#include <string>

#include <mpi.h>

#include <Epetra_MpiComm.h>
#include <Epetra_CrsGraph.h>
#include <Epetra_FECrsGraph.h>

#include "hl_DOFsHandler.h"
#include "hl_TypeDefs.h"
#include "hl_IO_Aux.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    string DOFsHandler::_stdFile(string prefix)
    {
        if (prefix[prefix.size() - 1] == '.')
            return prefix  + to_string(_myRank) + ".hl";
        else
            return prefix + "." + to_string(_myRank) + ".hl";
    }

    void DOFsHandler::outFullData(std::ostream& os, OutputMode mode, bool printAux) const
    {
        //Output headers
        vector<int> ibuff(4);
        ibuff[0] = numDOFs();
        ibuff[1] = numNodeAuxF();
        ibuff[2] = numElemAuxF();
        ibuff[3] = _stdIntPts;
        IO::printData(os, ibuff.data(), ibuff.size(), mode);

        //Output mesh
        os << mesh->nameTag() << " " <<  mesh->classTag() << " " << str(mode) << endl;
        mesh->outFullData(os, mode);

        //Output DOFs
        os << nodeDOFs->nameTag()  << " " << nodeDOFs->classTag() << " " << str(mode) << endl;
        nodeDOFs->outFullData(os, mode);

        //Output DOFs0
        os << nodeDOFs0->nameTag()  << " " << nodeDOFs0->classTag() << " " << str(mode) << endl;
        nodeDOFs0->outFullData(os, mode);

        //Output constraints
        os << flagConstr->nameTag()  << " " << flagConstr->classTag() << " " << str(mode) << endl;
        flagConstr->outFullData(os, mode);
        os << valuConstr->nameTag()  << " " << valuConstr->classTag() << " " << str(mode) << endl;
        valuConstr->outFullData(os, mode);

        //Output auxiliary node fields
        if (printAux && numNodeAuxF() > 0)
        {
            os << nodeAuxF->nameTag()  << " " << nodeAuxF->classTag() << " " << str(mode) << endl;
            nodeAuxF->outFullData(os, mode);
        }

        //Output auxiliary element fields
        if (printAux && numElemAuxF() > 0)
        {
            os << elemAuxF->nameTag()  << " " << elemAuxF->classTag() << " " << str(mode) << endl;
            elemAuxF->outFullData(os, mode);
        }

        // os << _nodeData->nameTag()  << " " << _nodeData->classTag() << " " << str(mode) << endl;
        // _nodeData->outFullData(os, mode);
        // os << _nodeFlags->nameTag()  << " " << _nodeFlags->classTag() << " " << str(mode) << endl;
        // _nodeFlags->outFullData(os, mode);
    }



    int DOFsHandler::printFile(string test_prefix, OutputMode mode, bool printAux, double time, std::vector<double> globalData)
    {
        ofstream ofile;
        string fileName = _stdFile(test_prefix);

        if (mode == OutputMode::Text)
            ofile.open(fileName);
        else
            ofile.open(fileName, ios::binary);

        //FIXME: This has to go to the HiPerProblem
        ofile << std::scientific << std::setprecision(15);
        ofile << "Time " << "time " << str(mode) << endl << time << endl;
        ofile << "GlobalData " << "globaldata " << str(mode) << endl;
        ofile << globalData.size() << endl;
        for (auto g: globalData)
            ofile << g << " ";
        ofile << endl;


        ofile << _nameTag << " ";
        ofile << _classTag << " ";
        ofile << str(mode) << endl;

        outFullData(ofile, mode, printAux);


        ofile.close();

        return 0;

    }


    void DOFsHandler::_updateFile()
    {

        ifstream ifile;
        string fileName = _stdFile(_tmp_filePrefix);
        string buffName, buffClass, buffMode;

        // Read the File Mode
        if(_tmp_outputmode == OutputMode::Undefined)
        {
            ifile.open(fileName);
            if (ifile.good() == false)
                throw std::runtime_error("DOFsHandler::Update: The file: "+  fileName + " could not be opened. Check that and rerun, please. Goodbye!");

            ifile >> buffName; ifile >> buffClass; ifile >> buffMode;

            _tmp_outputmode = outputMode(buffMode);
            ifile.close();
        }

        if (_tmp_outputmode == OutputMode::Text)
            ifile.open(fileName);
        else
            ifile.open(fileName, ios::binary);

        if (ifile.good() == false)
            throw std::runtime_error("DOFsHandler::Update: The file: "+  fileName + " could not be opened. Check that and rerun, please. Goodbye!");

        //FIXME:Time should go to hiperproblem
        ifile >> buffName; ifile >> buffClass; ifile >> buffMode;
        if (buffClass == "time" || buffName == "Time")
        {
            vector<double> ibuff(1);
            IO::fillData(ibuff.data(), ifile, ibuff.size(), _tmp_outputmode);
            ifile >> buffName; ifile >> buffClass; ifile >> buffMode;
        }
        // ifile >> buffName; ifile >> buffClass; ifile >> buffMode;
        if (buffClass == "globaldata" || buffName == "GlobalData")
        {
            vector<int> ibuff(1);
            IO::fillData(ibuff.data(), ifile, ibuff.size(), _tmp_outputmode);
            vector<double> dbuff(ibuff[0]);
            IO::fillData(dbuff.data(), ifile, dbuff.size(), _tmp_outputmode);
            ifile >> buffName; ifile >> buffClass; ifile >> buffMode;
        }

        if (buffClass != _classTag)
        {
            throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: buffClass: " + buffClass + "). Check that and rerun, please. Goodbye!");
        }

        if (buffName == "" || buffMode == "")
            throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: name/mode). Check that and rerun, please. Goodbye!");

        _nameTag = buffName;
        OutputMode readOM = outputMode(buffMode);

        if (readOM != _tmp_outputmode)
            throw std::runtime_error("DOFsHandler::Update: The mode set is not the same of the file. Check that and rerun, please. Goodbye!");

        _tmp_istream = &ifile;

        _updateIStream();


        ifile.close();

    }

    void DOFsHandler::_updateIStream()
    {

        string buffName, buffClass, buffMode;
        string rMode;
        rMode = str(_tmp_outputmode);

        istream& in = *_tmp_istream;

        vector<int> ibuff(4);
        IO::fillData(ibuff.data(), in, ibuff.size(), _tmp_outputmode);

        auto numDOFs = ibuff[0];
        auto numNodeAuxF = ibuff[1];
        auto numElemAuxF = ibuff[2];
        _stdIntPts = ibuff[3];

        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "DistributedMesh" || buffName != "DisMesh" || buffMode != rMode)
        {
            throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: DisMesh). Check that and rerun, please. Goodbye!");
        }
        else
        {
            mesh = rcp(new DistributedMesh(buffName));
            mesh->setIStream(in, _tmp_outputmode);
            mesh->Update();
        }

        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "FieldStruct" || buffName != "nodeDOFs" || buffMode != rMode)
        {
            throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: nodeDOFs). Check that and rerun, please. Goodbye!");
        }
        else
        {
            nodeDOFs = rcp(new FieldStruct(buffName));
            nodeDOFs->setIStream(in, _tmp_outputmode);
            nodeDOFs->Update();

            if(numDOFs != nodeDOFs->numFlds())
                throw std::runtime_error("DOFsHandler::Update: the readed numDOFs of DOFsHandler is not compatible with the readed FieldStruct. Check that and rerun, please. Goodbye!");
        }

        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "FieldStruct" || buffName != "nodeDOFs0" || buffMode != rMode)
        {

            //TODO: uncomment this in version 5
//            throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: nodeDOFs0). Check that and rerun, please. Goodbye!");

            //TODO: delete this in version 5
            if(_myRank == 0)
                cout << "WARNING: DOFsHandler::_updateIStream: nodeDOFs0 could not be loaded (probably due to an old .hl file); they have been set to zero." << endl;
            nodeDOFs0 = rcp(new FieldStruct("nodeDOFs0"));
            nodeDOFs0->setBlockMap(nodeDOFs->map());
            nodeDOFs0->setNFlds(nodeDOFs->numFlds());
            nodeDOFs0->Update();
        }
        else
        {
            nodeDOFs0 = rcp(new FieldStruct(buffName));
            nodeDOFs0->setIStream(in, _tmp_outputmode);
            nodeDOFs0->Update();

            if(numDOFs != nodeDOFs0->numFlds())
                throw std::runtime_error("DOFsHandler::Update: the readed numDOFs of DOFsHandler is not compatible with the readed FieldStruct. Check that and rerun, please. Goodbye!");

            //TODO: move below this bracket in version 5
            in >> buffName; in >> buffClass; in >> buffMode;
        }

        if (buffClass != "FieldStruct" || buffName != "flagConstr" || buffMode != rMode)
        {
            throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: flagConstr). Check that and rerun, please. Goodbye!");
        }
        else
        {
            flagConstr = rcp(new FieldStruct(buffName));
            flagConstr->setIStream(in, _tmp_outputmode);
            flagConstr->Update();
        }

        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "FieldStruct" || buffName != "valuConstr" || buffMode != rMode)
        {
            throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: valuConstr). Check that and rerun, please. Goodbye!");
        }
        else
        {
            valuConstr = rcp(new FieldStruct(buffName));
            valuConstr->setIStream(in, _tmp_outputmode);
            valuConstr->Update();
        }

        if (numNodeAuxF != 0)
        {
            in >> buffName; in >> buffClass; in >> buffMode;
            if (buffClass != "FieldStruct" || buffName != "nodeAuxF" || buffMode != rMode)
            {
                throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: nodeAuxF). Check that and rerun, please. Goodbye!");
            }
            else
            {
                nodeAuxF = rcp(new FieldStruct(buffName));
                nodeAuxF->setIStream(in, _tmp_outputmode);
                nodeAuxF->Update();

                if(numNodeAuxF != nodeAuxF->numFlds())
                    throw std::runtime_error("DOFsHandler::Update: the read numNodeAuxF of DOFsHandler is not compatible with the read FieldStruct. Check that and rerun, please. Goodbye!");
            }
        }

        if (numElemAuxF != 0)
        {
            in >> buffName; in >> buffClass; in >> buffMode;
            if (buffClass != "FieldStruct" || buffName != "elemAuxF" || buffMode != rMode)
            {
                throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: elemAuxF). Check that and rerun, please. Goodbye!");
            }
            else
            {
                elemAuxF = rcp(new FieldStruct(buffName));
                elemAuxF->setIStream(in, _tmp_outputmode);
                elemAuxF->Update();

                if(numElemAuxF != elemAuxF->numFlds())
                    throw std::runtime_error("DOFsHandler::Update: the read numElemAuxF of DOFsHandler is not compatible with the read FieldStruct. Check that and rerun, please. Goodbye!");
            }

        }


        // in >> buffName; in >> buffClass; in >> buffMode;
        // if (buffClass != "IntFieldStruct" || buffName != "nodeFlags" || buffMode != rMode)
        // {
        //     throw std::runtime_error("DOFsHandler::Update: this file does not contain a valid DOFsHandler (error: IntFieldStruct). Check that and rerun, please. Goodbye!");
        // }
        // else
        // {
        //     _nodeFlags->setIStream(in, _tmp_outputmode);
        //     _nodeFlags->Update();
        // }

    }

}
