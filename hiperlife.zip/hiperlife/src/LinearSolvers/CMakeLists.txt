#------------------------------------------------------------
# hiperlife's Solves Shared library
#------------------------------------------------------------

#------------------------------------------------------------
# Glob Source files
#------------------------------------------------------------
file(GLOB SOURCES_H   *.h)
file(GLOB SOURCES_CPP *.cpp)

##Remove MUMPS solver if library not found
if (MUMPS_FOUND)
  message(STATUS "LinearSolvers: Mumps direct solver enabled")
else()
  message(STATUS "LinearSolvers: Mumps direct solver disabled")
  file(GLOB MUMPS_H *MUMPS.h)
  file(GLOB MUMPS_CPP *MUMPS.cpp)
  list(REMOVE_ITEM SOURCES_H ${MUMPS_H})
  list(REMOVE_ITEM SOURCES_CPP ${MUMPS_CPP})
endif()


set(SOURCE_FILES ${SOURCES_H} ${SOURCES_CPP})
set(LIBNAME hlLinearSolvers)

#------------------------------------------------------------
# Building the LIBRARY
#------------------------------------------------------------
add_library(${LIBNAME} ${SOURCE_FILES})

target_link_libraries(${LIBNAME} ${MPI_LIB})
target_link_libraries(${LIBNAME} ${Trilinos_LIBRARIES})
target_link_libraries(${LIBNAME} ${HPLFE_LIBRARIES})

if (MUMPS_FOUND)
  target_link_libraries(${LIBNAME} ${MUMPS_LIBS})
  if(MUMPS_DOWNLOADING)
    add_dependencies(${LIBNAME} MUMPS)
  endif()
endif()

install(TARGETS ${LIBNAME} DESTINATION lib EXPORT hiperlifeTargets)
install(FILES ${SOURCES_H} DESTINATION include)

#------------------------------------------------------------
# Storing the Library
#------------------------------------------------------------
set(HPLFE_LIBRARIES ${HPLFE_LIBRARIES} ${LIBNAME} CACHE INTERNAL "HPLFE_LIBRARIES")
