/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <string>

#include <Teuchos_RCP.hpp>
#include <Teuchos_CommandLineProcessor.hpp>
#include <Teuchos_ParameterList.hpp>
#include <Teuchos_StandardCatchMacros.hpp>
#include <AztecOO.h>
#include <Amesos_BaseSolver.h>

#include <BelosLinearProblem.hpp>
#include <BelosSolverManager.hpp>

#include <BelosBlockGmresSolMgr.hpp>
#include <BelosPseudoBlockGmresSolMgr.hpp>
#include <BelosBlockCGSolMgr.hpp>
#include <BelosPseudoBlockCGSolMgr.hpp>
#include <BelosPseudoBlockTFQMRSolMgr.hpp>
#include <BelosGCRODRSolMgr.hpp>
#include <BelosRCGSolMgr.hpp>

#include <Ifpack_Preconditioner.h>
#include <Ifpack.h>

#include "hl_LinearSolver_Iterative_Belos.h"

namespace hiperlife
{

    void BelosIterativeLinearSolver::Update()
    {
        if (_paramDef == true)
            _setDefaultParameters();

        _getLinearProblem();
        _checkSettings();

        typedef double                ST;
        typedef Epetra_MultiVector    MV;
        typedef Epetra_Operator       OP;
        auto _A = Teuchos::rcpFromRef(*_linearProblem->GetMatrix());
        auto _X = Teuchos::rcpFromRef(*_linearProblem->GetLHS());
        auto _B = Teuchos::rcpFromRef(*_linearProblem->GetRHS());
        _problem = Teuchos::rcp(new Belos::LinearProblem<ST, MV, OP>(_A, _X, _B));

        Teuchos::ParameterList ifpackList;  // Parameters of Ifpack, very simple ones
        // specify parameters for Ict
        if (_prec == Preconditioner::Ict)
        {
            ifpackList.set("fact: drop tolerance", 1e-9);
            ifpackList.set("fact: ict level-of-fill", 1.0);
            ifpackList.set("schwarz: combine mode", "Add");
        }
        // specify parameters for Ilu
        if (_prec == Preconditioner::Ilu)
        {
            ifpackList.set("fact: ict level-of-fill", 1.0);
            ifpackList.set("schwarz: combine mode", "Add");
        }

        Ifpack Factory;
        int OverlapLevel = (_prec == Preconditioner::Ilu) ? 1 : 0; // must be >= 0. If Comm.NumProc() == 1 it is ignored.
        _precond = Teuchos::rcp(Factory.Create(_listPrec[static_cast<int>(_prec)], _A.getRawPtr(), OverlapLevel));
        assert(_precond != Teuchos::null);
        _precond->SetParameters(ifpackList);
        _precond->Initialize();
        _precond->Compute();

        if (_precSide == PreconditionerSide::Left)
            _problem->setLeftPrec(_precond);
        else if (_precSide == PreconditionerSide::Right)
            _problem->setRightPrec(_precond);

        bool set = _problem->setProblem();
        if (set == false)
            std::cout << std::endl << "ERROR:  Belos::LinearProblem failed to set up correctly!" << std::endl;

        Teuchos::ParameterList paramList;
        paramList.set("Maximum Iterations", _maxIter); // Maximum number of iterations allowed
        paramList.set("Convergence Tolerance", _tol);  // Relative convergence tolerance requested
        if (_type == Solver::BlockGMRES or _type == Solver::PseudoBlockGMRES or _type == Solver::GCRODR or _type == Solver::RCG)
            paramList.set("Num Blocks", _krysize);              // Maximum number of blocks in Krylov factorization
        if (_type == Solver::BlockGMRES or _type == Solver::PseudoBlockGMRES or _type == Solver::GCRODR)
            paramList.set("Maximum Restarts", _maxRest);        // Maximum number of restarts allowed

        switch (_type)
        {
            case Solver::BlockGMRES:
            {
                _solver = Teuchos::rcp(new Belos::BlockGmresSolMgr<ST, MV, OP>(_problem, Teuchos::rcp(&paramList, false)));
                break;
            }
            case Solver::PseudoBlockGMRES:
            {
                _solver = Teuchos::rcp(new Belos::PseudoBlockGmresSolMgr<ST, MV, OP>(_problem, Teuchos::rcp(&paramList, false)));
                break;
            }
            case Solver::BlockCG:
            {
                _solver = Teuchos::rcp(new Belos::BlockCGSolMgr<ST, MV, OP>(_problem, Teuchos::rcp(&paramList, false)));
                break;
            }
            case Solver::PseudoBlockCG:
            {
                _solver = Teuchos::rcp(new Belos::PseudoBlockCGSolMgr<ST, MV, OP>(_problem, Teuchos::rcp(&paramList, false)));
                break;
            }
            case Solver::GCRODR:
            {
                _solver = Teuchos::rcp(new Belos::GCRODRSolMgr<ST, MV, OP>(_problem, Teuchos::rcp(&paramList, false)));
                break;
            }
            case Solver::RCG:
            {
                _solver = Teuchos::rcp(new Belos::RCGSolMgr<ST, MV, OP>(_problem, Teuchos::rcp(&paramList, false)));
                break;
            }
            case Solver::TFQMR:
            {
                _solver = Teuchos::rcp(new Belos::PseudoBlockTFQMRSolMgr<ST, MV, OP>(_problem, Teuchos::rcp(&paramList, false)));
                break;
            }
            default:
            {
                throw runtime_error("BelosIterativeLinearSolver::checkSettings: The solver type has not been defined.");
            }
        }

    }

    void BelosIterativeLinearSolver::_setDefaultParameters()
    {
        // Max iterations
        if (_maxIter == -1)
        {
            _maxIter = 5000;
            if (_myRank == 0)
                cout << "BelosIterativeLinearSolver::setDefaultParameters: Maximum number of iterations set to default value '5000'." << endl;
        }

        // Solver type
        if (_type == Solver::Undefined)
        {
            _type = Solver::PseudoBlockGMRES;
            if (_myRank == 0)
                cout << "BelosIterativeLinearSolver::setDefaultParameters: Solver type set to default value 'PseudoBlockGMRES'." << endl;
        }

        // Preconditioner
        if (_prec == Preconditioner::Undefined)
        {
            _prec = Preconditioner::Ilu;
            if (_myRank == 0)
                cout << "BelosIterativeLinearSolver::setDefaultParameters: Preconditioner set to default value 'Ilu'." << endl;
        }

        // Preconditioner side
        if (_precSide == PreconditionerSide::Undefined)
        {
            _precSide = PreconditionerSide::Left;
            if (_myRank == 0)
                cout << "BelosIterativeLinearSolver::setDefaultParameters: Preconditioner side set to default value 'Left'." << endl;
        }

        // Krylov subspace size
        if (_type == Solver::BlockGMRES or _type == Solver::PseudoBlockGMRES or _type == Solver::GCRODR or _type == Solver::RCG)
        {
            if (_krysize == -1)
            {
                _krysize = 300;
                if (_myRank == 0)
                    cout << "BelosIterativeLinearSolver::setDefaultParameters: Krylov subspace size set to default value '300'." << endl;
            }
        }

        // Maximum number of restarts
        if (_type == Solver::BlockGMRES or _type == Solver::PseudoBlockGMRES or _type == Solver::GCRODR)
        {
            if (_maxRest == -1)
            {
                _maxRest = 20;
                if (_myRank == 0)
                    cout << "BelosIterativeLinearSolver::setDefaultParameters: Maximum number of restarts set to default value '20'." << endl;
            }
        }

        // Tolerance
        if (_tol == -1.0)
        {
            _tol = 1.E-6;
            if (_myRank == 0)
                cout << "BelosIterativeLinearSolver::setDefaultParameters: Tolerance set to default value '1.E-6'." << endl;
        }

        // Verbosity
        if (_verbose == Verbosity::Undefined)
        {
            _verbose = Verbosity::None;
            if (_myRank == 0)
                cout << "BelosIterativeLinearSolver::setDefaultParameters: Verbosity set to default value 'None'." << endl;
        }
    }

    bool BelosIterativeLinearSolver::solve()
    {
        _timer = Teuchos::rcp(new Timer({"solver","filling"}));

        _timer->start("filling");
        if(_hiperProbl!=Teuchos::null)
            _hiperProbl->FillLinearSystem();
        _timer->end("filling");

        _timer->start("solver");
        auto _A = Teuchos::rcpFromRef(*_linearProblem->GetMatrix());
        auto _X = Teuchos::rcpFromRef(*_linearProblem->GetLHS());
        auto _B = Teuchos::rcpFromRef(*_linearProblem->GetRHS());
        _problem->setOperator(_A);
        _problem->setProblem(_X, _B);
        Belos::ReturnType _ret = _solver->solve();
        _timer->end("solver");

        _converged = _ret == Belos::Converged;

        _numIter = _solver->getNumIters();

        if (_verbose != Verbosity::Undefined)
            output(_verbose);

        return _converged;
    }

    void BelosIterativeLinearSolver::output(Verbosity verbose, std::ostream& out)
    {
        if (verbose == Verbosity::Undefined)
            throw runtime_error("BelosIterativeLinearSolver::output: Verbosity has not been defined");

        int _verInt = static_cast<int>(verbose);
        if (_verInt >= 1)
        {
            using namespace std;

            if (_myRank == 0)
            {
                out << "================================================" << endl;
                out << _listSolv[static_cast<int>(_type)] << " with " << _listPrec[static_cast<int>(_prec)] << " preconditioner" << endl;
                out << "Iterative linear solver from Belos" << endl;
                out << "Converged            = " << boolalpha << _converged << endl;
                if (_verInt >= 2)
                {
                    out << "Number of iterations = " << _numIter << endl;
                    out << "Residual             = " << _solver->achievedTol() << endl;
                }
                if (_verInt >= 3)
                {
                    out << "Timer                = " << _timer->printAccumTime("solver") + _timer->printAccumTime("filling") << endl;
                    if (_hiperProbl != Teuchos::null)
                    {
                        out << "       Filling                = " << _timer->printAccumTime("filling") << endl;
                        out << "       Solver                 = " << _timer->printAccumTime("solver") << endl;
                    }
                }
                out << "================================================" << endl;
            }
        }
    }

    double BelosIterativeLinearSolver::time(TimerName tim)
    {
        double _times = -1.0;
        if (tim == TimerName::Undefined)
            throw runtime_error("BelosIterativeLinearSolver::checkSettings: Timer Name has not been defined");
        else if (tim == TimerName::Total)
            _times = (_timer->printAccumTime("solver") + _timer->printAccumTime("filling"));
        else if (tim == TimerName::Filling)
            _times = _timer->printAccumTime("filling");
        else if (tim == TimerName::Solver)
            _times = _timer->printAccumTime("solver");
        return _times;
    }

    void BelosIterativeLinearSolver::_checkSettings()
    {
        if (_type == Solver::Undefined)
            throw runtime_error("BelosIterativeLinearSolver::checkSettings: The solver type has not been defined.");
        if (_prec == Preconditioner::Undefined)
            throw runtime_error("BelosIterativeLinearSolver::checkSettings: The preconditioner has not been defined.");
        if (_precSide == PreconditionerSide::Undefined)
            throw runtime_error("BelosIterativeLinearSolver::checkSettings: The preconditioner side has not been defined.");
        if (_maxIter == -1)
            throw runtime_error("BelosIterativeLinearSolver::checkSettings: Maximum number of iterations has not been defined.");
        if (_tol == -1.0)
            throw runtime_error("BelosIterativeLinearSolver::checkSettings: Tolerance has not been defined.");
        if (_hiperProbl == Teuchos::null)
            throw runtime_error("BelosIterativeLinearSolver::checkSettings: The hiperproblem has not been defined.");
        if (_type == Solver::BlockGMRES or _type == Solver::PseudoBlockGMRES or _type == Solver::GCRODR or _type == Solver::RCG)
        {
            if (_krysize == -1)
            {
                throw runtime_error("BelosIterativeLinearSolver::checkSettings: Maximum dimension of Krylov set has not been defined.");
            }
        }
        else
        {
            if (_krysize != -1)
            {
                cout << "BelosIterativeLinearSolver::checkSettings:: Warning: you have set the maximum dimension of the Krylov set but you are not using a solver that needs it. This option will be ignored." << endl;
            }
        }
        if (_type == Solver::BlockGMRES or _type == Solver::PseudoBlockGMRES or _type == Solver::GCRODR)
        {
            if (_maxRest == -1)
            {
                throw runtime_error("BelosIterativeLinearSolver::checkSettings: Maximum number of restarts has not been defined.");
            }
        }
        else
        {
            if (_maxRest != -1)
            {
                cout << "BelosIterativeLinearSolver::checkSettings:: Warning: you have set the maximum number of restarts but you are not using a solver that needs it. This option will be ignored." << endl;
            }
        }
    }

}
