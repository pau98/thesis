/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>
#include <Epetra_MultiVector.h>
#include <Epetra_LinearProblem.h>

#include <Amesos.h>
#include <Amesos_BaseSolver.h>

#include "hl_Timer.h"
#include "hl_LinearSolver_Direct_Amesos.h"


namespace hiperlife
{

    void AmesosDirectLinearSolver::Update()
    {
        if (_paramDef == true)
            _setDefaultParameters();

        _getLinearProblem();
        _checkSettings();

        //Checks
        if(!Amesos().Query(_listSolv[static_cast<int>(_type)]))
            throw runtime_error("AmesosDirectLinearSolver:: Solver " + _listSolv[static_cast<int>(_type)] + " not enabled.");

        //  Status Parameters
        _paramList.set("OutputLevel", 0); // some verbose output: 0 - no output at all, 1 - output as specified by other parameters, 2 - all possible output
        _paramList.set("DebugLevel",  0); // level of debug output: 0 - no output at all, 1 - some debug output - set by some tests upon a test failure, >1 - more debug output (unused at this point)
        _paramList.set("PrintTiming",         false); // print some timing information (on process 0)
        _paramList.set("ComputeVectorNorms",  false); // compute norms of some vectors
        _paramList.set("ComputeTrueResidual", false); // compute the true residual Ax-b after solution

        //  Control Parameters
        _paramList.set("AddZeroToDiag", false); // add zero to diagonal if diagonal element is not present - not supported for matrices which are missing elements from the diagonal.
        _paramList.set("AddToDiag", 0.0); // add this value to all diagonal elements which are structurally non-zero - no change is made to non-zero structure of the matrix.
        _paramList.set("Refactorize", _refact == Refactorize::True); // Determine whether to Refactorize
        _paramList.set("RcondThreshold", _rcondThr); // threshold for determining if refactorize worked OK
        _paramList.set("MaxProcs", -1); // define how many processes to use in the ScaLAPACK factor and solve - if (-1), a heuristic is used to determine the number of processes to use
        _paramList.set("MatrixProperty", _MatrixTypeList[static_cast<int>(_matType)]); // Matrix property, defined internally in Amesos_Mumps as an integer: 0 general unsymmetric, 1 SPD, 2 general symmetric
        _paramList.set("ScaleMethod", static_cast<int>(_sclMet)); // scaling method: 0: none, 1: use method's default, 2: use the method's 1st alternative, 3: etc.
        _paramList.set("Reindex", false);

        // Klu parameters
        _paramList.set("TrustMe", false); // If set, Amesos_Klu trusts that the data can be used in place

        // Superludist Parameters (http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.366.2886&rep=rep1&type=pdf)
        _paramList.set("Redistribute", false);
        Teuchos::ParameterList _superludistParams;
        {
            _superludistParams.set("ReuseSymbolic", false); // Specifies whether or not we factorize or refactorize (??)
            _superludistParams.set("Fact", "SamePattern"); // Specifies whether or not the factored form of the matrix A is supplied on entry, and if not, how the matrix A will be factorized base on the previous history
            _superludistParams.set("Equil", true); // Specifies whether to equilibrate the system
            _superludistParams.set("ColPerm", "MMD_AT_PLUS_A"); // Specifies how to permute the columns of the matrix for sparsity preservation
            _superludistParams.set("RowPerm", "LargeDiag"); // Specifies whether to permute the rows of the original matrix
            _superludistParams.set("perm_c", (int*) 0); // Column permutation vector
            _superludistParams.set("perm_r", (int*) 0); // Row permutation vector
            _superludistParams.set("IterRefine", "DOUBLE"); // Specifies whether to perform iterative refinement, and in what precision to compute the residual
            _superludistParams.set("ReplaceTinyPivot", true); // Specifies whether to replace the tiny diagonals by √ε · ||A|| during LU factorization
            _superludistParams.set("PrintNonzeros", false); // Specifies whether to print the solver’s statistics
        }
        _paramList.set("Superludist", _superludistParams);

        //  Lapack Parameters (https://www.netlib.org/lapack/lug/)
        Teuchos::ParameterList _lapackParams;
        {
            _lapackParams.set("Equilibrate",true);
        }
        _paramList.set("Lapack", _lapackParams);

        //  Mumps Parameters (http://mumps.enseeiht.fr/doc/userguide_5.2.1.pdf)
        _paramList.set("NoDestroy", false); // Specifies whether or not to destroy the instance (deallocate internal data structures)
        Teuchos::ParameterList _mumpsParams;
        {
            _mumpsParams.set("Equilibrate", true);
            _mumpsParams.set("RowScaling", (double*) 0); // Row scaling if provided by the user (0.0 - no scaling)
            _mumpsParams.set("ColScaling", (double*) 0); // Columns scaling if provided by the user (0.0 - no scaling)
        }
        _paramList.set("Mumps", _mumpsParams);

        //  Paraklete Parameters - same as Klu

        //  Pardiso Parameters (https://pardiso-project.org/manual/manual.pdf)
        Teuchos::ParameterList _pardisoParams;
        {
            _pardisoParams.set("MSGLVL",    0); // Message level
            _pardisoParams.set("IPARM(1)",  0); // Use default values
            _pardisoParams.set("IPARM(2)",  0); // Fill-In reduction reordering
            _pardisoParams.set("IPARM(3)",  0); // Number of processors
            _pardisoParams.set("IPARM(4)",  0); // Preconditioned CGS
            _pardisoParams.set("IPARM(8)",  0); // Iterative refinement steps
            _pardisoParams.set("IPARM(10)", 0); // Pivot perturbation
            _pardisoParams.set("IPARM(11)", 0); // Scaling vectors
            _pardisoParams.set("IPARM(18)", 0); // Number nonzeros in factors
            _pardisoParams.set("IPARM(19)", 0); // GFlops of factorization
            _pardisoParams.set("IPARM(21)", 0); // Pivoting for symmetric indefinite matrices.
        }
        _paramList.set("Pardiso", _pardisoParams);

        //  Scalapack Parameters (https://pdfs.semanticscholar.org/e064/7d1fc72b52ba8dc30c2ac019bcea13cc7c14.pdf)
        Teuchos::ParameterList _scalapackParams;
        {
            _scalapackParams.set("2D distribution",true); // Two dimensional block cyclic data distribution
            _scalapackParams.set("grid_nb",32);           // Grid size
        }
        _paramList.set("Scalapack", _scalapackParams);

        // Use of transposed matrix
        if (_type == Solver::Klu or _type == Solver::Umfpack or _type == Solver::Mumps or _type == Solver::Lapack)
            _paramList.set("UseTranspose", _transp == UseTranspose::True);
    }


    bool AmesosDirectLinearSolver::solve()
    {

        _timer = Teuchos::rcp(new Timer({"full", "creation","filling","numericfact","symbolicfact","solver"}));

        _timer->start("full");

        _timer->start("creation");
        _solver = rcp(_AmesFact.Create(_listSolv[static_cast<int>(_type)], *_linearProblem));
        _solver->SetParameters(_paramList);
        _timer->end("creation");

        _timer->start("filling");
        if(_hiperProbl!=Teuchos::null)
            _hiperProbl->FillLinearSystem();
        _timer->end("filling");

        _timer->start("symbolicfact");
        if (_symfact == SymbolicFactorization::True)
            _solver->SymbolicFactorization();
        _timer->end("symbolicfact");

        _timer->start("numericfact");
        if (_numfact == NumericFactorization::True)
            _solver->NumericFactorization();
        _timer->end("numericfact");

        _timer->start("solver");
        int err = _solver->Solve();
        _timer->end("solver");

        _timer->end("full");

        _converged = err == 0;

        if(_verbose != Verbosity::Undefined)
            output(_verbose);

        _solver = Teuchos::null;

        return _converged;
    }

    void AmesosDirectLinearSolver::output(Verbosity verbose, std::ostream& out)
    {
        if (verbose == Verbosity::Undefined)
            throw runtime_error("AmesosDirectLinearSolver::output: Verbosity has not been defined");

        int _verInt = static_cast<int>(verbose);
        if (_verInt >= 1)
        {
            using namespace std;
            double residual;
            if (_verInt >= 2)
            {
                auto A = _linearProblem->GetMatrix();
                auto B = _linearProblem->GetRHS();
                auto X = _linearProblem->GetLHS();

                Epetra_MultiVector Ax(B->Map(), 1);
                A->Multiply(false, *X, Ax);
                Ax.Update(1.0, *B, -1.0);
                Ax.Norm2(&residual);
            }

            if (_myRank == 0)
            {
                out << "================================================" << endl;
                out << _listSolv[static_cast<int>(_type)] << endl;
                out << "Direct linear solver from Amesos" << endl;
                out << "Converged    = " << boolalpha << _converged << endl;
                if (_verInt >= 2)
                    out << "Residual     = " << residual << endl;
                if (_verInt >= 3)
                {
                    out << "Timer: Total = " << _timer->printAccumTime("full") << endl;
                    out << "       Solver Creation        = " << _timer->printAccumTime("creation") << endl;
                    out << "       Filling                = " << _timer->printAccumTime("filling") << endl;
                    out << "       Symbolic Factorization = " << _timer->printAccumTime("symbolicfact") << endl;
                    out << "       Numeric Factorization  = " << _timer->printAccumTime("numericfact") << endl;
                    out << "       Solver                 = " << _timer->printAccumTime("solver") << endl;
                }
                out << "================================================" << endl;
            }
        }
    }

    double AmesosDirectLinearSolver::time(TimerName tim)
    {
        double _times = -1.0;
        if (tim == TimerName::Undefined)
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: Timer Name has not been defined");
        else if (tim == TimerName::Total)
            _times = _timer->printAccumTime("full");
        else if (tim == TimerName::SolverCreation)
            _times = _timer->printAccumTime("creation");
        else if (tim == TimerName::Filling)
            _times = _timer->printAccumTime("filling");
        else if (tim == TimerName::SymbolicFactorization)
            _times = _timer->printAccumTime("symbolicfact");
        else if (tim == TimerName::NumericFactorization)
            _times = _timer->printAccumTime("numericfact");
        else if (tim == TimerName::Solver)
            _times = _timer->printAccumTime("solver");
        return _times;
    }

    void AmesosDirectLinearSolver::_checkSettings()
    {
        if (_type == Solver::Undefined)
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: The solver type has not been defined.");
        if (_matType == MatrixType::Undefined)
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: The matrix type has not been defined.");
        if (_sclMet == ScaleMethod::Undefined)
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: Scale Method has not been defined.");
        if (_refact == Refactorize::Undefined)
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: Refactorization has not been defined.");
        if (_rcondThr != -1 and _refact == Refactorize::False)
        {
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: Refactorization threshold has been settled without refactorization.");
        }
        if (_rcondThr == -1 and _refact == Refactorize::True)
        {
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: Refactorization has been settled without refactorization threshold.");
        }
        if (_hiperProbl == Teuchos::null)
            throw runtime_error("AmesosDirectLinearSolver::checkSettings: The hiperproblem has not been defined.");
        if (_type == Solver::Klu or _type == Solver::Umfpack or _type == Solver::Mumps or _type == Solver::Lapack)
        {
            if (_transp == UseTranspose::Undefined)
            {
                throw runtime_error("AmesosDirectLinearSolver::checkSettings: Use transposed matrix has not been defined.");
            }
        }
        else
        {
            if (_transp != UseTranspose::Undefined)
            {
                cout << "AmesosDirectLinearSolver::checkSettings:: Warning: you have set the use of transposed matrix but you are not using a solver that needs it. This option will be ignored." << endl;
            }
        }
        if (_type != Solver::Klu and _type != Solver::Mumps)
        {
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::checkSettings:: Warning: declared solver has not been tested. Only Klu and Mumps have been tested so far." << endl;
        }
        /*if (_type == Solver::Mumps)
        {
            if (_matType == MatrixType::Undefined)
            {
                throw runtime_error("AmesosDirectLinearSolver::checkSettings: The matrix type has not been defined.");
            }
        }
        else
        {
            if (_matType != MatrixType::Undefined)
            {
                cout << "AmesosDirectLinearSolver::checkSettings:: Warning: you have set the matrix type but you are not using a solver that needs it. This option will be ignored." << endl;
            }
        }*/
        /*
        if (_type == Solver::Klu)
        {
            if (_refact == Refactorize::Undefined)
            {
                throw runtime_error("AmesosDirectLinearSolver::checkSettings: Refactorization has not been defined.");
            }
            if (_sclMet == ScaleMethod::Undefined)
            {
                throw runtime_error("AmesosDirectLinearSolver::checkSettings: Scale Method has not been defined.");
            }
            if (_rcondThr != -1 and _refact != Refactorize::True)
            {
                throw runtime_error("AmesosDirectLinearSolver::checkSettings: Refactorization threshold has been settled without refactorization.");
            }
            if (_rcondThr == -1 and _refact == Refactorize::True)
            {
                throw runtime_error("AmesosDirectLinearSolver::checkSettings: Refactorization has been settled without refactorization threshold.");
            }
        }
        else
        {
            if (_refact != Refactorize::Undefined)
            {
                cout << "AmesosDirectLinearSolver::checkSettings:: Warning: you have set refactorize but you are not using a solver that needs it. This option will be ignored." << endl;
            }
            if (_rcondThr != -1)
            {
                cout << "AmesosDirectLinearSolver::checkSettings:: Warning: you have set refactorization threshold but you are not using a solver that needs it. This option will be ignored." << endl;
            }
            if (_sclMet != ScaleMethod::Undefined)
            {
                cout << "AmesosDirectLinearSolver::checkSettings:: Warning: you have set Scale Method but you are not using a solver that needs it. This option will be ignored." << endl;
            }
        }
        */
    }

    void AmesosDirectLinearSolver::_setDefaultParameters()
    {
        // Solver type
        if (_type == Solver::Undefined)
        {
            _type = Solver::Klu;
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::setDefaultParameters: Solver type set to default value 'Klu'." << endl;
        }

        // MatrixType
        if (_matType == MatrixType::Undefined)
        {
            _matType = MatrixType::General;
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::setDefaultParameters: MatrixType set to default value 'General'." << endl;
        }

        // Refactorize
        if (_refact == Refactorize::Undefined)
        {
            _refact = Refactorize::False;
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::setDefaultParameters: Refactorize set to default value 'False'." << endl;
        }

        //_rcondThr = (_rcondThr == -1 and _refact == Refactorize::True) ? 1.E-12 : _rcondThr;

        // Scale method
        if (_sclMet == ScaleMethod::Undefined)
        {
            _sclMet = ScaleMethod::True;
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::setDefaultParameters: Scale method set to default value 'True'." << endl;
        }

        // Use transpose
        if (_type == Solver::Klu or _type == Solver::Umfpack or _type == Solver::Mumps or _type == Solver::Lapack)
        {
            if (_transp == UseTranspose::Undefined)
            {
                _transp = UseTranspose::False;
                if (_myRank == 0)
                    cout << "AmesosDirectLinearSolver::setDefaultParameters: Use transpose set to default value 'False'." << endl;
            }
        }

        // Symbolic factorization
        if (_symfact == SymbolicFactorization::Undefined)
        {
            _symfact = SymbolicFactorization::True;
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::setDefaultParameters: Symbolic factorization set to default value 'True'." << endl;
        }

        // Numeric factorization
        if (_numfact == NumericFactorization::Undefined)
        {
            _numfact = NumericFactorization::True;
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::setDefaultParameters: Numeric factorization set to default value 'True'." << endl;
        }

        // Verbosity
        if (_verbose == Verbosity::Undefined)
        {
            _verbose = Verbosity::None;
            if (_myRank == 0)
                cout << "AmesosDirectLinearSolver::setDefaultParameters: Verbosity set to default value 'None'." << endl;
        }
    }
}
