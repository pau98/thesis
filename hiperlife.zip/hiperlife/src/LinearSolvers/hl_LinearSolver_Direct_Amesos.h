/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DIRECT_AMESOS_H
#define DIRECT_AMESOS_H

#include <mpi.h>
#include <string>

#include <Epetra_LinearProblem.h>
#include <Amesos.h>

#include "hl_LinearSolver_Direct.h"

namespace hiperlife
{

    /*!
    * \class Direct_Amesos
    * \brief Direct Solvers
    *
    * It uses several solvers from Trilinos's Amesos package
    * https://trilinos.org/docs/dev/packages/amesos/doc/html/index.html
    *
    * Only the solvers SuperLU_Dist, Mumps and Dscpack work in parallel. The rest work in serial.
    * Only Klu and Mumps have been tested so far.
    */
    class AmesosDirectLinearSolver : public DirectLinearSolver
    {
        public:

            AmesosDirectLinearSolver(){};

            /** @name Constructor / Destructor / Operator
            *  @{ */
            AmesosDirectLinearSolver(AmesosDirectLinearSolver &&other) = default;
            ~AmesosDirectLinearSolver() = default;
            AmesosDirectLinearSolver& operator=(AmesosDirectLinearSolver&& other) = default;

            AmesosDirectLinearSolver& operator=(const AmesosDirectLinearSolver& other) = delete;
            AmesosDirectLinearSolver(const AmesosDirectLinearSolver& other) = delete;
            /** @} */ // end of constructors

            bool solve() override;
            void Update() override;
            void output(Verbosity verbose = Verbosity::Undefined, std::ostream& out = std::cout) override;

            /*! \brief Defines the type of solver that we are using. Default: Klu. */
            enum class Solver
            {
                Undefined    = -1,
                /*! https://users.encs.concordia.ca/~krzyzak/R%20Code-Communications%20in%20Statistics%20and%20Simulation%202014/Zubeh%F6r/SuiteSparse/KLU/Doc/KLU_UserGuide.pdf */
                Klu          =  0,
                /*! https://users.encs.concordia.ca/~krzyzak/R%20Code-Communications%20in%20Statistics%20and%20Simulation%202014/Zubeh%F6r/SuiteSparse/UMFPACK/Doc/UserGuide.pdf */
                Umfpack      =  1,
                /*! https://pardiso-project.org/manual/manual.pdf */
                Pardiso      =  2,
                /*! http://www.jasoncantarella.com/tsnnls/tags/start/taucs.pdf */
                Taucs        =  3,
                /*! http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.366.2886&rep=rep1&type=pdf */
                SuperLU_Dist =  4,
                /*! http://mumps.enseeiht.fr/doc/userguide_5.2.1.pdf */
                Mumps        =  5,
                /*! https://www.netlib.org/lapack/lug/ */
                Lapack       =  6,
                /*! http://www.cse.psu.edu/research/scl/software/dscpack/dscpackdoc.pdf */
                Dscpack      =  7,
                /*! http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.366.2886&rep=rep1&type=pdf */
                SuperLU      =  8,
                /*! http://www.netlib.org/scalapack/slug/ */
                Scalapack    =  9,
                /*! https://trilinos.org/packages/amesos/ */
                Paraklete    = 10,
                /*! https://github.com/ibayer/CSparse/blob/master/README.txt */
                CSparse      = 11
            };
            /*! \brief Defines the type of matrix that we are using. Default: General. */
            enum class MatrixType
            {
                Undefined = -1,
                /*! General Unsymmetric Matrix */
                General   =  0,
                /*! Symmetric Positive-Definite Matrix */
                SPD       =  1,
                /*! General Symmetric Matrix */
                Symmetric =  2
            };
            /*! \brief Defines if we refactorize the matrix or not. */
            enum class Refactorize
            {
                Undefined = -1,
                False     =  0,
                True      =  1
            };
            /*! \brief Defines if we use Scale Method or not. */
            enum class ScaleMethod
            {
                Undefined = -1,
                False     =  0,
                True      =  1
            };
            /*! \brief Settles the timer we want to print. */
            enum class TimerName
            {
                Undefined             = -1,
                Total                 =  0,
                SolverCreation        =  1,
                Filling               =  2,
                NumericFactorization  =  3,
                SymbolicFactorization =  4,
                Solver                =  5
            };

            /** @name Amesos Direct Linear Solver parameters
            *  @{ */
            /*! \brief Sets which solver is used. Default: Klu.
            * \param type Solver specified by enum class Solver
            */
            void setSolver(Solver type){_type = type;}
            /*! \brief Sets the matrix type (general unsymmetric, general symmetric or symmetric positive definite). Default: General.
            * \param matType Matrix Type specified by enum class MatrixType (General, Symmetric or SPD)
            */
            void setMatrixType(MatrixType matType){_matType = matType;}
            /*! \brief Specifies whether the solver uses a scale method or none. Default: true.
            * \param sclMet false if we do not use scale method, true if we do
            */
            void setScaleMethod(bool sclMet){_sclMet = (sclMet == true) ? ScaleMethod::True : ScaleMethod::False;}
            /*! \brief Specifies whether the solver refactorizes or not. Default: false.
            * \param refact false if we do not refactorize, true if we do
            */
            void setRefactorize(bool refact){_refact = (refact == true) ? Refactorize::True : Refactorize::False;}
            /*! \brief Specifies threshold to accept if the refactorization is worth.  No default parameter. If refactorization is chosen, it is mandatory to set its threshold explicitly.
            * \param rcondThr Tolerance for the condition number of the refactorized matrix
            */
            void setRCondThreshold(double rcondThr){_rcondThr = rcondThr;}
            //void setThreshold(double thresh){_thresh = thresh;}; // Not used in any solver (according to manual). Threshold to decide if a small enough matrix element can be taken as zero.
            /*! \brief Returns the time of a process.
            * \param timer Timer specifying the process desired.
            */
            double time(TimerName tim = TimerName::Undefined);
            /** @} */

        private:
            Amesos _AmesFact;
            Teuchos::ParameterList _paramList;
            Teuchos::RCP<Amesos_BaseSolver> _solver = Teuchos::null;
            Solver _type = Solver::Undefined;
            MatrixType _matType = MatrixType::Undefined;
            Refactorize _refact = Refactorize::Undefined;
            ScaleMethod _sclMet = ScaleMethod::Undefined;
            double _rcondThr{-1.0};
            //double thresh{-1.0};

            std::vector<std::string> _listSolv       = {"Klu", "Umfpack", "Pardiso", "Taucs", "Superludist", "Mumps", "Lapack", "Dscpack", "Superlu", "Scalapack", "Paraklete", "CSparse"};
            std::vector<std::string> _MatrixTypeList = {"general", "SPD", "symmetric"};

        protected:
            void _checkSettings() override;
            void _setDefaultParameters() override;

    };
}




#endif //DIRECT_AMESOS_H
