/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>
#include <Epetra_MultiVector.h>

#include <Amesos2.hpp>
#include <Amesos2_Version.hpp>

#include "hl_Timer.h"
#include "hl_LinearSolver_Direct_Amesos2.h"

#ifdef EXTRAE_PROFILING
#include "extrae_user_events.h"
#endif

namespace hiperlife
{

    void Amesos2DirectLinearSolver::Update()
    {
        if (_paramDef == true)
            _setDefaultParameters();

        _getLinearProblem();
        _checkSettings();

        std::vector<std::string> _QuerySolverList = {"shylubasker", "basker", "klu2", "superludist", "superlumt", "umfpack", "tacho", "superlu", "pardisomkl", "lapack", "mumps", "cholmod"};
        std::vector<std::string> _TransType       = {"NOTRANS", "TRANS", "CONJ"};

        //Checks
        if(!Amesos2::query(_QuerySolverList[static_cast<int>(_type)]))
            throw runtime_error("Amesos2DirectLinearSolver:: Solver " + _QuerySolverList[static_cast<int>(_type)] + " not enabled.");

        _solverName = _SolverNameList[static_cast<int>(_type)];
        if (_type == Solver::SuperLU) // https://github.com/trilinos/Trilinos/blob/69f8850c25bdead51b38866ae34d4fa40947b67f/packages/amesos2/src/Amesos2_Superlu_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("Trans", _TransType[static_cast<int>(_transp)]); // Solve for the transpose system or not
            _amesos2_params.sublist(_solverName).set("IterRefine", "NOREFINE"); // Type of iterative refinement to use
            _amesos2_params.sublist(_solverName).set("ColPerm", "COLAMD"); // Specifies how to permute the columns of the matrix for sparsity preservation
            _amesos2_params.sublist(_solverName).set("DiagPivotThresh", 1.0); // Specifies the threshold used for a diagonal entry to be an acceptable pivot
            _amesos2_params.sublist(_solverName).set("Equil", true); // Whether to equilibrate the system before solve
            _amesos2_params.sublist(_solverName).set("SymmetricMode", false); // Specifies whether to use the symmetric mode. Gives preference to diagonal pivots and uses an (A^T + A)-based column permutation.
            _amesos2_params.sublist(_solverName).set("RowPerm", "LargeDiag"); // Type of row permutation strategy to use
            _amesos2_params.sublist(_solverName).set("ILU_DropTol", 0.0001); // ILUT drop tolerance
            _amesos2_params.sublist(_solverName).set("ILU_FillFactor", 10.0); // ILUT fill factor
            _amesos2_params.sublist(_solverName).set("ILU_Norm", "INF_NORM"); // Type of norm to use
            _amesos2_params.sublist(_solverName).set("ILU_MILU", "SILU"); // Type of modified ILU to use
            _amesos2_params.sublist(_solverName).set("ILU_FillTol", 0.01); // ILUT fill tolerance
            _amesos2_params.sublist(_solverName).set("ILU_Flag", false); // ILU flag: if true, run ILU routines
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Whether GIDs contiguous
        }
        else if (_type == Solver::Basker) // https://github.com/trilinos/Trilinos/blob/69f8850c25bdead51b38866ae34d4fa40947b67f/packages/amesos2/src/Amesos2_Basker_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Are GIDs contiguous
            _amesos2_params.sublist(_solverName).set("num_threads", 1); // Number of threads
            _amesos2_params.sublist(_solverName).set("pivot", false); // Should not pivot
            _amesos2_params.sublist(_solverName).set("pivot_tol", 0.0001); // Tolerance before pivot, currently not used
            _amesos2_params.sublist(_solverName).set("symmetric", false); // Should Symbolic assume symmetric nonzero pattern
            _amesos2_params.sublist(_solverName).set("realloc", false); // Should realloc space if not enough
            _amesos2_params.sublist(_solverName).set("verbose", false); // Information about factoring
            _amesos2_params.sublist(_solverName).set("verbose_matrix", false); // Give Permuted Matrices
            _amesos2_params.sublist(_solverName).set("matching", true); // Use WC matching (Not Supported)
            _amesos2_params.sublist(_solverName).set("matching_type", 0); // Type of WC matching (Not Supported)
            _amesos2_params.sublist(_solverName).set("btf", true); // Use BTF ordering
            _amesos2_params.sublist(_solverName).set("amd_btf", true); // Use AMD on BTF blocks (Not Supported)
            _amesos2_params.sublist(_solverName).set("amd_dom", true); // Use CAMD on ND blocks (Not Supported)
            _amesos2_params.sublist(_solverName).set("transpose", _transp == UseTranspose::True); // Solve the transpose A
            _amesos2_params.sublist(_solverName).set("alnnz", 2); // Approx number of nonzeros in L, default is 2*nnz(A)
            _amesos2_params.sublist(_solverName).set("aunnx", 2); // Approx number of nonzeros in I, default is 2*nnz(U)
        }
        else if (_type == Solver::Cholmod) // https://github.com/trilinos/Trilinos/blob/69f8850c25bdead51b38866ae34d4fa40947b67f/packages/amesos2/src/Amesos2_Cholmod_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("nmethods", 0); // Specifies the number of different ordering methods to try
            _amesos2_params.sublist(_solverName).set("print", 0); // Specifies the verbosity of the print statements
            _amesos2_params.sublist(_solverName).set("dbound", 0.0); // Specifies the smallest absolute value on the diagonal D for the LDL' factorization
            _amesos2_params.sublist(_solverName).set("Equil", true); // Whether to equilibrate the system before solve
            _amesos2_params.sublist(_solverName).set("PreferUpper", true); // Specifies whether the matrix will be stored in upper triangular form
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Whether GIDs contiguous
        }
        else if (_type == Solver::Lapack) // https://github.com/trilinos/Trilinos/blob/69f8850c25bdead51b38866ae34d4fa40947b67f/packages/amesos2/src/Amesos2_Lapack_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("Equilibrate", true); // Whether to equilibrate the input matrix
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Whether GIDs contiguous
        }
        else if (_type == Solver::Klu) // https://github.com/trilinos/Trilinos/blob/69f8850c25bdead51b38866ae34d4fa40947b67f/packages/amesos2/src/Amesos2_KLU2_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("Equil", true); // Whether to equilibrate the system before solve, does nothing now
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Whether GIDs contiguous
            _amesos2_params.sublist(_solverName).set("Trans", _TransType[static_cast<int>(_transp)]); // Solve for the transpose system or not
        }
        else if (_type == Solver::Pardiso_MKL) // https://github.com/trilinos/Trilinos/blob/69f8850c25bdead51b38866ae34d4fa40947b67f/packages/amesos2/src/Amesos2_PardisoMKL_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("IPARM(2)", 2); // Fill-in reducing ordering for the input matrix
            _amesos2_params.sublist(_solverName).set("IPARM(4)", 0); // Preconditioned CGS/CG. Non-0 options for advanced users
            _amesos2_params.sublist(_solverName).set("IPARM(8)", 0); // Iterative refinement step
            _amesos2_params.sublist(_solverName).set("IPARM(10)", 13); // Pivoting perturbation (e = 10^(-IPARM(10))
            _amesos2_params.sublist(_solverName).set("IPARM(12)", static_cast<int>(_transp)); // Solve with transposed or conjugate transposed matrix A
            _amesos2_params.sublist(_solverName).set("IPARM(18)", -1); // Report the number of non-zero elements in the factors
            _amesos2_params.sublist(_solverName).set("IPARM(24)", 1); // Parallel factorization control: 0 - PARDISO uses the previous algorithm for factorization, 1 - PARDISO uses the new two-level factorization algorithm
            _amesos2_params.sublist(_solverName).set("IPARM(25)", 1); // Parallel forward/backward solve control: 0 - PARDISO uses the parallel algorithm for the solve step, 1 - PARDISO uses the sequential forward and backward solve
            _amesos2_params.sublist(_solverName).set("IPARM(60)", 2); // PARDISO mode (OOC mode)
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Whether GIDs contiguous
        }
        else if (_type == Solver::SuperLU_Dist) // https://github.com/trilinos/Trilinos/blob/69f8850c25bdead51b38866ae34d4fa40947b67f/packages/amesos2/src/Amesos2_Superludist_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("npcol", 1); // Number of columns in the processor grid. Must be set with nprow
            _amesos2_params.sublist(_solverName).set("nprow", 1); // Number of rows in the SuperLU_DIST processor grid. Must be set together with npcol
            _amesos2_params.sublist(_solverName).set("Trans", _TransType[static_cast<int>(_transp)]); // Solve for the transpose system or not
        }
        else if (_type == Solver::ShyLU_Basker) // https://github.com/trilinos/Trilinos/blob/d5ff759c0d4794830960967ae3962c018710a638/packages/amesos2/src/Amesos2_ShyLUBasker_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Are GIDs contiguous
            _amesos2_params.sublist(_solverName).set("num_threads", 1); // Number of threads
            _amesos2_params.sublist(_solverName).set("pivot", false); // Should not pivot
            _amesos2_params.sublist(_solverName).set("pivot_tol", 0.0001); // Tolerance before pivot, currently not used
            _amesos2_params.sublist(_solverName).set("symmetric", false); // Should Symbolic assume symmetric nonzero pattern
            _amesos2_params.sublist(_solverName).set("realloc", false); // Should realloc space if not enough
            _amesos2_params.sublist(_solverName).set("verbose", false); // Information about factoring
            _amesos2_params.sublist(_solverName).set("verbose_matrix", false); // Give Permuted Matrices
            _amesos2_params.sublist(_solverName).set("matching", true); // Use WC matching (Not Supported)
            _amesos2_params.sublist(_solverName).set("matching_type", 0); // Type of WC matching (Not Supported)
            _amesos2_params.sublist(_solverName).set("btf", true); // Use BTF ordering
            _amesos2_params.sublist(_solverName).set("amd_btf", true); // Use AMD on BTF blocks (Not Supported)
            _amesos2_params.sublist(_solverName).set("amd_dom", true); // Use CAMD on ND blocks (Not Supported)
            _amesos2_params.sublist(_solverName).set("transpose", _transp == UseTranspose::True); // Solve the transpose A
        }
        else if (_type == Solver::SuperLU_MT) // https://github.com/trilinos/Trilinos/blob/d5ff759c0d4794830960967ae3962c018710a638/packages/amesos2/src/Amesos2_Superlumt_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("nprocs", 1); // The number of processors to factorize with
            _amesos2_params.sublist(_solverName).set("trans", _TransType[static_cast<int>(_transp)]); // Solve for the transpose system or not
            _amesos2_params.sublist(_solverName).set("panel_size", 1); // Specifies the number of consecutive columns to be treated as a unit of task
            _amesos2_params.sublist(_solverName).set("relax", 2); // Specifies the number of columns to be grouped as a relaxed supernode
            _amesos2_params.sublist(_solverName).set("Equil", true); // Whether to equilibrate the system before solve
            _amesos2_params.sublist(_solverName).set("diag_pivot_thresh", 1.0); // Specifies the threshold used for a diagonal entry to be an acceptable pivot
            _amesos2_params.sublist(_solverName).set("ColPerm", "COLAMD"); // Specifies how to permute the columns of the matrix for sparsity preservation
            _amesos2_params.sublist(_solverName).set("SymmetricMode", false); // Specifies whether to use the symmetric mode
            _amesos2_params.sublist(_solverName).set("PrintStat", false); // Specifies whether to print the solver's statistics
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Whether GIDs contiguous
        }
        else if (_type == Solver::Mumps) // https://github.com/trilinos/Trilinos/blob/d5ff759c0d4794830960967ae3962c018710a638/packages/amesos2/src/Amesos2_MUMPS_def.hpp
        {
            _amesos2_params.sublist(_solverName).set("ICNTL(1)", "no"); // output stream for error messages
            _amesos2_params.sublist(_solverName).set("ICNTL(2)", "no"); // output stream for diagnostic printing, statistics, and warning messages
            _amesos2_params.sublist(_solverName).set("ICNTL(3)", "no"); // output stream for global information, collected on the host
            _amesos2_params.sublist(_solverName).set("ICNTL(4)", "no"); // level of printing for error, warning, and diagnostic messages
            _amesos2_params.sublist(_solverName).set("ICNTL(6)", "no"); // permutes the matrix to a zero-free diagonal and/or scale the matrix
            _amesos2_params.sublist(_solverName).set("ICNTL(9)", (_transp == UseTranspose::True) ? "yes" : "no" ); // computes the solution using A or A^T
            _amesos2_params.sublist(_solverName).set("ICNTL(11)", "no"); // computes statistics related to an error analysis of the linear system solved
            _amesos2_params.sublist(_solverName).set("IsContiguous", true); // Whether GIDs contiguous
        }
        // No Umfpack parameters
        // No Tacho parameters
    }


    bool Amesos2DirectLinearSolver::solve()
    {
         _timer = Teuchos::rcp(new Timer({"full", "creation", "filling","numericfact","symbolicfact","solver"}));

        _timer->start("full");

        //Create solver
        _timer->start("creation");
        #ifdef EXTRAE_PROFILING
            Extrae_eventandcounters(1000, 20);
        #endif
            _solver = Amesos2::create<Epetra_CrsMatrix, Epetra_MultiVector>(_solverName, _hiperProbl->A, _hiperProbl->sol, _hiperProbl->rhs);
        #ifdef EXTRAE_PROFILING
            Extrae_eventandcounters(1000, 0);
        #endif
        _solver->setParameters(Teuchos::rcpFromRef(_amesos2_params));
        _timer->end("creation");

        //Fill linear system
        _timer->start("filling");
        if (_hiperProbl!=Teuchos::null)
            _hiperProbl->FillLinearSystem();
        _timer->end("filling");

        //Set symbolic and numeric factorization
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 21);
        #endif
        _timer->start("symbolicfact");
        if (_symfact == SymbolicFactorization::True)
            _solver->symbolicFactorization();
        _timer->end("symbolicfact");
        _timer->start("numericfact");
        if (_numfact == NumericFactorization::True)
            _solver->numericFactorization();
        _timer->end("numericfact");
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif

        //Solve
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 22);
        #endif
        _timer->start("solver");
        _solver->solve();
        _timer->end("solver");
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif

        _timer->end("full");

        _converged = false;

        auto A = _linearProblem->GetMatrix();
        auto B = _linearProblem->GetRHS();
        auto X = _linearProblem->GetLHS();
        Epetra_MultiVector Ax(B->Map(), 1);
        A->Multiply(false, *X, Ax);
        Ax.Update(1.0, *B, -1.0);
        Ax.Norm2(&_residual);

        if (_residual < _tol)
            _converged = true;

        if (_verbose != Verbosity::Undefined)
            output(_verbose);

        _solver = Teuchos::null;

        return _converged;
    }

    void Amesos2DirectLinearSolver::output(Verbosity verbose, std::ostream& out)
    {
        if (verbose == Verbosity::Undefined)
            throw runtime_error("Amesos2DirectLinearSolver::output: Verbosity has not been defined");

        int _verInt = static_cast<int>(verbose);
        if (_verInt >= 1)
        {
            using namespace std;
            double residual;
            if (_verInt >= 2)
            {
                auto A = _linearProblem->GetMatrix();
                auto B = _linearProblem->GetRHS();
                auto X = _linearProblem->GetLHS();

                Epetra_MultiVector Ax(B->Map(), 1);
                A->Multiply(false, *X, Ax);
                Ax.Update(1.0, *B, -1.0);
                Ax.Norm2(&residual);
            }

            if (_myRank == 0)
            {
                out << "================================================" << endl;
                out << _listSolv[static_cast<int>(_type)] << endl;
                out << "Direct linear solver from Amesos2" << endl;
                out << "Converged    = " << boolalpha << _converged << endl;
                if (_verInt >= 2)
                    out << "Residual     = " << residual << endl;
                if (_verInt >= 3)
                {
                    out << "Timer: Total = " << _timer->printAccumTime("full") << endl;
                    out << "       Solver Creation        = " << _timer->printAccumTime("creation") << endl;
                    out << "       Filling                = " << _timer->printAccumTime("filling") << endl;
                    out << "       Symbolic Factorization = " << _timer->printAccumTime("symbolicfact") << endl;
                    out << "       Numeric Factorization  = " << _timer->printAccumTime("numericfact") << endl;
                    out << "       Solver                 = " << _timer->printAccumTime("solver") << endl;
                }
                out << "================================================" << endl;
            }
        }
    }

    double Amesos2DirectLinearSolver::time(TimerName tim)
    {
        double _times = -1.0;
        if (tim == TimerName::Undefined)
            throw runtime_error("Amesos2DirectLinearSolver::checkSettings: Timer Name has not been defined");
        else if (tim == TimerName::Total)
            _times = _timer->printAccumTime("full");
        else if (tim == TimerName::SolverCreation)
            _times = _timer->printAccumTime("creation");
        else if (tim == TimerName::Filling)
            _times = _timer->printAccumTime("filling");
        else if (tim == TimerName::SymbolicFactorization)
            _times = _timer->printAccumTime("symbolicfact");
        else if (tim == TimerName::NumericFactorization)
            _times = _timer->printAccumTime("numericfact");
        else if (tim == TimerName::Solver)
            _times = _timer->printAccumTime("solver");
        return _times;
    }

    void Amesos2DirectLinearSolver::_checkSettings()
    {
        if (_type == Solver::Undefined)
            throw runtime_error("Amesos2DirectLinearSolver::checkSettings: The solver type has not been defined.");
        if (_type == Solver::Cholmod or _type == Solver::Lapack)
        {
            if (_transp != UseTranspose::Undefined)
                cout << "Amesos2DirectLinearSolver::checkSettings: Use transposed matrix has been defined when it is not necessary for the solver selected. This option will be ignored." << endl;
        }
        else
        {
            if (_transp == UseTranspose::Undefined)
                throw runtime_error("Amesos2DirectLinearSolver::checkSettings: Use transposed matrix has not been defined.");
        }
        if (_hiperProbl == Teuchos::null)
            throw runtime_error("Amesos2DirectLinearSolver::checkSettings: The hiperproblem has not been defined.");
        if (_symfact == SymbolicFactorization::Undefined)
            throw runtime_error("Amesos2DirectLinearSolver::checkSettings: Symbolic Factorization has not been defined.");
        if (_numfact == NumericFactorization::Undefined)
            throw runtime_error("Amesos2DirectLinearSolver::checkSettings: Numerical Factorization has not been defined.");
        if (_type != Solver::Klu and _type != Solver::Mumps)
        {
            if (_myRank == 0)
                cout << "Amesos2DirectLinearSolver::checkSettings:: Warning: declared solver has not been tested. Only Klu and Mumps have been tested so far." << endl;
        }
        //if (_matType == MatrixType::Undefined)
        //    throw runtime_error("AmesosDirectLinearSolver::checkSettings: The matrix type has not been defined.");
    }

    void Amesos2DirectLinearSolver::_setDefaultParameters()
    {
        // Solver type
        if (_type == Solver::Undefined)
        {
            _type = Solver::Klu;
            if (_myRank == 0)
                cout << "Amesos2DirectLinearSolver::setDefaultParameters: Solver type set to default value 'Klu'." << endl;
        }

        // Use transpose
        if (_type != Solver::Cholmod and _type != Solver::Lapack)
        {
            if (_transp == UseTranspose::Undefined)
            {
                _transp = UseTranspose::False;
                if (_myRank == 0)
                    cout << "Amesos2DirectLinearSolver::setDefaultParameters: Use transpose set to default value 'False'." << endl;
            }
        }

        // Symbolic factorization
        if (_symfact == SymbolicFactorization::Undefined)
        {
            _symfact = SymbolicFactorization::True;
            if (_myRank == 0)
                cout << "Amesos2DirectLinearSolver::setDefaultParameters: Symbolic factorization set to default value 'True'." << endl;
        }

        // Numeric factorization
        if (_numfact == NumericFactorization::Undefined)
        {
            _numfact = NumericFactorization::True;
            if (_myRank == 0)
                cout << "Amesos2DirectLinearSolver::setDefaultParameters: Numeric factorization set to default value 'True'." << endl;
        }

        // Verbosity
        if (_verbose == Verbosity::Undefined)
        {
            _verbose = Verbosity::None;
            if (_myRank == 0)
                cout << "Amesos2DirectLinearSolver::setDefaultParameters: Verbosity set to default value 'None'." << endl;
        }
    }
}
