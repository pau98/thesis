/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <numeric>

#include <dmumps_c.h>

#include "hl_Timer.h"
#include "hl_LinearSolver_Direct_MUMPS.h"


#ifdef EXTRAE_PROFILING
#include "extrae_user_events.h"
#endif

namespace hiperlife
{
    void MUMPSDirectLinearSolver::Update()
    {
        //Set default parameters and check them
        if (_paramDef == true)
            _setDefaultParameters();
        _checkSettings();

        //Get linear problem
        _getLinearProblem();

        //Set MUMPS outputs
        _icntl[1] = -1;
        _icntl[2] = -1;
        _icntl[3] = -1;
        _icntl[4] = -1;

        //Iterative refinement with a fixed number of steps IR Steps (= |ICNTL(10)|).
        //_icntl[10] = 1; //Note: It does not work with distributed solution ICNTL(21)

        //Computes statistics related to an error analysis of the linear system solved (1 more statistics than 2, but very expensive)
        //_icntl[11] = 1; //Note: It does not work with distributed solution ICNTL(21)

        //Parallelism of the root node (enabling or not the use of ScaLAPACK) and also its splitting.
        _icntl[13] = 1;

        //Percentage increase in the estimated working space (default is 20)
        _icntl[14] = _mem;

        //Set the number of openMP threads (does not seem not work)
        // _icntl[16] = 1;

        //Set ordering package
        if (static_cast<int>(_anType) != 2)
            _icntl[7]  = static_cast<int>(_ordLibrary); //7: Auto; 0: AMD; 2: AMF; 3: Scotch; 4: PORD; 5: Metis; 6: QAMD
        else if (static_cast<int>(_anType) == 2)
            _icntl[29] = static_cast<int>(_ordLibrary); //0: Auto; 1: ptscotch; 2: parmetis

        //Set analysis type
        if (static_cast<int>(_anType) == 2)
            _icntl[28] = static_cast<int>(_anType); //0: Auto; 1: Sequential; 2: Parallel

        //Set matrix input format (0: on the host; 1: structure on the host, returns a mapping and the user must distribute it; 2: structure on the host but entries of the matrix are distributed; 3: Everything distributed)
        if (numProcs() == 1 or _matrixOnHost == true)
            _icntl[18] = 0;
        else
            _icntl[18] = 3;

        //Set RHS distribution //FIXME: MUMPS 5.3.1 allows it; use id.version_number
        _icntl[20] = 0; //0: Not distributed; 1,2,3: Distributed

        //Set solution distribution
        _icntl[21] = 0; //0: Not distributed; 1: Distributed

        //Performs the forward elimination of the right-hand sides during the factorization (JOB=2).
        //_icntl[32)=1;

        // Enable diagonal scaling:
        _icntl[8] = 77;  // automatic scaling
    }

    void MUMPSDirectLinearSolver::_getMatrix()
    {
        //Initialize
        auto A = Teuchos::rcpFromRef(*_linearProblem->GetMatrix());
        _jcn_l.clear();
        _irn_l.clear();
        _a_l.clear();

        //Global descriptors
        _nCols = A->NumGlobalCols();
        _nnz   = A->NumGlobalNonzeros();

        //Local descriptors
        _nRows_l = A->NumMyRows();
        _nCols_l = A->NumMyCols();
        _nnz_l   = A->NumMyNonzeros();

        //Matrix
        for (int lid = 0; lid < _nRows_l; lid++)
        {
            const int gid = A->RowMatrixRowMap().GID(lid);
            int numEntriesInRow;
            A->NumMyRowEntries(lid, numEntriesInRow);
            double* rowvals = new double [numEntriesInRow];
            int* rowinds = new int [numEntriesInRow];
            A->ExtractMyRowCopy(lid, numEntriesInRow, numEntriesInRow, rowvals, rowinds);

            for (int i = 0; i < numEntriesInRow; i++)
            {
                if (_matType == MatrixType::General)
                {
                    _irn_l.push_back(gid + 1);
                    _jcn_l.push_back(A->RowMatrixColMap().GID(rowinds[i])+1);
                    _a_l.push_back(rowvals[i]);
                }
                else
                {
                    if (A->RowMatrixColMap().GID(rowinds[i]) >= gid)
                    {
                        _irn_l.push_back(gid + 1);
                        _jcn_l.push_back(A->RowMatrixColMap().GID(rowinds[i])+1);
                        _a_l.push_back(rowvals[i]);
                    }
                }
            }
            if (rowvals != NULL)
                delete [] rowvals;
            if (rowinds != NULL)
                delete [] rowinds;
        }

        //Modify descriptors if the matrix is symmetric
        if (_matType != MatrixType::General)
        {
            int s = _a_l.size();
            MPI_Allreduce(&s, &_nnz, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
            _nnz_l = s;
        }
    }

    void MUMPSDirectLinearSolver::_getRHS()
    {
        //Initialize
        auto rhs = _linearProblem->GetRHS();
        _rhs_l.clear();

        //rhs
        double *val = rhs->Values();
        for (int i = 0; i < rhs->MyLength(); i++)
            _rhs_l.push_back(val[i]);
    }

    void MUMPSDirectLinearSolver::_RHSToHost()
    {
        //Get sizes of local rhs
        vector<int> rsizes(_numProcs);
        MPI_Barrier(MPI_COMM_WORLD);
        int rs = _rhs_l.size();
        MPI_Allgather(&rs, 1, MPI_INT, rsizes.data(), 1, MPI_INT, MPI_COMM_WORLD);

        //Resize rhs and b
        _rhs.resize(_nCols);

        //Copy rhs to processor 0
        vector<int> displs(_numProcs);
        for (int i = 0; i < _numProcs; ++i)
            displs[i] = accumulate(rsizes.begin(), rsizes.begin()+i, 0);
        MPI_Allgatherv(_rhs_l.data(), rsizes[_myRank], MPI_DOUBLE, _rhs.data(), rsizes.data(), displs.data(), MPI_DOUBLE, MPI_COMM_WORLD);

        return;
    }

    bool MUMPSDirectLinearSolver::solve()
    {
        //Create timer
        _timer = Teuchos::rcp(new Timer({"full", "creation", "filling", "symbolicfact","numericfact", "solve", "solver"}));
        _timer->start("full");

        //Fill linear system
        _timer->start("filling");
        if (_hiperProbl!=Teuchos::null)
            _hiperProbl->FillLinearSystem();
        _timer->end("filling");

        //Compute residual
        double residual0{};
        if (_conv == ConvergenceCriteria::Relative)
        {
            auto A = _linearProblem->GetMatrix();
            auto B = _linearProblem->GetRHS();
            auto X = _linearProblem->GetLHS();
            Epetra_MultiVector Ax(B->Map(), 1);
            A->Multiply(false, *X, Ax);
            Ax.Update(1.0, *B, -1.0);
            Ax.Norm2(&residual0);
        }


        // ====================================================
        // [1] Set up MUMPS parameters and initialize it
        // ====================================================
        _timer->start("creation");
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 19);
        #endif

        //Get linear problem
        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "  Getting linear problem" << endl;
        _getMatrix();
        _getRHS();

        //Copy linear system to host (if needed)
        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "  Copying data to host" << endl;
        _RHSToHost();

        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "  Initializing mumps" << endl;

        DMUMPS_STRUC_C id; //FIXME:: Move to .h
        //Initialization of mumps (-1)
        id.job = -1;
        //Host is involved in the solution
        id.par = 1;
        //Symmetric
        id.sym = static_cast<int>(_matType);
        //Fortran communicator. Use -987654 in c
        id.comm_fortran = -987654;
        //Initialize mumps
        dmumps_c(&id);

        //Set the linear system
        if (numProcs() == 1)
        {
            id.n   = _nCols;
            id.nnz = _nnz;
            id.irn = _irn_l.data();
            id.jcn = _jcn_l.data();
            id.a   = _a_l.data();
            id.rhs = _rhs.data();
        }
        else
        {
            if (myRank() == 0)
            {
                id.n   = _nCols;
                id.rhs = _rhs.data();
            }
            id.nnz_loc = _nnz_l;
            id.irn_loc = _irn_l.data();
            id.jcn_loc = _jcn_l.data();
            id.a_loc   = _a_l.data();
        }

        //Set options
        #define ICNTL(I) icntl[(I)-1]
        for (map<int,int>::iterator it = _icntl.begin(); it != _icntl.end(); ++it)
            id.ICNTL(it->first) = it->second;
        #define CNTL(I) cntl[(I)-1]
        for (map<int,double>::iterator it = _cntl.begin(); it != _cntl.end(); ++it)
            id.CNTL(it->first) = it->second;

        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif
        _timer->end("creation");

        // ====================================================
        // [2] Solve
        // ====================================================

        _timer->start("solver");

        //Analysis
        _timer->start("symbolicfact");
        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "  Analysis phase" << endl;
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 20);
        #endif
        id.job = 1;
        dmumps_c(&id);
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif
        if (id.infog[1-1] < 0)
        {
            if (id.info[1-1] != -1)
            {
                cout << "Error: Mumps exited with error " << id.info[1-1] << " and info " << id.info[2-1] << " on processor " << myRank() << "during the analysis phase." << endl;
            }
        }
        _timer->end("symbolicfact");

        //Factorization
        _timer->start("numericfact");
        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "  Factorization phase" << endl;
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 21);
        #endif
        id.job = 2;
        dmumps_c(&id);
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif
        if (id.infog[1-1] < 0)
        {
            if (id.info[1-1] != -1)
            {
                cout << "Error: Mumps exited with error " << id.info[1-1] << " and info " << id.info[2-1] << " on processor " << myRank() << "during the factorization phase." << endl;
            }
        }
        _timer->end("numericfact");

        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "  Number of negative pivots " << id.infog[12-1] << endl;

        //Solve
        _timer->start("solve");
        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "  Solve phase" << endl;
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 22);
        #endif
        id.job = 3;
        dmumps_c(&id);
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif
        if (id.infog[1-1] < 0)
        {
            if (id.info[1-1] != -1)
            {
                cout << "Error: Mumps exited with error " << id.info[1-1] << " and info " << id.info[2-1] << " on processor " << myRank() << "during the solve phase." << endl;
            }
        }
        _timer->end("solve");

        // ====================================================
        // [3] Save solution and info
        // ====================================================

        //Share solution
        if (myRank() == 0)
        {
            for (size_t i = 0; i < _rhs.size(); i++)
                _rhs[i] = id.rhs[i];
        }
        MPI_Bcast(_rhs.data(), _nCols, MPI_DOUBLE, 0, MPI_COMM_WORLD);

        //Save solution
        auto sol = _linearProblem->GetLHS();
        for (int lid = 0; lid < _nRows_l; lid++)
        {
            const int gid = sol->Map().GID(lid);
            sol->ReplaceGlobalValue(gid, 0, _rhs[gid]);
        }

        //Save info
        _usedAnType = static_cast<AnalysisType>(id.infog[32-1]);
        _usedOrdLibrary = static_cast<OrderingLibrary>(id.infog[7-1]);

        _timer->end("solver");

        // ====================================================
        // [4] Output statistics
        // ====================================================
        // if (myRank() == -10) //FIXME:: verb extreme
        // {
        //     cout << endl
        //          << "Infinite matrix norm   :" << id.rinfog[3] << endl
        //          << "Infinite solution norm :" << id.rinfog[4] << endl
        //          << "Scaled residual        :" << id.rinfog[5] << endl
        //          << "w1 backward error      :" << id.infog[7] << endl
        //          << "w2 backward error      :" << id.infog[8] << endl
        //          << "error estimate         :" << id.infog[9] << endl
        //          << "Condition number 1     :" << id.rinfog[10] << endl
        //          << "Condition number 2     :" << id.rinfog[11] << endl
        //          << "??                     :" << id.rinfog[9] << endl
        //          << endl;
        //     // for (int i = 1; i < 20; i++)
        //     //     cout << i << " : " << id.info[i] << endl;
        // }


        // ====================================================
        // [5] End MUMPS
        // ====================================================
        if (myRank() == 0 and _verbose == Verbosity::Extreme)
            cout << "End MUMPS" << endl;
        id.job = -2;
        dmumps_c(&id);


        // ====================================================
        // [6] Get residual and output info
        // ====================================================

        //Compute residual
        auto A = _linearProblem->GetMatrix();
        auto B = _linearProblem->GetRHS();
        auto X = _linearProblem->GetLHS();
        Epetra_MultiVector Ax(B->Map(), 1);
        A->Multiply(false, *X, Ax);
        Ax.Update(1.0, *B, -1.0);
        Ax.Norm2(&_residual);

        //Save convergence
        if (_conv == ConvergenceCriteria::Absolute and _residual < _tol)
            _converged = true;
        else if (_conv == ConvergenceCriteria::Relative and _residual/residual0 < _tol)
            _converged = true;

        //End timer
        _timer->end("full");

        //Output if requested
        if (_verbose != Verbosity::Undefined)
            output(_verbose);

        return _converged;
    }

    void MUMPSDirectLinearSolver::output(Verbosity verbose, std::ostream& out)
    {
        if (verbose == Verbosity::Undefined)
            throw runtime_error("MUMPSDirectLinearSolver::output: Verbosity has not been defined");

        int _verInt = static_cast<int>(verbose);
        if (_verInt >= 1)
        {
            using namespace std;

            if (_myRank == 0)
            {
                out << "================================================" << endl;
                out << "Direct linear solver MUMPS" << endl;
                if (_verInt >= 3)
                {
                    out << "   Matrix type:      " << str(_matType) << endl;
                    out << "   Analysis type:    " << str(_usedAnType) << endl;
                    out << "   Ordering library: " << str(_usedOrdLibrary, _usedAnType) << endl;
                }
                out << "Converged = " << boolalpha << _converged << endl;
                if (_verInt >= 2)
                    out << "Residual  = " << _residual << endl;
                if (_verInt >= 3)
                {
                    out << "Time      = " << _timer->printAccumTime("full") << endl;
                    out << "   Filling  = " << _timer->printAccumTime("filling") << endl;
                    out << "   Solver   = " << _timer->printAccumTime("creation") + _timer->printAccumTime("solver") << endl;
                    out << "      Creation phase        = " << _timer->printAccumTime("creation") << endl;
                    out << "      Analysis phase        = " << _timer->printAccumTime("symbolicfact") << endl;
                    out << "      Factorization phase   = " << _timer->printAccumTime("numericfact") << endl;
                    out << "      Solve phase           = " << _timer->printAccumTime("solve") << endl;

                }
                out << "================================================" << endl;
            }
        }
    }

    double MUMPSDirectLinearSolver::time(TimerName tim)
    {
        double _times = -1.0;
        if (tim == TimerName::Undefined)
            throw runtime_error("MUMPSDirectLinearSolver::checkSettings: Timer Name has not been defined");
        else if (tim == TimerName::Total)
            _times = _timer->printAccumTime("full");
        else if (tim == TimerName::SolverCreation)
            _times = _timer->printAccumTime("creation");
        else if (tim == TimerName::Filling)
            _times = _timer->printAccumTime("filling");
        else if (tim == TimerName::SymbolicFactorization)
            _times = _timer->printAccumTime("symbolicfact");
        else if (tim == TimerName::NumericFactorization)
            _times = _timer->printAccumTime("numericfact");
        else if (tim == TimerName::Solve)
            _times = _timer->printAccumTime("solve");
        else if (tim == TimerName::Solver)
            _times = _timer->printAccumTime("solver");
        return _times;
    }

    void MUMPSDirectLinearSolver::_checkSettings()
    {
        //Check MatrixType
        if (_matType == MatrixType::Undefined)
            throw runtime_error("MUMPSDirectLinearSolver::checkSettings: The matrix type has not been defined.");

        //Check AnalysisType
        if (_anType == AnalysisType::Undefined)
        {
            throw runtime_error("MUMPSDirectLinearSolver::checkSettings: The analysis type has not been defined.");
        }
        else if (_anType == AnalysisType::Parallel and _numProcs == 1)
        {
            cout << endl << "Warning::" << endl << "   MUMPSDirectLinearSolver::checkSettings: You have selected parallel analysis, but you are running on one processor only."<< endl << "   Changing to sequential analysis and automatic ordering library" << endl << endl;
            _anType = AnalysisType::Sequential;
            _ordLibrary = OrderingLibrary::Auto;
        }

        //Check OrderingLibrary
        if (_ordLibrary == OrderingLibrary::Undefined)
            throw runtime_error("MUMPSDirectLinearSolver::checkSettings: The ordering library has not been defined.");

        //Check compatibilities AnalysisType <-> OrderingLibrary
        if (_anType == AnalysisType::Sequential and (_ordLibrary == OrderingLibrary::Parmetis or _ordLibrary == OrderingLibrary::PtScotch))
            throw runtime_error("MUMPSDirectLinearSolver::checkSettings: Ordering libraries Parmetis/PtScotch or not compatible with sequential analysis.");
        if (_anType == AnalysisType::Parallel and (_ordLibrary != OrderingLibrary::Auto and _ordLibrary != OrderingLibrary::Parmetis and _ordLibrary != OrderingLibrary::PtScotch))
            throw runtime_error("MUMPSDirectLinearSolver::checkSettings: The ordering libraries Parmetis/PtScotch are the only ones compatible with parallel analysis.");

    }

    void MUMPSDirectLinearSolver::_setDefaultParameters()
    {
        // MatrixType
        if (_matType == MatrixType::Undefined)
        {
            _matType = MatrixType::General;
            if (_myRank == 0)
                cout << "MUMPSDirectLinearSolver::setDefaultParameters: MatrixType set to default value 'General'." << endl;
        }

        // AnalysisType
        if (_anType == AnalysisType::Undefined)
        {
            if (_numProcs == 1)
                _anType = AnalysisType::Sequential;
            else
                _anType = AnalysisType::Parallel;
            if (_myRank == 0)
                cout << "MUMPSDirectLinearSolver::setDefaultParameters: AnalysisType set to default value '"<< str(_anType) << "'." << endl;
        }

        // OrderingLibrary
        if (_ordLibrary == OrderingLibrary::Undefined)
        {
            _ordLibrary = OrderingLibrary::Auto;
            if (_myRank == 0)
                cout << "MUMPSDirectLinearSolver::setDefaultParameters: OrderingLibrary set to default value 'Auto'." << endl;
        }

        // Convergence criteria
        if (_conv == ConvergenceCriteria::Undefined)
        {
            _conv = ConvergenceCriteria::Relative;
            if (_myRank == 0)
                cout << "MUMPSDirectLinearSolver::setDefaultParameters: ConvergenceCriteria set to default value 'Relative'." << endl;
        }

        // Tolerance
        if (_tol == -1.0)
        {
            _tol = 1E-8;
            if (_myRank == 0)
                cout << "MUMPSDirectLinearSolver::setDefaultParameters: Tolerance set to default value '1E-8'." << endl;
        }

        // Verbosity
        if (_verbose == Verbosity::Undefined)
        {
            _verbose = Verbosity::None;
            if (_myRank == 0)
                cout << "MUMPSDirectLinearSolver::setDefaultParameters: Verbosity set to default value 'None'." << endl;
        }
    }

    std::string MUMPSDirectLinearSolver::str(MatrixType matType)
    {
        switch(matType)
        {
            case MatrixType::General:
                return "General";
            case MatrixType::SPD:
                return "SPD";
            case MatrixType::Symmetric:
                return "Symmetric";
            default:
                return "Undefined";
        }
    }

    std::string MUMPSDirectLinearSolver::str(AnalysisType anType)
    {
        switch(anType)
        {
            case AnalysisType::Sequential:
                return "Sequential";
            case AnalysisType::Parallel:
                return "Parallel";
            default:
                return "Undefined";
        }
    }

    std::string MUMPSDirectLinearSolver::str(OrderingLibrary ordLibrary, AnalysisType anType)
    {
        if (anType == AnalysisType::Sequential)
        {
            switch(ordLibrary)
            {
                case OrderingLibrary::AMD:
                    return "AMD";
                case OrderingLibrary::AMF:
                    return "AMF";
                case OrderingLibrary::Scotch:
                    return "Scotch";
                case OrderingLibrary::PORD:
                    return "PORD";
                case OrderingLibrary::Metis:
                    return "Metis";
                case OrderingLibrary::QAMD:
                    return "QAMD";
                case OrderingLibrary::Auto:
                    return "Auto";
                default:
                    return "Undefined";
            }
        }
        else if (anType == AnalysisType::Parallel)
        {
            switch(ordLibrary)
            {
                case OrderingLibrary::Parmetis:
                    return "Parmetis";
                case OrderingLibrary::PtScotch:
                    return "PtScotch";
                case OrderingLibrary::Auto:
                    return "Auto";
                default:
                    return "Undefined";
            }
        }
        else
        {
            throw runtime_error("MUMPSDirectLinearSolver::str(ord,an): Analysis type not defined.");
            return "Error";
        }
    }

}
