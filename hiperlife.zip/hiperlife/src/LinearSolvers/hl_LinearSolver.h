/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LINEARSOLVER_H
#define LINEARSOLVER_H

#include <Teuchos_RCP.hpp>
#include <Epetra_LinearProblem.h>

#include "hl_StTimer.h"
#include "hl_HiPerProblem.h"

namespace hiperlife
{
    /*!
    * \class LinearSolver
    * \brief Model virtual class for linear solvers
    *
    * Every other Linear Solver inherits from this class.
    *
   */
    class LinearSolver : public DistributedClass
    {
        public:
            /** @name Constructor / Destructor / Operator
            *  @{ */
            LinearSolver() = default;
            LinearSolver(LinearSolver &&other) = default;
            LinearSolver& operator=(LinearSolver&& other) = default;

            LinearSolver& operator=(const LinearSolver& other) = delete;
            LinearSolver(const LinearSolver& other) = delete;
            /** @} */ // end of constructors
            /** \name Solve Method
             * \brief Solver returns \ref boolean indicating convergence
             *
            *  @{ */
            /*! \brief Solve the system according to the parameters specified */
            virtual bool solve() = 0;
            /*! \brief Return the bool for convergence */
            bool converged(){return _converged;};
            /** @} */ // end solve
            /** \name Update Solution Method
             *
             *  @{ */
            /*!* \brief Updates the solver solution into the HiPerProblem */
            virtual void UpdateSolution()
            {
                if(_hiperProbl!=Teuchos::null)
                    _hiperProbl->UpdateSolution();
                else
                    throw runtime_error("LinearSolver::UpdateSolution: The HiPerProblem has not been set.");
            };
            /** @} */ // end solve
            /** \name Solver Update
             *
            *  @{ */
            /*!* \brief Links the HiPerProblem to the solver and settles all the solver parameters */
            virtual void Update() = 0;
            /** @} */
            void setLinearProblem(Teuchos::RCP<Epetra_LinearProblem> linearProblem)
            {
                if (_hiperProbl == Teuchos::null)
                    _linearProblem = linearProblem;
                else
                    throw runtime_error("LinearSolver::setLinearProblem: cannot set linear problem if HiPerProblem has already been set");
            }
            /** \name HiPerProblem set
             *
            *  @{ */
            /*! \brief Specifies which HiPerProblem is linked to the solver */
            void setHiPerProblem(Teuchos::RCP<HiPerProblem> hiperProbl)
            {
                if (_linearProblem == Teuchos::null)
                    _hiperProbl = hiperProbl;
                else
                    throw runtime_error("LinearSolver::setHiPerProblem: cannot set HiPerProblem if linear problem has already been set");
            }
            /** @} */
            /** \name Verbose and output
             *
            *  @{ */
            /*! \brief Defines the verbosity of the output */
            enum class Verbosity
            {
                Undefined = -1,
                None      =  0,
                Low       =  1,
                Medium    =  2,
                High      =  3,
                Extreme   =  4
            };
            /*! \brief Defines whether we want an output of the solver status each time we solve
            * \param verbose false if we do not want output, true if we do
            * */
            void setVerbosity(Verbosity verbose){_verbose = verbose;};
            /*! \brief Plots the solver status
            * \param out Output method
            * \param verInt Verbosity of the output
            * */
            virtual void output(Verbosity verbose, std::ostream& out) = 0;
            /** @} */
            /** \name Default parameters
             *
            *  @{ */
            /*! \brief Use hiperlife default parameters if they have not been explicitly specified */
            void setDefaultParameters(){_paramDef = true;};
            /** @} */

            /** @name Information access methods
            *  @{
            */
            Teuchos::RCP<HiPerProblem> hiperProblem(){return _hiperProbl;};
            Teuchos::RCP<Epetra_LinearProblem> linearProblem(){return _linearProblem;};
            Teuchos::RCP<Timer> timer(){return _timer;};
            /** @} */ // end of information access methods


        protected:
            Teuchos::RCP<Epetra_LinearProblem> _linearProblem = Teuchos::null;
            Teuchos::RCP<HiPerProblem> _hiperProbl = Teuchos::null;
            bool _converged{};
            bool _paramDef{false};
            Teuchos::RCP<Timer> _timer;
            Verbosity _verbose = Verbosity::Undefined;

            /*! \brief Links the HiPerProblem to the linear solver */
            void _getLinearProblem()
            {
                if (_hiperProbl != Teuchos::null)
                    _linearProblem = _hiperProbl->linProbl;
            }
            /*! \brief Checks if all the solver parameters and HiPerProblem have been properly defined */
            virtual void _checkSettings() = 0;
            /*! \brief Sets for each solver the hiperlife default parameters in case they have not been explicitly specified*/
            virtual void _setDefaultParameters() = 0;
            /*! \brief Returns \ref printed on screen the status of the solver */


        friend class NonlinearSolver;

    };
}


#endif //HIPERLIFE_LINEARSOLVER_H
