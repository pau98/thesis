/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DIRECT_AMESOS2_H
#define DIRECT_AMESOS2_H

#include <mpi.h>
#include <string>

#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>
#include <Epetra_MultiVector.h>
#include <Epetra_LinearProblem.h>
#include <Amesos2.hpp>

#include "hl_LinearSolver_Direct.h"

namespace hiperlife
{

    /*!
    * \class Direct_Amesos2
    * \brief Direct Solvers
    *
    * It uses several solvers from Trilinos's Amesos2 package
    * https://trilinos.org/docs/dev/packages/amesos2/doc/html/index.html
    *
    * The solvers SuperLU_Dist, Mumps work in parallel.
    * Only Klu and Mumps have been tested so far.
    *
   */
    class Amesos2DirectLinearSolver : public DirectLinearSolver
    {
        public:

            Amesos2DirectLinearSolver(){};

            /** @name Constructor / Destructor / Operator
            *  @{ */
            Amesos2DirectLinearSolver(Amesos2DirectLinearSolver &&other) = default;
            virtual ~Amesos2DirectLinearSolver() = default;
            Amesos2DirectLinearSolver& operator=(Amesos2DirectLinearSolver&& other) = default;

            Amesos2DirectLinearSolver& operator=(const Amesos2DirectLinearSolver& other) = delete;
            Amesos2DirectLinearSolver(const Amesos2DirectLinearSolver& other) = delete;
            /** @} */ // end of constructors

            bool solve() override;
            void Update() override;
            void output(Verbosity verbose = Verbosity::Undefined, std::ostream& out = std::cout) override;

            /*! \brief Defines the type of solver that we are using. */
            enum class Solver
            {
                Undefined    = -1,
                /*! https://trilinos.org/packages/amesos2/ */
                ShyLU_Basker =  0,
                /*! https://trilinos.org/packages/amesos2/ */
                Basker       =  1,
                /*! https://users.encs.concordia.ca/~krzyzak/R%20Code-Communications%20in%20Statistics%20and%20Simulation%202014/Zubeh%F6r/SuiteSparse/KLU/Doc/KLU_UserGuide.pdf */
                Klu          =  2,
                /*! http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.366.2886&rep=rep1&type=pdf */
                SuperLU_Dist =  3,
                /*! http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.366.2886&rep=rep1&type=pdf */
                SuperLU_MT   =  4,
                /*! https://users.encs.concordia.ca/~krzyzak/R%20Code-Communications%20in%20Statistics%20and%20Simulation%202014/Zubeh%F6r/SuiteSparse/UMFPACK/Doc/UserGuide.pdf */
                Umfpack      =  5,
                /*! https://www.sandia.gov/~srajama/publications/tacho_ipdps18.pdf */
                Tacho        =  6,
                /*! http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.366.2886&rep=rep1&type=pdf */
                SuperLU      =  7,
                /*! https://pardiso-project.org/manual/manual.pdf */
                Pardiso_MKL  =  8,
                /*! https://www.netlib.org/lapack/lug/ */
                Lapack       =  9,
                /*! http://mumps.enseeiht.fr/doc/userguide_5.2.1.pdf */
                Mumps        = 10,
                /*! https://usermanual.wiki/Document/CHOLMODUserGuide.393504250 */
                Cholmod      = 11
            };
            /*! \brief Settles the timer we want to print. */
            enum class TimerName
            {
                Undefined             = -1,
                Total                 =  0,
                SolverCreation        =  1,
                Filling               =  2,
                NumericFactorization  =  3,
                SymbolicFactorization =  4,
                Solver                =  5
            };
            // Amesos2 does not support matrix type interface
            /*enum class MatrixType
            {
                Undefined = -1,
                General   =  0,
                SPD       =  1,
                Symmetric =  2
            };*/
            /** @name Amesos2 Direct Linear Solver parameters
            *  @{ */
            /*! \brief Sets which solver is used. Default: Klu.
            * \param type Solver specified by enum class Solver
            */
            void setSolver(Solver type){_type = type;}
            /*! \brief Returns the time of a process.
            * \param timer Timer specifying the process desired.
            */
            double time(TimerName tim = TimerName::Undefined);
            //void setMatrixType(MatrixType matType){_matType = matType;}
            /** @} */

        private:
            Solver _type = Solver::Undefined;
            //MatrixType _matType = MatrixType::Undefined;
            Teuchos::ParameterList _amesos2_params;
            Teuchos::RCP<Amesos2::Solver<Epetra_CrsMatrix, Epetra_MultiVector>> _solver = Teuchos::null;
            std::string _solverName;
            std::vector<std::string> _listSolv = {"ShyLU Basker",
                                                  "Basker",
                                                  "Klu",
                                                  "SuperLU Dist",
                                                  "SuperLU MT",
                                                  "Umfpack",
                                                  "Tacho",
                                                  "SuperLU",
                                                  "Pardiso MKL",
                                                  "Lapack",
                                                  "Mumps",
                                                  "Cholmod"
                                                  };
            std::vector<std::string> _SolverNameList  = {"ShyLUBasker", "Basker", "KLU2", "superludist", "superlumt", "umfpack", "tacho", "SuperLU", "pardisomkl", "lapack", "MUMPS", "amesos2_cholmod"};
            double _residual{};
            const double _tol{1.E-8}; //FIXME: is there a way to know whether amesos2 has converge? Jordi look at this, please

        protected:
            void _checkSettings() override;
            void _setDefaultParameters() override;
    };
}




#endif //DIRECT_AMESOS2_H
