/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DIRECT_MUMPS_H
#define DIRECT_MUMPS_H

#include <mpi.h>
#include <string>

#include <Teuchos_RCP.hpp>
#include <Epetra_LinearProblem.h>

#include "hl_LinearSolver.h"

namespace hiperlife
{

    /*!
    * \class Direct_MUMPS
    * \brief Direct Solvers
    *
    * Implementation of the MUltifrontal Massively Parallel sparse direct Solver
    * http://mumps.enseeiht.fr/
    *
   */
    class MUMPSDirectLinearSolver : public LinearSolver
    {
        public:

            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects can be created from
             *  temporal objects through move constructors
             *  @{ */
            MUMPSDirectLinearSolver(){};
            MUMPSDirectLinearSolver(MUMPSDirectLinearSolver &&other) = default;
            ~MUMPSDirectLinearSolver() = default;
            MUMPSDirectLinearSolver& operator=(MUMPSDirectLinearSolver&& other) = default;
            //Operators
            MUMPSDirectLinearSolver& operator=(const MUMPSDirectLinearSolver& other) = delete;
            MUMPSDirectLinearSolver(const MUMPSDirectLinearSolver& other) = delete;
            /** @} */ // end of constructors

            /** @name Main enum classes
             *  @{ */
            /*! \brief Timer name. */
            enum class TimerName
            {
                Undefined             = -1,
                Total                 =  0,
                SolverCreation        =  1,
                Filling               =  2,
                NumericFactorization  =  3,
                SymbolicFactorization =  4,
                Solve                 =  5,
                Solver                =  6
            };
            /*! \brief The type of matrix. */
            enum class MatrixType
            {
                Undefined = -1,
                General   =  0,
                SPD       =  1,
                Symmetric =  2
            };
            /*! \brief Analysis type. */
            enum class AnalysisType
            {
                Undefined  = -1,
                Sequential =  1,
                Parallel   =  2
            };
            /*! \brief Ordering library. */
            enum class OrderingLibrary
            {
                Undefined = -1,
                AMD       =  0,
                AMF       =  2,
                Scotch    =  3,
                PORD      =  4,
                Metis     =  5,
                QAMD      =  6,
                PtScotch  =  1,
                Parmetis  =  2,
                Auto      =  7
            };
            /*! \brief Specifies the convergence criteria (less than tolerance) */
            enum class ConvergenceCriteria
            {
                Undefined = -1,
                Relative  =  0,
                Absolute  =  1
            };
            /** @} */ // end enums


            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the type of matrix.
              \param matType MatrixType enum
             */
            void setMatrixType(MatrixType matType){_matType = matType;}
            /*! \brief Sets the type of analysis.
              \param anType AnalysisType enum
             */
            void setAnalysisType(AnalysisType anType){_anType = anType;}
            /*! \brief Set the ordering library.
              \param ordLibrary OrderingLibrary enum
             */
            void setOrderingLibrary(OrderingLibrary ordLibrary){_ordLibrary = ordLibrary;}
            /*! \brief Sets which convergence criteria is used. Default: Relative.
            * \param type Convergence criteria specified by enum class Convergence
            */
            void setConvergenceCriteria(ConvergenceCriteria conv){_conv = conv;}
            /*! \brief Sets the convergence tolerance criteria. Default: 1.E-8.
            * \param tol Tolerance
            */
            void setTolerance(double tol){_tol = tol;};
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of primary object creation


            /** @name Expert user object creation management
             * Parameters for the creation of the object for expert users.
             * All of them have a default value for non-experts.
             */
            /*! \brief Set the increase in internal memory workspace for MUMPs
              \param mem Percentage of memory increase (default: 20%)
             */
            void setWorkSpaceMemoryIncrease(int mem){_mem = mem;};
            /** @} */ // end of expert user object creation management


            /** @name Main methods:
             *  @{
             */
            /*! \brief Solve the linear system.*/
            bool solve() override;
            /** @} */

            /** @name Information access methods
             *  @{
             */
            /*! \brief Output information about the solver
             * \param verbose Verbosity level
             * \param out ostream. Default cout
             .*/
            void output(Verbosity verbose = Verbosity::Undefined, std::ostream& out = std::cout) override;
            /*! \brief Output times of the different phases.
             * \param tName TimerName
             */
            double time(TimerName tName = TimerName::Undefined);
            /** @} */

            /** @name Auxiliary functions:
             *  @{
             */
            std::string str(MatrixType matType);
            std::string str(AnalysisType anType);
            std::string str(OrderingLibrary ordLibrary, AnalysisType anType);
            /** @} */

            /** @name Expert users and developers only
             *  @{ */
            /*! \brief Set MUMPS integer control parameter.
              \param idx Index to be set
              \param value Value of the index
             */
            void _setICNTL(int idx, int value){_icntl[idx] = value;};
            /*! \brief Set MUMPS double control parameter.
              \param idx Index to be set
              \param value Value of the index
             */
            void _setCNTL(int idx, double value){_cntl[idx] = value;};
            /** @} */ // end of Expert users and developers only


        private:

            //Main options
            MatrixType _matType = MatrixType::Undefined;
            AnalysisType _anType = AnalysisType::Undefined;
            OrderingLibrary _ordLibrary = OrderingLibrary::Undefined;
            ConvergenceCriteria _conv = ConvergenceCriteria::Undefined;
            int _matrixOnHost{0};
            double _residual{};
            double _tol{-1.0};
            int _mem{20};

            //Auxiliary variables
            AnalysisType _usedAnType = AnalysisType::Undefined;
            OrderingLibrary _usedOrdLibrary = OrderingLibrary::Undefined;
            std::map<int,int> _icntl;
            std::map<int,double> _cntl;

            void _getMatrix();
            void _getRHS();
            void _RHSToHost();

            //Initialize main variables
            int _nCols, _nnz;
            int _nRows_l, _nCols_l, _nnz_l;
            //Matrix
            std::vector<int> _irn_l, _irn;
            std::vector<int> _jcn_l, _jcn;
            std::vector<double> _a_l, _a;
            //RHS and solution
            std::vector<double> _rhs_l, _rhs;


        protected:
            void _checkSettings() override;
            void _setDefaultParameters() override;
    };
}


#endif //DIRECT_MUMPS
