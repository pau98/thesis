/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DIRECTLINEARSOLVER_H
#define DIRECTLINEARSOLVER_H

#include <Epetra_LinearProblem.h>
#include <Teuchos_ParameterList.hpp>

#include "hl_LinearSolver.h"

namespace hiperlife
{
    /*!
    * \class DirectLinearSolver
    * \brief Model virtual class for direct linear solvers
    *
    */
    class DirectLinearSolver : public LinearSolver
    {
        public:
            /** @name Constructor / Destructor / Operator
            *  @{ */
            DirectLinearSolver() = default;

            DirectLinearSolver(DirectLinearSolver &&other) = default;
            DirectLinearSolver& operator=(DirectLinearSolver&& other) = default;

            DirectLinearSolver& operator=(const DirectLinearSolver& other) = delete;
            DirectLinearSolver(const DirectLinearSolver& other) = delete;
            /** @} */ // end of constructors
            /*! \brief Defines if we solve the transposed system or not. */
            enum class UseTranspose
            {
                Undefined = -1,
                /*! Solve \f$ (A^T)x=b \f$ */
                True      =  0,
                /*! Solve \f$ Ax=b \f$ */
                False     =  1,
            };
            /*! \brief Defines if we use Symbolic Factorization or not. */
            enum class SymbolicFactorization
            {
                Undefined = -1,
                True      =  0,
                False     =  1,
            };
            /*! \brief Defines if we use Numeric Factorization or not. */
            enum class NumericFactorization
            {
                Undefined = -1,
                True      =  0,
                False     =  1,
            };
            /** @name Direct Linear Solver parameters
            *  @{ */
            /*! \brief Specifies if we study the system Ax=b or (A^T)x=b. Default: false.
            * \param transp false for Ax=b, true for (A^T)x=b
            */
            void setUseTranspose(bool transp){_transp = (transp == true) ? UseTranspose::True : UseTranspose::False;}
            /*! \brief Specifies if we use Symbolic Factorization or not. Default: true.
            * \param symfact false if we do not use Symbolic Facotrization, true if we do
            */
            void setSymbolicFactorization(bool symfact){_symfact = (symfact == true) ? SymbolicFactorization::True : SymbolicFactorization::False;}
            /*! \brief Specifies if we use Numeric Factorization or not. Default: true.
            * \param numfact false if we do not use Numeric Facotrization, true if we do
            */
            void setNumericFactorization(bool numfact){_numfact = (numfact == true) ? NumericFactorization::True : NumericFactorization::False;}
            /** @} */

        protected:
            UseTranspose _transp = UseTranspose::Undefined;
            SymbolicFactorization _symfact = SymbolicFactorization::Undefined;
            NumericFactorization  _numfact = NumericFactorization::Undefined;
    };
}


#endif //DIRECTLINEARSOLVER_H
