/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ITERATIVE_AZTECOO_H
#define ITERATIVE_AZTECOO_H

#include <mpi.h>
#include <string>

#include <AztecOO.h>
#include <Epetra_LinearProblem.h>

#include "hl_LinearSolver_Iterative.h"

namespace hiperlife
{
    /*!
    * \class AztecOOIterativeLinearSolver
    * \brief Interface for AztecOO package
    *
    * It supports a variety of iterative solvers like CG and GMRES
    * https://trilinos.org/docs/dev/packages/aztecoo/doc/html/index.html
    *
    * All the options of the package are compatible with the interface and can be used.
   */
    class AztecOOIterativeLinearSolver : public IterativeLinearSolver
    {
        public:

            /** @name Constructor / Destructor / Operator
            *  @{ */
            AztecOOIterativeLinearSolver(){};

            AztecOOIterativeLinearSolver(AztecOOIterativeLinearSolver &&other) = default;
            ~AztecOOIterativeLinearSolver() = default;
            AztecOOIterativeLinearSolver& operator=(AztecOOIterativeLinearSolver&& other) = default;

            AztecOOIterativeLinearSolver& operator=(const AztecOOIterativeLinearSolver& other) = delete;
            AztecOOIterativeLinearSolver(const AztecOOIterativeLinearSolver& other) = delete;
            /** @} */ // end of constructors

            bool solve() override;
            void Update() override;
            void output(Verbosity verbose = Verbosity::Undefined, std::ostream& out = std::cout) override;
            /*! \brief Defines the type of solver that we are using */
            enum class Solver
            {
                Undefined       = -1,
                /*! Conjugate Gradient */
                ConjGrad        =  0,
                /*! Restarted Generalized Minimal Residual */
                Gmres           =  1,
                /*!  Conjugate Gradient Squared */
                ConjGradS       =  2,
                /*! Transpose-Free Quasi-Minimal Residual */
                Tfqmr           =  3,
                /*! Bi-Conjugate Gradient with stabilization */
                Bicgstab        =  4,
                /*! Conjugate Gradient with condition number estimation */
                ConjGradCondNum = 11,
                /*! Restarted GMRES with condition number estimation */
                GmresCondNum    = 12
            };
            /*! \brief Defines the type of preconditioner that we are using */
            enum class Precond
            {
                Undefined      = -1,
                /*!  No preconditioning */
                None           =  0,
                /*! Block Jacobi for DVBR matrices where each block corresponds to a VBR block */
                Jacobi         =  1,
                /*! Non-overlapping domain decomposition (additive Schwarz) k step symmetric Gauss-Siedel */
                SymGaussSeidel =  2,
                /*! Neumann series polynomial */
                Neumann        =  3,
                /*! Least-Squares polynomial */
                LeastSquares   =  4,
                /*! Domain Decomposition (additive Schwarz) */
                DomainDecomp   = 14
            };
            /*! \brief Defines the type of preconditioner that we are using */
            enum class Preconditioner
            {
                Undefined      = -1,
                /*!  No preconditioning */
                None           =  0,
                /*! Block Jacobi for DVBR matrices where each block corresponds to a VBR block */
                Jacobi         =  1,
                /*! Non-overlapping domain decomposition (additive Schwarz) k step symmetric Gauss-Siedel */
                SymGaussSeidel =  2,
                /*! Neumann series polynomial */
                Neumann        =  3,
                /*! Least-Squares polynomial */
                LeastSquares   =  4,
                /*! Domain Decomposition (additive Schwarz) */
                DomainDecomp   = 14
            };
            /*! \brief Specifies the solver to use on each subdomain when the preconditioner is DomainDecomp */
            enum class SubdomainSolve
            {
                Undefined = -1,
                /*! Incomplete LU factorization in subdomains */
                Ilu       =  6,
                /*! Block ILU in subdomains*/
                Bilu      =  7,
                /*! Incomplete Choleski factorization in domains */
                Icc       =  8,
                /*! A dual threshold Incomplete LU factorization in subdomains */
                Ilut      =  9,
                /*! Relaxed Incomplete LU factorization in subdomains */
                Rilu      = 11
            };
            /*! \brief Specifies the convergence criteria (less than tolerance) */
            enum class Convergence
            {
                Undefined = -1,
                /*! \f$ ||r||_2 / ||r^{(0)}||_2 \f$ */
                Relative  =  0,
                /*! \f$ ||r||_2 \f$ */
                Absolute  =  6,
                /*! \f$ ||r||_2 / ||b||_2 \f$ */
                RHS       =  1,
                /*! \f$ ||r||_2 / ||A||_\infty \f$ */
                Anorm     =  2,
                /*! \f$ ||r||_\infty/(||A||_\infty ||x||_1+||b||_\infty) \f$ */
                Sol       =  3
            };
            /*! \brief Specifies the convergence criteria (less than tolerance) */
            enum class ConvergenceCriteria
            {
                Undefined = -1,
                /*! \f$ ||r||_2 / ||r^{(0)}||_2 \f$ */
                Relative  =  0,
                /*! \f$ ||r||_2 \f$ */
                Absolute  =  6,
                /*! \f$ ||r||_2 / ||b||_2 \f$ */
                RHS       =  1,
                /*! \f$ ||r||_2 / ||A||_\infty \f$ */
                Anorm     =  2,
                /*! \f$ ||r||_\infty/(||A||_\infty ||x||_1+||b||_\infty) \f$ */
                Sol       =  3
            };
            /*! \brief Settles the timer we want to print. */
            enum class TimerName
            {
                Undefined = -1,
                Total     =  0,
                Filling   =  1,
                Solver    =  2
            };
            /** @name AztecOO Iterative Linear Solver parameters
            *  @{ */
            /*! \brief Sets which solver is used. Default: Gmres.
            * \param type Solver specified by enum class Solver
            */
            void setSolver(Solver type){_type = type;}
            /*! \brief Sets which preconditioner is used. Default: None.
            * \param prec Preconditioner specified by enum class Preconditioner
            */
            [[deprecated("This function is deprecated and will be removed in the next major release. Please, use setPreconditioner(Preconditioner prec) instead.")]]
            void setPrecond(Precond prec){_prec = static_cast<Preconditioner>(prec);}
            void setPreconditioner(Preconditioner prec){_prec = prec;}
            /*! \brief Sets which subdomain is used. No default parameter. If the DomainDecomp preconditiones is chosen, it is mandatory to set SubdomainSolve explicitly.
            * \param subSol Subdomain specified by enum class SubdomainSolve
            */
            void setSubdomainSolve(SubdomainSolve subSol){_subSol = subSol;}
            /*! \brief Sets which convergence criteria is used. Default: Relative.
            * \param type Convergence criteria specified by enum class Convergence
            */
            [[deprecated("This function is deprecated and will be removed in the next major release. Please, use setConvergenceCriteria(ConvergenceCriteria conv) instead.")]]
            void setConvergence(Convergence conv){_conv = static_cast<ConvergenceCriteria>(conv);}
            void setConvergenceCriteria(ConvergenceCriteria conv){_conv = conv;}
            /*! \brief Returns the solver true residual. */
            [[deprecated("This function is deprecated and will be removed in the next major release. Please, use trueResidual() instead.")]]
            double getTrueResidual(){return _solver->TrueResidual();}
            double trueResidual(){return _solver->TrueResidual();}
            /*! \brief Returns the time of a process.
            * \param timer Timer specifying the process desired.
            */
            double time(TimerName tim = TimerName::Undefined);
            /** @} */

        private:
            Teuchos::RCP<AztecOO> _solver = Teuchos::null;
            Solver _type = Solver::Undefined;
            Preconditioner _prec = Preconditioner::Undefined;
            SubdomainSolve _subSol = SubdomainSolve::Undefined;
            ConvergenceCriteria _conv = ConvergenceCriteria::Undefined;
            std::vector<string> _listSolv = {"Conjugate Gradients",
                                        "GMRES",
                                        "Conjugate Gradients Squared",
                                        "TFQMR",
                                        "BiCG Stabilized",
                                        "5",
                                        "6",
                                        "7",
                                        "8",
                                        "9",
                                        "10",
                                        "Conjugate Gradients + Condition Number",
                                        "GMRES + Condition Number"};
            std::vector<string> _listPrec = {"no",
                                        "Jacobi",
                                        "SymGaussSeidel",
                                        "Neumann",
                                        "LeastSquares",
                                        "5",
                                        "ILU",
                                        "BILU",
                                        "ICC",
                                        "ILUT",
                                        "10",
                                        "RILU",
                                        "12",
                                        "13",
                                        "DomainDecomp"};

        protected:
            void _checkSettings() override;
            void _setDefaultParameters() override;
    };
}




#endif //ITERATIVE_AZTECOO_H
