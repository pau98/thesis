/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ITERATIVE_BELOS_H
#define ITERATIVE_BELOS_H

#include <mpi.h>
#include <string>

#include <Epetra_LinearProblem.h>
#include <EpetraExt_readEpetraLinearSystem.h>
#include <Epetra_CrsMatrix.h>
#include <Epetra_Map.h>

#include <Ifpack_Preconditioner.h>
#include <Ifpack.h>

#include <BelosConfigDefs.hpp>
#include <BelosLinearProblem.hpp>
#include <BelosEpetraAdapter.hpp>
#include <BelosBlockGmresSolMgr.hpp>

#include "hl_LinearSolver_Iterative.h"

namespace hiperlife
{
    /*!
    * \class BelosIterativeLinearSolver
    * \brief Interface for Belos package and Ifpack package
    *
    * It supports Block and PseudoBlock solvers from Belos package
    * https://trilinos.org/docs/dev/packages/belos/doc/html/files.html.
    * It can be set with the "Solver" option in the solver
    *
    * A simple preconditioner from the Ifpack package can be used:
    * https://trilinos.org/docs/dev/packages/ifpack/doc/html/index.html.
    * It can be set with the "Preconditioner" option in the solver
    *
    * All solvers and preconditiones inside the enum class have been tested.
    *
   */
    class BelosIterativeLinearSolver : public IterativeLinearSolver
    {
        public:

            /** @name Constructor / Destructor / Operator
        *  @{ */
            BelosIterativeLinearSolver(){};

            BelosIterativeLinearSolver(BelosIterativeLinearSolver &&other) = default;
            ~BelosIterativeLinearSolver() = default;
            BelosIterativeLinearSolver& operator=(BelosIterativeLinearSolver&& other) = default;

            BelosIterativeLinearSolver& operator=(const BelosIterativeLinearSolver& other) = delete;
            BelosIterativeLinearSolver(const BelosIterativeLinearSolver& other) = delete;
            /** @} */ // end of constructors

            bool solve() override;
            void Update() override;
            void output(Verbosity verbose = Verbosity::Undefined, std::ostream& out = std::cout) override;
            /*! \brief Defines the type of solver that we are using */
            enum class Solver
            {
                Undefined        = -1,
                /*! Block Generalized Minimal Residual (GMRES) solver for nonsymmetric linear systems */
                BlockGMRES       =  0,
                /*! GMRES solver for nonsymmetric linear systems, that performs single right-hand side solves on multiple right-hand sides at once */
                PseudoBlockGMRES =  1,
                /*! Block Conjugate Gradients (CG) solver for symmetric (Hermitian in complex arithmetic) positive definite linear systems */
                BlockCG          =  2,
                /*! CG solver that performs single right-hand side CG on multiple right-hand sides at once */
                PseudoBlockCG    =  3,
                /*! Variant of GMRES that performs subspace recycling to accelerate convergence for sequences of solves with related linear systems */
                GCRODR           =  4,
                /*! Variant of CG that performs subspace recycling to accelerate convergence for sequences of related linear systems */
                RCG              =  5,
                /*! Transpose-Free Quasi-Minimal Residual (TFQMR) solver for nonsymmetric linear systems */
                TFQMR            =  6
                //PseudoBlockStochasticCG = "PseudoBlockStochasticCG",
                //MINRES                  = "MINRES",
            };
            /*! \brief Defines the type of preconditioner that we are using. Check https://trilinos.github.io/pdfs/IfpackUserGuide.pdf for further details */
            enum class Precond
            {
                Undefined                         = -1,
                /*! Point Relaxation */
                PointRelaxation                   =  0,
                /*! Point Relaxation Stand-alone */
                PointRelaxationStandAlone         =  1,
                /*! Complete LU factorization on each subdomain. Requires IFPACK support for AMESOS */
                Amesos                            =  2,
                /*! Amesos Stand-alone */
                AmesosStandAlone                  =  3,
                /*! Incomplete Cholesky factorization on each subdomain */
                Ic                                =  4,
                /*! Incomplete Cholesky factorization with threshold on each subdomain */
                Ict                               =  5,
                /*! Incomplete LU factorization on each subdomain */
                Ilu                               =  6,
                /*! Incomplete LU with threshold on each subdomain */
                Ilut                              =  7,
                /*! Chebyshev */
                Chebyshev                         =  8,
                /*! Krylov */
                Krylov                            =  9,
                /*! IHSS */
                IHSS                              = 10,
                /*! SORa */
                SORa                              = 11
            };
            enum class Preconditioner
            {
                Undefined                         = -1,
                /*! Point Relaxation */
                PointRelaxation                   =  0,
                /*! Point Relaxation Stand-alone */
                PointRelaxationStandAlone         =  1,
                /*! Complete LU factorization on each subdomain. Requires IFPACK support for AMESOS */
                Amesos                            =  2,
                /*! Amesos Stand-alone */
                AmesosStandAlone                  =  3,
                /*! Incomplete Cholesky factorization on each subdomain */
                Ic                                =  4,
                /*! Incomplete Cholesky factorization with threshold on each subdomain */
                Ict                               =  5,
                /*! Incomplete LU factorization on each subdomain */
                Ilu                               =  6,
                /*! Incomplete LU with threshold on each subdomain */
                Ilut                              =  7,
                /*! Chebyshev */
                Chebyshev                         =  8,
                /*! Krylov */
                Krylov                            =  9,
                /*! IHSS */
                IHSS                              = 10,
                /*! SORa */
                SORa                              = 11
            };
            /*! \brief Defines the side where the preconditioner P is applied */
            enum class PrecondSide
            {
                Undefined = -1,
                /*! \f$ P^{-1}Ax=P^{-1}b \f$ */
                Left      =  0,
                /*! \f$ AP^{-1} Px=b \f$ */
                Right     =  1
            };
            enum class PreconditionerSide
            {
                Undefined = -1,
                /*! \f$ P^{-1}Ax=P^{-1}b \f$ */
                Left      =  0,
                /*! \f$ AP^{-1} Px=b \f$ */
                Right     =  1
            };
            /*! \brief Settles the timer we want to print. */
            enum class TimerName
            {
                Undefined = -1,
                Total     =  0,
                Filling   =  1,
                Solver    =  2
            };
            /** @name Belos Iterative Linear Solver parameters
            *  @{ */
            /*! \brief Sets which solver is used. Default: PseudoBlockGMRES.
            * \param type Solver specified by enum class Solver
            */
            void setSolver(Solver type){_type = type;}
            /*! \brief Sets which preconditioner is used. Default: Ilu.
            * \param prec Preconditioner specified by enum class Preconditioner
            */
            [[deprecated("This function is deprecated and will be removed in the next major release. Please, use setPreconditioner(Preconditioner prec) instead.")]]
            void setPrecond(Precond prec){_prec = static_cast<Preconditioner>(prec);}
            void setPreconditioner(Preconditioner prec){_prec = prec;}
            /*! \brief Sets in which side the preconditioner is applied. Default: Left.
            * \param precSide Preconditioner side specified by enum class PrecondSide
            */
            [[deprecated("This function is deprecated and will be removed in the next major release. Please, use setPreconditioner(Preconditioner prec) instead.")]]
            void setPrecondSide(PrecondSide precSide){_precSide = static_cast<PreconditionerSide>(precSide);}
            void setPreconditionerSide(PreconditionerSide precSide){_precSide = precSide;}
            /*! \brief Specifies maximum number of Krylov set restarts. Default: 20.
            * \param maxRestest Maxim number of restarts
            */
            void setMaxNumRestarts(int maxRest){ _maxRest = maxRest;}
            /*! \brief Returns the time of a process.
            * \param timer Timer specifying the process desired.
            */
            double time(TimerName tim = TimerName::Undefined);
            /** @} */

        private:

            typedef double                ST;
            typedef Epetra_MultiVector    MV;
            typedef Epetra_Operator       OP;

            int _maxRest{-1};

            Solver  _type = Solver::Undefined;
            Preconditioner _prec = Preconditioner::Undefined;
            PreconditionerSide _precSide = PreconditionerSide::Undefined;

            Teuchos::RCP<Ifpack_Preconditioner> _precond = Teuchos::null;
            Teuchos::RCP<Belos::LinearProblem<ST, MV, OP >> _problem = Teuchos::null;
            Teuchos::RCP<Belos::SolverManager<ST, MV, OP >> _solver = Teuchos::null;
            Teuchos::RCP<Belos::EpetraPrecOp> _belosPrec = Teuchos::null;

            std::vector<std::string> _listPrec = {"point relaxation",
                                                  "point relaxation stand-alone",
                                                  "Amesos",
                                                  "Amesos stand-alone",
                                                  "IC",
                                                  "ICT",
                                                  "ILU",
                                                  "ILUT",
                                                  "Chebyshev",
                                                  "Krylov",
                                                  "IHSS",
                                                  "SORa"
                                                  };
            std::vector<std::string> _listSolv = {"Block GMRES",
                                                  "PseudoBlock GMRES",
                                                  "Block Conj. Grad.",
                                                  "PseudoBlock Conj. Grad.",
                                                  "Recycled GMRES",
                                                  "Recycled Conj. Grad.",
                                                  "TFQMR"
                                                  };

        protected:

            void _checkSettings() override;
            void _setDefaultParameters() override;
    };

}




#endif //ITERATIVE_BELOS_H
