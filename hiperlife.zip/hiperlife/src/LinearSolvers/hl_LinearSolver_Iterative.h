/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ITERATIVELINEARSOLVER_H
#define ITERATIVELINEARSOLVER_H

#include <Teuchos_ParameterList.hpp>
#include <Epetra_LinearProblem.h>

#include "hl_LinearSolver.h"

namespace hiperlife
{
    /*!
    * \class IterativeLinearSolver
    * \brief Model virtual class for iterative linear solvers
    *
    */
    class IterativeLinearSolver : public LinearSolver
    {
        public:

            /** @name Constructor / Destructor / Operator
             *  @{ */
            IterativeLinearSolver() = default;

            IterativeLinearSolver(IterativeLinearSolver &&other) = default;
            IterativeLinearSolver& operator=(IterativeLinearSolver&& other) = default;

            IterativeLinearSolver& operator=(const IterativeLinearSolver& other) = delete;
            IterativeLinearSolver(const IterativeLinearSolver& other) = delete;
            /** @} */ // end of constructors
            /** @name Iterative Linear Solver parameters
            *  @{ */
            /*! \brief Sets the maximum number of iterations. Default: 5000.
            * \param maxIter Maximum number
            */
            void setMaxNumIterations(int maxIter){_maxIter = maxIter;};
            /*! \brief Sets the convergence tolerance criteria. Default: 1.E-6.
            * \param tol Tolerance
            */
            void setTolerance(double tol){_tol = tol;};
            /*! \brief Sets the maximum size for the Krylov space. Default: 300.
            * \param krysize Maxmimum size
            */
            void setKrylovSpaceMaxSize(int krysize){ _krysize = krysize;};
            /** @} */
            /*! \brief Return the number of iterations performed by the solver */
            int numIter(){return _numIter;};

        protected:

            int _maxIter{-1};
            double _tol{-1.0};
            int _krysize{-1};
            int _numIter{};

    };
}


#endif //ITERATIVELINEARSOLVER_H
