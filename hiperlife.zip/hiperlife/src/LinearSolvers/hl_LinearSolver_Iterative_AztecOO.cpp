/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <string>

#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>
#include <AztecOO.h>
#include <Epetra_MultiVector.h>

#include "hl_LinearSolver_Iterative_AztecOO.h"

#ifdef EXTRAE_PROFILING
#include "extrae_user_events.h"
#endif


namespace hiperlife
{

    void AztecOOIterativeLinearSolver::Update()
    {
        if (_paramDef == true)
            _setDefaultParameters();

        _getLinearProblem();
        _checkSettings();

        _solver = Teuchos::rcp(new AztecOO(*_linearProblem));
        _solver->SetAztecOption(AZ_max_iter, _maxIter);
        _solver->SetAztecOption(AZ_tol, _tol);
        _solver->SetAztecOption(AZ_kspace, _krysize);
        _solver->SetAztecOption(AZ_solver, static_cast<int>(_type));
        _solver->SetAztecOption(AZ_precond, static_cast<int>(_prec));
        _solver->SetAztecOption(AZ_subdomain_solve, static_cast<int>(_subSol));
        _solver->SetAztecOption(AZ_conv, static_cast<int>(_conv));
        _solver->SetAztecOption(AZ_output, AZ_none);
    }

    void AztecOOIterativeLinearSolver::_setDefaultParameters()
    {
        // Max iterations
        if (_maxIter == -1)
        {
            _maxIter = 5000;
            if (_myRank == 0)
                cout << "AztecOOIterativeLinearSolver::setDefaultParameters: Maximum number of iterations set to default value '5000'." << endl;
        }

        // Krylov subspace size
        if (_krysize == -1)
        {
            _krysize = 300;
            if (_myRank == 0)
                cout << "AztecOOIterativeLinearSolver::setDefaultParameters: Krylov subspace size set to default value '300'." << endl;
        }

        // Solver type
        if (_type == Solver::Undefined)
        {
            _type = Solver::Gmres;
            if (_myRank == 0)
                cout << "AztecOOIterativeLinearSolver::setDefaultParameters: Solver type set to default value 'Gmres'." << endl;
        }

        // Preconditioner
        if (_prec == Preconditioner::Undefined)
        {
            _prec = Preconditioner::None;
            if (_myRank == 0)
                cout << "AztecOOIterativeLinearSolver::setDefaultParameters: Preconditioner set to default value 'None'." << endl;
        }

        // Convergence
        if (_conv == ConvergenceCriteria::Undefined)
        {
            _conv = ConvergenceCriteria::Relative;
            if (_myRank == 0)
                cout << "AztecOOIterativeLinearSolver::setDefaultParameters: ConvergenceCriteria set to default value 'Relative'." << endl;
        }


        // Tolerance
        if (_tol == -1.0)
        {
            _tol = 1.E-6;
            if (_myRank == 0)
                cout << "AztecOOIterativeLinearSolver::setDefaultParameters: Tolerance set to default value '1.E-6'." << endl;
        }

        // Verbosity
        if (_verbose == Verbosity::Undefined)
        {
            _verbose = Verbosity::None;
            if (_myRank == 0)
                cout << "AztecOOIterativeLinearSolver::setDefaultParameters: Verbosity set to default value 'None'." << endl;
        }
    }

    bool AztecOOIterativeLinearSolver::solve()
    {
        _timer = Teuchos::rcp(new Timer({"solver", "filling"}));

        //Fill linear system
        _timer->start("filling");
        if(_hiperProbl!=Teuchos::null)
            _hiperProbl->FillLinearSystem();
        _timer->end("filling");

        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 22);
        #endif
        _timer->start("solver");
        _solver->Iterate(_maxIter, _tol);
        _timer->end("solver");
        #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
        #endif

        _numIter = _solver->NumIters();
        auto* status = _solver->GetAztecStatus();
        _converged = status[AZ_why] == 0;

        if (_verbose != Verbosity::Undefined)
            output(_verbose);

        return _converged;
    }

    void AztecOOIterativeLinearSolver::output(Verbosity verbose, std::ostream& out)
    {
        if (verbose == Verbosity::Undefined)
            throw runtime_error("AztecOOIterativeLinearSolver::output: Verbosity has not been defined");

        int _verInt = static_cast<int>(verbose);
        if (_verInt >= 1)
        {
            using namespace std;

            if (_myRank == 0)
            {
                out << "================================================" << endl;
                out << _listSolv[static_cast<int>(_type)] << " with " << _listPrec[static_cast<int>(_prec)] << " preconditioner" << endl;
                out << "Iterative linear solver from AztecOO" << endl;
                out << "Converged            = " << boolalpha << _converged << endl;
                if (_verInt >= 2)
                {
                    out << "Number of iterations = " << _numIter << endl;
                    out << "Residual             = " << _solver->TrueResidual() << endl;
                }
                if (_verInt >= 3)
                {
                    out << "Timer                = " << _timer->printAccumTime("solver") + _timer->printAccumTime("filling") << endl;
                    if (_hiperProbl != Teuchos::null)
                    {
                        out << "       Filling                = " << _timer->printAccumTime("filling") << endl;
                        out << "       Solver                 = " << _timer->printAccumTime("solver") << endl;
                    }
                }
                out << "================================================" << endl;
            }
        }
    }

    double AztecOOIterativeLinearSolver::time(TimerName tim)
    {
        double _times = -1.0;
        if (tim == TimerName::Undefined)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: Timer Name has not been defined");
        else if (tim == TimerName::Total)
            _times = (_timer->printAccumTime("solver") + _timer->printAccumTime("filling"));
        else if (tim == TimerName::Filling)
            _times = _timer->printAccumTime("filling");
        else if (tim == TimerName::Solver)
            _times = _timer->printAccumTime("solver");
        return _times;
    }

    void AztecOOIterativeLinearSolver::_checkSettings()
    {
        if (_type == Solver::Undefined)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: The solver type has not been defined.");
        if (_prec == Preconditioner::Undefined)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: The preconditioner has not been defined.");
        if (_conv == ConvergenceCriteria::Undefined)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: The convergence criteria for tolerance has not been defined.");
        if (_maxIter == -1)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: Maximum number of iterations has not been defined.");
        if (_tol == -1.0)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: Tolerance has not been defined.");
        if(_krysize == -1)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: Maximum dimension of Krylov set has not been defined.");
        if (_hiperProbl == Teuchos::null)
            throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: The hiperproblem has not been defined.");
        if (_prec == Preconditioner::DomainDecomp)
        {
            if (_subSol == SubdomainSolve::Undefined)
            {
                throw runtime_error("AztecOOIterativeLinearSolver::checkSettings: The preconditioner has been set to DomainDecomp but you have not set a SubdomainSolve option.");
            }
        }
        else
        {
            if (_subSol != SubdomainSolve::Undefined)
            {
                cout << "AztecOOIterativeLinearSolver::checkSettings:: Warning: you have set the subdomain solve option but you are not using the domain decomposition preconditioner. This option will be ignored." << endl;
            }
        }
    }
}
