/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MESHMAP_H
#define MESHMAP_H

#include "hl_DistributedSrcData.h"
#include "hl_TypeDefs.h"


namespace hiperlife
{

    /*!
     * \brief Virtual class for the mapping between meshes.
    */
    class MeshMap : public DistributedSrcData
    {

        public:

            /** @name Constructor / Destructor / Operator
            *  @{ */
            MeshMap(std::string tag ="MeshMap", MPI_Comm comm = MPI_COMM_WORLD) : DistributedSrcData(tag, comm) {_classTag = "MeshMap";}
//        MapBalance(Teuchos::RCP<Epetra_IntVector>& oldToNew, Teuchos::RCP<Epetra_IntVector>& newToOld, std::string tag ="Map", MPI_Comm comm = MPI_COMM_WORLD);
//        MapBalance(Epetra_IntVector& oldToNew, Epetra_IntVector& newToOld, std::string tag ="Map", MPI_Comm comm = MPI_COMM_WORLD);

            MeshMap(MeshMap &&other) = default;
            virtual ~MeshMap() = default;
            MeshMap& operator=(MeshMap&& other) = default;

            MeshMap& operator=(const MeshMap& other) = delete;
            MeshMap(const MeshMap& other) = delete;
            /** @} */ // end of constructors


            /** @name Primary object creation management
             */
            inline void setOutNItems(int outNitems) {_outNItems = outNitems;}
            inline void setMeshInNItems(int meshInNItems) {_meshInNItems = meshInNItems;}
            inline void setMeshOutNItems(int meshOutNItems) {_meshOutNItems = meshOutNItems;}
            /** @} */ // end of primary object creation



            virtual std::vector<int> directMap(int idx, IndexType type = IndexType::Global) = 0;
            virtual std::vector<int> inverseMap(int idx, IndexType type = IndexType::Global) = 0;
            virtual std::vector<int> operator[](int locIdx) const = 0;
            int outNItems() {return _outNItems;}
            int meshInNItems() {return _meshInNItems;}
            int meshOutNItems() {return _meshOutNItems;}

            virtual Teuchos::RCP<MeshMap> generateInverse() = 0;


            /** @name IO Methods
             *  @{
             */
            /*! \brief Output data in hiperlife's own format.*/
            virtual void outFullData(std::ostream& os, OutputMode mode) const = 0;
            void setIStream(std::istream &in, OutputMode mode){_tmp_istream = &in; _tmp_outputmode = mode;};
            /** @} */ // end of IO

            std::vector<std::vector<int>> _kmap;
            std::vector<std::vector<int>> _offsetmap;
            std::vector<std::vector<int>> _idxCuba;

        protected:

            int _outNItems{-1};
            int _meshInNItems{-1};
            int _meshOutNItems{-1};


            //IO
            std::istream* _tmp_istream{nullptr};
            OutputMode _tmp_outputmode;


            friend std::ostream& operator<<(std::ostream &os, const MeshMap& map);

        private:

    };


}


#endif //MESHMAP_H
