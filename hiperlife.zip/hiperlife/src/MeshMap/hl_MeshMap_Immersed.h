/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MESHMAP_IMMERSED_H
#define MESHMAP_IMMERSED_H

#include <vector>
#include <unordered_map>

#include "hl_DistributedData.h"
#include "hl_MeshMap.h"
#include "hl_TypeDefs.h"

namespace hiperlife
{

    class MeshMap_Immersed : public MeshMap
    {
        public:

            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects can be created from
             *  temporal objects through move constructors
            *  @{ */
            MeshMap_Immersed(std::string tag ="MeshMap_Immersed", MPI_Comm comm = MPI_COMM_WORLD) : MeshMap(tag, comm) {};
            MeshMap_Immersed(MeshMap_Immersed &&other) = default;
            MeshMap_Immersed(const MeshMap_Immersed &other) = delete;
            ~MeshMap_Immersed() = default;

            //Operators
            MeshMap_Immersed &operator=(MeshMap_Immersed &&other) = default;
            MeshMap_Immersed &operator=(const MeshMap_Immersed &other) = delete;
            /** @} */ // end of constructors


            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the map from a distributed unordered_multimap.
             * \param dismap unordered_multimap, distributed mapping
             */
            void setDistrMap(std::unordered_multimap<int, int> map) {_map = map;}
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of primary object creation


            /** @name Mesh map data access
             *  @{
            */
            std::vector<int> directMap(int idx, IndexType type = IndexType::Global) override;
            std::vector<int> inverseMap(int idx, IndexType type = IndexType::Global) override;
            std::vector<int> operator[](int locIdx) const override;
            /** @} */ // end of mesh map data access


            Teuchos::RCP <MeshMap> generateInverse() override;


            /** @name IO Methods
             *  @{
             */
            /*! \brief Output data in hiperlife's own format.*/
            void outFullData(std::ostream& os, OutputMode mode) const override;
            /** @} */ // end of IO


            /** @name Expert users/developers only variables
            *  @{ */
            std::unordered_multimap<int, int> _map{};
            std::vector<int> _mostFreq{};
            std::vector<int> _vals{};
            std::vector<int> _keys{};
            DistributedData _disData;
            /** @} */ // end of expert variables

        private:

            //IO
            void _updateIStream();

    };
}

#endif //MESHMAP_IMMERSED_H
