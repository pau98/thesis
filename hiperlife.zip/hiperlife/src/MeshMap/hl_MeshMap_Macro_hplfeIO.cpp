/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_MeshMap.h"
#include "hl_MeshMap_Macro.h"
#include "hl_IO_Aux.h"

using namespace std;


namespace hiperlife
{

    void MeshMap_Macro::outFullData(std::ostream& os, OutputMode mode) const
    {
        //Output number of items
        vector<int> ibuff(2);
        ibuff[0] = _loc_nItem;
        ibuff[1] = _outNItems;
        IO::printData(os, ibuff.data(), ibuff.size(), mode);
    }

    void MeshMap_Macro::_updateIStream()
    {
        //Initialize
        istream& in = *_tmp_istream;

        //Read data
        vector<int> ibuff(2);
        IO::fillData(ibuff.data(), in, ibuff.size(), _tmp_outputmode);

        //Set number of items
        setLocNItem(ibuff[0]);
        setOutNItems(ibuff[1]);
    }

}
