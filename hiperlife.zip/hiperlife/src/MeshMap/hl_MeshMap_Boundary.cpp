/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <unordered_map>

#include "hl_MeshMap_Boundary.h"
#include "hl_MeshMap.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::rcp_dynamic_cast;

namespace hiperlife
{


    void MeshMap_Boundary::Update()
    {
        setLocNItem(_distrMap.size());
        UpdateDistData();

        for (auto i = 0u; i < _distrMap.size(); i++)
            _map.emplace(i, _distrMap[i]);
    }

    vector<int> MeshMap_Boundary::operator[](int locIdx) const
    {
        vector<int> vec = {_map.at(locIdx)};
        return vec;
    }


    RCP<MeshMap> MeshMap_Boundary::generateInverse()
    {
        RCP<MeshMap_Boundary> mapBnd = rcp(new MeshMap_Boundary());
        mapBnd->Update();

        RCP<MeshMap> meshmap = rcp_dynamic_cast<MeshMap>(mapBnd);

        return meshmap;
    }

}
