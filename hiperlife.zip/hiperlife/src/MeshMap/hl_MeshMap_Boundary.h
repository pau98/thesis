/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MESHMAP_BOUNDARY_H
#define MESHMAP_BOUNDARY_H

#include <vector>
#include <unordered_map>

#include "hl_MeshMap.h"
#include "hl_TypeDefs.h"

namespace hiperlife
{

    class MeshMap_Boundary : public MeshMap
    {
        public:
//
            /** @name Constructor / Destructor / Operator
            *  @{ */
            MeshMap_Boundary(std::string tag ="MeshMap_Boundary", MPI_Comm comm = MPI_COMM_WORLD) : MeshMap(tag, comm) {};
//                    MeshMap_Boundary(Teuchos::RCP<Epetra_IntVector>& oldToNew, Teuchos::RCP<Epetra_IntVector>& newToOld, std::string tag ="Map", MPI_Comm comm = MPI_COMM_WORLD);
//                    MeshMap_Boundary(Epetra_IntVector& oldToNew, Epetra_IntVector& newToOld, std::string tag ="Map", MPI_Comm comm = MPI_COMM_WORLD);
            MeshMap_Boundary(MeshMap_Boundary &&other) = default;
            ~MeshMap_Boundary() = default;
            MeshMap_Boundary &operator=(MeshMap_Boundary &&other) = default;
            MeshMap_Boundary &operator=(const MeshMap_Boundary &other) = delete;
            MeshMap_Boundary(const MeshMap_Boundary &other) = delete;
            /** @} */ // end of constructors


            void Update() override;

            void setDistrMap(std::vector<int> dismap) {_distrMap = dismap;}


            std::vector<int> directMap(int idx, IndexType type = IndexType::Global) override
            {
                #ifdef DEBUG
                if (type == IndexType::Global and (idx < 0 or idx > nItem()))
                        throw std::runtime_error("MeshMap_Boundary::directMap: idx " + std::to_string(idx) +" is not valid.");
                    if (type == IndexType::Local and (idx < 0 or idx > loc_nItem()))
                        throw std::runtime_error("MeshMap_Boundary::directMap: idx " + std::to_string(idx) +" is not valid.");
                #endif

                if (type == IndexType::Global)
                    return operator[](locIdx(idx));
                else
                    return operator[](idx);
            }


            std::vector<int> inverseMap(int idx, IndexType type = IndexType::Global) override
            {
                (void)idx;
                (void)type;
                throw std::logic_error("inverseMap not implemented for " + _nameTag);
            }

            std::vector<int> operator[](int locIdx) const override;

            Teuchos::RCP <MeshMap> generateInverse() override;


            /** @name IO Methods
             *  @{
             */
            /*! \brief Output data in hiperlife's own format.*/
            void outFullData(std::ostream& os, OutputMode mode) const override;
            /** @} */ // end of IO

            std::unordered_map<int, int> _map;
            std::vector<int> _distrMap;
        private:


    };
}

#endif //MESHMAP_BOUNDARY_H
