/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MESHMAP_MACRO_H
#define MESHMAP_MACRO_H

#include <string>
#include <vector>
#include <unordered_map>

#include "hl_MeshMap.h"
#include "hl_TypeDefs.h"




namespace hiperlife
{

    /*!
     * \brief Mapping between meshes that share a macro-element relationship.
    */
    class MeshMap_Macro : public MeshMap
    {

        public:

            /** @name Constructor / Destructor / Operator
            *  @{ */
            MeshMap_Macro(std::string tag ="MeshMap_Macro", MPI_Comm comm = MPI_COMM_WORLD) : MeshMap(tag, comm) {};
            MeshMap_Macro(MeshMap_Macro &&other) = default;
            ~MeshMap_Macro() = default;
            MeshMap_Macro &operator=(MeshMap_Macro &&other) = default;
            MeshMap_Macro &operator=(const MeshMap_Macro &other) = delete;
            MeshMap_Macro(const MeshMap_Macro &other) = delete;
            /** @} */ // end of constructors


            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of primary object creation


            /** @name Mesh map data access
             *  @{
            */
            std::vector<int> directMap(int idx, IndexType type = IndexType::Global) override;
            std::vector<int> inverseMap(int idx, IndexType type = IndexType::Global) override;
            std::vector<int> operator[](int locIdx) const override;
            std::vector<int> fineToCoarse(int locIdx, int fineOff) const;
            std::vector<int> coarseToFine(int locIdx, int coarOff) const;
            inline int N() {return _N;}
            inline bool coarToFn() {return _coarToFn;}
            /** @} */ // end of mesh map data access


            Teuchos::RCP <MeshMap> generateInverse() override;

            /** @name IO Methods
             *  @{
             */
            /*! \brief Output data in hiperlife's own format.*/
            void outFullData(std::ostream& os, OutputMode mode) const override;
            /** @} */ // end of IO

        private:
            int _N{-1};
            bool _coarToFn = true;

            //IO
            void _updateIStream();
    };

}


#endif //HIPERLIFE_HPLFE_MESHMAP_MACRO_H
