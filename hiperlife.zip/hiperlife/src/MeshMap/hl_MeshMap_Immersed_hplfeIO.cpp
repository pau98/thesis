/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_MeshMap.h"
#include "hl_MeshMap_Immersed.h"
#include "hl_IO_Aux.h"

using namespace std;


namespace hiperlife
{

    void MeshMap_Immersed::outFullData(std::ostream& os, OutputMode mode) const
    {
        //Output number of items
        // _map is an unordered_multimap, so its flattened size (_keys.size(),
        // the actual number of (key,val) pairs written below) can be larger
        // than _loc_nItem (_meshInNItems: the number of *distinct* input
        // items) whenever an input item maps to more than one output item --
        // which is the common case for an ImmersedBoundary relation, where
        // one immersed element typically overlaps several background
        // elements. That pair count has to be persisted explicitly so
        // _updateIStream() can size the keys/vals buffers correctly; reusing
        // _loc_nItem for that (as before) under-reads whenever there are
        // duplicate keys, desynchronizing every read that follows in the
        // same stream.
        vector<int> ibuff(3);
        ibuff[0] = _loc_nItem;
        ibuff[1] = _meshOutNItems;
        ibuff[2] = static_cast<int>(_keys.size());
        IO::printData(os, ibuff.data(), ibuff.size(), mode);

        //Output map
        IO::printData(os, _keys.data(), _keys.size(), mode);
        IO::printData(os, _vals.data(), _vals.size(), mode);
    }

    void MeshMap_Immersed::_updateIStream()
    {
        //Initialize
        istream& in = *_tmp_istream;

        //Read number of items
        vector<int> ibuff(3);
        IO::fillData(ibuff.data(), in, ibuff.size(), _tmp_outputmode);

        //Set number of items
        setMeshInNItems(ibuff[0]);
        setMeshOutNItems(ibuff[1]);
        int nPairs = ibuff[2];

        //Read keys and values
        vector<int> keys(nPairs), vals(nPairs);
        IO::fillData(keys.data(), in, nPairs, _tmp_outputmode);
        IO::fillData(vals.data(), in, nPairs, _tmp_outputmode);

        //Create map
        _map.reserve(nPairs);
        for (int i = 0; i < nPairs; i++)
            _map.emplace(keys[i], vals[i]);
    }

}
