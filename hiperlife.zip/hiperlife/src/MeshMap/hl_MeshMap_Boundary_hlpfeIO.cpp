/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_MeshMap_Boundary.h"
#include "hl_MeshMap.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{

    void MeshMap_Boundary::outFullData(std::ostream& os, OutputMode mode) const
    {
        (void) os;
        (void) mode;
    }

}
