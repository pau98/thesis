/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <unordered_map>

#include "hl_MeshMap.h"
#include "hl_MeshMap_Macro.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::rcp_dynamic_cast;

namespace hiperlife
{
    void MeshMap_Macro::Update()
    {
        //Update from file
        if (_tmp_istream != nullptr && _tmp_outputmode != OutputMode::Undefined)
            _updateIStream();

        //Update distributed data
        UpdateDistData();

        // If OutNItem is not set, we keep the default behavior: coarse -> fine  and N = 4
        if (_outNItems > 0)
        {
            int inNItems = _loc_nItem;
            if (_outNItems > inNItems)
            {
                if(_outNItems % inNItems != 0)
                    throw std::runtime_error("MeshMap_Macro::Update: The two meshes are not compatible. inItems: "
                                             + std::to_string(_outNItems) + " outItems: " + std::to_string(inNItems));

                _coarToFn = true;
                _N = _outNItems / inNItems;
            }
            else if (inNItems > _outNItems)
            {
                if (inNItems % _outNItems != 0)
                    throw std::runtime_error("MeshMap_Macro::Update: The two meshes are not compatible. inItems: "
                                             + std::to_string(_outNItems) + " outItems: " + std::to_string(inNItems));

                _coarToFn = false;
                _N = inNItems / _outNItems;
            }
            else if (inNItems == _outNItems)
            {
                _coarToFn = false;
                _N = 1;
            }
            else
            {
                throw std::runtime_error("MeshMap_Macro::Update: The two meshes have the same number of items. This is not possible.");
            }
        }
        else
        {
            std::clog << "MeshMap_Macro::Update: Be careful, the map is created with the default options:  "
                "coarse -> fine and N = 4" << std::endl;

            _coarToFn = true;
            _N = 4;
        }

    }

    std::vector<int> MeshMap_Macro::directMap(int idx, IndexType type)
    {
#ifdef DEBUG
        if (type == IndexType::Global and (idx < 0 or idx > nItem()))
            throw std::runtime_error("MeshMap_Macro::directMap: idx " + std::to_string(idx) +" is not valid.");
        if (type == IndexType::Local and (idx < 0 or idx > loc_nItem()))
            throw std::runtime_error("MeshMap_Macro::directMap: idx " + std::to_string(idx) +" is not valid.");
#endif

        if (type == IndexType::Global)
            return operator[](locIdx(idx));
        else
            return operator[](idx);
    }

    std::vector<int> MeshMap_Macro::inverseMap(int idx, IndexType type)
    {
#ifdef DEBUG
        // Check Enter values, this needs to be delimited by the output items of the map
        int outNItem;
        int outLocNItem;
        int outOff;
        int outOffP1;

        if (_coarToFn)
        {
            outNItem = nItem() * _N;
            outLocNItem = loc_nItem() * _N;
            outOff = offs_nItem() * _N;
            outOffP1 = (offs_nItem() + proc_nItem()) *_N;

        }
        else
        {
            outNItem = nItem() / _N;
            outLocNItem = loc_nItem() / _N;
            outOff = offs_nItem() / _N;
            outOffP1 = (offs_nItem() + proc_nItem()) / _N;
        }


        if (type == IndexType::Global and (idx < 0 or idx > outNItem))
            throw std::runtime_error("MeshMap_Macro::inverseMap: idx " + std::to_string(idx) +" is not valid.");
        if (type == IndexType::Local and (idx < 0 or idx > outLocNItem))
            throw std::runtime_error("MeshMap_Macro::inverseMap: idx " + std::to_string(idx) +" is not valid.");


        int lIdx = (type == IndexType::Global)? locIdx(idx) : idx;
        std::vector<int> ret;



        if (_coarToFn)
            ret = fineToCoarse(lIdx, outOff);
        else
            ret = coarseToFine(lIdx, outOff);


        // Check Return values, this needs to be delimited by the input items of the map
        int retOff = offs_nItem();
        int retOffP1 = offs_nItem() + proc_nItem();

        auto it = std::find_if (ret.begin(), ret.end(), [retOff, retOffP1](const int& i){
                                                            return i < (retOff) or i >= retOffP1; });

        if (it != ret.end())
        {
            std::stringstream ss;

            ss << "MeshMap_Macro::inverseMap: Something has happened and the return values are not valid." << std::endl;
            ss << "Internal Info ->  inLocItems: " <<  _loc_nItem << "  " << std::endl;
            ss << "Internal Info ->  inElemsIdx:      [" <<  offs_nItem() <<","<< offs_nItem()+proc_nItem() << "]  " << std::endl;
            ss << "Internal Info ->  outNItems:  " <<  _outNItems << "  " << std::endl;
            ss << "Internal Info ->  outElemsIdx:      [" <<  outOff <<","<< outOffP1 << "]  " << std::endl;
            ss << "Internal Info ->  N: " <<  _N << "  " << std::endl;
            ss << "Internal Info ->  coarToFn:   " <<  _coarToFn  << "  " << std::endl;
            ss << "Input id   ->  in: " <<  idx << "   locId:   " <<  lIdx   << std::endl;
            ss << "Return ids ->";
            for (auto& r : ret)
                ss << "  " << r;
            ss << std::endl;

            throw std::runtime_error(ss.str());

        }


        return ret;
#else
        int lIdx = (type == IndexType::Global)? locIdx(idx) : idx;
        int outOff?(offs_nItem() * _N):(offs_nItem() / _N);

        if (_coarToFn)
            return fineToCoarse(lIdx, outOff);
        else
            return coarseToFine(lIdx, outOff);
#endif

    }

    std::vector<int> MeshMap_Macro::operator[](int locIdx) const
    {
        if (_coarToFn)
        {
            return coarseToFine(locIdx, offs_nItem());
        }
        else
        {
            return fineToCoarse(locIdx, offs_nItem());
        }
    }

    Teuchos::RCP <MeshMap> MeshMap_Macro::generateInverse()
    {
        auto invMap = Teuchos::rcp(new MeshMap_Macro());

        invMap->setLocNItem(_outNItems);
        invMap->setOutNItems(_loc_nItem);
        invMap->Update();

        return invMap;
    }


    std::vector<int> MeshMap_Macro::fineToCoarse(int locIdx, int fineOff) const
    {
        return {(locIdx+fineOff) / _N};
    }

    std::vector<int> MeshMap_Macro::coarseToFine(int locIdx, int coarOff) const
    {
        std::vector<int> fineItems;
        for (int i = 0; i < _N; i++)
            fineItems.push_back(locIdx*_N + i + coarOff*_N);

        return fineItems;
    }
}
