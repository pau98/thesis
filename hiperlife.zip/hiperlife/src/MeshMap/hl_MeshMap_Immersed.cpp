/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <unordered_map>

#include "hl_MeshMap.h"
#include "hl_MeshMap_Immersed.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::rcp_dynamic_cast;

namespace hiperlife
{

    void MeshMap_Immersed::Update()
    {
        //Update from file
        if (_tmp_istream != nullptr && _tmp_outputmode != OutputMode::Undefined)
            _updateIStream();

        //Checks
        if (_map.empty())
            throw runtime_error("hl_MeshMap_Immersed::Update: The map is empty.");
        if (_meshInNItems == -1)
            throw runtime_error("hl_MeshMap_Immersed::Update: meshInNItems not set.");
        if (_meshOutNItems == -1)
            throw runtime_error("hl_MeshMap_Immersed::Update: meshOutNItems not set.");

        //Set distributed data
        setLocNItem(_meshInNItems);
        UpdateDistData();

        //Set auxiliary vectors
        int prev = -1;
        for (auto it = _map.begin(); it != _map.end(); ++it)
        {
            _keys.push_back(it->first);
            _vals.push_back(it->second);
            if (it->first != prev)
                _mostFreq.push_back(it->second);
            prev = it->first;
        }

        //Create distributed data for the map
        _disData.setLocNItem(_keys.size());
        _disData.Update();
    }


    std::vector<int> MeshMap_Immersed::directMap(int idx, IndexType type)
    {
        // #ifdef DEBUG
        // if (type == IndexType::Global and (idx < 0 or idx > nItem()))
        //         throw std::runtime_error("MeshMap_Immersed::directMap: idx " + std::to_string(idx) +" is not valid.");
        //     if (type == IndexType::Local and (idx < 0 or idx > loc_nItem()))
        //         throw std::runtime_error("MeshMap_Immersed::directMap: idx " + std::to_string(idx) +" is not valid.");
        // #endif

        if (type == IndexType::Global)
            return operator[](locIdx(idx));
        else
            return operator[](idx);
    }

    std::vector<int> MeshMap_Immersed::inverseMap(int idx, IndexType type)
    {
        (void)idx;
        (void)type;
        throw std::logic_error("inverseMap not implemented for " + _nameTag);
    }

    vector<int> MeshMap_Immersed::operator[](int locIdx) const
    {
        vector<int> vec;
        auto its = _map.equal_range(locIdx);
        for (auto it = its.first; it != its.second; ++it)
            vec.push_back(it->second);

        return vec;
    }


    RCP<MeshMap> MeshMap_Immersed::generateInverse()
    {
        //Create distributed data of the in and out meshes
        DistributedData mInDisData;
        mInDisData.setLocNItem(_meshInNItems);
        mInDisData.Update();
        DistributedData mOutDisData;
        mOutDisData.setLocNItem(_meshOutNItems);
        mOutDisData.Update();

        //Redistribute mapping
        unordered_multimap<int, int> iMap;
        vector<int> p_oldKeys, p_oldVals;
        for (int p = 0; p < numProcs(); p++)
        {
            //BCast number of keys
            int p_nKeys = _keys.size();
            MPI_Bcast(&p_nKeys, 1, MPI_INT, p, comm());

            //Broadcast keys and values
            p_oldKeys.resize(p_nKeys);
            p_oldVals.resize(p_nKeys);
            if (myRank() == p)
            {
                p_oldKeys = _keys;
                p_oldVals = _vals;
            }
            MPI_Bcast(&p_oldKeys[0], p_nKeys, MPI_INT, p, comm());
            MPI_Bcast(&p_oldVals[0], p_nKeys, MPI_INT, p, comm());


            //Get the keys and values that are mine
            for (int n = 0; n < p_nKeys; n++)
            {
                int oldVal = p_oldVals[n];

                // Distribute according to the vals
                if (mOutDisData.isItemInPart(oldVal))
                {
                    int first = mOutDisData.locIdx(oldVal);
                    int second = p_oldKeys[n] + mInDisData.offs_nItem(p);

                    // Add only if this pair (first, second) is not on the map already //FIXME: Not optimized
                    if (iMap.count(first) != 0)
                    {
                        auto its = iMap.equal_range(first);
                        vector<int> vec;
                        for (auto it = its.first; it != its.second; ++it)
                            vec.push_back(it->second);
                        auto it = std::find(vec.begin(), vec.end(), second);
                        if (it == vec.end())
                            iMap.emplace(first, second);
                    }
                    else
                    {
                        iMap.emplace(first, second);
                    }
                }
            }

            //Wait for all procs
            Barrier();
        }

        //Create inverse mapping
        RCP<MeshMap_Immersed> mapImm = rcp(new MeshMap_Immersed());
        mapImm->setMeshInNItems(_meshOutNItems);
        mapImm->setMeshOutNItems(_meshInNItems);
        mapImm->setDistrMap(iMap);
        mapImm->Update();

        //Cast to MeshMap
        RCP<MeshMap> meshmap = rcp_dynamic_cast<MeshMap>(mapImm);

        return meshmap;
    }

}
