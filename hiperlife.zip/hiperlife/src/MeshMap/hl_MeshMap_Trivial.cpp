/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_MeshMap.h"
#include "hl_MeshMap_Trivial.h"


namespace hiperlife
{

    void MeshMap_Trivial::Update()
    {
        //Update from file
        if (_tmp_istream != nullptr && _tmp_outputmode != OutputMode::Undefined)
            _updateIStream();

        //Update distributed data
        UpdateDistData();
    }


    std::vector<int> MeshMap_Trivial::directMap(int idx, IndexType type)
    {
#ifdef DEBUG
        if (type == IndexType::Global and (idx < 0 or idx > nItem()))
            throw std::runtime_error("MeshMap_Trivial::directMap: idx " + std::to_string(idx) +" is not valid.");
        if (type == IndexType::Local and (idx < 0 or idx > loc_nItem()))
            throw std::runtime_error("MeshMap_Trivial::directMap: idx " + std::to_string(idx) +" is not valid.");
#endif

        if (type == IndexType::Global)
            return operator[](locIdx(idx));
        else
            return operator[](idx);

    }

    std::vector<int> MeshMap_Trivial::inverseMap(int idx, IndexType type)
    {
#ifdef DEBUG
        if (type == IndexType::Global and (idx < 0 or idx > nItem()))
            throw std::runtime_error("MeshMap_Trivial::directMap: idx " + std::to_string(idx) +" is not valid.");
        if (type == IndexType::Local and (idx < 0 or idx > loc_nItem()))
            throw std::runtime_error("MeshMap_Trivial::directMap: idx " + std::to_string(idx) +" is not valid.");
#endif

        if (type == IndexType::Global)
            return operator[](locIdx(idx));
        else
            return operator[](idx);

    }

    std::vector<int> MeshMap_Trivial::operator[](int locIdx) const
    {
        return {locIdx + offs_nItem()};
    }

    Teuchos::RCP<MeshMap> MeshMap_Trivial::generateInverse()
    {
        Teuchos::RCP <MeshMap> inverseMap = Teuchos::rcp(new MeshMap_Trivial(_nameTag, _comm));

        inverseMap->setLocNItem(_loc_nItem);
        inverseMap->Update();

        return inverseMap;

    }

    Teuchos::RCP<MeshMap> createMeshMap_Trivial(int loc_nElems)
    {
        Teuchos::RCP <MeshMap> mapTriv = Teuchos::rcp(new MeshMap_Trivial());
        mapTriv->setLocNItem(loc_nElems);
        mapTriv->Update();

        return mapTriv;
    }
}
