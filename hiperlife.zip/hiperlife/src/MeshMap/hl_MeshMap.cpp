/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <ostream>

#include "hl_MeshMap.h"

using namespace std;


namespace hiperlife
{

    ostream &operator<<(ostream &os, const MeshMap &map)
    {
        MPI_Comm comm = MPI_COMM_WORLD;
        int myRank, numProcs;
        MPI_Comm_rank(comm, &myRank);
        MPI_Comm_size(comm, &numProcs);


        MPI_Barrier(comm);
        if (myRank == 0)
            os << "----- Mesh Map Object Type: "  << map.nameTag()  << "-----" << endl << endl;

        if (myRank == 0)
            os << "Direct Map " << endl;

        for (int p = 0; p < numProcs; p++)
        {
            if (p == myRank)
            {
                os << "  Rank " << p << endl;
                for (int i = 0; i < map.loc_nItem(); i++)
                {
                    auto out = map[i];
                    os << "   " << to_string(i + map.offs_nItem()) << " -> ";
                    for (auto& o : out)
                        cout << to_string(o) << " ";
                    cout << endl;
                }
            }

            MPI_Barrier(comm);
        }


        return os;
    }

}
