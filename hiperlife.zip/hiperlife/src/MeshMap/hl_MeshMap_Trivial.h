/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MESHMAP_TRIVIAL_H
#define MESHMAP_TRIVIAL_H

#include "hl_MeshMap.h"



namespace hiperlife
{


    /*!
     * \brief Mapping between meshes that share the same distribution of elements.
    */
    class MeshMap_Trivial : public MeshMap
    {
        public:

            /** @name Constructor / Destructor / Operator
            *  @{ */
            MeshMap_Trivial(std::string tag = "MeshMap_Trivial", MPI_Comm comm = MPI_COMM_WORLD) : MeshMap(tag, comm){}
            MeshMap_Trivial(MeshMap_Trivial &&other) = default;
            ~MeshMap_Trivial() = default;

            MeshMap_Trivial &operator=(MeshMap_Trivial &&other) = default;
            MeshMap_Trivial &operator=(const MeshMap_Trivial &other) = delete;
            MeshMap_Trivial(const MeshMap_Trivial &other) = delete;
            /** @} */ // end of constructors

            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of primary object creation

            /** @name Mesh map data access
             *  @{
            */
            std::vector<int> directMap(int idx, IndexType type = IndexType::Global) override;
            std::vector<int> inverseMap(int idx, IndexType type = IndexType::Global) override;
            std::vector<int> operator[](int locIdx) const override;
            /** @} */ // end of mesh map data access

            Teuchos::RCP <MeshMap> generateInverse() override;


            /** @name IO Methods
             *  @{
             */
            /*! \brief Output data in hiperlife's own format.*/
            void outFullData(std::ostream& os, OutputMode mode) const override;
            /** @} */ // end of IO

        private:

            //IO
            void _updateIStream();
    };


    Teuchos::RCP<MeshMap> createMeshMap_Trivial(int loc_nElems);

}

#endif
