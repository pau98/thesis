/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ST_TIMER_H
#define ST_TIMER_H

#include <iostream>
#include <string>
#include <map>
#include <vector>

#include <mpi.h>

#include "hl_DistributedClass.h"

namespace hiperlife
{


    /*!
     * \class Timer
     * \brief Class that provides a simple way of timing parts of the code.
     *
     * It needs to be created with a list of strings, each of them will label each timing region:
     *      Timer timer({"timA", "timB", "timC", ...});
     *
     * Then, we can call the methods start(label) and end(label) to demarcate the region of measurement.
     * If a region is called several times, the object will stores the total number of iterations, the
     * average time and the longest iteration.
     *
     * Aditionally, we can also set up some integer / double fields with relevant information
     * of our simulations that are not time measurements.
     *
     * The methods printTiming() and printTesting() can be used for recovering the timing information.
     *
    */
    class Timer : public hiperlife::DistributedClass
    {

        public:
            /*!
             * Creates a timer with a set of measures already in.
             */
            Timer(std::vector<std::string> measureList, MPI_Comm comm = MPI_COMM_WORLD);

            /*!
             * Creates a empty timer
             */
            Timer(MPI_Comm comm = MPI_COMM_WORLD);

            /*!
             * Start measuring a timing region.
             * \param id region identifier
             */
            void start(std::string id);

            /*!
             * End measuring a timing region.
             * \param id region identifier
             */
            double end(std::string id);

            /*!
             * Set some integer fields.
             * \param idIntList vector with all the fields identifiers
             */
            void setIntFields(std::vector<std::string> idIntList);

            /*!
             * Set some double fields.
             * \param idDoubList vector with all the fields identifiers
             */
            void setDoubleFields(std::vector<std::string> idDoubList);

            /*!
             * Add a new value to a integer field.
             * \param id region identifier
             * \param value value to add
             */
            void addFieldData(std::string id, int value);


            /*!
             * Add a new value to a double field.
             * \param id region identifier
             * \param value value to add
             */
            void addFieldData(std::string id, double value);

            /*!
             * Method that prints the full output for all the set regions.
             * \param printAllRanks It true, each rank prints its own measurement
             */
            void printTiming(bool printAllRanks = false, std::ostream &out = std::cout);

            /*!
             * Method that prints a compact output in one line, thought as testing output for grouping
             * different runs.
             * \param prefix First part of the line that will be printed, for example info about the run.
             */
            void printTesting(std::string prefix, std::ostream &out = std::cout);

             /*!
             * Method that prints the accumulated time for a given id
             * \param id measure to be printed
             */
            double printAccumTime(std::string id);

        private:

            // Private class that stores all the individual timers.
            class Measure
            {
                public:
                    double accumTime{0.};
                    double maxTime{0.};
                    double tmp_start{-1.};
                    int iters{0};
                    std::string name;

                    Measure() = delete;
                    Measure(std::string s) : name(s) {}

                    void start()
                    {
                        tmp_start = MPI_Wtime();
                    }

                    double end()
                    {
                        double tmp = MPI_Wtime();

                        if(tmp_start < 0.)
                            return 0;

                        tmp = tmp - tmp_start;
                        accumTime += tmp;
                        tmp_start = -1.0;
                        iters++;
                        if(tmp > maxTime)
                            maxTime = tmp;

                        return tmp;
                    }

                    double average()
                    {
                        return (iters!=0)?(accumTime / iters) : (0.00);
                    }
            };

            template<typename T> class Field
            {
                public:
                    int iters{0};
                    std::string name;
                    T accumValue;
                    T maxValue;

                    Field() = delete;
                    Field(std::string s) : name(s), accumValue(0), maxValue(0) {}

                    T add(T newVal)
                    {
                        accumValue += newVal;

                        iters++;
                        if(newVal > maxValue)
                            maxValue = newVal;

                        return newVal;
                    }

                    T average()
                    {
                        return (iters!=0)?(maxValue / iters) : (0.00);
                    }
            };


            std::map<std::string, int> map;
            std::vector<Measure> measures;

            std::map<std::string, int> intMap;
            std::vector<Field<int>> intFields;

            std::map<std::string, int> douMap;
            std::vector<Field<double>> douFields;
    };




}




#endif // ST_TIMER_H
