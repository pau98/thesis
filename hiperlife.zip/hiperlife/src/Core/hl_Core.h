#ifndef HL_CORE
#define HL_CORE

#include <mpi.h>

#include "Teuchos_RCP.hpp"

namespace hiperlife {

    void Init(int argc, char** argv);

    void Finalize();

    [[maybe_unused]] void GlobalBarrier();

    [[maybe_unused]] int MyRank();

    [[maybe_unused]] int NumProcs();

    [[maybe_unused]] bool VerboseRank();

#ifdef HL_VTK
    constexpr bool CompiledWithVtk()
    {
        return true;
    }
#else
    constexpr bool CompiledWithVtk()
    {
        return false;
    }
#endif

#ifdef HL_MUMPS
    constexpr bool CompiledWithMumps()
    {
        return true;
    }
#else
    constexpr bool CompiledWithMumps()
    {
        return false;
    }
#endif

#ifdef HL_SCOTCH
    constexpr bool CompiledWithScotch()
    {
        return true;
    }
#else
    constexpr bool CompiledWithScotch()
    {
        return false;
    }
#endif

#ifdef HL_GMSH
    constexpr bool CompiledWithGmsh()
    {
        return true;
    }
#else
    constexpr bool CompiledWithGmsh()
    {
        return false;
    }
#endif

    template<typename T> using SmartPtr = Teuchos::RCP<T>;

    using Teuchos::null;

    template<typename T, typename... Args> SmartPtr<T> Create(Args... args)
    {
        return Teuchos::rcp(new T(args...));
    }
} // hiperlife


#include "hl_Core-impl.h"

#endif //HL_CORE
