/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <vector>
#include <string>

#include <Teuchos_RCP.hpp>
#include <Epetra_BlockMap.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_DistributedSrcData.h"
#include "hl_IO_Aux.h"

using namespace std;


namespace hiperlife
{

    /*! \brief Print the critical information in text mode */
    void DistributedSrcData::outDisData_text(std::ostream& os) const
    {
        os << _numProcs << " ";
        os << _nItem << " ";
        os << _loc_nItem << " ";
        os << _ghosts.size() << endl;

        IO::printData_text(os, _proc_nItem->Values(), _numProcs);
        IO::printData_text(os, _offs_nItem->Values(), _numProcs);
        if(_ghosts.size() != 0)
            IO::printData_text(os, _ghosts.data(), _ghosts.size());
    }

    /*! \brief Print the critical information in binary mode */
    void DistributedSrcData::outDisData_binary(std::ostream& os) const
    {
        int ghostSize = _ghosts.size();

        os.write(reinterpret_cast<const char*>(&_numProcs), sizeof(_numProcs));
        os.write(reinterpret_cast<const char*>(&_nItem), sizeof(_nItem));
        os.write(reinterpret_cast<const char*>(&_loc_nItem), sizeof(_loc_nItem));
        os.write(reinterpret_cast<const char*>(&ghostSize), sizeof(ghostSize));

        IO::printData_binary(os, _proc_nItem->Values(), _numProcs);
        IO::printData_binary(os, _offs_nItem->Values(), _numProcs);
        if(_ghosts.size() != 0)
            IO::printData_binary(os, _ghosts.data(), _ghosts.size());
    }

    void DistributedSrcData::outDisData(std::ostream& os, OutputMode mode) const
    {
        if(mode == OutputMode::Binary)
            outDisData_binary(os);
        else if (mode == OutputMode::Text)
            outDisData_text(os);
        else
            throw runtime_error("DistributedSrcData::outDisData: Not a valid OutputMode.");
    }


    /*!
     * The input stream is suppose to be opened in the corresponding OutputMode.
     * The method generates a DistributedSrcData object will the information of loc_nItem
     * and nItem and will check the rest of the information contained in the file.
     * If something is not consistent, it will raise an error.
     * \param in Input stream located at the beggining of the data.
     * \param mode input mode, Binary or Text
     */
    void DistributedSrcData::UpdateDistData(istream& in, OutputMode mode)
    {

        int size = (_numProcs>4)?_numProcs:4;
        vector<int> buff(size, 0);


        IO::fillData(buff.data(), in, 4, mode);

        int readNumProcs;
        readNumProcs = buff[0];

        if(_numProcs == readNumProcs)
            _updateDistData_sameNumProcs(in, buff, mode);
        else
            throw runtime_error("DistributedSrcData::UpdateDistData: Not yet implemented, sorry. NumProcs: " + to_string(readNumProcs));

    }

    void DistributedSrcData::_updateDistData_sameNumProcs(istream& in, vector<int> buff, OutputMode mode)
    {
        int ghostSize;
        std::istringstream iss;

        // Setting key variables and creating the Object
        _nItem = buff[1];
        _loc_nItem = buff[2];
        ghostSize  = buff[3];

        UpdateDistData();


        // Checking file's info respect to the distribution computed
        IO::fillData(buff.data(), in, _numProcs, mode);
        checkBuffer(buff.data(), _proc_nItem->Values(), _numProcs);
        IO::fillData(buff.data(), in, _numProcs, mode);
        checkBuffer(buff.data(), _offs_nItem->Values(), _numProcs);

        vector<int> readGhosts(ghostSize);
        IO::fillData(readGhosts.data(), in, ghostSize, mode);
        UpdateGhosts(readGhosts);

    }

    ostream& operator<<(ostream& os, const DistributedSrcData& dd)
    {
        if (dd._myRank == 0)
            os << dd._nameTag << " " << dd._classTag << endl;

        for (int p = 0; p < dd._numProcs; p++)
        {
            if (p == dd._myRank)
            {
                os << "Rank:  " << dd._myRank  << endl;
                dd.outDisData_text(os);
            }

            dd.Barrier();
        }
        return os;
    }


}
