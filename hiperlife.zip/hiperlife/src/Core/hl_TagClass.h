/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef TAGCLASS_H
#define TAGCLASS_H

#include <vector>
#include <string.h>
#include <string>
#include <algorithm>

#include "hl_DistributedClass.h"


namespace hiperlife
{
    /*!
     * \class TagClass
     * \brief Support for mapping tags to indices
     *
     * Allow to have support for tags that maps strings to integer indices.
     * It can be inherit to add support in any class or instantiated in a separated object.
     *
    */
    class TagClass
    {
        protected:
            /*! \brief Vector of tags that maps the strings to the corresponding indices. */
            std::vector<std::string> _tags;
            std::string _nameTag_debug;

        public:
            /*! \brief Creates the tags associated to some indices. It will check that the tags are
             * the same among all the processors associated to disData
             *
             * \param disData DistributedSrcData class that establishes the processors that will be compared
             * \param tags vector with all the tags
             * \return the total number of tags
             * */
            int createTags(DistributedClass& disData, std::vector<std::string>& tags)
            {
                // Add tags
                for (auto &t : tags)
                {
                    if(isTag(t))
                        throw std::runtime_error("TagClass::createTags: There is a repeated tag (" + t + ") in " + disData.nameTag() +  ".");

                    _tags.push_back(t);
                }

                // Check that all tags match
                const bool ERR = checkTagsAllRanks(disData);
                if (ERR == false)
                    throw std::runtime_error("TagClass::createTags: The tags are not consistent through all the ranks in " + disData.nameTag() +  ".");

                // Save class name (useful for errors)
                _nameTag_debug = disData.nameTag();

                // Return number of tags
                return static_cast<int>(_tags.size());
            }


            /*! \brief Check that the tags are the same among all the processors that corresponds to the
             * MPI communicator of the DistributedClass introduced.
             *
             * \param disData DistributedSrcData class that establishes the processors that will be compared
             * \return true if they are all equal
             * */
            bool checkTagsAllRanks(DistributedClass& disData)
            {
                const int ROOT = 0;
                int tagSize = static_cast<int>(_tags.size());
                int recBuff;
                MPI_Allreduce(&tagSize, &recBuff, 1, MPI_INT, MPI_MAX, disData.comm());

                if (recBuff != static_cast<int>(_tags.size()))
                    return false;

                std::vector<char> bufVec(100);
                auto* buffer = bufVec.data();
                for (int i = 0; i < tagSize; i++)
                {
                    memset(buffer, 0, strlen(buffer));
                    if (disData.myRank() == ROOT)
                        strcpy(buffer, _tags[i].c_str());

                    MPI_Bcast(buffer, 100, MPI_CHAR, ROOT, disData.comm());

                    const int CMP = strcmp(buffer, _tags[i].c_str());

                    if (CMP != 0)
                        return false;
                }

                return true;
            }

            /*! \brief Returns the index of a given tag. In Debug it checks that the key exists,
             * in Release the behavior cannot be guaranteed if a non-existing key is introduced
             *
             * \param key string to be searched
             * \return index that correspond to that key
             * */
            inline int index(std::string key) const
            {
                #ifdef DEBUG
                    auto findkey = std::find(_tags.begin(), _tags.end(), key);

                    if (findkey == _tags.end())
                        throw std::runtime_error("TagClass::index: key \"" + key + "\" not found in " + _nameTag_debug + ".");
                    return std::distance(_tags.begin(), findkey);
                #else
                    return (std::distance(_tags.begin(), std::find(_tags.begin(), _tags.end(), key)));
                #endif
            }

            /*! \brief Returns the index of a given tag. In Debug it checks that the key exists,
             * in Release the behavior cannot be guaranteed if a non-existing key is introduced
             *
             * \param index string to be searched
             * \return tag that correspond with the given index
             * */
            inline std::string tag(int i) const
            {
                #ifdef DEBUG
                if (i < 0 or i >= int(_tags.size()))
                    throw std::runtime_error("TagClass::tag: index " + std::to_string(i) + " not found in " + _nameTag_debug + ".");
                #endif

                return _tags[i];
            }

            /*! \brief Returns the a vector of the tags
             *
             * \return _tags vector
             * */
            inline std::vector<std::string> tags() const
            {
                return _tags;
            }

            /*! \brief It checks that a given key exists in the tags set
             *
             * \param key string to be searched
             * \return true if exists, false otherwise
             * */
            inline bool isTag(std::string key)
            {
                return std::find(_tags.begin(), _tags.end(), key) != _tags.end();
            }

            /*! \brief Creates a default set of tags consisting in a prefix plus a its index.
             * It will check that the tags are the same among all the processors associated to disData
             *
             * \param disData DistributedSrcData class that establishes the processors that will be compared
             * \param ntags total number of tags
             * \param prefix prefix of all the tags
             * \return the total number of tags
             * */
            int genDefaultTags(DistributedClass& disData, int ntags, std::string prefix = "Tag")
            {
                std::vector<std::string> _temp;

                for (int i = 0; i < ntags; i++)
                    _temp.push_back(prefix + "_" + std::to_string(i));

                createTags(disData, _temp);

                return static_cast<int>(_tags.size());
            }


    };
}


#endif //TAGCLASS_H
