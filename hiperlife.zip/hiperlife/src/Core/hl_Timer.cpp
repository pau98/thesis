#include "hl_State.h"
#include "hl_StTimer.h"
#include "hl_Core.h"
#include "hl_Timer.h"

namespace hiperlife::timer
{

    void start(const std::string& id)
    {
        Timer& timer = State::GetTimer();
        timer.start(id);
    }

    void stop(const std::string& id)
    {
        Timer& timer = State::GetTimer();
        timer.end(id);
    }

    void output(std::ostream &out)
    {
        Timer& timer = State::GetTimer();
        timer.printTiming(false, out);
    }

    double getTime(const std::string& id)
    {
        Timer& timer = State::GetTimer();
        return timer.printAccumTime(id);
    }
}



