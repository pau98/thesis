/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DISTRIBUTEDSRCDATA_H
#define DISTRIBUTEDSRCDATA_H

#include <vector>
#include <string>
#include <exception>
#include <stdexcept>

#include <Teuchos_RCP.hpp>

#include <Epetra_Import.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_DistributedClass.h"
#include "hl_TypeDefs.h"


namespace hiperlife
{
    /*!
     * \class DistributedSrcData
     * \brief Virtual class that provides a model for all the objects that store Distributed Data in
     * <b>hiperlife</b>.
     *
     * It is composed for items that are distributed among all the partitions.
     * It assumes that the items are ordered among the different partitions being the first
     * n0 in partition 0, the following n1 in partition 1 and so on.
     * As a virtual class, cannot be instanciated but it can be inherit from to create any kind
     * of object.
    */
    class DistributedSrcData : public DistributedClass
    {

        public:
            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            DistributedSrcData(std::string tag ="DistributedSrcData", MPI_Comm comm = MPI_COMM_WORLD) : DistributedClass(tag, comm) {}
            DistributedSrcData(DistributedSrcData &&other) = default;
            virtual ~DistributedSrcData() = default;
            DistributedSrcData& operator=(DistributedSrcData&& other) = default;

            DistributedSrcData& operator=(const DistributedSrcData& other);
            DistributedSrcData(const hiperlife::DistributedSrcData& other);
            /** @} */ // end of constructors


            /** @name Object Creation Management
            *  @{
            */
            /*! \brief Method that sets the total number of points. */
            void setNItem(int nitms) {_nItem = nitms;}
            /*! \brief Method that sets the number of points in the calling partition. */
            void setLocNItem(int locnitms) {_loc_nItem = locnitms;}
            /*! \brief Method that sets the number of points in the calling partition. */
            void setInPrefix(std::string prefix) {_filePrefix = prefix;}
            /*! \brief Method that checks the compatibility of the local and total points. */
            int checkDistribution() const;
            /*! \brief Compute a trivial distribution of nItem in all the partitions. */
            int computeTrivialDistrib() const;
            /*! \brief Method checks all the parameters and creates the object. */
            virtual void Update() = 0;
            /*! \brief Method that updates the information of the ghosts. */
            virtual void UpdateGhosts();
            /*! \brief Method that checks all the parametes and creates how is the information distributed */
            void UpdateDistData();
            /*! \brief Method that checks all the parametes and creates how is the information distributed from a input stream*/
            void UpdateDistData(std::istream& in, OutputMode mode);
            /*! \brief Method that creates the ghost list for each partition. */
            virtual int UpdateGhosts(std::vector<int> listGhosts);
            /** @} */ // end of object creation


            /** @name Object Distribution
            *  @{
            */
            /*! \brief Returns the total number of items. */
            int nItem() const {return _nItem;}
            /*! \brief Returns the number of items stored in the current partition.
             *  It does not include ghost points. */
            int loc_nItem() const {return _loc_nItem;}
            /*! \brief Returns the number of ghost items stored in the current partition.*/
            int loc_nGhost() const {return _ghosts.size();}
            /*! \brief Returns the number of items stored in a partition.
             \param part the partition to return the items, by default the calling one. */
            int proc_nItem(int part = -1) const;
            /*! \brief Returns the label of the first item stored in a partition.
             \param part the partition to return the items, by default the calling one. */
            int offs_nItem(int part = -1) const;

            /*! \brief Returns if a item belongs to the calling partition. */
            bool isItemInPart(int globIdx) const;

            /*! \brief Returns the patition that an item belongs to. */
            int getItemPartition(int globIdx) const;

            /*! \brief Returns if a item is in the list of ghosts of the calling partition. */
            virtual bool isItemInPartGhosts(int globIdx) const;
            /*! \brief Returns if a the information of an item is the calling partition, belonging or via ghosts. */
            bool isItemInfoInPart(int globIdx) const;

            /*! \brief Returns the local index that corresponds with the given one.
             \param globIdx a global index.
             */
            int locIdx(int globIdx) const {return _map->LID(globIdx);}
            /*! \brief Returns the global index that corresponds with the given one.
             \param locIdx a local index.
             */
            int globIdx(int locIdx) const {return _map->GID(locIdx);}

            /*! \brief Returns the idx in the ghost list for a given globalIdx
             *  It the globIdx is not in the ghosts lists, it will throw an exception.
                \param globIdx a global index.
            */
            int locGhostIdx(int globIdx) const;

            /*! \brief Returns the BlockMap of this object. */
            Epetra_BlockMap map() const {return *_map;}
            /** @} */ // end of object distribution


            /** @name Info Ghosts
             */

            /*! \brief Returns the reference to the complete list of ghosts */
            std::vector<int>& listGhosts() {return _ghosts;}
            /*! \brief Returns the total number of ghosts stored */
            int numGhosts() const {return _ghosts.size();}
            /*! \brief Returns the ghost stored in the n position of the array that stores the ghosts.
             *  This index should be transparent so think carefully if you need this method. */
            int getGhostByArrIndex(int n) const {return _ghosts[n];}

            /** @} */ // end of info ghosts

            /** @name I/O Methods
            *  @{
            */
            /*! \brief Print the critical information */
            void outDisData(std::ostream& os, OutputMode mode) const;
            /** @} */ // end of I/O methods



       protected:
            Teuchos::RCP<Epetra_BlockMap> _map = Teuchos::null;
            int _loc_nItem{0};    //!< Items stored locally.
            int _nItem{0};        //!< Total number of items
            /*! \brief Vector that stores the items of each partition. */
            Teuchos::RCP<Epetra_IntSerialDenseVector> _proc_nItem  = Teuchos::null;
            /*! \brief Vector that stores the offsets of each partition. */
            Teuchos::RCP<Epetra_IntSerialDenseVector> _offs_nItem  = Teuchos::null;
            /*! \brief Path to the file to read. */
            std::string _filePrefix;

            std::vector<int> _ghosts; //!< List of ghost stored in the partition.
            bool _ghostComputed{false}; //!< flag that controls if the ghosts are computed and communicated.
            /*! \brief Ghost importer for communicate information. */
            Teuchos::RCP<Epetra_Import>   _ghostsImporter  = Teuchos::null;


            /*! \brief Compute the offsets of all the partitions. */
            void _computeOffsets();
            /*! \brief Generate the Importers for ghost communication. */
            virtual int _generateImporters();
            /*! \brief Allocate ghost memory and comunicate the information. */
            virtual int _allocGhosts();


            /*! \brief update with the same number of cores*/
            void _updateDistData_sameNumProcs(std::istream& in, std::vector< int> buff, OutputMode mode);

            /*! \brief Print the critical information in binary mode */
            void outDisData_binary(std::ostream& os) const;
            /*! \brief Print the critical information in text mode */
            void outDisData_text(std::ostream& os) const;

            /*! \brief Bisection algorithm for finding the partition */
            int bisection(int) const;

        friend std::ostream &operator<<(std::ostream &output,
                                        const DistributedSrcData &dd);
    };




    template<typename T> int checkBuffer(T *buff, T *comp, int size)
    {
        int err = 0;

        for (int i = 0; i < size; i++)
            if(buff[i] != comp[i])
                err++;

        if(err != 0)
        {
            std::stringstream ss;

            ss << "checkBuffer: Error in the reading file. The read value does not correspond what it should be." << std::endl;
            ss << "Read:";
            for (int i = 0; i < size; i++)
                ss << " " << buff[i];
            ss << std::endl;
            ss << "Ref: ";
            for (int i = 0; i < size; i++)
                ss << " " << comp[i];
            ss << std::endl;

            throw std::runtime_error(ss.str());
        }

        return 0;
    }



}



#endif // DISTRIBUTEDSRCDATA_H
