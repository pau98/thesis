/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef TYPEDEFS_H
#define TYPEDEFS_H

#include <iostream>
#include <string>
#include <exception>
#include <stdexcept>
#include <numeric>
#include <math.h>
#include <map>
#include <unordered_map>
#include <vector>
#include <algorithm>

namespace hiperlife
{
    enum class ElemType
    {
        Undefined,
        Point,
        Line,
        Triang,
        Square,
        Tetrah,
        Parallelep
    };

    template<ElemType e> constexpr int computePDim();

    template<> constexpr int computePDim<ElemType::Point>()      { return 0; }
    template<> constexpr int computePDim<ElemType::Line>()       { return 1; }
    template<> constexpr int computePDim<ElemType::Triang>()     { return 2; }
    template<> constexpr int computePDim<ElemType::Square>()     { return 2; }
    template<> constexpr int computePDim<ElemType::Tetrah>()     { return 3; }
    template<> constexpr int computePDim<ElemType::Parallelep>() { return 3; }


    /*!
    * This method transforms a BasisFuncType into its corresponding string
    *
    \param mode Output basis function.
    */
    inline std::string str(ElemType et)
    {
        if (et == ElemType::Point)
            return "Point";
        else if (et == ElemType::Line)
            return "Line";
        else if (et == ElemType::Triang)
            return "Triang";
        else if (et == ElemType::Square)
            return "Square";
        else if (et == ElemType::Tetrah)
            return "Tetrah";
        else if (et == ElemType::Parallelep)
            return "Parallelep";
        else if (et == ElemType::Undefined)
            return "Undefined";
        else
            throw std::runtime_error("str: Element type not recognized, sorry.");

    }

    inline ElemType Element(std::string str)
    {
        if (str == "Point")
            return ElemType::Point;
        else if (str == "Line")
            return ElemType::Line;
        else if (str == "Triang")
            return ElemType::Triang;
        else if (str == "Square")
            return ElemType::Square;
        else if (str == "Tetrah")
            return ElemType::Tetrah;
        else if (str == "Parallelep")
            return ElemType::Parallelep;
        else if (str == "Undefined")
            return ElemType::Undefined;
        else
            throw std::runtime_error("str: Element type: " +  str +  " not recognized, sorry.");

    }

    inline ElemType& operator--(ElemType &f)
    {
        switch(f)
        {
            case ElemType::Line:
                return f=ElemType::Point;
            case ElemType::Triang:
                return f=ElemType::Line;
            case ElemType::Square:
                return f=ElemType::Line;
            case ElemType::Tetrah:
                return f=ElemType::Triang;
            case ElemType::Parallelep:
                return f=ElemType::Square;
            default:
                return f=ElemType::Undefined;
        }
    }

    inline ElemType operator--(ElemType& f, int)
    {
        ElemType tmp(f);
        --tmp;
        return tmp;
    }

    enum class BasisFuncType
    {
        Undefined,
        GlobConstr,
        Linear,
        Lagrangian,
        BSplines,
        Nurbs,
        SubdivSurfs
    };

    /*!
    * This method transforms a BasisFuncType into its corresponding string
    *
    \param mode Output basis function.
    */
    inline std::string str(BasisFuncType bf)
    {
        if (bf == BasisFuncType::GlobConstr)
            return "BasisFuncType::GlobConstr";
        else if (bf == BasisFuncType::Linear)
            return "BasisFuncType::Linear";
        else if (bf == BasisFuncType::SubdivSurfs)
            return "BasisFuncType::SubdivSurfs";
        else if (bf == BasisFuncType::Lagrangian)
            return "BasisFuncType::Lagrangian";
        else if (bf == BasisFuncType::BSplines)
            return "BasisFuncType::BSplines";
        else if (bf == BasisFuncType::Nurbs)
            return "BasisFuncType::Nurbs";
        else if (bf == BasisFuncType::Undefined)
            return "BasisFuncType::Undefined";
        else
            throw std::runtime_error("str: Basis function type not recognized.");
    }


    inline std::istream& operator>>(std::istream& str, BasisFuncType &bfType)
    {
        std::string st;
        str >> st;

        if (st == "BasisFuncType::GlobConstr")
            bfType = BasisFuncType::GlobConstr;
        else if (st == "BasisFuncType::Linear")
            bfType = BasisFuncType::Linear;
        else if (st == "BasisFuncType::SubdivSurfs")
            bfType = BasisFuncType::SubdivSurfs;
        else if (st == "BasisFuncType::Lagrangian")
            bfType = BasisFuncType::Lagrangian;
        else if (st == "BasisFuncType::BSplines")
            bfType = BasisFuncType::BSplines;
        else if (st == "BasisFuncType::Nurbs")
            bfType = BasisFuncType::Nurbs;
        else
            bfType = BasisFuncType::Undefined;

        return str;
    }

    inline BasisFuncType BasisFunction(std::string st)
    {
        if (st == "GlobConstr")
            return BasisFuncType::GlobConstr;
        else if (st == "Linear")
            return BasisFuncType::Linear;
        else if (st == "SubdivSurfs")
            return BasisFuncType::SubdivSurfs;
        else if (st == "Lagrangian")
            return BasisFuncType::Lagrangian;
        else if (st == "BSplines")
            return BasisFuncType::BSplines;
        else if (st == "Nurbs")
            return BasisFuncType::Nurbs;
        else
            return BasisFuncType::Undefined;
    }

    enum class IndexType
    {
        Undefined,
        Local,
        Global
    };

    enum class MeshType
    {
        Undefined,
        Sequential,
        Parallel
    };

    enum class OutputMode
    {
        Undefined,
        Text,
        Binary
    };

    enum class MAxis
    {
        Undefined,
        Xmin,
        Xmax,
        Ymin,
        Ymax,
        Zmin,
        Zmax
    };

    enum class Axis
    {
        Undefined,
        Xaxis,
        Yaxis,
        Zaxis
    };

    enum class BorderIntersections
    {
        Undefined,
        XmaxYmax,
        XmaxYmin,
        XmaxZmax,
        XmaxZmin,
        XminYmax,
        XminYmin,
        XminZmax,
        XminZmin,
        YminZmax,
        YminZmin,
        YmaxZmax,
        YmaxZmin
    };

    enum class CubaType
    {
        Undefined,
        Gauss,
        BorderGauss,
        BorderIntersections,
        IrregSubdivSurf,
        CutCellNonConforming,
        CutCellConforming,
        BorderImmersed,
        UserDefined,
        InteriorFacet,
        GhostPenalty
    };

    /*!
     * This method transforms a CubaType into its corresponding string
     *
     * \param mode Output cubature type.
    */
    inline std::string str(CubaType ct)
    {
        if (ct == CubaType::Gauss)
            return "CubaType::Gauss";
        else if (ct == CubaType::BorderGauss)
            return "CubaType::BorderGauss";
        else if (ct == CubaType::BorderIntersections)
            return "CubaType::BorderIntersections";
        else if (ct == CubaType::IrregSubdivSurf)
            return "CubaType::IrregSubdivSurf";
        else if (ct == CubaType::CutCellNonConforming)
            return "CubaType::CutCellNonConforming";
        else if (ct == CubaType::CutCellConforming)
            return "CubaType::CutCellConforming";
        else if (ct == CubaType::BorderImmersed)
            return "CubaType::BorderImmersed";
        else if (ct == CubaType::UserDefined)
            return "CubaType::UserDefined";
        else if (ct == CubaType::InteriorFacet)
            return "CubaType::InteriorFacet";
        else if (ct == CubaType::GhostPenalty)
            return "CubaType::GhostPenalty";
        else if (ct == CubaType::Undefined)
            return "CubaType::Undefined";
        else
            throw std::runtime_error("str: CubaType not recognized.");
    }

    /*! \brief Check compatibility between CubaTypes */
    inline bool areCubaTypesCompatible(CubaType ct0, CubaType ct1)
    {
        // Checks
        if (ct0 == CubaType::Undefined)
            throw std::runtime_error("areCubaTypesCompatible: The first CubaType is not defined.");
        if (ct1 == CubaType::Undefined)
            throw std::runtime_error("areCubaTypesCompatible: The second CubaType is not defined.");

        // Equal cubatures are compatible
        if (ct0 == ct1)
            return true;

        // Check compatibility
        std::vector<CubaType> compatibleCubaTypes = {CubaType::Gauss, CubaType::IrregSubdivSurf, CubaType::CutCellConforming, CubaType::CutCellNonConforming, CubaType::UserDefined};
        if (std::find(compatibleCubaTypes.begin(), compatibleCubaTypes.end(), ct0) != compatibleCubaTypes.end() and std::find(compatibleCubaTypes.begin(), compatibleCubaTypes.end(), ct1) != compatibleCubaTypes.end())
            return true;
        else
            return false;
    }

    /*! \brief Defines the verbosity of the output */
    enum class Verbosity
    {
        Undefined = -1,
        None      =  0,
        Low       =  1,
        Medium    =  2,
        High      =  3,
        Extreme   =  4
    };

    /*! \brief Defines the type of connectivity between meshes*/
    enum class MultiPatchConnectivity
    {
        Undefined         = -1,
        Disconnected      =  1,
        LinearConstraints =  2,
        Unclamped         =  3
    };

    /*! \brief Defines the type of remesher to use*/
    enum class RemeshMethod
    {
        Undefined = -1,
        Serial    =  1,
        Parallel  =  2
    };

    /*! \brief Defines the type of method for interpolating fields from integration points to nodes*/
    enum class ProjectionMethod
    {
        Undefined    = -1,
        LeastSquares =  1
    };

    /*! \brief Defines the type of solver for interpolating fields from integration points to nodes*/
    enum class RemeshSolver
    {
        Undefined   = -1,
        AZ_Gmres    =  1,
        AZ_ConjGrad =  2,
        MUMPS       =  3,
        BE_Gmres    =  4,
        BE_ConjGrad =  5
    };

    /*! \brief Defines the time stepping scheme for the time iterator*/
    enum class TimeSteppingScheme
    {
        Undefined = -1,
        Constant = 0,
        AdaptiveLinear = 1,
        AdaptiveGeneralizedAlpha = 2
    };

    /*! \brief Defines the method used be the time iterator to print the results*/
    enum class PrintToFileMethod
    {
        Undefined = -1,
        hiperlife = 0,
        Vtk       = 1,
        LegacyVtk = 2
    };

    /*! \brief Defines the verbosity of the output */
    enum class ConsistencyCheckType
    {
        Undefined = -1,
        None      =  0,
        Jacobian  =  1,
        Hessian   =  2,
        Both      =  3
    };

    /*! \brief Defines the type of mesh relation between meshes for its automatic creation*/
    enum class MeshRelation
    {
        None,
        hRefin,
        pRefin,
        GlobConstr,
        Boundary,
        ImmersedBoundary,
        ImmersedMesh
    };

    inline std::string str(MeshRelation mr)
    {
        if (mr == MeshRelation::None)
            return "MeshRelation::None";
        else if (mr == MeshRelation::hRefin)
            return "MeshRelation::hRefin";
        else if (mr == MeshRelation::pRefin)
            return "MeshRelation::pRefin";
        else if (mr == MeshRelation::GlobConstr)
            return "MeshRelation::GlobConstr";
        else if (mr == MeshRelation::Boundary)
            return "MeshRelation::Boundary";
        else if (mr == MeshRelation::ImmersedBoundary)
            return "MeshRelation::ImmersedBoundary";
        else if (mr == MeshRelation::ImmersedMesh)
            return "MeshRelation::ImmersedMesh";
        else
            throw std::runtime_error("str: MeshRelation not recognized.");
    }
    /*! \brief Defines the type of mesh relation between meshes for its automatic creation*/
    enum class ElementLocatorEngine
    {
        Undefined,
        None,
        Octree,
        Quadtree,
        Vtk,
        BoundingVolumeHierarchy
    };

    /*!
    * This method reads an string and transforms it into OutputMode.
    *
    \param str String to be recognized
    */
    inline OutputMode outputMode(std::string str)
    {
        if (str == "Binary")
            return OutputMode::Binary;
        else if (str == "Text")
            return OutputMode::Text;
        else
            throw std::runtime_error("outpuMode: string not recognized, sorry.");
    }

    /*!
    * This method transforms an OutputMode into its corresponding string
    *
    \param mode Output mode.
    */
    inline std::string str(OutputMode mode)
    {
        if (mode == OutputMode::Binary)
            return "Binary";
        else if (mode == OutputMode::Text)
            return "Text";
        else
            throw std::runtime_error("str: mode not recognized, sorry.");
    }


    /*!
    * This method transforms an IndexType into its corresponding string
    *
    \param type indextype mode.
    */
    inline std::string str(IndexType type)
    {
        if (type == IndexType::Local)
            return "IndexType::Local";
        else if (type == IndexType::Global)
            return "IndexType::Global";
        else
            throw std::runtime_error("str: idxtype not recognized, sorry.");
    }

    inline int computeNVert(BasisFuncType bfType, ElemType eType, int bfOrderX, int bfOrderY = -1, int bfOrderZ = -1)
    {
        int bfOrder = bfOrderX;

        switch (int(bfType))
        {
            case static_cast<int>(BasisFuncType::Linear):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Line):
                        return 2;
                    case static_cast<int>(ElemType::Triang):
                        return 3;
                    case static_cast<int>(ElemType::Tetrah):
                        return 4;
                    default:
                        throw std::runtime_error("computeNVert: ElemType not set for BasisFuncType::Linear.");
                }
                break;
            case static_cast<int>(BasisFuncType::Lagrangian):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Line):
                        return bfOrder+1;
                    case static_cast<int>(ElemType::Square):
                        return (bfOrder+1)*(bfOrder+1);
                    case static_cast<int>(ElemType::Parallelep):
                        return (bfOrder+1)*(bfOrder+1)*(bfOrder+1);
                    case static_cast<int>(ElemType::Triang):
                        return ((bfOrder+1)*(bfOrder+1)+(bfOrder+1))/2;
                    case static_cast<int>(ElemType::Tetrah):
                        return (bfOrder+1)*(bfOrder+2)*(bfOrder+3)/6;
                    default:
                        throw std::runtime_error("computeNVert: ElemType not set for BasisFuncType::Lagrangian.");
                }
                break;
            case static_cast<int>(BasisFuncType::BSplines):
                switch(int(eType))
                {
                    case static_cast<int>(ElemType::Line):
                        return bfOrderX+1;
                    case static_cast<int>(ElemType::Square):
                        return (bfOrderX+1)*(bfOrderY+1);
                    case static_cast<int>(ElemType::Parallelep):
                        return (bfOrderX+1)*(bfOrderY+1)*(bfOrderZ+1);
                    default:
                        throw std::runtime_error("computeNVert: ElemType not set for BSplines.");
                }
            case static_cast<int>(BasisFuncType::Nurbs):
                switch(int(eType))
                {
                    case static_cast<int>(ElemType::Line):
                        return bfOrderX+1;
                    case static_cast<int>(ElemType::Square):
                        return (bfOrderX+1)*(bfOrderY+1);
                    case static_cast<int>(ElemType::Parallelep):
                        return (bfOrderX+1)*(bfOrderY+1)*(bfOrderZ+1);
                    default:
                        throw std::runtime_error("computeNVert: ElemType not set for Nurbs.");
                }
            case static_cast<int>(BasisFuncType::SubdivSurfs):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Triang):
                        return 3;
                    default:
                        throw std::runtime_error("computeNVert: Use BasisFuncType::SubdivSurfs only with triangles.");
                }
            case static_cast<int>(BasisFuncType::GlobConstr):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Point):
                        return 1;
                    default:
                        throw std::runtime_error("computeNVert: Use BasisFuncType::GlobConstr only with Points.");
                }
            default:
                throw std::runtime_error("computeNVert: bfType not set.");
        }
    }

    inline int computePDim(ElemType eType)
    {
        switch(int (eType))
        {
            case static_cast<int>(ElemType::Point):
                return 0;
            case static_cast<int>(ElemType::Line):
                return 1;
            case static_cast<int>(ElemType::Square):
                return 2;
            case static_cast<int>(ElemType::Parallelep):
                return 3;
            case static_cast<int>(ElemType::Triang):
                return 2;
            case static_cast<int>(ElemType::Tetrah):
                return 3;
            default:
                throw std::runtime_error("computePDim: ElemType not set.");
        }
    }

    inline int computeDefaultNumGPts(ElemType eType, int bfOrder)
    {
        int nGPts;
        std::map<int,int> nGPts_T;

        switch(int (eType))
        {
            case static_cast<int>(ElemType::Line):
                nGPts = (int) ceil((bfOrder+1.0)/2.0);
                return nGPts;
            case static_cast<int>(ElemType::Triang):
                // nGPts_T = {{1,1},{2,3},{3,4},{4,6},{5,7},{6,12},{7,13},{8,16},{10,25},{15,54},{20,85},{25,126},{30,175}}; //FIXME: 4 and 13 points cubatures deactivated
                nGPts_T = {{1,1},{2,3},{3,6},{4,6},{5,7},{6,12},{7,16},{8,16},{10,25},{15,54},{20,85},{25,126},{30,175}};
                if (nGPts_T.count(bfOrder) == 0)
                    throw std::runtime_error("There is no default number of Gauss points for order " + std::to_string(bfOrder) + " in triangular elements.");
                return nGPts_T.find(bfOrder)->second;
            case static_cast<int>(ElemType::Square):
                nGPts = (int) ceil((bfOrder+1.0)/2.0);
                return nGPts*nGPts;
            case static_cast<int>(ElemType::Tetrah):
                nGPts_T = {{1,1},{2,4},{3,5},{4,11},{5,15},{6,27},{7,64}};
                if (nGPts_T.count(bfOrder) == 0)
                    throw std::runtime_error("There is no default number of Gauss points for order " + std::to_string(bfOrder) + " in tetrah elements.");
                return nGPts_T.find(bfOrder)->second;
            case static_cast<int>(ElemType::Parallelep):
                nGPts = (int) ceil((bfOrder+1.0)/2.0);
                return nGPts*nGPts*nGPts;
            default:
                throw std::runtime_error("computeDefaultGPts: Wrong element type.");
        }
    }

    /*! \brief Return the element corner coordinates in local element order. */
    inline std::vector<std::vector<double>> referenceCoordsElemCorners(ElemType eType)
    {
        std::vector<std::vector<double>> corners;
        switch (int(eType))
        {
            case static_cast<int>(ElemType::Line):
            {
                corners = {{-1.0}, {1.0}};

                break;
            }
            case static_cast<int>(ElemType::Triang):
            {
                corners = {{0.0, 0.0},
                           {1.0, 0.0},
                           {0.0, 1.0}};

                break;
            }
            case static_cast<int>(ElemType::Square):
            {
                corners = {{-1.0, -1.0},
                           { 1.0, -1.0},
                           {-1.0,  1.0},
                           { 1.0,  1.0}};
                break;
            }
            case static_cast<int>(ElemType::Tetrah):
            {
                corners = {{0.0, 0.0, 0.0},
                           {1.0, 0.0, 0.0},
                           {0.0, 1.0, 0.0},
                           {0.0, 0.0, 1.0}};

                break;
            }
            case static_cast<int>(ElemType::Parallelep):
            {
                corners = {{-1.0, -1.0, -1.0},
                           { 1.0, -1.0, -1.0},
                           {-1.0,  1.0, -1.0},
                           { 1.0,  1.0, -1.0},
                           {-1.0, -1.0,  1.0},
                           { 1.0, -1.0,  1.0},
                           {-1.0,  1.0,  1.0},
                           { 1.0,  1.0,  1.0}};

                break;
            }

            default:
                break;
        }

        return corners;
    }

    inline int hlToVtkElemType(ElemType eType, BasisFuncType bfType, int bfOrder)
    {
        switch (int(bfType))
        {
            case static_cast<int>(BasisFuncType::Linear):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Point):
                        return 1;
                    case static_cast<int>(ElemType::Line):
                        return 3;
                    case static_cast<int>(ElemType::Triang):
                        return 5;
                    case static_cast<int>(ElemType::Tetrah):
                        return 10;
                    default:
                        throw std::runtime_error("hlTovtkElemType: ElemType unknown!");
                }
            case static_cast<int>(BasisFuncType::Lagrangian):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Point):
                        return 1;
                    case static_cast<int>(ElemType::Line):
                        if (bfOrder == 1)
                            return 3;
                        else if (bfOrder == 2)
                            return 21;
                        else if (bfOrder == 3)
                            return 35;
                        else
                            return 68;
                    case static_cast<int>(ElemType::Triang):
                        if (bfOrder == 1)
                            return 5;
                        else if (bfOrder == 2)
                            return 22;
                        else
                            return 69;
                    case static_cast<int>(ElemType::Square):
                        if (bfOrder == 1)
                            return 9;
                        else if (bfOrder == 2)
                            return 28;
                        else
                            return 70;
                    case static_cast<int>(ElemType::Tetrah):
                        if (bfOrder == 1)
                            return 10;
                        else if (bfOrder == 2)
                            return 24;
                        else
                            return 71;
                    case static_cast<int>(ElemType::Parallelep):
                        if (bfOrder == 1)
                            return 12;
                        else if (bfOrder == 2)
                            return 29;
                        else
                            return 72;
                    default:
                        throw std::runtime_error("hlTovtkElemType: ElemType unknown!");
                }
            case static_cast<int>(BasisFuncType::BSplines):
            case static_cast<int>(BasisFuncType::Nurbs):
                switch(int(eType))
                {
                    case static_cast<int>(ElemType::Point):
                        return 1;
                    case static_cast<int>(ElemType::Line):
                        return 75;
                    case static_cast<int>(ElemType::Square):
                        return 77;
                    case static_cast<int>(ElemType::Parallelep):
                        return 79;
                    default:
                        throw std::runtime_error("hlTovtkElemType: ElemType unknown for BSplines/Nurbs.");
                }
            case static_cast<int>(BasisFuncType::SubdivSurfs):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Point):
                        return 1;
                    case static_cast<int>(ElemType::Triang):
                        return 5;
                    default:
                        throw std::runtime_error("hlTovtkElemType: ElemType unknown for SubdivSurfs.");
                }
            case static_cast<int>(BasisFuncType::GlobConstr):
                switch(int (eType))
                {
                    case static_cast<int>(ElemType::Point):
                        return 1;
                    default:
                        throw std::runtime_error("hlTovtkElemType: ElemType unknown for GlobConstr.");
                }
            default:
                throw std::runtime_error("hlToVtkElemType: bfType not set.");
        }
    }

    inline ElemType vtkTohlElemType(int vtkType)
    {
        switch(vtkType)
        {
            case 1:
                return ElemType::Point;
                break;
            case 3:
            case 68:
            case 75:
                return ElemType::Line;
                break;
            case 5:
            case 69:
                return ElemType::Triang;
                break;
            case 9:
            case 70:
            case 77:
                return ElemType::Square;
                break;
            case 10:
            case 71:
            case 79:
                return ElemType::Tetrah;
                break;
            case 12:
            case 72:
                return ElemType::Parallelep;
                break;
            default:
                throw std::runtime_error("vtkTohlElemType: vtkType unknown!");
                break;
        }
    }

    inline void gmshTohlElemType(int gmshType, ElemType &eType, BasisFuncType &bfType, int &bfOrder)
    {
        switch(gmshType)
        {
            case 15:
                eType   = ElemType::Point;
                bfType  = BasisFuncType::GlobConstr; //FIXME: No other implemented
                bfOrder = 1;
                return;
                break;
            case 1:
                eType   = ElemType::Line;
                bfType  = BasisFuncType::Lagrangian;
                bfOrder = 1;
                return;
                break;
            case 2:
                eType   = ElemType::Triang;
                bfType  = BasisFuncType::Lagrangian;
                bfOrder = 1;
                return;
                break;
            case 3:
                eType   = ElemType::Square;
                bfType  = BasisFuncType::Lagrangian;
                bfOrder = 1;
                return;
                break;
            case 4:
                eType   = ElemType::Tetrah;
                bfType  = BasisFuncType::Lagrangian;
                bfOrder = 1;
                return;
                break;
            case 5:
                eType   = ElemType::Parallelep;
                bfType  = BasisFuncType::Lagrangian;
                bfOrder = 1;
                return;
                break;
                //FIXME: Many types missing https://gmsh.info/doc/texinfo/gmsh.html#Node-ordering
            default:
                throw std::runtime_error("gmshTohlElemType: gmshType (" + std::to_string(gmshType) + ") unknown!");
                break;
        }
    }

    /*! \brief Return the element corner ids in local element order. */
    inline std::vector<int> elemCornerId(ElemType eType, BasisFuncType bfType, int bfOrderX, int bfOrderY = -1, int bfOrderZ = -1)
    {
        int bfOrder = bfOrderX;

        std::vector<int> cornerId;
        switch(int (eType))
        {
            case static_cast<int>(ElemType::Line):
                cornerId = {0, bfOrder};
                break;

            case static_cast<int>(ElemType::Triang):
                if (bfType == BasisFuncType::SubdivSurfs)
                    cornerId = {0, 1, 2};
                else
                    cornerId = {0, bfOrder, ((bfOrder+1)*(bfOrder+1)+(bfOrder+1))/2-1};
                break;

            case static_cast<int>(ElemType::Square):
                if (bfType == BasisFuncType::BSplines or bfType == BasisFuncType::Nurbs)
                    cornerId = {0, bfOrderX, (bfOrderX+1)*bfOrderY, (bfOrderX+1)*(bfOrderY+1)-1};
                else
                    cornerId = {0, bfOrder, (bfOrder+1)*bfOrder, (bfOrder+1)*(bfOrder+1)-1};
                break;

            case static_cast<int>(ElemType::Tetrah):
                if (bfOrder == 1)
                    cornerId = {0, 1, 2, 3};
                else
                    throw std::runtime_error("elemCornerId: High order not implemented for tetrah elements.");
                break;

            case static_cast<int>(ElemType::Parallelep):
                if (bfType == BasisFuncType::BSplines or bfType == BasisFuncType::Nurbs)
                    cornerId = {0, bfOrderX,
                                (bfOrderX+1)*bfOrderY, (bfOrderX+1)*(bfOrderY+1)-1,
                                (bfOrderX+1)*(bfOrderY+1)*bfOrderZ, (bfOrderX+1)*(bfOrderY+1)*bfOrderZ+bfOrderX,
                                (bfOrderX+1)*(bfOrderY+1)*(bfOrderZ+1)-1-bfOrderX, (bfOrderX+1)*(bfOrderY+1)*(bfOrderZ+1)-1};
                else
                    cornerId = {0, bfOrder,
                                (bfOrder+1)*bfOrder, (bfOrder+1)*(bfOrder+1)-1,
                                (bfOrder+1)*(bfOrder+1)*bfOrder, (bfOrder+1)*(bfOrder+1)*bfOrder+bfOrder,
                                (bfOrder+1)*(bfOrder+1)*(bfOrder+1)-1-bfOrder, (bfOrder+1)*(bfOrder+1)*(bfOrder+1)-1};
                break;

            default:
                throw std::runtime_error("elemCornerId: ElemType not set.");
                break;
        }

        return cornerId;
    }

    /*! \brief Get element node type in vtk ordering (Interior = 0; Edges = 1; Corners = 2; Faces = 3)*/
    inline std::vector<int> elemNodeTypeVtk(ElemType eType, BasisFuncType bfType, int bfOrder)
    {
        // Checks
        if (bfType == BasisFuncType::BSplines and eType == ElemType::Line)
        {  
            // std::cout << "BSplines not tested" << std::endl;
        }
        else if (bfType == BasisFuncType::BSplines or bfType == BasisFuncType::Nurbs)
            throw std::runtime_error("elemNodeTypeVtk: Not implemented for BSplines or NURBS.");

        // Allocate all as interior (0)
        int nVert = computeNVert(bfType, eType, bfOrder);
        std::vector<int> nType(nVert, 0);

        // Mark edges, corners and faces
        int n{};
        switch(int (eType))
        {
            case static_cast<int>(ElemType::Line): //FIXME:: In theory is like the following but it does not work
            {
                // Corners
                nType[0] = 2;
                nType[1] = 2;

                break;
            }
            case static_cast<int>(ElemType::Triang):
            {
                if (bfType == BasisFuncType::SubdivSurfs)
                {
                    // Corners
                    nType = {2,2,2};
                }
                else
                {
                    // Corners
                    for (int i = 0; i < 3; i++)
                        nType[n+i] = 2;
                    n = 3;

                    // Edges
                    for (int i = 0; i < 3*(bfOrder-1); i++)
                        nType[n+i] = 1;
                }
                break;
            }
            case static_cast<int>(ElemType::Square):
            {
                // Corners
                for (int i = 0; i < 4; i++)
                    nType[n+i] = 2;
                n = 4;

                // Edges
                for (int i = 0; i < 4*(bfOrder-1); i++)
                    nType[n+i] = 1;

                break;
            }
            case static_cast<int>(ElemType::Tetrah):
            {
                // Corners
                for (int i = 0; i < 4; i++)
                    nType[n+i] = 2;
                n = 4;

                // Edges
                for (int i = 0; i < 6*(bfOrder-1); i++)
                    nType[n+i] = 1;
                n += 6*(bfOrder-1);

                // Faces
                int nVert_triang = computeNVert(bfType, ElemType::Triang, bfOrder);
                for (int i = 0; i < 4*(nVert_triang-(3+3*(bfOrder-1))); i++)
                    nType[n+i] = 3;

                break;
            }
            case static_cast<int>(ElemType::Parallelep):
            {
                // Corners
                for (int i = 0; i < 8; i++)
                    nType[n+i] = 2;
                n = 8;

                // Edges
                for (int i = 0; i < 12*(bfOrder-1); i++)
                    nType[n+i] = 1;
                n += 12*(bfOrder-1);

                // Faces
                for (int i = 0; i < 6*(bfOrder-1)*(bfOrder-1); i++)
                    nType[n+i] = 3;

                break;
            }
            default:
                throw std::runtime_error("elemNodeTypeVtk: ElemType not set.");
                break;
        }

        return nType;
    }

    /*! \brief Get number of element node types {Interior, Edges, Corners, Faces}*/
    inline std::vector<int> numElemNodeType(ElemType eType, BasisFuncType bfType, int bfOrder)
    {
        // Get element node type
        std::vector<int> nType = elemNodeTypeVtk(eType, bfType, bfOrder);

        // Count frequency of each type
        std::unordered_map<int, int> mp;
        for (size_t i = 0; i < nType.size(); i++)
            mp[nType[i]]++;

        // Save into vector
        std::vector<int> numnType(4);
        for (int i = 0; i < 4; i++)
            numnType[i] = mp[i];

        return numnType;
    }

    // Create vector with the ordering of the connectivity for VTK, either direct or inverse
    //  see https://blog.kitware.com/wp-content/uploads/2018/09/Source_Issue_43.pdf
    inline std::vector<int> vtkReordering(ElemType eType, BasisFuncType bfType, int bfOrder, bool getInvertedMap = false)
    {
        // // Checks
        // if (bfType == BasisFuncType::BSplines or bfType == BasisFuncType::Nurbs)
        //     throw std::runtime_error("elemNodeTypeVtk: Not implemented for BSplines or NURBS.");

        std::vector<int> reorder;
        int nVert = computeNVert(bfType, eType, bfOrder);
        switch(int (eType))
        {
            case static_cast<int>(ElemType::Line):
                //FIXME:: In theory is like the following but it does not work
                //Corners
                reorder = {0, bfOrder};
                //Edges
                for (int ii = 1; ii < bfOrder; ii++)
                    reorder.push_back(ii);
                break;

            case static_cast<int>(ElemType::Triang):

                if (bfType==BasisFuncType::SubdivSurfs)
                {
                    reorder.resize(3);
                    iota(std::begin(reorder), std::end(reorder), 0);
                }
                else
                {
                    for (int l = 0; l < (bfOrder-1)/3+1; l++)
                    {
                        //Corners
                        reorder.push_back(nVert-(bfOrder+1-l)*(bfOrder+1-l+1)/2+l);
                        reorder.push_back(nVert-(bfOrder-l)*(bfOrder-l+1)/2-1-l);
                        reorder.push_back(nVert-(2*l+1)*(2*l+1+1)/2+l);

                        //Edges
                        for (int ii = 1; ii < bfOrder+1-l-2*(l+1)+1; ii++)
                            reorder.push_back(nVert-(bfOrder+1-l)*(bfOrder+1-l+1)/2+l+ii);
                        for (int jj = bfOrder+1-l-2; jj > 2+2*l-2; jj--)
                            reorder.push_back(nVert-(jj)*(jj+1)/2-l-1);
                        for (int jj = 2+2*l; jj < bfOrder+1-l; jj++)
                            reorder.push_back(nVert-(jj)*(jj+1)/2+l);
                    }
                    //Center
                    if (bfOrder%3 == 0)
                        reorder.push_back(nVert-(bfOrder+1-((bfOrder-1)/3+1))*(bfOrder+1-((bfOrder-1)/3+1)+1)/2+((bfOrder-1)/3+1));
                }
                break;

            case static_cast<int>(ElemType::Square):
                //Corners
                reorder = {0, bfOrder, (bfOrder+1)*(bfOrder+1)-1, (bfOrder+1)*bfOrder};
                //Edges
                for (int ii = 1; ii < bfOrder; ii++)
                    reorder.push_back(ii);
                for (int jj = 1; jj < bfOrder; jj++)
                    reorder.push_back(bfOrder+jj*(bfOrder+1));
                for (int ii = 1; ii < bfOrder; ii++)
                    reorder.push_back(ii+(bfOrder+1)*bfOrder);
                for (int jj = 1; jj < bfOrder; jj++)
                    reorder.push_back(jj*(bfOrder+1));
                //Faces
                for (int jj = 1; jj < bfOrder; jj++)
                    for (int ii = 1; ii < bfOrder; ii++)
                        reorder.push_back(jj*(bfOrder+1)+ii);
                break;

            case static_cast<int>(ElemType::Tetrah):
                if (bfOrder == 1)
                {
                    // No change for order 1
                    reorder = {0, 1, 2, 3};
                }
                else
                {
                    throw std::runtime_error("vtkReordering: High order not implemented for tetrah elements.");
                }
                break;

            case static_cast<int>(ElemType::Parallelep):
                //Corners
                reorder = {0, bfOrder, (bfOrder+1)*(bfOrder+1)-1, (bfOrder+1)*bfOrder, (bfOrder+1)*(bfOrder+1)*bfOrder, (bfOrder+1)*(bfOrder+1)*bfOrder+bfOrder, (bfOrder+1)*(bfOrder+1)*(bfOrder+1)-1, (bfOrder+1)*(bfOrder+1)*(bfOrder+1)-1-bfOrder};

                //Edges (horizontal)
                for (int m = 0; m < 5; m += 4)
                {
                    for (int ii = 1; ii < bfOrder; ii++)
                        reorder.push_back(reorder[m]+ii);
                    for (int jj = 1; jj < bfOrder; jj++)
                        reorder.push_back(reorder[m]+bfOrder+jj*(bfOrder+1));
                    for (int ii = 1; ii < bfOrder; ii++)
                        reorder.push_back(reorder[m]+ii+(bfOrder+1)*bfOrder);
                    for (int jj = 1; jj < bfOrder; jj++)
                        reorder.push_back(reorder[m]+jj*(bfOrder+1));
                }
                //Edges (vertical)
                for (int kk = 1; kk < bfOrder; kk++)
                    reorder.push_back(reorder[0] + kk*(bfOrder+1)*(bfOrder+1));
                for (int kk = 1; kk < bfOrder; kk++)
                    reorder.push_back(reorder[1] + kk*(bfOrder+1)*(bfOrder+1));
                if (bfOrder == 2) // Order is different between VTK_BIQUADRATIC_HEXA and VTK_LAGRANGE_HEXA
                {
                    for (int kk = 1; kk < bfOrder; kk++)
                        reorder.push_back(reorder[2] + kk*(bfOrder+1)*(bfOrder+1));
                    for (int kk = 1; kk < bfOrder; kk++)
                        reorder.push_back(reorder[3] + kk*(bfOrder+1)*(bfOrder+1));
                }
                else
                {
                    for (int kk = 1; kk < bfOrder; kk++)
                        reorder.push_back(reorder[3] + kk*(bfOrder+1)*(bfOrder+1));
                    for (int kk = 1; kk < bfOrder; kk++)
                        reorder.push_back(reorder[2] + kk*(bfOrder+1)*(bfOrder+1));
                }

                //Faces
                for (int ii = 0; ii < bfOrder+1; ii += bfOrder)
                {
                    for (int kk = 1; kk < bfOrder; kk++)
                        for (int jj = 1; jj < bfOrder; jj++)
                            reorder.push_back(kk*(bfOrder+1)*(bfOrder+1)+jj*(bfOrder+1)+ii);
                }
                for (int jj = 0; jj < bfOrder+1; jj += bfOrder)
                {
                    for (int kk = 1; kk < bfOrder; kk++)
                        for (int ii = 1; ii < bfOrder; ii++)
                            reorder.push_back(kk*(bfOrder+1)*(bfOrder+1)+jj*(bfOrder+1)+ii);
                }
                for (int kk = 0; kk < bfOrder+1; kk += bfOrder)
                {
                    for (int jj = 1; jj < bfOrder; jj++)
                        for (int ii = 1; ii < bfOrder; ii++)
                            reorder.push_back(kk*(bfOrder+1)*(bfOrder+1)+jj*(bfOrder+1)+ii);
                }

                //Volume
                for (int kk = 1; kk < bfOrder; kk++)
                    for (int jj = 1; jj < bfOrder; jj++)
                        for (int ii = 1; ii < bfOrder; ii++)
                            reorder.push_back(kk*(bfOrder+1)*(bfOrder+1)+jj*(bfOrder+1)+ii);

                break;

            default:
                throw std::runtime_error("vtk: ElemType not set.");
                break;
        }

        if (getInvertedMap == false)
        {
            return reorder;
        }
        else
        {
            std::vector<int> i_reorder;
            int pos;
            for (size_t i = 0u; i < reorder.size(); i++)
            {
                pos = std::find(reorder.begin(), reorder.end(), i) - reorder.begin();
                i_reorder.push_back(pos);
            }
            return i_reorder;
        }
    }

    inline int getMAxis(MAxis ax)
    {
        //Get max or min axis
        switch (int(ax))
        {
            case static_cast<int>(MAxis::Xmin):
                return 2;
            case static_cast<int>(MAxis::Xmax):
                return 3;
            case static_cast<int>(MAxis::Ymin):
                return 5;
            case static_cast<int>(MAxis::Ymax):
                return 7;
            case static_cast<int>(MAxis::Zmin):
                return 11;
            case static_cast<int>(MAxis::Zmax):
                return 13;
            default:
                throw std::runtime_error("MAxis not set.");
        }
    }

    inline int getBorderIntersections(BorderIntersections BI)
    {
        switch (int(BI))
        {
            case static_cast<int>(BorderIntersections::XmaxYmax):
                return 21;
            case static_cast<int>(BorderIntersections::XmaxYmin):
                return 15;
            case static_cast<int>(BorderIntersections::XmaxZmax):
                return 39;
            case static_cast<int>(BorderIntersections::XmaxZmin):
                return 33;
            case static_cast<int>(BorderIntersections::XminYmax):
                return 14;
            case static_cast<int>(BorderIntersections::XminYmin):
                return 10;
            case static_cast<int>(BorderIntersections::XminZmax):
                return 26;
            case static_cast<int>(BorderIntersections::XminZmin):
                return 22;
            case static_cast<int>(BorderIntersections::YmaxZmax):
                return 91;
            case static_cast<int>(BorderIntersections::YmaxZmin):
                return 77;
            case static_cast<int>(BorderIntersections::YminZmax):
                return 65;
            case static_cast<int>(BorderIntersections::YminZmin):
                return 55;
            default:
                throw std::runtime_error("BoundaryIntersection not set.");
        }
    }

    inline int getAxis(MAxis ax)
    {
        //Get max or min axis
        switch (int(ax))
        {
            case static_cast<int>(MAxis::Xmin):
            case static_cast<int>(MAxis::Xmax):
                return 0;
            case static_cast<int>(MAxis::Ymin):
            case static_cast<int>(MAxis::Ymax):
                return 1;
            case static_cast<int>(MAxis::Zmin):
            case static_cast<int>(MAxis::Zmax):
                return 2;
            default:
                throw std::runtime_error("MAxis not set.");
        }
    }

    /*!
     * \brief Related to immersed method: This strcut saves the exterior basis function id as slave
        and ids of inner basis functions as masters and corresponding weights and value.
     */
    struct cutBFConstraint
    {
        int slave;
        std::vector<int> masters;
        std::vector<double> weights;
        double value{};
    };

}
#endif // TYPEDEFS_H
