#include "hl_Core.h"

#include "hl_State.h"

namespace hiperlife {
    State* State::_state{nullptr};

    void Init(int argc, char **argv) {
        MPI_Init(&argc, &argv);
        State::Create(argc, argv);
    }

    void Finalize() {
        State::Destroy();
        MPI_Finalize();
    }

    void GlobalBarrier()
    {
        MPI_Barrier(State::Get()->_comm);
    }

    int MyRank()
    {
        return State::Get()->_myRank;
    }

    int NumProcs()
    {
        return State::Get()->_numProcs;
    }

    bool VerboseRank()
    {
        return State::Get()->_myRank == 0;
    }


}