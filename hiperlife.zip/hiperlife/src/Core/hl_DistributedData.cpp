/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <mpi.h>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <algorithm>
#include <iterator>

#include <Teuchos_RCP.hpp>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_DistributedData.h"
#include "hl_IO_Aux.h"


using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{

    void DistributedData::Update()
    {
        _classTag = "DistributedData";

        if (_loc_nItem != 0)
            UpdateDistData();
        else if (_filePrefix != "")
            _update_file();
        else if (_loc_nItem == 0 && _nItem != 0)
        {
            _loc_nItem = computeTrivialDistrib();
            UpdateDistData();
        }
        else
            throw runtime_error("DistributedData::Update: hiperlife cannot create the object. \
        //     Set the parameters correctly and run again. Goodbye!");

        //FIXME:: Can we use the following instead??
        // if (_filePrefix != "")
        // {
        //     _update_file();
        // }
        // else
        // {
        //     //Sum _loc_nItem
        //     int sum_nPts;
        //     MPI_Allreduce(&_loc_nItem, &sum_nPts, 1, MPI_INT, MPI_SUM, _comm);

        //     //Check that either _loc_nItem or _nItem has been set
        //     if (sum_nPts == 0 && _nItem == 0)
        //         throw runtime_error("DistributedData::Update: hiperlife cannot create the object. Both the number of local and global items are zero.");

        //     //Compute local items
        //     if (sum_nPts == 0 && _nItem != 0)
        //         _loc_nItem = computeTrivialDistrib();

        //     //Update
        //     UpdateDistData();
        // }

    }

    void DistributedData::_update_file()
    {
        string nameFile = _filePrefix + "." + to_string(myRank());
        string line;

        ifstream file(nameFile);
        if (!file)
            throw runtime_error("DistributedData::Update: The given file does not exists or cannot be open. Check it and run again. Goodbye!");

        getline(file, line);
        std::istringstream iss(line);

        vector<string> tokens{istream_iterator<string>{iss},
                    istream_iterator<string>{}};

        _nameTag = tokens[0];
        if (tokens[1] != _classTag)
            throw runtime_error("DistributedData::Update: The given file does not contain a "
            + _classTag + " object. Set the paramenters correctly and run again. Goodbye!");

        file.close();

        OutputMode readMode = outputMode(tokens[2]);

        if (readMode == OutputMode::Text)
        {
            file.open(nameFile);
            getline(file, line);
            UpdateDistData(file, OutputMode::Text);
            file.close();
        }
        else
        {
            file.open(nameFile, ios::binary);
            getline(file, line, '\n');
            UpdateDistData(file, OutputMode::Binary);
            file.close();
        }

    }


    void DistributedData::printFile(std::string prefix, OutputMode mode)
    {
        ofstream file;

        string nameFile = prefix + "." + to_string(myRank());

        if (mode == OutputMode::Text)
        {
            file.open(nameFile, ios::trunc);
            file << _nameTag << " " << _classTag << " Text"<< endl;
            outDisData(file, mode);
            file.close();
        }
        else if (mode == OutputMode::Binary)
        {
            file.open(nameFile, ios::binary);
            file << _nameTag << " " << _classTag << " Binary"<< endl;
            outDisData(file, mode);
            file.close();
        }


    }


}
