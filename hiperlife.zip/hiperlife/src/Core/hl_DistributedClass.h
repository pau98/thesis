/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DISTRIBUTEDCLASS
#define DISTRIBUTEDCLASS

#include <iostream>
#include <mpi.h>

#include <Epetra_MpiComm.h>
#include <Teuchos_RCP.hpp>

//FIXME: warrada, Daniel fix
#include <set>
#include <list>


namespace hiperlife
{


    /*!
     * \class DistributedClass
     * \brief Class that gather information related to the MPI rank information
     *
     * The fundamental application of this class is to provide a usefull wrapper for the MPI communicator.
     * Most of the classes of hiperlife inherits from here so we can use everywhere all the methods defined here.
     * Also, have some tags about the class and the name for the objects instanciated.
     *
    */
    class DistributedClass
    {

        public:
            /** @name Constructors
                Save inside the DistributedClass usefull information about MPI ranks.
                It can be called with a name tag for the created object.
            *  @{ */
            DistributedClass(std::string tag ="DistributedClass", MPI_Comm comm = MPI_COMM_WORLD)
            {
                _comm = comm;
                _epComm = Teuchos::rcp(new Epetra_MpiComm(_comm));

                MPI_Comm_rank(_comm, &_myRank);
                MPI_Comm_size(_comm, &_numProcs);

                _nameTag = tag;
            }
            /** @} */ // end of constructors


            /** @name Tags methods
                Setting and getting the object tags
            *  @{ */

            /*! \brief Method that set the name of the object. */
            void setNameTag(std::string name)
            {
                _nameTag = name;
            }

            /*! \brief Returns the name of the object. */
            std::string nameTag() const
            {
                return _nameTag;
            }

            /*! \brief Returns the class of the object. */
            std::string classTag() const
            {
                return _classTag;
            }
            /** @} */ // end of tags methods


            /** @name MPI Methods
                Rank information and methods related with MPI
            *  @{ */

            /*! \brief Returns the total number of MPI cores. */
            int numProcs() const
            {
                return _numProcs;
            }

            /*! \brief Return the calling rank. */
            int myRank() const
            {
                return _myRank;
            }

            /*! \brief Return the MPI communicator. */
            MPI_Comm& comm()
            {
                return _comm;
            }

            /*! \brief Return the EpetraMPI communicator. */
            Epetra_MpiComm& epComm()
            {
                return *_epComm;
            }

            /*! \brief Calling a MPI Barrier */
            void Barrier() const
            {
                MPI_Barrier(_comm);
            }
            /** @} */ // end of MPI methods


        protected:
            int _myRank;
            int _numProcs;
            MPI_Comm _comm = MPI_COMM_WORLD;
            Teuchos::RCP<Epetra_MpiComm> _epComm = Teuchos::null;
            std::string _nameTag;
            std::string _classTag{"DistributedClass"};
    };

}


#endif // DISTRIBUTEDCLASS
