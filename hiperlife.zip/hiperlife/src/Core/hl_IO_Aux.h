/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef IO_AUX
#define IO_AUX

#include <iomanip>
#include <string>
#include <sstream>
#include <exception>
#include <stdexcept>

#include "hl_TypeDefs.h"

namespace hiperlife
{
    namespace IO
    {



        /*!
        * This method write an array in text mode into an ostream. It is a template method
        * that can be used with any data type. It will add an endline at the end of
        * the array.
        *
        \param os Output stream.
        \param data Array to write.
        \param numItms Number of item to read.
        */
        template<typename T> void printData_text(std::ostream& os, T*& data, int numItms)
        {
            os << std::scientific << std::setprecision(15);

            for (int i = 0; i < numItms; i++)
                os << data[i] << " ";
            os << std::endl;
        }

        /*!
        * This method write an array in text mode into an ostream. It is a template method
        * that can be used with any data type. It will add an endline at the end of
        * the array.
        *
        \param os Output stream.
        \param data Array to write.
        \param numItms Number of item to read.
        */
        template<typename T> void printData_text(std::ostream& os, T*&& data, int numItms)
        {
            os << std::scientific << std::setprecision(15);
            for (int i = 0; i < numItms; i++)
                os << data[i] << " ";
            os << std::endl;
        }

        /*!
        * This method write an array in binary mode into an ostream. It is a template method
        * that can be used with any data type.
        *
        \param os Output stream.
        \param data Array to write.
        \param numItms Number of item to read.
        */
        template<typename T> void printData_binary(std::ostream& os, T*& data, int numItms)
        {
            for (int i = 0; i < numItms; i++)
                os.write(reinterpret_cast<const char*>(&data[i]), sizeof(data[i]));
        }

        /*!
        * This method write an array in binary mode into an ostream. It is a template method
        * that can be used with any data type.
        *
        \param os Output stream.
        \param data Array to write.
        \param numItms Number of item to read.
        */
        template<typename T> void printData_binary(std::ostream& os, T*&& data, int numItms)
        {
            for (int i = 0; i < numItms; i++)
                os.write(reinterpret_cast<const char*>(&data[i]), sizeof(data[i]));
        }



        /*!
        * This method reads from a text source and set the array. It is a template method
        * that can be used with any data type. It is suppose to read a whole
        * line.
        *
        \param outData Array to set.
        \param in Input stream to read
        \param numItms Number of item to read.
        */
        template<typename T> void fillData_text(T*& outData, std::istream& in, int numItms)
        {

            for (int i = 0; i < numItms; i++)
            {
                in >> outData[i];
            }
        }

        /*!
        * This method reads from a text source and set the array. It is a template method
        * that can be used with any data type. It is suppose to read a whole
        * line.
        *
        \param outData Array to set.
        \param in Input stream to read
        \param numItms Number of item to read.
        */
        template<typename T> void fillData_text(T*&& outData, std::istream& in, int numItms)
        {

            for (int i = 0; i < numItms; i++)
            {
                in >> outData[i];
            }
        }


        /*!
        * This method reads from a binary source and set the array. It is a template method
        * that can be used with any data type.
        *
        \param outData Array to set.
        \param in Input stream to read
        \param numItms Number of item to read.
        */
        template<typename T> void fillData_binary(T*& outData, std::istream& in, int numItms)
        {
            in.read(reinterpret_cast<char *>(outData), sizeof(T)*numItms);
        }

        /*!
        * This method reads from a binary source and set the array. It is a template method
        * that can be used with any data type.
        *
        \param outData Array to set.
        \param in Input stream to read
        \param numItms Number of item to read.
        */
        template<typename T> void fillData_binary(T*&& outData, std::istream& in, int numItms)
        {
            in.read(reinterpret_cast<char *>(outData), sizeof(T)*numItms);
        }


        /*!
        * This method reads from a source and set the array. It is a template method
        * that can be used with any data type. In OutputMode::Text, it is suppose to read a whole
        * line.
        *
        \param outData Array to set.
        \param in Input stream to read
        \param numItms Number of item to read.
        \param mode Write mode binary or text
        */
        template<typename T> int fillData(T*& outData, std::istream& in,
                                                int numItms, OutputMode mode)
        {

            if(mode == OutputMode::Binary)
            {
                fillData_binary(outData, in, numItms);
            }
            else if (mode == OutputMode::Text)
            {
                fillData_text(outData, in, numItms);
            }
            else
                return 1;

            return 0;
        }


        /*!
        * This method reads from a source and set the array. It is a template method
        * that can be used with any data type. In OutputMode::Text, it is suppose to read a whole
        * line.
        *
        \param outData Array to set.
        \param in Input stream to read
        \param numItms Number of item to read.
        \param mode Write mode binary or text
        */
        template<typename T> int fillData(T*&& outData, std::istream& in,
                                                int numItms, OutputMode mode)
        {
            if(numItms == 0)
                return 0;

            if(mode == OutputMode::Binary)
            {
                fillData_binary(outData, in, numItms);
            }
            else if (mode == OutputMode::Text)
            {
                fillData_text(outData, in, numItms);

            }
            else
                return 1;

            return 0;
        }


        /*!
        * This method write an array into an ostream. It is a template method
        * that can be used with any data type. It text mode, it adds an endline at the end of
        * the array.
        *
        \param os Output stream.
        \param data Array to write.
        \param numItms Number of item to read.
        \param mode Write mode binary or text
        */
        template<typename T> void printData(std::ostream& os, T*& data, int numItms, OutputMode mode)
        {
            if(numItms == 0)
                return;

            if(mode == OutputMode::Binary)
                printData_binary(os, data, numItms);
            else if (mode == OutputMode::Text)
                printData_text(os, data, numItms);
            else
                throw std::runtime_error("printData: Unknown output mode.");
        }

        /*!
        * This method write an array into an ostream. It is a template method
        * that can be used with any data type. It text mode, it adds an endline at the end of
        * the array.
        *
        \param os Output stream.
        \param data Array to write.
        \param numItms Number of item to read.
        \param mode Write mode binary or text
        */
        template<typename T> void printData(std::ostream& os, T*&& data, int numItms, OutputMode mode)
        {
            if(mode == OutputMode::Binary)
                printData_binary(os, data, numItms);
            else if (mode == OutputMode::Text)
                printData_text(os, data, numItms);
            else
                throw std::runtime_error("printData: Unknown output mode.");
        }


    }

}




#endif
