/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DISTRIBUTEDDATA_H
#define DISTRIBUTEDDATA_H

#include <vector>

#include <Teuchos_RCP.hpp>

#include <Epetra_Import.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_TypeDefs.h"
#include "hl_DistributedSrcData.h"


namespace hiperlife
{



    /*!
     * \brief Simplest implementation of the DistributedSrcData class. It can be used to generate trivial data distributions.
     *
    */
    class DistributedData : public DistributedSrcData
    {

        public:
            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            DistributedData(std::string tag ="DistributedData", MPI_Comm comm = MPI_COMM_WORLD) : DistributedSrcData(tag, comm) {}

            /** @} */ // end of constructors


            /** @name Object Creation Management
            *  @{
            */
            virtual void Update();

            void printFile(std::string nameFile, OutputMode mode);

            /** @} */ // end of object creation

        protected:
            void _update_file();
    };





}



#endif // DISTRIBUTEDDATA_H
