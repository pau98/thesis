/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef TIMER_H
#define TIMER_H

#include <iostream>
#include <string>

namespace hiperlife::timer
{
    /// @brief Starts a timer measure. If id does not exist in the global timer, it creates it.
    /// @param id Unique identifier to the starting measurement.
    void start(const std::string& id);
    
    /// @brief Stops a timer measure.
    /// @param id Unique identifier of the stopped measurement.
    void stop(const std::string& id);

    /// @brief Stops a timer measure.
    /// @param id Unique identifier of the stopped measurement.
    void reset();

    /// @brief Output all the measurement in the standard output.
    void output(std::ostream &out = std::cout);

    /// @brief Returns the accumulated time of a given measurement.
    /// @param id Unique indentifier of the measurement.
    double getTime(const std::string& id);
}

#endif // TIMER_H
