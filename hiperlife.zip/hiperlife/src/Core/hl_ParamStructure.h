/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef PARAM_STRUCTURE_H
#define PARAM_STRUCTURE_H

#include <functional>
#include <string>
#include <variant>
#include <vector>

#include "hl_Core.h"
#include "hl_TypeDefs.h"
#include "hl_ParserHelper.h"
#include "magic_enum/magic_enum.hpp"


namespace hiperlife
{
    struct InputParameter {
        std::string key;
        std::variant<std::monostate, double, int, std::string, bool> value_default;
        std::variant<std::monostate, std::array<double,2>, std::array<int,2>, std::vector<std::string>> value_range;

        InputParameter()
                : value_default(std::monostate()), value_range(std::monostate()){
        }

        // Copy constructor
        InputParameter(const InputParameter& other) = default;

        // Move constructor
        InputParameter(InputParameter&& other) noexcept = default;

        // Copy assignment operator
        InputParameter& operator=(const InputParameter& other) = default;

        // Move assignment operator
        InputParameter& operator=(InputParameter&& other) noexcept = default;

        // Destructor
        ~InputParameter() = default;

        // Constructor for two parameters
        template<typename T> InputParameter(const std::string key, const T default_value)
                : key(key), value_default(default_value) {
        }

        InputParameter(const std::string key, const int default_value, const int min_value, const int max_value)
                : key(key), value_default(default_value) {
                    if(min_value >= max_value)
                        throw std::runtime_error("ParameterList: Error, max_value needs to be greater than min_value.");
                    value_range = std::array<int, 2>{min_value, max_value};
        }

        InputParameter(const std::string key, const double default_value, const double min_value, const double max_value)
                : key(key), value_default(default_value) {
            if(min_value >= max_value)
                throw std::runtime_error("ParameterList: Error, max_value needs to be greater than min_value.");
            value_range = std::array<double, 2>{min_value, max_value};
        }

        InputParameter(const std::string k, const std::string default_value, std::vector<std::string> options)
                : key(k), value_default(default_value) {
            if(options.empty())
                throw std::runtime_error("ParameterList: Error, values cannot be empty.");
            value_range = options;
        }
    };

    //typedef std::map<std::string, std::variant<double, int, std::string, bool>> ParameterList;
    typedef std::vector<InputParameter> ParameterList;



    /*!
     * \brief Structure to store quantities that we want to pass to the integration functions.
     */
    class ParamStructure
    {
        public:
            std::vector<int>         iparam;    ///< e.g. number of nodes, samples, or other useful value
            std::vector<double>      dparam;    ///< e.g. material parameters(E, nu), punctual load (RHS)
            std::vector<std::string> sparam;    ///< e.g. strings
            std::vector<bool>        bparam;    ///< e.g. booleans

            std::vector<void*> vparam;

            std::vector<double> a_aux;     ///< auxiliary array of double variables
            std::vector<double> b_aux;     ///< auxiliary array of double variables
            std::vector<double> c_aux;     ///< auxiliary array of double variables

            std::vector<double> u_aux;     ///< auxiliary array of double variables
            std::vector<double> v_aux;     ///< auxiliary array of double variables
            std::vector<double> w_aux;     ///< auxiliary array of double variables

            std::vector<double> p_aux;     ///< auxiliary array of double variables
            std::vector<double> q_aux;     ///< auxiliary array of double variables
            std::vector<double> r_aux;     ///< auxiliary array of double variables

            std::vector<double> x_aux;     ///< auxiliary array of double variables
            std::vector<double> y_aux;     ///< auxiliary array of double variables
            std::vector<double> z_aux;     ///< auxiliary array of double variables

            std::vector<int> i_aux;        ///< auxiliary array of integers
            std::vector<int> j_aux;        ///< auxiliary array of integers

            std::vector<InputParameter> iParamInfo;
            std::vector<InputParameter> dParamInfo;
            std::vector<InputParameter> sParamInfo;
            std::vector<InputParameter> bParamInfo;

            std::vector<std::function<std::vector<double>(std::vector<double>)>> funcs; ///< Auxiliary functions

            template<typename T> inline T& getParameter([[maybe_unused]] int i) {
                if constexpr (std::is_same<T, double>::value)
                    return dparam[i];
                else if constexpr (std::is_same<T, int>::value)
                    return iparam[i];
                else if constexpr (std::is_same<T, std::string>::value)
                    return sparam[i];
                else if constexpr (std::is_same<T, bool>::value)
                    throw std::runtime_error("Error! Don't use getParameter<bool>(), use getBoolParameter()/setBoolParameter() instead.");
                else
                    throw std::runtime_error("Error! Parameter type not valid.");
            }

            inline double& getRealParameter(int i)
            {
                return getParameter<double>(i);
            }

            inline int& getIntParameter(int i)
            {
                return getParameter<int>(i);
            }

            inline std::string& getStringParameter(int i)
            {
                return getParameter<std::string>(i);
            }

            inline bool getBoolParameter(int i)
            {
                return bparam[i];
            }

            template<typename T> inline void setParameter(int i, T value) {
                if constexpr (std::is_same<T, double>::value) {
                    if (std::holds_alternative<std::array<double, 2>>(dParamInfo[i].value_range)) {
                        auto range = std::get<std::array<double, 2>>(dParamInfo[i].value_range);
                        if (value < range[0] or value > range[1])
                            throw std::runtime_error("SetParameter: Error, the introduced value (" + std::to_string(value) + ") is not valid. It needs to be in the range [" + std::to_string(range[0]) + ", " + std::to_string(range[1]) + "].");
                    }
                    dparam[i] = value;
                }
                else if constexpr (std::is_same<T, int>::value) {
                    if (std::holds_alternative<std::array<int, 2>>(iParamInfo[i].value_range)) {
                        auto range = std::get<std::array<int, 2>>(iParamInfo[i].value_range);
                        if (value < range[0] or value > range[1])
                            throw std::runtime_error("SetParameter: Error, the introduced value (" + std::to_string(value) + ") is not valid. It needs to be in the range [" + std::to_string(range[0]) + ", " + std::to_string(range[1]) + "].");
                    }
                    iparam[i] = value;
                }
                else if constexpr (std::is_same<T, std::string>::value) {
                    if (std::holds_alternative<std::vector<std::string>>(sParamInfo[i].value_range)) {
                        auto options = std::get<std::vector<std::string>>(sParamInfo[i].value_range);

                        if (std::find(options.begin(), options.end(), value) == options.end()) {
                            std::string all_options = std::accumulate(std::next(options.begin()), options.end(),
                                                                      options[0],
                                                                      [](std::string &a,
                                                                         const std::string &b) -> std::string {
                                                                          return a.append(", ").append(b);
                                                                      });
                            throw std::runtime_error("CheckRangeAndOptions: Error, the introduced value (\"" + value +
                                                     "\") is not valid. It needs to be one of the following options: [" +
                                                     all_options + "].");
                        }
                    }
                    sparam[i] = value;
                }
                else if constexpr (std::is_same<T, bool>::value) {
                    bparam[i] = value;
                }
                else {
                    throw std::runtime_error("Error! Parameter type not valid.");
                }
            }

            inline void setRealParameter(int i, double value)
            {
                setParameter<double>(i, value);
            }

            inline void setIntParameter(int i, int value)
            {
                setParameter<int>(i, value);
            }

            inline void setStringParameter(int i, std::string value)
            {
                return setParameter<std::string>(i, value);
            }

            inline void setBoolParameter(int i, bool value)
            {
                setParameter<bool>(i, value);
            }

            template <typename E, bool RemPrex = true>
                auto getParameterName(E value) noexcept
                {
                    return GetParameterName<E, RemPrex>(value);
                }

            // Parameters for time
            struct timeStruct
            {
                double deltat{};
                double time{};
                int timeStep{};
            } time;


            // Parameters for PredefinedElementFillings
            /* \brief Parameters for Poisson equation. See explanation in hl_PredefinedElementFillings.h*/
            struct PoissonStruct
            {
                double constantSource{std::numeric_limits<double>::quiet_NaN()};
                std::function<double(double, double, double)> source;
            } Poisson;

            /* \brief Parameters for TransientDiffusion equation. See explanation in hl_PredefinedElementFillings.h*/
            struct TransientDiffusionStruct
            {
                double diffusionCoefficient{std::numeric_limits<double>::quiet_NaN()};
                double constantSource{std::numeric_limits<double>::quiet_NaN()};
                std::function<double(double, double, double)> source;
            } TransientDiffusion;

            /* \brief Parameters for AllenCahn equation. See explanation in hl_PredefinedElementFillings.h*/
            struct AllenCahnStruct
            {
                double epsilon2{std::numeric_limits<double>::quiet_NaN()};
                double constantMobility{std::numeric_limits<double>::quiet_NaN()};
                std::function<std::vector<double>(double)> mobility;
                std::function<std::vector<double>(double)> doubleWell;
            } AllenCahn;

            /* \brief Parameters for linearElasticity equation. See explanation in hl_PredefinedElementFillings.h*/
            struct LinearElasticityStruct
            {
                double mu{std::numeric_limits<double>::quiet_NaN()};
                double lambda{std::numeric_limits<double>::quiet_NaN()};
                std::function<std::vector<double>(double, double, double)> bodyForce;
            } linearElasticity;

            /* \brief Parameters for CahnHilliard equation. See explanation in hl_PredefinedElementFillings.h*/
            struct CahnHilliardStruct
            {
                double epsilon2{std::numeric_limits<double>::quiet_NaN()};
                double constantMobility{std::numeric_limits<double>::quiet_NaN()};
                std::function<std::vector<double>(double)> mobility;
                std::function<std::vector<double>(double)> doubleWell;
            } CahnHilliard;


        friend std::ostream& operator<<(std::ostream &out, const ParamStructure &param);
    };

    std::ostream& operator<<(std::ostream &out, const ParamStructure &param);

}

#define HL_PARAMETER_LIST static inline hiperlife::ParameterList

#endif //PARAM_STRUCTURE_H
