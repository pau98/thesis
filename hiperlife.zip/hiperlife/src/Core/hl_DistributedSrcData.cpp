/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <vector>
#include <functional>

#include <Teuchos_RCP.hpp>
#include <Epetra_BlockMap.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_DistributedSrcData.h"


using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{
    DistributedSrcData::DistributedSrcData(const DistributedSrcData& other)
    : DistributedClass(other._nameTag)
    {
        this->_nameTag = other._nameTag;
        this->_classTag = other._classTag;

        this->setNItem(other.nItem());
        this->setLocNItem(other.loc_nItem());

        this->UpdateDistData();

        this->UpdateGhosts(other._ghosts);

    }

    DistributedSrcData& DistributedSrcData::operator=(const DistributedSrcData& other)
    {
        if(&other == this)
            return *this;

        this->_nameTag = other._nameTag;
        this->_classTag = other._classTag;
        this->setNItem(other.nItem());
        this->setLocNItem(other.loc_nItem());
        this->UpdateDistData();
        this->UpdateGhosts(other._ghosts);

        return *this;
    }





    int DistributedSrcData::bisection(int globIdx) const
    {

        int test_proc = _numProcs / 2;

        int proc_left = 0;
        int proc_right = _numProcs;

        while (true)
        {

            test_proc = static_cast<int>((proc_right + proc_left) / 2.);

            if(globIdx  >= (*_offs_nItem)[test_proc] && globIdx < (*_offs_nItem)[test_proc+1])
                return test_proc;

            if(globIdx  > (*_offs_nItem)[test_proc])
                proc_left = test_proc;
            else
                proc_right = test_proc;

            if (proc_right < (_numProcs-1))
            {
                if ((*_offs_nItem)[proc_right+1] == (*_offs_nItem)[proc_right] and globIdx  >= (*_offs_nItem)[proc_right])
                {
                    proc_left++;
                    proc_right = proc_right+1;
                }

            }

        }

    }




    /*! The method computes the partition in which the item globIdx is
     * stored. This information is not stores but computed using the _computeOffset
     * of the partitions.
     *
     \param globIdx item searched in global index
     */
    int DistributedSrcData::getItemPartition (int globIdx) const
    {
        if (globIdx < 0 || globIdx >= _nItem)
        {
            cout << "DistributedSrcData::getItemPartition: " + _classTag + "." << endl;
            cout << "The argument is not a valid value." << endl;
            cout << "myRank:  " << _myRank << endl;

            abort();
        }

        return bisection(globIdx);

    }

    /*!
     \param globIdx item searched in global index
     */
    bool DistributedSrcData::isItemInPart(int globIdx) const
    {
        if (globIdx >= (*_offs_nItem)[_myRank] && globIdx < (*_offs_nItem)[_myRank+1])
            return true;
        else
            return false;
    }

    /*! The method check if the information of a given item is in the current
     * partition, whether belongs to it or to the ghost list.
     *
     \param globIdx item searched in global index
     */
    bool DistributedSrcData::isItemInfoInPart(int globIdx) const
    {
        if ( isItemInPart(globIdx) )
            return true;
        else if ( isItemInPartGhosts(globIdx) )
            return true;
        else
            return false;
    }


    /*! The method check if the information of a given item is on the ghost
     * list of the calling partition.
     *
     \param globIdx item searched in global index
     */
    bool DistributedSrcData::isItemInPartGhosts(int globIdx) const
    {
        if (_ghostComputed == false)
            return false;

        auto it = std::find(_ghosts.begin(), _ghosts.end(), globIdx);

        if (it == _ghosts.end())
            return false;
        else
            return true;
    }

    int DistributedSrcData::locGhostIdx(int globIdx) const
    {
        auto it = std::find(_ghosts.begin(), _ghosts.end(), globIdx);

        if (it == _ghosts.end())
            throw runtime_error("DistributedSrcData::locGhostIdx: The idx is not in the ghost list.");

        auto posIdx = std::distance(_ghosts.begin(), it);

        return int(posIdx);
    }


    /*! \param part the partition to return the items, by default the calling one. */
    int DistributedSrcData::proc_nItem(int part) const
    {
        int ret_p = (part==-1)?_myRank:part;

        return (*_proc_nItem)[ret_p];
    }

    /*! \param part the partition to return the items, by default the calling one. */
    int DistributedSrcData::offs_nItem(int part) const
    {
        int ret_p = (part==-1)?_myRank:part;

        return (*_offs_nItem)[ret_p];
    }



    /*! In this method each partition takes its local items and broadcasting
     * this information to the rest of them, each one can stores the points
     * belonging to all the partitions and compute the corresponding offsets.
     *
     */
    void DistributedSrcData::_computeOffsets()
    {
            _proc_nItem = rcp(new Epetra_IntSerialDenseVector(_numProcs));
            _offs_nItem = rcp(new Epetra_IntSerialDenseVector(_numProcs+1));

            MPI_Allgather(&_loc_nItem, 1, MPI_INT, _proc_nItem->Values(), 1, MPI_INT, _comm);

            (*_offs_nItem)[0]  = 0;
            for (int p = 0; p < _numProcs; p++)
                (*_offs_nItem)[p+1]  = (*_offs_nItem)[p]  + (*_proc_nItem)[p];
    }


    /*!
     * If the total and local number of points are set, the method will check that the input
     * parameters are compatible and, if not, it will raise an error.
     * In the case that only _loc_nItem is set, the total number of points is computed and returned
     * but not set inside.
     * When both are compatible, _nItem is also returned.
     */
    int DistributedSrcData::checkDistribution() const
    {
        int sum_nPts;
        Barrier();
        MPI_Allreduce(&_loc_nItem, &sum_nPts, 1, MPI_INT, MPI_SUM, _comm);


        if (_nItem == 0)
        {
            return sum_nPts;
        }

        if(sum_nPts != _nItem)
        {
                throw runtime_error(_classTag +"::Update (" +  _nameTag + "): nItem does not correspond with loc_nItem");
        }

        return _nItem;
    }

    /*!
     * The total number of points is distributed in all the partitions in a way that
     * all the local number of points are compatible with the known total value.
     * The method only returns the computed values, not change them in the class.
     */
    int DistributedSrcData::computeTrivialDistrib() const
    {
        int base_loc_nItem =  _nItem / _numProcs;
        int remain_nItem = _nItem - base_loc_nItem * _numProcs;
        int locnitem = (_myRank < remain_nItem)?(base_loc_nItem+1):(base_loc_nItem);

        return locnitem;
    }


    /*!
     * If only the _loc_nItem is set, the total number of points is computed. If both are set,
     * the method will check that the input parameters are compatible and, if not, it will
     * raise an error.
     */
    void DistributedSrcData::UpdateDistData()
    {
        int sum_nPts;
        Barrier();
        MPI_Allreduce(&_loc_nItem, &sum_nPts, 1, MPI_INT, MPI_SUM, _comm);

        if(sum_nPts == 0)
        {
            throw runtime_error("DistributedSrcData::Update: nPts cannot be zero.");
        }
        else if (_nItem == 0)
        {
            _nItem = sum_nPts;
        }
        else
        {
            if(sum_nPts != _nItem)
                throw runtime_error("DistributedSrcData::Update (" +  _nameTag + "): nPts does not correspond with loc_nPts");
        }

        _computeOffsets();

        _map = rcp(new Epetra_BlockMap(_nItem, _loc_nItem, 1, 0, *_epComm));
            if(sum_nPts != _nItem)
                throw runtime_error("DistributedSrcData::Update (" +  _nameTag + "): nPts does not correspond with loc_nPts");

        Barrier();
    }

    /*!
     * The list provided is used to generate the importer information.
     * If the ghost are already computed, it raises an error.
     * \param listGhosts Input stream located at the beggining of the data.
     */
    int DistributedSrcData::UpdateGhosts(vector<int> listGhosts)
    {
        Barrier();

        _ghosts = listGhosts;

        int succ = _generateImporters();

        if (succ == 0)
        {
            int succ2 = _allocGhosts();
            if (succ != 0)
            {
                _ghostComputed = false;
                return succ2;
            }

            _ghostComputed = true;
        }
        else
        {
            _ghostComputed = false;
        }

        Barrier();

        return succ;
    }

    /*!
     * The function is called in UpdateGhosts(list) if the creation
     * of the importers has been succesfull. It is suppose
     * to be implemeneted in all the daughter clases and it will raise
     * and error if it is not.
     */
    int DistributedSrcData::_allocGhosts()
    {
        throw bad_function_call();
    }

    /*!
     * Method that should be override in daughter classes.
     * If not, a call to it raises an error.
     */
    void DistributedSrcData::UpdateGhosts()
    {
        throw bad_function_call();
    }


    int DistributedSrcData::_generateImporters()
    {

        Epetra_IntSerialDenseVector targetElements;

        targetElements.Size(_ghosts.size());

        int n = 0;
        for(auto g : _ghosts)
        {
            targetElements[n] = g;

            if (g < 0)
            {
                clog << _myRank << " : " << _nameTag << " : ";
                clog << "Negative ghost found in the list, check please!! Full List:";
                for(auto gg : _ghosts)
                    clog << gg << " ";
                clog << endl;
                throw runtime_error(_nameTag + "::_generateImporters: The list of ghost is wrong!!" );
            }

            n++;
        }


        if (_map == Teuchos::null)
            throw runtime_error(_nameTag + "::_generateImporters: Something has gone terribly bad because there is no map of the object!!" );

        Epetra_Map targetMap(-1, targetElements.Length(),
                             targetElements.Values(), 0, *_epComm);

        _ghostsImporter = rcp(new Epetra_Import(targetMap, *_map));

        return 0;
    }

}
