/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <iomanip>

#include <mpi.h>

#include "hl_StTimer.h"

namespace hiperlife
{

    Timer::Timer(std::vector<std::string> measureList, MPI_Comm comm) : DistributedClass("Timer", comm)
    {

        int size = measureList.size();
        std::vector<int> checks(_numProcs);
        MPI_Gather(&size, 1, MPI_INT, checks.data(), 1, MPI_INT, 0, _comm);

        if (_myRank == 0)
        {
            for (int i = 0; i < _numProcs; i++)
            {
                if (int(measureList.size()) != checks[i])
                    throw std::runtime_error("Timer: The information among the processors is not compatible!!");
            }
        }

        for (int i = 0; i < int(measureList.size()); i++)
        {
            map.emplace(measureList[i], i);
            measures.emplace_back(Measure(measureList[i]));
        }
    }

    Timer::Timer(MPI_Comm comm) : DistributedClass("Timer", comm)
    {
    }


    void Timer::start(std::string id)
    {
        if (map.find(id) == map.end())
        {
            map.emplace(id, measures.size());
            measures.emplace_back(Measure(id));
        }

        measures[map[id]].start();
    }

    double Timer::end(std::string id)
    {
        return measures[map[id]].end();
    }


    void Timer::setIntFields(std::vector<std::string> idIntList)
    {
        int size = idIntList.size();
        std::vector<int> checks(_numProcs);
        MPI_Gather(&size, 1, MPI_INT, checks.data(), 1, MPI_INT, 0, _comm);

        if (_myRank == 0)
        {
            for (int i = 0; i < _numProcs; i++)
            {
                if (int(idIntList.size()) != checks[i])
                    throw std::runtime_error("Timer: The information among the processors is not compatible!!");
            }
        }

        for (int i = 0; i < int(idIntList.size()); i++)
        {
            intMap.emplace(idIntList[i], i);
            intFields.push_back(Field<int>(idIntList[i]));
        }

    }

    void Timer::setDoubleFields(std::vector<std::string> idDouList)
    {
        int size = idDouList.size();
        std::vector<int> checks(_numProcs);
        MPI_Gather(&size, 1, MPI_INT, checks.data(), 1, MPI_INT, 0, _comm);

        if (_myRank == 0)
        {
            for (int i = 0; i < _numProcs; i++)
            {
                if (int(idDouList.size()) != checks[i])
                    throw std::runtime_error("Timer: The information among the processors is not compatible!!");
            }
        }

        for (int i = 0; i < int(idDouList.size()); i++)
        {
            douMap.emplace(idDouList[i], i);
            douFields.emplace_back(Field<double>(idDouList[i]));
        }
    }

    void Timer::addFieldData(std::string id, int value)
    {
        intFields[intMap[id]].add(value);

    }

    void Timer::addFieldData(std::string id, double value)
    {
        douFields[douMap[id]].add(value);
    }

    void Timer::printTiming(bool printAllRanks, std::ostream &out)
    {
        using std::endl;

        if (!printAllRanks)
        {
            Barrier();

            if (_myRank == 0)
            {
                out << "**********************************************************************************" << endl;
                out << "****************    Time Measurement    ******************************************" << endl;
                out << "      name         \ttotal_time\taverage   \tmax_time\titers " <<endl;
                for (auto m : measures)
                {
                    std::string padName = m.name + ":";
                    if(10 > padName.size())
                        padName.insert(m.name.size() + 1, 10 - padName.size() , ' ');


                    out << "Timer " << padName << "\t";
                    out << std::scientific << std::setprecision(4);
                    out << m.accumTime << "\t";
                    out << m.average() << "\t";
                    out << m.maxTime << "\t";
                    out << m.iters;
                    out << endl;
                }
                out << "**********************************************************************************" << endl;
            }

        }
        else
        {
            Barrier();

            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    if(p == 0)
                        out << "***  Time Measurement ***" << endl;

                    out << "Timer Rank " << _myRank << endl;
                    for (auto m : measures)
                    {
                        std::string padName = m.name;
                        if(10 > padName.size())
                            padName.insert(0, 20 - padName.size(), ' ');

                        out << padName << ":\t";
                        out << std::scientific << std::setprecision(4);

                        out << m.accumTime << "\t";
                        out << m.average() << "\t";
                        out << m.maxTime << "\t";
                        out << m.iters;
                        out << endl;
                    }
                }
                Barrier();
            }
        }
    }


    void Timer::printTesting(std::string prefix, std::ostream &out)
    {
        Barrier();

        if (_myRank == 0)
        {
            out << prefix;
            out << std::scientific << std::setprecision(4);
            for (auto m : measures)
                out << "  " << m.average();
            for (auto m : intFields)
                out << "  " << m.average();
            for (auto m : douFields)
                out << "  " << m.average();

            out << "     # ";
            for (auto m : measures)
                out << "  " << m.name;
            for (auto m : intFields)
                out << "  " << m.name;
            for (auto m : douFields)
                out << "  " << m.name;
            out << std::endl;
        }

        Barrier();
    }

    double Timer::printAccumTime(std::string id)
    {
        return measures[map[id]].accumTime;
    }


}
