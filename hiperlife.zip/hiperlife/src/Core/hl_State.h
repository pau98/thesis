#ifndef HL_STATE
#define HL_STATE

#include <string>
#include <vector>

#include "hl_StTimer.h"

#include <mpi.h>

namespace hiperlife
{

    /*!
     * \class State
     * \brief Internal state of a hiperlife execution
     *
     * It stores the current state of hiperlife.
     * It is designed for rapid access to general features of hiperlife like the arguments, timer, etc.
     * It should not contain anything critical that could affect to the numerical results.
     *
    */
    class State
    {
        public:
            State(State &other) = delete;
            void operator=(const State &) = delete;

            static State* Get()
            {
                return _state;
            }

            static void Create(int argc, char** argv)
            {
                if(!_state)
                {
                    _state = new State(argc, argv);
                }
            }

            static void Destroy()
            {
                delete _state;
            }

            static Timer& GetTimer()
            {
                return _state->_timer;
            }

            static std::vector<std::string>& GetParameters()
            {
                return _state->_parameters;
            }

            std::vector<std::string> _parameters;
            Timer _timer;
            MPI_Comm _comm = MPI_COMM_WORLD;
            Teuchos::RCP<Epetra_MpiComm> _epComm = Teuchos::null;
            int _myRank;
            int _numProcs;

        protected:
            State(int argc, char** argv)
            {
                for(int i = 1; i < argc; i++)
                {
                    _parameters.emplace_back(argv[i]);
                }

                _comm = MPI_COMM_WORLD;
                _epComm = Teuchos::rcp(new Epetra_MpiComm(_comm));

                MPI_Comm_rank(_comm, &_myRank);
                MPI_Comm_size(_comm, &_numProcs);
            }

            static State* _state;
    };

}

#endif //HL_STATE
