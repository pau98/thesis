#include <iostream>

#include "hl_ParamStructure.h"

std::ostream& hiperlife::operator<<(std::ostream &out, const hiperlife::ParamStructure &param)
{
    if(hiperlife::VerboseRank()) {
        out << std::boolalpha;
        out << "# Parameter structure description" << std::endl;
        if (!param.dparam.empty())
            out << "## Real parameters: " << std::endl;
        for(auto i = 0u; i < param.dparam.size(); i++) {
            out << (param.dparam.size() == param.dParamInfo.size() ? param.dParamInfo[i].key : std::to_string(i)) << " = ";
            out << param.dparam[i];
            if (std::holds_alternative<std::array<double, 2>>(param.dParamInfo[i].value_range)) {
                const auto range = std::get<std::array<double, 2>>(param.dParamInfo[i].value_range);
                const auto def_val = std::get<double>(param.dParamInfo[i].value_default);
                out << "  # range: [" << range[0] << "," << range[1] << "]";
            }
            out << std::endl;
        }
        if (!param.iparam.empty())
            out << "## Integer parameters: " << std::endl;
        for(auto i = 0u; i < param.iparam.size(); i++) {
            out << (param.iparam.size() == param.iParamInfo.size() ? param.iParamInfo[i].key : std::to_string(i)) << " = ";
            out << param.iparam[i];
            if (std::holds_alternative<std::array<int, 2>>(param.iParamInfo[i].value_range)) {
                const auto range = std::get<std::array<int, 2>>(param.iParamInfo[i].value_range);
                out << "  # range: [" << range[0] << "," << range[1] << "]";
            }
            out << std::endl;

        }
        if (!param.sparam.empty())
            out << "## String parameters: " << std::endl;
        for(auto i = 0u; i < param.sparam.size(); i++) {
            out << (param.sparam.size() == param.sParamInfo.size() ? param.sParamInfo[i].key : std::to_string(i)) << " = ";
            out << param.sparam[i];
            if (std::holds_alternative<std::vector<std::string>>(param.sParamInfo[i].value_range)) {
                const auto values = std::get<std::vector<std::string>>(param.sParamInfo[i].value_range);
                std::string all_options = std::accumulate(std::next(values.begin()), values.end(), values[0],
                                                          [](std::string& a, const std::string& b) -> std::string {
                                                              return a.append(", ").append(b); } );
                out << "  # options: [" << all_options << "]";
            }
            out << std::endl;
        }
        if (!param.bparam.empty())
            out << "## Boolean parameters: " << std::endl;
        for(auto i = 0u; i < param.bparam.size(); i++) {
            out << (param.bparam.size() == param.bParamInfo.size() ? param.bParamInfo[i].key : std::to_string(i)) << " = ";
            out << param.bparam[i] << std::endl;
        }

    }

    return out;
}
