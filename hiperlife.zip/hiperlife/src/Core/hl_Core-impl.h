#ifndef HL_CORE_IMPL
#define HL_CORE_IMPL

#include <filesystem>

#include "hl_State.h"
#include "hl_ConfigFile.h"

namespace hiperlife
{

}


#endif //HL_CORE_IMPL