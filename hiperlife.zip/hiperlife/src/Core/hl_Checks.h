/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CHECKS
#define CHECKS

#include <vector>



/*!
* The method checks a list of booleans and returns: zero if all
* of them are false, one if only one is true, and two otherwise
* \param vec list of booleans.
*/
inline int checkUpdates(std::vector<bool> vec)
{
    int n = 0;
    for (auto v :vec)
        n += int(v);

    return (n<2)?n:2;
}






#endif
