/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATURESET_H
#define CUBATURESET_H

#include <vector>
#include <set>

#include <Epetra_IntVector.h>

#include "hl_TypeDefs.h"
#include "hl_DistributedClass.h"
#include "hl_CubatureInfo.h"
#include "hl_AdjcyENStruct.h"


namespace hiperlife
{
    /*!
     * \class CubatureSet
     * \brief Class that stores sets of integrationInfo of the cubatures.
     *
     * It allows to save important information during initialization
     *
    */
    class CubatureSet
    {
        public:
            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects
             * can be created from temporal objects through move constructors.
             *  @{ */
            CubatureSet() = default;
            CubatureSet(CubatureSet&& other) = default;
            CubatureSet(const CubatureSet& other) = delete;
            CubatureSet(Teuchos::RCP<AdjcyENStruct> adjcy);
            ~CubatureSet() = default;
            // Operators
            CubatureSet& operator=(const CubatureSet& other) = delete;
            CubatureSet& operator=(CubatureSet&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate this object and,
             * in fact, several can be incompatible between each other.
             *  @{*/
            void setAdjcyEN(Teuchos::RCP<AdjcyENStruct> adjcy){_adjcyEN = adjcy;};
            void setCubaInfo(const std::vector<CubatureInfo>& cubaInfo){_cubas = cubaInfo;};
            void addCubaInfo(size_t cubaTag, const CubatureInfo& cubaInfo, std::set<size_t> elems={}, IndexType idxtype=IndexType::Global);
            void Update();
            /** @} */ // end of object creation


            /** @name Information access methods
            *  @{*/
            std::vector<CubatureInfo> cubaInfo(int elem, IndexType idxtype);
            CubatureInfo& cubaInfo(int cubaTag){return _cubas[cubaTag];};
            std::vector<int>& cubaTag(int e,  IndexType idxtype);
            int maxIntPts(); //FIXME:: Not used???
            size_t numCubas(){return _cubas.size();}
            /** @} */ // end of information access methods

        private:

            std::vector<CubatureInfo> _cubas;
            std::vector<std::vector<int>> _cubaTags;
            Teuchos::RCP<AdjcyENStruct> _adjcyEN;

    };

}

#endif // CUBATURESET_H
