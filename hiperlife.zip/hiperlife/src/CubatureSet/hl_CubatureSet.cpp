/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_AdjcyENStruct.h"
#include "hl_CubatureInfo.h"
#include "hl_CubatureSet.h"

using namespace std;

using Teuchos::rcp;
using Teuchos::RCP;


namespace hiperlife
{

    CubatureSet::CubatureSet(RCP<AdjcyENStruct> adjcy)
    {
        setAdjcyEN(adjcy);

        Update();
    }

    void CubatureSet::Update()
    {
        _cubaTags.resize(_adjcyEN->loc_nElem());

        // _cubaTags = rcp(new Epetra_IntVector(_adjcyEN->_adjcyElemNodes->RowMap()));
        // _cubaTags->PutValue(0);

        // _cubaTags->PutValue(0);

        // _cubas.resize(1);
    }

    void CubatureSet::addCubaInfo(size_t cubaTag, const CubatureInfo& cubaInfo, std::set<size_t> elems, IndexType idxtype)
    {
        if (cubaTag == _cubas.size())
        {
            //Add cubaInfo
            _cubas.push_back(cubaInfo);

            //Add cubaTags to element(s)
            if (elems.empty())
            {
                for (auto& cTag : _cubaTags)
                    cTag.push_back(cubaTag);
            }
            else
            {
                for (auto elem: elems)
                {
                    //Get local element
                    int locE{};
                    if (idxtype == IndexType::Local)
                        locE = elem;
                    else
                        locE = _adjcyEN->locIdx(elem);

                    //Add cubatag
                    _cubaTags[locE].push_back(cubaTag);
                }
            }
        }
        else if (cubaTag < _cubas.size())
        {
            //Add cubaTag to element(s)
            if (!elems.empty())
            {
                for (auto elem: elems)
                {
                    int locE{};

                    if (idxtype == IndexType::Local)
                        locE = static_cast<int>(elem);
                    else
                        locE = _adjcyEN->locIdx(static_cast<int>(elem));

                    _cubaTags[locE].push_back(static_cast<int>(cubaTag));
                }
            }
            else
            {
                throw std::runtime_error("CubatureSet::addCubaInfo: cubaId "+ std::to_string(cubaTag)+" already exists (i.e. is set for some elements) but now is being added to all elements (thus, some elements will have a repeated cubature).");
            }
        }
        else
        {
            throw std::runtime_error("CubatureSet::addCubaInfo: cubaId "+ std::to_string(cubaTag) +" does not exist or is larger than the number of cuba types existing (it cannot be added).");
        }
    }

    vector<CubatureInfo> CubatureSet::cubaInfo(int elem, IndexType idxtype)
    {
        //Get cubaTags
        vector<int>& tags = cubaTag(elem, idxtype);

        //Get vector of cubaInfo for this element
        vector<CubatureInfo> cubas={};
        for (auto t: tags)
            cubas.push_back(_cubas[t]);

        return cubas;
    }

    std::vector<int>& CubatureSet::cubaTag(int e,  IndexType idxtype)
    {
        // int locE = (idxtype==IndexType::Local)?e:_cubaTags->Map().LID(e);
        // return (*_cubaTags)[locE];
        int locE = (idxtype==IndexType::Local)?e:_adjcyEN->locIdx(e);
        return _cubaTags[locE];
    }

    int CubatureSet::maxIntPts()
    {
        int maxIntPts = -1;

        for (auto c : _cubas)
        {
            if (c.iPts > maxIntPts)
                maxIntPts = c.iPts;
        }

        return maxIntPts;
    }
}
