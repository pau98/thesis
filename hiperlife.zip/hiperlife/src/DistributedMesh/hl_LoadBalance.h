/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef NEW_BALANCE_MESH_H
#define NEW_BALANCE_MESH_H

#include <Teuchos_RCP.hpp>

#include "hl_ConnecStruct.h"
#include "hl_AdjcyNEStruct.h"
#include "hl_DistributedMesh.h"
#include "hl_MapBalance.h"
#include "hl_MeshMap_Trivial.h"
#include "hl_MeshMap_Boundary.h"
#include "hl_MeshMap_Macro.h"
#include "hl_MeshMap_Immersed.h"

namespace hiperlife
{


    /*!
     * @brief Functions related with the LoadBalance of a Distributed Mesh
     *
    */
    namespace LoadBalance
    {

        /*!
         * @brief Generation of an element-element adjacency
         *
         * The function takes an EN adjacency and a NE adjacency and create a element-element one.
         * @param connec element-node adjacency
         * @param adjcyNE node-element adjacency
         *
        */
        Teuchos::RCP<Epetra_FECrsGraph> createAdjcyElemElem(Teuchos::RCP<ConnecStruct> connec, Teuchos::RCP<AdjcyNEStruct> adjcyNE);

        /*!
         * @brief Generate the element load balance of a given mesh
         *
         * The function create internally a element-element adjacency and then performed the load balance in them.
         * With the new proposed ordering, it created a map from the old numbering to the new one.
         * This method does not change anything in the mesh, only create the map to perform the changes afterwards.
         * @param mesh The mesh to balance.
         * @param imbalaceTolerance Tolerance to the load balance distribution, per unit.
         *
        */
        Teuchos::RCP<MapBalance> elemLoadBalance(DistributedMesh* mesh, double imbalaceTolerance = 0.05);

        /*!
         * @brief Get the MapBalance for an h-refined mesh from the parent MapBalance.
         * @param parBalMap MapBalance of the parent mesh
         * @param oldMapToPar Map to Parent Elements previous to balance
         *
        */
        Teuchos::RCP<MapBalance> elemLoadBalance_HRefin(Teuchos::RCP<MapBalance> parBalMap, Teuchos::RCP<MeshMap_Macro> oldMapToPar);

        /*!
         * @brief Get the MapBalance for a boundary mesh from the parent MapBalance.
         * @param parBalMap MapBalance of the parent mesh
         * @param oldMapToPar Map to Parent Elements previous to balance
        */
        Teuchos::RCP<MapBalance> elemLoadBalance_Boundary(Teuchos::RCP<MapBalance> parBalMap, Teuchos::RCP<MeshMap_Boundary>& oldMapToPar);

        /*!
         * @brief Get the MapBalance for an immersed mesh from the parent MapBalance.
         * @param parBalMap MapBalance of the parent mesh
         * @param oldMapToPar Map to Parent Elements previous to balance
         *
        */
        Teuchos::RCP<MapBalance> elemLoadBalance_Immersed(Teuchos::RCP<MapBalance> parBalMap, Teuchos::RCP<MeshMap_Immersed>& oldMapToPar);

        /*!
         * @brief This method redistributes the elements of a distributed mesh according with a given map
         *
         * The new map defined in the introduced map is used to redistribute the elements of the Connec
         * inside the distributed mesh and therefore the element distribution of the mesh is changed.
         * @param mesh mesh to redistribute
         * @param map element map that it is used for the redistribution
        */
        void redistributeElems(DistributedMesh* mesh, Teuchos::RCP<MapBalance> map);

        void redistributeMapToParent_Immersed(DistributedMesh* mesh, Teuchos::RCP<MapBalance> parBalMap, Teuchos::RCP<MeshMap_Immersed>& oldMapToPar);

        /*!
         * @brief Generate the node balance map according to the distribution of elements.
         *
         * The introduced mesh is not changed in any way.
         * @param mesh mesh to redistribute
        */
        Teuchos::RCP<MapBalance> nodeLoadBalance(DistributedMesh* mesh);

        /*!
         * @brief This method redistributes the nodes of a distributed mesh according with a given map
         *
         * All the information stored in the nodes, the nodeData and nodeFlags are redistributed
         * according with the new map.
         * This method does not modify Connec, so DistributedMesh is broken
         * and relabelConnetivity needs to be applied after o before.
         * @param mesh mesh to redistribute
         * @param map node map that it is used for the redistribution
        */
        void redistributeNodes(DistributedMesh* mesh, Teuchos::RCP<MapBalance> map);

        /*!
         * @brief This method redistributes linear constraints of a distributed mesh according with a given map
         * @param mesh mesh to redistribute
         * @param map node map that it is used for the redistribution
        */
        void redistributeLinearConstraints(DistributedMesh* mesh, Teuchos::RCP<MapBalance> map);

        /*!
         * @brief Relabel the nodes in Connec according to the given map.
         * @param mesh mesh to redistribute
         * @param map node map that it is used for the redistribution
        */
        void relabelConnectivity(DistributedMesh* mesh, Teuchos::RCP<MapBalance> map);


        /*!
         * @brief Make elements of the fine grid compatible with the coarse for the MacroElements.
         * @param mesh Mesh to change
        */
        void macroElemCompatible(DistributedMesh* mesh);
    }


}



#endif
