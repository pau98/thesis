/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ELEMENT_LOCATOR_H
#define ELEMENT_LOCATOR_H

#include <vector>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include "hl_DistributedMesh.h"

namespace hiperlife
{
    // Forward declaration of distributed mesh so that we can create a pointer to it
    class DistributedMesh;

    /*!
     * \brief Virtual class for element locators
     */
    class ElementLocator: public DistributedClass
    {
        public:

            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects can be created from
             *  temporal objects through move constructors
             *  @{ */
            ElementLocator(std::string tag ="ElementLocator", MPI_Comm comm = MPI_COMM_WORLD);
            ElementLocator(ElementLocator&& other) = default;
            ElementLocator(const ElementLocator& other) = delete;
            ~ElementLocator() = default;

            // Operators
            ElementLocator& operator=(const ElementLocator& other) = delete;
            ElementLocator& operator=(ElementLocator&& other) = default;
            /** @} */ // end of constructors

            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Set distributed mesh
             * \param disMesh Distributed mesh
             */
            // void setDistributedMesh(Teuchos::RCP<DistributedMesh> disMesh){_disMesh = disMesh;}
            void setDistributedMesh(DistributedMesh* disMesh){_disMesh = disMesh;}
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            virtual void Update() = 0;
            /** @} */ // end of primary object creation



            /** @name Search methods
             *  @{
            */
            /*! \brief Finds the element and the coordinates in reference space of a the closest point
             * projection of one point in a partition. It returns the minimum distance to the point
             * \param elem Element global id that contains the closest point projection
             * \param rCoords Vector with the coordinates in reference space of the closest point projection
             * \param xCoords Vector of coordinates of the point
             */
            virtual double searchElementInPartition(int& elem, std::vector<double>& rCoords, std::vector<double> xCoords) = 0;
            /*! \brief Finds the element and the coordinates in reference space of a the closest point
             * projection of several points in a partition. It returns the minimum distance to the points
             * \param elems Element global ids that contain the closest point projections
             * \param rCoords Vector of vector with the coordinates in reference space of the closest point projections
             * \param xCoords Vector of vectors of coordinates of the points
             */
            std::vector<double> searchElementInPartition(std::vector<int>& elems, std::vector<std::vector<double>>& rCoords, std::vector<std::vector<double>> xCoords);
            /*! \brief Finds the element and the coordinates in reference space of a the closest point
             * projection of several points
             * \param elems Element global ids that contain the closest point projections
             * \param rCoords Vector of vector with the coordinates in reference space of the closest point projections
             * \param xCoords Vector of vectors of coordinates of the points
             */
            virtual std::vector<double> searchElement(std::vector<int>& elems, std::vector<std::vector<double>>& rCoords, std::vector<std::vector<double>> xCoords) = 0;
            /** @} */ // end of search methods


        protected:

            // Auxiliary variables
            int _nDim;
            int _pDim;
            int _nElem;
            int _loc_nElem;
            int _nPts;
            int _loc_nPts;

            // Main variables
            // Teuchos::RCP<DistributedMesh> _disMesh;
            DistributedMesh* _disMesh = nullptr;
    };

}
#endif
