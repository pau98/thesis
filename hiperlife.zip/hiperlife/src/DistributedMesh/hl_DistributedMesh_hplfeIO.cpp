/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iomanip>
#include <iostream>
#include <ostream>
#include <istream>
#include <fstream>
#include <string>

#include <mpi.h>

#include <Epetra_MpiComm.h>
#include <Epetra_CrsGraph.h>
#include <Epetra_FECrsGraph.h>

#include "hl_DistributedMesh.h"
#include "hl_TypeDefs.h"
#include "hl_IO_Aux.h"
#include "hl_MeshMap_Trivial.h"
#include "hl_MeshMap_Macro.h"
#include "hl_MeshMap_Immersed.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::rcp_dynamic_cast;


namespace hiperlife
{
    string DistributedMesh::_stdFile(string prefix)
    {
        return prefix + "." + to_string(_myRank) + ".hl";
    }


    //Output
    void DistributedMesh::_outFullData_linearConstraints(std::ostream& os, OutputMode mode) const
    {
        // Output number of lc
        vector<int> ibuff(1, 0);
        ibuff[0] = static_cast<int>(_linearConstraints.size());
        IO::printData(os, ibuff.data(), ibuff.size(), mode);

        // Output number of masters per lc
        vector<int> sizes(_linearConstraints.size());
        for (size_t i = 0; i < _linearConstraints.size(); i++)
            sizes[i] = static_cast<int>(_linearConstraints[i].masters.size());
        IO::printData(os, sizes.data(), _linearConstraints.size(), mode);

        // Output lc (casted to double)
        for (size_t i = 0; i < _linearConstraints.size(); i++)
        {
            // Rearrange
            vector<double> lc(2+2*sizes[i]);
            lc[0] = static_cast<double>(_linearConstraints[i].slave);
            for (int j = 0; j < sizes[i]; j++)
                lc[j+1] = static_cast<double>(_linearConstraints[i].masters[j]);
            for (int j = 0; j < sizes[i]; j++)
                lc[sizes[i]+j+1] = _linearConstraints[i].weights[j];
            lc[2*sizes[i]+1] = _linearConstraints[i].value;

            // Print
            IO::printData(os, lc.data(), lc.size(), mode);
        }
    }

    void DistributedMesh::_outFullData_Nurbs(std::ostream& os, OutputMode mode) const
    {
        //Output pdim and dimensions
        vector<int> ibuff(4, 0);
        ibuff[0] = static_cast<int>(_uKnot.size());
        ibuff[1] = static_cast<int>(_vKnot.size());
        ibuff[2] = static_cast<int>(_wKnot.size());
        ibuff[3] = static_cast<int>(_weights.size());
        IO::printData(os, ibuff.data(), ibuff.size(), mode);

        //Output knots
        IO::printData(os, _uKnot.data(), static_cast<int>(_uKnot.size()), mode);
        if (_pDim > 1)
            IO::printData(os, _vKnot.data(), static_cast<int>(_vKnot.size()), mode);
        if (_pDim > 2)
            IO::printData(os, _wKnot.data(), static_cast<int>(_wKnot.size()), mode);

        //Output weights
        if (_weights.size() > 0)
            IO::printData(os, _weights.data(), static_cast<int>(_weights.size()), mode);

    }

    void DistributedMesh::outFullData(std::ostream& os, OutputMode mode) const
    {
        //Output headers
        vector<int> ibuff(7);
        ibuff[0] = _nDim;
        ibuff[1] = _pDim;
        ibuff[2] = int(_basisFuncType);
        ibuff[3] = _bfOrder;
        ibuff[4] = _bfOrderX;
        ibuff[5] = _bfOrderY;
        ibuff[6] = _bfOrderZ;
        IO::printData(os, ibuff.data(), ibuff.size(), mode);

        //Output graph
        os << _graph->nameTag()  << " " << _graph->classTag() << " " << str(mode) << endl;
        _graph->outFullData(os, mode);

        //Output connectivity
        os << _connec->nameTag() << " " <<  _connec->classTag() << " " << str(mode) << endl;
        _connec->outFullData(os, mode);

        //Output node coordinates
        os << _nodeData->nameTag()  << " " << _nodeData->classTag() << " " << str(mode) << endl;
        _nodeData->outFullData(os, mode);

        //Output node flags
        os << _nodeFlags->nameTag()  << " " << _nodeFlags->classTag() << " " << str(mode) << endl;
        _nodeFlags->outFullData(os, mode);

        //Output element flags
        os << _elemFlags->nameTag()  << " " << _elemFlags->classTag() << " " << str(mode) << endl;
        _elemFlags->outFullData(os, mode);

        //Output knots and weights
        os << "Knots"  << " " << "Weights" << " " << str(mode) << endl;
        _outFullData_Nurbs(os, mode);

        //Output linear constraints
        os << "Periodicity"  << " " << "PeriodicBC" << " " << str(mode) << endl;
        _outFullData_linearConstraints(os, mode);

        //Output map to parent
        if (_mapToParent != Teuchos::null)
        {
            os << _mapToParent->nameTag()  << " " << _mapToParent->classTag() << " " << str(mode) << endl;
            _mapToParent->outFullData(os, mode);
        }
        else
        {
            os << "MeshMap_Empty"  << " " << "MeshMap" << " " << str(mode) << endl;
        }
    }

    int DistributedMesh::printFile(string test_prefix, OutputMode mode, vector<Epetra_MultiVector*> vecData, vector<string> vecNames)
    {
        (void)vecData;   //FIXME erase these argument or make use of it
        (void)vecNames;  //FIXME
        ofstream ofile;
        string fileName = _stdFile(test_prefix);

        if (mode == OutputMode::Text)
            ofile.open(fileName);
        else
            ofile.open(fileName, ios::binary);

        ofile << _nameTag << " ";
        ofile << _classTag << " ";
        ofile << str(mode) << endl;

        outFullData(ofile, mode);


        ofile.close();

        return 0;

    }


    //Input
    void DistributedMesh::_updateFile()
    {

        ifstream ifile;
        string fileName = _stdFile(_tmp_filePrefix);
        string buffName, buffClass, buffMode;

        if (_tmp_outputmode == OutputMode::Text)
            ifile.open(fileName);
        else
            ifile.open(fileName, ios::binary);

        if (ifile.good() == false)
            throw std::runtime_error("DistributedMesh::Update: The file: "+  fileName + " could not be opened. Check that and rerun, please. Goodbye!");



        ifile >> buffName; ifile >> buffClass; ifile >> buffMode;

        if (buffClass != _classTag)
            throw std::runtime_error("DistributedMesh::Update: this file does not contain a valid DistributedMesh (error: buffClass: " + buffClass + "). Check that and rerun, please. Goodbye!");

        if (buffName == "" || buffMode == "")
            throw std::runtime_error("DistributedMesh::Update: this file does not contain a valid DistributedMesh (error: name/mode). Check that and rerun, please. Goodbye!");


        _nameTag = buffName;
        OutputMode readOM = outputMode(buffMode);

        if(_tmp_outputmode == OutputMode::Undefined)
            _tmp_outputmode = readOM;
        else
        {
            if (readOM != _tmp_outputmode)
                throw std::runtime_error("DistributedMesh::Update: The mode set is not the same of the file. Check that and rerun, please. Goodbye!");
        }

        _tmp_istream = &ifile;

        _updateIStream();


        ifile.close();
    }

    void DistributedMesh::_updateIStream()
    {
        //Initialize
        string buffName, buffClass, buffMode;
        string rMode;
        rMode = str(_tmp_outputmode);
        istream& in = *_tmp_istream;

        //Read headers
        vector<int> ibuff(7);
        IO::fillData(ibuff.data(), in, ibuff.size(), _tmp_outputmode);
        _nDim = ibuff[0];
        _pDim = ibuff[1];
        _basisFuncType = BasisFuncType(ibuff[2]);
        _bfOrder = ibuff[3];
        _bfOrderX = ibuff[4];
        _bfOrderY = ibuff[5];
        _bfOrderZ = ibuff[6];

        //Check ndim
        if (ibuff[0] != 3)
            throw std::runtime_error("DistributedMesh::Update: Is the physical dimension really different from three? Check that and rerun, please. Goodbye!");

        //Read graph
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "GraphStruct" || buffName != "Graph" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: this file does not contain a valid DistributedMesh (error: GraphStruct). Check that and rerun, please. Goodbye!");
        }
        else
        {
            _graph->setIStream(in, _tmp_outputmode);
            _graph->Update();
        }

        //Read connectivity
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "ConnecStruct" || buffName != "Connec" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: this file does not contain a valid DistributedMesh (error: ConnecStruct). Check that and rerun, please. Goodbye!");
        }
        else
        {
            _connec->setIStream(in, _tmp_outputmode);
            _connec->Update();
        }

        //Read node coordinates
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "FieldStruct" || buffName != "nodeData" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: this file does not contain a valid DistributedMesh (error: FieldStruct). Check that and rerun, please. Goodbye!");
        }
        else
        {
            _nodeData->setIStream(in, _tmp_outputmode);
            _nodeData->Update();
        }

        //Read node flags
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "IntFieldStruct" || buffName != "nodeFlags" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: this file does not contain a valid DistributedMesh (error: IntFieldStruct). Check that and rerun, please. Goodbye!");
        }
        else
        {
            _nodeFlags->setIStream(in, _tmp_outputmode);
            _nodeFlags->Update();
        }

        //Read element flags
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "IntFieldStruct" || buffName != "elemFlags" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: this file does not contain a valid DistributedMesh (error: IntFieldStruct). Check that and rerun, please. Goodbye!");
        }
        else
        {
            _elemFlags->setIStream(in, _tmp_outputmode);
            _elemFlags->Update();
        }

        //Read knots and weights
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "Weights" || buffName != "Knots" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: this file does not contain valid knot and/or weight (error: knot/weight). Check that and rerun, please. Goodbye!");
        }
        else
        {
            _updateIStream_Nurbs();
        }

        //Read mesh linear constraints
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "PeriodicBC" || buffName != "Periodicity" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: this file does not contain valid linearConstraints data (error: periodic). Check that and rerun, please. Goodbye!");
        }
        else
        {
            _updateIStream_linearConstraints();
        }

        //Read map to parent
        in >> buffName; in >> buffClass; in >> buffMode;
        if (buffClass != "MeshMap" || buffMode != rMode)
        {
            throw std::runtime_error("DistributedMesh::Update: This file does not contain valid map to parent data (error: meshmap). Check that and rerun, please. Goodbye!");
        }
        else
        {
            if (buffName == "MeshMap_Empty")
            {

            }
            else if (buffName == "MeshMap_Trivial")
            {
                //Create map to parent
                RCP<MeshMap_Trivial> map = rcp(new MeshMap_Trivial("MeshMap_Trivial", _comm));
                map->setIStream(in, _tmp_outputmode);
                map->Update();

                //Cast it to a MeshMap
                _mapToParent = rcp_dynamic_cast<MeshMap>(map);
            }
            else if (buffName == "MeshMap_Macro")
            {
                //Create map to parent
                RCP<MeshMap_Macro> map = rcp(new MeshMap_Macro("MeshMap_Macro", _comm));
                map->setIStream(in, _tmp_outputmode);
                map->Update();

                //Cast it to a MeshMap
                _mapToParent = rcp_dynamic_cast<MeshMap>(map);
            }
            else if (buffName == "MeshMap_Immersed")
            {
                //Create map to parent
                RCP<MeshMap_Immersed> map = rcp(new MeshMap_Immersed("MeshMap_Immersed", _comm));
                map->setIStream(in, _tmp_outputmode);
                map->Update();

                //Cast it to a MeshMap
                _mapToParent = rcp_dynamic_cast<MeshMap>(map);
            }
            else
            {
                throw std::runtime_error("DistributedMesh::Update: This file does not contain valid map to parent data (error: meshmap). Check that and rerun, please. Goodbye!");
            }
        }

        // Compute Ghosts for graph
        UpdateBasicGhosts();

        // Reorder connectivity
        if (_basisFuncType == BasisFuncType::SubdivSurfs)
            _reorderConnecSubdivSurfs();

        // Create Adjcy NE
        updateAdjcyNE();
    }

    void DistributedMesh::_updateIStream_Nurbs()
    {
        istream& in = *_tmp_istream;
        OutputMode mode = _tmp_outputmode;

        //Get pdim and knot dimensions
        vector<int> buff(4);
        IO::fillData(buff.data(), in, buff.size(), mode);
        int uk_size = buff[0];
        int vk_size = buff[1];
        int wk_size = buff[2];
        int wei_size = buff[3];

        //Set number of elements per direction
        _nElemX = uk_size - _bfOrderX*2 - 1;
        if (vk_size != 0)
            _nElemY = vk_size - _bfOrderY*2 - 1;
        else
            _nElemY = -1;
        if (wk_size != 0)
            _nElemZ = wk_size - _bfOrderZ*2 - 1;
        else
            _nElemZ = -1;

        //Read knots
        double * _tmp_uKnot = new double[uk_size];
        double * _tmp_vKnot = new double[vk_size];
        double * _tmp_wKnot = new double[wk_size];
        IO::fillData(_tmp_uKnot, in, uk_size, mode);
        if (_pDim > 1)
            IO::fillData(_tmp_vKnot, in, vk_size, mode);
        if (_pDim > 2)
            IO::fillData(_tmp_wKnot, in, wk_size, mode);

        //Set knots
        _uKnot.reserve(uk_size);
        for (int k = 0; k < uk_size; k++)
            _uKnot.push_back(_tmp_uKnot[k]);
        _vKnot.reserve(vk_size);
        for (int k = 0; k < vk_size; k++)
            _vKnot.push_back(_tmp_vKnot[k]);
        _wKnot.reserve(wk_size);
        for (int k = 0; k < wk_size; k++)
            _wKnot.push_back(_tmp_wKnot[k]);

        //Read and set weights
        double * _tmp_weights = new double[wei_size];
        if (wei_size > 0)
        {
            _weights.reserve(wei_size);
            IO::fillData(_tmp_weights, in, wei_size, mode);
            for (int k = 0; k < wei_size; k++)
                _weights.push_back(_tmp_weights[k]);
        }

        //Delete
        delete[] _tmp_uKnot;
        delete[] _tmp_vKnot;
        delete[] _tmp_wKnot;
        delete[] _tmp_weights;
    }


    void DistributedMesh::_updateIStream_linearConstraints()
    {
        istream& in = *_tmp_istream;
        OutputMode mode = _tmp_outputmode;

        // Get number of mesh linear constraints
        vector<int> buff(1);
        IO::fillData(buff.data(), in, buff.size(), mode);
        int nlc = buff[0];
        _linearConstraints.resize(nlc);

        // Read number of masters per lc
        vector<int> sizes(nlc);
        IO::fillData(sizes.data(), in, nlc, mode);

        // Read lc
        for (size_t i = 0; i < _linearConstraints.size(); i++)
        {
            // Read
            vector<double> lc(2+2*sizes[i]);
            IO::fillData(lc.data(), in, 2+2*sizes[i], mode);

            // Rearrange
            _linearConstraints[i].slave = static_cast<int> (lc[0]);
            _linearConstraints[i].masters.resize(sizes[i]);
            for (int j = 0; j < sizes[i]; j++)
                _linearConstraints[i].masters[j] = static_cast<int>(lc[j+1]);
            _linearConstraints[i].weights.resize(sizes[i]);
            for (int j = 0; j < sizes[i]; j++)
                _linearConstraints[i].weights[j] = lc[sizes[i]+j+1];
            _linearConstraints[i].value = lc[2*sizes[i]+1];
        }
    }


}
