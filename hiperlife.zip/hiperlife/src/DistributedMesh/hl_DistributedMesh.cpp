/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <mpi.h>
#include <numeric>      // std::accumulate


#include "hl_StTimer.h"
#include "hl_Geometry.h" // doesIntersect
#include <hl_MeshMap_Boundary.h>
#include <hl_MeshMap_Trivial.h>
#include <hl_MeshMap_Macro.h>
#include <hl_MeshMap_Immersed.h>
#include "hl_DistributedMesh.h"
#include "hl_Linear.h"
#include "hl_Lagrangian.h"
#include "hl_BSplines.h"
#include "hl_Nurbs.h"
#include "hl_LoopSubdivision.h"
#include "hl_LoadBalance.h"
#include "hl_OctreeElementLocator.h"
#include "hl_QuadtreeElementLocator.h"
#include "hl_BVHElementLocator.h"
#ifdef HL_VTK
#include "hl_vtkElementLocator.h"
#endif

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::rcp_dynamic_cast;


namespace hiperlife
{

    DistributedMesh::DistributedMesh(std::string tag, MPI_Comm comm) : DistributedClass(tag, comm)
    {
        _connec = rcp(new ConnecStruct("Connec", _comm));
        _graph  = rcp(new GraphStruct("Graph", _comm));

        _adjcyNE  = rcp(new AdjcyNEStruct("adjcyNE", _comm));
        _adjcyEN  = rcp(new AdjcyENStruct("adjcyEN", _comm));
        _adjcyFullNE  = rcp(new AdjcyNEStruct("adjcyFullNE", _comm));

        _nodeData = rcp(new FieldStruct("nodeData", _comm));
        _nodeFlags = rcp(new IntFieldStruct("nodeFlags", _comm));

        _elemFlags = rcp(new IntFieldStruct("elemFlags", _comm));

        _mProc = numProcs()-1;
    }

    void DistributedMesh::Update()
    {
        _classTag = "DistributedMesh";
        if (_nameTag == "DistributedClass")
            _nameTag = "DistributedMesh";

        if (_tmp_filePrefix != "")
        {
            _updateFile();
        }
        else if (_tmp_istream != nullptr && _tmp_outputmode != OutputMode::Undefined)
        {
            _updateIStream();
        }
        else
        {
            // Control if we have a valid parent mesh
            if (_parentMesh != Teuchos::null and _parentMesh->_meshCrea != Teuchos::null and
                _meshRel != MeshRelation::ImmersedBoundary and _meshRel != MeshRelation::ImmersedMesh)
            {
                _meshCrea = _parentMesh->_meshCrea;
            }

            // Create the mesh
            if (_myRank == 0 and _verbosity >= Verbosity::Medium)
                cout << "  Updating meshCreator" << endl;
            UpdateMeshCreator();

            // Create all the fundamental structures of DistributedMesh
            if (_myRank == 0 and _verbosity >= Verbosity::Medium)
                cout << "  Creating all the fundamental structures of the distributed mesh" << endl;
            UpdateBasic();

            // Create map to parent
            if (_myRank == 0 and _verbosity >= Verbosity::Medium and _meshRel != MeshRelation::None)
                cout << "  Creating map to parent" << endl;
            if (_meshRel == MeshRelation::hRefin)
            {
                if (_hRefLevel == 0)
                {
                    RCP<MeshMap_Trivial> mapTriv = rcp(new MeshMap_Trivial("MeshMap_Trivial", _comm));
                    mapTriv->setLocNItem(_parentMesh->loc_nElem());
                    mapTriv->Update();
                    _mapToParent = rcp_dynamic_cast<MeshMap>(mapTriv);
                }
                else
                {
                    //Compute the final local nElems through the parent one and the element ratio
                    uint64_t locNElem = static_cast<uint64_t>(nElem()) * static_cast<uint64_t>(_parentMesh->loc_nElem());
                    locNElem /= static_cast<uint64_t>(_parentMesh->nElem());

                    //Create map to parent
                    RCP<MeshMap_Macro> mapMacro = rcp(new MeshMap_Macro("MeshMap_Macro", _comm));
                    mapMacro->setLocNItem(locNElem);
                    mapMacro->setOutNItems(_parentMesh->loc_nElem());
                    mapMacro->Update();

                    //Save map to parent
                    _mapToParent = rcp_dynamic_cast<MeshMap>(mapMacro);
                }
            }
            else if (_meshRel == MeshRelation::pRefin)
            {
                //Create map to parent
                RCP<MeshMap_Trivial> mapTriv = rcp(new MeshMap_Trivial("MeshMap_Trivial", _comm));
                mapTriv->setLocNItem(_parentMesh->loc_nElem());
                mapTriv->Update();

                //Save map to parent
                _mapToParent = rcp_dynamic_cast<MeshMap>(mapTriv);
            }
            else if (_meshRel == MeshRelation::GlobConstr)
            {
                //Create map to parent
                RCP<MeshMap_Trivial> mapTriv = rcp(new MeshMap_Trivial("MeshMap_Trivial", _comm));
                mapTriv->setLocNItem(_parentMesh->loc_nElem());
                mapTriv->Update();

                //Save map to parent
                _mapToParent = rcp_dynamic_cast<MeshMap>(mapTriv);
            }
            else if (_meshRel == MeshRelation::Boundary)
            {
                // Create map to parent
                RCP<MeshMap_Boundary> mapBnd = rcp(new MeshMap_Boundary("MeshMap_Boundary", _comm));
                mapBnd->setDistrMap(_meshCrea->_elMap_newToOld);
                mapBnd->Update();

                // Save map to parent
                _mapToParent = rcp_dynamic_cast<MeshMap>(mapBnd);
            }
            else if (_meshRel == MeshRelation::ImmersedBoundary)
            {
                // Save and share immersed segments to back mesh only
                _parentMesh->_setChildMesh(this);
                _parentMesh->_shareImmersedSegments(); // Done for Bsplines

                // Create map to parent
                RCP<MeshMap_Immersed> mapImm = rcp(new MeshMap_Immersed("MeshMap_Immersed", _comm));
                mapImm->setMeshInNItems(loc_nElem());
                mapImm->setMeshOutNItems(_parentMesh->loc_nElem());
                mapImm->setDistrMap(_createImmersedElemMap());  // Done for bsplines
                mapImm->Update();

                // Save map to parent
                _mapToParent = rcp_dynamic_cast<MeshMap>(mapImm);
            }
            else if (_meshRel == MeshRelation::ImmersedMesh)
            {
                // FIXME:: I will probably need to set _vMAx in a correct order

                // Save and share immersed segments to back mesh only
                _parentMesh->_setChildMesh(this);
                _parentMesh->_shareImmersedSegments();

                // Create map to parent
                RCP<MeshMap_Immersed> mapImm = rcp(new MeshMap_Immersed("MeshMap_Immersed", _comm));
                mapImm->setMeshInNItems(_computeNumberOfBoundaryElements());
                mapImm->setMeshOutNItems(_parentMesh->loc_nElem());
                mapImm->setDistrMap(_createImmersedElemMap());
                mapImm->Update();

                // Save map to parent
                _mapToParent = rcp_dynamic_cast<MeshMap>(mapImm);
            }

            //Balance mesh
            if (_myRank == 0 and _verbosity >= Verbosity::Medium and _balanceMesh)
                cout << "  Balancing the mesh" << endl;
            if (_balanceMesh)
                BalanceDistMesh();
        }

        // Complete the construction of the distributed mesh
        if (_myRank == 0 and _verbosity >= Verbosity::Medium)
            cout << "  Completing the construction of the distributed mesh" << endl;
        UpdateComplete();

        // Create interior/boundary/exterior element flags
        if (!(_tmp_filePrefix != "") and !(_tmp_istream != nullptr && _tmp_outputmode != OutputMode::Undefined))
        {
            if (_meshRel == MeshRelation::ImmersedBoundary)
            {
                // _parentMesh->setImmersedInteriorPoints(_interiorPoints);
                _parentMesh->setRegionTags(_userTags);
                _parentMesh->setImmersedInteriorPoints(_interiorPoints);
                _parentMesh->_createElemFlagsForImmersed();  // Done for Bsplines
                _parentMesh->_saveMapToChild();
                if (_userTags.size() == 0)
                    _parentMesh->_createCutBFStruts();
                else
                    _parentMesh->_createCutBFStrutsRegions();  // FIXBSPLINES
            }
            else if (_meshRel == MeshRelation::ImmersedMesh)
            {
                _parentMesh->setImmersedInteriorPoints(_interiorPoints);
                _parentMesh->_createElemFlagsForImmersed();
                _parentMesh->_saveMapToChild();
                _parentMesh->_createCutBFStruts();
            }
        }

        // Create multiple curves flag vector for BSplines
        if ((basisFuncType() == BasisFuncType::BSplines) and (elemType() == ElemType::Line))
        {
            double knt0 = -100;
            int k = -7;
            _vCrv.clear();
            for (double knt : _uKnot)
            {
                if(knt < knt0)
                {
                    _vCrv.push_back(k);
                    k -= 7; // block of n_c+7 knots per curve: k = first element of the next curve
                }
                k++;
                knt0 = knt;
            }
        }

        // Reload meshCreator
        if (_meshCrea != Teuchos::null)
        {
            if (_myRank == 0 and _verbosity >= Verbosity::Medium)
                cout << "  Reload meshCreator parent" << endl;
            _meshCrea->_reloadMesh();
        }
    }

    void DistributedMesh::UpdateMeshCreator()
    {
        //Check that there is a mesh creator and a parent mesh for immersed
        if ((_meshRel == MeshRelation::ImmersedBoundary or _meshRel == MeshRelation::ImmersedMesh) and (_meshCrea == Teuchos::null or _parentMesh == Teuchos::null))
            throw runtime_error("DistributedMesh::Update: Immersed meshes need both a mesh creator and a parent mesh.");
        //Check that we have a mesh creator
        if (_meshCrea == Teuchos::null)
            throw runtime_error("DistributedMesh::Update: There is no Mesh Creator of any kind (StructMeshGenerator or MeshLoader) available. Please check that.");

        //Save meshCreator
        _meshCrea->_saveMesh();

        //Get specific meshes
        if (_parentMesh == Teuchos::null)
        {
            //Check mesh
            try
            {
                _meshCrea->_checkMesh();
            }
            catch(runtime_error& err)
            {
                throw runtime_error("DistributedMesh::UpdateMeshCreator: The mesh created by the MeshCreator is wrong. " + string(err.what()));
            }

        }
        else if (_meshRel == MeshRelation::hRefin)
        {
            // Get h refined mesh
            if (_hRefLevel != 0)
                _meshCrea->_getHRefinedMesh(_hRefLevel);

            // Check mesh
            try
            {
                _meshCrea->_checkMesh();
            }
            catch(runtime_error& err)
            {
                throw runtime_error("DistributedMesh::UpdateMeshCreator: The h-refined mesh created by the MeshCreator is wrong. " + string(err.what()));
            }
        }
        else if (_meshRel == MeshRelation::pRefin)
        {
            // Get p-refined mesh
            _meshCrea->_getPRefinedMesh(_pRefOrderDiff);

            // Check mesh
            try
            {
                _meshCrea->_checkMesh();
            }
            catch(runtime_error& err)
            {
                throw runtime_error("DistributedMesh::UpdateMeshCreator: The p-refined mesh created by the MeshCreator is wrong. " + string(err.what()));
            }
        }
        else if (_meshRel == MeshRelation::GlobConstr)
        {
            setNDim(_parentMesh->_nDim);
            setElemType(ElemType::Point);
            setBasisFuncType(BasisFuncType::GlobConstr);
            setBasisFuncOrder(0);
            setBasisFuncOrderDir(-1, -1, -1);

            setLocNElem(_parentMesh->loc_nElem());
            if (myRank() == _mProc)
                setLocNPts(1);
            else
                setLocNPts(0);

            vector<double> coords(_parentMesh->_nDim, 0.0);
            setDistCoords(coords);
            vector<int> creases(1, 0);
            setDistCreases(creases);
            vector<int> connec;
            if (_parentMesh->loc_nElem() > 0)
                connec.resize(_parentMesh->loc_nElem(), 0);
            else
                connec.resize(1, 0);
            setDistConnec(connec);
            vector<int> elemFlags(1, 0);
            setDistElemFlags(elemFlags);

            return;
        }
        else if (_meshRel == MeshRelation::Boundary)
        {
            // Get boundary mesh
            _meshCrea->_getBoundaryMesh(_vMAx);

            // Check mesh
            try
            {
                _meshCrea->_checkMesh();
            }
            catch(runtime_error& err)
            {
                throw runtime_error("DistributedMesh::UpdateMeshCreator: The boundary mesh created by the MeshCreator is wrong. " + string(err.what()));
            }
        }

        //Set distributed mesh
        setNDim(_meshCrea->_nDim);
        setElemType(_meshCrea->_eType);
        setBasisFuncType(_meshCrea->_bfType);
        setBasisFuncOrder(_meshCrea->_bfOrder);
        setBasisFuncOrderDir(_meshCrea->_bfOrderX, _meshCrea->_bfOrderY, _meshCrea->_bfOrderZ);
        if (_basisFuncType == BasisFuncType::SubdivSurfs)
            setBasisFuncOrder(2);
        setLinearConstraints(_meshCrea->_linearConstraints);

        if (_meshCrea->_meshType == MeshType::Parallel)
        {
            setLocNElem(_meshCrea->_loc_nElem);
            setNElemDir(_meshCrea->_nEx, _meshCrea->_nEy, _meshCrea->_nEz);
            setLocNPts(_meshCrea->_loc_nPts);

            setGlobWeights(_meshCrea->_weights);
            setGlobKnots(_meshCrea->_uKnot, _meshCrea->_vKnot, _meshCrea->_wKnot);

            setDistConnec(_meshCrea->_connec);
            setDistCoords(_meshCrea->_x_nodes);
            setDistCreases(_meshCrea->_creases);
            setDistElemFlags(_meshCrea->_eflags);
        }
        else if (_meshCrea->_meshType == MeshType::Sequential)
        {
            setNElem(_meshCrea->_nElem);
            setNPts(_meshCrea->_nPts);

            setGlobConnec(_meshCrea->_glob_connec);
            setGlobCoords(_meshCrea->_glob_x_nodes);
            setGlobCreases(_meshCrea->_glob_creases);
            setGlobElemFlags(_meshCrea->_glob_eflags);
        }

        return;
    }

    void DistributedMesh::UpdateBasic()
    {

        // Set number of vertices
        if (_basisFuncType != BasisFuncType::BSplines and _basisFuncType != BasisFuncType::Nurbs)
            _setNVert(computeNVert(_basisFuncType, elemType(), _bfOrder));
        else
            _setNVert(computeNVert(_basisFuncType, elemType(), _bfOrderX, _bfOrderY, _bfOrderZ));
        _pDim = computePDim(elemType());

        // Set connectivity
        if (_myRank == 0 and _verbosity >= Verbosity::High)
            cout << "    Connectivity" << endl;
        if (_connec->loc_nElem() == 0)
        {
            int nElem = _connec->nElem();

            int base_loc_nElem =  nElem / _numProcs;
            int remain_nElem = nElem - base_loc_nElem * _numProcs;
            int locNElem = (_myRank < remain_nElem)?(base_loc_nElem+1):(base_loc_nElem);

            _connec->setLocNElem(locNElem);
        }
        _connec->Update();

        // Set graph
        if (_myRank == 0 and _verbosity >= Verbosity::High)
            cout << "    Graph" << endl;
        if (_graph->loc_nPts() == 0)
        {
            int nPts = _graph->nPts();

            int base_loc_nPts =  nPts / _numProcs;
            int remain_nPts = nPts - base_loc_nPts * _numProcs;
            int locNPts = (_myRank < remain_nPts)?(base_loc_nPts+1):(base_loc_nPts);

            _graph->setLocNPts(locNPts);
        }
        _graph->setConnecStruct(_connec);
        _graph->Update();

        // Set node coordinates
        if (_myRank == 0 and _verbosity >= Verbosity::High)
            cout << "    Node coordinates" << endl;
        if (_tmp_distXnodes != nullptr)
        {
            _nodeData->setBlockMap(_graph->map());
            _nodeData->setNFlds(_nDim);
            _nodeData->setDistFields(_tmp_distXnodes);
            _nodeData->Update();
        }
        else if (_tmp_globXnodes != nullptr)
        {
            _nodeData->setBlockMap(_graph->map());
            _nodeData->setNFlds(_nDim);
            _nodeData->setGlobFields(_tmp_globXnodes);
            _nodeData->Update();
        }
        else
        {
            throw runtime_error("DistributedMesh::Update: The coordinates are not set!!");
        }

        // Set creases
        if (_myRank == 0 and _verbosity >= Verbosity::High)
            cout << "    Creases" << endl;
        if (_tmp_distCreases != nullptr)
        {
            _nodeFlags->setBlockMap(_graph->map());
            _nodeFlags->setNFlds(_nCrease);
            _nodeFlags->setDistFields(_tmp_distCreases);
            _nodeFlags->Update();
        }
        else if (_tmp_globCreases != nullptr)
        {
            _nodeFlags->setBlockMap(_graph->map());
            _nodeFlags->setNFlds(_nCrease);
            _nodeFlags->setGlobFields(_tmp_globCreases);
            _nodeFlags->Update();
        }
        else
        {
            throw runtime_error("DistributedMesh::Update: The creases are not set!!");
        }

        // Init elem flags
        if (_myRank == 0 and _verbosity >= Verbosity::High)
            cout << "    Element flags" << endl;
        if (_tmp_distElemFlags != nullptr)
        {
            Epetra_Map elemMap(-1, _connec->loc_nElem(), 0, epComm());
            _elemFlags->setBlockMap(elemMap);
            _elemFlags->setNFlds(_nEFlags);
            _elemFlags->setDistFields(_tmp_distElemFlags);
            _elemFlags->Update();
        }
        else if (_tmp_globElemFlags != nullptr)
        {
            Epetra_Map elemMap(-1, _connec->loc_nElem(), 0, epComm());
            _elemFlags->setBlockMap(elemMap);
            _elemFlags->setNFlds(_nEFlags);
            _elemFlags->setGlobFields(_tmp_globElemFlags);
            _elemFlags->Update();
        }
        else
        {
            throw runtime_error("DistributedMesh::Update: The element flags are not set!!");
        }

        // Compute ghosts for graph
        if (_myRank == 0 and _verbosity >= Verbosity::High)
            cout << "    Ghosts for graph" << endl;
        UpdateBasicGhosts();

        // Create Adjcy NE
        if (_myRank == 0 and _verbosity >= Verbosity::High)
            cout << "    AdjcyNE" << endl;
        updateAdjcyNE();

        if (_generateCreases)
            generateCreases();

        // Reorder connectivity for subdivision surfaces
        if (_basisFuncType == BasisFuncType::SubdivSurfs)
            _reorderConnecSubdivSurfs();
    }

    void DistributedMesh::UpdateBasicGhosts()
    {
        vector<int> ghCon = _computeGraphGhosts(*_connec);
        _graph->UpdateGhosts(ghCon);
        _nodeFlags->UpdateGhosts(ghCon);
        _nodeData->UpdateGhosts(ghCon);
        _nodeFlags->UpdateGhosts(ghCon);
    }

    void DistributedMesh::UpdateComplete()
    {
        if (_basisFuncType == BasisFuncType::Undefined)
            throw runtime_error("DistributedMesh::UpdateComplete BF not set.");

        // Compute ghosts for graph
        vector<int> ghCon = _computeGraphGhosts(*_connec);
        _graph->UpdateGhosts(ghCon);
        _nodeFlags->UpdateGhosts(ghCon);

        // if (_basisFuncType == BasisFuncType::SubdivSurfs)
        //     _reorderConnecSubdivSurfs();

        // Create Adjcy NE
        _adjcyNE->setGraph(_graph);
        _adjcyNE->setConnec(_connec);
        _adjcyNE->setLocNPts(_graph->loc_nPts());
        _adjcyNE->setNPts(_graph->nPts());

        _adjcyNE->Update();

        vector<int> ghostNE = _computeAjdcyNEGhosts(*_connec);
        _adjcyNE->UpdateGhosts(ghostNE);

        // Compute ghosts for connec
        vector<int> ghosts;
        ghosts = _computeConnecGhosts();
        if (_meshRel == MeshRelation::ImmersedBoundary or _meshRel == MeshRelation::ImmersedMesh)
            _computeImmersedConnecGhosts(ghosts);
        _connec->UpdateGhosts(ghosts);

        // Create Adjcy EN
        _adjcyEN->setBasisFuncType(_basisFuncType);
        _adjcyEN->setBasisFuncOrder(_bfOrder);
        _adjcyEN->setBasisFuncOrderDir(_bfOrderX, _bfOrderY, _bfOrderZ);
        _adjcyEN->setNElemDir(_nElemX, _nElemY, _nElemZ);
        _adjcyEN->setGlobWeights(_weights);
        _adjcyEN->setGlobKnots(_uKnot, _vKnot, _wKnot);
        _adjcyEN->setConnec(_connec);
        _adjcyEN->setAdjcyNE(_adjcyNE);
        _adjcyEN->Update();

        // Recompute ghosts for graph using EN information
        ghosts = _computeGraphGhosts(*_adjcyEN);
        if (_meshRel == MeshRelation::ImmersedBoundary or _meshRel == MeshRelation::ImmersedMesh)
            _computeImmersedGraphGhosts(ghosts);
        _graph->UpdateGhosts(ghosts);


        // Update ghost data
        _nodeData->UpdateGhosts(listGhosts());
        _nodeFlags->UpdateGhosts(listGhosts());

        ghostNE = _computeAjdcyNEGhosts(*_adjcyEN);
        _adjcyNE->UpdateGhosts(ghostNE);

        // Create Adjcy Full NE
        if (_basisFuncType == BasisFuncType::SubdivSurfs)
        {
            _adjcyFullNE->setGraph(_graph);
            _adjcyFullNE->setConnec(_adjcyEN);
            _adjcyFullNE->setLocNPts(_graph->loc_nPts());
            _adjcyFullNE->setNPts(_graph->nPts());

            _adjcyFullNE->Update();
            _adjcyFullNE->UpdateGhosts(ghostNE);
        }
        else
        {
            _adjcyFullNE = _adjcyNE;
        }

        // Create BasisFunctions
        switch(int(_basisFuncType))
        {
            case static_cast<int>(BasisFuncType::GlobConstr):
                _basisFunctions = rcp(new Lagrangian);
                _basisFunctions->setAdjcyEN(_adjcyEN);
                _basisFunctions->Update();
                break;
            case static_cast<int>(BasisFuncType::Linear):
                _bfOrder = 1;
                _basisFunctions = rcp(new Linear);
                _basisFunctions->setAdjcyEN(_adjcyEN);
                _basisFunctions->Update();
                break;
            case static_cast<int>(BasisFuncType::Lagrangian):
                _basisFunctions = rcp(new Lagrangian);
                _basisFunctions->setAdjcyEN(_adjcyEN);
                _basisFunctions->Update();
                break;
            case static_cast<int>(BasisFuncType::BSplines):
                _basisFunctions = rcp(new BSplines);
                _basisFunctions->setAdjcyEN(_adjcyEN);
                _basisFunctions->setElemFlags(_elemFlags);
                _basisFunctions->Update();
                break;
            case static_cast<int>(BasisFuncType::Nurbs):
                _basisFunctions = rcp(new Nurbs);
                _basisFunctions->setAdjcyEN(_adjcyEN);
                _basisFunctions->setElemFlags(_elemFlags);
                _basisFunctions->Update();
                break;
            case static_cast<int>(BasisFuncType::SubdivSurfs):
                _basisFunctions = rcp(new LoopSubdivision);
                _basisFunctions->setAdjcyEN(_adjcyEN);
                _basisFunctions->setNodeFlags(_nodeFlags);
                _basisFunctions->Update();
                break;
            default:
                throw runtime_error("DistributedMesh::UpdateComplete: Not implemented yet.");
        }

        // Update pointer to invert element mapping
        if ((_basisFuncType == BasisFuncType::Lagrangian and elemType() == ElemType::Triang and _bfOrder == 1) or
            (_basisFuncType == BasisFuncType::Linear and elemType() == ElemType::Triang))
            invertElementMapping = &DistributedMesh::_invertElementMapping_LinearTriangle;
        else if ((_basisFuncType == BasisFuncType::Lagrangian or _basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs) and (elemType() == ElemType::Square and _bfOrder == 1))
            invertElementMapping = &DistributedMesh::_invertElementMapping_LinearSquare;
        else if ((_basisFuncType == BasisFuncType::Lagrangian or _basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs) and (elemType() == ElemType::Parallelep and _bfOrder == 1))
            invertElementMapping = &DistributedMesh::_invertElementMapping_LinearParallelep;
        else
            invertElementMapping = &DistributedMesh::_invertElementMapping;

        // Create element locator
        UpdateElementLocator();
    }

    void DistributedMesh::updateAdjcyNE()
    {
        _adjcyNE->setGraph(_graph);
        _adjcyNE->setConnec(_connec);
        _adjcyNE->setLocNPts(_graph->loc_nPts());
        _adjcyNE->setNPts(_graph->nPts());

        _adjcyNE->Update();

        vector<int> ghostNE = _computeAjdcyNEGhosts(*_connec);
        _adjcyNE->UpdateGhosts(ghostNE);
    }

    void DistributedMesh::updateGraph(int locNPts)
    {
        if (locNPts != -1)
            _graph->setLocNPts(locNPts);

        _graph->setConnecStruct(_connec);
        _graph->Update();

        vector<int> ghosts = _computeGraphGhosts(*_graph);
        _graph->UpdateGhosts(ghosts);

    }

    void DistributedMesh::UpdateElementLocator()
    {
        // Update locator
        if (_elLocEngine != ElementLocatorEngine::None)
        {
            // Set default
            if (_elLocEngine == ElementLocatorEngine::Undefined) // <---- FIXME:: Create a default settings function
            {
                if (_myRank == 0)
                {
                    cout << "WARNING: DistributedMesh:: Element locator engine was not set." << endl
                         << "          It will be set to its default value ElementLocatorEngine::BoundingVolumeHierarchy. " << endl
                         << "          This set will be required in future releases." << endl;
                }
                _elLocEngine = ElementLocatorEngine::BoundingVolumeHierarchy;
            }

            // Create
            _elementLocator = Teuchos::null;
            if (_elLocEngine == ElementLocatorEngine::Quadtree)
            {
                _elementLocator = rcp(new QuadtreeElementLocator);
            }
            else if (_elLocEngine == ElementLocatorEngine::Octree)
            {
                _elementLocator = rcp(new OctreeElementLocator);
            }
            else if (_elLocEngine == ElementLocatorEngine::Vtk)
            {
                #ifdef HL_VTK
                _elementLocator = rcp(new vtkElementLocator);
                #else
                throw runtime_error("DistributedMesh::UpdateElementLocator: ElementLocatorEngine::Vtk not available without VTK.");
                #endif
            }
            else if (_elLocEngine == ElementLocatorEngine::BoundingVolumeHierarchy)
            {
                _elementLocator = rcp(new BVHElementLocator);
            }
            else
            {
                throw runtime_error("DistributedMesh::UpdateElementLocator: ElementLocatorEngine not implemented");
            }

            _elementLocator->setDistributedMesh(this);
            _elementLocator->Update();
        }
    }

    void DistributedMesh::setNDim(int ndim)
    {
        if (ndim != 3)
            throw runtime_error("DistributedMesh::setNDim: Wrong number of dimensions.");

        _nDim = ndim;
    }

    void DistributedMesh::setNElemDir(int nelemX, int nelemY, int nelemZ)
    {
        _nElemX = nelemX;
        _nElemY = nelemY;
        _nElemZ = nelemZ;

        _connec->setNElemDir(_nElemX, _nElemY, _nElemZ);
    }

    void DistributedMesh::setGlobCoords(double*& x_nodes)
    {
        if (x_nodes == nullptr)
            throw runtime_error("DistributedMesh::setGlobCoords: Invalid pointer.");

        _tmp_globXnodes = x_nodes;
    }
    void DistributedMesh::setGlobCoords(std::vector<double>& x_nodes)
    {
        if (x_nodes.size() == 0)
            throw runtime_error("DistributedMesh::setGlobCoords: Invalid vector.");

        _tmp_globXnodes = x_nodes.data();
    }

    void DistributedMesh::setGlobCreases(int*& creases)
    {
        if (creases == nullptr)
            throw runtime_error("DistributedMesh::setGlobCreases: Invalid pointer.");

        _tmp_globCreases = creases;
    }
    void DistributedMesh::setGlobCreases(std::vector<int>& creases)
    {
        if (creases.size() == 0)
            throw runtime_error("DistributedMesh::setGlobCreases: Invalid vector.");

        _tmp_globCreases = creases.data();
    }

    void DistributedMesh::setGlobElemFlags(int*& eflags)
    {
        if (eflags == nullptr)
            throw runtime_error("DistributedMesh::setGlobElemFlags: Invalid pointer.");

        _tmp_globElemFlags = eflags;
    }
    void DistributedMesh::setGlobElemFlags(std::vector<int>& eflags)
    {
        if (eflags.size() == 0)
            throw runtime_error("DistributedMesh::setGlobElemFlags: Invalid vector.");

        _tmp_globElemFlags = eflags.data();
    }

    void DistributedMesh::setDistCoords(double*& x_nodes)
    {
        if (x_nodes == nullptr)
            throw runtime_error("DistributedMesh::setDistCoords: Invalid pointer.");

        _tmp_distXnodes = x_nodes;
    }
    void DistributedMesh::setDistCoords(std::vector<double>& x_nodes)
    {
        if (x_nodes.size() == 0)
            throw runtime_error("DistributedMesh::setDistCoords: Invalid vector.");

        _tmp_distXnodes = x_nodes.data();
    }

    void DistributedMesh::setDistCreases(int*& creases)
    {
        if (creases == nullptr)
            throw runtime_error("DistributedMesh::setDistCreases: Invalid pointer.");

        _tmp_distCreases = creases;
    }
    void DistributedMesh::setDistCreases(std::vector<int>& creases)
    {
        if (creases.size() == 0)
            throw runtime_error("DistributedMesh::setDistCreases: Invalid vector.");

        _tmp_distCreases = creases.data();
    }

    void DistributedMesh::setDistElemFlags(int*& eflags)
    {
        if (eflags == nullptr)
            throw runtime_error("DistributedMesh::setDistElemFlags: Invalid pointer.");

        _tmp_distElemFlags = eflags;
    }
    void DistributedMesh::setDistElemFlags(std::vector<int>& eflags)
    {
        if (eflags.size() == 0)
            throw runtime_error("DistributedMesh::setDistElemFlags: Invalid vector.");

        _tmp_distElemFlags = eflags.data();
    }

    double DistributedMesh::nodeCoord(int node, int dim, IndexType idxtype)
    {
        if (dim <0 || dim >= _nDim)
            throw logic_error("DistributedMesh::nodeCoord: The dimension is not valid: " + to_string(dim));

        return _nodeData->getValue(dim, node, idxtype);

    }

    double DistributedMesh::nodeCoord(int node, char coord, IndexType idxtype)
    {
        try
        {
            return nodeCoord(node, (int)(coord - 'x'), idxtype);
        }
        catch(logic_error &e)
        {
            return nodeCoord(node, (int)(coord - 'X'), idxtype);
        }
    }

    int DistributedMesh::nodeCrease(int node, IndexType idxtype)
    {
        return _nodeFlags->getValue(0, node, idxtype);
    }

    int DistributedMesh::nodeMAxis(int node, IndexType idxtype)
    {
        return _nodeFlags->getValue(1, node, idxtype);
    }

    bool DistributedMesh::isNodeInMAxis(MAxis axis, int node, IndexType idxtype)
    {
        int nodeAxis = _nodeFlags->getValue(1, node, idxtype);
        int intAxis = getMAxis(axis);

        return nodeAxis % intAxis == 0;
    }

    vector<double> DistributedMesh::nodeCoords(int node, IndexType idxtype)
    {
        vector<double> coords(3);

        coords[0] = nodeCoord(node, 0, idxtype);
        coords[1] = nodeCoord(node, 1, idxtype);
        coords[2] = nodeCoord(node, 2, idxtype);

        return coords;
    }

    vector<double> DistributedMesh::elemNborNodeCoords(int elem, IndexType idxType)
    {
        // Initialize vector
        int eNN = _adjcyEN->getNumNbors(elem, idxType);
        vector<double> nborCoords(eNN*_nDim);

        // Save coordinates
        vector<int> nbors = _adjcyEN->getNborList(elem, idxType);
        for (int i = 0; i < eNN; i++)
            for (int j = 0; j < _nDim; j++)
                nborCoords[i*_nDim+j] = nodeCoord(nbors[i], j);

        return nborCoords;
    }

    vector<int> DistributedMesh::elemNbors(int elem, IndexType idxType)
    {
        // Initialize
        vector<int> eNbors;

        // Get element neighbors based on node neighbors
        vector<int> nNbor = _connec->getNborList(elem, idxType);
        for (auto n: nNbor)
        {
            vector<int> eNbors_n = _adjcyNE->getNborList(n, IndexType::Global);
            for (auto e: eNbors_n)
                if (_adjcyEN->isItemInPart(e))
                    eNbors.push_back(e);
        }

        // Remove duplicates
        std::sort(eNbors.begin(), eNbors.end());
        eNbors.erase(std::unique(eNbors.begin(), eNbors.end()), eNbors.end());

        return eNbors;
    }

    std::vector<int> DistributedMesh::_computeConnecGhosts()
    {
        set<int> set_ghosts;
        set<int> set_nodesChecked;

        for (int e = 0; e < _connec->loc_nElem(); e++)
        {
            for (int j = 0; j < _connec->nVert(); j++)
            {
                int node = _connec->getNbor(e, j, IndexType::Local);


                if (set_nodesChecked.find(node) != set_nodesChecked.end())
                    continue;

                set_nodesChecked.insert(node);

                try
                {
                    auto vecElemNbors = _adjcyNE->getNborList(node);

                    for (auto elemNbor : vecElemNbors)
                    {
                        bool owned = _connec->isItemInPart(elemNbor);

                        if(owned == false)
                            set_ghosts.insert(elemNbor);
                    }
                }
                catch(runtime_error& err)
                {
                    cout <<  "DistributedMesh::_computeConnecGhosts  "  << _myRank << ":  node: "  << node << "  " << err.what() << endl;
                }
            }

        }

        vector<int> ghosts(set_ghosts.size());
        std::copy(set_ghosts.begin(), set_ghosts.end(), ghosts.begin());

        return ghosts;
    }

    std::vector<int> DistributedMesh::_computeGraphGhosts(AdjcyStruct &adjcy)
    {
        set<int> set_ghosts;

        for (int i = 0; i < adjcy.loc_nItem(); i++)
        {
            auto vecNbors = adjcy.getNborList(i, IndexType::Local);

            for (auto nbor : vecNbors)
            {
                bool owned = _graph->isItemInPart(nbor);

                if (owned == false)
                    set_ghosts.insert(nbor);
            }
        }


        vector<int> ghosts(set_ghosts.size());
        std::copy(set_ghosts.begin(), set_ghosts.end(), ghosts.begin());

        return ghosts;
    }

    void DistributedMesh::_computeImmersedConnecGhosts(std::vector<int>& ghosts)
    {
        //Get the inverse mapping
        RCP<MeshMap_Immersed> tmpParMap = rcp_dynamic_cast<MeshMap_Immersed>(_mapToParent);
        RCP<MeshMap_Immersed> iMap = rcp_dynamic_cast<MeshMap_Immersed>(tmpParMap->generateInverse());

        //Store ghosts
        vector<int> g;
        for (auto it = iMap->_map.begin(); it != iMap->_map.end(); it++)
        {
            if (!_connec->isItemInPart(it->second))
            {
                g.push_back(it->second);
            }
        }

        //Remove duplicates
        sort(g.begin(), g.end());
        g.erase(unique(g.begin(), g.end()), g.end());

        //Add to ghost vector
        for (auto e: g)
            ghosts.push_back(e);
    }

    void DistributedMesh::_computeImmersedGraphGhosts(std::vector<int>& ghosts)
    {
        //Get the inverse mapping
        RCP<MeshMap_Immersed> tmpParMap = rcp_dynamic_cast<MeshMap_Immersed>(_mapToParent);
        RCP<MeshMap_Immersed> iMap = rcp_dynamic_cast<MeshMap_Immersed>(tmpParMap->generateInverse());

        //Store ghosts
        vector<int> g;
        for (auto it = iMap->_map.begin(); it != iMap->_map.end(); it++)
        {
            if (!_connec->isItemInPart(it->second))
            {
                vector<int> nbors = _connec->getNborList(it->second, IndexType::Global);
                for (auto n: nbors)
                {
                    if (!_graph->isItemInfoInPart(n))
                        g.push_back(n);
                }
            }
        }

        //Remove duplicates
        sort(g.begin(), g.end());
        g.erase(unique(g.begin(), g.end()), g.end());

        //Add to ghost vector
        for (auto e: g)
            ghosts.push_back(e);
    }

    std::vector<int> DistributedMesh::_computeAjdcyNEGhosts(AdjcyStruct &adjcy)
    {
        set<int> set_ghosts;

        for (int e = 0; e < adjcy.loc_nItem(); e++)
        {
            int nVert = adjcy.getNumNbors(e, IndexType::Local);

            for (int i = 0; i < nVert; i++)
            {
                int node = adjcy.getNbor(e ,i, IndexType::Local);

                bool owned = _adjcyNE->isItemInPart(node);

                if (owned == false)
                    set_ghosts.insert(node);
            }
        }

        vector<int> ghosts(set_ghosts.size());
        std::copy(set_ghosts.begin(), set_ghosts.end(), ghosts.begin());

        return ghosts;

    }

    std::vector<int> DistributedMesh::_getElementCornerNodes(int e, IndexType idxtype)
    {

        vector<int> corners;
        int last;
        int idx;
        int nvert;

        switch (int(elemType()))
        {
            case static_cast<int>(ElemType::Line):
            {
                corners.resize(2);
                corners[0] = _connec->getNbor(e, 0, idxtype);
                last = _connec->getNumNbors(e, idxtype) - 1;
                corners[1] = _connec->getNbor(e, last, idxtype);

                break;
            }
            case static_cast<int>(ElemType::Triang):
            {
                corners.resize(3);
                corners[0] = _connec->getNbor(e, 0, idxtype);

                if (_basisFuncType == BasisFuncType::SubdivSurfs)
                    corners[1] = _connec->getNbor(e, 1, idxtype);
                else
                    corners[1] = _connec->getNbor(e, _bfOrder, idxtype);

                last = _connec->getNumNbors(e, idxtype) - 1;
                corners[2] = _connec->getNbor(e, last, idxtype);

                break;
            }
            case static_cast<int>(ElemType::Square):
            {

                corners.resize(4);

                int bfOrderX = _bfOrder;

                if (_bfOrderX >= 0 || _bfOrderY >= 0)
                    bfOrderX = _bfOrderX;

                corners[0] = _connec->getNbor(e, 0, idxtype);
                corners[1] = _connec->getNbor(e, bfOrderX, idxtype);

                last = _connec->getNumNbors(e, idxtype) - 1;
                corners[2] = _connec->getNbor(e, last - bfOrderX, idxtype);
                corners[3] = _connec->getNbor(e, last, idxtype);

                break;
            }
            case static_cast<int>(ElemType::Tetrah):
            {
                corners.resize(4);
                corners[0] = _connec->getNbor(e, 0, idxtype);
                corners[1] = _connec->getNbor(e, _bfOrder, idxtype);

                // The base of the Tetrah is the Triang element of the same order, so the third corner is just the last node of the triangle.
                idx = computeNVert(_basisFuncType, ElemType::Triang, _bfOrder) - 1;
                corners[2] = _connec->getNbor(e, idx, idxtype);

                last = _connec->getNumNbors(e, idxtype) - 1;
                corners[3] = _connec->getNbor(e, last, idxtype);

                break;
            }
            case static_cast<int>(ElemType::Parallelep):
            {
                // Resize
                corners.resize(8);

                // Set order
                int bfOrderX = _bfOrder;
                int bfOrderY = _bfOrder;
                if (_bfOrderX >= 0 || _bfOrderY >= 0)
                {
                    bfOrderX = _bfOrderX;
                    bfOrderY = _bfOrderY;
                }

                // Bottom
                corners[0] = _connec->getNbor(e, 0, idxtype);
                corners[1] = _connec->getNbor(e, bfOrderX, idxtype);
                // The base of the Parallelep is the Square element of the same order, so the fourth corner is just the last node of the square.
                nvert = computeNVert(_basisFuncType, ElemType::Square, bfOrderX, bfOrderY);
                corners[2] = _connec->getNbor(e, nvert - 1 - bfOrderX, idxtype);
                corners[3] = _connec->getNbor(e, nvert - 1, idxtype);

                // Top
                last = _connec->getNumNbors(e, idxtype) - 1;
                corners[4] = _connec->getNbor(e, last - nvert + 1, idxtype);
                corners[5] = _connec->getNbor(e, last - nvert + 1 + bfOrderX, idxtype);

                corners[6] = _connec->getNbor(e, last - bfOrderX, idxtype);
                corners[7] = _connec->getNbor(e, last, idxtype);

                break;
            }

            default:
                break;
        }

        return corners;
    }

    std::vector<int> DistributedMesh::_getMeshBoundariesOfElement(int e, IndexType idxtype, vector<MAxis> axes)
    {
        // Get ids of the corner nodes
        auto corners = _getElementCornerNodes(e, idxtype);

        // Get vector of sides for this element
        vector<int> sides;
        if (elemType() == ElemType::Line)
        {
            if (axes.empty())
            {
                int cr0 = nodeCrease(corners[0], IndexType::Global);
                int cr1 = nodeCrease(corners[1], IndexType::Global);

                if (cr0 > 0)            // Xmin
                    sides.push_back(1);
                else if (cr1 > 0)       // Xmax
                    sides.push_back(2);
            }
            else
            {
                int axis0 = nodeMAxis(corners[0], IndexType::Global);
                int axis1 = nodeMAxis(corners[1], IndexType::Global);

                for (auto ax: axes)
                {
                    int iax = getMAxis(ax);

                    if (axis0%iax == 0)      // Xmin
                        sides.push_back(1);
                    if (axis1%iax == 0)      // Xmax
                        sides.push_back(2);
                }
            }
        }
        else if (elemType() == ElemType::Triang)
        {
            if (axes.empty())
            {
                int cr0 = nodeCrease(corners[0], IndexType::Global);
                int cr1 = nodeCrease(corners[1], IndexType::Global);
                int cr2 = nodeCrease(corners[2], IndexType::Global);

                if (cr0 > 0 and cr1 > 0 and cr2 > 0)
                    throw runtime_error("DistributedMesh::getElementVectorOfSides: the triangle " + to_string(e) + " has 3 creases!");
                else if (cr0 > 0 and cr1 > 0) // y == 0
                    sides.push_back(1);
                else if (cr1 > 0 and cr2 > 0) // Tilted line
                    sides.push_back(2);
                else if (cr2 > 0 and cr0 > 0) // x == 0
                    sides.push_back(3);
            }
            else
            {
                int axis0 = nodeMAxis(corners[0], IndexType::Global);
                int axis1 = nodeMAxis(corners[1], IndexType::Global);
                int axis2 = nodeMAxis(corners[2], IndexType::Global);

                for (auto ax: axes)
                {
                    int iax = getMAxis(ax);

                    if (axis0%iax == 0 and axis1%iax == 0)
                        sides.push_back(1);
                    if (axis1%iax == 0 and axis2%iax == 0)
                        sides.push_back(2);
                    if (axis2%iax == 0 and axis0%iax == 0)
                        sides.push_back(3);
                }

            }
        }
        else if (elemType() == ElemType::Square)
        {
            if (axes.empty())
            {
                int cr0 = nodeCrease(corners[0], IndexType::Global);
                int cr1 = nodeCrease(corners[1], IndexType::Global);
                int cr2 = nodeCrease(corners[2], IndexType::Global);
                int cr3 = nodeCrease(corners[3], IndexType::Global);

                if (cr0 > 0 and cr1 > 0) //Ymin
                    sides.push_back(1);
                if (cr1 > 0 and cr3 > 0) //Xmax
                    sides.push_back(2);
                if (cr3 > 0 and cr2 > 0) //Ymax
                    sides.push_back(3);
                if (cr2 > 0 and cr0 > 0) //Xmin
                    sides.push_back(4);
            }
            else
            {
                int axis0 = nodeMAxis(corners[0], IndexType::Global);
                int axis1 = nodeMAxis(corners[1], IndexType::Global);
                int axis2 = nodeMAxis(corners[2], IndexType::Global);
                int axis3 = nodeMAxis(corners[3], IndexType::Global);

                for (auto ax: axes)
                {
                    int iax = getMAxis(ax);

                    if (axis0%iax == 0 and axis1%iax == 0) //Ymin
                        sides.push_back(1);
                    if (axis1%iax == 0 and axis3%iax == 0) //Xmax
                        sides.push_back(2);
                    if (axis3%iax == 0 and axis2%iax == 0) //Ymax
                        sides.push_back(3);
                    if (axis2%iax == 0 and axis0%iax == 0) //Xmin
                        sides.push_back(4);
                }
            }
        }
        else if (elemType() == ElemType::Tetrah)
        {
            if (axes.empty())
            {
                int cr0 = nodeCrease(corners[0], IndexType::Global);
                int cr1 = nodeCrease(corners[1], IndexType::Global);
                int cr2 = nodeCrease(corners[2], IndexType::Global);
                int cr3 = nodeCrease(corners[3], IndexType::Global);

                if (cr0 > 0 and cr1 > 0 and cr2 > 0) // z == 0
                    sides.push_back(1);
                if (cr0 > 0 and cr1 > 0 and cr3 > 0) // y == 0
                    sides.push_back(2);
                if (cr1 > 0 and cr2 > 0 and cr3 > 0) // Tilted plane
                    sides.push_back(3);
                if (cr2 > 0 and cr0 > 0 and cr3 > 0) // x == 0
                    sides.push_back(4);
            }
            else
            {
                int axis0 = nodeMAxis(corners[0], IndexType::Global);
                int axis1 = nodeMAxis(corners[1], IndexType::Global);
                int axis2 = nodeMAxis(corners[2], IndexType::Global);
                int axis3 = nodeMAxis(corners[3], IndexType::Global);

                for (auto ax: axes)
                {
                    int iax = getMAxis(ax);

                    if (axis0%iax == 0 and axis1%iax == 0 and axis2%iax == 0)
                        sides.push_back(1);
                    if (axis0%iax == 0 and axis1%iax == 0 and axis3%iax == 0)
                        sides.push_back(2);
                    if (axis1%iax == 0 and axis2%iax == 0 and axis3%iax == 0)
                        sides.push_back(3);
                    if (axis2%iax == 0 and axis0%iax == 0 and axis3%iax == 0)
                        sides.push_back(4);

                }
            }
        }
        else if (elemType() == ElemType::Parallelep)
        {
            if (axes.empty())
            {
                int cr0 = nodeCrease(corners[0], IndexType::Global);
                int cr1 = nodeCrease(corners[1], IndexType::Global);
                int cr2 = nodeCrease(corners[2], IndexType::Global);
                int cr3 = nodeCrease(corners[3], IndexType::Global);
                int cr4 = nodeCrease(corners[4], IndexType::Global);
                int cr5 = nodeCrease(corners[5], IndexType::Global);
                int cr6 = nodeCrease(corners[6], IndexType::Global);
                int cr7 = nodeCrease(corners[7], IndexType::Global);

                if (cr0 > 0 and cr1 > 0 and cr2 > 0 and cr3 > 0) //Zmin
                    sides.push_back(1);
                if (cr0 > 0 and cr1 > 0 and cr4 > 0 and cr5 > 0) //Ymin
                    sides.push_back(2);
                if (cr0 > 0 and cr2 > 0 and cr4 > 0 and cr6 > 0) //Xmin
                    sides.push_back(3);
                if (cr2 > 0 and cr3 > 0 and cr6 > 0 and cr7 > 0) //Ymax
                    sides.push_back(4);
                if (cr1 > 0 and cr3 > 0 and cr5 > 0 and cr7 > 0) //Xmax
                    sides.push_back(5);
                if (cr4 > 0 and cr5 > 0 and cr6 > 0 and cr7 > 0) //Zmax
                    sides.push_back(6);
            }
            else
            {

                int axis0 = nodeMAxis(corners[0], IndexType::Global);
                int axis1 = nodeMAxis(corners[1], IndexType::Global);
                int axis2 = nodeMAxis(corners[2], IndexType::Global);
                int axis3 = nodeMAxis(corners[3], IndexType::Global);
                int axis4 = nodeMAxis(corners[4], IndexType::Global);
                int axis5 = nodeMAxis(corners[5], IndexType::Global);
                int axis6 = nodeMAxis(corners[6], IndexType::Global);
                int axis7 = nodeMAxis(corners[7], IndexType::Global);

                for (auto ax: axes)
                {
                    int iax = getMAxis(ax);
                    if (axis0%iax == 0 and axis1%iax == 0 and axis2%iax == 0 and axis3%iax == 0) //Zmin
                        sides.push_back(1);
                    if (axis0%iax == 0 and axis1%iax == 0 and axis4%iax == 0 and axis5%iax == 0) //Ymin
                        sides.push_back(2);
                    if (axis0%iax == 0 and axis2%iax == 0 and axis4%iax == 0 and axis6%iax == 0) //Xmin
                        sides.push_back(3);
                    if (axis2%iax == 0 and axis3%iax == 0 and axis6%iax == 0 and axis7%iax == 0) //Ymax
                        sides.push_back(4);
                    if (axis1%iax == 0 and axis3%iax == 0 and axis5%iax == 0 and axis7%iax == 0) //Xmax
                        sides.push_back(5);
                    if (axis4%iax == 0 and axis5%iax == 0 and axis6%iax == 0 and axis7%iax == 0) //Zmax
                        sides.push_back(6);
                }
            }
        }
        else
        {
            throw runtime_error("DistributedMesh::getElementVectorOfSides: Element " + str(elemType()) + " not programmed!");
        }

        return sides;
    }

    int DistributedMesh::_newElementIndex(int oldIdx)
    {
        if (_balanceMesh == true)
            return _elemBalMap->getNewIndex(oldIdx);
        else
            return oldIdx;
    }

    int DistributedMesh::_oldElementIndex(int newIdx)
    {
        if (_balanceMesh == true)
            return _elemBalMap->getOldIndex(newIdx);
        else
            return newIdx;
    }

    void DistributedMesh::BalanceDistMesh()
    {
        // Set timer
        vector<string> timerTags = {"Generate elem map",
                                    "Redistribute elements",
                                    "Generate node map",
                                    "Redistribute nodes",
                                    "Relabel connectivity"};
        if (_meshRel == MeshRelation::hRefin)
            timerTags.emplace_back("h-Refin compatible");
        else if (_meshRel == MeshRelation::ImmersedBoundary or _meshRel == MeshRelation::ImmersedMesh)
            timerTags.emplace_back("Redistribute par map");
        Timer timer(timerTags);

        // Output information
        if (myRank() == 0 and _verbosity >= Verbosity::Medium)
        {
            cout << "***********************************************************************" << endl;
            cout << "******************           BALANCE MESH            ******************" << endl;
        }

        // Generate element balance map
        if (myRank() == 0 and _verbosity >= Verbosity::Extreme)
            cout << "    elemLoadBalance" << endl;
        timer.start(timerTags[0]);
        if (_extElemBalMap == Teuchos::null && _meshRel == MeshRelation::None)
        {
            _elemBalMap = LoadBalance::elemLoadBalance(this, _imbalancedTol);
        }
        else if (_extElemBalMap != Teuchos::null && _meshRel == MeshRelation::None)
        {
            _elemBalMap = _extElemBalMap;
        }
        else if (_meshRel == MeshRelation::hRefin)
        {
            if (_hRefLevel == 0)
            {
                _elemBalMap = _parentMesh->elemBalanceMap();
            }
            else
            {
                auto hRefinParMap = rcp_dynamic_cast<MeshMap_Macro>(_mapToParent);
                _elemBalMap = LoadBalance::elemLoadBalance_HRefin(_parentMesh->elemBalanceMap(), hRefinParMap);
            }
        }
        else if (_meshRel == MeshRelation::pRefin)
        {
            _elemBalMap = _parentMesh->elemBalanceMap();
        }
        else if (_meshRel == MeshRelation::GlobConstr)
        {
            _elemBalMap = _parentMesh->elemBalanceMap();
        }
        else if (_meshRel == MeshRelation::Boundary)
        {
            throw runtime_error("Remove everything related to the boundary.");
            auto bndryParMap = rcp_dynamic_cast<MeshMap_Boundary>(_mapToParent);
            _elemBalMap = LoadBalance::elemLoadBalance_Boundary(_parentMesh->elemBalanceMap(), bndryParMap);
            _mapToParent = rcp_dynamic_cast<MeshMap>(bndryParMap);
        }
        else if (_meshRel == MeshRelation::ImmersedBoundary)
        {
            auto immParMap = rcp_dynamic_cast<MeshMap_Immersed>(_mapToParent);
            _elemBalMap = LoadBalance::elemLoadBalance_Immersed(_parentMesh->elemBalanceMap(), immParMap);
            _mapToParent = rcp_dynamic_cast<MeshMap>(immParMap);
        }
        else if (_meshRel == MeshRelation::ImmersedMesh)
        {
            // Balance mapToParent, but use the a standard elemBalMap //FIXME
            auto immParMap = rcp_dynamic_cast<MeshMap_Immersed>(_mapToParent);
            _elemBalMap = LoadBalance::elemLoadBalance_Immersed(_parentMesh->elemBalanceMap(), immParMap);
            _mapToParent = rcp_dynamic_cast<MeshMap>(immParMap);

            // Use standard balance
            _elemBalMap = LoadBalance::elemLoadBalance(this, _imbalancedTol);
        }
        timer.end(timerTags[0]);

        // Redistribute elements
        if (myRank() == 0 and _verbosity >= Verbosity::Extreme)
            cout << "    Redistribute elements" << endl;
        timer.start(timerTags[1]);
        LoadBalance::redistributeElems(this, _elemBalMap);
        timer.end(timerTags[1]);

        // Generate node balance map
        if (myRank() == 0 and _verbosity >= Verbosity::Extreme)
            cout << "    Generate node balance map" << endl;
        timer.start(timerTags[2]);
        this->updateAdjcyNE();
        _nodeBalMap = LoadBalance::nodeLoadBalance(this);
        timer.end(timerTags[2]);

        // Redistribute nodes
        if (myRank() == 0 and _verbosity >= Verbosity::Extreme)
            cout << "    Redistribute nodes" << endl;
        timer.start(timerTags[3]);
        LoadBalance::redistributeNodes(this, _nodeBalMap);
        LoadBalance::redistributeLinearConstraints(this, _nodeBalMap);
        timer.end(timerTags[3]);

        // Relabel connectivity
        if (myRank() == 0 and _verbosity >= Verbosity::Extreme)
            cout << "    Relabel connectivity" << endl;
        timer.start(timerTags[4]);
        LoadBalance::relabelConnectivity(this, _nodeBalMap);
        this->updateGraph(_nodeBalMap->newLocNItem());
        timer.end(timerTags[4]);

        // Update ghost information of the new balance mesh
        if (myRank() == 0 and _verbosity >= Verbosity::Extreme)
            cout << "    UpdateBasicGhosts" << endl;
        UpdateBasicGhosts();

        // Make connectivities compatible for macro elements
        if (_meshRel == MeshRelation::hRefin)
        {
            timer.start(timerTags[5]);
            LoadBalance::macroElemCompatible(this);
            this->updateGraph(_nodeBalMap->newLocNItem());
            timer.end(timerTags[5]);
        }

        // Redistribute immersed mapping
        if (_meshRel == MeshRelation::ImmersedBoundary or _meshRel == MeshRelation::ImmersedMesh)
        {
            timer.start(timerTags[5]);
            auto immParMap = rcp_dynamic_cast<MeshMap_Immersed>(_mapToParent);
            LoadBalance::redistributeMapToParent_Immersed(this, _elemBalMap, immParMap);
            _mapToParent = rcp_dynamic_cast<MeshMap>(immParMap);
            timer.start(timerTags[5]);
        }


        // Output information
        if (_verbosity >= Verbosity::Medium)
            timer.printTiming(false);
        if (_verbosity >= Verbosity::High)
        {
            for (int p = 0; p < numProcs(); p++)
            {
                if (p == myRank())
                {
                    if (myRank() == 0)
                    {
                        cout << "***********************************************************************" << endl;
                        cout << "*** Partition Imbalance" << endl;
                        cout << "       Rank\tlocPts\tRatio\tDeviation Average" << endl;
                    }


                    cout << "       " << myRank() << "\t";
                    cout  << loc_nPts()   << "\t";
                    cout << setprecision(4) << std::fixed << loc_nPts() / double(nPts()) << "\t";
                    cout << setprecision(2) << std::scientific << loc_nPts() / double(nPts()) - 1.0/numProcs() << "\t";
                    cout  << loc_nElem()   << "\t";
                    cout << setprecision(4) << std::fixed << loc_nElem() / double(nElem()) << "\t";
                    cout << setprecision(2) << std::scientific << loc_nElem() / double(nElem()) - 1.0/numProcs() << "\t";
                    cout << endl;

                    if (myRank() == numProcs()-1)
                        cout << "***********************************************************************" << endl;

                }

                Barrier();
            }
        }
    }

    void DistributedMesh::setBoundaryMesh(MAxis ax)
    {
        vector<MAxis> vMAx = {ax};
        setBoundaryMesh(vMAx);
    }

    void DistributedMesh::setBoundaryMesh(std::vector<MAxis> vMAx)
    {
        //Check MAxis repetition
        map<int,int> dup;
        for_each(vMAx.begin(), vMAx.end(), [&dup](MAxis val){dup[static_cast<int>(val)]++;});
        for(auto p : dup)
        {
            if (p.second > 1)
                throw runtime_error("DistributedMesh: MAxis label repetition while setting the boundary mesh. Please remove one.");
        }

        //Set
        int l = vMAx.size();
        _vMAx.resize(l);
        _vMAx = vMAx;
    }

    bool DistributedMesh::hasBorder()
    {
        int loc_crease = 0;
        int glo_crease = 0;
        for (int i = 0; i < loc_nPts(); i++)
        {
            if ( nodeCrease(i,IndexType::Local) > 0 and nodeCoord(i, 1, IndexType::Local) > 0 )
                loc_crease = 1;
        }
        MPI_Allreduce(&loc_crease, &glo_crease, 1, MPI_INT, MPI_MAX, _comm);

        return static_cast<bool>(glo_crease);
    }

    void DistributedMesh::_allGatherMesh(vector<int>& _globConnec, vector<double>& x_nodes)
    {
        //FIXME:: This function has to be commented and probably optimized
        //FIXME:: Through a big warning to discourage its use
        int eNN=nVert();
        auto adjcyEN = _adjcyEN;
        int nDim = _nDim;
        int nodeIdx{};
        int elemIdx{};
        int begin_row{};
        int maxSize{};
        std::vector<int> nodeID;
        //Get connectivity and nodal coordinates for serial case
        std::vector<std::vector<int>> GlobalNodeData;
        std::vector<std::vector<int>> GlobalElemData;
        GlobalElemData.resize(_adjcyEN->nElem());
        GlobalNodeData.resize(nPts());
        int recvCount[_numProcs];
        int globDisp[_numProcs];
        int disp_v[_numProcs];
        globDisp[_myRank] = loc_nElem();


        for (int i = 0; i < _numProcs; i++)
        {
            recvCount[i] = 1;
            disp_v[i] = i;
        }

        MPI_Allgatherv(&globDisp[_myRank], 1 , MPI_INT, &globDisp[0], recvCount, disp_v, MPI_INT, MPI_COMM_WORLD);

        maxSize = globDisp[0];

        for (int i = 0; i < _numProcs; i++)
        {
            if (maxSize < globDisp[i])
                maxSize=globDisp[i];
        }

        int recv[_numProcs*maxSize];
        recv[0] = 0;

        for (int i = 1; i < _numProcs; i++)
            recv[i] = i*maxSize;

        int recvCount_node[_numProcs];
        int globDisp_node[_numProcs];
        int disp_v_node[_numProcs];
        globDisp_node[_myRank] = loc_nPts();

        for (int i = 0; i < _numProcs; i++)
        {
            recvCount_node[i]=1;
            disp_v_node[i]=i;
        }

        MPI_Allgatherv(&globDisp_node[_myRank], 1 , MPI_INT, &globDisp_node[0], recvCount_node, disp_v_node, MPI_INT, MPI_COMM_WORLD);


        int maxSize_node = globDisp_node[0];
        for (int i = 0; i < _numProcs; i++)
        {
            if (maxSize_node<globDisp_node[i])
                maxSize_node=globDisp_node[i];
        }

        int recv_node[_numProcs*maxSize];
        recv_node[0]=0;
        for (int i=1; i<_numProcs;i++)
            recv_node[i]=i*maxSize_node;


        int globConnect[maxSize*_numProcs][eNN];
        int nodeId[maxSize_node*_numProcs];
        double nodeCoords[maxSize_node*_numProcs][3];


        for (int i=0;i<maxSize*_numProcs;i++)
        {
            for (int eNN_idx=0;eNN_idx<3;eNN_idx++)
            {
                globConnect[i][eNN_idx] = -1;
            }
        }


        for (int coord_idx=0;coord_idx<3;coord_idx++)
        {
            for (int i = 0; i < maxSize_node * _numProcs; i++)
                nodeCoords[i][coord_idx] = 0.;

        }

        for (int i=0;i<maxSize_node*_numProcs;i++)
            nodeId[i]=-1;


        for (int i = 0; i < loc_nPts(); i++)
        {
            int localToGlobalId = _adjcyNE->globIdx(i);

            double x = nodeCoord(i, 0, IndexType::Local);
            double y = nodeCoord(i, 1, IndexType::Local);
            double z = nodeCoord(i, 2, IndexType::Local);

            nodeId[_myRank * maxSize_node + i] = localToGlobalId;
            nodeCoords[_myRank * maxSize_node + i][0] =  x;
            nodeCoords[_myRank * maxSize_node + i][1] =  y;
            nodeCoords[_myRank * maxSize_node + i][2] =  z;

        }

        for (int loc_elem = 0; loc_elem < loc_nElem(); loc_elem++)
        {
            vector<int> nborNodes = _connec->getNborList(loc_elem, IndexType::Local);

            for (size_t eNN_idx=0;eNN_idx<nborNodes.size();eNN_idx++)
            {
                globConnect[_myRank * maxSize + loc_elem][eNN_idx] = nborNodes[eNN_idx];
            }
        }


        begin_row = _myRank * maxSize;
        int _connect[maxSize*_numProcs];

        for (int i = 0 ;i<maxSize*_numProcs;i++)
            _connect[i]=-1;


        double _nodeCoords[maxSize_node*_numProcs];
        for (int i = 0 ;i<maxSize_node*_numProcs;i++)
            _nodeCoords[i]=0.;


        for (int eNN_idx=0;eNN_idx<eNN;eNN_idx++)
        {
            for (int array_idx = 0; array_idx < _numProcs * maxSize; array_idx++)
                _connect[array_idx] = globConnect[array_idx][eNN_idx];

            MPI_Allgatherv(&_connect[begin_row], globDisp[_myRank], MPI_INT, &_connect[0], globDisp, recv, MPI_INT, MPI_COMM_WORLD);

            for (int array_idx = 0; array_idx < _numProcs * maxSize; array_idx++)
                globConnect[array_idx][eNN_idx]=  _connect[array_idx];
        }

        begin_row =_myRank* maxSize_node;

        MPI_Allgatherv(&nodeId[begin_row], globDisp_node[_myRank], MPI_INT, &nodeId[0], globDisp_node, recv_node, MPI_INT, MPI_COMM_WORLD);


        for (int coord_idx=0;coord_idx<3;coord_idx++)
        {
            for (int array_idx = 0; array_idx < _numProcs * maxSize_node; array_idx++)
                _nodeCoords[array_idx] = nodeCoords[array_idx][coord_idx];

            MPI_Allgatherv(&_nodeCoords[begin_row], globDisp_node[_myRank], MPI_DOUBLE, &_nodeCoords[0], globDisp_node, recv_node, MPI_DOUBLE, MPI_COMM_WORLD);

            for (int array_idx = 0; array_idx < _numProcs * maxSize_node; array_idx++)
                nodeCoords[array_idx][coord_idx]=  _nodeCoords[array_idx];
        }

        nodeID.resize(nPts());
        x_nodes.resize(nPts()*nDim);
        _globConnec.resize(nVert()*nElem());


        for (int i = 0; i < _numProcs*maxSize_node; i++)
        {
            if (nodeId[i] > 0 or nodeId[i] == 0)
            {
                nodeID[nodeIdx]            = nodeId[i];
                x_nodes[nDim* nodeIdx + 0] = nodeCoords[i][0];
                x_nodes[nDim* nodeIdx + 1] = nodeCoords[i][1];
                x_nodes[nDim* nodeIdx + 2] = nodeCoords[i][2];
                nodeIdx++;
            }
        }

        elemIdx=0;
        for (int i = 0;i < _numProcs*maxSize; i++)
        {
            if (globConnect[i][0] > 0 or globConnect[i][0] == 0)
            {
                for (int k=0;k<eNN;k++)
                    _globConnec[nVert() * elemIdx + k] = globConnect[i][k];
                elemIdx++;
            }
        }
    }

    void DistributedMesh::_communicateGhostCreases(const std::vector<int>& edges)
    {
        int localSize = static_cast<int>(edges.size());
        std::vector<int> sizePerProc(numProcs());
        MPI_Allgather(&localSize, 1, MPI_INT, sizePerProc.data(), 1, MPI_INT, MPI_COMM_WORLD);
        int totalSize = std::accumulate(sizePerProc.begin(), sizePerProc.end(), 0);

        std::vector<int> displacements(numProcs());
        int displacement = 0;
        for (int i = 0; i < numProcs(); ++i)
        {
            displacements[i] = displacement;
            displacement += sizePerProc[i];
        }

        std::vector<int> recv_buffer(totalSize);
        MPI_Allgatherv(edges.data(), localSize, MPI_INT,
                       recv_buffer.data(), sizePerProc.data(), displacements.data(),
                       MPI_INT, comm());

        for (int node : recv_buffer)
        {
            if (_nodeFlags->isItemInPart(node))
                _nodeFlags->setValue(0, node, IndexType::Global, 1);
        }
    }

    bool DistributedMesh::_checkIfEdgeIsInBorder(const std::array<int, 2>& edge) const
    {
        std::vector<int> elemNbors0 = _adjcyNE->getNborList(edge[0], IndexType::Global);
        std::vector<int> elemNbors1 = _adjcyNE->getNborList(edge[1], IndexType::Global);

        std::sort(elemNbors0.begin(), elemNbors0.end());
        std::sort(elemNbors1.begin(), elemNbors1.end());

        // Find the intersection
        std::vector<int> intersection;
        std::set_intersection(elemNbors0.begin(), elemNbors0.end(),
                              elemNbors1.begin(), elemNbors1.end(),
                              std::back_inserter(intersection));

        return intersection.size() == 1;
    }

    void DistributedMesh::generateCreases()
    {
        if (computePDim(elemType()) != 2)
            throw runtime_error("DistributedMesh::generateCreases: error! creases can only be generated for 2D meshes.");

        std::set<int> ghostsEdges;
        for (int i = 0; i < loc_nElem(); i++)
        {
            std::vector<int>& nbors = _connec->getNborList(i,IndexType::Local);
            std::vector<std::array<int, 2>> edges{};

            if (elemType() == ElemType::Triang)
                edges = {{nbors[0], nbors[1]}, {nbors[1], nbors[2]}, {nbors[2], nbors[0]}};
            else if (elemType() == ElemType::Square)
                edges = {{nbors[0], nbors[1]}, {nbors[0], nbors[2]}, {nbors[1], nbors[3]}, {nbors[2], nbors[3]}};

            for (auto edge: edges)
            {
                const bool isEdge = _checkIfEdgeIsInBorder(edge);
                if (isEdge)
                {
                    if (_nodeFlags->isItemInPart(edge[0]))
                        _nodeFlags->setValue(0, edge[0], IndexType::Global, 1);
                    else
                        ghostsEdges.insert(edge[0]);
                    if (_nodeFlags->isItemInPart(edge[1]))
                        _nodeFlags->setValue(0, edge[1], IndexType::Global, 1);
                    else
                        ghostsEdges.insert(edge[0]);
                }
            }
        }

        _communicateGhostCreases(std::vector<int>(ghostsEdges.begin(), ghostsEdges.end()));

        _nodeFlags->UpdateGhosts();
    }

    void DistributedMesh::_printMap2ChildForDebugging()
    {
          // Get the mapping
        RCP<MeshMap_Immersed> tmpParMap  = rcp_dynamic_cast<MeshMap_Immersed>(_childMesh->_mapToParent);
        RCP<MeshMap_Immersed> mapToChild = rcp_dynamic_cast<MeshMap_Immersed>(tmpParMap->generateInverse());

        for (size_t k = 0; k < mapToChild->_keys.size(); k++)
        {
            cout << _myRank << ":: " << mapToChild->_keys[k] + offs_nElem() << "->" << mapToChild->_vals[k]  << " " << _elemFlags->getValue(1, mapToChild->_keys[k], IndexType::Local) << endl;
        }
    }
}
