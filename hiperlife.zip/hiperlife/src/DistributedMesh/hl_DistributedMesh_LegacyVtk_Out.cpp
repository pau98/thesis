/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>

#include <mpi.h>

#include "hl_DistributedMesh.h"
#include "hl_TypeDefs.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    int DistributedMesh::_printFileLegacyVtk(string file_prefix, vector<Epetra_MultiVector*> vecData, vector<vector<string>> vecNames)
    {
        //Initialize
        ofstream file_mesh;
        string file_name{file_prefix}, ext{"vtk"}, tmpext{""};
        size_t i = file_prefix.rfind('.', file_prefix.length());
        if (i != string::npos)
            tmpext = (file_prefix.substr(i+1, file_prefix.length() - i));
        if (tmpext != ext)
            file_name = file_prefix + ".vtk";

        // Create file and write header
        if (_myRank == 0)
        {
            file_mesh.open(file_name, std::ofstream::trunc);

            file_mesh << "# vtk DataFile Version 4.0" << endl;
            file_mesh << "vtk output" << endl;
            file_mesh << "ASCII" << endl;
            file_mesh << "DATASET UNSTRUCTURED_GRID" << endl;

            file_mesh.close();
        }

        //Write node coordinates
        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                //Open
                file_mesh.open(file_name, std::ofstream::app);
                file_mesh << scientific << setprecision(15);

                //Write header
                if (_myRank == 0)
                {
                    file_mesh << endl;
                    file_mesh << "POINTS " << nPts() << " float" << endl;
                }

                //Write coordinates
                for (int i = 0; i < loc_nPts(); i++)
                {
                    file_mesh << nodeCoord(i, 'x', IndexType::Local) << " ";
                    file_mesh << nodeCoord(i, 'y', IndexType::Local) << " ";
                    file_mesh << nodeCoord(i, 'z', IndexType::Local) << " ";
                    file_mesh << endl;
                }

                //Close
                file_mesh.close();
            }
            Barrier();
        }

        //Write cell data (connectivity, type, partitions and elemAuxF)
        if ((_basisFuncType == BasisFuncType::Lagrangian) and (elemType() != ElemType::Tetrah))
        {
            //Create vector with the ordering of the connectivity
            vector<int> reorder = vtkReordering(elemType(), _basisFuncType, _bfOrder);

            //CELLS (connectivity)
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    //Open file
                    file_mesh.open(file_name, std::ofstream::app);

                    //Write header
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELLS " << nElem() << " " << nElem() * (nVert() + 1) << endl;
                    }

                    //Write connectivity
                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        vector<int> myNbor(nVert());
                        myNbor= _connec->getNborList(e, IndexType::Local);
                        file_mesh << nVert() << " ";
                        for (int m = 0; m < int(myNbor.size()); m++)
                        {
                            file_mesh << myNbor[reorder[m]] << " ";
                        }
                        file_mesh << endl;
                    }

                    //Close
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL TYPES
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    //Open file
                    file_mesh.open(file_name, std::ofstream::app);

                    //Write headers
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_TYPES " << nElem() << endl;
                    }

                    //Write element type
                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        file_mesh << hlToVtkElemType(elemType(), _basisFuncType, _bfOrder) << endl;
                    }

                    //Close file
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (partitions)
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    //Open file
                    file_mesh.open(file_name, std::ofstream::app);

                    //Write header
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_DATA " << nElem() << endl;
                        file_mesh << "SCALARS Partition int" << endl;
                        file_mesh << "LOOKUP_TABLE default" << endl;
                    }

                    //Write rank
                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        file_mesh << _myRank << endl;
                    }

                    //Close file
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (elemAuxF)
            if (int(vecData.size()) == 3)
            {
                int f = 2;
                if (vecData[f]!= nullptr)
                {
                    vector<string> names = vecNames[f];
                    for (int d = 0; d < vecData[f]->NumVectors(); d++)
                    {
                        for (int p = 0; p < _numProcs; p++)
                        {
                            if (_myRank == p)
                            {
                                //Open file
                                file_mesh.open(file_name, std::ofstream::app);

                                //Write headers
                                if (_myRank == 0)
                                {
                                    file_mesh << endl;

                                    if (d == 0)
                                    {
                                        file_mesh << "FIELD FieldData " << vecData[f]->NumVectors() << endl;
                                    }
                                    file_mesh << names[d] << "  "  << 1 << "  "  << nElem() << "  " <<  "double" << endl;
                                }


                                //Write rank
                                for (int e = 0; e < loc_nElem(); e++)
                                {
                                    file_mesh << (*vecData[f])[d][e] << endl;
                                }

                                //Close file
                                file_mesh.close();
                            }
                            Barrier();
                        }
                    }
                }
            }

        }
        else if ((_basisFuncType == BasisFuncType::Lagrangian) and ((elemType() == ElemType::Tetrah)))
        {
            int mynVert = 4;
            vector<int> myidx = {0, _bfOrder, ((_bfOrder+1)*(_bfOrder+1)+(_bfOrder+1))/2-1, nVert()-1};
            vector<int> myNbor(mynVert);

            //CELLS (connectivity)
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    file_mesh.open(file_name, std::ofstream::app);
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELLS " << nElem() << " " << nElem() * (mynVert + 1) << endl;
                    }
                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        myNbor = _connec->getNborList(e, IndexType::Local);
                        file_mesh << mynVert << " ";
                        for (int m = 0; m < int(myidx.size()); m++)
                            file_mesh << myNbor[myidx[m]] << " ";
                        file_mesh << endl;
                    }
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL TYPES
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {

                    file_mesh.open(file_name, std::ofstream::app);

                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_TYPES " << nElem() << endl;
                    }
                    for (int e = 0; e < loc_nElem(); e++)
                    {

                        file_mesh << hlToVtkElemType(elemType(), _basisFuncType, 1) << endl;
                    }

                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (partitions)
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {

                    file_mesh.open(file_name, std::ofstream::app);

                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_DATA " << nElem() << endl;
                        file_mesh << "SCALARS Partition int" << endl;
                        file_mesh << "LOOKUP_TABLE default" << endl;
                    }

                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        file_mesh << _myRank << endl;
                    }

                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (elemAuxF)
            if (int(vecData.size()) == 3)
            {
                int f = 2;
                if (vecData[f]!= nullptr)
                {
                    vector<string> names = vecNames[f];
                    for (int d = 0; d < vecData[f]->NumVectors(); d++)
                    {
                        for (int p = 0; p < _numProcs; p++)
                        {
                            if (_myRank == p)
                            {
                                //Open file
                                file_mesh.open(file_name, std::ofstream::app);

                                //Write headers
                                if (_myRank == 0)
                                {
                                    file_mesh << endl;

                                    if (d == 0)
                                    {
                                        file_mesh << "FIELD FieldData " << vecData[f]->NumVectors() << endl;
                                    }
                                    file_mesh << names[d] << "  "  << 1 << "  "  << nElem() << "  " <<  "double" << endl;
                                }


                                //Write rank
                                for (int e = 0; e < loc_nElem(); e++)
                                {
                                    file_mesh << (*vecData[f])[d][e] << endl;
                                }

                                //Close file
                                file_mesh.close();
                            }
                            Barrier();
                        }
                    }
                }
            }

        }
        else if ((_basisFuncType == BasisFuncType::BSplines) || (_basisFuncType == BasisFuncType::Nurbs))
        {
            int mynVert, nElemX{}, nElemY{}, nElemZ{}, mynElem{};
            vector<int> myidx;
            switch(int (elemType()))
            {
                case static_cast<int>(ElemType::Line):
                    mynVert = 2;
                    myidx = {0, 1};
                    nElemX = static_cast<int>(_uKnot.size()) - _bfOrderX*2 - 1;
                    mynElem = nElemX + _bfOrderX - 1;
                    break;
                case static_cast<int>(ElemType::Square):
                    mynVert = 4;
                    myidx = {0, 1, _bfOrderX+2, _bfOrderX+1};
                    nElemX = static_cast<int>(_uKnot.size()) - _bfOrderX*2 - 1;
                    nElemY = static_cast<int>(_vKnot.size()) - _bfOrderY*2 - 1;
                    mynElem = (nElemX+_bfOrderX-1)*(nElemY+_bfOrderY-1);
                    break;
                case static_cast<int>(ElemType::Parallelep):
                    mynVert = 8;
                    myidx = {0, 1, _bfOrderX+2, _bfOrderX+1, (_bfOrderX+1)*(_bfOrderY+1), (_bfOrderX+1)*(_bfOrderY+1)+1, (_bfOrderX+1)*(_bfOrderY+1)+_bfOrderX+2, (_bfOrderX+1)*(_bfOrderY+1)+_bfOrderX+1};
                    nElemX = static_cast<int>(_uKnot.size()) - _bfOrderX*2 - 1;
                    nElemY = static_cast<int>(_vKnot.size()) - _bfOrderY*2 - 1;
                    nElemZ = static_cast<int>(_wKnot.size()) - _bfOrderZ*2 - 1;
                    mynElem = (nElemX+_bfOrderX-1)*(nElemY+_bfOrderY-1)*(nElemZ+_bfOrderZ-1);
                    break;
                default:
                    throw runtime_error("vtk: ElemType not set.");
                    break;
            }

            //CELLS (connectivity)
            int myloc_nElem{};
            vector<int> myNbor(mynVert);
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    file_mesh.open(file_name, std::ofstream::app);
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELLS " << mynElem << " " << mynElem * (mynVert + 1) << endl;
                    }
                    for (int i = 0; i < loc_nElem(); i++)
                    {
                        vector<int> myNbor(mynVert);
                        myNbor = _connec->getNborList(i, IndexType::Local);
                        int elem = _basisFunctions->_elemFlags->getValue(0, i, IndexType::Local);
                        int inex{}, iney{}, inez{};
                        int iimax{1}, jjmax{1}, kkmax{1};
                        switch(int (elemType()))
                        {
                            case static_cast<int>(ElemType::Line):
                                inex = elem % nElemX;
                                if (inex == nElemX-1)
                                    iimax = _bfOrderX;
                                for (int ii = 0; ii < iimax; ii++)
                                {
                                    file_mesh << mynVert << " ";
                                    for (int m = 0; m < int(myidx.size()); m++)
                                        file_mesh << myNbor[ii+myidx[m]] << " ";
                                    file_mesh << endl;
                                    myloc_nElem++;
                                }
                                break;
                            case static_cast<int>(ElemType::Square):
                                inex = elem % nElemX;
                                iney = (int) elem/nElemX;
                                if (inex == nElemX-1)
                                    iimax = _bfOrderX;
                                if (iney == nElemY-1)
                                    jjmax = _bfOrderY;
                                for (int jj = 0; jj < jjmax; jj++)
                                {
                                    for (int ii = 0; ii < iimax; ii++)
                                    {
                                        file_mesh << mynVert << " ";
                                        for (int m = 0; m < int(myidx.size()); m++)
                                            file_mesh << myNbor[jj*(_bfOrderX+1)+ii+myidx[m]] << " ";
                                        file_mesh << endl;
                                        myloc_nElem++;
                                    }
                                }
                                break;
                            case static_cast<int>(ElemType::Parallelep):
                                inex = elem % nElemX;
                                iney = (elem%(nElemX*nElemY))/nElemX;
                                inez = (elem/(nElemX*nElemY));
                                if (inex == nElemX-1)
                                    iimax = _bfOrderX;
                                if (iney == nElemY-1)
                                    jjmax = _bfOrderY;
                                if (inez == nElemZ-1)
                                    kkmax = _bfOrderZ;
                                for (int kk = 0; kk < kkmax; kk++)
                                {
                                    for (int jj = 0; jj < jjmax; jj++)
                                    {
                                        for (int ii = 0; ii < iimax; ii++)
                                        {
                                            file_mesh << mynVert << " ";
                                            for (int m = 0; m < int(myidx.size()); m++)
                                                file_mesh << myNbor[kk*(_bfOrderX+1)*(_bfOrderY+1)+jj*(_bfOrderX+1)+ii+myidx[m]] << " ";
                                            file_mesh << endl;
                                            myloc_nElem++;
                                        }
                                    }
                                }
                                break;
                            default:
                                throw runtime_error("vtk: ElemType not set.");
                                break;
                        }
                    }
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL TYPES
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    file_mesh.open(file_name, std::ofstream::app);
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_TYPES " << mynElem << endl;
                    }
                    for (int e = 0; e < myloc_nElem; e++)
                    {
                        file_mesh << hlToVtkElemType(elemType(), _basisFuncType, 1) << endl;
                    }
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (partitions)
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {

                    file_mesh.open(file_name, std::ofstream::app);
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_DATA " << mynElem << endl;
                        file_mesh << "SCALARS Partition int" << endl;
                        file_mesh << "LOOKUP_TABLE default" << endl;
                    }
                    for (int e = 0; e < myloc_nElem; e++)
                    {
                        file_mesh << _myRank << endl;
                    }

                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (elemAuxF)
            if (int(vecData.size()) == 3 and _bfOrder == 1)
            {
                int f = 2;
                if (vecData[f]!= nullptr)
                {
                    vector<string> names = vecNames[f];
                    for (int d = 0; d < vecData[f]->NumVectors(); d++)
                    {
                        for (int p = 0; p < _numProcs; p++)
                        {
                            if (_myRank == p)
                            {
                                //Open file
                                file_mesh.open(file_name, std::ofstream::app);

                                //Write headers
                                if (_myRank == 0)
                                {
                                    file_mesh << endl;

                                    if (d == 0)
                                    {
                                        file_mesh << "FIELD FieldData " << vecData[f]->NumVectors() << endl;
                                    }
                                    file_mesh << names[d] << "  "  << 1 << "  "  << nElem() << "  " <<  "double" << endl;
                                }


                                //Write rank
                                for (int e = 0; e < myloc_nElem; e++)
                                {
                                    file_mesh << (*vecData[f])[d][e] << endl;
                                }

                                //Close file
                                file_mesh.close();
                            }
                            Barrier();
                        }
                    }
                }
            }

        }
        else //if (_basisFuncType == BasisFuncType::SubdivSurfs)
        {
            //CELLS (connectivity)
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    //Open file
                    file_mesh.open(file_name, std::ofstream::app);

                    //Write header
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELLS " << nElem() << " " << nElem() * (nVert() + 1) << endl;
                    }

                    //Write connectivity
                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        file_mesh << nVert() << " ";
                        for (auto el : _connec->getNborList(e, IndexType::Local))
                            file_mesh << el << " ";
                        file_mesh << endl;
                    }

                    //Close
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL TYPES
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    //Open file
                    file_mesh.open(file_name, std::ofstream::app);

                    //Write headers
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_TYPES " << nElem() << endl;
                    }

                    //Write element type
                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        file_mesh << hlToVtkElemType(elemType(), _basisFuncType, _bfOrder) << endl;
                    }

                    //Close file
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (partitions)
            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    //Open file
                    file_mesh.open(file_name, std::ofstream::app);

                    //Write header
                    if (_myRank == 0)
                    {
                        file_mesh << endl;
                        file_mesh << "CELL_DATA " << nElem() << endl;
                        file_mesh << "SCALARS Partition int" << endl;
                        file_mesh << "LOOKUP_TABLE default" << endl;
                    }

                    //Write rank
                    for (int e = 0; e < loc_nElem(); e++)
                    {
                        file_mesh << _myRank << endl;
                    }

                    //Close file
                    file_mesh.close();
                }
                Barrier();
            }

            //CELL DATA (elemAuxF)
            if (int(vecData.size()) == 3)
            {
                int f = 2;
                if (vecData[f]!= nullptr)
                {
                    vector<string> names = vecNames[f];
                    for (int d = 0; d < vecData[f]->NumVectors(); d++)
                    {
                        for (int p = 0; p < _numProcs; p++)
                        {
                            if (_myRank == p)
                            {
                                //Open file
                                file_mesh.open(file_name, std::ofstream::app);

                                //Write headers
                                if (_myRank == 0)
                                {
                                    file_mesh << endl;

                                    if (d == 0)
                                    {
                                        file_mesh << "FIELD FieldData " << vecData[f]->NumVectors() << endl;
                                    }
                                    file_mesh << names[d] << "  "  << 1 << "  "  << nElem() << "  " <<  "double" << endl;
                                }


                                //Write rank
                                for (int e = 0; e < loc_nElem(); e++)
                                {
                                    file_mesh << (*vecData[f])[d][e] << endl;
                                }

                                //Close file
                                file_mesh.close();
                            }
                            Barrier();
                        }
                    }
                }
            }

        }

        //Write (nodal) partitions
        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                //Open file
                file_mesh.open(file_name, std::ofstream::app);

                //Write header
                if (_myRank == 0)
                {
                    file_mesh << endl;
                    file_mesh << "POINT_DATA " << nPts() << endl;
                    file_mesh << "SCALARS PartitionPts int" << endl;
                    file_mesh << "LOOKUP_TABLE default" << endl;
                }

                //Write rank
                for (int i = 0; i < loc_nPts(); i++)
                {
                    file_mesh << _myRank << endl;
                }

                //Close file
                file_mesh.close();
            }
            Barrier();
        }

        //Write creases
        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                file_mesh.open(file_name, std::ofstream::app);

                //Write header
                if (_myRank == 0)
                {
                    file_mesh << endl;
                    file_mesh << "FIELD FieldData " << 1 << endl;
                    file_mesh << "CreasesId" << "  "  << 1 << "  "  << nPts() << "  " <<  "double" << endl;
                }

                //Write data
                for (int i = 0; i < loc_nPts(); i++)
                {
                    file_mesh << nodeCrease(i, IndexType::Local) << endl;
                }

                //Close file
                file_mesh.close();
            }
            Barrier();
        }

        //Write node fields (nodeDOFs and nodeAuxF)
        for (int f = 0; f < int(vecData.size()) and f < 2; f++ )
        {
            if (vecData[f]!= nullptr)
            {
                vector<string> names = vecNames[f];
                for (int d = 0; d < vecData[f]->NumVectors(); d++)
                {
                    for (int p = 0; p < _numProcs; p++)
                    {
                        if (_myRank == p)
                        {
                            //Open file
                            file_mesh.open(file_name, std::ofstream::app);

                            //Write headers
                            if (_myRank == 0)
                            {
                                file_mesh << endl;

                                if (d == 0)
                                {
                                    file_mesh << "FIELD FieldData " << vecData[f]->NumVectors() << endl;
                                }
                                file_mesh << names[d] << "  "  << 1 << "  "  << nPts() << "  " <<  "double" << endl;
                            }

                            //Write fields
                            for (int i = 0; i < loc_nPts(); i++)
                            {
                                file_mesh << (*vecData[f])[d][i] << endl;
                            }

                            //Close file
                            file_mesh.close();
                        }
                        Barrier();
                    }
                }
            }
        }

        return 0;
    }

    int DistributedMesh::_printFileLegacyCSV(string file_prefix, vector<Epetra_MultiVector*> vecData, vector<vector<string>> vecNames)
    {
        //Initialize
        ofstream file_mesh;
        string file_name{file_prefix}, ext{"csv"}, tmpext{""};
        size_t i = file_prefix.rfind('.', file_prefix.length());
        if (i != string::npos)
            tmpext = (file_prefix.substr(i+1, file_prefix.length() - i));
        if (tmpext != ext)
            file_name = file_prefix + ".csv";

        //Write header
        if (_myRank == 0)
        {
            //Open
            file_mesh.open(file_name, std::ofstream::trunc);
            file_mesh << scientific << setprecision(15);

            //Write
            file_mesh << "x " << "y " << "z";
            for (int f = 0; f < int(vecData.size()); f++ )
            {
                if (vecData[f]!= nullptr)
                {
                    vector<string> names = vecNames[f];
                    for (int d = 0; d < vecData[f]->NumVectors(); d++)
                    {
                        file_mesh << " " << names[d];
                    }
                }
            }
            file_mesh << endl;

            //Close
            file_mesh.close();
        }
        Barrier();

        //Write fields
        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                //Open
                file_mesh.open(file_name, std::ofstream::app);
                file_mesh << scientific << setprecision(15);

                //Write
                for (int i = 0; i < loc_nPts(); i++)
                {
                    file_mesh << nodeCoord(i, 'x', IndexType::Local) << " ";
                    file_mesh << nodeCoord(i, 'y', IndexType::Local) << " ";
                    file_mesh << nodeCoord(i, 'z', IndexType::Local);
                    for (int f = 0; f < int(vecData.size()); f++ )
                    {
                        if (vecData[f]!= nullptr)
                        {
                            vector<string> names = vecNames[f];
                            for (int d = 0; d < vecData[f]->NumVectors(); d++)
                            {
                                file_mesh << " " << (*vecData[f])[d][i];
                            }
                        }

                    }
                    file_mesh << endl;
                }

                //Close
                file_mesh.close();
            }

            Barrier();
        }

        //Reorder file
        if (_myRank == 0)
        {
            stringstream command;
            command << "LC_ALL=C sort -k3g,3 -k2g,2 -k1g,1 -o " << file_name << " " << file_name << endl;
            auto s = system(command.str().c_str());
            (void) s;
        }
        Barrier();

        return 0;
    }

}
