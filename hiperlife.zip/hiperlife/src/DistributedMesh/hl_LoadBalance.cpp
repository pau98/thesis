/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <numeric>

#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>
#include <Isorropia_Epetra.hpp>
#include <Isorropia_EpetraOrderer.hpp>
#include <Isorropia_EpetraPartitioner.hpp>
#include <Isorropia_EpetraRedistributor.hpp>

#include "hl_Timer.h"
#include "hl_Math.h"
#include "hl_ConnecStruct.h"
#include "hl_AdjcyNEStruct.h"
#include "hl_DistributedMesh.h"
#include "hl_LoadBalance.h"
#include "hl_MapBalance.h"
#include "hl_MeshMap_Boundary.h"
#include "hl_MeshMap_Macro.h"


using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;

namespace hiperlife
{
    namespace LoadBalance
    {
        static Epetra_IntVector* computeMapOldToNew(MPI_Comm &comm, Epetra_IntVector &new_to_old, const Epetra_BlockMap &old_map)
        {
            Epetra_IntVector *old_to_new = new Epetra_IntVector(old_map);

            int alloc_points;
            int *p_new_to_old;
            int myRank, numProcs;
            MPI_Comm_rank(comm, &myRank);
            MPI_Comm_size(comm, &numProcs);

            alloc_points = new_to_old.MyLength();
            MPI_Barrier(comm);
            int recBuff = 0;
            MPI_Allreduce(&alloc_points, &recBuff, 1, MPI_INT, MPI_MAX, comm);
            alloc_points = recBuff;

            p_new_to_old = new int[alloc_points];

            for (int p = 0; p < numProcs; p++)
            {
                int p_points = new_to_old.MyLength();
                int p_offset = new_to_old.Map().MinMyGID();

                MPI_Bcast(&p_points, 1, MPI_INT, p, comm);
                MPI_Bcast(&p_offset, 1, MPI_INT, p, comm);


                if (myRank == p)
                {
                    int ERROR = new_to_old.ExtractCopy(p_new_to_old);

                    if (ERROR != 0)
                    {
                        clog << "ERROR!!!  " << __FILE__ << ":" << __LINE__ << "  ->  Extration Copy failed, code: "
                             << ERROR << endl;
                        abort();
                    }

                }

                MPI_Barrier(comm);
                MPI_Bcast(p_new_to_old, p_points, MPI_INT, p, comm);

                for (int i = 0; i < p_points; i++)
                {
                    int n_old = p_new_to_old[i];

                    if (n_old < old_to_new->Map().MinMyGID() || n_old > old_to_new->Map().MaxMyGID())
                        continue;

                    int loc_n_old = old_to_new->Map().LID(n_old);
                    (*old_to_new)[loc_n_old] = i + p_offset;
                }

            }

            delete[] p_new_to_old;

            return old_to_new;
        }

        RCP<Epetra_FECrsGraph> createAdjcyElemElem(RCP<ConnecStruct> connec, RCP<AdjcyNEStruct> adjcyNE)
        {

            int loc_nElem = connec->loc_nElem();

            Epetra_Map vec_map(-1, loc_nElem, 0, connec->epComm());

            RCP<Epetra_FECrsGraph> graph = rcp(new Epetra_FECrsGraph(Copy, vec_map, 10)); // FIXME Careful with the '7'

            int nVert = connec->nVert();

            for (int e = 0; e < connec->loc_nElem(); e++)
            {
                int eGl = e + connec->offs_nItem();
                for (int n = 0; n < nVert; n++)
                {
                    int node = connec->getNbor(e, n, IndexType::Local);
                    auto nbors = adjcyNE->getNborList(node);

                    for (auto &elem : nbors)
                        graph->InsertGlobalIndices(1, &eGl, 1, &elem);

                }

            }

            connec->Barrier();
            graph->GlobalAssemble();

            return graph;
        }

        RCP<MapBalance> elemLoadBalance(DistributedMesh* mesh, double imbalaceTolerance)
        {
            // Get imbalance tolerance
            string ImbTol = to_string(1 + imbalaceTolerance);

            // Set parameters for the partitioning method
            Teuchos::ParameterList params;
            params.set("PARTITIONING METHOD", "GRAPH");
            //      params.set("Partitioning Method", "RANDOM");
            params.set("IMBALANCE TOL", ImbTol);
            Teuchos::ParameterList &sublist = params.sublist("Zoltan");
            sublist.set("LB_APPROACH", "PARTITION");
            sublist.set("DEBUG_LEVEL", "0");
            //         sublist.set("PHG_COARSENING_LIMIT", "1000");

            // Create adjacency element-element
            RCP<const Epetra_CrsGraph> c_ptr = createAdjcyElemElem(mesh->_connec, mesh->_adjcyNE);

            // Create element partitions
            RCP<Isorropia::Epetra::Partitioner> part = rcp(new Isorropia::Epetra::Partitioner(c_ptr, params));

            // Set the elements of this partition in a vector
            auto epetraMap = *part->createNewMap();
            Epetra_Map vec_map(-1, epetraMap.NumMyElements(), 0, mesh->epComm());
            Epetra_IntVector new_to_old(vec_map);
            for (int i = 0; i < new_to_old.MyLength(); i++)
                new_to_old[i] = epetraMap.GID(i);

            // Compute the inverse map
            Epetra_Map old_map(-1, mesh->_connec->loc_nElem(), 0, mesh->epComm());
            Epetra_IntVector* old_to_new = computeMapOldToNew(mesh->comm(), new_to_old, old_map);


            // Create the MapBalance object with the information computed above
            RCP<MapBalance> map = rcp(new MapBalance(*old_to_new, new_to_old, "Map", mesh->comm()));

            delete old_to_new;
            return map;
        }

        RCP<MapBalance> elemLoadBalance_HRefin(RCP<MapBalance> parBalMap, RCP<MeshMap_Macro> oldMapToPar)
        {
            int parNItems = parBalMap->newLocNItem();



            // We get the new Number of Items of the current Mesh
            int newNItems;
            if (oldMapToPar->coarToFn())
                throw runtime_error("LoadBalance::genLoadBalance_HRefin: We can not use the Load Balance from coarse to fine.");
            else
                newNItems = parNItems * oldMapToPar->N();


            Epetra_Map vec_map(-1, newNItems, 0, oldMapToPar->epComm());

            Epetra_IntVector new_to_old(vec_map);


            const int N = oldMapToPar->N();
            for (int i = 0; i < parNItems; i++)
            {
                for (int n = 0; n < N; n++)
                    new_to_old[i*N + n] = parBalMap->locNewToOld(i) * N + n;
            }


            Epetra_IntVector* old_to_new = computeMapOldToNew(oldMapToPar->comm(), new_to_old, oldMapToPar->map());


            // Creating the MapBalance Object with the information computed above
            RCP<MapBalance> map = rcp(new MapBalance(*old_to_new, new_to_old, "Map", oldMapToPar->comm()));

            delete old_to_new;

            return map;
        }

        RCP<MapBalance> elemLoadBalance_Boundary(RCP<MapBalance> parBalMap, RCP<MeshMap_Boundary>& oldMapToPar)
        {

            int alloc_points;
            int *p_old_mapToPar;
            vector<int> vecNewBalMap;
            vector<int> vecBndNewToOld;

            auto comm = oldMapToPar->comm();



            // We pass the Map To Parent to all the partitions

            auto BMoldToPar = oldMapToPar->map();

            alloc_points = BMoldToPar.NumMyElements();
            int recBuf = 0;
            MPI_Allreduce(&alloc_points, &recBuf, 1, MPI_INT, MPI_MAX, oldMapToPar->comm());
            alloc_points = recBuf;

            p_old_mapToPar = new int[alloc_points];


            for (int p = 0; p < oldMapToPar->numProcs(); p++)
            {
                int p_points = BMoldToPar.NumMyElements();
                int p_offset = BMoldToPar.MinMyGID();

                MPI_Bcast(&p_points, 1, MPI_INT, p, comm);
                MPI_Bcast(&p_offset, 1, MPI_INT, p, comm);

                if (oldMapToPar->myRank() == p)
                {
                    p_old_mapToPar = oldMapToPar->_distrMap.data();
                }

                MPI_Bcast(p_old_mapToPar, p_points, MPI_INT, p, comm);


                // Loop over parent elements to see which we need
                auto end_vector = p_old_mapToPar+p_points;
                for (int e = 0; e < parBalMap->newLocNItem(); e++)
                {
                    int oldTag = parBalMap->locNewToOld(e);

                    int *elem = std::find(p_old_mapToPar, end_vector, oldTag);

                    // For the boundary elements that belongs to my partition, We keep tag of the corresponding new Parent element and the old tag of the boundary element.
                    if (elem != end_vector)
                    {
                        vecNewBalMap.push_back(e + parBalMap->newMap().MinMyGID());
                        int oldBndyElem = static_cast<int>(elem - p_old_mapToPar) + p_offset;
                        vecBndNewToOld.push_back(oldBndyElem);

                    }

                }

                oldMapToPar->Barrier();
            }


            // We save the BlockMap of the old distribution of boundary elements
            auto oldMyMap = oldMapToPar->map();


            // We update the map to Parent with the Balanced Map
            RCP<MeshMap_Boundary> mapBnd = rcp(new MeshMap_Boundary("MeshMap_Boundary", comm));
            mapBnd->setDistrMap(vecNewBalMap);
            mapBnd->Update();

            oldMapToPar = mapBnd;



            // We construct the MapBalance for the boundary
            auto newBalMapSize = vecNewBalMap.size();

            Epetra_Map vec_map(-1, newBalMapSize, 0, oldMapToPar->epComm());
            Epetra_IntVector new_to_old(vec_map);

            for (auto i = 0u; i < newBalMapSize; i++)
                new_to_old[i] = vecBndNewToOld[i];

            Epetra_IntVector* old_to_new = computeMapOldToNew(oldMapToPar->comm(), new_to_old, oldMyMap);
            // Creating the MapBalance Object with the information computed above
            RCP<MapBalance> map = rcp(new MapBalance(*old_to_new, new_to_old, "Map", comm));

            delete old_to_new;

            return map;

        }

        RCP<MapBalance> elemLoadBalance_Immersed(RCP<MapBalance> parBalMap, RCP<MeshMap_Immersed>& oldMapToPar)
        {
            // Initialize
            vector<int> vecNewBalMap;
            vector<int> vecImmNewToOld;
            auto comm = oldMapToPar->comm();

            // Compute maximum number of elements per partition in the old immersed mesh
            auto IMoldToPar = oldMapToPar->map();
            int alloc_points = IMoldToPar.NumMyElements();
            int recBuf = 0;
            MPI_Allreduce(&alloc_points, &recBuf, 1, MPI_INT, MPI_MAX, oldMapToPar->comm());
            alloc_points = recBuf;

            // Pass map to parent of the old immersed mesh to all partitions and keep some
            int *p_old_mapToPar = new int[alloc_points];
            for (int p = 0; p < oldMapToPar->numProcs(); p++)
            {
                int p_points = IMoldToPar.NumMyElements();
                int p_offset = IMoldToPar.MinMyGID();
                MPI_Bcast(&p_points, 1, MPI_INT, p, comm);
                MPI_Bcast(&p_offset, 1, MPI_INT, p, comm);
                if (oldMapToPar->myRank() == p)
                    p_old_mapToPar = oldMapToPar->_mostFreq.data();
                MPI_Bcast(p_old_mapToPar, p_points, MPI_INT, p, comm);

                // Loop over parent elements to see which ones we need
                auto end_vector = p_old_mapToPar + p_points;
                for (int e = 0; e < parBalMap->newLocNItem(); e++)
                {
                    int oldTag = parBalMap->locNewToOld(e);
                    // For the immersed elements that belong to my partition, we keep the tag of
                    // the corresponding new parent element and the tag of the old immersed element
                    int repeated = std::count(p_old_mapToPar, end_vector, oldTag);
                    int *ini_vector = p_old_mapToPar;
                    for (int r = 0; r < repeated; r++)
                    {
                        //New element balance map
                        int newTag = e + parBalMap->newMap().MinMyGID();
                        vecNewBalMap.push_back(newTag);

                        //New map to parent
                        int *elem = std::find(ini_vector, end_vector, oldTag);
                        int oldImmElem = static_cast<int>(elem - p_old_mapToPar) + p_offset;
                        vecImmNewToOld.push_back(oldImmElem);
                        ini_vector = ++elem;
                    }
                }

                oldMapToPar->Barrier();
            }

            // Relabel immersed map

            // Compute maximum number of elements per partition in the old immersed mesh
            alloc_points = oldMapToPar->_vals.size();
            recBuf = 0;
            MPI_Allreduce(&alloc_points, &recBuf, 1, MPI_INT, MPI_MAX, oldMapToPar->comm());
            alloc_points = recBuf;

            // Pass (old) map to parent of the (old) immersed mesh to all partitions
            unordered_multimap<int, int> newMap;
            p_old_mapToPar = new int[alloc_points];
            for (int p = 0; p < oldMapToPar->numProcs(); p++)
            {
                int p_points = oldMapToPar->_disData.loc_nItem();
                int p_offset = oldMapToPar->_disData.offs_nItem();
                MPI_Bcast(&p_points, 1, MPI_INT, p, comm);
                MPI_Bcast(&p_offset, 1, MPI_INT, p, comm);

                if (oldMapToPar->myRank() == p)
                    p_old_mapToPar = oldMapToPar->_vals.data();
                MPI_Bcast(p_old_mapToPar, p_points, MPI_INT, p, comm);

                // Loop over (new) parent elements to see which ones we need
                int *ini_vector = p_old_mapToPar;
                int *end_vector = p_old_mapToPar + p_points;
                vector<int> newVals_tmp(p_points, -1);
                for (int e = 0; e < parBalMap->newLocNItem(); e++)
                {
                    //Get old parent tag
                    int oldTag = parBalMap->locNewToOld(e);

                    int repeated = std::count(p_old_mapToPar, end_vector, oldTag);
                    int *start_search = p_old_mapToPar;
                    for (int r = 0; r < repeated; r++)
                    {
                        //Find old parent tag in vector
                        int *elem = std::find(start_search, end_vector, oldTag);

                        //Get global parent new tag
                        int newTag = e + parBalMap->newMap().MinMyGID();
                        int pos = std::distance(ini_vector, elem);

                        //Save relabeled
                        newVals_tmp[pos] = newTag;

                        //Increment
                        start_search = ++elem;
                    }
                }

                //Share info
                vector<int> newVals(p_points);
                MPI_Allreduce(newVals_tmp.data(), newVals.data(), p_points, MPI_INT, MPI_MAX, MPI_COMM_WORLD);

                if (oldMapToPar->myRank() == p)
                {
                    for (size_t i = 0; i < newVals.size(); i++)
                        newMap.emplace(oldMapToPar->_keys[i], newVals[i]);
                }

                oldMapToPar->Barrier();
            }

            // Save the BlockMap of the old immersed mesh distribution
            auto oldMyMap = oldMapToPar->map();

            // Update the map to parent with the balanced map
            RCP<MeshMap_Immersed> mapImm = rcp(new MeshMap_Immersed("MeshMap_Immersed", comm));
            mapImm->setMeshInNItems(oldMapToPar->meshInNItems());
            mapImm->setMeshOutNItems(oldMapToPar->meshOutNItems());
            mapImm->setDistrMap(newMap);
            mapImm->Update();
            oldMapToPar = mapImm;

            // Construct the MapBalance for the immersed mesh
            auto newBalMapSize = vecNewBalMap.size();
            Epetra_Map vec_map(-1, newBalMapSize, 0, oldMapToPar->epComm());
            Epetra_IntVector new_to_old(vec_map);
            for (auto i = 0u; i < newBalMapSize; i++)
                new_to_old[i] = vecImmNewToOld[i];
            Epetra_IntVector* old_to_new = computeMapOldToNew(oldMapToPar->comm(), new_to_old, oldMyMap);

            // Create the MapBalance Object with the information computed above
            RCP<MapBalance> map = rcp(new MapBalance(*old_to_new, new_to_old, "Map", comm));

            delete old_to_new;
            return map;
        }

        void redistributeElems(DistributedMesh* mesh, Teuchos::RCP<MapBalance> map)
        {

            const int nVert = mesh->_connec->nVert();
            const int newLocNElem = map->newLocNItem();
            const int newLocSize = newLocNElem * nVert;
            Epetra_Map newConnMap(-1, newLocSize, 0, mesh->_connec->epComm());
            RCP<Epetra_IntVector> newAdjcyConnec = rcp(new Epetra_IntVector(newConnMap));


            // Generate Importers
            // Generate Adjcy Ghosts
            Epetra_IntSerialDenseVector targetElemVerts;
            targetElemVerts.Size(newLocSize);
            Epetra_IntSerialDenseVector targetElemSing;
            targetElemSing.Size(newLocNElem);

            int n = 0;
            for (auto e = 0; e < newLocNElem; e++)
            {
                for (int i = 0; i < nVert; i++)
                {
                    targetElemVerts[n] = map->locNewToOld(e) * nVert + i;
                    n++;
                }
                targetElemSing[e] = map->locNewToOld(e);
            }

            Epetra_Map targetMap(-1, targetElemVerts.Length(),
                                 targetElemVerts.Values(), 0, mesh->epComm());

            auto importerOldToNew = rcp(new Epetra_Import(targetMap, mesh->_connec->_adjcyConnec->Map()));

            newAdjcyConnec->Import(*mesh->_connec->_adjcyConnec, *importerOldToNew, Insert);


            Teuchos::RCP<ConnecStruct> new_connec = rcp(new ConnecStruct("Connec"));

            new_connec->setNVert(nVert);
            new_connec->setElemType(mesh->_connec->elemType());
            new_connec->setAdjcyConnec(newAdjcyConnec);
            new_connec->Update();


            mesh->_connec = new_connec;



            if (mesh->_elemFlags->numFlds() > 0)
            {
                // Redistributing nodeElems
                Epetra_Map newElemMap(-1, targetElemSing.Length(), 0, mesh->epComm());
                Epetra_Map targetMapSing(-1, targetElemSing.Length(),
                                         targetElemSing.Values(), 0, mesh->epComm());

                auto importerElemsOldToNew = rcp(new Epetra_Import(targetMapSing, mesh->_elemFlags->_data[0]->Map()));

                const int numElemFlags = mesh->_elemFlags->numFlds();
                Teuchos::RCP<IntFieldStruct> newFS_elemFlags = rcp(new IntFieldStruct("elemFlags"));
                newFS_elemFlags->setBlockMap(newElemMap);
                newFS_elemFlags->setNFlds(numElemFlags);
                newFS_elemFlags->Update();

                for (auto i = 0; i < numElemFlags; i++)
                    newFS_elemFlags->_data[i]->Import(*mesh->_elemFlags->_data[i], *importerElemsOldToNew, Insert);

                mesh->_elemFlags = newFS_elemFlags;
            }

        }

        void redistributeMapToParent_Immersed(DistributedMesh* mesh, Teuchos::RCP<MapBalance> balMap, Teuchos::RCP<MeshMap_Immersed>& oldMapToPar)
        {
            // Initialize
            vector<int> oldKeys = oldMapToPar->_keys;
            vector<int> oldVals = oldMapToPar->_vals;
            unordered_multimap<int, int> newMap;

            //Redistribute mapping
            vector<int> p_oldKeys, p_oldVals;
            for (int p = 0; p < oldMapToPar->numProcs(); p++)
            {
                //BCast number of keys
                int p_nKeys = oldKeys.size();
                MPI_Bcast(&p_nKeys, 1, MPI_INT, p, oldMapToPar->comm());

                //Broadcast keys and values
                p_oldKeys.resize(p_nKeys);
                p_oldVals.resize(p_nKeys);
                if (oldMapToPar->myRank() == p)
                {
                    p_oldKeys = oldKeys;
                    p_oldVals = oldVals;
                }
                MPI_Bcast(&p_oldKeys[0], p_nKeys, MPI_INT, p, oldMapToPar->comm());
                MPI_Bcast(&p_oldVals[0], p_nKeys, MPI_INT, p, oldMapToPar->comm());

                int p_offset = oldMapToPar->map().MinMyGID();
                MPI_Bcast(&p_offset, 1, MPI_INT, p, balMap->comm());

                //Get the keys and values that are mine
                for (int n = 0; n < p_nKeys; n++)
                {
                    int oldKey = p_oldKeys[n] + p_offset;
                    int newKey = balMap->getNewIndex(oldKey);
                    int oldVal = p_oldVals[n];

                    // Distribute according to the keys
                    if (newKey >= balMap->newMap().MinMyGID() and newKey < balMap->newMap().MinMyGID()+balMap->newMap().NumMyElements())
                        newMap.emplace(newKey-balMap->newMap().MinMyGID(), oldVal);
                }
                oldMapToPar->Barrier();
            }

            // Update the map to parent with the balanced map
            RCP<MeshMap_Immersed> mapImm = rcp(new MeshMap_Immersed("MeshMap_Immersed", oldMapToPar->comm()));
            mapImm->setMeshInNItems(mesh->loc_nElem());
            mapImm->setMeshOutNItems(mesh->_parentMesh->loc_nElem());
            mapImm->setDistrMap(newMap);
            mapImm->Update();
            oldMapToPar = mapImm;
        }

        /*
         * Method that selects in which partition a node is going to be.
         * It is the actual implementation of the algorithm described
         * in the documentation of the method generateNodeBalance in this file.
         *
         * \param part It is the first partition to be check, by default, the calling one.
         */
        static int getPartOfNode(DistributedMesh* mesh, const int node, int part = -1)
        {
            if (part == -1)
                part = mesh->myRank();

            unsigned numInPart = 0;

            auto nbors = mesh->_adjcyNE->getNborList(node);

            for (auto &e : nbors)
            {
                if (mesh->_connec->isItemInPart(e))
                    numInPart++;
            }

            // If the current partition have more than half of the neighbors
            if (numInPart > nbors.size() / 2)
                return part;

            map<int, int> partits;
            for (auto i = 0u; i < nbors.size(); i++)
            {
                int part = mesh->_connec->getItemPartition(nbors[i]);
                partits[part]++;
            }

            vector<pair<int, int>> maxPart = {make_pair<>(0, -1)};
            for (auto &p : partits)
            {
                if (p.second > maxPart[0].second)
                {
                    maxPart.clear();
                    maxPart.push_back(p);
                } else if (maxPart[0].second == p.second)
                {
                    maxPart.push_back(p);
                }
            }

            // If there is one partition with the highest number of elements we return this
            if (maxPart.size() == 1)
                return maxPart[0].first;


            // If there is a tie between several partitions
            sort(maxPart.begin(), maxPart.end(),
                 [&mesh](const pair<int, int> &a, const pair<int, int> &b) -> bool {
                     return mesh->_connec->proc_nItem(a.first) < mesh->_connec->proc_nItem(b.first);
                 });

            return maxPart[0].first;

        }

        /*!
         *
         *  The new map for the node distribution is defined of the following way:
         *     1. For all node neighbors of the elements of the current partition, we check if
         *        more than half of its elements neighbors are in this partition, if this is
         *        fulfill, we assign the node to the partition.
         *     2. For the rest, we check if which is the partition with mode elements nbors to
         *        the node and assign to it.
         *     3. If there is a tie between two partitions, situation that can happen easily
         *        in the boundary between two partitions, we assign the nodes to the partitions with
         *        less elements.
         *
         *  The ordering inside one partition tries to preserve the connectivity of the elements
         *  to favor the sparsity in the global matrix.
         *
        */
        Teuchos::RCP<MapBalance> nodeLoadBalance(DistributedMesh* mesh)
        {

            set<int> checkInserted;
            vector<int> nodesToKepp; // All the nodes of a partition, the
            nodesToKepp.reserve(mesh->loc_nPts());

            for (auto e = 0; e < mesh->loc_nElem(); e++)
            {

                auto nbors = mesh->_connec->getNborList(e, IndexType::Local);

                for (auto &node : nbors)
                {
                    auto it = checkInserted.find(node);

                    if (it == checkInserted.end())
                    {
                        int part = getPartOfNode(mesh, node);

                        if (part == mesh->myRank())
                        {
                            checkInserted.insert(node);
                            nodesToKepp.push_back(node);
                        }


                    }
                }

            }


            mesh->Barrier();


            // Creating the node map
            Epetra_Map newMap(-1, nodesToKepp.size(), 0, mesh->epComm());
            Epetra_IntVector new_to_old(newMap);
            for (int i = 0; i < new_to_old.MyLength(); i++)
                new_to_old[i] = nodesToKepp[i];

            Epetra_Map oldMap(-1, mesh->loc_nPts(), 0, mesh->epComm());
            Epetra_IntVector* old_to_new = computeMapOldToNew(mesh->comm(), new_to_old, oldMap);


            RCP<MapBalance> map = rcp(new MapBalance(*old_to_new, new_to_old, "Map", mesh->comm()));

            delete old_to_new;
            return map;
        }

        void redistributeNodes(DistributedMesh* mesh, Teuchos::RCP<MapBalance> map)
        {

            const int newLocNPts = map->newLocNItem();

            Epetra_IntSerialDenseVector targetElements;

            targetElements.Size(newLocNPts);

            for (auto n = 0; n < newLocNPts; n++)
            {
                targetElements[n] = map->locNewToOld(n);
            }

            Epetra_Map targetMap(-1, targetElements.Length(),
                                 targetElements.Values(), 0, mesh->epComm());

            auto importerOldToNew = rcp(new Epetra_Import(targetMap, mesh->_nodeData->_data->Map()));


            // Redistributing nodeData
            const int numNodeData = mesh->_nodeData->numFlds();
            RCP<Epetra_FEVector> newNodeData = rcp(new Epetra_FEVector(map->newMap(), numNodeData));
            newNodeData->Import(*mesh->_nodeData->_data, *importerOldToNew, Insert);

            // New Coordinates:
            Teuchos::RCP<FieldStruct> newFS_nodeData = rcp(new FieldStruct("nodeData"));
            newFS_nodeData->setFields(newNodeData);
            newFS_nodeData->Update();

            mesh->_nodeData = newFS_nodeData;


            // Redistributing nodeFlags
            const int numNodeFlags = mesh->_nodeFlags->numFlds();
            Teuchos::RCP<IntFieldStruct> newFS_nodeFlags = rcp(new IntFieldStruct("nodeFlags"));
            newFS_nodeFlags->setBlockMap(mesh->_nodeData->map());
            newFS_nodeFlags->setNFlds(numNodeFlags);
            newFS_nodeFlags->Update();


            for (auto i = 0; i < numNodeFlags; i++)
                newFS_nodeFlags->_data[i]->Import(*mesh->_nodeFlags->_data[i], *importerOldToNew, Insert);


            mesh->_nodeFlags = newFS_nodeFlags;
        }


        void redistributeLinearConstraints(DistributedMesh *mesh, Teuchos::RCP<MapBalance> map)
        {
            //**************************************************************
            // [0] Relabel linear constraints
            //**************************************************************

            // Save old linear constraints
            vector<linearConstraint> oldlinearConstraints = mesh->_linearConstraints;

            // Share maximum number of local nodes
            int alloc_points = map->locOldNItem();
            int recBuf = 0;
            MPI_Allreduce(&alloc_points, &recBuf, 1, MPI_INT, MPI_MAX, mesh->comm());
            alloc_points = recBuf;

            // Relabel slave and masters
            vector<int> p_old_to_new(alloc_points);
            auto oldNodMap = map->oldMap();
            for (int p = 0; p < mesh->numProcs(); p++)
            {
                // Share number of nodes and offsets
                int p_points = oldNodMap.NumMyElements();
                int p_offset = oldNodMap.MinMyGID();
                MPI_Bcast(&p_points, 1, MPI_INT, p, mesh->comm());
                MPI_Bcast(&p_offset, 1, MPI_INT, p, mesh->comm());

                // Get mapping
                if (mesh->myRank() == p)
                {
                    int ERROR = map->_oldToNew->ExtractCopy(p_old_to_new.data());

                    if (ERROR != 0)
                    {
                        clog << "ERROR!!!  " << __FILE__ << ":" << __LINE__ << "  ->  Extration Copy failed, code: "
                             << ERROR << endl;
                        abort();
                    }
                }

                // Share old-to-new mapping
                MPI_Bcast(p_old_to_new.data(), p_points, MPI_INT, p, mesh->comm());
                const int p_offNextPart = p_offset + p_points;

                // Relabel linear constraints
                for (size_t n = 0; n < mesh->_linearConstraints.size(); n++)
                {
                    // Relabel slave node
                    int nborSlave = oldlinearConstraints[n].slave;
                    if (nborSlave >= p_offset and nborSlave < p_offNextPart)
                        mesh->_linearConstraints[n].slave = p_old_to_new[nborSlave-p_offset];

                    // Relabel master nodes
                    for (size_t m = 0; m < mesh->_linearConstraints[n].masters.size(); m++)
                    {
                        int nborMaster = oldlinearConstraints[n].masters[m];
                        if (nborMaster >= p_offset and nborMaster < p_offNextPart)
                            mesh->_linearConstraints[n].masters[m] = p_old_to_new[nborMaster-p_offset];
                    }

                }
            }


            //**************************************************************
            // [1] Redistribute linear constraints
            //**************************************************************

            // Save relabeled old linear constraints
            vector<int> oldSlaves(mesh->_linearConstraints.size());
            vector<double> oldValues(mesh->_linearConstraints.size());
            vector<vector<int>> oldMasters(mesh->_linearConstraints.size());
            vector<vector<double>> oldWeights(mesh->_linearConstraints.size());
            for (size_t n = 0; n < mesh->_linearConstraints.size(); n++)
            {
                oldSlaves[n] = mesh->_linearConstraints[n].slave;
                oldValues[n] = mesh->_linearConstraints[n].value;
                for (size_t m = 0; m < mesh->_linearConstraints[n].masters.size(); m++)
                {
                    oldMasters[n] = mesh->_linearConstraints[n].masters;
                    oldWeights[n] = mesh->_linearConstraints[n].weights;
                }
            }

            //Distribute linear constraints
            mesh->_linearConstraints.resize(0);
            for (int p = 0; p < mesh->numProcs(); p++)
            {
                // Share the number of linear constrained nodes
                int p_nLC = oldSlaves.size();
                MPI_Bcast(&p_nLC, 1, MPI_INT, p, mesh->comm());

                // Share slaves and values
                vector<int> p_oldSlaves(p_nLC);
                vector<double> p_oldValues(p_nLC);
                if (mesh->myRank() == p)
                {
                    p_oldSlaves = oldSlaves;
                    p_oldValues = oldValues;
                }
                MPI_Bcast(&p_oldSlaves[0], p_nLC, MPI_INT, p, mesh->comm());
                MPI_Bcast(&p_oldValues[0], p_nLC, MPI_DOUBLE, p, mesh->comm());

                // Share masters and weights
                vector<vector<int>> p_oldMasters(p_nLC);
                vector<vector<double>> p_oldWeigths(p_nLC);
                for (int n = 0; n < p_nLC; n++)
                {
                    // Share the number of masters
                    int p_nMasters{};
                    if (mesh->myRank() == p)
                        p_nMasters = oldMasters[n].size();
                    MPI_Bcast(&p_nMasters, 1, MPI_INT, p, mesh->comm());

                    // Share masters and weights
                    p_oldMasters[n].resize(p_nMasters);
                    p_oldWeigths[n].resize(p_nMasters);
                    if (mesh->myRank() == p)
                    {
                        p_oldMasters[n] = oldMasters[n];
                        p_oldWeigths[n] = oldWeights[n];
                    }
                    MPI_Bcast(&p_oldMasters[n][0], p_nMasters, MPI_INT, p, mesh->comm());
                    MPI_Bcast(&p_oldWeigths[n][0], p_nMasters, MPI_DOUBLE, p, mesh->comm());
                }

                // Get the LC nodes that are mine (if slave is mine)
                for (int n = 0; n < p_nLC; n++)
                {
                    int slave = p_oldSlaves[n];
                    if (slave >= map->newMap().MinMyGID() and slave <= map->newMap().MaxMyGID())
                        mesh->_linearConstraints.push_back({slave, p_oldMasters[n], p_oldWeigths[n], p_oldValues[n]});
                }
            }
        }


        void relabelConnectivity(DistributedMesh *mesh, Teuchos::RCP<MapBalance> map)
        {

            int alloc_points;
            int *p_old_to_new;

            auto oldNodMap = map->oldMap();

            alloc_points = map->locOldNItem();
            int recBuf = 0;
            MPI_Allreduce(&alloc_points, &recBuf, 1, MPI_INT, MPI_MAX, mesh->comm());
            alloc_points = recBuf;

            Teuchos::RCP<Epetra_IntVector> oldConnec = rcp(new Epetra_IntVector(*mesh->_connec->_adjcyConnec));

            p_old_to_new = new int[alloc_points];

            for (int p = 0; p < mesh->numProcs(); p++)
            {
                int p_points = oldNodMap.NumMyElements();
                int p_offset = oldNodMap.MinMyGID();

                MPI_Bcast(&p_points, 1, MPI_INT, p, mesh->comm());
                MPI_Bcast(&p_offset, 1, MPI_INT, p, mesh->comm());

                if (mesh->myRank() == p)
                {
                    int ERROR = map->_oldToNew->ExtractCopy(p_old_to_new);

                    if (ERROR != 0)
                    {
                        clog << "ERROR!!!  " << __FILE__ << ":" << __LINE__ << "  ->  Extration Copy failed, code: "
                             << ERROR << endl;
                        abort();
                    }
                }

                MPI_Bcast(p_old_to_new, p_points, MPI_INT, p, mesh->comm());
                const int p_offNextPart = p_offset + p_points;

                // For over all the nbors of the local connec to select what we change
                for (int n = 0; n < oldConnec->MyLength(); n++)
                {
                    int nbor = (*oldConnec)[n];
                    // For connectivity
                    if (nbor >= p_offset and nbor < p_offNextPart)
                    {
                        const int locIdx = nbor - p_offset;
                        const int newIdx = p_old_to_new[locIdx];
                        (*mesh->_connec->_adjcyConnec)[n] = newIdx;
                    }
                }

            }

            delete[] p_old_to_new;
        }

        int closerElemToParentNode(DistributedMesh* mesh, const vector<int>& parElMap, vector<double>& parNodeCoords)
        {

            double minDis= 1e100;
            int idxMinDis= -1;


            for (auto i = 0u; i < parElMap.size(); i++)
            {
                auto chElCon = mesh->_connec->getNborList(parElMap[i], IndexType::Global);

                for (auto& node: chElCon)
                {
                    auto coords = mesh->nodeCoords(node);

                    double currDist = Math::SDist3D(coords.data(), parNodeCoords.data());
                    if (currDist  < minDis)
                    {
                        minDis = currDist;
                        idxMinDis = i;

                    }
                }
            }

            return idxMinDis;
        }

        void macroElemCompatible(DistributedMesh *mesh)
        {

            // Map Coarse to Fine:
            auto mapCoarToFine = mesh->_mapToParent->generateInverse();
            auto parElems = mapCoarToFine->loc_nItem();
            int N = mesh->loc_nElem() / parElems;

            if (N != mesh->nVert()+1 or mesh->elemType() != ElemType::Triang)
                clog << "Warning!!!  MacroElements for element type different from Triangles and more than one division has not been tested and it is probably working incorrectly." << endl;


            if (N == 1)
                return;

            list<int> fullList(N);
            iota(fullList.begin(), fullList.end(), 0);


            //  Loop over parent mesh
            for (int e = 0; e < parElems; e++)
            {
                vector<int> orderElems(mesh->nVert(), -1);
                list<int> eList = fullList;

                auto parElMap = mapCoarToFine->directMap(e, IndexType::Local);
                auto parElCon = mesh->_parentMesh->_connec->getNborList(e, IndexType::Local);

                for (auto i = 0u; i < parElCon.size(); i++)
                {
                    auto parNodeCoords = mesh->_parentMesh->nodeCoords(parElCon[i]);

                    orderElems[i] = closerElemToParentNode(mesh, parElMap, parNodeCoords);
                    eList.remove(orderElems[i]);
                }


                if (eList.size() == 1)
                    orderElems.push_back(eList.front());
                else
                    throw runtime_error("LoadBalance: macroElemCompatible: something has gone terribly bad.");

                vector<vector<int>> macroElemConnecs;
                int firstElem = mapCoarToFine->directMap(e, IndexType::Local)[0] ;
                for (int& orderElem : orderElems)
                {
                    orderElem += firstElem;

                    macroElemConnecs.push_back(mesh->_connec->getNborList(orderElem));
                }


                for (auto i = 0u; i < orderElems.size(); i++)
                    mesh->_connec->setNborList(i+firstElem, macroElemConnecs[i]);
            }

        }

    }
}
