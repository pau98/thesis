/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <numeric>

#include "vtkSmartPointer.h"
#include "vtkPoints.h"
#include "vtkCell.h"
#include "vtkDoubleArray.h"
#include "vtkPointData.h"
#include "vtkCellData.h"
#include "vtkCellArray.h"
#include <vtkUnstructuredGrid.h>
#include <vtkXMLUnstructuredGridWriter.h>
#include <vtkXMLUnstructuredGridReader.h>

#include "hl_DistributedMesh.h"

using namespace std;


namespace hiperlife
{

    int DistributedMesh::_printFileVtk(string file_prefix, vector<Teuchos::RCP<FieldStruct>> vecData, vector<vector<string>> vecNames, vector<double> globalData, vector<string> globalNames)
    {
        if ((_basisFuncType == BasisFuncType::Nurbs or _basisFuncType == BasisFuncType::BSplines) and (VTK_MAJOR_VERSION < 9))
            throw runtime_error("DistributedMesh::_printFileVtk: Support for Bsplines and nurbs requires a vtk version > 9.0.0.");

        //Initialize
        ofstream file_mesh;
        string file_name{};
        file_name = file_prefix + "." + to_string(myRank()) + ".vtu";

        if(vecData.size() != vecNames.size())
            throw runtime_error("DistributedMesh::_printFileVtk: Number of fields does not correspond to number of names.");
        if(globalData.size() != globalNames.size())
            throw runtime_error("DistributedMesh::_printFileVtk: Number of fields does not correspond to number of names.");

        vtkSmartPointer<vtkUnstructuredGrid> mesh = vtkSmartPointer<vtkUnstructuredGrid>::New();
        vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();

        for (int i = 0; i < loc_nPts(); i++)
        {
            double x = nodeCoord(i, 'x', IndexType::Local);
            double y = nodeCoord(i, 'y', IndexType::Local);
            double z = nodeCoord(i, 'z', IndexType::Local);
            points->InsertNextPoint (x, y, z);
        }
        for (auto i: _graph->listGhosts())
        {
            double x = nodeCoord(i, 'x', IndexType::Global);
            double y = nodeCoord(i, 'y', IndexType::Global);
            double z = nodeCoord(i, 'z', IndexType::Global);
            points->InsertNextPoint (x, y, z);
        }
        mesh->SetPoints(points);

        vector<int> reorder = vtkReordering(elemType(), _basisFuncType, _bfOrder);

        vtkSmartPointer<vtkCellArray> cells = vtkSmartPointer<vtkCellArray>::New();
        for (int e = 0; e < loc_nElem(); e++)
        {
            vtkSmartPointer<vtkIdList> element = vtkSmartPointer<vtkIdList>::New();

            auto _nbors = _connec->getNborList(e, IndexType::Local);

            //nbors to local
            vector<int> loc_nbors;
            for(auto n: _nbors)
            {
                if (_graph->isItemInfoInPart(n))
                {
                    if (_graph->isItemInPart(n))
                        loc_nbors.push_back(_graph->locIdx(n));
                    else
                        loc_nbors.push_back(_graph->locGhostIdx(n) + loc_nPts());
                }
                else
                    throw runtime_error("DistributedMesh::_printFileVtk: Ghost not found.");
            }

            for (auto r: reorder)
                element->InsertNextId(loc_nbors[r]);

            cells->InsertNextCell(element);
        }
        mesh->SetCells(hlToVtkElemType(elemType(), _basisFuncType, _bfOrder),cells);

        if (vecNames.size() > 0)
        {
            for (int g = 0; g < min(int(vecNames.size()),2); g++)
            {
                for (size_t f = 0; f < vecNames[g].size(); f++)
                {
                    vtkSmartPointer<vtkDoubleArray> vtknodeField = vtkSmartPointer<vtkDoubleArray>::New();
                    vtknodeField->SetNumberOfComponents(1);
                    vtknodeField->SetNumberOfTuples(loc_nPts()+_graph->numGhosts());
                    vtknodeField->SetName(vecNames[g][f].c_str());

                    for (int i = 0; i < loc_nPts(); i++)
                        vtknodeField->SetValue(i, vecData[g]->getValue(f, i, IndexType::Local));

                    int n{loc_nPts()};
                    for (auto i: _graph->listGhosts())
                    {
                            vtknodeField->SetValue(n, vecData[g]->getValue(f, i, IndexType::Global));
                            n++;
                    }
                    mesh->GetPointData()->AddArray(vtknodeField);
                }
            }

            if(vecNames.size()==3)
            {
                for (size_t f = 0; f < vecNames[2].size(); f++)
                {
                    vtkSmartPointer<vtkDoubleArray> vtkcellField = vtkSmartPointer<vtkDoubleArray>::New();
                    vtkcellField->SetNumberOfComponents(1);
                    vtkcellField->SetNumberOfTuples(loc_nElem());
                    vtkcellField->SetName(vecNames[2][f].c_str());

                    for(int e = 0; e < loc_nElem(); e++)
                        vtkcellField->SetValue(e, vecData[2]->getValue(f, e, IndexType::Local));

                    mesh->GetCellData()->AddArray(vtkcellField);
                }
            }
        }

        // Write vtu
        vtkSmartPointer<vtkXMLUnstructuredGridWriter> writer = vtkSmartPointer<vtkXMLUnstructuredGridWriter>::New();
        writer->SetInputData(mesh);
        writer->SetFileName(file_name.c_str());
        writer->Update();

        // Write vtm
        if (_myRank == 0)
        {
            string vtmname = file_prefix + ".vtm";
            ofstream file;
            file.open(vtmname, ios::out | ios::trunc);
            file << "<VTKFile type=\"vtkMultiBlockDataSet\" version=\"1.0\"" << endl;
            file << "byte_order=\"LittleEndian\" header_type=\"UInt64\">" << endl;
            file << "<vtkMultiBlockDataSet>"<< endl;
            for(int i = 0; i < _numProcs; i++)
            {
                file << "<DataSet index=\"" << i << "\" ";
                file << "name=\"" << i << "\" ";
                file << "file=\"" << file_prefix+"."+std::to_string(i)+".vtu";
                file << "\"></DataSet>" << endl;
            }
            file << "</vtkMultiBlockDataSet>" << endl;
            file <<"<FieldData>" << endl;
            for(size_t i = 0; i < globalData.size(); i++)
            {
                file <<"<DataArray type=\"Float64\" Name=\"" << globalNames[i] <<"\" NumberOfTuples=\"1\" format=\"ascii\" RangeMin=\"" << globalData[i] << "\" RangeMax=\"" << globalData[i] << "\">" << endl;
                file << globalData[i] << endl;
                file << "</DataArray>" << endl;
            }
            file << "</FieldData>" << endl;
            file << "</VTKFile>" << endl;
            file.close();
        }

        MPI_Barrier(_comm);
        return 0;
    }
}
