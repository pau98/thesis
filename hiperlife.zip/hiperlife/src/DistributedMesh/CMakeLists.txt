
#------------------------------------------------------------
# hiperlife's DistMesh Shared library
#------------------------------------------------------------

#------------------------------------------------------------
# Glob Source files
#------------------------------------------------------------
file(GLOB SOURCES_H   *.h)
file(GLOB SOURCES_CPP *.cpp)
set(SOURCE_FILES ${SOURCES_H} ${SOURCES_CPP})
set(LIBNAME hlDistMesh)


#Include VTK
if(VTK_FOUND)
  include_directories(SYSTEM ${VTK_INCLUDE_DIRS})
else()
  file(GLOB OUTVTK hl_DistributedMesh_Vtk_Out.cpp hl_vtkElementLocator.h hl_vtkElementLocator.cpp)
  if (NOT OUTVTK STREQUAL "")
    list(REMOVE_ITEM SOURCE_FILES ${OUTVTK})
  endif()
  message(STATUS "Warning!! VTK module is disabled in DistributedMesh.")
endif()


#------------------------------------------------------------
# Building the LIBRARY
#------------------------------------------------------------
add_library(${LIBNAME} ${SOURCE_FILES})

target_link_libraries(${LIBNAME} ${MPI_LIB})
target_link_libraries(${LIBNAME} ${Trilinos_LIBRARIES})
target_link_libraries(${LIBNAME} ${HPLFE_LIBRARIES})

if(VTK_FOUND)
  target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
endif()

install(TARGETS ${LIBNAME} DESTINATION lib EXPORT hiperlifeTargets)
install(FILES ${SOURCES_H} DESTINATION include)


#------------------------------------------------------------
# Storing the Library
#------------------------------------------------------------
set(HPLFE_LIBRARIES ${HPLFE_LIBRARIES} ${LIBNAME} CACHE INTERNAL "HPLFE_LIBRARIES")
