/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef VTK_ELEMENT_LOCATOR_H
#define VTK_ELEMENT_LOCATOR_H

#include <vector>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include <vtkSmartPointer.h>
#include <vtkCellLocator.h>
#include <vtkGenericCell.h>
#include <vtkUnstructuredGrid.h>

#include "hl_ElementLocator.h"


namespace hiperlife
{

    /*!
     * \brief Class to create an element locator based on vtk and Silva2009 (http://dx.doi.org/10.3166/ejcm.18.307-331)
     */
    class vtkElementLocator: public ElementLocator
    {
        public:

            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects can be created from
             *  temporal objects through move constructors
             *  @{ */
            vtkElementLocator(std::string tag ="vtkElementLocator", MPI_Comm comm = MPI_COMM_WORLD);
            vtkElementLocator(vtkElementLocator&& other) = default;
            vtkElementLocator(const vtkElementLocator& other) = delete;
            ~vtkElementLocator() = default;

            // Operators
            vtkElementLocator& operator=(const vtkElementLocator& other) = delete;
            vtkElementLocator& operator=(vtkElementLocator&& other) = default;
            /** @} */ // end of constructors

            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            // /*! \brief Set number of tree subdivision levels
            //  * \param nLevels Number of tree subdivision levels
            //  */
            // void setNumberOfTreeSubdivisionLevels(int nLevels){_nLevels = nLevels;}
            // /*! \brief Set maximum number of tree subdivision levels
            //  * \param maxNLevels Maximum number of tree subdivision levels
            //  */
            // void setMaxNumberOfTreeSubdivisionLevels(int maxNLevels){_maxNLevels = maxNLevels;}
            // /*! \brief Set number of elements per octant
            //  * \param nElemPerOctant Number of elements per octant
            //  */
            // void setNumberOfElementsPerOctant(int nElemPerOctant){_nElemPerOctant = nElemPerOctant;}
            // /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of primary object creation



            // /** @name Data access
            //  *  @{
            // */
            // /*! \brief Returns the number of dimensions.*/
            // inline int numberOfTreeSubdivisionLevels(){return _nLevels;}
            // /*! \brief Returns the maximum boundary of the mesh.*/
            // std::vector<double> meshMaximum();
            // /*! \brief Returns the minimum boundary of the mesh.*/
            // std::vector<double> meshMinimum();
            // /** @} */ // end of mesh data access



            /** @name Search methods
             *  @{
            */
            /*! \brief Finds the element and the coordinates in reference space of a the closest point
             * projection of one point in a partition. It returns the minimum distance to the point
             * \param elems Element global id that contains the closest point projection
             * \param rCoords Vector with the coordinates in reference space of the closest point projection
             * \param xCoords Vector of coordinates of the point
             */
            double searchElementInPartition(int& elems, std::vector<double>& rCoords, std::vector<double> xCoords) override;
            /*! \brief Finds the element and the coordinates in reference space of a the closest point
             * projection of several points
             * \param elems Element global ids that contain the closest point projections
             * \param rCoords Vector of vector with the coordinates in reference space of the closest point projections
             * \param xCoords Vector of vectors of coordinates of the points
             */
            std::vector<double> searchElement(std::vector<int>& elems, std::vector<std::vector<double>>& rCoords, std::vector<std::vector<double>> xCoords) override;
            /** @} */ // end of search methods


            /** @name Expert users/developers only
            *  @{ */
            //Main
            // int _mProc{0};
            /** @} */ // end of expert variables


        private:

            // Auxiliary variables
            int _nVert;
            ElemType _eType;
            BasisFuncType _basisFuncType;
            int _bfOrder;
            int _bfOrderX, _bfOrderY, _bfOrderZ;

            // Main
            vtkSmartPointer<vtkCellLocator> _myCellLocator;
            vtkSmartPointer<vtkGenericCell> _myGenericCell;
    };

}
#endif
