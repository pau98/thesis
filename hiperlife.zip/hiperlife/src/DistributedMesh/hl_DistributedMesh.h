/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat and Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef DISTRIBUTED_MESH_H
#define DISTRIBUTED_MESH_H

#include <vector>
#include <unordered_map>
#include <mpi.h>

#include <Teuchos_RCP.hpp>

#include <Epetra_MpiComm.h>
#include <Epetra_ConfigDefs.h>
#include <Epetra_CrsGraph.h>
#include <Epetra_FECrsGraph.h>
#include <Epetra_FEVector.h>
#include <Epetra_FECrsMatrix.h>
#include <Epetra_IntVector.h>

#include "hl_MeshMap.h"
#include "hl_DistributedData.h"
#include "hl_MapBalance.h"
#include "hl_TypeDefs.h"
#include "hl_DistributedClass.h"
#include "hl_GraphStruct.h"
#include "hl_ConnecStruct.h"
#include "hl_AdjcyNEStruct.h"
#include "hl_AdjcyENStruct.h"
#include "hl_BasisFunctions.h"
#include "hl_FieldStruct.h"
#include "hl_IntFieldStruct.h"
#include "hl_MeshCreator.h"



namespace hiperlife
{

    // Forward declaration of element locator so that we can create a pointer to it
    class ElementLocator;

    /*!
     * \brief Computational Mesh. It has all the important information of the distribution of mesh data.
     */
    class DistributedMesh: public DistributedClass
    {
        public:

            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects can be created from
             *  temporal objects through move constructors
             *  @{ */
            DistributedMesh(std::string tag = "DistributedMesh", MPI_Comm comm = MPI_COMM_WORLD);
            DistributedMesh(DistributedMesh&& other) = default;
            DistributedMesh(const DistributedMesh& other) = delete;
            ~DistributedMesh() = default;

            // Operators
            DistributedMesh& operator=(const DistributedMesh& other) = delete;
            DistributedMesh& operator=(DistributedMesh&& other) = default;
            /** @} */ // end of constructors

            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the distributed mesh from a mesh creator.
             * \param meshCrea MeshCreator
             */
            void setMesh(Teuchos::RCP<MeshCreator> meshCrea){_meshCrea = meshCrea;}
            /*! \brief Sets a relation between the current mesh and a parent distributed mesh.
             * \param mesrel Type of mesh relation
             * \param parmesh Parent distributed mesh
             * \param meshmap MeshMap between the distributed meshes. If not specified, it
             * will be calculated
             */
            void setMeshRelation(MeshRelation mesrel, Teuchos::RCP<DistributedMesh> parmesh,
                                 Teuchos::RCP<MeshMap> meshmap = Teuchos::null)
            {
                _meshRel = mesrel;
                _parentMesh = parmesh;
                _mapToParent = meshmap;
            }
            /*! \brief Sets order difference between this mesh and the parent mesh. Only valid
             * if the mesh is a related to a parent mesh by p-refinement.
             * \param orderDiff Order difference
             */
            void setPRefinement(int orderDiff){_pRefOrderDiff = orderDiff;}
            /*! \brief Sets the level of refinement of the parent mesh. Only valid
             * if the mesh is a related to a parent mesh by h-refinement.
             * \param refLevel Level of refinement
             */
            void setHRefinement(int refLevel){_hRefLevel = refLevel;}
            /*! \brief Sets the interior points of the background mesh for the immersed method.
             * \param intPoints Vector of interior points
             */
            void setImmersedInteriorPoints(std::vector<std::vector<std::vector<double>>> intPoints){_interiorPoints = intPoints;}
            /*! \brief Sets the tags for the diferent regions of the background mesh for the immersed method.
             * \param userTags Vector with an interior point for each region, same order as interior points
             */
            void setRegionTags(std::vector<std::string> usrTags){_userTags = usrTags;}

            /*! \brief Re-establishes the parent/child bookkeeping of an ImmersedBoundary relation
             * after both this (child) mesh and \p parentMesh have been reconstructed from a file
             * (i.e. via setFilePrefix()/setIStream() followed by Update(), rather than from a
             * MeshCreator). That bookkeeping -- the child-mesh link, shared immersed segments,
             * region tags, immersed interior points, element flags and the cut-cell
             * basis-function constraint structure used by HiPerProblem -- is built automatically
             * by Update() when the mesh is generated, but is skipped (and not part of the
             * serialized data) when the mesh is instead deserialized from disk. Call this once,
             * right after both meshes have been loaded and before building any HiPerProblem that
             * uses cut-cell cubature on \p parentMesh.
             * \param parentMesh The background mesh this immersed mesh is coupled to.
             * \param regionTags Region tags, in the same order as originally passed to
             * setRegionTags() when the meshes were first created.
             * \param interiorPoints Interior points, in the same order as originally passed to
             * setImmersedInteriorPoints() when the meshes were first created.
             */
            void reconnectImmersedChild(Teuchos::RCP<DistributedMesh> parentMesh,
                                         std::vector<std::string> regionTags,
                                         std::vector<std::vector<std::vector<double>>> interiorPoints);

            /*! \brief Sets the threshols for the definition of ill posed elements for the immersed method.
             * \param eta_0 Minimum of the element inside of the integration region to be considered well posed
             */
            void setIllPosThreshold(double eta_0){_eta_0 = eta_0;}
            /*! \brief Sets whether the mesh nodes and elements should be balance among partitions
             * and the imbalance tolerance.
             * \param bal True or false
             * \param imbalancedTol Imbalance tolerance. Default 0.05.
             */
            void setBalanceMesh(bool bal, double imbalancedTol = 0.05) {_balanceMesh = bal; _imbalancedTol = imbalancedTol;}
            /*! \brief Sets the element locator engine to be used when searching for points
             * \param elLocEngine ElementLocatorEngine
             */
            void setElementLocatorEngine(ElementLocatorEngine elLocEngine){_elLocEngine = elLocEngine;};
            /*! \brief Sets the main processor. For now it only works for global constraints.*/
            void setMasterProcessor(int p){_mProc = p;};
            /*! \brief Set verbosity level.*/
            void setVerbosity(Verbosity verb){_verbosity = verb;};
            /*! \brief Enables the generation of topological creases during the creation of the distributed mesh. */
            void setGenerateCreases(bool generateCreases){_generateCreases = generateCreases;}
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update();
            /** @} */ // end of primary object creation



            /** @name Mesh data access
             *  @{
            */
            /*! \brief Returns the number of dimensions.*/
            int nDim(){return _nDim;}
            /*! \brief Returns the parametric of dimension.*/
            int pDim(){return _pDim;}
            /*! \brief Returns the number of vertices.*/
            int nVert(){return _connec->nVert();}
            /*! \brief Returns the element type.*/
            ElemType elemType() {return _connec->elemType();};
            /*! \brief Returns the basis function type.*/
            BasisFuncType basisFuncType() {return _basisFuncType;};
            /*! \brief Returns element basis functin type. */
            BasisFuncType basisFunctionType() const { return _basisFuncType; }
            /*! \brief Returns the basis function order.*/
            int basisFuncOrder() {return _bfOrder;};
            /*! \brief Returns element basis function order. */
            int basisFunctionOrder() const { return _bfOrder; }
            /*! \brief Returns the basis function order per direction.*/
            std::vector<int> basisFuncOrderDir() {return {_bfOrderX, _bfOrderY, _bfOrderZ};};
            /*! \brief Returns the global number of points.*/
            int nPts(){return _graph->nPts();}
            /*! \brief Returns the local number of points.*/
            int loc_nPts(){return _graph->loc_nPts();}
            /*! \brief Returns the number of points of the specified partition.*/
            int proc_nPts(int part = -1){return _graph->proc_nPts(part);}
            /*! \brief Returns the point offset of the specified partition.*/
            int offs_nPts(int part = -1){return _graph->offs_nPts(part);}
            /*! \brief Returns the global number of elements.*/
            int nElem(){return _connec->nElem();}
            /*! \brief Returns the local number of elements.*/
            int loc_nElem(){return _connec->loc_nElem();}
            /*! \brief Returns the number of elements of the specified partition.*/
            int proc_nElem(int part = -1){return _connec->proc_nElem(part);}
            /*! \brief Returns the element offset of the specified partition.*/
            int offs_nElem(int part = -1){return _connec->offs_nElem(part);}
            /*! \brief Returns a node coordinate for an specified dimension.
             * \param node Node number
             * \param dim Dimension of the coordinate (0, 1, 2)
             * \param idxtype Global or Local numbering of the given node
             */
            double nodeCoord(int node, int dim, IndexType idxtype = IndexType::Global);
            /*! \brief Returns a node coordinate for an specified dimension.
             * \param node Node number
             * \param dim Dimension of the coordinate (x, y, z)
             * \param idxtype Global or Local numbering of the given node
             */
            double nodeCoord(int node, char coord, IndexType idxtype = IndexType::Global);
            /*! \brief Returns node coordinates of a node.
             * \param node Node number
             * \param idxtype Global or Local numbering of the given node
             */
            std::vector<double> nodeCoords(int node, IndexType idxtype = IndexType::Global);
            /*! \brief Returns node coordinates of the neighboring nodes of an element in a
             * eNN x nDim vector of vectors.
             * \param node Element id
             * \param idxtype Global or Local numbering of the given element
             */
            std::vector<double> elemNborNodeCoords(int elem, IndexType idxType = IndexType::Global); // FIXME: Name?
            // std::vector<std::vector<double>> elemNborCoords(int elem, IndexType idxtype);

            /*! \brief Returns the element neighbors of a given element (returns IndexType::Global)
             * \param node Element id
             * \param idxtype Global or Local numbering of the given element
             */
            std::vector<int> elemNbors(int elem, IndexType idxType = IndexType::Global);
            /*! \brief Returns the node neighbors of a given element (returns IndexType::Global)
             * \param node Element id
             * \param idxtype Global or Local numbering of the given element
             */
            std::vector<int> elemNodeNbors(int elem, IndexType idxType = IndexType::Global){return _connec->getNborList(elem, idxType);};


            /*! \brief Returns the node crease of a node.*/
            int nodeCrease(int node, IndexType idxtype = IndexType::Global);
            /*! \brief Returns the node MAxis of a node.*/
            int nodeMAxis(int node, IndexType idxtype = IndexType::Global);
            /*! \brief Returns whether the node is in the MAxis given of a node.*/
            bool isNodeInMAxis(MAxis axis, int node, IndexType idxtype = IndexType::Global);
            /*! \brief Returns the tag of an element.*/
            int elemTag(int tag, int elem, IndexType idxtype = IndexType::Global)
            {
                return _elemFlags->getValue(tag, elem, idxtype);
            }
            /*! \brief Returns the tags of a vector of elements.*/
            std::vector<int> elemTag(int tag, std::vector<int>& elems, IndexType idxtype = IndexType::Global)
            {
                std::vector<int> retVec;
                for (auto& e : elems)
                    retVec.push_back(elemTag(tag, e, idxtype));
                return retVec;
            }
            /*! \brief Returns the global point/node id.*/
            inline int globalNodeId(int locNodeId){return _adjcyNE->globIdx(locNodeId);};
            /*! \brief Returns the local point/node id.*/
            inline int localNodeId(int globNodeId){return _adjcyNE->locIdx(globNodeId);};
            /*! \brief Returns the global element id.*/
            inline int globalElemId(int locElemId){return _adjcyEN->globIdx(locElemId);};
            /*! \brief Returns the local element id.*/
            inline int localElemId(int globElemId){return _adjcyEN->locIdx(globElemId);};
            /*! \brief Returns the element map balance.*/
            Teuchos::RCP<MapBalance> elemBalanceMap(){return _elemBalMap;}
            /*! \brief Returns the node map balance.*/
            Teuchos::RCP<MapBalance> nodeBalanceMap(){return _nodeBalMap;}
            /*! \brief Check if a node is in the current partition.*/
            inline bool isNodeInPart(int globalIndex){return _graph->isItemInPart(globalIndex);};
            /*! \brief Check if a node is in the ghosts of the current partition.*/
            inline bool isNodeInPartGhosts(int globalIndex){return _graph->isItemInPartGhosts(globalIndex);};
            /*! \brief Check if a node is in the current partition (either directly or in the ghosts).*/
            inline bool isNodeInfoInPart(int globalIndex){return _graph->isItemInfoInPart(globalIndex);};
            /*! \brief Get the partition of a node.*/
            [[deprecated("This function is deprecated and will be removed in the next release. Please use nodePartition(same arguments) instead.")]]
            inline int getNodePartition(int globalIndex){return _graph->getItemPartition(globalIndex);};
            /*! \brief Get the partition of a node.*/
            inline int nodePartition(int globalIndex){return _graph->getItemPartition(globalIndex);};
            /*! \brief Check if an element is in the current partition.*/
            inline bool isElemInPart(int globalIndex){return _connec->isItemInPart(globalIndex);};
            /*! \brief Check if an element is in the ghosts of the current partition.*/
            inline bool isElemInPartGhosts(int globalIndex){return _connec->isItemInPartGhosts(globalIndex);};
            /*! \brief Check if an element is in the current partition (either directly or in the ghosts).*/
            inline bool isElemInfoInPart(int globalIndex){return _connec->isItemInfoInPart(globalIndex);};
            /*! \brief Get the partition of an element.*/
            inline int elemPartition(int globalIndex){return _connec->getItemPartition(globalIndex);};
            /*! \brief Get a list of the ghosts of this partition.*/
            std::vector<int>& listGhosts(){return _graph->_ghosts;}
            /*! \brief Get a pointer to the element locator.*/
            inline Teuchos::RCP<ElementLocator> elementLocator(){return _elementLocator;};
            /*! \brief Get element locator engine.*/
            ElementLocatorEngine elementLocatorEngine(){return _elLocEngine;};
            /** @} */ // end of mesh data access



            /** @name Output methods
             * Methods to output the distributed mesh in different formats.
             *  @{
             */
            /*! \brief Output data in hiperlife's own format.*/
            int printFile(std::string test_prefix, OutputMode mode = OutputMode::Text,
                          std::vector<Epetra_MultiVector*> vecData = std::vector<Epetra_MultiVector*>(),
                          std::vector<std::string> vecNames = std::vector<std::string>());
            /*! \brief Output mesh in vtk legacy format.
            * This is here for compatibility reasons and for small problems. Don't use it
            * when computing big systems.
            * \param file_prefix name prefix of the output file, a '.vtk' extension will be added.
            */
            int printFileLegacyVtk(std::string file_prefix){return _printFileLegacyVtk(file_prefix);};
            /*! \brief Output mesh in vtk format.
            * This is here for compatibility reasons and for small problems. Don't use it
            * when computing big systems.
            * \param file_prefix name prefix of the output file, a '.vtk' extension will be added.
            */
#ifdef HL_VTK
            int printFileVtk(std::string file_prefix){return _printFileVtk(file_prefix);};
#endif
            /*! \brief Output mesh CSV format.
            * This is here for compatibility reasons and for small problems. Don't use it
            * when computing big systems.
            * \param file_prefix name prefix of the output file, a '.csv' extension will be added.
            */
            int printFileLegacyCSV(std::string file_prefix){return _printFileLegacyCSV(file_prefix);};
            /** @} */ // end of output methods



            /** @name IO Methods
             *  @{
             */
            /*! \brief Output data in hiperlife's own format.*/
            void outFullData(std::ostream& os, OutputMode mode) const;
            void setIStream(std::istream &in, OutputMode mode)
                {_tmp_istream = &in; _tmp_outputmode = mode;}
            void setFilePrefix(std::string prefix, OutputMode mode = OutputMode::Undefined)
                {_tmp_filePrefix = std::string(prefix); _tmp_outputmode = mode;}
            /** @} */ // end of IO



            /** @name Search methods
             *  @{
             */
            // Interpolate mapping at point
            double (DistributedMesh::*invertElementMapping)(std::vector<double>&, int, std::vector<double>, std::vector<double>, IndexType type, bool);

            // FIXME::: IndexType in all functions!
            std::vector<double> searchElementInPartition(std::vector<int>& elems, std::vector<std::vector<double>>& rCoords, std::vector<std::vector<double>> xCoords);
            double searchElementInPartition(int& elem, std::vector<double>& rCoords, std::vector<double> xCoords);

            std::vector<double> searchElement(std::vector<int>& elems, std::vector<std::vector<double>>& rCoords, std::vector<std::vector<double>> xCoords);
            double searchElement(int& elem, std::vector<double>& rCoords, std::vector<double> xCoords);

            void interpolatePosition(std::vector<double>& xCoords, int elem, std::vector<double> rCoords, IndexType type = IndexType::Global);
            std::vector<double> interpolatePosition(int elem, std::vector<double> rCoords, IndexType type = IndexType::Global);
            std::vector<std::vector<double>> closestPointProjection(std::vector<std::vector<double>> xCoords);
            std::vector<double> closestPointProjection(std::vector<double> xCoords)
            {
                std::vector<std::vector<double>> xCoords_v(1, xCoords);
                return closestPointProjection(xCoords_v)[0];
            };
            /** @} */ // end of search methods


            /** @name Object creation management for expert users/developers:
             * The parameters for the creation of the objects were set via these functions.
             * Now they have been replaced by the primary ones and are used within the class.
             *  @{
             */
            // Setters - Updates
            /*! \brief Sets the number of physical dimensions. Currently it should be 3. */
            void setNDim(int ndim);
            /*! \brief Sets the global number of points. */
            void setNPts(int npts) { _graph->setNPts(npts);}
            /*! \brief Sets the local number of points. */
            void setLocNPts(int locnpts) { _graph->setLocNPts(locnpts);}
            /*! \brief Sets the global number of elements. */
            void setNElem(int nelem) {_connec->setNElem(nelem); _graph->setTmpNElem(nelem);}
            /*! \brief Sets the local number of elements. */
            void setLocNElem(int loc_nelem) {_connec->setLocNElem(loc_nelem);}
            /*! \brief Sets the global number of elements per direction. */
            void setNElemDir(int nelemX, int nelemY, int nelemZ);
            /*! \brief Sets the element type. */
            void setElemType(ElemType etype){_connec->setElemType(etype);}
            /*! \brief Sets the basis function type. */
            void setBasisFuncType(BasisFuncType bfType){_basisFuncType = bfType;}
            /*! \brief Sets the basis function order. */
            void setBasisFuncOrder(int order){_bfOrder = order;}
            /*! \brief Sets the basis function order per direction. */
            void setBasisFuncOrderDir(int orderX, int orderY, int orderZ){_bfOrderX = orderX; _bfOrderY = orderY; _bfOrderZ = orderZ;}
            /*! \brief Sets Periodic boundary conditions. */
            void setLinearConstraints(std::vector<linearConstraint> linearConstraints){_linearConstraints = linearConstraints;};
            /*! \brief Sets the global NURBS weights. */
            void setGlobWeights(std::vector<double>& weights){_weights = weights;};
            /*! \brief Sets the global knot vectors. */
            void setGlobKnots(std::vector<double>& uKnot, std::vector<double>& vKnot, std::vector<double>& wKnot){_uKnot = uKnot; _vKnot = vKnot; _wKnot = wKnot;};
            /*! \brief Sets an array with the global coordinates. */
            void setGlobCoords(double*& x_nodes);
            /*! \brief Sets a vector with the global coordinates. */
            void setGlobCoords(std::vector<double>& x_nodes);
            /*! \brief Sets an array with the global creases. */
            void setGlobCreases(int*& creases);
            /*! \brief Sets a vector with the global creases. */
            void setGlobCreases(std::vector<int>& creases);
            /*! \brief Sets an array with the element flags. */
            void setGlobElemFlags(int*& eflags);
            /*! \brief Sets a vector with the element flags. */
            void setGlobElemFlags(std::vector<int>& eflags);
            /*! \brief Sets an array with the global connectivity. */
            void setGlobConnec(int*& connec) {_connec->setGlobConnec(connec);}
            /*! \brief Sets a vector with the global connectivity. */
            void setGlobConnec(std::vector<int>& connec) {_connec->setGlobConnec(connec);}
            /*! \brief Sets a vector with the coordinates locally distributed. This distribution should
             coincide with given local points*/
            void setDistCoords(double*& x_nodes);
            /*! \brief Sets a vector with the coordinates locally distributed. This distribution should
             coincide with given local points*/
            void setDistCoords(std::vector<double>& x_nodes);
            /* /\*! \brief Sets the node coordinates with an Epetra Object. *\/ */
            /* void setNodeCoords(Teuchos::RCP<Epetra_FEVector> coords){_graph->setNodeCoords(coords); } */
            /*! \brief Sets an array with the creases locally distributed. This distribution should
             coincide with given local points*/
            void setDistCreases(int*& creases);
            /*! \brief Sets a vector with the creases locally distributed. This distribution should
             coincide with given local points*/
            void setDistCreases(std::vector<int>& creases);
            /* /\*! \brief Sets the creases with an Epetra Object. *\/ */
            /* void setNodeCreases(Teuchos::RCP<Epetra_IntVector> creases){_graph->setNodeCreases(creases); } */
            /*! \brief Sets an array with the element flags locally distributed. This distribution should
             coincide with given local elements*/
            void setDistElemFlags(int*& eflags);
            /*! \brief Sets a vector with the element flags locally distributed. This distribution should
             coincide with given local elements.*/
            void setDistElemFlags(std::vector<int>& eflags);
            /*! \brief Sets an array with the connectivity locally distributed. This distribution should
             coincide with given local points*/
            void setDistConnec(int*& connec) {_connec->setDistConnec(connec);}
            /*! \brief Sets a vector with the creases locally distributed. This distribution should
             coincide with given local points*/
            void setDistConnec(std::vector<int>& connec) {_connec->setDistConnec(connec);}
            /*! \brief Sets the connectivity in connec.*/
            void setAdjcyConnec(Teuchos::RCP<Epetra_IntVector> adjcy){_connec->setAdjcyConnec(adjcy);}
            /*! \brief the node-node adjacency in graph.*/
            void setAdjcyNodeNode(Teuchos::RCP<Epetra_CrsGraph> adjcy){_graph->setAdjcyNodeNode(adjcy);}
            /*! \brief Sets the element map balance.*/
            void setElemBalanceMap(Teuchos::RCP<MapBalance> map) {_extElemBalMap = map;}
            /*! \brief Sets one element tag.*/
            void setElemTag(int tag, int elem, IndexType idxtype = IndexType::Global, int value = 0)
            {
                _elemFlags->setValue(tag, elem, idxtype, value);
            }
            /*! \brief Set the nodes and graph.*/
            int setNodesAndGraph(Teuchos::RCP<Epetra_MultiVector> & coord,
                                 Teuchos::RCP<Epetra_CrsGraph> &adj_nod, int nDim);
            /*! \brief Updates the mesh creator.*/
            void UpdateMeshCreator();
            /*! \brief Update (basic).*/
            void UpdateBasic();
            /*! \brief Update (basic ghosts).*/
            void UpdateBasicGhosts();
            /*! \brief Update (final).*/
            void UpdateComplete();
            /*! \brief Updates the adjacency node-element.*/
            void updateAdjcyNE();
            /*! \brief Updates the graph.*/
            void updateGraph(int locNPts = -1);
            /*! \brief Updates the element locator.*/
            void UpdateElementLocator();
            /*! \brief Generates the topological creases.*/
            void generateCreases();
            /** @} */ // end of secondary object creation



            /** @name Auxiliary functions for expert users/developers:
             *  @{
             */
            /*! \brief .*/
            bool hasBorder();
            /*! \brief Get the ids of the corner nodes of an element.
             * Note that for some element types (such as BSplines), the location of
             * the nodes needs not be at the actual corner of the element.
             */
            std::vector<int> _getElementCornerNodes(int e, IndexType idxtype = IndexType::Global);
            /*! \brief Given an element, return a vector of its sides that are at the
             * boundary of the mesh.
             * There are two ways to determine if they are at the boundary.
             *  1) By their creases (default, returns all boundaries)
             *  2) Given a vector of MAxis (returns only boundaries at the given MAxis)
             * *Important note*: Do not change the numbering unless you know what you are
             * doing.
             */
            std::vector<int> _getMeshBoundariesOfElement(int e, IndexType idxtype, std::vector<MAxis> axes = {});
            /*! \brief .*/
            void _reorderConnecSubdivSurfs();
            /*! \brief Method that gets the new element index from the old one, no matter which
             *  partition is calling, and taking into account if the balance has been performed.
             *  The index has to be given in global id.
             *
             * This method is supposed to be called with the same parameter from all the ranks and then,
             * the partition that holds this information will communicate the correct index to others.
             * */
            int _newElementIndex(int oldIdx);
            /*! \brief Method that gets the old element index from new old one, no matter which
             *  partition is calling, and taking into account if the balance has been performed.
             *  The index has to be given in global id.
             *
             * This method is supposed to be called with the same parameter from all the ranks and then,
             * the partition that holds this information will communicate the correct index to others.
             * */
            int _oldElementIndex(int newIdx);
            /*! \brief .*/
            void BalanceDistMesh();
            /*! \brief .*/
            // Create Related Meshes
            Teuchos::RCP<DistributedMesh> createGlobConstrMesh(Teuchos::RCP<DistributedMesh>& newMesh, int rank = 0);
            /*! \brief Output mesh in vtk in legacy format.*/
            int _printFileLegacyVtk(std::string file_prefix, std::vector<Epetra_MultiVector*> vecData = {},
                                    std::vector<std::vector<std::string>> vecNames = {});
#ifdef HL_VTK
            /*! \brief Output mesh in vtk (vtu/vtm) format.*/
            int _printFileVtk(std::string file_prefix, std::vector<Teuchos::RCP<FieldStruct>> vecData = {},
                              std::vector<std::vector<std::string>> vecNames = {}, std::vector<double> globalData = {}, std::vector<std::string> globalNames = {});
#endif
            /*! \brief Output mesh CSV format.*/
            int _printFileLegacyCSV(std::string file_prefix, std::vector<Epetra_MultiVector*> vecData = {},
                                    std::vector<std::vector<std::string>> vecNames = {});
            /*! \brief Gathers the connectivity and nodal coordinates from all processors
             *
             * \param globConnect stores the connectivity information  of the distribute mesh object
             * \param x_nodes stores the nodal coordinate information  of the distributed mesh object
             */
            void _allGatherMesh(std::vector<int>& globConnec, std::vector<double>& x_nodes);
            /*! \brief Related to the immersed method. Returns the corner flags of the given element.
            * \param conerGlobCoords matrix in which the global coordinates of the corners are saved. In 2D,
            * 0: bottom-left, 1: bottom-right, 2: top-left, 3: top-right.
            * \param elemID element number
            * \param type type of element numbering global or local
            */
            std::vector<int> _computeImmersedCornerFlags(std::vector<std::vector<double>> &cornerGlobCoords, int elemID, IndexType type);
            std::vector<int> _computeImmersedCornerFlags(std::vector<std::vector<double>> cornerGlobCoords);
            /*! \brief Related to the immersed method. Returns the _immSegments. */
            std::vector<double> _ImmersedSegments() { return _immSegments; }
            /*! \brief Related to the immersed method. Returns the _immCornerFlags map.
             * \param elementID an integer specifying the elmenet ID
             * \param type Index type indicating global or local numbering
             */
            std::vector<int> _immersedCornerFlags(int elementID, IndexType type);
            /*! \brief Related to the immersed method. Get user defined Tags*/
            std::vector<std::string> _regionTags() {return _userTags; }
            /*! \brief Related to the immersed method. Get eta_0 teshold*/
            double _eta0() {return _eta_0; }
            /*! \brief Related to the immersed method: This function returns an integer which is the flag of the back element mesh.
             *  0 means exterior, 1 means interior, and 2 means cut element.
             */
            int _computeBackElementFlag(std::vector<std::vector<double>> cornerGlobCoords, std::vector<int> cornerFlags); // #FIXME: Don't use corner flags
            /*! \brief Related to the immersed method: Using the shared immersed elements this functions returns a vector
             *  containing the status of each background element. This function must be called from backmesh.
             */
            std::vector<int> _createImmersedFlags();
            /*! \brief Related to the immersed method: This function finds which element contains the inside point that
             *  user passed and checks whether everything is ok or not. If the user-passed point is defined as exterior
             *  element reverse tags of exterior and inner elements.
             */
            void _checkInteriorPoints(std::vector<int> &immEFlags);
            /*! \brief Related to the immersed method: This function sets the diferent used defined regions according to the given tags.
             */
            std::vector<int> _updateCornerTag(std::vector<int>& immEFlags, std::set<int>& immTouched, int ini, int userTag, int el, IndexType type);
            /*! \brief Related to the immersed method: This function computes the flags of background elements after balancing
             *  and saves them in a field.
             */
            void _createElemFlagsForImmersed();
            /*! \brief Related to the immersed method. Saves mapToChild */
            void _saveMapToChild();
            /*! \brief Related to the immersed method (extending basis funciotns to remove instability).
             *  This method creates _cutBFs structures.
             */
            void _createCutBFStruts();
            /*! \brief Related to the immersed method (extending basis funciotns to remove instability).
             *  This method creates _cutBFs structures for the multiple user defined regions.
             */
            void _createCutBFStrutsRegions();
            /*! \brief Related to immersed mesh. Creates aggregate elements for extended basis function stabilization.
             * This function returns a map with cut elements as keys and root elements as values.
             */
            std::vector<cutBFConstraint> _cutBFsConstraints;
            /*! \brief Related to immersed mesh. Creates aggregate elements for extended basis function stabilization,
            to store different constrains for each region
             */
            std::vector<std::vector<linearConstraint>> _cutBFConstrRegions;
            std::vector<int> _createTouchFlags(int iTag);
            /*! \brief Related to the immersed method (2D ImmersedBoundary). Returns the pieces of the immersed curves that
             *  cross the local background element, as segments in global coordinates (BSplines curves are sampled with
             *  nine chords per immersed element). It is the geometry the conforming cut-cell cubature integrates on.
             *  \param locElem Local id of the background element
             */
            std::vector<std::vector<std::vector<double>>> _cutCellImmersedSegments(int locElem);
            /*! \brief Related to the immersed method (2D ImmersedBoundary). Oriented pieces {start, end} of an
             *  immersed element: the segment between its end nodes (Lagrangian) or nine chords (BSplines).
             *  \param immElem Local id of the immersed element
             */
            std::vector<std::vector<std::vector<double>>> _immersedElemChords(int immElem);
            /*! \brief Related to the immersed method. Groups the chords of the immersed elements into closed
             *  curves and builds each region from the curves around its interior point (for
             *  _cutCellRegionFractions and _cutCellRegionPolygons). Called by _createTouchFlags and by the
             *  CutCellConforming cubature set. Returns false if the regions can not be built (e.g. crossing curves).
             */
            bool _buildImmersedCurves();
            /*! \brief Related to the immersed method. Winding number of the point (x,y) around immersed curve c
             *  (built by _buildImmersedCurves).
             */
            int _immCurveWinding(int c, double x, double y);
            /*! \brief Related to the immersed method. Index of the region tag of the point (x,y), from the immersed
             *  curves (built by _buildImmersedCurves); -1 if none.
             */
            int _immRegionOfPoint(double x, double y);
            /*! \brief Related to the immersed method. Polygons of the part of a cut element in region iTag, in the
             *  reference coordinates of the element: each polygon is a list of rings (outer ring first, then its
             *  holes), each ring a list of points {r, s}. Built from the same polyline as _cutCellRegionFractions,
             *  without tolerances nor corner flags (input of CubatureCutCellConforming::setPolygons).
             *  \param locElem Local id of the background element
             *  \param iTag Index of the region tag
             */
            std::vector<std::vector<std::vector<std::vector<double>>>> _cutCellRegionPolygons(int locElem, int iTag);
            /*! \brief Related to the immersed method. Fraction of a cut element that belongs to each user region
             *  (indexed as the region tags): exact area of the element enclosed by the polyline of the immersed
             *  curves (the one the conforming cut-cell cubature uses). Returns an empty vector if the regions
             *  can not be built from the curves (e.g. crossing curves).
             *  \param locElem Local id of the background element
             */
            std::vector<double> _cutCellRegionFractions(int locElem);
            /*! \brief Related to the immersed method. Fraction of a cut element that belongs to region iTag,
             *  estimated by ray casting from a 10x10 grid of points. Fallback of _cutCellRegionFractions.
             *  \param globElem Global id of the background element
             */
            double _gridRegionFraction(int globElem, int iTag);
            std::unordered_map<int, std::vector<int>> _findClosestFAE(std::vector<int> touchFlags);
            std::unordered_map<int, std::vector<int>> _createAggregateElements(std::vector<int> touchFlags);
            /*! \brief Computes the lagrangian extrapolation weight for linear constrain used for extended basis function
             *  stabilization.
             *  \param slaveNodeID Global id of slave node
             *  \param masterNodeID Global id of master node
             *  \param bfOrder Order of basis function
             */
            std::vector<double> _computeExtrapolationWeights(int slaveNodeID, std::vector<int> masterNodeIDs, int bfOrder);
            /*! \brief Finds adjacent elements of a given element through facet for a structured mesh
             *  in 2D there are max 4 adjacent element through facent for an element
             */
            std::vector<int> _findFacetAdjacentElements(int elemIdx, IndexType type);
            /*! \brief Auxiliar function for the genertion of creases. Communicates ghost creases to the owning partition.*/
            void _communicateGhostCreases(const std::vector<int>& nodes);
            /*! \brief Auxiliar function for the genertion of creases. It checks if an edge is in a border.*/
            bool _checkIfEdgeIsInBorder(const std::array<int, 2>& edge) const;
            /** @} */ // end of auxiliary functions



            /** @name Non-used or deprecated
             *  @{
             */
            void setBoundaryMesh(MAxis ax);
            void setBoundaryMesh(std::vector<MAxis> vMAx);
            int initialize(int*& connec, double*& x_nodes, int& nPts, int& nElem, int& nVert, int& nDim);
            int initialize(Teuchos::RCP<Epetra_IntVector> &, Teuchos::RCP<Epetra_MultiVector> &,
                            Teuchos::RCP<Epetra_CrsGraph> &, int nVert, int nDim);
            int getNodesOfLocElemInPart(int elem, int part = -1);
            int setElems(Teuchos::RCP<Epetra_IntVector> &adj_elem, int nVert); //FIXME: Not used??
            /** @} */ // end of non-used



            /** @name Expert users/developers only
            *  @{ */
            //Main
            int _mProc{0};
            int _nDim{};
            int _pDim{};
            int _nCrease = 2; //FIXME: Set it from meshCreator
            int _nEFlags = 1; //FIXME: Set it from meshCreator
            bool _balanceMesh{true};
            bool _generateCreases{false};
            double _imbalancedTol{0.05};
            BasisFuncType _basisFuncType{BasisFuncType::Undefined};
            int _bfOrder{-1};
            int _bfOrderX{-1}, _bfOrderY{-1}, _bfOrderZ{-1};
            int _nElemX, _nElemY, _nElemZ;
            std::vector<linearConstraint> _linearConstraints;
            std::vector<double> _weights;
            std::vector<double> _uKnot, _vKnot, _wKnot;
            std::vector<int> _vCrv;
            //Mesh creator
            Teuchos::RCP<MeshCreator> _meshCrea = Teuchos::null;
            Teuchos::RCP<DistributedMesh> _parentMesh = Teuchos::null;
            // Teuchos::RCP<DistributedMesh> _childMesh  = Teuchos::null;
            DistributedMesh* _childMesh = nullptr;
            MeshRelation _meshRel = MeshRelation::None;
            Teuchos::RCP<MeshMap> _mapToParent = Teuchos::null;
            Teuchos::RCP<MeshMap> _mapToChild  = Teuchos::null;
            int _pRefOrderDiff{-1};
            int _hRefLevel{};
            //Balance
            Teuchos::RCP<MapBalance> _elemBalMap = Teuchos::null;
            Teuchos::RCP<MapBalance> _extElemBalMap= Teuchos::null;
            Teuchos::RCP<MapBalance> _nodeBalMap = Teuchos::null;

            //Child
            std::vector<MAxis> _vMAx;
            //Distribution
            double *_tmp_distXnodes{nullptr};
            int *_tmp_distCreases{nullptr};
            int *_tmp_distElemFlags{nullptr};
            double *_tmp_globXnodes{nullptr};
            int *_tmp_globCreases{nullptr};
            int *_tmp_globElemFlags{nullptr};
            //Output
            std::string _tmp_filePrefix{""};
            std::istream* _tmp_istream{nullptr};
            OutputMode _tmp_outputmode;
            // Mesh Data
            Teuchos::RCP<GraphStruct>   _graph   = Teuchos::null;
            Teuchos::RCP<ConnecStruct>  _connec  = Teuchos::null;
            Teuchos::RCP<AdjcyNEStruct> _adjcyNE = Teuchos::null;
            Teuchos::RCP<AdjcyENStruct> _adjcyEN = Teuchos::null;
            Teuchos::RCP<AdjcyNEStruct> _adjcyFullNE = Teuchos::null;
            Teuchos::RCP<BasisFunctions> _basisFunctions = Teuchos::null;
            Teuchos::RCP<FieldStruct> _nodeData = Teuchos::null; // In principle is the coordinates, but can also include another stuff.
            Teuchos::RCP<IntFieldStruct> _nodeFlags = Teuchos::null; // In principle is for the creases, but can also include another stuff.
            Teuchos::RCP<IntFieldStruct> _elemFlags = Teuchos::null; // In principle is for the bspline/nurbs flags, but can also include another stuff.
            std::vector<std::vector<double>> _immTangents{};
            // Immersed element id and local parametric coordinate matching each
            // border-immersed integration point, indexed the same way as
            // _immTangents (per background element, one entry per integration
            // point). Lets a fill function re-evaluate the immersed mesh's
            // basis functions (e.g. second derivatives for curvature) at the
            // exact point used to build the border cubature, using whichever
            // nodal values it wants (current or previous time step).
            std::vector<std::vector<int>> _immElemID{};
            std::vector<std::vector<double>> _immLocalParam{};
            void _printMap2ChildForDebugging();

            double _invertElementMapping_LinearTriangle(std::vector<double>& rCoords, int elem, std::vector<double> xCoords, std::vector<double> rCoords0, IndexType type = IndexType::Global, bool checkPointOutside = true);
            double _invertElementMapping_LinearSquare(std::vector<double>& rCoords, int elem, std::vector<double> xCoords, std::vector<double> rCoords0, IndexType idxType = IndexType::Global, bool checkPointOutside = true);
            double _invertElementMapping_RegSquare(std::vector<double>& rCoords, int elem, std::vector<double> xCoords, IndexType idxType = IndexType::Global, bool checkPointOutside = true);
            double _invertElementMapping_LinearParallelep(std::vector<double>& rCoords, int elem, std::vector<double> xCoords, std::vector<double> rCoords0, IndexType idxType = IndexType::Global, bool checkPointOutside = true);
            double _invertElementMapping(std::vector<double>& rCoords, int elem, std::vector<double> xCoords, std::vector<double> rCoords0, IndexType type = IndexType::Global, bool checkPointOutside = true);

            std::vector<double> _compBsplineEq(DistributedMesh* disMesh,int locElem); // Returns parameters for the cubic spline (x(t),y(t)), t=[-1,1]
            std::vector<double> _compBsplineEqPreBF(DistributedMesh* disMesh,std::vector<int> vC, int locElem); // Returns parameters for the cubic spline (x(t),y(t)), t=[0,1]


            // Variables and functions for the element locator to invert a map given in a FieldStruct
            Teuchos::RCP<FieldStruct> _mapFieldStruct = Teuchos::null;
            std::vector<int> _mapFields;
            inline double _mapCoordX(int node, int, IndexType idxtype = IndexType::Global)
            {
                return _mapFieldStruct->getValue(_mapFields[0], node, idxtype);
            };
            inline double _mapCoordY(int node, int, IndexType idxtype = IndexType::Global)
            {
                return _mapFieldStruct->getValue(_mapFields[1], node, idxtype);
            };
            inline double _mapCoordZ(int node, int, IndexType idxtype = IndexType::Global)
            {
                return _mapFieldStruct->getValue(_mapFields[2], node, idxtype);
            };
            double (DistributedMesh::*_mapCoordX_ptr)(int, int, IndexType);
            double (DistributedMesh::*_mapCoordY_ptr)(int, int, IndexType);
            double (DistributedMesh::*_mapCoordZ_ptr)(int, int, IndexType);
            std::vector<double> _mapCoords(int node, IndexType idxtype = IndexType::Global);
            std::vector<double> _elemNborMapCoords(int elem, IndexType idxType = IndexType::Global);
            std::vector<double> _elemNborCornerCoords(int el,IndexType idxtype = IndexType::Global);


            /** @} */ // end of expert variables

        private:
            std::vector<int> _computeConnecGhosts();
            std::vector<int> _computeGraphGhosts(AdjcyStruct &adjcy);
            std::vector<int> _computeAjdcyNEGhosts(AdjcyStruct &adjcy);
            void _computeImmersedConnecGhosts(std::vector<int>& ghosts);
            void _computeImmersedGraphGhosts(std::vector<int>& ghosts);

            std::string _stdFile(std::string prefix);

            void _updateFile();
            void _updateIStream();
            void _setNVert(int nvert){_connec->setNVert(nvert); _graph->setTmpNVert(nvert);}
            void _outFullData_linearConstraints(std::ostream& os, OutputMode mode) const;
            void _outFullData_Nurbs(std::ostream& os, OutputMode mode) const;
            void _updateIStream_Nurbs();
            void _updateIStream_linearConstraints();

            Verbosity _verbosity = Verbosity::None;

            std::map<int, int> _generateFullMapOldToNew(std::vector<int> &mapNewToOld, DistributedData& disPoints, std::vector<int> oldGhosts);

            //Immersed related
            std::unordered_multimap<int, int> _createImmersedElemMap();
            std::unordered_multimap<int, int> _createImmersedBoundaryElemMap();
            std::unordered_multimap<int, int> _createImmersedMeshElemMap();
            void _shareImmersedSegments();
            int _computeNumberOfBoundaryElements();
            void _setChildMesh(DistributedMesh* childMesh){_childMesh = childMesh;};
            std::vector<std::vector<std::vector<double>>> _interiorPoints{};
            std::vector<std::string> _userTags{};
            std::vector<double> _etaEl{};
            // Immersed curves for _cutCellRegionFractions (built by _buildImmersedCurves)
            bool _immCurvesBuilt = false;
            bool _immRegionsValid = false;
            std::vector<std::vector<std::vector<double>>> _immCurveChords{}; // per curve, chords {xa, ya, xb, yb}
            std::vector<std::vector<std::vector<double>>> _immCurveLoops{};  // per curve, ordered points {x, y}
            std::vector<std::vector<double>> _immCurveBox{};                // per curve, {xmin, ymin, xmax, ymax}
            std::vector<double> _immCurveSign{};                            // +1 counter-clockwise, -1 clockwise
            // Per region, its pieces (one per interior point, duplicates removed): the curve enclosing the piece
            // (-1: none) and the curves removed from it. A region is the union of its pieces
            std::vector<std::vector<std::pair<int, std::vector<int>>>> _immRegionPieces{};
            double _eta_0 = 1; // Related to immersed, sets the threshold for an element to be considered ill-defined
            std::vector<double> _immSegments; // Stores all segments of the immersed mesh (each segment consists of two points)
            std::vector<std::vector<int>> _immCornerFlags; // First element is the local number of the back mesh element and the 2:5 elements are the corner flags
            std::set<int> _boundaryElements;
            /*! \brief Creates a vector with the immediate adjacent elements for structured meshes*/

            // Search element related
            ElementLocatorEngine _elLocEngine = ElementLocatorEngine::Undefined;
            Teuchos::RCP<ElementLocator> _elementLocator = Teuchos::null;

    };

}
#endif
