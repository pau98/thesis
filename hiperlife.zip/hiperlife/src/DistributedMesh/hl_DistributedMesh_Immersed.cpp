/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <mpi.h>
#include <numeric>      // std::accumulate
#include <algorithm> // remove_if
#include <array>
#include <sys/stat.h>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>

#include "hl_MpiHelpers.h"
#include "hl_MeshMap_Immersed.h"
#include "hl_DistributedMesh.h"
#include "hl_Geometry.h" // doesIntersect and cubicLineIntersect


using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::rcp_dynamic_cast;


namespace hiperlife
{
    template<class T>
    void sortByFreq(std::vector<T>& v)
    {
        std::unordered_map<T, size_t> count;

        for (T i : v)
            count[i]++;

        std::sort(
            v.begin(),
            v.end(),
            [&count](T const& a, T const& b)
            {
                if (a == b)
                    return false;
                if (count[a] > count[b])
                    return true;
                else if (count[a] < count[b])
                    return false;
                return a < b;
            });
    }

    std::unordered_multimap<int, int> DistributedMesh::_createImmersedElemMap()
    {
        if (_meshRel == MeshRelation::ImmersedBoundary)
            return _createImmersedBoundaryElemMap();
        else if (_meshRel == MeshRelation::ImmersedMesh)
            return _createImmersedMeshElemMap();
        else
            throw runtime_error("DistributedMesh::_createImmersedElemMap: Only works with mesh relations MeshRelation::ImmersedBoundary and MeshRelation::ImmersedMesh");
    }

    std::unordered_multimap<int, int> DistributedMesh::_createImmersedBoundaryElemMap()
    {
        // Initialize
        std::unordered_multimap<int, int> map;
        Teuchos::RCP<MeshCreator> backMesh = _parentMesh->_meshCrea;

        // Create mapping
        if (elemType() == ElemType::Line and backMesh->_eType == ElemType::Square)
        {
            // Loop over local elements
            for (int immElem = 0; immElem < loc_nElem(); immElem++)
            {
                const int N = 2000;
                vector<double> xCoords_v(3*(N+1));
                if(basisFunctionType() == BasisFuncType::Lagrangian)
                {
                    // Get coordinates of the first and last node in the element
                    vector<double> xf(3), xl(3);
                    vector<int> nodeList = _connec->getNborList(immElem, IndexType::Local); // Global indexes of nodes in the element immElem
                    for (int i = 0; i < 3; ++i)
                    {
                        xf[i] = _nodeData->getValue(i, nodeList[0]);
                        xl[i] = _nodeData->getValue(i, nodeList.back());
                    }

                    // Interpolate linearly and get background element for each point //FIXME:: Change interpolation to actual values using basis funcs.

                    int n{};
                    vector<double> x = xf, u(3, 0.0);
                    for (int d = 0; d < nDim(); d++)
                        u[d] = (xl[d] - xf[d]) / double(N);
                    for (int i = 0; i < N + 1; i++)
                    {
                        // Get coordinates
                        vector<double> x(nDim());
                        for (int d = 0; d < nDim(); d++)
                        {
                            xCoords_v[n] = xf[d] + i*u[d];
                            n++;
                        }
                    }
                }
                else if (basisFunctionType() == BasisFuncType::BSplines)
                {
                    // Get nodes of the element
                    vector<double> xf(3), xl(3);
                    std::vector<double> pSeg = _parentMesh->_immSegments;
                    
                    // Use basis functions to obtain coordinates of the element
                    int n{};
                    for (int i = 0; i < N + 1; i++)
                    {
                        double u = 2.*(double)i/(double)N-1;
                        double xNode = pSeg[8*immElem]*u*u*u+pSeg[8*immElem+2]*u*u+pSeg[8*immElem+4]*u+pSeg[8*immElem+6];
                        double yNode = pSeg[8*immElem+1]*u*u*u+pSeg[8*immElem+3]*u*u+pSeg[8*immElem+5]*u+pSeg[8*immElem+7];
                        // cout << u<< "(" <<xNode<<","<<yNode<<")"<<endl;
                        xCoords_v[n] = xNode;
                        n++;
                        xCoords_v[n] = yNode;
                        n++;
                        xCoords_v[n] = 0.;
                        n++;
                    }
                    
                }
                else
                {
                    throw runtime_error("DistributedMesh::_createImmersedBoundaryElemMap: Only works with BasisFunctionType::BSplines and BasisFunctionType::Lagrangian");   
                }
                // Share point coordinates (NEEDED?)
                MPI_Bcast(xCoords_v.data(), xCoords_v.size(), MPI_DOUBLE, elemPartition(immElem), _comm);

                // Rearrange into a vector of vectors
                vector<vector<double>> xCoords(xCoords_v.size()/nDim(), vector<double>(nDim()));
                for (size_t n = 0; n < xCoords_v.size()/nDim(); n++)
                {
                    for (int d = 0; d < nDim(); d++)
                    {
                        xCoords[n][d] = xCoords_v.at(nDim()*n+d);//[nDim()*n+d];
                    }
                }

                // Search elements in the parent mesh for these points
                vector<int> backElems;
                vector<vector<double>> rCoords;
                _parentMesh->searchElement(backElems, rCoords, xCoords);

                // Save to map
                if (backElems.size() > 0)
                {
                    // Sort vector by frequency, remove elements that only have one point and remove duplicates
                    sortByFreq(backElems);
                    // FIXME: This removes elements that only have one point
                    // It creates small integration problems for the CutCellConforming
                    // I commented it, but left it here in case it is necessary later
                    for (size_t i = backElems.size() - 1; i > 0; i--)
                    {
                        if (backElems[i] != backElems[i - 1])
                            backElems.erase(backElems.begin() + i);
                        else
                            break;
                    }
                    backElems.erase(unique(backElems.begin(), backElems.end()), backElems.end());
                    // cout << "immElem: " << immElem << "black elems: (";
                    // Store them in the map (putting the most frequent first)
                    for (size_t i = backElems.size() - 1; i < backElems.size(); --i)
                    {
                        map.emplace(immElem, backElems[i]);
                        // cout << backElems[i]<< ",";
                    }
                    // cout << ")"<< endl;
                }
            }
        }
        else if (elemType() == ElemType::Triang and backMesh->_eType == ElemType::Parallelep)
        {
            // Loop over local elements of the immersed geometry
            for (int immElem = 0; immElem < loc_nElem(); immElem++)
            {
                // Get coordinates of immElem nodes
                vector<int> nodeList = _connec->getNborList(immElem, IndexType::Local);
                vector<double> n0(3), n1(3), n2(3);
                for (int i = 0; i < 3; ++i)
                {
                    n0[i] = _nodeData->getValue(i, nodeList[0]);
                    n1[i] = _nodeData->getValue(i, nodeList[1]);
                    n2[i] = _nodeData->getValue(i, nodeList[2]);
                }

                // Distribute points on the element and get background element for each point //FIXME:: Change interpolation to actual values using basis funcs.
                int numPtsX = 40;
                int numPtxY = 40;
                vector<vector<double>> disPoints = SGeometry::distributedPointsOnTriangle(n0, n1, n2, numPtsX, numPtxY);
                vector<int> backElems;
                for (auto pt : disPoints)
                {
                    // Get element of the background mesh
                    // FIXME: Don't assume unit length and don't assume regular geometry
                    double elx = pt[0] / (1.0 / double(backMesh->_nEx));
                    double ely = pt[1] / (1.0 / double(backMesh->_nEy));
                    double elz = pt[2] / (1.0 / double(backMesh->_nEz));
                    vector<int> xIndex, yIndex, zIndex;
                    xIndex.push_back(floor(elx));
                    yIndex.push_back(floor(ely));
                    zIndex.push_back(floor(elz));
                    double tol = 1.e-9;
                    if (fabs(elx - round(elx)) < tol)
                    {
                        xIndex.push_back(round(elx) - 1);
                    }
                    if (fabs(ely - round(ely)) < tol)
                    {
                        yIndex.push_back(round(ely) - 1);
                    }
                    if (fabs(elz - round(elz)) < tol)
                    {
                        zIndex.push_back(round(elz) - 1);
                    }
                    for (size_t i{}; i < xIndex.size(); ++i)
                    {
                        for (size_t j{}; j < yIndex.size(); ++j)
                        {
                            for (size_t k{}; k < zIndex.size(); ++k)
                            {
                                int be = zIndex[k] * backMesh->_nEy * backMesh->_nEx + yIndex[j] * backMesh->_nEx + xIndex[i];
                                if (be >= 0 and be < backMesh->_nElem)
                                {
                                    backElems.push_back(be);
                                }
                            }
                        }
                    }
                }

                // Save to map
                if (backElems.size() > 0)
                {
                    // Sort vector by frequency, remove elements that only have one point and remove duplicates
                    sortByFreq(backElems);
                    for (size_t i = backElems.size() - 1; i > 0; i--)
                    {
                        if (backElems[i] != backElems[i - 1])
                            backElems.erase(backElems.begin() + i);
                        else
                            break;
                    }
                    backElems.erase(unique(backElems.begin(), backElems.end()), backElems.end());

                    // Store them in the map (putting the most frequent first)
                    for (size_t i = backElems.size() - 1; i < backElems.size(); --i)
                        map.emplace(immElem, backElems[i]);
                }
            }
        }
        else if (elemType() == ElemType::Square and backMesh->_eType == ElemType::Parallelep)
        {
            throw runtime_error("DistributedMesh::_createImmersedBoundaryElemMap: 3D immersed boundary method with square element for geometry is under development.");
        }
        else
        {
            throw runtime_error("DistributedMesh::_createImmersedBoundaryElemMap: For 2D immersed boundary method the immersed geometry must be 1D Line element and the back mesh must be 2D Square.\nFor the 3D immersed boundary method the immersed geometry must be 2D Square or Triangle element and the back mesh must be 3D Parallelep.");
        }

        return map;
    }

    std::unordered_multimap<int, int> DistributedMesh::_createImmersedMeshElemMap()
    {
        // Initialize
        std::unordered_multimap<int, int> map;
        Teuchos::RCP<MeshCreator> backMesh = _parentMesh->_meshCrea;

        // Create mapping
        if (pDim() == 2 and backMesh->_eType == ElemType::Square)
        {
            // Compute bound node ordering //FIXME: Higher-order //FIXME:: Move to hl_TypeDefs.h?
            int numCorners = numElemNodeType(elemType(), basisFuncType(), _bfOrder)[2];
            vector<int> reorder = vtkReordering(elemType(), basisFuncType(), _bfOrder, false);
            vector<int> bOrder(reorder.begin(), reorder.begin()+numCorners);
            bOrder.push_back(bOrder[0]);

            // Loop over global elements -> Don't assume regular geometry
            if (true)
            for (int immElem = 0; immElem < nElem(); immElem++)
            {
                // Save list of point coordinates in each element boundary // FIXME:: Do this with segment intersection
                const int N = 2000;
                vector<double> xCoords_v;
                int n{};
                if (isElemInPart(immElem))
                {
                    // Get neighbors
                    vector<int> nbors = _connec->getNborList(immElem, IndexType::Global);

                    // Loop through boundaries and save list of points to evaluate
                    for (size_t b = 0; b < bOrder.size()-1; b++)
                    {
                        // Save node ids
                        int n0 = nbors[bOrder[b]];
                        int n1 = nbors[bOrder[b+1]];

                        // Check if this line is a boundary
                        bool boundaryElem{false};
                        if (_vMAx.empty())
                        {
                            int cr0 = nodeCrease(n0, IndexType::Global);
                            int cr1 = nodeCrease(n1, IndexType::Global);
                            if (cr0 > 0 and cr1 > 0)
                                boundaryElem = true;
                        }
                        else
                        {
                            for (auto ax: _vMAx)
                            {
                                int ax0 = nodeMAxis(n0, IndexType::Global);
                                int ax1 = nodeMAxis(n1, IndexType::Global);
                                if (ax0%getMAxis(ax) == 0 and ax1%getMAxis(ax) == 0)
                                {
                                    boundaryElem = true;
                                }
                            }
                        }

                        // Save points
                        if (boundaryElem)
                        {
                            // Get coordinates of the first and last node in the element
                            vector<double> xf = nodeCoords(n0, IndexType::Global);
                            vector<double> xl = nodeCoords(n1, IndexType::Global);

                            // Interpolate linearly and save list of points //FIXME:: Change interpolation to actual values using basis funcs.
                            xCoords_v.resize(xCoords_v.size()+3*(N+1));
                            vector<double> s(3, 0.0);
                            for (int d = 0; d < nDim(); d++)
                            {
                                s[d] = (xl[d] - xf[d]) / double(N);
                            }
                            for (int i = 0; i < N+1; i++)
                            {
                                for (int d = 0; d < nDim(); d++)
                                {
                                    xCoords_v[n] = xf[d] + i*s[d];
                                    n++;
                                }
                            }
                        }
                    }
                }

                // Share point coordinates
                MPI_Bcast(xCoords_v.data(), xCoords_v.size(), MPI_DOUBLE, elemPartition(immElem), _comm);

                // Rearrange into a vector of vectors
                vector<vector<double>> xCoords(xCoords_v.size()/nDim(), vector<double>(nDim()));
                for (size_t n = 0; n < xCoords_v.size()/nDim(); n++)
                {
                    for (int d = 0; d < nDim(); d++)
                    {
                        xCoords[n][d] = xCoords_v.at(nDim()*n+d);//[nDim()*n+d];
                    }
                }

                // Search elements in the parent mesh for these points
                vector<int> backElems;
                vector<vector<double>> rCoords;
                _parentMesh->searchElement(backElems, rCoords, xCoords);

                // Save to map
                if (backElems.size() > 0)
                {
                    // Sort vector by frequency, remove elements that only have one point and remove duplicates
                    sortByFreq(backElems);
                    // Note: elements with only one point are kept on purpose (removing them caused small integration problems in CutCellConforming)
                    backElems.erase(unique(backElems.begin(), backElems.end()), backElems.end());

                    // Store them in the map (putting the most frequent first)
                    for (size_t i = backElems.size() - 1; i < backElems.size(); --i)
                    {
                        map.emplace(_elemFlags->locIdx(immElem), backElems[i]);
                    }
                }
            }

            // Loop over local elements -> Works for regular geometry
            if (false)
            for (int immElem = 0; immElem < loc_nElem(); immElem++)
            {
                // Get neighbors
                vector<int> nbors = _connec->getNborList(immElem, IndexType::Local);

                // Loop through boundaries
                vector<int> backElems;
                for (size_t b = 0; b < bOrder.size()-1; b++)
                {
                    // Save node ids
                    int n0 = nbors[bOrder[b]];
                    int n1 = nbors[bOrder[b+1]];

                    // Check if this line is a boundary
                    bool boundaryElem{false};
                    if (_vMAx.empty())
                    {
                        int cr0 = nodeCrease(n0, IndexType::Global);
                        int cr1 = nodeCrease(n1, IndexType::Global);
                        if (cr0 > 0 and cr1 > 0)
                            boundaryElem = true;
                    }
                    else
                    {
                        for (auto ax: _vMAx)
                        {
                            int ax0 = nodeMAxis(n0, IndexType::Global);
                            int ax1 = nodeMAxis(n1, IndexType::Global);
                            if (ax0%getMAxis(ax) == 0 and ax1%getMAxis(ax) == 0)
                            {
                                boundaryElem = true;
                            }
                        }
                    }
                    if (!boundaryElem)
                        continue;

                    // Get coordinates
                    vector<double> xf = nodeCoords(n0, IndexType::Global);
                    vector<double> xl = nodeCoords(n1, IndexType::Global);

                    // Interpolate linearly and get background element for each point //FIXME:: Change interpolation to actual values using basis funcs.
                    const int N = 2000;
                    vector<double> u(3, 0.0);
                    for (int d = 0; d < nDim(); d++)
                        u[d] = (xl[d] - xf[d]) / double(N);
                    for (int i = 0; i < N + 1; i++)
                    {
                        // Get coordinates
                        vector<double> x(nDim());
                        for (int d = 0; d < nDim(); d++)
                            x[d] = xf[d] + i*u[d];

                        // Get element of the background mesh //FIXME: Don't assume unit length
                        double elx = x[0]*backMesh->_nEx;
                        double ely = x[1]*backMesh->_nEy;
                        vector<int> xIndex, yIndex; // FIXME: Why vector????
                        xIndex.push_back(floor(elx));
                        yIndex.push_back(floor(ely));
                        double tol = 1.e-9;
                        if (fabs(elx - round(elx)) < tol)
                        {
                            xIndex.push_back(round(elx) - 1);
                        }
                        if (fabs(ely - round(ely)) < tol)
                        {
                            yIndex.push_back(round(ely) - 1);
                        }
                        for (size_t l{}; l < xIndex.size(); ++l)
                        {
                            for (size_t j{}; j < yIndex.size(); ++j)
                            {
                                if (xIndex[l] >= 0 and xIndex[l] < backMesh->_nEx and
                                    yIndex[j] >= 0 and yIndex[j] < backMesh->_nEy)
                                {
                                    int be = yIndex[j] * backMesh->_nEx + xIndex[l];
                                    backElems.push_back(be);
                                }
                            }
                        }
                    }
                }

                // Save to map
                if (backElems.size() > 0)
                {
                    // Sort vector by frequency, remove elements that only have one point and remove duplicates
                    sortByFreq(backElems);
                    // Note: elements with only one point are kept on purpose (removing them caused small integration problems in CutCellConforming)
                    backElems.erase(unique(backElems.begin(), backElems.end()), backElems.end());

                    // Store them in the map (putting the most frequent first)
                    for (size_t i = backElems.size() - 1; i < backElems.size(); --i)
                        map.emplace(immElem, backElems[i]);
                }
            }
        }
        else if (pDim() == 3 and backMesh->_eType == ElemType::Parallelep)
        {
            throw runtime_error("DistributedMesh::_createImmersedMeshElemMap: 3D immersed method is under development.");
        }
        else
        {
            throw runtime_error("DistributedMesh::_createImmersedMeshElemMap: For 2D immersed method the immersed geometry must be 2D Square or Triangle element and the back mesh must be 2D Square.\nFor the 3D immersed method the immersed geometry must be 3D Tetrah or Parallelep element and the back mesh must be 3D Parallelep.");
        }

        return map;
    }

    void DistributedMesh::_shareImmersedSegments()
    {
        /***************************************************************************************/
        /* This function sets the all immersed segments (_immSegments).                        */
        /* In 2D: Each segment consists of two points and each point contains the coordinates. */
        /* In 3D: Each segment either is a square or triangle which consists of 4/3 points.    */
        /***************************************************************************************/

        // Checks
        if (_childMesh->basisFunctionType() == BasisFuncType::BSplines)
        {
            // throw runtime_error("DistributedMesh::_shareImmersedSegments: Immersed geometry with BSpline basis function is not implemented.");
            if (_pDim == 2)
            {
                if (_childMesh->_meshRel == MeshRelation::ImmersedBoundary)  // TODO IMMBOUNDARY
                {
                    // Check
                    if (_childMesh->elemType() != ElemType::Line)
                    {
                        throw runtime_error("DistributedMesh::_shareImmersedSegments: In 2D immersed boundary method, the geometry can be defined using Line element only.");
                    }

                    
                }
                else
                {
                    throw runtime_error("DistributedMesh::_shareImmersedSegments: BSplines interface only implemented Boundary immersed.");
                }
            }
            else
            {
                throw runtime_error("DistributedMesh::_shareImmersedSegments: BSplines interface only implemented for 2D.");
            }

        }
        if (_pDim == 1)
        {
            throw runtime_error("DistributedMesh::_shareImmersedSegments: 1D immersed method is not implemented.");
        }

        // Sharing segments depending on the parametric dimension and immersed mesh element type.
        // --------------------------------------------------------------------------------------
        if (_pDim == 2)
        {
            if (_childMesh->_meshRel == MeshRelation::ImmersedBoundary)  // TODO IMMBOUNDARY
            {
                // Check
                if (_childMesh->elemType() != ElemType::Line)
                {
                    throw runtime_error("DistributedMesh::_shareImmersedSegments: In 2D immersed boundary method, the geometry can be defined using Line element only.");
                }
                if (_childMesh->basisFunctionType() == BasisFuncType::BSplines)
                {
                    // Loop over local elements of the immersed boundary mesh and save its coordinates
                    // -------------------------------------------------------------------------------
                    int localNumElems = _childMesh->loc_nElem(); // Get local number of immersed elements
                    int numberOfPt{};
                    if (_childMesh->basisFunctionType() == BasisFuncType::Nurbs or
                        _childMesh->basisFunctionType() == BasisFuncType::BSplines)
                    {
                        numberOfPt = 2*localNumElems*(_childMesh->_bfOrder+1);
                    }
                    // cout << "Number of points: " <<numberOfPt << "Local num elems: "<< localNumElems <<;
                    vector<double> localImmersedSegments(numberOfPt);
                    int counter{};
                    double knt0 = -100;
                    int k = -7;
                    vector<int> vC{};
                    for (double knt : _childMesh->_uKnot)
                    {
                        if(knt < knt0)
                        {
                            vC.push_back(k);
                            k -= 7; // block of n_c+7 knots per curve: k = first element of the next curve
                        }
                        k++;
                        knt0 = knt;
                    }
                    for (int locElem = 0; locElem < localNumElems; ++locElem)
                    {
                        // Get the paramteric equation (x(t),y(t)) for the cubic segment 
                        std::vector<double> abcd = _compBsplineEqPreBF(_childMesh,vC,locElem);
                        for (size_t i = 0; i < abcd.size(); ++i)
                        {
                            localImmersedSegments[counter] = abcd[i];
                            counter++;
                        }
                    }

                    // Get size of local immersed segments
                    // -----------------------------------
                    vector<int> segSizes(_numProcs);
                    int mySegSize = localImmersedSegments.size();
                    MPI_Allgather(&mySegSize, 1, MPI_INT, segSizes.data(), 1, MPI_INT, MPI_COMM_WORLD);
                    // Resize the _immersedSegmetnts
                    _immSegments.resize(static_cast<size_t>(accumulate(segSizes.begin(), segSizes.end(), 0)));

                    // Share local segments
                    // --------------------
                    vector<int> disp(_numProcs);
                    for (int i = 0; i < _numProcs; ++i)
                    {
                        disp[i] = accumulate(segSizes.begin(), segSizes.begin() + i, 0);
                    }
                    MPI_Allgatherv(localImmersedSegments.data(), segSizes[_myRank], MPI_DOUBLE,
                                _immSegments.data(), segSizes.data(), disp.data(), MPI_DOUBLE, MPI_COMM_WORLD);
                }
                else
                {
                    //Loop over local elements of the immersed boundary mesh and save its coordinates
                    // -------------------------------------------------------------------------------
                    int localNumElems = _childMesh->loc_nElem(); // Get local number of immersed elements
                    int numberOfPt{};
                    if (_childMesh->basisFunctionType() == BasisFuncType::Nurbs or
                        _childMesh->basisFunctionType() == BasisFuncType::BSplines)
                    {
                        numberOfPt = 3 * (localNumElems + _childMesh->basisFunctionOrder());
                    }
                    else
                    {
                        numberOfPt = 3 * (_childMesh->basisFunctionOrder() + 1) * localNumElems;
                    }
                    vector<double> localImmersedSegments(numberOfPt);
                    int counter{};
                    for (int locElem = 0; locElem < localNumElems; ++locElem)
                    {
                        // Get global index of nodes connected to the local element
                        vector<int> nbors = _childMesh->_connec->getNborList(locElem, IndexType::Local);
                        for (size_t n = 0; n < nbors.size() - 1; ++n)
                        {
                            vector<double> segmentStart = _childMesh->nodeCoords(nbors[n]);
                            vector<double> segmentEnd = _childMesh->nodeCoords(nbors[n + 1]);
                            for (size_t i = 0; i < segmentStart.size(); ++i)
                            {
                                localImmersedSegments[counter] = segmentStart[i];
                                counter++;
                            }
                            for (size_t i = 0; i < segmentEnd.size(); ++i)
                            {
                                localImmersedSegments[counter] = segmentEnd[i];
                                counter++;
                            }
                        }
                    }

                    // Get size of local immersed segments
                    // -----------------------------------
                    vector<int> segSizes(_numProcs);
                    int mySegSize = localImmersedSegments.size();
                    MPI_Allgather(&mySegSize, 1, MPI_INT, segSizes.data(), 1, MPI_INT, MPI_COMM_WORLD);
                    // Resize the _immersedSegmetnts
                    _immSegments.resize(static_cast<size_t>(accumulate(segSizes.begin(), segSizes.end(), 0)));

                    // Share local segments
                    // --------------------
                    vector<int> disp(_numProcs);
                    for (int i = 0; i < _numProcs; ++i)
                    {
                        disp[i] = accumulate(segSizes.begin(), segSizes.begin() + i, 0);
                    }
                    MPI_Allgatherv(localImmersedSegments.data(), segSizes[_myRank], MPI_DOUBLE,
                                _immSegments.data(), segSizes.data(), disp.data(), MPI_DOUBLE, MPI_COMM_WORLD);
                }
            }
            else if (_childMesh->_meshRel == MeshRelation::ImmersedMesh)
            {
                // Check
                if (_childMesh->elemType() != ElemType::Triang and _childMesh->elemType() != ElemType::Square)
                {
                    throw runtime_error("DistributedMesh::_shareImmersedSegments: In 2D ImmersedMesh method, the geometry can be defined using Triang or Square elements only.");
                }

                // Get axis
                vector<MAxis> axes = _childMesh->_vMAx;

                // Compute bound node ordering //FIXME: Higher-order //FIXME:: Move to hl_TypeDefs.h?
                int numCorners = numElemNodeType(_childMesh->elemType(), _childMesh->basisFuncType(), _childMesh->_bfOrder)[2];
                vector<int> reorder = vtkReordering(_childMesh->elemType(), _childMesh->basisFuncType(), _childMesh->_bfOrder, false);
                vector<int> bOrder(reorder.begin(), reorder.begin()+numCorners);
                bOrder.push_back(bOrder[0]);

                // Compute local number of immersed segments
                int localNumSeg{};
                for (int locElem = 0; locElem < _childMesh->loc_nElem(); locElem++)
                {
                    // Get neighbors
                    vector<int> nbors = _childMesh->_connec->getNborList(locElem, IndexType::Local);

                    // Loop through boundaries
                    for (size_t b = 0; b < bOrder.size()-1; b++)
                    {
                        if (axes.empty())
                        {
                            int cr0 = _childMesh->nodeCrease(nbors[bOrder[b]], IndexType::Global);
                            int cr1 = _childMesh->nodeCrease(nbors[bOrder[b+1]], IndexType::Global);
                            if (cr0 > 0 and cr1 > 0)
                                localNumSeg++;
                        }
                        else
                        {
                            int ax0 = _childMesh->nodeMAxis(nbors[bOrder[b]], IndexType::Global);
                            int ax1 = _childMesh->nodeMAxis(nbors[bOrder[b+1]], IndexType::Global);
                            for (auto ax: axes)
                            {
                                if (ax0%getMAxis(ax) == 0 and ax1%getMAxis(ax) == 0)
                                {
                                    localNumSeg++;
                                    break;
                                }
                            }
                        }
                    }
                }

                // Compute local segments
                vector<double> localImmersedSegments(6*localNumSeg);
                int counter{};
                for (int locElem = 0; locElem < _childMesh->loc_nElem(); locElem++)
                {
                    // Get neighbors
                    vector<int> nbors = _childMesh->_connec->getNborList(locElem, IndexType::Local);

                    // Loop through boundaries
                    for (size_t b = 0; b < bOrder.size()-1; b++)
                    {
                        // Get node ids
                        int n0 = nbors[bOrder[b]];
                        int n1 = nbors[bOrder[b+1]];

                        // Check if segment is boundary
                        bool boundSegment{false};
                        if (axes.empty())
                        {
                            int cr0 = _childMesh->nodeCrease(n0, IndexType::Global);
                            int cr1 = _childMesh->nodeCrease(n1, IndexType::Global);
                            if (cr0 > 0 and cr1 > 0)
                                boundSegment = true;
                        }
                        else
                        {
                            int ax0 = _childMesh->nodeMAxis(n0, IndexType::Global);
                            int ax1 = _childMesh->nodeMAxis(n1, IndexType::Global);
                            for (auto ax: axes)
                            {
                                if (ax0%getMAxis(ax) == 0 and ax1%getMAxis(ax) == 0)
                                {
                                    boundSegment = true;
                                }
                            }
                        }

                        // Save segments
                        if (boundSegment)
                        {
                            vector<double> segmentStart = _childMesh->nodeCoords(n0);
                            vector<double> segmentEnd = _childMesh->nodeCoords(n1);
                            for (size_t i = 0; i < segmentStart.size(); ++i)
                            {
                                localImmersedSegments[counter] = segmentStart[i];
                                counter++;
                            }
                            for (size_t i = 0; i < segmentEnd.size(); ++i)
                            {
                                localImmersedSegments[counter] = segmentEnd[i];
                                counter++;
                            }
                        }
                    }
                }

                // Share segments
                _immSegments = MpiHelpers::allgatherv(localImmersedSegments, _numProcs, _myRank);
            }
        }
        else if (_pDim == 3 and _childMesh->elemType() == ElemType::Triang)
        {
            // FIXME: Since at this stage we are not using the basis functions to define the geometry
            // and we are linearly interpolating the geometry, using higher order basis functions is nonsense
            if (_childMesh->basisFunctionOrder() > 1)
            {
                throw runtime_error("DistributedMesh::_shareImmersedSegments: Use of higher-order basis functions for immersed geometry is not implemented. \nPlease use linear basis functions.");
            }
            // Loop over local elements of the immersed mesh and save its coordinate
            // ---------------------------------------------------------------------
            int localNumElems = _childMesh->loc_nElem(); // Get local number of immersed elements
            vector<double> localImmersedSegments(3 * 3 * localNumElems);
            int counter{};
            for (int locElem = 0; locElem < localNumElems; ++locElem)
            {
                // Get global index of nodes connected to the local element
                /* 2
                   |\
                   | \
                   0--1
                */
                vector<int> nbors = _childMesh->_connec->getNborList(locElem, IndexType::Local);
                for (int n : nbors)
                {
                    vector<double> nodeCoords = _childMesh->nodeCoords(n);
                    for (double coord : nodeCoords)
                    {
                        localImmersedSegments[counter] = coord;
                        counter++;
                    }
                }
            }

            // Get size of local immersed segments
            // -----------------------------------
            vector<int> segSizes(_numProcs);
            int mySegSize = localImmersedSegments.size();
            MPI_Allgather(&mySegSize, 1, MPI_INT, segSizes.data(), 1, MPI_INT, MPI_COMM_WORLD);
            // Resize the _immersedSegmetnts
            _immSegments.resize(static_cast<size_t>(accumulate(segSizes.begin(), segSizes.end(), 0)));

            // Share local segments
            // --------------------
            vector<int> disp(_numProcs);
            for (int i = 0; i < _numProcs; ++i)
            {
                disp[i] = accumulate(segSizes.begin(), segSizes.begin() + i, 0);
            }
            MPI_Allgatherv(localImmersedSegments.data(), segSizes[_myRank], MPI_DOUBLE,
                _immSegments.data(), segSizes.data(), disp.data(), MPI_DOUBLE, MPI_COMM_WORLD);
        }
        else if (_pDim == 3 and _childMesh->elemType() == ElemType::Square)
        {
            // FIXME: Since at this stage we are not using the basis functions to define the geometry
            // and we are linearly interpolating the geometry, using higher order basis functions is nonsense
            if (_childMesh->basisFunctionOrder() > 1)
            {
                throw runtime_error("DistributedMesh::_shareImmersedSegments: Use of higher-order basis functions for immersed geometry is not implemented. \nPlease use linear basis functions.");
            }
            // Loop over local elements of the immersed mesh and save its coordinate
            // ---------------------------------------------------------------------
            int localNumElems = _childMesh->loc_nElem(); // Get local number of immersed elements
            vector<double> localImmersedSegments(3 * 6 * localNumElems);
            // Triangulate the linear square element into two triangles and save the global coordinates of its vertices
            // 2 --- 3    triangles:
            // | \   |       0, 1, 2
            // |  \  |       1, 2, 3
            // 0 --- 1
            int counter{};
            for (int locElem = 0; locElem < localNumElems; ++locElem)
            {
                // Get global index of nodes connected to the local element
                vector<int> nbors = _childMesh->_connec->getNborList(locElem, IndexType::Local);
                for (size_t i = 0; i < (nbors.size() - 1); ++i) // 0,1,2 triangle
                {
                    vector<double> nodeCoords = _childMesh->nodeCoords(nbors[i]);
                    for (double coord : nodeCoords)
                    {
                        localImmersedSegments[counter] = coord;
                        counter++;
                    }
                }
                for (size_t i = 1; i < nbors.size(); ++i) // 1,2,3 triangle
                {
                    vector<double> nodeCoords = _childMesh->nodeCoords(nbors[i]);
                    for (double coord : nodeCoords)
                    {
                        localImmersedSegments[counter] = coord;
                        counter++;
                    }
                }
            }

            // Get size of local immersed segments
            // -----------------------------------
            vector<int> segSizes(_numProcs);
            int mySegSize = localImmersedSegments.size();
            MPI_Allgather(&mySegSize, 1, MPI_INT, segSizes.data(), 1, MPI_INT, MPI_COMM_WORLD);
            // Resize the _immersedSegmetnts
            _immSegments.resize(static_cast<size_t>(accumulate(segSizes.begin(), segSizes.end(), 0)));

            // Share local segments
            // --------------------
            vector<int> disp(_numProcs);
            for (int i = 0; i < _numProcs; ++i)
            {
                disp[i] = accumulate(segSizes.begin(), segSizes.begin() + i, 0);
            }
            MPI_Allgatherv(localImmersedSegments.data(), segSizes[_myRank], MPI_DOUBLE,
                _immSegments.data(), segSizes.data(), disp.data(), MPI_DOUBLE, MPI_COMM_WORLD);
        }
        else
        {
            throw runtime_error("DistributedMesh::_shareImmersedSegments: Case not implemented.");
        }
    }

    std::vector<double> DistributedMesh::_compBsplineEq(DistributedMesh* dismesh, int el)
    {
        vector<double> x(8,0.);

        std::vector<double> r = {-1.,0.,0.5,1.};
        for (int k = 0; k < 4; k++)
        {

            std::vector<double> rk = {r[k]};
            std::vector<std::vector<double>>& bf = dismesh->_basisFunctions->computeBasisFunctionsReference(rk, dismesh->_basisFunctions->getTag(el, IndexType::Local));

            std::vector<int> cnn = dismesh->_connec->getNborList(el, IndexType::Local);
            for (int i = 0; i < 4; i++)
            {
                std::vector<double> nCoords = dismesh->nodeCoords(cnn[i],IndexType::Local);
                x[k] += nCoords[0]*bf[0][i];
                x[k+4] += nCoords[1]*bf[0][i];
            }
        }

        vector<double> abcd(8);

        for (int i = 0; i < 2; i++)
        {
            abcd[i] =  -1./3.*x[4*i] +2.*x[4*i+1] -8./3.*x[4*i+2] +x[4*i+3];
            abcd[2+i] = 0.5*x[4*i]-x[4*i+1]+0.5*x[4*i+3];
            abcd[4+i] = -1./6.*x[4*i] -2.*x[4*i+1] +8./3.*x[4*i+2] -1./2.*x[4*i+3];
            abcd[6+i] = x[4*i+1];
        }

        return abcd;
    }

    std::vector<double> DistributedMesh::_compBsplineEqPreBF(DistributedMesh* dismesh, vector<int> vC, int el)
    {
        std::vector<int> cnn = dismesh->_connec->getNborList(el, IndexType::Local);
        std::vector<double> knts = dismesh->_uKnot;
        int inex = el;
        int offU = 0;

        for(int i = 0; i < (int)vC.size(); i++)
        {
            if (inex < vC[i])
            {
                break;
            }
            offU += 7;
        }
        double t0 = knts[el+3+offU];
        double t1 = knts[el+4+offU];

        double t_inc = 0.5*(t1-t0);
        double t_mean = 0.5*(t1+t0);
        std::vector<double> t(6);
        for (int i = 0; i < 6; i++)
        {
            t[i] = knts[el+i+1+offU];
        }
        
        vector<double> px(4);
        vector<double> py(4);
        for (int i = 0; i < 4; i++)
        {
            std::vector<double> nCoords = dismesh->nodeCoords(cnn[i],IndexType::Local);
            px[i] = nCoords[0];
            py[i] = nCoords[1];
        }

        // Return the parameters ai bi ci di that form the polynomial i = ai*t^3+bi*t^2+ci*t+di*t where i = x,y
        double D03=1./((t[3]-t[0])*(t[3]-t[1])*(t[3]-t[2]));
        double D131=1./((t[3]-t[0])*(t[3]-t[1])*(t[3]-t[2]));
        double D132=1./((t[4]-t[1])*(t[3]-t[1])*(t[3]-t[2]));
        double D133=1./((t[4]-t[1])*(t[4]-t[2])*(t[3]-t[2]));
        double D231=1./((t[4]-t[1])*(t[3]-t[1])*(t[3]-t[2]));
        double D232=1./((t[4]-t[1])*(t[4]-t[2])*(t[3]-t[2]));
        double D233=1./((t[5]-t[2])*(t[4]-t[2])*(t[3]-t[2]));
        double D33=1./((t[5]-t[2])*(t[4]-t[2])*(t[3]-t[2]));
        vector<double> N03 = {-D03,D03*3.*t[3],-D03*3.*t[3]*t[3],D03*t[3]*t[3]*t[3]};
        vector<double> N131 = {D131,D131*(-t[0]-2.*t[3]),D131*(t[3]*t[3]+2.*t[3]*t[0]),D131*(-t[3]*t[3]*t[0])};
        vector<double> N132 = {D132,D132*(-t[1]-t[3]-t[4]),D132*(t[1]*t[3]+t[1]*t[4]+t[3]*t[4]),D132*(-t[1]*t[3]*t[4])};
        vector<double> N133 = {D133,D133*(-t[2]-2.*t[4]),D133*(t[4]*t[4]+2.*t[4]*t[2]),D133*(-t[4]*t[4]*t[2])};
        vector<double> N231 = {-D231,D231*(2.*t[1]+t[3]),D231*(-t[1]*t[1]-2.*t[1]*t[3]),D231*(t[1]*t[1]*t[3])};
        vector<double> N232 = {-D232,D232*(t[1]+t[2]+t[4]),D232*(-t[1]*t[2]-t[1]*t[4]-t[2]*t[4]),D232*(t[1]*t[2]*t[4])};
        vector<double> N233 = {-D233,D233*(2.*t[2]+t[5]),D233*(-t[2]*t[2]-2.*t[2]*t[5]),D233*(t[2]*t[2]*t[5])};
        vector<double> N33 = {D33,-D33*3.*t[2],D33*3.*t[2]*t[2],-D33*t[2]*t[2]*t[2]};

        vector<double> abcd(8);
        for (int i = 0; i < 4; i++)
        {
            abcd[2*i] = N03[i]*px[0]+(N131[i]+N132[i]+N133[i])*px[1]+(N231[i]+N232[i]+N233[i])*px[2]+N33[i]*px[3];
            abcd[2*i+1] = N03[i]*py[0]+(N131[i]+N132[i]+N133[i])*py[1]+(N231[i]+N232[i]+N233[i])*py[2]+N33[i]*py[3];
        
        }

        vector<double> abcdOld = abcd;
        // Shift according to position on the curve and t1-t0 lenght
        abcd[0] = abcdOld[0]*(t_inc*t_inc*t_inc);
        abcd[2] = abcdOld[0]*(t_inc*t_inc)*3.*t_mean+abcdOld[2]*(t_inc*t_inc);
        abcd[4] = abcdOld[0]*(t_inc)*3.*t_mean*t_mean+abcdOld[2]*(t_inc)*2.*t_mean+abcdOld[4]*t_inc;
        abcd[6] = abcdOld[0]*t_mean*t_mean*t_mean+abcdOld[2]*t_mean*t_mean+abcdOld[4]*t_mean+abcdOld[6];

        abcd[1] = abcdOld[1]*(t_inc*t_inc*t_inc);
        abcd[3] = abcdOld[1]*(t_inc*t_inc)*3.*t_mean+abcdOld[3]*(t_inc*t_inc);
        abcd[5] = abcdOld[1]*(t_inc)*3.*t_mean*t_mean+abcdOld[3]*(t_inc)*2.*t_mean+abcdOld[5]*t_inc;
        abcd[7] = abcdOld[1]*t_mean*t_mean*t_mean+abcdOld[3]*t_mean*t_mean+abcdOld[5]*t_mean+abcdOld[7];

        return abcd;
    }

    int DistributedMesh::_computeNumberOfBoundaryElements()
    {
        int locBElems{};
        for (int locElem = 0; locElem < loc_nElem(); locElem++)
        {
            // Get neighbors
            vector<int> nbors = _connec->getNborList(locElem, IndexType::Local);

            // Loop through boundaries
            for (auto n: nbors)
            {
                bool belem{false};
                if (_vMAx.empty())
                {
                    if (nodeCrease(n, IndexType::Global) > 0)
                        belem = true;
                }
                else
                {
                    int ax = nodeMAxis(n, IndexType::Global);
                    for (auto a: _vMAx)
                    {
                        if (ax%getMAxis(a) == 0)
                        {
                            belem = true;
                            break;
                        }
                    }
                }

                // Break if boundary element
                if (belem)
                {
                    locBElems++;
                    break;
                }
            }
        }

        return locBElems;
    }

    vector<int> DistributedMesh::_computeImmersedCornerFlags(vector<vector<double>> &cornerGlobCoords, int elemID, IndexType type)
    {
        /*************************************************************************/
        /* This functions returns the back mesh corner flag (0 for out, 1 for    */
        /* inside of the physical domain, and 2 for on the boundary). Also this  */
        /* function saves the global coordinates of the corners.                 */
        /*************************************************************************/

        // Checks
        if (_immSegments.empty())
        {
            throw runtime_error("DistributedMesh::_computeImmersedCornerFlags: _immSegments is empty.");
        }
        if (_pDim == 3 and elemType() != ElemType::Parallelep)
        {
            throw runtime_error("DistributedMesh::_computeImmersedCornerFlags: Back mesh can only be parallelep for 3D immersed problems.");
        }
        if (_pDim == 2 and elemType() != ElemType::Square)
        {
            throw runtime_error("DistributedMesh::_computeImmersedCornerFlags: Back mesh can only be square for 2D immersed problems.");
        }

        // Find the reference coordinate of the corners of the element
        vector<vector<double>> refCorners = referenceCoordsElemCorners(elemType());

        // Resizing the cornerGlobCoords with respect to the problem dimension
        cornerGlobCoords.resize(refCorners.size());

        // Loop over the corners and get the global coordinate of the corner
        for (size_t i{}; i < refCorners.size(); ++i)
        {
            cornerGlobCoords[i] = interpolatePosition(elemID, refCorners[i], type);
        }

        return _computeImmersedCornerFlags(cornerGlobCoords);
    }

    vector<int> DistributedMesh::_computeImmersedCornerFlags(vector<vector<double>> cornerGlobCoords)
    {
        /*************************************************************************/
        /* This functions returns the back mesh corner flag (0 for out, 1 for    */
        /* inside of the physical domain, and 2 for on the boundary) for a       */
        /* given global coordinates of corners of an element.                    */
        /*************************************************************************/

        // Checks
        if (_immSegments.empty())
        {
            throw runtime_error("DistributedMesh::_computeImmersedCornerFlags: _immSegments is empty.");
        }
        if (_pDim == 1)
        {
            throw runtime_error("DistributedMesh::_computeImmersedCornerFlags 1D immersed method is not implemented.");
        }

        vector<int> cornerFlags;
        if (_pDim == 2) // 2D immersed method
        {
            cornerFlags.resize(cornerGlobCoords.size(), 0); // resize and initialize to zero
            // Check if a ray to right infinity from corner intersects with the immersed mesh.
            // -------------------------------------------------------------------------------
            /*
            2        3
            o--------o
            |        |
            |        |
            |        |
            o--------o
            0        1
            */
            for (size_t l{}; l < cornerGlobCoords.size(); ++l) // loop over the corners
            {
                // Compute the number of intersection of the ray from this corner with the immersed mesh
                int numIntersection = 0;
                bool onImmersedMesh = false;

                if(_childMesh->basisFunctionType() == BasisFuncType::Lagrangian)
                {
                    for (size_t i = 0; i < (_immSegments.size() / 6); ++i)
                    {
                        double xStart = _immSegments[6 * i + 0];
                        double yStart = _immSegments[6 * i + 1];
                        double xEnd = _immSegments[6 * i + 3];
                        double yEnd = _immSegments[6 * i + 4];

                        // Check if the corner lies on the boundary
                        if (SGeometry::tripletOrientation2D({ xStart, yStart }, cornerGlobCoords[l], { xEnd, yEnd }) == 0)
                        {
                            if (SGeometry::isOnSegment({ xStart, yStart, 0. }, cornerGlobCoords[l], { xEnd, yEnd, 0. }))
                            {
                                cornerFlags[l] = 2;
                                onImmersedMesh = true;
                                break;
                            }
                            if (min(SGeometry::distanceTwoPoints({xStart, yStart, 0.}, cornerGlobCoords[l]),SGeometry::distanceTwoPoints({xEnd, yEnd, 0.}, cornerGlobCoords[l])) < 1e-14)
                            {
                                cornerFlags[l] = 2;
                                onImmersedMesh = true;
                                break;
                            }
                        }

                        if (((cornerGlobCoords[l][1] <= yStart) == (cornerGlobCoords[l][1] > yEnd)) and
                            (cornerGlobCoords[l][0] - xStart - (cornerGlobCoords[l][1] - yStart) * (xEnd - xStart) / (yEnd - yStart)) < 0)
                        {
                            numIntersection++;
                        }
                    }
                    if (!onImmersedMesh)
                    {
                        cornerFlags[l] = numIntersection % 2;
                    }
                }
                else if (_childMesh->basisFunctionType() == BasisFuncType::BSplines)
                {
                    // cout << "Immsegments size: "<< _immSegments.size() << endl;
                    vector<vector<double>> dupl{};
                    for (size_t i = 0; i < (_immSegments.size() / 8); ++i)
                    {
                        // compute where y(t) crosses yCrnrCoord
                        vector<double> abcdx = {_immSegments[8*i],_immSegments[8*i+2],_immSegments[8*i+4],_immSegments[8*i+6]};
                        vector<double> abcdy = {_immSegments[8*i+1],_immSegments[8*i+3],_immSegments[8*i+5],_immSegments[8*i+7]};

                        vector<double> tsols = SGeometry::cubicLineIntersect(abcdy, cornerGlobCoords[l][1]);
                        for(double sol:tsols)
                        {
                            if ((sol>=-1.001) and (sol<=1.001))
                            {
                                bool repeated = 0;
                                double xSol = abcdx[0]*sol*sol*sol + abcdx[1]*sol*sol + abcdx[2]*sol + abcdx[3];
                                double ySol = abcdy[0]*sol*sol*sol + abcdy[1]*sol*sol + abcdy[2]*sol + abcdy[3];
                                if ((fabs(sol)>0.9))
                                {
                                    for(vector<double> oldCoord:dupl)
                                    {
                                        double diff = sqrt((oldCoord[0]-xSol)*(oldCoord[0]-xSol)+(oldCoord[1]-ySol)*(oldCoord[1]-ySol));
                                        if (diff < 1e-3)
                                        {
                                            repeated = 1;
                                        }
                                    }
                                    vector<double>coordSol = {xSol,ySol};
                                    dupl.push_back(coordSol);
                                }
                                if(xSol>cornerGlobCoords[l][0] and !repeated)
                                {
                                    numIntersection++;
                                }
                            }
                        }
                    }
                    cornerFlags[l] = numIntersection % 2;
                }
            }
        }
        else if(_pDim == 3)
        {
            cornerFlags.resize(8, 0); // resize and initialize to zero
            // corner numbering
            // xMin yMin zMin : 0
            // xMax yMin zMin : 1
            // xMin yMax zMin : 2
            // xMax yMax zMin : 3
            // xMin yMin zMax : 4
            // xMax yMin zMax : 5
            // xMin yMax zMax : 6
            // xMax yMax zMax : 7

            // Create a set of vertices of immersed mesh
            set<vector<double>> immVertices;
            for (size_t i = 0; i < (_immSegments.size() / 9); ++i)
            {
                vector<double> pt0 = {_immSegments[9 * i + 0], _immSegments[9 * i + 1], _immSegments[9 * i + 2]};
                vector<double> pt1 = {_immSegments[9 * i + 3], _immSegments[9 * i + 4], _immSegments[9 * i + 5]};
                vector<double> pt2 = {_immSegments[9 * i + 6], _immSegments[9 * i + 7], _immSegments[9 * i + 8]};
                immVertices.insert(pt0);
                immVertices.insert(pt1);
                immVertices.insert(pt2);
            }

            for (size_t l{}; l < cornerGlobCoords.size(); ++l) // loop over the corners
            {
                // Compute the number of intersection of the ray from this corner with the immersed mesh
                bool onImmersedMesh = false;
                double numIntersection = 0;
                for (size_t i = 0; i < (_immSegments.size() / 9); ++i)
                {
                    vector<double> pt0 = {_immSegments[9 * i + 0], _immSegments[9 * i + 1], _immSegments[9 * i + 2]};
                    vector<double> pt1 = {_immSegments[9 * i + 3], _immSegments[9 * i + 4], _immSegments[9 * i + 5]};
                    vector<double> pt2 = {_immSegments[9 * i + 6], _immSegments[9 * i + 7], _immSegments[9 * i + 8]};

                    // Check if the corner lies on the boundary
                    if (SGeometry::isOnPlane(cornerGlobCoords[l], pt0, pt1, pt2))
                    {
                        if (SGeometry::isPointInside3DTriangle(cornerGlobCoords[l], pt0, pt1, pt2))
                        {
                            cornerFlags[l] = 2;
                            onImmersedMesh = true;
                            break;
                        }
                    }

                    // Find min X coordinate of pt0, pt1, and pt2
                    vector<double> xCoords = {pt0[0], pt1[0], pt2[0]};
                    auto minX = min_element(xCoords.begin(), xCoords.end());

                    if (cornerGlobCoords[l][0] < *minX)
                    {
                        // Create the yz projection of the immersed element and back mesh corner
                        vector<vector<double>> yzProjImmSeg = { {pt0[1], pt0[2]}, {pt1[1], pt1[2]}, { pt2[1], pt2[2]} };
                        vector<double> yzProjCorner = {cornerGlobCoords[l][1], cornerGlobCoords[l][2]};
                        int positionFlag = SGeometry::pointPositionInPolygon(yzProjImmSeg, yzProjCorner);
                        if ( positionFlag == 1)
                        {
                            numIntersection++;
                        }
                        else if (positionFlag == 2)
                        {
                            numIntersection += 0.5;
                        }
                    }
                }

                // Checking for intersection of a ray from corner to the immersed vertices
                for (auto v : immVertices)
                {
                    if (cornerGlobCoords.at(l).at(0) < v.at(0) and cornerGlobCoords.at(l).at(1) == v.at(1) and cornerGlobCoords.at(l).at(2) == v.at(2))
                    {
                        numIntersection++;
                    }
                }

                // Deciding based on number of intersection of rays
                if (!onImmersedMesh)
                {
                    cornerFlags[l] = static_cast<int>(numIntersection) % 2;
                }
            }

        }

        return cornerFlags;
    }

    vector<int> DistributedMesh::_immersedCornerFlags(int elementID, IndexType type)
    {
        if (!_immCornerFlags.empty())
        {
            if (type == IndexType::Global)
            {
                int localElemID = elementID - _connec->offs_nItem();
                vector<int> localCornerFlags(_immCornerFlags[localElemID].begin() + 1, _immCornerFlags[localElemID].end());
                return localCornerFlags;
            }
            else if (type == IndexType::Local)
            {
                vector<int> localCornerFlags(_immCornerFlags[elementID].begin() + 1, _immCornerFlags[elementID].end());
                return localCornerFlags;
            }
            else
            {
                throw runtime_error("DistributedMesh::_immersedCornerFlags: Working for IndexType of 'Global' and 'Local' only.");
            }
        }
        else
        {
            throw runtime_error("DistributedMesh::_immersedCornerFlags: _immCornerFlags is empty.");
        }
    }

    int DistributedMesh::_computeBackElementFlag(vector<vector<double>> cornerGlobCoords, vector<int> cornerFlags)
    {
        if (_pDim == 2)
        {
            // Defining element edges with its corners
            vector<int> elementEdges = { 0, 1, 3, 2, 0 };

            // Loop over all edges of the element and check for any intersections with the immersed mesh
            for (size_t i = 0; i < elementEdges.size() - 1; ++i)
            {
                vector<vector<double>> edge = { cornerGlobCoords[elementEdges[i]], cornerGlobCoords[elementEdges[i + 1]] };
                for (size_t j = 0; j < (_immSegments.size() / 6); ++j)
                {
                    double xStart = _immSegments[6 * j + 0];
                    double yStart = _immSegments[6 * j + 1];
                    double zStart = _immSegments[6 * j + 2];
                    double xEnd = _immSegments[6 * j + 3];
                    double yEnd = _immSegments[6 * j + 4];
                    double zEnd = _immSegments[6 * j + 5];
                    vector<vector<double>> segment = { {xStart, yStart, zStart}, {xEnd, yEnd, zEnd} };
                    if (SGeometry::doesIntersect(edge, segment))
                    {
                        return 2;
                    }
                }
            }
            // If none of the edges of the element is cut by the immersed mesh this element still may be a cut element.
            // Geometry may pass only through the vertices of the element so let's check the corner status.
            if ((cornerFlags[0] == 2 and cornerFlags[3] == 2 and cornerFlags[1] != 2 and cornerFlags[2] != 2) or
                (cornerFlags[1] == 2 and cornerFlags[2] == 2 and cornerFlags[0] != 2 and cornerFlags[3] != 2))
            {
                return 2;
            }

            if ((cornerFlags[0] == 1 or cornerFlags[0] == 2) and
                (cornerFlags[1] == 1 or cornerFlags[1] == 2) and
                (cornerFlags[2] == 1 or cornerFlags[2] == 2) and
                (cornerFlags[3] == 1 or cornerFlags[3] == 2))
            {
                return 1;
            }

            return 0;
        }
        else if (_pDim == 3)
        {
            // Create (numberOfRays x numberOfRays) line on xMin to xMax, yMin to yMax, zMin to zMax faces of the element
            int numberOfRays = 5;

            vector<vector<double>> xMinPts = SGeometry::distributedPointsOnSquare(cornerGlobCoords[0], cornerGlobCoords[2], cornerGlobCoords[4], numberOfRays, numberOfRays);
            vector<vector<double>> xMaxPts = SGeometry::distributedPointsOnSquare(cornerGlobCoords[1], cornerGlobCoords[3], cornerGlobCoords[5], numberOfRays, numberOfRays);

            vector<vector<double>> yMinPts = SGeometry::distributedPointsOnSquare(cornerGlobCoords[0], cornerGlobCoords[1], cornerGlobCoords[4], numberOfRays, numberOfRays);
            vector<vector<double>> yMaxPts = SGeometry::distributedPointsOnSquare(cornerGlobCoords[2], cornerGlobCoords[3], cornerGlobCoords[6], numberOfRays, numberOfRays);

            vector<vector<double>> zMinPts = SGeometry::distributedPointsOnSquare(cornerGlobCoords[0], cornerGlobCoords[1], cornerGlobCoords[2], numberOfRays, numberOfRays);
            vector<vector<double>> zMaxPts = SGeometry::distributedPointsOnSquare(cornerGlobCoords[4], cornerGlobCoords[5], cornerGlobCoords[6], numberOfRays, numberOfRays);

            // Check for intersection of immersed mesh with elements rays
            for (size_t i{}; i < yMinPts.size(); ++i)
            {
                for (size_t j{}; j < (_immSegments.size() / 9); ++j)
                {
                    // Extract immersed element vertices
                    vector<double> p0 = { _immSegments[9 * j + 0], _immSegments[9 * j + 1], _immSegments[9 * j + 2] };
                    vector<double> p1 = { _immSegments[9 * j + 3], _immSegments[9 * j + 4], _immSegments[9 * j + 5] };
                    vector<double> p2 = { _immSegments[9 * j + 6], _immSegments[9 * j + 7], _immSegments[9 * j + 8] };
                    // Check for intersection
                    if (SGeometry::doesLineIntersect3DTriangle(xMinPts[i], xMaxPts[i], p0, p1, p2) or
                        SGeometry::doesLineIntersect3DTriangle(yMinPts[i], yMaxPts[i], p0, p1, p2) or
                        SGeometry::doesLineIntersect3DTriangle(zMinPts[i], zMaxPts[i], p0, p1, p2))
                    {
                        return 2;
                    }
                }
            }
            if ((cornerFlags[0] == 1 or cornerFlags[0] == 2) and
                (cornerFlags[1] == 1 or cornerFlags[1] == 2) and
                (cornerFlags[2] == 1 or cornerFlags[2] == 2) and
                (cornerFlags[3] == 1 or cornerFlags[3] == 2) and
                (cornerFlags[4] == 1 or cornerFlags[4] == 2) and
                (cornerFlags[5] == 1 or cornerFlags[5] == 2) and
                (cornerFlags[6] == 1 or cornerFlags[6] == 2) and
                (cornerFlags[7] == 1 or cornerFlags[7] == 2))
            {
                return 1;
            }

            return 0;
        }
        else
        {
            throw runtime_error("DistributedMesh::_computeBackElementFlag: 1D Immersed method is not implemented. Immersed method works only with\
                                 parallelep and square elements as back elements.");
        }
    }

    vector<int> DistributedMesh::_createImmersedFlags()
    {
        // Get the mapping
        RCP<MeshMap_Immersed> tmpParMap = rcp_dynamic_cast<MeshMap_Immersed>(_childMesh->_mapToParent);
        RCP<MeshMap_Immersed> mapToChild = rcp_dynamic_cast<MeshMap_Immersed>(tmpParMap->generateInverse());

        // Save map to child
        _mapToChild = rcp_dynamic_cast<MeshMap>(mapToChild);

        // Get number of local back elements from backMesh
        int numLocalElems = loc_nElem();

        // Create vector of immersed flags (0: exterior, 1:interior, 2:cut)
        vector<int> immEFlags(numLocalElems, 0);
        _immCornerFlags.resize(numLocalElems);

        // Cut element flags
        for (auto k: mapToChild->_keys)
        {
            immEFlags[k] = 2;
        }

        // Loop over all back mesh elements and find the status of the corners of that element
        for (int e = 0; e < numLocalElems; ++e)
        {
            vector<vector<double>> cornerGlobalCoords;
            vector<int> cornerFlags = _computeImmersedCornerFlags(cornerGlobalCoords, e, IndexType::Local); // called from backMesh
            _immCornerFlags[e].resize(cornerFlags.size() + 1);
            _immCornerFlags[e][0] = e;
            for (size_t i = 1; i <= cornerFlags.size(); ++i)
            {
                _immCornerFlags[e][i] = cornerFlags[i - 1];
            }

            if (immEFlags[e] != 2)
            {
                int nInterior = std::count(cornerFlags.cbegin(), cornerFlags.cend(), 1);
                if (nInterior > 1)
                {
                    immEFlags[e] = 1;
                }
            }
        }

        return immEFlags;
    }

    void DistributedMesh::_checkInteriorPoints(vector<int>& immEFlags)
    {
        // Check which element contains the inside point that user passed and check whether everything is ok or not
        // If the user-passed point is defined as exterior element reverse tags of exterior and inner elements
        // --------------------------------------------------------------------------------------------------------
        vector<int> localInPtStatus(_interiorPoints[0].size(), 0); // 0 means the user-passed point is consistent with what is assumed

        if (_interiorPoints.size()>1)
        {
            throw runtime_error("\nDistributedMesh::_createImmersedFlags: More than one region defined without setting labels.\n");
        }
        for (size_t i = 0; i < _interiorPoints[0].size(); ++i) // Loop over all user-passed interior points
        {
            int inPtGlobElemID{};    // Stores the global element number on which the point exists
            vector<double> rCoords;  // Stores the reference coordinates of the point within the element
            searchElement(inPtGlobElemID, rCoords, _interiorPoints[0][i]);
            if (isElemInPart(inPtGlobElemID))
            {
                int inPtLocElemID{};  // Stores the local element number on which the point exists
                inPtLocElemID = inPtGlobElemID - _connec->offs_nItem(); // convert global element ID to local
                if (immEFlags[inPtLocElemID] == 0)
                {
                    localInPtStatus[i] = 1;
                }
            }
        }


        // Share localInPtStatus
        vector<int> globalInPtStatus(_interiorPoints[0].size(), 0);
        MPI_Allreduce(localInPtStatus.data(), globalInPtStatus.data(), localInPtStatus.size(), MPI_INT, MPI_MAX, MPI_COMM_WORLD);

        // If there were more than one interior point check if the interior points are consistent with each other or not
        if (globalInPtStatus.size() > 1)
        {
            if (!(equal(globalInPtStatus.begin() + 1, globalInPtStatus.end(), globalInPtStatus.begin())))
            {
                throw runtime_error("\nDistributedMesh::_createImmersedFlags: The passed interior points are not consistent with each other.\n");
            }
        }

        // Reverse the element if applicable
        if (globalInPtStatus[0] == 1)
        {
            for (int i = 0; i < loc_nElem(); ++i)
            {
                // Reverse element flags
                if (immEFlags[i] == 0)
                {
                    immEFlags[i] = 1;
                }
                else if (immEFlags[i] == 1)
                {
                    immEFlags[i] = 0;
                }

                // Reverse corner flags
                for (size_t j = 0; j < _immCornerFlags[i].size(); j++)
                {
                    if (_immCornerFlags[i][j] == 0)
                    {
                        _immCornerFlags[i][j] = 1;
                    }
                    else if (_immCornerFlags[i][j] == 1)
                    {
                        _immCornerFlags[i][j] = 0;
                    }
                }
            }
        }
    }

    std::vector<int> DistributedMesh::_updateCornerTag(vector<int>& immEFlags, set<int>& immTouched, int ini, int userTag, int el, IndexType type)
    {
        vector<int> vNborEls{};
        if (immTouched.find(el) == immTouched.end())
        {
            // Add element to touched set
            immTouched.insert(el);
            // Get corner flags and node ids
            vector<int> cornerFlags = _immCornerFlags[el];
            vector<int> elNodeNbors = _getElementCornerNodes(el,IndexType::Global);
            bool immEFlagsUpdated = 0;

            // Loop over corners (cornerFlags[0] is the element id, corners are 1..4)
            for (size_t i = 0; i < cornerFlags.size()-1; ++i)
            {
                // If corner belongs to current region
                if(cornerFlags[i+1] == ini or cornerFlags[i+1] == userTag)
                {
                    // Change node flag to region flag
                    cornerFlags[i+1] = userTag;
                    _immCornerFlags[el][i+1] = userTag;

                    // Get element nbors and loop over them
                    std::vector<int> elNbrs = elemNbors(el,type);
                    for (int el2:elNbrs)
                    {
                        // If nbor element not visited
                        if (immTouched.find(el2) == immTouched.end())
                        {
                            // Check if nbor shares current corner and return them
                            std::vector<int> el2NodeNbors = _connec->getNborList(el2);

                            if (find(el2NodeNbors.begin(), el2NodeNbors.end(), elNodeNbors[i]) != el2NodeNbors.end())
                            {
                                vNborEls.push_back(el2);
                            }                                
                        }
                    }
                }
            }
        }
        return vNborEls;
    }

    void DistributedMesh::reconnectImmersedChild(RCP<DistributedMesh> parentMesh,
                                                  std::vector<std::string> regionTags,
                                                  std::vector<std::vector<std::vector<double>>> interiorPoints)
    {
        // This replays the ImmersedBoundary-specific bookkeeping that Update()
        // performs when this mesh is built from a MeshCreator (see the
        // _meshRel == MeshRelation::ImmersedBoundary branches in
        // DistributedMesh::Update()), skipping only the creation of
        // _mapToParent: that map is part of the serialized mesh data and is
        // expected to already be set on both meshes by their own prior
        // Update() call (via setFilePrefix()/setIStream()).
        _meshRel = MeshRelation::ImmersedBoundary;
        _parentMesh = parentMesh;
        _userTags = regionTags;
        _interiorPoints = interiorPoints;

        _parentMesh->_setChildMesh(this);
        _parentMesh->_shareImmersedSegments();

        _parentMesh->setRegionTags(_userTags);
        _parentMesh->setImmersedInteriorPoints(_interiorPoints);
        _parentMesh->_createElemFlagsForImmersed();
        _parentMesh->_saveMapToChild();

        if (_userTags.size() == 0)
            _parentMesh->_createCutBFStruts();
        else
            _parentMesh->_createCutBFStrutsRegions();
    }

    void DistributedMesh::_createElemFlagsForImmersed()
    {
        // Create immersed flags
        vector<int> immEFlags = _createImmersedFlags();

        if (_userTags.size() == 0)
        {
            // Check interior point
            _checkInteriorPoints(immEFlags);
        }
        else
        {
            for (int i{}; i < immEFlags.size(); i++)
            {
                if (immEFlags[i] == 0)
                    immEFlags[i] = 1;
            }

            // Change tags to user defined
            vector<int> tagsInternal = {3,5,7,11};
            for (int i{}; i < _userTags.size(); i++)
            {
                vector<int> rayTag = _computeImmersedCornerFlags(_interiorPoints[i]);
                for (int j{}; j < _interiorPoints[i].size(); j++)
                {
                    int ini = rayTag[j];
                    int tag = tagsInternal[i];
                    int elID{};
                    vector<double> rCoords;
                    searchElement(elID, rCoords, _interiorPoints[i][j]);

                    set<int> immTouched{}; 
                    vector<int> nborEls  = _updateCornerTag(immEFlags, immTouched, ini, tag, elID, IndexType::Global);
                    while (nborEls.size()>0)
                    {
                        vector<int> nborElsOld = nborEls;
                        nborEls.clear();
                        for(int el:nborElsOld)
                        {
                            vector<int> nborEls0  = _updateCornerTag(immEFlags, immTouched, ini, tag, el, IndexType::Global);
                            for(int el0:nborEls0)
                            {
                                nborEls.push_back(el0);
                            }
                        }

                    }
                }
            }

            for (int el{};el<loc_nElem();el++)
            {
                vector<int> cornerFlags = _immCornerFlags[el];
                set<int> rgns{};
                for(int i = 1;i< cornerFlags.size();i++)
                    rgns.insert(cornerFlags[i]);
                
                for(int flg:rgns)
                {
                    if (flg != 2)
                        immEFlags[el] *= flg; 
                }
            }

            // Fix elements that have nodes in one region but have a boundary
            bool elChanged = 1;
            // while (elChanged)
            {
                elChanged = 1;
                for(int e{}; e < loc_nElem(); e++)
                {
                    if (immEFlags[e]%2 == 0)
                    {
                        int nRegions = 0;
                        int tempRegion = -1;
                        for (int itag:tagsInternal)
                        {
                            if (immEFlags[e]%itag == 0)
                            {
                                nRegions += 1;
                                tempRegion = itag;
                            }
                        }
                        if (nRegions == 1)
                        {
                            std::vector<int> elNbrs = elemNbors(e);
                            elChanged = 1;
                            bool itagChanged = 0;
                            for (int e2 : elNbrs)
                            {
                                for (int itag :tagsInternal)
                                {
                                    if (immEFlags[e2]%itag == 0 && itag != tempRegion)
                                    {
                                        immEFlags[e] *= itag;
                                        itagChanged = 1;
                                        break;
                                    }
                                }
                                if (itagChanged)
                                    break;
                            }

                        }
                        else if (nRegions != 2)
                        {
                            std::cout << "WARNING: ELEMENT "<< e << " WITH "<< nRegions << " REGION/S" << endl;
                        }
                    }
                }
            }

            // Fix elements that have no boundary but two regions
            for(int e{}; e < loc_nElem(); e++)
            {
                if (immEFlags[e]%2 != 0)
                {
                    int nRegions = 0;
                    for (int itag:tagsInternal)
                    {
                        if (immEFlags[e]%itag == 0)
                        {
                            nRegions += 1;
                        }
                    }
                    if (nRegions > 1)
                    {
                        std::vector<int> elNbrs = _findFacetAdjacentElements(e, IndexType::Global);
                        int tmpRegion = -1;
                        vector<int> cRegion(tagsInternal.size(),0);
                        // cout << elNbrs.size() << endl;
                        for (int e2 : elNbrs)
                        {
                            for (int itag{};itag < tagsInternal.size();itag++)
                                if (immEFlags[e2]%tagsInternal[itag] == 0)
                                    cRegion[itag] += 1;
                        }
                        // cout <<"Element: " << e <<" "<<  cRegion[0] << " " << cRegion[1] << " " << cRegion[2] << endl; 
                        for (int itag{};itag < tagsInternal.size();itag++)
                        {
                            if (cRegion[itag] == 4)
                                immEFlags[e] = tagsInternal[itag];
                        }
                        // cout << "Elem: " << e << ": "<< immEFlags[e]<< endl;
                    }
                }
            }

            // Element and corner flags from the exact areas of the regions in each element, on the polyline of the
            // immersed curves (the geometry of the cut-cell cubature and of the aggregation): an element is cut if
            // two or more regions have area in it. The ray casting of the corner flags and the fixes above go wrong
            // when a curve is tangent to a mesh line or passes through a node
            if (_buildImmersedCurves())
            {
                const double minFraction = 1e-10; // below roundoff of the fractions: the region is not in the element
                for (int e = 0; e < loc_nElem(); e++)
                {
                    vector<double> fractions = _cutCellRegionFractions(e);
                    int flag = 1;
                    int nRegions = 0;
                    for (size_t iTag = 0; iTag < fractions.size(); iTag++)
                    {
                        if (fractions[iTag] > minFraction)
                        {
                            flag *= tagsInternal[iTag];
                            nRegions++;
                        }
                    }
                    if (nRegions > 1)
                        flag *= 2;
                    immEFlags[e] = flag;

                    vector<double> crnrs = _elemNborCornerCoords(e, IndexType::Local);
                    for (int i = 0; i < 4; i++)
                    {
                        int iTag = _immRegionOfPoint(crnrs[3*i], crnrs[3*i+1]);
                        if (iTag != -1)
                            _immCornerFlags[e][i+1] = tagsInternal[iTag];
                    }
                }
            }
        }

        // Create vector with element flags //FIXME:: Add a function to Fields to add a new field
        _nEFlags = 2;
        vector<int> tmp_eflags(_nEFlags * loc_nElem());
        for (int e = 0; e < loc_nElem(); e++)
        {
            tmp_eflags[e] = _elemFlags->getValue(0, e, IndexType::Local);
        }
        std::copy(immEFlags.begin(), immEFlags.end(), tmp_eflags.begin() + loc_nElem());

        // Update element flags
        setDistElemFlags(tmp_eflags);
        _elemFlags = Teuchos::null;
        _elemFlags = rcp(new IntFieldStruct("elemFlags", _comm));
        Epetra_Map elemMap(-1, loc_nElem(), 0, epComm());
        _elemFlags->setBlockMap(elemMap);
        _elemFlags->setNFlds(_nEFlags);
        _elemFlags->setDistFields(_tmp_distElemFlags);
        _elemFlags->Update();

        // Create element ghosts1;
        vector<int> ghostElems;
        for (int loc_elem = 0; loc_elem < loc_nElem(); loc_elem++)
        {
            vector<int> nborNodes = _connec->getNborList(loc_elem, IndexType::Local);
            for (size_t i = 0; i < nborNodes.size(); i++)
            {
                int numElemNbors = _adjcyNE->getNumNbors(nborNodes[i]);
                for (int j = 0; j < numElemNbors; j++)
                {
                    int nborElem = _adjcyNE->getNbor(nborNodes[i], j);
                    if (not _connec->isItemInPart(nborElem))
                        ghostElems.push_back(nborElem);
                }
            }
        }

        // Remove element ghost duplicates
        sort(ghostElems.begin(), ghostElems.end());
        ghostElems.erase(unique(ghostElems.begin(), ghostElems.end()), ghostElems.end());

        // Update element ghosts flags
        _elemFlags->UpdateGhosts(ghostElems);
    }

    void DistributedMesh::_saveMapToChild()
    {
        // FIXME: Why all the rcp_dynamic_cast???
        if (_childMesh->_meshRel == MeshRelation::ImmersedBoundary or
                 _childMesh->_meshRel == MeshRelation::ImmersedMesh)
        {
            // Get the mapping
            RCP<MeshMap_Immersed> tmpParMap = rcp_dynamic_cast<MeshMap_Immersed>(_childMesh->_mapToParent);
            RCP<MeshMap_Immersed> mapToChild = rcp_dynamic_cast<MeshMap_Immersed>(tmpParMap->generateInverse());

            // Save map to child
            _mapToChild = rcp_dynamic_cast<MeshMap>(mapToChild);
        }
        else
        {
            throw runtime_error("DistributedMesh::_saveMapToChild: Only implemented for MeshRelation::ImmersedBoundary and MeshRelation::ImmersedMesh");
        }
    }

    void DistributedMesh::_createCutBFStruts()
    {
        vector<int> touchFlags(nElem(), -1);
        // 0 means untouched
        // 1 means touched
        // -1 NA
        for (int globElem{}; globElem < nElem(); ++globElem)
        {
            if (_connec->isItemInPart(globElem))
            {
                if (_elemFlags->getValue(1, globElem, IndexType::Global) == 1)
                {
                    touchFlags.at(globElem) = 1;
                }
                else if (_elemFlags->getValue(1, globElem, IndexType::Global) == 2)
                {
                    touchFlags.at(globElem) = 0;
                }
            }
        }
        
        if(true) // TODO unify threshold with refined elements, (create new element tag for elements inside threshold)
        {
            // Added threshold for aggregated elements. Mark as touched all elements in the boundary
            // that are under the threshold. 
            
            double eta0 = _childMesh->_eta_0; // Minimum portion of the exterior area of the element for it to be considered a root cell.
            for (int globElem{}; globElem < nElem(); ++globElem)
            {
                if (_elemFlags->getValue(1, globElem, IndexType::Global) == 2)
                {
                    // Create grid pts
                    int G_Npts = 10;
                    int G_NNpts = G_Npts*G_Npts;
                    vector<vector<double>> Gpts(2);
                    for (int i = 0; i < G_Npts; i++) 
                    {
                        for (int j = 0; j < G_Npts; j++)
                        {
                            Gpts[0].push_back(((double)i/(double)G_Npts)*2.-1.);
                            Gpts[1].push_back(((double)j/(double)G_Npts)*2.-1.);
                        }
                    }

                    // Param to coords 
                    vector<vector<double>> GCoords(2);
                    vector<int> GptFlag(G_NNpts);
                    for (int j = 0; j < G_NNpts; j++)
                    {
                        vector<double> inInt = {Gpts[0][j], Gpts[1][j],0.};
                        vector<double> resInt = interpolatePosition(globElem, inInt, IndexType::Global);
                        GCoords[0].push_back(resInt[0]);
                        GCoords[1].push_back(resInt[1]);
                    
                        // Check if point inside immersed boundary
                        // Compute the number of intersection of the ray from this corner with the immersed mesh
                        int numIntersection = 0;
                        bool onImmersedMesh = false;
                        for (size_t i = 0; i < (_immSegments.size() / 6); ++i)
                        {
                            double xStart = _immSegments[6 * i + 0];
                            double yStart = _immSegments[6 * i + 1];
                            double xEnd = _immSegments[6 * i + 3];
                            double yEnd = _immSegments[6 * i + 4];

                            // Check if the corner lies on the boundary
                            if (SGeometry::tripletOrientation2D({ xStart, yStart }, resInt, { xEnd, yEnd }) == 0)
                            {
                                if (SGeometry::isOnSegment({ xStart, yStart, 0. }, resInt, { xEnd, yEnd, 0. }))
                                {
                                    GptFlag[j] = 2;
                                    onImmersedMesh = true;
                                    break;
                                }
                            }

                            if (((resInt[1] <= yStart) == (resInt[1] > yEnd)) and
                                (resInt[0] - xStart - (resInt[1] - yStart) * (xEnd - xStart) / (yEnd - yStart)) < 0)
                            {
                                numIntersection++;
                            }
                        }
                        if (!onImmersedMesh)
                        {
                            GptFlag[j] = numIntersection % 2;
                        }
                    }

                    double nIn = 0.;
                    for (int i = 0; i < G_NNpts; i++) 
                    {
                        if(GptFlag[i] > 1)
                        {
                            
                            nIn += 0.5;
                        }
                        else
                        {
                            nIn += (double)GptFlag[i];
                        }
                    }
                    double etaK = 1.-((double)nIn)/(double)G_NNpts;
                    if (etaK > eta0)
                        touchFlags.at(globElem) = 1;
                }
            }
        }
        
        // Create aggregate cells
        unordered_map<int, vector<int>> exteriorBFs = _createAggregateElements(touchFlags);

        // unordered_map<int, vector<int>> exteriorBFs;
        map<pair<int,int>, double> Cold;

        // Create cut basis function structures and add to constraint map
        for (auto itr = exteriorBFs.begin(); itr != exteriorBFs.end(); ++itr)
        {
            // Compute the extrapolation weights
            vector<double> weights {};
            int nMEl = itr->second.size()/nVert();//number of master elements
            for (int t =0; t < nMEl ; t++) // nVert() it gives the number of vertices of one element (disMesh->nVert() if we are in the code)
            {
                vector<int> nrEl(nVert()); // nodes root element
                for (int i = 0; i < nVert(); i++)
                    nrEl[i] = itr->second[nVert()*t+i];
                // vector<int> nrEl = {itr->second[4*t], itr->second[4*t+1], itr->second[4*t+2], itr->second[4*t+3]};// nodes root element
                vector<double> wrEl = _computeExtrapolationWeights(itr->first, nrEl, basisFunctionOrder());// weights root element
                
                
                for (double w : wrEl)
                    weights.push_back(w/(double)nMEl);
            }

            for (int i = 0; i < itr->second.size(); i++)
                Cold[make_pair(itr->first,itr->second[i])] = weights[i];
        }

        unordered_map<int, vector<int>> mapConstraints;

        // Loop for the local nodes to separate them in four sets
        // {Well-Posed Free,Well-Posed Hanging,Ill-posed Free,Well-Posed Hanging}
        set<int> SF, SWF, SWH, SIF, SIH, mastersWH;
        double CH = 0.5;        
        map<pair<int,int>, double> C; // Map for all the constraints (old and new)
        map<int, vector<int>> mastersH; // Map for the old linear constrains from the mesh
        for (int i = 0; i < nPts(); i++)
        { 
            int node = i;
            bool freeNode = 1;
            // FIXME: Only works with h-refined hierarchical constraints.
            for (linearConstraint lCons : _linearConstraints)
            {
                if (lCons.slave == node)
                {
                    freeNode = 0;
                    bool wellPosed = false;
                    int numElemNbors = _adjcyNE->getNumNbors(node);
                    mastersH[node] = lCons.masters;
                    for (int j = 0; j < numElemNbors; j++)
                    {
                        int nborElem = _adjcyNE->getNbor(node, j);
                        if (touchFlags[nborElem] == 1)
                            wellPosed = true;
                    }
                    if (wellPosed)
                    { 
                        SWH.insert(node);
                        C[make_pair(node,lCons.masters[0])] += CH;
                        C[make_pair(node,lCons.masters[1])] += CH;
                        mapConstraints[node] = lCons.masters;
                        mastersWH.insert(lCons.masters[0]);
                        mastersWH.insert(lCons.masters[1]);
                    }
                    else
                    {
                        SIH.insert(node);
                    }
                }
            }
            if (freeNode)
                SF.insert(node);
        }
        
        // Move hanging nodes with only one master to free nodes
        vector<int>  SIHtoIF;
        for (int node : SIH)
        {
            
            bool unusedMaster = 0;
            for (int master : mastersH[node])
            {
                if(find(SF.begin(),SF.end(),master) != SF.end())
                {
                    unusedMaster = 1;
                    break;
                }
            }
            if (unusedMaster)
            {
                SIHtoIF.push_back(node);
            }
        }
        
        for (int node : SIHtoIF)
        {
            SIH.erase(node);
            SIF.insert(node);
        }


        for (int node : SF)
        {
            bool wellPosed = false;
            int numElemNbors = _adjcyNE->getNumNbors(node);
            for (int j = 0; j < numElemNbors; j++)
            {
                int nborElem = _adjcyNE->getNbor(node, j);
                if (touchFlags[nborElem] == 1)
                wellPosed = true;
            }
            if ((wellPosed) || (mastersWH.count(node))) 
            {
                SWF.insert(node);
            }
            else
            {
                SIF.insert(node);
            }
        }
        // Ill posed free ndoes
        for (int node : SIF)
        {
            if (exteriorBFs.count(node))
            {
                vector<int> mastersA = exteriorBFs.at(node);

                for (int node1 : mastersA)
                {
                    if (SWF.count(node1))
                    {
                        // if (C.find(make_pair(node,node1)) == C.end())
                        {
                            C[make_pair(node,node1)] += Cold[make_pair(node,node1)];
                            vector<int> nodeConstraintsVec = mapConstraints[node];
                            if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node1) == nodeConstraintsVec.end())
                                mapConstraints[node].push_back(node1);
                        }

                    }
                    else if (SWH.count(node1))
                    {
                        for (int node2 : mastersH.at(node1))
                        {
                            C[make_pair(node,node2)] += Cold[make_pair(node,node1)]*CH;
                            vector<int> nodeConstraintsVec = mapConstraints[node];
                            if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node2) == nodeConstraintsVec.end())
                                mapConstraints[node].push_back(node2);
                        }
                    }
                }
            }
        }

        // Ill posed hanging nodes
        for (int node : SIH) 
        {
            for (int node1 : mastersH[node])
            {
                if (SWF.count(node1))
                {
                    C[make_pair(node,node1)] += CH;
                    vector<int> nodeConstraintsVec = mapConstraints[node];
                    if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node1) == nodeConstraintsVec.end())
                        mapConstraints[node].push_back(node1);
                }
                else
                {
                    vector<int> mastersA = exteriorBFs[node1];
                    if (mastersA.size() == 0) 
                    {
                        vector<int> mastersATmp = exteriorBFs[node];
                        if (mastersATmp.size() > 0)
                        {

                            vector<double> weightsTmp {};
                            int nMEl = mastersATmp.size()/nVert();//number of master elements
                            for (int t =0; t < nMEl ; t++) // nVert() it gives the number of vertices of one element (disMesh->nVert() if we are in the code)
                            {
                                vector<int> nrEl(nVert()); // nodes root element
                                for (int i = 0; i < nVert(); i++)
                                    nrEl[i] = mastersATmp[nVert()*t+i];
                                // vector<int> nrEl = {mastersATmp[4*t], mastersATmp[4*t+1], mastersATmp[4*t+2], mastersATmp[4*t+3]};// nodes root element
                                vector<double> wrEl = _computeExtrapolationWeights(node1, nrEl, basisFunctionOrder());// weights root element
                                for (double w : wrEl)
                                    weightsTmp.push_back(w/(double)nMEl);
                            }
                            
                            for (int ii = 0; ii < mastersATmp.size(); ii++)
                            {
                                Cold[make_pair(node1,mastersATmp[ii])] = weightsTmp[ii];
                            }
                            mastersA = mastersATmp;
                        }
                    }
                    for (int node2 : mastersA)
                    {
                        if (SWF.count(node2))
                        {
                            // if (C.find(make_pair(node,node2)) == C.end())
                            {
                                C[make_pair(node,node2)] += CH*Cold[make_pair(node1,node2)];
                                vector<int> nodeConstraintsVec = mapConstraints[node];
                                if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node2) == nodeConstraintsVec.end())
                                    mapConstraints[node].push_back(node2);
                            }

                        }
                        else if (SWH.count(node2))
                        {
                            for (int node3 : mastersH.at(node2))
                            {
                                C[make_pair(node,node3)] += CH*Cold[make_pair(node1,node2)]*CH;
                                vector<int> nodeConstraintsVec = mapConstraints[node];
                                if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node3) == nodeConstraintsVec.end())
                                    mapConstraints[node].push_back(node3);
                            }
                        }
                    }
                }   
            }
        }
        _linearConstraints.clear();

        for (auto smPairs : mapConstraints)
        {
            int slave = smPairs.first;
            vector<int> masters = smPairs.second;
            vector<double> weights;
            vector<double> slaveCoords = nodeCoords(slave,IndexType::Global);
            for (int master : masters)
            {
                weights.push_back(C[make_pair(slave,master)]);
                vector<double> masterCoords = nodeCoords(master,IndexType::Global);
            }
            _linearConstraints.push_back({slave, masters, weights,0.});
        }
    }

    vector<int> DistributedMesh::_createTouchFlags(int iTag)
    {
        vector<int> touchFlags(nElem(), -1);
        _etaEl.resize(nElem(),1);
        vector<int> regionTag = {3,5,7,11};
        // 0 means untouched
        // 1 means touched
        // -1 NA
        for (int globElem{}; globElem < nElem(); ++globElem)
        {
            if (_connec->isItemInPart(globElem))
            {
                if (_elemFlags->getValue(1, globElem, IndexType::Global)%regionTag[iTag] == 0)
                {
                    touchFlags.at(globElem) = 1;

                    if (_elemFlags->getValue(1, globElem, IndexType::Global)%2 == 0)
                        touchFlags.at(globElem) = 0;
                }
            }
        }
        
        
        // Added threshold for aggregated elements. Mark as touched all elements in the boundary
        // that are under the threshold. 
        double eta0 = _childMesh->_eta_0; // Minimum portion of the exterior area of the element for it to be considered a root cell.
        // cout << "Eta0: " << std::setprecision(16) << eta0<< endl;
        _buildImmersedCurves(); // current geometry of the immersed curves for _cutCellRegionFractions
        for (int globElem{}; globElem < nElem(); ++globElem)
        {

            if (touchFlags.at(globElem) == 0) // _elemFlags->getValue(1, globElem, IndexType::Global) == 2)
            {
                // Region fraction from the exact area enclosed by the polyline the cut-cell cubature
                // integrates on (a sliver of the region can not be taken as well posed); the grid estimate
                // is only used if the regions can not be built from the curves (e.g. crossing curves)
                vector<double> fractions = _cutCellRegionFractions(localElemId(globElem));
                double etaK = fractions.empty() ? _gridRegionFraction(globElem, iTag) : fractions[iTag];
                _etaEl[globElem] = etaK;
                if (etaK > eta0)
                {
                    touchFlags.at(globElem) = 1;
                }
            }
        }
        return touchFlags;
    }

    double DistributedMesh::_gridRegionFraction(int globElem, int iTag)
    {
        vector<int> regionTag = {3,5,7,11};
        // Local corner flags (_immCornerFlags is indexed by local element)
        vector<int> cornerFlags = _immersedCornerFlags(globElem, IndexType::Global);

        // Create grid pts
        int G_Npts = 10;
        int G_NNpts = G_Npts*G_Npts;
        vector<vector<double>> Gpts(2);
        for (int j = 0; j < G_Npts; j++) 
        {
            for (int i = 0; i < G_Npts; i++)
            {
                Gpts[0].push_back(((double)i/(double)(G_Npts-1))*2.-1.);
                Gpts[1].push_back(((double)j/(double)(G_Npts-1))*2.-1.);
            }
        }
        // cout << Gpts[0][0]Gpts[0][0]
        vector<int> iToGpts = {0,G_Npts-1,G_Npts*(G_Npts-1),G_NNpts-1};

        int refGpt = -1;
        for (int i{};i<iToGpts.size();i++)
        {
            if (cornerFlags[i] == regionTag[iTag])
            {
                refGpt = iToGpts[i];
                break;
            }
        }

        // Param to coords 
        vector<vector<double>> GCoords(2);
        vector<int> GptFlag(G_NNpts);
        for (int j = 0; j < G_NNpts; j++)
        {
            vector<double> inInt = {Gpts[0][j], Gpts[1][j],0.};
            vector<double> resInt = interpolatePosition(globElem, inInt, IndexType::Global);
            GCoords[0].push_back(resInt[0]);
            GCoords[1].push_back(resInt[1]);
            // Check if point inside immersed boundary
            // Compute the number of intersection of the ray from this corner with the immersed mesh
            int numIntersection = 0;
            bool onImmersedMesh = false;
            if (_childMesh->basisFunctionType() == BasisFuncType::Lagrangian)
            {
                for (size_t i = 0; i < (_immSegments.size() / 6); ++i)
                {
                    double xStart = _immSegments[6 * i + 0];
                    double yStart = _immSegments[6 * i + 1];
                    double xEnd = _immSegments[6 * i + 3];
                    double yEnd = _immSegments[6 * i + 4];

                    // Check if the corner lies on the boundary
                    if (SGeometry::tripletOrientation2D({ xStart, yStart }, resInt, { xEnd, yEnd }) == 0)
                    {
                        if (SGeometry::isOnSegment({ xStart, yStart, 0. }, resInt, { xEnd, yEnd, 0. }))
                        {
                            GptFlag[j] = 2;
                            onImmersedMesh = true;
                            break;
                        }
                    }

                    if (((resInt[1] <= yStart) == (resInt[1] > yEnd)) and
                        (resInt[0] - xStart - (resInt[1] - yStart) * (xEnd - xStart) / (yEnd - yStart)) < 0)
                    {
                        numIntersection++;
                    }
                }
                if (!onImmersedMesh)
                {
                    GptFlag[j] = numIntersection % 2;
                }
            }
            else if(_childMesh->basisFunctionType() == BasisFuncType::BSplines)
            {
                vector<double> vXSol;

                for (size_t i = 0; i < (_immSegments.size() / 8); ++i)
                {
                    vector<double> abcdx = {_immSegments[8*i],   _immSegments[8*i+2],
                                            _immSegments[8*i+4], _immSegments[8*i+6]};
                    vector<double> abcdy = {_immSegments[8*i+1], _immSegments[8*i+3],
                                            _immSegments[8*i+5], _immSegments[8*i+7]};

                    vector<double> tsols = SGeometry::cubicLineIntersect(abcdy, resInt[1]);
                    
                    for (double sol : tsols)
                    {
                        // FIX 2: tighter parameter domain, half-open interval [-1, 1)
                        // to avoid double-counting shared endpoints between adjacent segments
                        if (sol < -1.0001 - 1e-9 || sol >= 1.0001 + 1e-9)
                            continue;
                        // FIX 2: clamp before evaluating to avoid tiny extrapolation errors
                        sol = std::max(-1.0, std::min(1.0, sol));
                        // FIX 4: skip tangent touches (even-multiplicity roots don't cross)
                        double dydt = 3.0*abcdy[0]*sol*sol + 2.0*abcdy[1]*sol + abcdy[2];
                        if (fabs(dydt) < 1e-10)
                            continue;

                        double xSol = abcdx[0]*sol*sol*sol + abcdx[1]*sol*sol + abcdx[2]*sol + abcdx[3];
                        double ySol = abcdy[0]*sol*sol*sol + abcdy[1]*sol*sol + abcdy[2]*sol + abcdy[3];
                        // FIX 5: on-curve check — point lies on the immersed boundary
                        if (fabs(xSol - resInt[0]) < 1e-7 && fabs(ySol - resInt[1]) < 1e-7)
                        {
                            GptFlag[j] = 2;
                            onImmersedMesh = true;
                            break;
                        }
                        // Only count intersections to the right of the query point (ray goes +X)
                        if (xSol <= resInt[0])
                            continue;
                        // FIX 1: relative tolerance deduplication to avoid merging
                        // legitimately close but distinct intersections in large domains
                        bool newPt = true;
                        for (int k = 0; k < (int)vXSol.size(); k++)
                        {
                            double tol = 1e-8 * (1.0 + fabs(xSol));
                            // if (globElem == 2520 && j < 10)
                            //     cout << fabs(vXSol[k] - xSol) << " "<< tol << endl;
                            if (fabs(vXSol[k] - xSol) < tol)
                            {
                                newPt = false;
                                break;
                            }
                        }
                        if (newPt)
                        {
                            // if (globElem == 2520 && j < 10)
                            //     cout << "Final npt = " << j << "segment = " << i <<" Sol = " << sol << " " <<  resInt[0] << "," << resInt[1] << endl;
                            numIntersection++;
                            vXSol.push_back(xSol);
                        }
                    }

                    if (onImmersedMesh) break;  // early exit if point found on boundary
                }

                if (!onImmersedMesh)
                    GptFlag[j] = numIntersection % 2;

                // debug output (unchanged)
                if (iTag == 1)
                {
                    ofstream myfile;
                    myfile.open("tryy0.csv", std::ios_base::app);
                    myfile << resInt[0] << ", " << resInt[1] << ", " << numIntersection << endl;
                    myfile.close();
                }
            }
        }

        int refFlag{};
        if (refGpt != -1)
            refFlag= GptFlag[refGpt];
        else
            refFlag = (GptFlag[0]+1)%2;

        double nIn = 0.;
        for (int i = 0; i < G_NNpts; i++) 
        {
            if (GptFlag[i] == refFlag)
                GptFlag[i] = 0;
            else if(GptFlag[i] != 2)
                GptFlag[i] = 1;
            if(GptFlag[i] == 2)
                nIn += 0.5;
            else
                nIn += (double)GptFlag[i];
        }
        double etaK = 1.-((double)nIn)/(double)G_NNpts;
        return etaK;
    }

    vector<vector<vector<double>>> DistributedMesh::_immersedElemChords(int immElem)
    {
        // Oriented pieces (start, end) of an immersed element of the 2D ImmersedBoundary: the
        // segment between its end nodes (Lagrangian) or nine chords of the cubic piece (BSplines)
        vector<vector<vector<double>>> chords;
        if (_childMesh->basisFunctionType() == BasisFuncType::Lagrangian)
        {
            int numNbors = _childMesh->_connec->getNumNbors(immElem);
            int globalNodeNumber0 = _childMesh->_connec->getNbor(immElem, 0);
            int globalNodeNumber1 = _childMesh->_connec->getNbor(immElem, numNbors-1);
            chords.push_back({_childMesh->nodeCoords(globalNodeNumber0), _childMesh->nodeCoords(globalNodeNumber1)});
        }
        else if (_childMesh->basisFunctionType() == BasisFuncType::BSplines)
        {
            int nItp = 10;
            vector<double> abcd = _childMesh->_compBsplineEq(_childMesh, immElem);
            vector<double> abcdx = {abcd[0],abcd[2],abcd[4],abcd[6]};
            vector<double> abcdy = {abcd[1],abcd[3],abcd[5],abcd[7]};
            auto curvePoint = [&](double t) -> vector<double>
            {
                return {abcdx[0]*t*t*t+abcdx[1]*t*t+abcdx[2]*t+abcdx[3],
                        abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3], 0.};
            };
            for (int ti = 0; ti < nItp-1; ti++)
                chords.push_back({curvePoint(2.*double(ti)/double(nItp-1.)-1.), curvePoint(2.*double(ti+1)/double(nItp-1.)-1.)});
        }
        else
        {
            throw runtime_error("DistributedMesh::_immersedElemChords: Only implemented for immersed mesh BasisFuncType::BSplines and BasisFuncType::Lagrangian.");
        }
        return chords;
    }

    vector<vector<vector<double>>> DistributedMesh::_cutCellImmersedSegments(int locElem)
    {
        // Shared by Integration::_genCubaSetCutCell and the region fractions of the aggregation
        // (through _immersedElemChords), so that both see the same polyline
        vector<vector<vector<double>>> immersedSegments;
        vector<int> immElems = _mapToChild->directMap(locElem, IndexType::Local);

        if (_childMesh->basisFunctionType() == BasisFuncType::Lagrangian)
        {
            for (int immElem : immElems)
            {
                vector<vector<vector<double>>> chords = _immersedElemChords(immElem);
                immersedSegments.insert(immersedSegments.end(), chords.begin(), chords.end());
            }
        }
        else
        {
            // Keep the chords touching the element (bounding box from its bottom-left and top-right corners)
            vector<double> elCrnrs = _elemNborCornerCoords(locElem, IndexType::Local);
            double x0 = elCrnrs[0];
            double y0 = elCrnrs[1];
            double x1 = elCrnrs[9];
            double y1 = elCrnrs[10];
            vector<double> elCrn = {x0,y0,x1,y1};
            for (int immElem : immElems)
            {
                for (auto& sgmnt : _immersedElemChords(immElem))
                {
                    bool ptIn = false;
                    for (int j = 0; j < 2; j++)
                    {
                        if (((sgmnt[j][0]>x0) and (sgmnt[j][0]<x1)) and (sgmnt[j][1]>y0) and (sgmnt[j][1]<y1))
                            ptIn = true;
                    }
                    if (ptIn or SGeometry::doesSegmentIntersect2DSquare(sgmnt,elCrn))
                        immersedSegments.push_back(sgmnt);
                }
            }
        }

        return immersedSegments;
    }

    bool DistributedMesh::_buildImmersedCurves()
    {
        _immCurvesBuilt = true;
        _immRegionsValid = false;
        _immCurveChords.clear();
        _immCurveSign.clear();
        _immRegionPieces.clear();
        _immCurveLoops.clear();
        _immCurveBox.clear();
        if (_pDim != 2 or elemType() != ElemType::Square or _childMesh == nullptr or
            _childMesh->_meshRel != MeshRelation::ImmersedBoundary or _interiorPoints.size() < _userTags.size())
            return false;

        // Group the immersed elements into closed curves (elements sharing nodes)
        int nImm = _childMesh->loc_nElem();
        vector<int> root(nImm);
        iota(root.begin(), root.end(), 0);
        function<int(int)> findRoot = [&](int e) { return root[e] == e ? e : root[e] = findRoot(root[e]); };
        unordered_map<int, int> nodeElem;
        for (int e = 0; e < nImm; e++)
        {
            vector<int> nbors = _childMesh->_connec->getNborList(e, IndexType::Local);
            for (int n : nbors)
            {
                auto it = nodeElem.find(n);
                if (it == nodeElem.end())
                    nodeElem[n] = e;
                else
                    root[findRoot(e)] = findRoot(it->second);
            }
        }
        unordered_map<int, int> curveId;
        vector<vector<int>> curveElems;
        for (int e = 0; e < nImm; e++)
        {
            int r = findRoot(e);
            if (curveId.find(r) == curveId.end())
            {
                curveId[r] = curveElems.size();
                curveElems.push_back({});
            }
            curveElems[curveId[r]].push_back(e);
        }

        // Make each curve watertight: the end of an element and the start of the next one are the same knot
        // evaluated from two cubics, which differ by roundoff, and a ray through such a gap would get the
        // winding number wrong
        vector<vector<vector<vector<double>>>> elemChords(nImm);
        for (int e = 0; e < nImm; e++)
            elemChords[e] = _immersedElemChords(e);
        for (auto& elems : curveElems)
        {
            for (int e : elems)
            {
                vector<double>& end = elemChords[e].back()[1];
                for (int f : elems)
                {
                    vector<double>& start = elemChords[f].front()[0];
                    double tol = 1e-10*(1. + fabs(end[0]) + fabs(end[1]));
                    if (f != e and fabs(start[0] - end[0]) < tol and fabs(start[1] - end[1]) < tol)
                    {
                        start = end;
                        break;
                    }
                }
            }
        }
        for (auto& elems : curveElems)
        {
            _immCurveChords.push_back({});
            for (int e : elems)
                for (auto& ch : elemChords[e])
                    _immCurveChords.back().push_back({ch[0][0], ch[0][1], ch[1][0], ch[1][1]});
        }
        int nCurves = _immCurveChords.size();
        if (nCurves == 0)
            return false;

        // Ordered points of each curve (the chords chain exactly: consecutive ones share their end points)
        for (auto& chords : _immCurveChords)
        {
            map<pair<double, double>, size_t> byStart;
            for (size_t i = 0; i < chords.size(); i++)
            {
                if (chords[i][0] != chords[i][2] or chords[i][1] != chords[i][3])
                    byStart[{chords[i][0], chords[i][1]}] = i;
            }
            if (byStart.empty())
                return false;
            size_t first = byStart.begin()->second;
            size_t cur = first;
            _immCurveLoops.push_back({});
            vector<double> box = {chords[cur][0], chords[cur][1], chords[cur][0], chords[cur][1]};
            while (true)
            {
                _immCurveLoops.back().push_back({chords[cur][0], chords[cur][1]});
                box = {min(box[0], chords[cur][0]), min(box[1], chords[cur][1]), max(box[2], chords[cur][0]), max(box[3], chords[cur][1])};
                auto it = byStart.find({chords[cur][2], chords[cur][3]});
                if (it == byStart.end() or _immCurveLoops.back().size() > byStart.size())
                    return false; // not a closed curve
                cur = it->second;
                if (cur == first)
                    break;
            }
            _immCurveBox.push_back(box);
        }

        // Orientation of each curve (+1 counter-clockwise)
        for (auto& chords : _immCurveChords)
        {
            double A{};
            for (auto& ch : chords)
                A += 0.5*(ch[0]*ch[3] - ch[2]*ch[1]);
            _immCurveSign.push_back(A > 0. ? 1. : -1.);
        }

        auto winding = [&](int c, double x, double y) { return _immCurveWinding(c, x, y); };

        // Nesting of the curves (they must not cross): inside[c][d] if curve d is inside curve c
        vector<vector<bool>> inside(nCurves, vector<bool>(nCurves, false));
        vector<int> depth(nCurves, 0);
        for (int c = 0; c < nCurves; c++)
        {
            for (int d = 0; d < nCurves; d++)
            {
                if (c != d and winding(c, _immCurveChords[d][0][0], _immCurveChords[d][0][1]) != 0)
                {
                    inside[c][d] = true;
                    depth[d]++;
                }
            }
        }

        // Each interior point gives a piece of its region: the interior of the innermost curve containing
        // the point (or the whole plane), minus the curves directly inside it. A region with several
        // interior points (e.g. several disjoint lumens) is the union of their pieces
        for (size_t iTag = 0; iTag < _userTags.size(); iTag++)
        {
            _immRegionPieces.push_back({});
            for (auto& pt : _interiorPoints[iTag])
            {
                double xp = pt[0];
                double yp = pt[1];
                vector<int> S;
                for (int c = 0; c < nCurves; c++)
                {
                    if (winding(c, xp, yp) != 0)
                        S.push_back(c);
                }
                int plus = -1;
                for (int c : S)
                {
                    if (plus == -1 or depth[c] > depth[plus])
                        plus = c;
                }
                // The curves around the point must be plus and all the curves around plus
                for (int c : S)
                {
                    if (c != plus and !inside[c][plus])
                        return false;
                }
                if (plus != -1 and int(S.size()) != depth[plus] + 1)
                    return false;
                vector<int> minus;
                for (int d = 0; d < nCurves; d++)
                {
                    if ((plus == -1 and depth[d] == 0) or (plus != -1 and inside[plus][d] and depth[d] == depth[plus] + 1))
                        minus.push_back(d);
                }
                // Two points in the same piece give it once
                bool repeated = false;
                for (auto& pc : _immRegionPieces.back())
                    repeated = repeated or pc.first == plus;
                if (!repeated)
                    _immRegionPieces.back().push_back({plus, minus});
            }
        }
        // The pieces of different regions must not overlap (same enclosing curve)
        for (size_t a = 0; a < _immRegionPieces.size(); a++)
            for (size_t b = a + 1; b < _immRegionPieces.size(); b++)
                for (auto& pa : _immRegionPieces[a])
                    for (auto& pb : _immRegionPieces[b])
                        if (pa.first == pb.first)
                            return false;
        _immRegionsValid = true;
        return true;
    }

    int DistributedMesh::_immCurveWinding(int c, double x, double y)
    {
        // Winding number of a point around curve c (upward ray, half-open in x, so that a ray through a
        // vertex of the watertight polyline is counted once)
        int w{};
        for (auto& ch : _immCurveChords[c])
        {
            if ((ch[0] <= x) != (ch[2] <= x))
            {
                double yc = ch[1] + (x - ch[0])*(ch[3] - ch[1])/(ch[2] - ch[0]);
                if (yc > y)
                    w += (ch[2] < ch[0]) ? 1 : -1;
            }
        }
        return w;
    }

    int DistributedMesh::_immRegionOfPoint(double x, double y)
    {
        if (!_immRegionsValid)
            return -1;
        for (size_t iTag = 0; iTag < _immRegionPieces.size(); iTag++)
        {
            for (auto& pc : _immRegionPieces[iTag])
            {
                bool in = (pc.first == -1 or _immCurveWinding(pc.first, x, y) != 0);
                for (int d : pc.second)
                    in = in and _immCurveWinding(d, x, y) == 0;
                if (in)
                    return iTag;
            }
        }
        return -1;
    }

    vector<double> DistributedMesh::_cutCellRegionFractions(int locElem)
    {
        if (!_immCurvesBuilt)
            _buildImmersedCurves();
        if (!_immRegionsValid)
            return {};

        vector<double> elCrnrs = _elemNborCornerCoords(locElem, IndexType::Local);
        double x0 = elCrnrs[0];
        double y0 = elCrnrs[1];
        double x1 = elCrnrs[9];
        double y1 = elCrnrs[10];
        double H = y1 - y0;
        double area = (x1 - x0)*H;

        // Area of the element below a chord (within its x-span): the clamped height is linear between the
        // points where the chord crosses y0 and y1, so the midpoint rule on each piece is exact
        auto areaBelow = [&](const vector<double>& ch)
        {
            double xa = ch[0], ya = ch[1], xb = ch[2], yb = ch[3];
            if (xb < xa)
            {
                swap(xa, xb);
                swap(ya, yb);
            }
            double lo = max(xa, x0);
            double hi = min(xb, x1);
            if (hi <= lo)
                return 0.;
            double slope = (yb - ya)/(xb - xa);
            vector<double> brk = {lo, hi};
            if (slope != 0.)
            {
                for (double level : {y0, y1})
                {
                    double xs = xa + (level - ya)/slope;
                    if (xs > lo and xs < hi)
                        brk.push_back(xs);
                }
            }
            sort(brk.begin(), brk.end());
            double A{};
            for (size_t i = 0; i + 1 < brk.size(); i++)
            {
                double xm = 0.5*(brk[i] + brk[i+1]);
                double hm = min(max(ya + slope*(xm - xa) - y0, 0.), H);
                A += (brk[i+1] - brk[i])*hm;
            }
            return A;
        };

        // Fraction of the element inside each curve: integral of the winding number over the element,
        // i.e. the areas below the chords signed by their direction (leftwards counts as +1)
        int nCurves = _immCurveChords.size();
        vector<double> inCurve(nCurves, 0.);
        for (int c = 0; c < nCurves; c++)
        {
            double W{};
            for (auto& ch : _immCurveChords[c])
                W += (ch[2] < ch[0] ? 1. : -1.)*areaBelow(ch);
            inCurve[c] = _immCurveSign[c]*W/area;
        }

        vector<double> fractions(_userTags.size());
        for (size_t iTag = 0; iTag < _userTags.size(); iTag++)
        {
            // The pieces of a region are disjoint: their fractions add up
            for (auto& pc : _immRegionPieces[iTag])
            {
                fractions[iTag] += (pc.first == -1) ? 1. : inCurve[pc.first];
                for (int d : pc.second)
                    fractions[iTag] -= inCurve[d];
            }
        }
        return fractions;
    }

    vector<vector<vector<vector<double>>>> DistributedMesh::_cutCellRegionPolygons(int locElem, int iTag)
    {
        typedef array<double, 2> P2;
        if (!_immCurvesBuilt)
            _buildImmersedCurves();
        if (!_immRegionsValid)
            throw runtime_error("DistributedMesh::_cutCellRegionPolygons: The regions can not be built from the immersed curves.");

        // Element bounds; reference coordinates as in _invertElementMapping_RegSquare
        vector<double> elCrnrs = _elemNborCornerCoords(locElem, IndexType::Local);
        double x0 = elCrnrs[0];
        double y0 = elCrnrs[1];
        double x1 = elCrnrs[9];
        double y1 = elCrnrs[10];

        // Boundary loops of the region oriented with the region on their left: the curve enclosing it
        // counter-clockwise and the curves removed from it clockwise, for every piece of the region. (curve, reversed)
        vector<pair<int, bool>> loops;
        for (auto& pc : _immRegionPieces[iTag])
        {
            if (pc.first != -1)
                loops.push_back({pc.first, _immCurveSign[pc.first] < 0.});
            for (int d : pc.second)
                loops.push_back({d, _immCurveSign[d] > 0.});
        }

        auto inside = [](const P2& p)
        {
            return p[0] >= -1. and p[0] <= 1. and p[1] >= -1. and p[1] <= 1.;
        };
        // Snap a point computed on a side of the reference square exactly onto it
        auto snap = [](P2 c, int axis, double side)
        {
            if (axis >= 0)
                c[axis] = side;
            for (int k = 0; k < 2; k++)
                c[k] = min(max(c[k], -1.), 1.);
            return c;
        };
        // Point where a->b crosses the boundary of the square, entering (a outside, b inside) or leaving
        // (a inside, b outside). Half-planes s*x_k <= 1 along a + t*(b-a): t*p <= q, p = s*d_k, q = 1 - s*a_k
        auto crossing = [&](const P2& a, const P2& b, bool entering)
        {
            double d[2] = {b[0] - a[0], b[1] - a[1]};
            double t = entering ? 0. : 1.;
            int axis = -1;
            double side = 0.;
            for (int k = 0; k < 2; k++)
            {
                for (double s : {-1., 1.})
                {
                    double p = s*d[k];
                    double q = 1. - s*a[k];
                    if (entering and p < 0. and q/p > t)
                    {
                        t = q/p;
                        axis = k;
                        side = s;
                    }
                    if (!entering and p > 0. and q/p < t)
                    {
                        t = q/p;
                        axis = k;
                        side = s;
                    }
                }
            }
            return snap({a[0] + t*d[0], a[1] + t*d[1]}, axis, side);
        };
        // Part of a->b inside the square when both ends are outside (Liang-Barsky); false if there is none
        auto through = [&](const P2& a, const P2& b, P2& pIn, P2& pOut)
        {
            double d[2] = {b[0] - a[0], b[1] - a[1]};
            double tE = 0., tX = 1., sE = 0., sX = 0.;
            int aE = -1, aX = -1;
            for (int k = 0; k < 2; k++)
            {
                for (double s : {-1., 1.})
                {
                    double p = s*d[k];
                    double q = 1. - s*a[k];
                    if (p == 0.)
                    {
                        if (q < 0.)
                            return false;
                    }
                    else if (p < 0. and q/p > tE)
                    {
                        tE = q/p;
                        aE = k;
                        sE = s;
                    }
                    else if (p > 0. and q/p < tX)
                    {
                        tX = q/p;
                        aX = k;
                        sX = s;
                    }
                }
            }
            if (!(tE < tX))
                return false;
            pIn = snap({a[0] + tE*d[0], a[1] + tE*d[1]}, aE, sE);
            pOut = snap({a[0] + tX*d[0], a[1] + tX*d[1]}, aX, sX);
            return pIn != pOut;
        };
        // Position of a boundary point counter-clockwise from (-1,-1): bottom [0,1), right [1,2), top [2,3), left [3,4)
        auto sigma = [](const P2& p)
        {
            if (p[1] == -1. and p[0] < 1.)
                return 0.5*(p[0] + 1.);
            if (p[0] == 1. and p[1] < 1.)
                return 1. + 0.5*(p[1] + 1.);
            if (p[1] == 1. and p[0] > -1.)
                return 2. + 0.5*(1. - p[0]);
            return 3. + 0.5*(1. - p[1]);
        };
        auto signedArea = [](const vector<P2>& r)
        {
            double A{};
            for (size_t i = 0; i < r.size(); i++)
            {
                const P2& a = r[i];
                const P2& b = r[(i + 1)%r.size()];
                A += a[0]*b[1] - b[0]*a[1];
            }
            return 0.5*A;
        };
        auto pointInRing = [](const P2& p, const vector<P2>& r)
        {
            bool in = false;
            for (size_t i = 0; i < r.size(); i++)
            {
                const P2& a = r[i];
                const P2& b = r[(i + 1)%r.size()];
                if ((a[0] <= p[0]) != (b[0] <= p[0]) and a[1] + (p[0] - a[0])*(b[1] - a[1])/(b[0] - a[0]) > p[1])
                    in = !in;
            }
            return in;
        };

        // Pieces of the loops inside the closed square: arcs from the boundary to the boundary, and rings for
        // the loops that do not leave it
        vector<vector<P2>> arcs, rings;
        for (auto& lp : loops)
        {
            const vector<double>& box = _immCurveBox[lp.first];
            if (box[2] < x0 or box[0] > x1 or box[3] < y0 or box[1] > y1)
                continue;
            const vector<vector<double>>& loop = _immCurveLoops[lp.first];
            int n = loop.size();
            vector<P2> pts(n);
            for (int i = 0; i < n; i++)
            {
                const vector<double>& q = loop[lp.second ? n - 1 - i : i];
                pts[i] = {(2.*q[0] - x1 - x0)/(x1 - x0), (2.*q[1] - y1 - y0)/(y1 - y0)};
            }
            int s = -1;
            for (int i = 0; i < n and s == -1; i++)
            {
                if (!inside(pts[i]))
                    s = i;
            }
            if (s == -1)
            {
                rings.push_back(pts);
                continue;
            }
            vector<P2> arc;
            for (int k = 0; k < n; k++)
            {
                const P2& a = pts[(s + k)%n];
                const P2& b = pts[(s + k + 1)%n];
                bool ia = inside(a);
                bool ib = inside(b);
                if (ia and ib)
                {
                    if (!arc.empty())
                        arc.push_back(b);
                }
                else if (ia)
                {
                    arc.push_back(crossing(a, b, false));
                    arcs.push_back(arc);
                    arc.clear();
                }
                else if (ib)
                    arc = {crossing(a, b, true), b};
                else
                {
                    P2 pIn, pOut;
                    if (through(a, b, pIn, pOut))
                        arcs.push_back({pIn, pOut});
                }
            }
        }
        // Remove repeated consecutive points and arcs of zero length (curve touching the boundary from outside)
        for (int k = arcs.size() - 1; k >= 0; k--)
        {
            arcs[k].erase(unique(arcs[k].begin(), arcs[k].end()), arcs[k].end());
            if (arcs[k].size() < 2)
                arcs.erase(arcs.begin() + k);
        }

        // Faces: follow an arc to its exit and the boundary counter-clockwise to the next entry, until closed
        const P2 corner[4] = {{1., -1.}, {1., 1.}, {-1., 1.}, {-1., -1.}}; // at sigma 1, 2, 3, 4 (= 0)
        vector<vector<P2>> outers, holes;
        vector<bool> used(arcs.size(), false);
        for (size_t k = 0; k < arcs.size(); k++)
        {
            if (used[k])
                continue;
            vector<P2> face;
            size_t cur = k;
            while (true)
            {
                used[cur] = true;
                for (auto& p : arcs[cur])
                {
                    if (face.empty() or p != face.back())
                        face.push_back(p);
                }
                double so = sigma(arcs[cur].back());
                size_t next = cur;
                double dmin = 5.;
                for (size_t j = 0; j < arcs.size(); j++)
                {
                    double d = sigma(arcs[j].front()) - so;
                    if (d < 0.)
                        d += 4.;
                    if (d < dmin)
                    {
                        dmin = d;
                        next = j;
                    }
                }
                int m0 = int(floor(so)) + 1;
                for (int m = m0; m < m0 + 4 and m - so < dmin; m++)
                {
                    if (corner[(m - 1)%4] != face.back())
                        face.push_back(corner[(m - 1)%4]);
                }
                if (next == k)
                    break;
                if (used[next])
                {
                    cout << "DistributedMesh::_cutCellRegionPolygons: Warning: inconsistent boundary walk in element " << locElem << endl;
                    break;
                }
                cur = next;
            }
            if (face.size() > 1 and face.front() == face.back())
                face.pop_back();
            if (face.size() >= 3)
                outers.push_back(face);
        }
        for (auto& r : rings)
        {
            double A = signedArea(r);
            if (A > 0.)
                outers.push_back(r);
            else if (A < 0.)
                holes.push_back(r);
        }

        // Without arcs nor enclosing rings, the boundary of the element is either all in the region (the element
        // minus the holes) or all out of it: the exact area of the region in the element tells which
        if (arcs.empty() and outers.empty())
        {
            double holesA{};
            for (auto& h : holes)
                holesA += signedArea(h);
            double f = _cutCellRegionFractions(locElem)[iTag];
            if (fabs(4.*f - (4. + holesA)) < fabs(4.*f))
                outers.push_back({{-1., -1.}, {1., -1.}, {1., 1.}, {-1., 1.}});
            else
                holes.clear();
        }

        // Each hole goes with the face that contains most of its points
        vector<vector<vector<P2>>> polys;
        for (auto& o : outers)
            polys.push_back({o});
        for (auto& h : holes)
        {
            int best = -1, bestCount = 0;
            for (size_t i = 0; i < outers.size(); i++)
            {
                int count{};
                for (auto& p : h)
                    count += pointInRing(p, outers[i]);
                if (count > bestCount)
                {
                    bestCount = count;
                    best = i;
                }
            }
            if (best == -1)
                cout << "DistributedMesh::_cutCellRegionPolygons: Warning: hole in element " << locElem << " outside every face, ignored" << endl;
            else
                polys[best].push_back(h);
        }

        vector<vector<vector<vector<double>>>> polygons;
        for (auto& poly : polys)
        {
            polygons.push_back({});
            for (auto& ring : poly)
            {
                polygons.back().push_back({});
                for (auto& p : ring)
                    polygons.back().back().push_back({p[0], p[1]});
            }
        }
        return polygons;
    }

    void DistributedMesh::_createCutBFStrutsRegions()
    {
        _cutBFConstrRegions.resize(_userTags.size());
        vector<int> regionTag = {3,5,7,11};

        for (int iTag{}; iTag < _userTags.size(); iTag++)
        {
            vector<int> touchFlags = _createTouchFlags(iTag);
            // Create aggregate cells
            unordered_map<int, vector<int>> exteriorBFs = _createAggregateElements(touchFlags);

            // unordered_map<int, vector<int>> exteriorBFs;
            map<pair<int,int>, double> Cold;
            unordered_map<int, vector<int>> exteriorBFs0 = exteriorBFs;
            // Create cut basis function structures and add to constraint map
            for (auto itr = exteriorBFs0.begin(); itr != exteriorBFs0.end(); ++itr)
            {
                // Compute the extrapolation weights
                vector<double> weights {};
                vector<int> masters {};
                int nMEl = itr->second.size()/nVert();//number of master elements
                for (int t = 0; t < nMEl ; t++) // nVert() it gives the number of vertices of one element (disMesh->nVert() if we are in the code)
                {
                    
                    vector<int> nrEl(nVert()); // nodes root element
                    for (int i = 0; i < nVert(); i++)
                        nrEl[i] = itr->second[nVert()*t+i];
                    vector<double> wrEl = _computeExtrapolationWeights(itr->first, nrEl, basisFunctionOrder());// weights root element

                    for (int i{}; i < nVert(); i++)
                    {
                        if (find(masters.begin(),masters.end(),nrEl[i]) == masters.end())
                        {
                            masters.push_back(nrEl[i]);
                            weights.push_back(wrEl[i]/(double)nMEl);
                        }
                        else
                        {
                            auto it = find(masters.begin(),masters.end(),nrEl[i]);
                            weights[it - masters.begin()] += wrEl[i]/(double)nMEl;
                        }

                    }
                }
                exteriorBFs[itr->first] = masters;
                for (int i = 0; i < masters.size(); i++)
                {
                    Cold[make_pair(itr->first,masters[i])] = weights[i];
                }

            }

            unordered_map<int, vector<int>> mapConstraints;

            // Loop for the local nodes to separate them in four sets
            // {Well-Posed Free,Well-Posed Hanging,Ill-posed Free,Well-Posed Hanging}
            set<int> SF, SWF, SWH, SIF, SIH, mastersWH;
            double CH = 0.5;        
            map<pair<int,int>, double> C; // Map for all the constraints (old and new)
            map<int, vector<int>> mastersH; // Map for the old linear constrains from the mesh
            for (int i = 0; i < nPts(); i++)
            { 
                int node = i;
                bool freeNode = 1;
                // FIXME: Only works with h-refined hierarchical constraints.
                for (linearConstraint lCons : _linearConstraints)
                {
                    if (lCons.slave == node)
                    {
                        freeNode = 0;
                        bool wellPosed = false;
                        int numElemNbors = _adjcyNE->getNumNbors(node);
                        mastersH[node] = lCons.masters;
                        for (int j = 0; j < numElemNbors; j++)
                        {
                            int nborElem = _adjcyNE->getNbor(node, j);
                            if (touchFlags[nborElem] == 1)
                                wellPosed = true;
                        }
                        if (wellPosed)
                        { 
                            SWH.insert(node);
                            for(int cnstr = 0; cnstr < lCons.masters.size(); cnstr++)
                                C[make_pair(node,lCons.masters[cnstr])] = lCons.weights[cnstr];
                            mapConstraints[node] = lCons.masters;
                            mastersWH.insert(lCons.masters[0]);
                            mastersWH.insert(lCons.masters[1]);
                        }
                        else
                        {
                            SIH.insert(node);
                        }
                    }
                }
                if (freeNode)
                    SF.insert(node);
            }
            
            // Move hanging nodes with only one master to free nodes
            vector<int>  SIHtoIF;
            for (int node : SIH)
            {
                
                bool unusedMaster = 0;
                for (int master : mastersH[node])
                {
                    if(find(SF.begin(),SF.end(),master) != SF.end())
                    {
                        unusedMaster = 1;
                        break;
                    }
                }
                if (unusedMaster)
                {
                    SIHtoIF.push_back(node);
                }
            }
            
            for (int node : SIHtoIF)
            {
                SIH.erase(node);
                SIF.insert(node);
            }


            for (int node : SF)
            {
                bool wellPosed = false;
                int numElemNbors = _adjcyNE->getNumNbors(node);
                for (int j = 0; j < numElemNbors; j++)
                {
                    int nborElem = _adjcyNE->getNbor(node, j);
                    if (touchFlags[nborElem] == 1)
                    wellPosed = true;
                }
                if ((wellPosed) || (mastersWH.count(node))) 
                {
                    SWF.insert(node);
                }
                else
                {
                    SIF.insert(node);
                }
            }
            // Ill posed free ndoes
            for (int node : SIF)
            {
                if (exteriorBFs.count(node))
                {
                    vector<int> mastersA = exteriorBFs.at(node);

                    for (int node1 : mastersA)
                    {
                        if (SWF.count(node1))
                        {
                            // if (C.find(make_pair(node,node1)) == C.end())
                            {
                                C[make_pair(node,node1)] += Cold[make_pair(node,node1)];
                                vector<int> nodeConstraintsVec = mapConstraints[node];
                                if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node1) == nodeConstraintsVec.end())
                                    mapConstraints[node].push_back(node1);
                            }

                        }
                        else if (SWH.count(node1))
                        {
                            for (int node2 : mastersH.at(node1))
                            {
                                C[make_pair(node,node2)] += Cold[make_pair(node,node1)]*CH;
                                vector<int> nodeConstraintsVec = mapConstraints[node];
                                if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node2) == nodeConstraintsVec.end())
                                    mapConstraints[node].push_back(node2);
                            }
                        }
                    }
                }
            }

            // Ill posed hanging nodes
            for (int node : SIH) 
            {
                for (int node1 : mastersH[node])
                {
                    if (SWF.count(node1))
                    {
                        C[make_pair(node,node1)] += CH;
                        vector<int> nodeConstraintsVec = mapConstraints[node];
                        if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node1) == nodeConstraintsVec.end())
                            mapConstraints[node].push_back(node1);
                    }
                    else
                    {
                        vector<int> mastersA = exteriorBFs[node1];
                        if (mastersA.size() == 0) 
                        {
                            vector<int> mastersATmp = exteriorBFs[node];
                            if (mastersATmp.size() > 0)
                            {

                                vector<double> weightsTmp {};
                                int nMEl = mastersATmp.size()/nVert();//number of master elements
                                for (int t =0; t < nMEl ; t++) // nVert() it gives the number of vertices of one element (disMesh->nVert() if we are in the code)
                                {
                                    vector<int> nrEl(nVert()); // nodes root element
                                    for (int i = 0; i < nVert(); i++)
                                        nrEl[i] = mastersATmp[nVert()*t+i];
                                    vector<double> wrEl = _computeExtrapolationWeights(node1, nrEl, basisFunctionOrder());// weights root element
                                    for (double w : wrEl)
                                        weightsTmp.push_back(w/(double)nMEl);
                                }
                                
                                for (int ii = 0; ii < mastersATmp.size(); ii++)
                                {
                                    Cold[make_pair(node1,mastersATmp[ii])] = weightsTmp[ii];
                                }
                                mastersA = mastersATmp;
                            }
                        }
                        for (int node2 : mastersA)
                        {
                            if (SWF.count(node2))
                            {
                                // if (C.find(make_pair(node,node2)) == C.end())
                                {
                                    C[make_pair(node,node2)] += CH*Cold[make_pair(node1,node2)];
                                    vector<int> nodeConstraintsVec = mapConstraints[node];
                                    if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node2) == nodeConstraintsVec.end())
                                        mapConstraints[node].push_back(node2);
                                }

                            }
                            else if (SWH.count(node2))
                            {
                                for (int node3 : mastersH.at(node2))
                                {
                                    C[make_pair(node,node3)] += CH*Cold[make_pair(node1,node2)]*CH;
                                    vector<int> nodeConstraintsVec = mapConstraints[node];
                                    if (find(nodeConstraintsVec.begin(),nodeConstraintsVec.end(),node3) == nodeConstraintsVec.end())
                                        mapConstraints[node].push_back(node3);
                                }
                            }
                        }
                    }   
                }
            }
            // _linearConstraints.clear();

            vector<linearConstraint> jointConstraints{};
            for (auto smPairs : mapConstraints)
            {
                int slave = smPairs.first;
                vector<int> masters = smPairs.second;
                vector<double> weights;
                vector<double> slaveCoords = nodeCoords(slave,IndexType::Global);
                // cout << "Number of masters: " << masters.size()<<endl;
                for (int master : masters)
                {
                    weights.push_back(C[make_pair(slave,master)]);
                    vector<double> masterCoords = nodeCoords(master,IndexType::Global);
                }
                jointConstraints.push_back({slave, masters, weights,0.});
            }
            _cutBFConstrRegions[iTag] = jointConstraints;

        }   
        //////////////////////////////////////////////////////
        ///////////// PRINT SLAVE MASTER INFO ////////////////
        //////////////////////////////////////////////////////
        
        if (false)
        {
            int m = 0;
            auto fileExists = [](const std::string& filename)
            {
                struct stat buf;
                if (stat(filename.c_str(), &buf) != -1)
                    return true;
                return false;
            };

            while (fileExists("SlaveMaster.0."+ to_string(m) +".csv"))
            {m++;}
            
            for (int iTag{}; iTag < _userTags.size(); iTag++)
            {
                for(int i{}; i < nPts(); i++)
                {
                    ofstream myfile;
                    if (!fileExists("SlaveMaster." + to_string(iTag) + "." + to_string(m) +".csv"))
                    {
                        myfile.open("SlaveMaster." + to_string(iTag) + "." + to_string(m) +".csv", std::ios_base::app);
                        myfile << "nodeId" << " " << "nodeX" << " " << "nodeY";
                        for (auto constr : _cutBFConstrRegions[iTag])
                            myfile << " " << constr.slave;
                        myfile << endl;
                    }
                    myfile.open("SlaveMaster." + to_string(iTag) + "." +  to_string(m) +".csv", std::ios_base::app);
                    vector<double> iCoords = nodeCoords(i,IndexType::Global);
                    myfile << i << " " << iCoords[0] << " " << iCoords[1];
                    for (auto constr : _cutBFConstrRegions[iTag])
                    {
                        vector<int> masters = constr.masters;
                        int slave = constr.slave;
                        vector<double> weights = constr.weights;
                        if (i == slave)
                            myfile << " " << "100";
                        else
                        {
                            bool iMaster = 0;
                            for (int j {}; j < masters.size(); j++)
                            {
                                if (masters[j] == i)
                                {
                                    myfile << " " << weights[j];
                                    iMaster = 1;
                                }
                            }
                            if(!iMaster)
                            {
                                myfile << " " << "Nan";
                            }
                        }
                    }
                    myfile<< endl;
                    myfile.close();
                }
            } 
        }
    }

    std::vector<double> DistributedMesh::_elemNborCornerCoords(int el,IndexType idxType)
    {
        vector<double> elCoordsV(4*3);
        vector<int> elCrnrs = _getElementCornerNodes(el, idxType);
        for (int i{}; i < 4; i++)
        {
            vector<double> cornrCoords = nodeCoords(elCrnrs[i], IndexType::Global);
            for (int j{}; j < 3; j++)
                elCoordsV[i*3+j] = cornrCoords[j];
        }
        return elCoordsV;
    }

    unordered_map<int, vector<int>> DistributedMesh::_findClosestFAE(vector<int> touchFlags)
    {
        // a map with cut elements as key and root elements as values
        unordered_map<int, vector<int>> aggregateCells;
        vector<int> sharedTouchFlags0 = touchFlags;
        MPI_Allreduce(touchFlags.data(), sharedTouchFlags0.data(), touchFlags.size(), MPI_INT, MPI_MAX, MPI_COMM_WORLD);
        for (int i{}; i < _pDim; ++i)
        {
            // update touch flags
            for (auto itr = aggregateCells.begin(); itr != aggregateCells.end(); ++itr)
            {
                touchFlags.at(itr->first) = 1;
            }

            // share touch flags with all processors
            vector<int> sharedTouchFlags = touchFlags;
            MPI_Allreduce(touchFlags.data(), sharedTouchFlags.data(), touchFlags.size(), MPI_INT, MPI_MAX, MPI_COMM_WORLD);

            for (int globElem{}; globElem < nElem(); ++globElem)
            {
                if (sharedTouchFlags.at(globElem) == 0)
                {
                    // Find facet adjacent elements of untouched element
                    vector<int> facetAdjcentElements = _findFacetAdjacentElements(globElem, IndexType::Global);
                    // Choose element to attach based on DEF 2.2
                    // Get nodes of the element
                    vector<int> nodeNbors = _getElementCornerNodes(globElem,IndexType::Global);
                    vector<double> elCoordsV = _elemNborCornerCoords(globElem,IndexType::Global);
                    
                    vector<vector<double>> elCoords(4);

                    for (int j = 0; j < 4; j++)
                        elCoords[j] = {elCoordsV[j*3],elCoordsV[j*3+1],elCoordsV[j*3+2]};
                    
                    vector<int> closestFae = {};
                    double dmin = 100;
                    double etaMax = 0;

                    unordered_map<int,double> elDist;
                    for (int fae : facetAdjcentElements)
                    {
                        if (fae != -1 and _connec->isItemInPart(fae)) // make sure that root element is in the same partition
                        {
                            if (sharedTouchFlags.at(fae) == 1)
                            {
                                vector<int> vrEl {};
                                // Check if element already aggregated and get the root element
                                if (sharedTouchFlags0.at(fae) != 1)
                                {
                                    auto itr = aggregateCells.find(fae);
                                    if (itr != aggregateCells.end()) 
                                    {
                                        for (int itr2 : itr->second)
                                        {
                                            vrEl.push_back(itr2); // stores all the masters
                                        }
                                    }
                                }
                                
                                if (vrEl.size()==0)
                                    vrEl.push_back(fae);    

                                for (int rEl : vrEl)
                                {
                                    // Get nodes of root
                                    vector<double> rElCoordsV = _elemNborCornerCoords(rEl, IndexType::Global);
                                    vector<vector<double>> rElCoords;
                                    for (int j = 0; j < 4; j++)
                                        rElCoords.push_back({rElCoordsV[j*3],rElCoordsV[j*3+1],rElCoordsV[j*3+2]});
                                    double maxDistNum = 0.;
                                    double maxDistDen = 0.;
                                    for (vector<double> rElPt : rElCoords)
                                    {
                                        // for (int j = 0; j < 3; j++)
                                        // {
                                            for(vector<double> globPt : elCoords)
                                            {
                                                double dist1 = (rElPt[0]-globPt[0])*(rElPt[0]-globPt[0])+(rElPt[1]-globPt[1])*(rElPt[1]-globPt[1]);
                                                // cout << dist1 << " r0"<< rElPt[0] << " g0" << globPt[0] << " r0"<< rElPt[1] << " g0" << globPt[1]<<endl;
                                                if (dist1 > maxDistNum)
                                                    maxDistNum = dist1;
                                            }
                                            for(vector<double> rElPt2 : rElCoords)
                                            {
                                                double dist2 = fabs(rElPt[0]-rElPt2[0]);
                                                if (dist2 > maxDistDen)
                                                    maxDistDen = dist2;
                                            }
                                        // }
                                    }
                                    // Get the d(fae,globElem)
                                    double d = (double)maxDistNum/(double)maxDistDen;
                                    if ((elDist.find(rEl) == elDist.end()))
                                    {   
                                        elDist.insert({rEl,d});
                                    }
                                    // cout << d << ", "<<_etaEl[rEl]<< "; ";
                                    if (d < dmin+1e-6)
                                    {
                                        dmin = d;
                                        etaMax = max(etaMax,_etaEl[rEl]);
                                    }
                                }
                            }
                        }
                    }

                    for ( auto itr = elDist.begin(); itr != elDist.end(); ++itr)         
                    {
                        if (fabs(itr->second - dmin) < 1e-5 & fabs(_etaEl[itr->first] - etaMax) < 1e-5)
                        {
                            closestFae.push_back(itr->first);
                            break;
                        }
                    }
                
                    if (closestFae.size() > 0)
                        aggregateCells.insert(pair<int, vector<int>>(globElem, closestFae));
                }    
            }
        }
        return aggregateCells;
    }

    unordered_map<int, vector<int>> DistributedMesh::_createAggregateElements(vector<int> touchFlags)
    {
        // This function returns a map with cut elements as keys and root elements as values

        // The implementation of this function is based on:
        // Badia, S., Verdugo, F., & Martín, A. F. (2018). The aggregated unfitted finite element method for
        // elliptic problems. Computer Methods in Applied Mechanics and Engineering, 336, 533-553.

        // Assumptions:
        // 1. Each cut element shares at least one corner with an interior element (this is
        //    usually true if the back mesh is fine enough to capture the geometry)
        // 2. This function is called by the back mesh

        // Checks
        if (_parentMesh != Teuchos::null)
        {
            throw runtime_error("DistributedMesh::_createAggregateElements:\
             This function should be called by back mesh.");
        }

        //----------------------------------------------------------------------------//
        // For each untouched cell check the facet adjacent elements, if there is any //
        // adjacent touch cell aggregate the untouched cell and mark it as touched.   //
        //----------------------------------------------------------------------------//
        /* Pseudo code:
        create a map with cut elements as keys and root elements as values
        it is proven in the paper that 2 and 3 iterates are enough for 2D and 3D cases, respectively
        iterate while there is no untouched element
        {
            for each untouched elem in global elements
            {
                find facet adjacent elements
                if any of the adjacent elements are touched
                {
                    check if the touched element is an interior element?
                    {
                        create a map pair from untouched element to touched interior element
                    }
                    else if the touched element is not interior
                    {
                        find the root element (interior) of this touched element
                        create a map pair from untouched element to this root element
                    }
                    tag untouched element as touched
                    break
                }
            }
        }
        */
        unordered_map<int, vector<int>> aggregateCells = _findClosestFAE(touchFlags);
        
        //--------------------------------------------------------------------//
        // Find critical basis functions in each cut element and create a map //
        // with critical basis functions as keys and root element as value.   //
        //--------------------------------------------------------------------//
        /* Pseudo code
        node = control point = bf
        element = knot span [xi_{i}, xi_{i+1}] x [eta_{i}, eta_{i+1}]
        for all cut element (keys of aggregateCells map)
        {
            loop over all bf
            {
                use _adjcyNE->getNborList to get the list of elements associate to this bf
                check if there is at least one in element
                if( this bf does not have any support inside the domain)
                {
                    tag it as critical.
                }
            }
        }
        */
        unordered_map<int, vector<int>> exBFs;
        for (auto itr = aggregateCells.begin(); itr != aggregateCells.end(); ++itr)
        {
            if (_connec->isItemInPart(itr->first))
            {
                vector<int> bfLists = _connec->getNborList(itr->first);
                for (int bf : bfLists)
                {
                    bool doesThisBFHaveInnerSupport = false;
                    vector<int> supportElements = _adjcyNE->getNborList(bf);
                    for (int e : supportElements)
                    {
                        if (touchFlags.at(e) == 1)
                        {
                            doesThisBFHaveInnerSupport = true;
                            break;
                        }
                    }
                    if (!doesThisBFHaveInnerSupport and _graph->isItemInPart(bf))
                    {
                        vector<int> elMasterNodes{};
                        for (int itr2 : itr->second)
                        {
                            for (int nborNode : _connec->getNborList(itr2))
                                elMasterNodes.push_back(nborNode);
                        }
                        exBFs.insert(pair<int, vector<int>>(bf,elMasterNodes));
                    }
                }
            }
        }

        return exBFs;
    }

    vector<double> DistributedMesh::_computeExtrapolationWeights(int slaveNodeID, vector<int> masterNodeIDs, int bfOrder)
    {
        // Check: this function must be called from back mesh
        if (_parentMesh != Teuchos::null)
        {
            throw runtime_error("DistributedMesh::_computeExtrapolationWeight\
                                This function must be called by back mesh.");
        }

        // Computing the weights acc. to Eq. (54) of
        // Rüberg, Thomas, and F. Cirak. "Subdivision-stabilised immersed b-spline finite elements for moving
        // boundary flows." Computer Methods in Applied Mechanics and Engineering 209 (2012): 266-283.

        std::vector<double> xS2(_pDim, 0.0);
        std::vector<std::vector<double>> xM2(masterNodeIDs.size(), std::vector<double>(_pDim, 0.0));
        for (int d = 0; d < _pDim; d++)
        {
            for (int ii = 0; ii < masterNodeIDs.size(); ii++)
            {
                xS2[d] = nodeCoord(slaveNodeID, d);
                xM2[ii][d] = nodeCoord(masterNodeIDs[ii], d);
            }
        }

        vector<double> weights(masterNodeIDs.size(), 1.);
        if(bfOrder == 1)
        {
            for (size_t node{}; node < masterNodeIDs.size(); ++node)
            {
                int n1;
                int n2;
                int n3;
                if (node == 0)
                {
                    n1 = 1;
                    n2 = 3;
                    n3 = 2;
                }
                else if (node == 1)
                {
                    n1 = 0;
                    n2 = 2;
                    n3 = 3;
                }
                else if (node == 2)
                {
                    n1 = 0;
                    n2 = 1;
                    n3 = 3;
                }
                else if (node == 3)
                {
                    n1 = 1;
                    n2 = 0;
                    n3 = 2;
                }
                double m12 = (xM2[n1][1]-xM2[n2][1])*(xM2[n1][0]-xM2[n2][0]);
                double a12 = xM2[n1][1]-m12*xM2[n1][0];
                double m23 = (xM2[n2][1]-xM2[n3][1])*(xM2[n2][0]-xM2[n3][0]);
                double a23 = xM2[n2][1]-m23*xM2[n2][0];
                weights.at(node) = 1;
                if (double(fabs(xM2[n1][0]-xM2[n2][0])) < 1e-14)
                {
                    weights.at(node) *= (xS2[0]-xM2[n1][0]);
                    weights.at(node) /= (xM2[node][0]-xM2[n1][0]);
                }
                else
                {
                    weights.at(node) *= (m12*xS2[0]+a12-xS2[1]);
                    weights.at(node) /= (m12*xM2[node][0]+a12-xM2[node][1]);
                }
                if (fabs(xM2[n2][0]-xM2[n3][0]) < 1e-14)
                {
                    weights.at(node) *= (xS2[0]-xM2[n3][0]);
                    weights.at(node) /= (xM2[node][0]-xM2[n3][0]);
                }
                else
                {
                    weights.at(node) *= (m23*xS2[0]+a23-xS2[1]);
                    weights.at(node) /= (m23*xM2[node][0]+a23-xM2[node][1]);
                }
            }
        }
        else if(bfOrder == 2)
        {
            double x0 = xM2[0][0];
            double x2 = xM2[8][0];
            double y0 = xM2[0][1];
            double y2 = xM2[8][1];
            double x1 = (x0+x2)*0.5;
            double y1 = (y0+y2)*0.5;
            double xL = x2-x0;
            double yL = y2-y0;
            double xL2 = xL*xL;
            double yL2 = yL*yL;
            // Biquadratic basis functions
            double wght[9] = {4,-8,4,-8,16,-8,4,-8,4};
            // Compute weights
            weights[0] = wght[0]*(xS2[0]-x1)*(xS2[0]-x2)*(xS2[1]-y1)*(xS2[1]-y2)/(xL2*yL2);
            weights[1] = wght[1]*(xS2[0]-x0)*(xS2[0]-x2)*(xS2[1]-y1)*(xS2[1]-y2)/(xL2*yL2);
            weights[2] = wght[2]*(xS2[0]-x0)*(xS2[0]-x1)*(xS2[1]-y1)*(xS2[1]-y2)/(xL2*yL2);
            weights[3] = wght[3]*(xS2[0]-x1)*(xS2[0]-x2)*(xS2[1]-y0)*(xS2[1]-y2)/(xL2*yL2);
            weights[4] = wght[4]*(xS2[0]-x0)*(xS2[0]-x2)*(xS2[1]-y0)*(xS2[1]-y2)/(xL2*yL2);
            weights[5] = wght[5]*(xS2[0]-x0)*(xS2[0]-x1)*(xS2[1]-y0)*(xS2[1]-y2)/(xL2*yL2);
            weights[6] = wght[6]*(xS2[0]-x1)*(xS2[0]-x2)*(xS2[1]-y0)*(xS2[1]-y1)/(xL2*yL2);
            weights[7] = wght[7]*(xS2[0]-x0)*(xS2[0]-x2)*(xS2[1]-y0)*(xS2[1]-y1)/(xL2*yL2);
            weights[8] = wght[8]*(xS2[0]-x0)*(xS2[0]-x1)*(xS2[1]-y0)*(xS2[1]-y1)/(xL2*yL2);
        }
        else
            throw runtime_error("DistributedMesh::_ComputeExtrapolationWeights: Only working for Basis Functions of order 1 or 2.");
        // Return weights
        return weights;
    }

    vector<int> DistributedMesh::_findFacetAdjacentElements(int elemIdx, IndexType type)
    {
        // WARNING: Only works with regular or hierarchical meshes.
        if (elemType() != ElemType::Square)
        {
            throw runtime_error("DistributedMesh::_findFacetAdjacentElements: Only working for square elements.");
        }

        // Convert the elemIdx to global if it is local
        if (type == IndexType::Local)
        {
            elemIdx += offs_nElem();
        }

        // Get the old index (before balancing)
        int oldIdx = _oldElementIndex(elemIdx);

        // Create a vector to save adjacent elements
        vector<int> adjacentElems;
        
        // Adjacent facet elements for refined mesh
        // Get element and node neighbors and coordinates
        vector<int> elNbrs = elemNbors(elemIdx,IndexType::Global);
        vector<int> nodeNbors = _getElementCornerNodes(elemIdx,IndexType::Global);
        vector<double> elCoords = _elemNborCornerCoords(elemIdx, IndexType::Global);


        // Obtain element size (elCoords holds the 4 corners only, not nVert() nodes)
        int nCrnrs = elCoords.size()/3;
        double elH = 1.;
        for (int i = 1; i < nCrnrs; i++)
        {
            double coordDiff = (elCoords[0]-elCoords[3*i])*(elCoords[0]-elCoords[3*i]);
            coordDiff += (elCoords[1]-elCoords[3*i+1])*(elCoords[1]-elCoords[3*i+1]);
            coordDiff += (elCoords[2]-elCoords[3*i+2])*(elCoords[2]-elCoords[3*i+2]);
            if (coordDiff < elH)
                elH = coordDiff;
        }
        vector<int> smallNbrs; // Vector of nbor elems that are smaller than current elem
        vector<int> bigNbrs; // Vector of nbor elems that are larger than current elem
        for (int elNbr : elNbrs)
        {
            // Get size of nbr elem
            // vector<double> elCoords = elemNborNodeCoords(elNbr, IndexType::Global);
            vector<int> elCrnrsNbr = _getElementCornerNodes(elNbr, IndexType::Global);
            vector<double> elCoordsNbr = _elemNborCornerCoords(elNbr, IndexType::Global);

            double elNbrH = 1.;
            for (int i = 1; i < nCrnrs; i++)
            {
                double coordDiff = (elCoordsNbr[0]-elCoordsNbr[3*i])*(elCoordsNbr[0]-elCoordsNbr[3*i]);
                coordDiff += (elCoordsNbr[1]-elCoordsNbr[3*i+1])*(elCoordsNbr[1]-elCoordsNbr[3*i+1]);
                coordDiff += (elCoordsNbr[2]-elCoordsNbr[3*i+2])*(elCoordsNbr[2]-elCoordsNbr[3*i+2]);
                if (coordDiff < elNbrH)
                    elNbrH = coordDiff;
            }
            if (abs(elNbrH - elH) < 1e-8) // If both elements are of the same size
            {
                vector<int> nborNbors = _getElementCornerNodes(elNbr,IndexType::Global);                
                int shNbrs = 0;  // Shared node nbrs
                for (int n1 : nborNbors)
                {
                    if(find(nodeNbors.begin(), nodeNbors.end(), n1) != nodeNbors.end())
                    {
                        shNbrs += 1;
                    }
                }
                if (shNbrs == 2) // If the elements share two nbrs they are facet adjacent
                    adjacentElems.push_back(elNbr);
            }
            else if (elNbrH < elH)
            {
                smallNbrs.push_back(elNbr);
            }
            else
                bigNbrs.push_back(elNbr);
        }

        // Returns the a vector with the shared elements between two vectors
        auto sharedInt = [](vector<int> a,vector<int> b)
        {
            vector<int> shrd;
            for (auto & el1 : a)
            {
                if(find(b.begin(), b.end(), el1) != b.end())
                    shrd.push_back(el1);
            }
            return shrd;
        };

        // Check which large elements are facet adjacent
        int numAdjEls = adjacentElems.size();
        for (int bigNbr : bigNbrs)
        {
            vector<int> nBigNbrs = _getElementCornerNodes(bigNbr,IndexType::Global);
            for (int j = 0; j < numAdjEls; j++)
            {
                vector<int> nAdjNbrs = _getElementCornerNodes(adjacentElems[j],IndexType::Global);
                vector<int> shrdBigAdj = sharedInt(nBigNbrs,nAdjNbrs);
                vector<int> shrdShrd = sharedInt(shrdBigAdj,nodeNbors);
                if (shrdBigAdj.size() == 1 && shrdShrd.size() == 0)
                    adjacentElems.push_back(bigNbr);
            }
        }

        // Check which small elements are facet adjacent
        for (int smallNbr : smallNbrs)
        {
            vector<int> nSmallNbrsi = _getElementCornerNodes(smallNbr,IndexType::Global);
            for (int j = 0; j < smallNbrs.size(); j++)
            {
                vector<int> nSmallNbrsj = _getElementCornerNodes(smallNbrs[j],IndexType::Global);
                vector<int> shrdSmallSmall = sharedInt(nSmallNbrsi,nSmallNbrsj);
                vector<int> shrdSSEl = sharedInt(shrdSmallSmall,nodeNbors);

                if (shrdSmallSmall.size() == 1 && shrdSSEl.size() == 0)
                    adjacentElems.push_back(smallNbr);
            }
        }
        
        return adjacentElems;
    }
}
