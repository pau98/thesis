/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef BVH_ELEMENT_LOCATOR_H
#define BVH_ELEMENT_LOCATOR_H

#include <vector>
#include <stdalign.h>
#include <mpi.h>


#include <Teuchos_RCP.hpp>

#include "hl_DOFsHandler.h"
#include "hl_ElementLocator.h"
#include "hl_FieldStruct.h"

#define nmax numeric_limits<double>::max();


namespace hiperlife
{

    /*!
     * \brief Class to create an element locator based on a boundary volume hierarchy. Refs:
     *  - Garth and Joy: Fast, Memory-efficient cell location in unstructured grids for visualization
     *    https://doi.org/10.1109/TVCG.2010.156
     *  - https://jacco.ompf2.com/2022/04/13/how-to-build-a-bvh-part-1-basics/
     *  - https://github.com/alecjacobson/computer-graphics-bounding-volume-hierarchy
     */
    class BVHElementLocator: public ElementLocator
    {
        public:

            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects can be created from
             *  temporal objects through move constructors
             *  @{ */
            BVHElementLocator(std::string tag ="BVHElementLocator", MPI_Comm comm = MPI_COMM_WORLD);
            BVHElementLocator(BVHElementLocator&& other) = default;
            BVHElementLocator(const BVHElementLocator& other) = delete;
            ~BVHElementLocator() = default;

            // Operators
            BVHElementLocator& operator=(const BVHElementLocator& other) = delete;
            BVHElementLocator& operator=(BVHElementLocator&& other) = default;
            /** @} */ // end of constructors

            /** @name Primary object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a the object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /*! \brief Set FieldStruct and fields were the map is stored
             * \param mapFieldStruct FieldStruct with the fields of the map
             * \param mapFields vector of fields
             */
            void setFieldsToMap(Teuchos::RCP<FieldStruct> mapFieldStruct, std::vector<int> mapFields){_mapFieldStruct = mapFieldStruct; _mapFields = mapFields;};
            // /*! \brief Set number of tree subdivision levels
            //  * \param nLevels Number of tree subdivision levels
            //  */
            // void setNumberOfTreeSubdivisionLevels(int nLevels){_nLevels = nLevels;}
            // /*! \brief Set maximum number of tree subdivision levels
            //  * \param maxNLevels Maximum number of tree subdivision levels
            //  */
            // void setMaxNumberOfTreeSubdivisionLevels(int maxNLevels){_maxNLevels = maxNLevels;}
            // /*! \brief Set number of elements per octant
            //  * \param nElemPerOctant Number of elements per octant
            //  */
            // void setNumberOfElementsPerOctant(int nElemPerOctant){_nElemPerOctant = nElemPerOctant;}
            /** @} */ // end of primary object creation



            /** @name Data access
             *  @{
            */
            // /*! \brief Returns the number of dimensions.*/
            // inline int numberOfTreeSubdivisionLevels(){return _nLevels;}
            // /*! \brief Returns the maximum boundary of the mesh.*/
            // std::vector<double> meshMaximum();
            // /*! \brief Returns the minimum boundary of the mesh.*/
            // std::vector<double> meshMinimum();
            /** @} */ // end of mesh data access



            /** @name Search methods
             *  @{
            */
            /*! \brief Finds the element and the coordinates in reference space of a the closest point
             * projection of one point in a partition. It returns the minimum distance to the point
             * \param elems Element global id that contains the closest point projection
             * \param rCoords Vector with the coordinates in reference space of the closest point projection
             * \param xCoords Vector of coordinates of the point
             */
            inline double searchElementInPartition(int& elem, std::vector<double>& rCoords, std::vector<double> xCoords) override {return _searchElementInBVH(elem, rCoords, xCoords);};
            /*! \brief Finds the element and the coordinates in reference space of a the closest point
             * projection of several points
             * \param elems Element global ids that contain the closest point projections
             * \param rCoords Vector of vector with the coordinates in reference space of the closest point projections
             * \param xCoords Vector of vectors of coordinates of the points
             */
            std::vector<double> searchElement(std::vector<int>& elems, std::vector<std::vector<double>>& rCoords, std::vector<std::vector<double>> xCoords) override;
            /** @} */ // end of search methods

            Teuchos::RCP<DOFsHandler> dhand = Teuchos::null;

            // Auxiliary
            void _printNode(const unsigned int nodeIdx);
            int _computeBVHHeightAndBalance(const unsigned int nodeIdx, int &balanceFactor);
            void _printBVHcharacteristics();

        private:

            // Mesh
            double _meshMin[3];
            double _meshMax[3];

            // Elements
            struct _elem // FIXME: Use floats
            {
                double min[3];
                double max[3];
                double cen[3]; // centroid
            };
            std::vector<_elem> _elems;
            std::vector<int> _elemsIdx;

            // Nodes
            struct _node // 56 bytes
            {
                double aabbMin[3], aabbMax[3]; // 8*3*2 = 48 bytes
                unsigned int leftFirst, elemCount;  // 2*4 = 8 bytes
                bool isLeaf() {return elemCount > 0;}
            };
            std::vector<_node> _nodes;
            unsigned int _nodesUsed{};
            // // Rays
            // struct _ray
            // {
            //     double O[3];
            //     double D[3];
            //     double t = std::numeric_limits<double>::max();
            // };

            // Tune parameters
            // TODO

            // Functions to create the BVH
            void _computeMeshBounds();
            void _createElements();
            void _computeNodeBounds(const unsigned int nodeIdx);
            double _computeSAH(_node& node, int axis, double pos);
            double _computeBestSplitPlane(_node& node, int& axis, double& splitPos);
            void _computeSplitCost(_node &node);
            double _computeNodeCost(_node& node);
            void _subdivideNode(const unsigned int nodeIdx);

            // Functions to search
            bool _isPointWithinElementBounds(const double x[3], const unsigned int elemIdx);
            bool _isPointWithinNodeBounds(const double x[3], const unsigned int nodeIdx);
            double _distanceSqToBounds(const double x[3], double bmin[3], double bmax[3]);
            double _distanceSqToElementBounds(const double x[3], const unsigned int elemIdx);
            double _distanceSqToNodeBounds(const double x[3], const unsigned int nodeIdx);
            void _searchElementCanditatesInBVH(const double x[3], const unsigned int nodeIdx, std::vector<int> &elemCandidates);
            double _searchElementInBVH(int& elems, std::vector<double>& rCoords, std::vector<double> xCoords, double maxSqDist = std::numeric_limits<double>::max());

            // Auxiliary
            Teuchos::RCP<FieldStruct> _mapFieldStruct;
            std::vector<int> _mapFields;

    };

}
#endif
