/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#include <limits.h>

#include <Teuchos_RCP.hpp>

#include "hl_Math.h"

#include "hl_OctreeElementLocator.h"


using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    OctreeElementLocator::OctreeElementLocator(std::string tag, MPI_Comm comm): ElementLocator(tag, comm)
    {
    }

    void OctreeElementLocator::_computeMeshBounds()
    {
        // Compute min and max in this partition
        vector<double> min(3,  numeric_limits<double>::max());
        vector<double> max(3, -numeric_limits<double>::max());
        for (int i = 0; i < _nPts; i++)
        {
            if (_disMesh->_nodeData->isItemInfoInPart(i))
            {
                for (int d = 0; d < _nDim; d++)
                {
                    double coord = _disMesh->nodeCoord(i, d, IndexType::Global);
                    if (coord < min[d])
                        min[d] = coord;
                    if (coord > max[d])
                        max[d] = coord;
                }
            }
        }

        // Make it per partition
        for (int d = 0; d < _nDim; d++)
        {
            _meshMin[d] = min[d];
            _meshMax[d] = max[d];
        }

        // Compute mesh diagonal
        double diagonal{};
        for (int d = 0; d < _nDim; d++)
            diagonal += _meshMax[d]-_meshMin[d];

        // If min = max, move them
        for (int d = 0; d < _nDim; d++)
        {
            if (_meshMax[d]-_meshMin[d] <= diagonal/1000.0)
            {
                _meshMin[d] -= diagonal/100.0;
                _meshMax[d] += diagonal/100.0;
            }
        }
    }

    void OctreeElementLocator::_createElements()
    {
        // Initialize vector of elements
        _elems.resize(_loc_nElem);

        // Get element data
        for (int i = 0; i < _loc_nElem; i++)
        {
            // Compute min and max  <------------------------------------------------------- FIXME: bsplines and subdiv
            int eNN = _disMesh->_adjcyEN->getNumNbors(i, IndexType::Local);
            vector<double> nborCoords = _disMesh->elemNborNodeCoords(i, IndexType::Local);
            for (int d = 0; d < _nDim; d++)
            {
                double min =  numeric_limits<double>::max();
                double max = -numeric_limits<double>::max();
                for (int n = 0; n < eNN; n++)
                {
                    double coord = nborCoords[n*_nDim+d];
                    if (coord < min)
                        min = coord;
                    if (coord > max)
                        max = coord;
                }
                _elems[i].min[d] = min;
                _elems[i].max[d] = max;
            }
        }
    }

    void OctreeElementLocator::Update()
    {
        // Check distributed mesh exists
        if (_disMesh == nullptr)
            throw runtime_error("OctreeElementLocator::Update: Distributed mesh not set.");

        // Initialize
        _nDim      = _disMesh->nDim();
        _pDim      = _disMesh->pDim();
        _nElem     = _disMesh->nElem();
        _loc_nElem = _disMesh->loc_nElem();
        _nPts      = _disMesh->nPts();
        _loc_nPts  = _disMesh->loc_nPts();

        // Compute number of levels
        if (_nLevels == -1)
            _nLevels = static_cast<int>(ceil(log(static_cast<double>(_loc_nElem)/_nElemPerOctant)/log(8.0)));
        if (_nLevels > _maxNLevels)
            _nLevels = _maxNLevels;

        // Compute number of octants
        _nOctDir = pow(2, _nLevels);
        _nOct = pow(_nOctDir, 3);

        // Create field structure
        _disMesh->_mapFieldStruct = _disMesh->_nodeData;
        _disMesh->_mapCoordX_ptr = &DistributedMesh::nodeCoord;
        _disMesh->_mapCoordY_ptr = &DistributedMesh::nodeCoord;
        _disMesh->_mapCoordZ_ptr = &DistributedMesh::nodeCoord;

        // Compute bounds <------------------------------------------------------- FIXME: Compute with previous func
        _computeMeshBounds();

        // Compute octant width and tolerance
        for (int d = 0; d < _nDim; d++)
        {
            _octWidth[d] = (_meshMax[d]-_meshMin[d])/_nOctDir;
            _octWidthTol[d] = _octWidth[d]/100.0;
        }

        // Create elements
        _createElements();

        // Add elements to octants
        _octElements.resize(_nOct);
        double *elemMin, *elemMax;
        for (int e = 0; e < _loc_nElem; e++)
        {
            // Get element min and max
            elemMin = _elems[e].min;
            elemMax = _elems[e].max;

            // Get possible octants per direction considering tolerance
            vector<int> octIdMin(3);
            vector<int> octIdMax(3);
            for (int d = 0; d < _nDim; d++)
            {
                // Min
                octIdMin[d] = static_cast<int>((elemMin[d]-_meshMin[d]-_octWidthTol[d])/_octWidth[d]);
                if (octIdMin[d] < 0)
                    octIdMin[d] = 0;

                // Max
                octIdMax[d] = static_cast<int>((elemMax[d]-_meshMin[d]+_octWidthTol[d])/_octWidth[d]);
                if (octIdMax[d] >= _nOctDir)
                    octIdMax[d] = _nOctDir-1;
            }

            // Insert element in octants
            for (int k = octIdMin[2]; k <= octIdMax[2]; k++)
            {
                for (int j = octIdMin[1]; j <= octIdMax[1]; j++)
                {
                    for (int i = octIdMin[0]; i <= octIdMax[0]; i++)
                    {
                        int octId = i + j*_nOctDir + k*_nOctDir*_nOctDir;
                        _octElements[octId].push_back(e); // <------------------------   FIXME: resize/reserve?
                    }
                }
            }
        }
    }

    vector<double> OctreeElementLocator::meshMaximum()
    {
        vector<double> meshMax(3);
        for (int i = 0; i < _nDim; i++)
            meshMax[i]= _meshMax[i];

        return meshMax;
    }

    vector<double> OctreeElementLocator::meshMinimum()
    {
        vector<double> meshMin(3);
        for (int i = 0; i < _nDim; i++)
            meshMin[i]= _meshMin[i];

        return meshMin;
    }

    double OctreeElementLocator::_distanceSqToOctant(const double x[3], const int id)
    {
        double bmin[3], bmax[3];

        int idx = id%_nOctDir;
        bmin[0] = _meshMin[0] + idx*_octWidth[0];
        bmax[0] = _meshMin[0] + (idx+1)*_octWidth[0];

        int idy = (id%(_nOctDir*_nOctDir))/_nOctDir;
        bmin[1] = _meshMin[1] + idy*_octWidth[1];
        bmax[1] = _meshMin[1] + (idy+1)*_octWidth[1];

        int idz = id/(_nOctDir*_nOctDir);
        bmin[2] = _meshMin[2] + idz*_octWidth[2];
        bmax[2] = _meshMin[2] + (idz+1)*_octWidth[2];

        return _distanceSqToBounds(x, bmin, bmax);
    }

    // Modified from vtkCellLocator
    // Note: Writing it in a loop makes it slower
    // Note: Using an array of 6 elements for the min and max makes it slightly slower  //THIS CHECK WAS DONE WITHOUT OPTIMIZATION FLAGS
    double OctreeElementLocator::_distanceSqToBounds(const double x[3], double bmin[3], double bmax[3])
    {
        // Check if the point is inside the bounds
        if (x[0] >= bmin[0] and x[0] <= bmax[0] and x[1] >= bmin[1] and x[1] <= bmax[1] and
            x[2] >= bmin[2] and x[2] <= bmax[2])
        {
            return 0.0;
        }

        // Initialize delt
        double delt[3];
        delt[0] = delt[1] = delt[2] = 0.0;

        // delta x
        if (x[0] < bmin[0])
        {
            delt[0] = bmin[0] - x[0];
        }
        else if (x[0] > bmax[0])
        {
            delt[0] = x[0] - bmax[0];
        }

        // delta y
        if (x[1] < bmin[1])
        {
            delt[1] = bmin[1] - x[1];
        }
        else if (x[1] > bmax[1])
        {
            delt[1] = x[1] - bmax[1];
        }

        // delta z
        if (x[2] < bmin[2])
        {
            delt[2] = bmin[2] - x[2];
        }
        else if (x[2] > bmax[2])
        {
            delt[2] = x[2] - bmax[2];
        }

        return Math::SNorm3D(delt);
    }

    vector<int> OctreeElementLocator::_octantRingIds(vector<int> octIdDir, const int ring)
    {
        // Return id if ring is 0
        if (ring == 0)
        {
            int octId = octIdDir[0] + octIdDir[1]*_nOctDir + octIdDir[2]*_nOctDir*_nOctDir;
            return {octId};
        }

        // Compute max and min ids for this ring
        int min[3];
        int max[3];
        for (int d = 0; d < _nDim; d++)
        {
            min[d] = octIdDir[d] - ring;
            max[d] = octIdDir[d] + ring;
            if (min[d] < 0)
                min[d] = 0;
            if (max[d] >= _nOctDir)
                max[d] = _nOctDir-1;
        }

        // Get ring ids (excluding inner rings)
        vector<int> octRingIds;
        for (int i = min[0]; i <= max[0]; i++)
        {
            for (int j = min[1]; j <= max[1]; j++)
            {
                for (int k = min[2]; k <= max[2]; k++)
                {
                    if (i == (octIdDir[0] + ring) or i == (octIdDir[0] - ring) or
                        j == (octIdDir[1] + ring) or j == (octIdDir[1] - ring) or
                        k == (octIdDir[2] + ring) or k == (octIdDir[2] - ring))
                    {
                        int octId = i + j*_nOctDir + k*_nOctDir*_nOctDir;
                        octRingIds.push_back(octId); // <------------------------   FIXME: resize/reserve?
                    }
                }
            }
        }

        return octRingIds;
    }

    vector<int> OctreeElementLocator::_octantRingIdsWithinRadius(const double x[3], const double radius, vector<bool> octantVisited)
    {
        // Get possible octants per direction
        int octIdMin[3];
        int octIdMax[3];
        for (int d = 0; d < _nDim; d++)
        {
            // Min
            octIdMin[d] = static_cast<int>(static_cast<double>((x[d]-radius-_meshMin[d])/_octWidth[d]));
            if (octIdMin[d] < 0)
                octIdMin[d] = 0;
            if (octIdMin[d] >= _nOctDir)
                octIdMin[d] = _nOctDir-1;

            // Max
            octIdMax[d] = static_cast<int>(static_cast<double>((x[d]+radius-_meshMin[d])/_octWidth[d]));
            if (octIdMax[d] < 0)
                octIdMax[d] = 0;
            if (octIdMax[d] >= _nOctDir)
                octIdMax[d] = _nOctDir-1;
        }

        // Get octant ids (excluding visited and empty octants)
        vector<int> octRingIds;
        for (int k = octIdMin[2]; k <= octIdMax[2]; k++)
        {
            for (int j = octIdMin[1]; j <= octIdMax[1]; j++)
            {
                for (int i = octIdMin[0]; i <= octIdMax[0]; i++)
                {
                    int octId = i + j*_nOctDir + k*_nOctDir*_nOctDir;
                    if (!_octElements[octId].empty() and octantVisited[octId] == false)
                        octRingIds.push_back(octId); // <------------------------   FIXME: resize/reserve?
                }
            }
        }

        return octRingIds;
    }

    double OctreeElementLocator::searchElementInPartition(int& elem, vector<double>& rCoords, vector<double> xCoords)
    {
        // Initialize
        vector<double> rCoords0(_pDim);

        // Find octant
        vector<int> octIdDir(3);
        for (int d = 0; d < _nDim; d++)
        {
            octIdDir[d] = static_cast<int>((xCoords[d]-_meshMin[d])/_octWidth[d]);
            if (octIdDir[d] < 0)
                octIdDir[d] = 0;
            if (octIdDir[d] >= _nOctDir)
                octIdDir[d] = _nOctDir-1;
        }

        // Find element within octants. Start in predicted octant (octIdDir)
        // and loop through neighbors in rings until one ring is non empty
        vector<bool> elementVisited(_loc_nElem, false); // This doesn't seem to slow the code
        vector<bool> octantVisited(_nOct, false);
        double minDistToEl = numeric_limits<double>::max();  // <----- FIXME change name to sq
        double minDistToPt = numeric_limits<double>::max();  // <----- FIXME change name to sq
        elem = -1;
        int ring;
        for (ring = 0; elem == -1 and ring < _nOctDir; ring++)
        {
            // Get octant rings
            vector<int> octRingIds = _octantRingIds(octIdDir, ring);

            // Loop over octants in the ring
            for (auto octRingId: octRingIds)
            {
                // Save octant visited
                octantVisited[octRingId] = true;

                // Order elements based on distance from point to element bounds
                int nElRing = _octElements[octRingId].size();
                vector<double> distsEl(nElRing, numeric_limits<double>::max());
                for (int i = 0; i < nElRing; i++)
                {
                    // Check whether element has already been visited
                    int loc_e = _octElements[octRingId][i];
                    if (elementVisited[loc_e] == true)
                        continue;

                    // Compute distance
                    distsEl[i] = _distanceSqToBounds(xCoords.data(), _elems[loc_e].min, _elems[loc_e].max);
                }
                std::vector<int> indices(nElRing);
                std::iota(indices.begin(), indices.end(), 0);
                std::sort(indices.begin(), indices.end(), [&](int a, int b) -> bool{return distsEl[a] < distsEl[b];});

                // Find element within octant
                for (int i = 0; i < nElRing; i++)
                {
                    // Get element
                    int index = indices[i];
                    int loc_e = _octElements[octRingId][index];

                    // Check whether element has already been visited
                    if (elementVisited[loc_e] == true)
                        continue;
                    elementVisited[loc_e] = true;

                    // If the element is within minDistToEl, invert mapping
                    if (distsEl[index] < minDistToEl)
                    {
                        // Invert mapping
                        vector<double> rCoords1(_pDim);
                        double distPt = (_disMesh->*(_disMesh->invertElementMapping))(rCoords1, loc_e, xCoords, rCoords0, IndexType::Local, true);

                        if (distPt < 0.0)
                            continue;
                        distPt *= distPt;

                        // Save
                        if (distPt < minDistToPt)
                        {
                            minDistToPt = distPt;
                            minDistToEl = distPt;
                            for (int i = 0; i < _pDim; i++)
                                rCoords[i] = rCoords1[i];
                            int e = _disMesh->globalElemId(loc_e);
                            elem = e;
                        }
                    }
                }
            }
        }

        // The found element may not be the correct one if the point was not
        // inside the zero ring. We need to loop through neighboring octants
        // in the next ring that are within a radius minDistToPt
        if (minDistToPt > 1.e-6 and ring < _nOctDir)
        {
            // Get octants that are within the radius minDistToPt to the point
            vector<int> octRingIds = _octantRingIdsWithinRadius(xCoords.data(), sqrt(minDistToPt), octantVisited);

            // Loop over octants
            for (auto octRingId: octRingIds)
            {
                // Skip this octant if it is not within radius minDistToPt
                double octDist = _distanceSqToOctant(xCoords.data(), octRingId);
                if (octDist > minDistToPt)
                    continue;

                // Order elements based on distance from point to element bounds
                int nElRing = _octElements[octRingId].size();
                vector<double> distsEl(nElRing, numeric_limits<double>::max());
                for (int i = 0; i < nElRing; i++)
                {
                    // Check whether element has already been visited
                    int loc_e = _octElements[octRingId][i];
                    if (elementVisited[loc_e] == true)
                        continue;

                    // Compute distance
                    distsEl[i] = _distanceSqToBounds(xCoords.data(), _elems[loc_e].min, _elems[loc_e].max);
                }
                std::vector<int> indices(nElRing);
                std::iota(indices.begin(), indices.end(), 0);
                std::sort(indices.begin(), indices.end(), [&](int a, int b) -> bool{return distsEl[a] < distsEl[b];});

                // Find element within octant
                for (int i = 0; i < nElRing; i++)
                {
                    // Get element
                    int index = indices[i];
                    int loc_e = _octElements[octRingId][index];

                    // Check whether element has already been visited
                    if (elementVisited[loc_e] == true)
                        continue;
                    elementVisited[loc_e] = true;

                    // If the element is within minDistToEl, invert mapping
                    if (distsEl[index] < minDistToEl)
                    {
                        // Invert mapping
                        vector<double> rCoords1(_pDim);
                        double distPt = (_disMesh->*(_disMesh->invertElementMapping))(rCoords1, loc_e, xCoords, rCoords0, IndexType::Local, true);

                        if (distPt < 0.0)
                            continue;
                        distPt *= distPt;

                        // Save
                        if (distPt < minDistToPt)
                        {
                            minDistToPt = distPt;
                            minDistToEl = distPt;
                            for (int i = 0; i < _pDim; i++)
                                rCoords[i] = rCoords1[i];
                            int e = _disMesh->globalElemId(loc_e);
                            elem = e;
                        }
                    }
                }
            }
        }

        return minDistToPt;
    }

    vector<double> OctreeElementLocator::searchElement(vector<int>& elems, vector<vector<double>>& rCoords, vector<vector<double>> xCoords)
    {
        // Get distances from points to partitions
        int nPoints = static_cast<int> (xCoords.size());
        vector<double> distSqToPartition(nPoints);
        for (int n = 0; n < nPoints; n++)
            distSqToPartition[n] = _distanceSqToBounds(xCoords[n].data(), _meshMin, _meshMax);

        // Compute minimum distances across partitions
        vector<double> min_distSqToPartitions(nPoints);
        MPI_Allreduce(distSqToPartition.data(), min_distSqToPartitions.data(), nPoints, MPI_DOUBLE, MPI_MIN, comm());

        // Initialize
        vector<double> dists(nPoints, numeric_limits<double>::max());
        elems.resize(nPoints);
        rCoords.resize(nPoints, vector<double>(_nDim));

        // Search element in predicted closest(s) processors
        for (int n = 0; n < nPoints; n++)
        {
            if ((min_distSqToPartitions[n] < 1e-6 and distSqToPartition[n] < 1e-6) or
                (min_distSqToPartitions[n] > 1e-6 and abs(min_distSqToPartitions[n]-distSqToPartition[n]) < 1e-6))
                dists[n] = searchElementInPartition(elems[n], rCoords[n], xCoords[n]);
        }

        // Compute minimum distances across partitions
        vector<double> min_dists(nPoints);
        MPI_Allreduce(dists.data(), min_dists.data(), nPoints, MPI_DOUBLE, MPI_MIN, comm());

        // If not found, look in nearby processors
        for (int n = 0; n < nPoints; n++)
        {
            if (min_dists[n] > 1e-6 and min_dists[n] >= distSqToPartition[n] and distSqToPartition[n] > 0.0)
                dists[n] = searchElementInPartition(elems[n], rCoords[n], xCoords[n]);
        }

        // Get (processor) location of the min distances
        struct distsAndProcs
        {
             double dist;
             int rank;
        };
        distsAndProcs * out = new distsAndProcs[nPoints];
        distsAndProcs * in  = new distsAndProcs[nPoints];
        for (int n = 0; n < nPoints; n++)
        {
            out[n].dist = dists[n];
            out[n].rank = _myRank;
        }
        MPI_Allreduce(out, in, nPoints, MPI_DOUBLE_INT, MPI_MINLOC, comm());

        // Share elems and rCoords //FIXME:: We are doing a loop, is there a more efficient way?
        for (int n = 0; n < nPoints; n++)
        {
            MPI_Bcast(&elems[n], 1, MPI_INT, in[n].rank, comm());
            MPI_Bcast(rCoords[n].data(), _pDim, MPI_DOUBLE, in[n].rank, comm());

            // Check
            if (in[n].dist < 0.0)
                throw runtime_error("ElementLocator::searchElement: Element not found");
        }

        // Delete
        delete[] out;
        delete[] in;

        return dists;  // FIXME:: This distance has not been shared among processors
    }

}
