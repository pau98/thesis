/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#include "hl_Math.h"
#include "hl_ElementLocator.h"
#include "hl_DistributedMesh.h"


using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{
    // Search
    vector<double> DistributedMesh::searchElementInPartition(vector<int>& elems, vector<vector<double>>& rCoords, vector<vector<double>> xCoords)
    {
        return _elementLocator->searchElementInPartition(elems, rCoords, xCoords);
    }

    double DistributedMesh::searchElementInPartition(int& elem, vector<double>& rCoords, vector<double> xCoords)
    {
        // Search element
        vector<int> elems;
        vector<vector<double>> rCs;
        vector<vector<double>> xCs(1, xCoords);
        vector<double> dists = _elementLocator->searchElementInPartition(elems, rCs, xCs);

        // Save
        elem = elems[0];
        rCoords = rCs[0];

        return dists[0];
    }

    vector<double> DistributedMesh::searchElement(vector<int>& elems, vector<vector<double>>& rCoords, vector<vector<double>> xCoords)
    {
        return _elementLocator->searchElement(elems, rCoords, xCoords);
    }

    double DistributedMesh::searchElement(int& elem, vector<double>& rCoords, vector<double> xCoords)
    {
        // Search element
        vector<int> elems;
        vector<vector<double>> rCs;
        vector<vector<double>> xCs(1, xCoords);
        vector<double> dists = _elementLocator->searchElement(elems, rCs, xCs);

        // Save
        elem = elems[0];
        rCoords = rCs[0];

        return dists[0];
    }


    // Interpolate
    void DistributedMesh::interpolatePosition(vector<double>& xCoords, int elem, vector<double> rCoord, IndexType type)
    {
        // Compute basis functions at rCoord
        int tag = _basisFunctions->getTag(elem, type);
        vector<vector<double>> BF = _basisFunctions->computeBasisFunctionsReference(rCoord, tag, 0);

        // Get element nbor node coordinates
        vector<double> nborCoords = elemNborNodeCoords(elem, type);

        // Compute coordinates
        int eNN = _adjcyEN->getNumNbors(elem, type);
        Math::MatTMult(xCoords.data(), 1, eNN, _nDim, BF[0].data(), nborCoords.data());
    }

    vector<double> DistributedMesh::interpolatePosition(int elem, vector<double> rCoord, IndexType type)
    {
        // Interpolate
        vector<double> xCoords(_nDim);
        interpolatePosition(xCoords, elem, rCoord, type);

        return xCoords;
    }

    vector<vector<double>> DistributedMesh::closestPointProjection(vector<vector<double>> xCoords)
    {
        // Check
        if (_elementLocator == Teuchos::null)
            throw runtime_error("DistributedMesh::closestPointProjection: The element locator is empty.");

        // Initialize
        int nPoints = xCoords.size();

        // Search elements in partition
        vector<int> elems;
        vector<vector<double>> rCoords;
        vector<double> dists = searchElementInPartition(elems, rCoords, xCoords);

        // Get (processor) location of the min distances
        struct distsAndProcs
        {
             double dist;
             int rank;
        };
        distsAndProcs * out = new distsAndProcs[nPoints];
        distsAndProcs * in  = new distsAndProcs[nPoints];
        for (int n = 0; n < nPoints; n++)
        {
            out[n].dist = dists[n];
            out[n].rank = _myRank;
        }
        MPI_Allreduce(out, in, nPoints, MPI_DOUBLE_INT, MPI_MINLOC, comm());

        // Interpolate positions locally
        vector<vector<double>> xCPP(nPoints, vector<double>(_nDim, 0.0));
        for (int n = 0; n < nPoints; n++)
        {
            // Check
            if (in[n].dist < 0.0)
                throw runtime_error("DistributedMesh::closestPointProjection: Error finding point. Element not found.");

            // Interpolate
            if (_myRank == in[n].rank)
                xCPP[n] = interpolatePosition(elems[n], rCoords[n], IndexType::Global);
        }

        // Share closest point projection //FIXME:: We are doing a loop, is there a more efficient way?
        for (int n = 0; n < nPoints; n++)
            MPI_Bcast(xCPP[n].data(), _nDim, MPI_DOUBLE, in[n].rank, comm());

        // Delete
        delete[] out;
        delete[] in;

        return xCPP;
    }
}
