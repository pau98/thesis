/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_Geometry.h"
#include "hl_Math.h"
#include "hl_Array.h"

#include "hl_DistributedMesh.h"
#include "hl_TypeDefs.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    vector<double> DistributedMesh::_mapCoords(int node, IndexType idxtype)
    {
        vector<double> coords(3);

        coords[0] = (this->*(this->_mapCoordX_ptr))(node, 0, idxtype);
        coords[1] = (this->*(this->_mapCoordY_ptr))(node, 1, idxtype);
        coords[2] = (this->*(this->_mapCoordZ_ptr))(node, 2, idxtype);

        return coords;
    }

    vector<double> DistributedMesh::_elemNborMapCoords(int elem, IndexType idxType)
    {
        // Initialize vector
        int eNN = _adjcyEN->getNumNbors(elem, idxType);
        vector<double> nborCoords(eNN*_nDim);

        // Save coordinates
        vector<int> nbors = _adjcyEN->getNborList(elem, idxType);
        for (int i = 0; i < eNN; i++)
        {
            nborCoords[i*_nDim+0] = (this->*(this->_mapCoordX_ptr))(nbors[i], 0, IndexType::Global);
            nborCoords[i*_nDim+1] = (this->*(this->_mapCoordY_ptr))(nbors[i], 1, IndexType::Global);
            nborCoords[i*_nDim+2] = (this->*(this->_mapCoordZ_ptr))(nbors[i], 2, IndexType::Global);
        }

        return nborCoords;
    }

    //FIXME:: Remove vectors
    // Adapted from vtkTriang.cxx
    double DistributedMesh::_invertElementMapping_LinearTriangle(vector<double>& rCoords, int elem, vector<double> xCoords, vector<double> rCoords0, IndexType idxType, bool checkPointOutside)
    {
        // Get local element
        int loc_el = elem;
        if (idxType == IndexType::Global)
            loc_el = localElemId(elem);

        // Save neighbors' coordinates
        vector<double> nborCoords = _elemNborMapCoords(loc_el, IndexType::Local);

        // Get node coordinates
        double p0[3], p1[3], p2[3];
        for (int d = 0; d < _nDim; d++)
        {
            p0[d] = nborCoords[0*3+d];
            p1[d] = nborCoords[1*3+d];
            p2[d] = nborCoords[2*3+d];
        }

        // Compute normal direction
        double v01[3], v02[3], n[3];
        for (int d = 0; d < 3; d++)
        {
            v01[d] = p1[d]-p0[d];
            v02[d] = p2[d]-p0[d];
        }
        Math::Cross(n, v01, v02);

        // Project point to plane
        double xp[3];
        SGeometry::projectPointToPlane(xp, n, p0, xCoords.data());

        // Choose two out of three coordinates (since the problem is over-determined
        // we can use only two of them). Choose those with less distorsion
        int maxId;
        double maxNi = -std::numeric_limits<double>::max();
        for (int d = 0; d < 3; d++)
        {
            if (abs(n[d]) > maxNi)
            {
                maxNi = abs(n[d]);
                maxId = d;
            }
        }
        int ind[2];
        int j = 0;
        for (int d = 0; d < 3; d++)
        {
            if (d != maxId)
                ind[j++] = d;
        }

        // Create linear system
        double A[4];
        A[0] = p1[ind[0]] - p0[ind[0]];
        A[1] = p2[ind[0]] - p0[ind[0]];
        A[2] = p1[ind[1]] - p0[ind[1]];
        A[3] = p2[ind[1]] - p0[ind[1]];
        double b[2];
        b[0] = xp[ind[0]] - p0[ind[0]];
        b[1] = xp[ind[1]] - p0[ind[1]];

        // Solve the system
        int solved = Math::SolveEq2x2(rCoords.data(), A, b);
        if (solved >= 1)
            return -1.0;  // FIXME:: Check that this is coherent

        // If rCoords are outside the reference element, move them to its boundary
        if (checkPointOutside)
        {
            if (rCoords[0] < 0.0 and rCoords[1] < 0.0)
            {
                double distCorner = Math::Dist3D(xCoords.data(), p0);
                double t1;
                double distLine1 = SGeometry::projectPointToSegment(xCoords.data(), p0, p1, t1);
                double t2;
                double distLine2 = SGeometry::projectPointToSegment(xCoords.data(), p0, p2, t2);
                double dist;
                if (distCorner < distLine1)
                {
                    dist = distCorner;
                    rCoords[0] = 0.0;
                    rCoords[1] = 0.0;
                }
                else
                {
                    dist = distLine1;
                    rCoords[0] = t1;
                    rCoords[1] = 0.0;
                }
                if (distLine2 < dist)
                {
                    rCoords[0] = 0.0;
                    rCoords[1] = t2;
                }
            }
            else if (rCoords[0] < 0.0 and rCoords[0]+rCoords[1] > 1.0)
            {
                double distCorner = Math::Dist3D(xCoords.data(), p2);
                double t1;
                double distLine1 = SGeometry::projectPointToSegment(xCoords.data(), p0, p2, t1);
                double t2;
                vector<double> xp(3);
                double distLine2 = SGeometry::projectPointToSegment(xCoords.data(), p1, p2, t2, xp.data());
                double dist;
                if (distCorner < distLine1)
                {
                    dist = distCorner;
                    rCoords[0] = 0.0;
                    rCoords[1] = 0.0;
                }
                else
                {
                    dist = distLine1;
                    rCoords[0] = 0.0;
                    rCoords[1] = t1;
                }
                if (distLine2 < dist)
                {
                    (this->*(this->invertElementMapping))(rCoords, loc_el, xp, rCoords0, IndexType::Local, false);
                }
            }
            else if (rCoords[1] < 0.0 and rCoords[0]+rCoords[1] > 1.0)
            {
                double distCorner = Math::Dist3D(xCoords.data(), p2);
                double t1;
                double distLine1 = SGeometry::projectPointToSegment(xCoords.data(), p0, p1, t1);
                double t2;
                vector<double> xp(3);
                double distLine2 = SGeometry::projectPointToSegment(xCoords.data(), p1, p2, t2, xp.data());
                double dist;
                if (distCorner < distLine1)
                {
                    dist = distCorner;
                    rCoords[0] = 0.0;
                    rCoords[1] = 0.0;
                }
                else
                {
                    dist = distLine1;
                    rCoords[0] = t1;
                    rCoords[1] = 0.0;
                }
                if (distLine2 < dist)
                {
                    (this->*(this->invertElementMapping))(rCoords, loc_el, xp, rCoords0, IndexType::Local, false);
                }
            }
            else if (rCoords[0] < 0.0)
            {
                rCoords[0] = 0.0;
                SGeometry::projectPointToSegment(xCoords.data(), p0, p2, rCoords[1]);
            }
            else if (rCoords[1] < 0.0)
            {
                rCoords[1] = 0.0;
                SGeometry::projectPointToSegment(xCoords.data(), p0, p1, rCoords[0]);
            }
            else if (rCoords[0]+rCoords[1] > 1.0)
            {
                double t;
                vector<double> xp(3);
                SGeometry::projectPointToSegment(xCoords.data(), p1, p2, t, xp.data());
                (this->*(this->invertElementMapping))(rCoords, loc_el, xp, rCoords0, IndexType::Local, false);
            }
        }

        // Compute closest point
        vector<vector<double>> bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, 0, 0);
        double gCoords[3];
        Math::MatTMult(gCoords, 1, 3, 3, bfDers[0].data(), nborCoords.data());

        // Return distance
        return Math::Dist3D(xCoords.data(), gCoords); // FIXME:: Should we return an squared distance???
    }

    //FIXME:: Remove vectors
    double DistributedMesh::_invertElementMapping_LinearSquare(vector<double>& rCoords, int elem, vector<double> xCoords, vector<double> rCoords0, IndexType idxType, bool checkPointOutside)
    {
        // Get local element
        int loc_el = elem;
        if (idxType == IndexType::Global)
            loc_el = localElemId(elem);

        // Save neighbors' coordinates
        vector<double> nborCoords = _elemNborMapCoords(loc_el, IndexType::Local);

        // Get node coordinates
        double p0[3], p1[3], p2[3], p3[3];
        for (int d = 0; d < _nDim; d++)
        {
            p0[d] = nborCoords[0*3+d];
            p1[d] = nborCoords[1*3+d];
            p2[d] = nborCoords[2*3+d];
            p3[d] = nborCoords[3*3+d];
        }

        // Compute normal direction // FIXME: If the element is superdistorted, we may have problems
        double v01[3], v03[3], n[3];
        for (int d = 0; d < 3; d++)
        {
            v01[d] = p1[d]-p0[d];
            v03[d] = p3[d]-p0[d];
        }
        Math::Cross(n, v01, v03);

        // Choose two out of three coordinates (since the problem is over-determined
        // we can use only two of them). Choose those with less distorsion
        int maxId;
        double maxNi = -std::numeric_limits<double>::max();
        for (int d = 0; d < 3; d++)
        {
            if (abs(n[d]) > maxNi)
            {
                maxNi = abs(n[d]);
                maxId = d;
            }
        }
        int ind[2];
        int j = 0;
        for (int d = 0; d < 3; d++)
        {
            if (d != maxId)
                ind[j++] = d;
        }

        // Compute 1D jacobian of the parent element to parameter space for Bsplines/Nurbs
        double jac{1.0};
        if (_basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs)
        {
            int inex = elem % _nElemX;
            // Knot offset of the element's curve (7 extra knots per earlier curve),
            // found from the unshifted element index
            int offU = 0;
            for(int i = 0; i < (int)_vCrv.size(); i++)
            {
                if (inex < _vCrv[i])
                {
                    break;
                }
                offU += 7;
            }
            inex += offU;
            jac = (_uKnot[_bfOrderX+inex+1]-_uKnot[_bfOrderX+inex])/2.0;
        }

        // Initial guess
        rCoords[0] = rCoords0[0];
        rCoords[1] = rCoords0[1];

        // Solve the system using a Newton-Raphson (analytical
        // solutions fail due to differences between small values)
        bool converged{false};
        vector<vector<double>> bfDers;
        double A[4], b[2], sol[2];
        for (int k = 0; !converged and k < 10; k++)
        {
            // Evaluate basis functions and derivatives (tag=0 also works for BSplines and NURBS as they are linear)
            bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, 0);

            // Create linear system
            Array::Fill(A, 4, 0.0);
            Array::Fill2D(b, 0.0);
            for (int i = 0; i < 4; i++)
            {
                // Partial fill rhs
                b[0] += bfDers[0][i]*nborCoords[i*3+ind[0]];
                b[1] += bfDers[0][i]*nborCoords[i*3+ind[1]];

                // Fill matrix
                A[0] += bfDers[1][i*2+0]*nborCoords[i*3+ind[0]];
                A[1] += bfDers[1][i*2+1]*nborCoords[i*3+ind[0]];
                A[2] += bfDers[1][i*2+0]*nborCoords[i*3+ind[1]];
                A[3] += bfDers[1][i*2+1]*nborCoords[i*3+ind[1]];
            }
            b[0] -= xCoords[ind[0]];
            b[1] -= xCoords[ind[1]];

            // Solve the system
            int solved = Math::SolveEq2x2(sol, A, b);
            if (solved >= 1)
                return -1.0;  // FIXME:: Check that this is coherent

            // Divide by 1D jacobian of the parent element to parameter space for Bsplines/Nurbs
            if (_basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs)
            {
                sol[0] /= jac;
                sol[1] /= jac;
            }

            // Update solution
            rCoords[0] -= sol[0];
            rCoords[1] -= sol[1];

            // Check convergence
            if (fabs(sol[0]) < 1e-4 and fabs(sol[1]) < 1e-4)
                converged = true;
            else if (fabs(rCoords[0]) > 1e6 or fabs(rCoords[1]) > 1e6) // ??
                return -1.0;  // FIXME:: Check that this is coherent
        }

        // Check convergence
        if (!converged)
            return -1.0;

        // If rCoords are outside the reference element, move them to its boundary
        if (checkPointOutside)
        {
            if (rCoords[0] < -1.0 and rCoords[1] < -1.0)
            {
                rCoords[0] = -1.0;
                rCoords[1] = -1.0;
            }
            else if (rCoords[0] < -1.0 and rCoords[1] > 1.0)
            {
                rCoords[0] = -1.0;
                rCoords[1] =  1.0;
            }
            else if (rCoords[0] > 1.0 and rCoords[1] < -1.0)
            {
                rCoords[0] =  1.0;
                rCoords[1] = -1.0;
            }
            else if (rCoords[0] > 1.0 and rCoords[1] > 1.0)
            {
                rCoords[0] =  1.0;
                rCoords[1] =  1.0;
            }
            else if (rCoords[0] < -1.0)
            {
                rCoords[0] = -1.0;
                SGeometry::projectPointToSegment(xCoords.data(), p0, p2, rCoords[1]);
                rCoords[1] = rCoords[1]*2.0-1.0;
            }
            else if (rCoords[0] > 1.0)
            {
                rCoords[0] = 1.0;
                SGeometry::projectPointToSegment(xCoords.data(), p1, p3, rCoords[1]);
                rCoords[1] = rCoords[1]*2.0-1.0;
            }
            else if (rCoords[1] < -1.0)
            {
                rCoords[1] = -1.0;
                SGeometry::projectPointToSegment(xCoords.data(), p0, p1, rCoords[0]);
                rCoords[0] = rCoords[0]*2.0-1.0;
            }
            else if (rCoords[1] > 1.0)
            {
                rCoords[1] =  1.0;
                SGeometry::projectPointToSegment(xCoords.data(), p2, p3, rCoords[0]);
                rCoords[0] = rCoords[0]*2.0-1.0;
            }
        }

        // Compute closest point
        bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, 0, 0);
        double gCoords[3];
        Math::MatTMult(gCoords, 1, 4, 3, bfDers[0].data(), nborCoords.data());

        // Return distance
        return Math::Dist3D(xCoords.data(), gCoords); // FIXME:: Should we return an squared distance???
    }

    double DistributedMesh::_invertElementMapping_RegSquare(vector<double>& rCoords, int elem, vector<double> xCoords, IndexType idxType, bool checkPointOutside)
    {
        // FIXME: Assumes elem nodes ordered and elements not rotated
        // Get local element
        int loc_el = elem;
        if (idxType == IndexType::Global)
            loc_el = localElemId(elem);

        // Save neighbors' coordinates
        vector<double> elCrnrs = _elemNborCornerCoords(loc_el, IndexType::Local);
        vector<double> x0 = {elCrnrs[0],elCrnrs[1]};
        vector<double> x1 = {elCrnrs[9],elCrnrs[10]};

        // We use a linear transfomation, independent for each coordiante
        for(int i{}; i < 2; i++)
            rCoords[i] = (2.*xCoords[i]-x1[i]-x0[i])/(x1[i]-x0[i]);

        // Query point as 3D (callers may pass 2D points)
        double xC[3] = {xCoords[0], xCoords[1], xCoords.size() > 2 ? xCoords[2] : 0.};

        // Get node coordinates
        double p0[3] = {}, p1[3] = {}, p2[3] = {}, p3[3] = {};
        for (int d = 0; d < _nDim; d++)
        {
            p0[d] = elCrnrs[0*3+d];
            p1[d] = elCrnrs[1*3+d];
            p2[d] = elCrnrs[2*3+d];
            p3[d] = elCrnrs[3*3+d];
        }

        // If rCoords are outside the reference element, move them to its boundary
        if (checkPointOutside)
        {
            if (rCoords[0] < -1.0 and rCoords[1] < -1.0)
            {
                rCoords[0] = -1.0;
                rCoords[1] = -1.0;
            }
            else if (rCoords[0] < -1.0 and rCoords[1] > 1.0)
            {
                rCoords[0] = -1.0;
                rCoords[1] =  1.0;
            }
            else if (rCoords[0] > 1.0 and rCoords[1] < -1.0)
            {
                rCoords[0] =  1.0;
                rCoords[1] = -1.0;
            }
            else if (rCoords[0] > 1.0 and rCoords[1] > 1.0)
            {
                rCoords[0] =  1.0;
                rCoords[1] =  1.0;
            }
            else if (rCoords[0] < -1.0)
            {
                rCoords[0] = -1.0;
                SGeometry::projectPointToSegment(xC, p0, p2, rCoords[1]);
                rCoords[1] = rCoords[1]*2.0-1.0;
            }
            else if (rCoords[0] > 1.0)
            {
                rCoords[0] = 1.0;
                SGeometry::projectPointToSegment(xC, p1, p3, rCoords[1]);
                rCoords[1] = rCoords[1]*2.0-1.0;
            }
            else if (rCoords[1] < -1.0)
            {
                rCoords[1] = -1.0;
                SGeometry::projectPointToSegment(xC, p0, p1, rCoords[0]);
                rCoords[0] = rCoords[0]*2.0-1.0;
            }
            else if (rCoords[1] > 1.0)
            {
                rCoords[1] =  1.0;
                SGeometry::projectPointToSegment(xC, p2, p3, rCoords[0]);
                rCoords[0] = rCoords[0]*2.0-1.0;
            }
        }
        
        double gCoords[3];
        for(int i{}; i < 2; i++)
            gCoords[i] = 0.5*((x1[i]-x0[i])*rCoords[i]+x1[i]+x0[i]);
        gCoords[2] = 0.;

        // Return distance
        return Math::Dist3D(xC, gCoords); // FIXME:: Should we return an squared distance???
    }

    //FIXME:: Remove vectors
    double DistributedMesh::_invertElementMapping_LinearParallelep(vector<double>& rCoords, int elem, vector<double> xCoords, vector<double> rCoords0, IndexType idxType, bool checkPointOutside)
    {
        // Get local element
        int loc_el = elem;
        if (idxType == IndexType::Global)
            loc_el = localElemId(elem);

        // Save neighbors' coordinates
        vector<double> nborCoords = _elemNborMapCoords(loc_el, IndexType::Local);

        // Compute 1D jacobian of the parent element to parameter space for Bsplines/Nurbs
        double jac{1.0};
        if (_basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs)
        {
            int inex = elem % _nElemX;
            // Knot offset of the element's curve (7 extra knots per earlier curve),
            // found from the unshifted element index
            int offU = 0;
            for(int i = 0; i < (int)_vCrv.size(); i++)
            {
                if (inex < _vCrv[i])
                {
                    break;
                }
                offU += 7;
            }
            inex += offU;
            jac = (_uKnot[_bfOrderX+inex+1]-_uKnot[_bfOrderX+inex])/2.0;
        }

        // Initial guess
        rCoords[0] = rCoords0[0];
        rCoords[1] = rCoords0[1];
        rCoords[2] = rCoords0[2];

        // Solve the system using a Newton-Raphson (analytical
        // solutions fail due to differences between small values)
        bool converged{false};
        vector<vector<double>> bfDers;
        double A[9], b[3], sol[3];
        for (int k = 0; !converged and k < 10; k++)
        {
            // Evaluate basis functions and derivatives (tag=0 also works for BSplines and NURBS as they are linear)
            bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, 0);

            // Create linear system
            Array::Fill(A, 9, 0.0);
            Array::Fill3D(b, 0.0);
            for (int i = 0; i < 8; i++)
            {
                // Partial fill rhs
                b[0] += bfDers[0][i]*nborCoords[i*3+0];
                b[1] += bfDers[0][i]*nborCoords[i*3+1];
                b[2] += bfDers[0][i]*nborCoords[i*3+2];

                // Fill matrix
                A[0] += bfDers[1][i*3+0]*nborCoords[i*3+0];
                A[1] += bfDers[1][i*3+1]*nborCoords[i*3+0];
                A[2] += bfDers[1][i*3+2]*nborCoords[i*3+0];

                A[3] += bfDers[1][i*3+0]*nborCoords[i*3+1];
                A[4] += bfDers[1][i*3+1]*nborCoords[i*3+1];
                A[5] += bfDers[1][i*3+2]*nborCoords[i*3+1];

                A[6] += bfDers[1][i*3+0]*nborCoords[i*3+2];
                A[7] += bfDers[1][i*3+1]*nborCoords[i*3+2];
                A[8] += bfDers[1][i*3+2]*nborCoords[i*3+2];
            }
            b[0] -= xCoords[0];
            b[1] -= xCoords[1];
            b[2] -= xCoords[2];

            // Solve the system
            int solved = Math::SolveEq3x3(sol, A, b);
            if (solved >= 1)
                return -1.0;  // FIXME:: Check that this is coherent

            // Divide by 1D jacobian of the parent element to parameter space for Bsplines/Nurbs
            if (_basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs)
            {
                sol[0] /= jac;
                sol[1] /= jac;
                sol[2] /= jac;
            }

            // Update solution
            rCoords[0] -= sol[0];
            rCoords[1] -= sol[1];
            rCoords[2] -= sol[2];

            // Check convergence
            if (fabs(sol[0]) < 1e-4 and fabs(sol[1]) < 1e-4 and fabs(sol[2]) < 1e-4)
                converged = true;
            else if (fabs(rCoords[0]) > 1e6 or fabs(rCoords[1]) > 1e6 or fabs(rCoords[2]) > 1e6) // ??
                return -1.0;  // FIXME:: Check that this is coherent
        }

        // Check convergence
        if (!converged)
            return -1.0;

        // If rCoords are outside the reference element, move them to its boundary
        if (checkPointOutside)
        {
            // FIXME:: This is just an approximation. We should project the point on the faces
            for (int i = 0; i < 3; i++)
            {
                if (rCoords[i] < -1.0)
                    rCoords[i] = - 1.0;
                else if (rCoords[i] > 1.0)
                    rCoords[i] = 1.0;
            }
        }

        // Compute closest point
        bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, 0, 0);
        double gCoords[3];
        Math::MatTMult(gCoords, 1, 8, 3, bfDers[0].data(), nborCoords.data());

        // Return distance
        return Math::Dist3D(xCoords.data(), gCoords); // FIXME:: Should we return an squared distance???
    }

    #include "hl_Tensor.h"
    double DistributedMesh::_invertElementMapping(vector<double>& rCoords, int elIdx, vector<double> xCoords, vector<double> rCoords0, IndexType idxType, bool checkPointOutside)
    {
        // checkPointOutside not used
        (void) checkPointOutside;

        using std::vector;
        using namespace hiperlife::Tensor; //FIXME: Remove tensors

        // Get element in global id
        int elem = elIdx;
        if (idxType == IndexType::Local)
            elem = _adjcyEN->globIdx(elIdx);

        // Initialize vectors
        vector<vector<double>> bfDers;
        tensor<double,1,false> x_f(xCoords.data(), _nDim);

        // Get element tag
        int tag = _basisFunctions->getTag(elem, IndexType::Global);

        // Save neighbors' coordinates
        int eNN = _adjcyEN->getNumNbors(elem);
        vector<double> nborCoords = _elemNborMapCoords(elem);
        tensor<double, 2, false> nborX(nborCoords.data(), eNN, _nDim);

        // Compute 1D jacobian of the parent element to parameter space for Bsplines/Nurbs
        double jac{1.0};
        if ((_basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs))
        {
            int inex = elem % _nElemX;
            // Knot offset of the element's curve (7 extra knots per earlier curve),
            // found from the unshifted element index
            int offU = 0;
            for(int i = 0; i < (int)_vCrv.size(); i++)
            {
                if (inex < _vCrv[i])
                {
                    break;
                }
                offU += 7;
            }
            inex += offU;
            jac = (_uKnot[_bfOrderX+inex+1]-_uKnot[_bfOrderX+inex])/2.0;
        }

        // Initial guess
        for (int i = 0; i < _pDim; i++)
            rCoords[i] = rCoords0[i];

        // Minimize f(chi) = ||x - sum(N_a(chi)*x_a)||^2 using a Newton-Raphson
        double f0{};
        int repeat{};
        bool found{true};
        for (int k = 0; k < 10; k++)
        {
            // Evaluate basis functions at rCoords0
            // bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, elem, IndexType::Global);
            // bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, tag);
            bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, tag, min(_bfOrder, 2));
            tensor<double,1,false>  bf(bfDers[0].data(), eNN);
            tensor<double,2,false> gbf(bfDers[1].data(), eNN, _pDim);

            // Compute auxiliary tensors
            tensor<double,1> x0 = bf*nborX;                     // nDim
            tensor<double,1>  v = x_f-x0;                       // nDim
            tensor<double,2> gx = product(nborX, gbf, {{0,0}}); // nDim x pDim

            // Compute f, its gradient and its hessian
            double f = v*v;                                     // 1
            tensor<double,1> gf = -2.0*(v*gx);                  // pDim
            tensor<double,2> hf = 2.0*product(gx,gx,{{0,0}});   // pDim x pDim
            if (_bfOrder > 1)
            {
                tensor<double,3,false> hbf(bfDers[2].data(), eNN, _pDim, _pDim);
                tensor<double,3> hx = product(nborX, hbf, {{0,0}}); // nDim x pDim x pDim
                hf -= 2.0*(v*hx);
            }

            // Solve the system and update solution
            tensor<double,1> sol(_pDim);
            if (_pDim == 1)
                sol(0) = (gf(0)/hf(0,0))/jac;
            else
                sol = (gf*hf.inv())/jac;
            for (int i = 0; i < _pDim; i++)
                rCoords[i] = rCoords0[i] - sol(i);

            // Check that the new rCoords are not outside the reference element
            if (elemType() == ElemType::Line or elemType() == ElemType::Square or elemType() == ElemType::Parallelep)
            {
                for (int i = 0; i < _pDim; i++)
                    if (rCoords[i] > 1.0 or rCoords[i] < -1.0)
                        found = false;
            }
            else if (elemType() == ElemType::Triang)
            {
                if (rCoords[0] < 0.0 or rCoords[1] < 0.0 or rCoords[0]+rCoords[1] > 1.0)
                    found = false;
            }
            else if (elemType() == ElemType::Tetrah)
            {
                if (rCoords[0] < 0.0 or rCoords[1] < 0.0 or rCoords[2] < 0.0 or
                    rCoords[0]+rCoords[1]+rCoords[2] > 1.0)
                    found = false;
                cout << "DistributedMesh::invertMapping never checked for tetrah" << endl;
            }
            else
            {
                throw runtime_error("invertElementMapping: elementType not implemented");
            }

            // Check if it was found, but allow repetition in case the element is on the border
            if (!found)
            {
                if (elemType() == ElemType::Line or elemType() == ElemType::Square or elemType() == ElemType::Parallelep)
                {
                    for (int i = 0; i < _pDim; i++)
                    {
                        if (rCoords[i] < -1.0)
                            rCoords[i] = - 1.0;
                        else if (rCoords[i] > 1.0)
                            rCoords[i] = 1.0;
                    }
                }
                else if (elemType() == ElemType::Triang)
                {
                    // Project to hypotenuse
                    if (rCoords[0]+rCoords[1] > 1.0)
                    {
                        rCoords[0] = 0.5*(1.0-rCoords[1]+rCoords[0]);
                        rCoords[1] = 1.0 - rCoords[0];
                    }

                    for (int i = 0; i < _pDim; i++)
                    {
                        if (rCoords[i] < 0.0)
                            rCoords[i] =  0.0;
                        else if (rCoords[i] > 1.0)
                            rCoords[i] = 1.0;
                    }
                }
                else if (elemType() == ElemType::Tetrah)
                {
                    // Project to tilted plane
                    if (rCoords[0]+rCoords[1]+rCoords[2] > 1.0 + 1e-14)
                    {
                        double l = 1.0/3.0*(rCoords[0]+rCoords[1]+rCoords[2]-1.0);
                        rCoords[0] = rCoords[0] - l;
                        rCoords[1] = rCoords[1] - l;
                        rCoords[2] = rCoords[2] - l;
                    }

                    for (int i = 0; i < _pDim; i++)
                    {
                        if (rCoords[i] < 0.0)
                            rCoords[i] =  0.0;
                        else if (rCoords[i] > 1.0)
                            rCoords[i] = 1.0;
                    }
                }
                else
                {
                    throw runtime_error("invertElementMapping: elementType not implemented");
                }

                found = true;
                repeat++;
            }

            // End if algorithm did not find solution within element
            if (repeat > 3)
                break;

            // Check convergence
            if (fabs(f-f0) < 1.e-12)
            {
                f0 = f;
                break;
            }
            else
            {
                f0 = f;
            }

            // Save previous
            for (int i = 0; i < _pDim; i++)
                rCoords0[i] = rCoords[i];
        }

        // Compute closest point
        // bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, tag);
        bfDers = _basisFunctions->computeBasisFunctionsReference(rCoords, tag, 0);
        double gCoords[3];
        Math::MatTMult(gCoords, 1, eNN, 3, bfDers[0].data(), nborCoords.data());

        return Math::Dist3D(gCoords, xCoords.data());
    }

}
