/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <stdexcept>
#include <queue>

#include <Teuchos_RCP.hpp>

#include "hl_Math.h"
#include "hl_Array.h"

#include "hl_BVHElementLocator.h"


using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    BVHElementLocator::BVHElementLocator(std::string tag, MPI_Comm comm): ElementLocator(tag, comm)
    {
    }

    // Creation of BVH
    void BVHElementLocator::_computeMeshBounds()
    {
        // Compute min and max in this partition
        vector<double> min(3,  numeric_limits<double>::max());
        vector<double> max(3, -numeric_limits<double>::max());
        for (int i = 0; i < _nPts; i++)
        {
            if (_disMesh->_nodeData->isItemInfoInPart(i))
            {
                vector<double> coords = _disMesh->_mapCoords(i, IndexType::Global);
                for (int d = 0; d < _nDim; d++)
                {
                    if (coords[d] < min[d])
                        min[d] = coords[d];
                    if (coords[d] > max[d])
                        max[d] = coords[d];
                }
            }
        }

        // Make it per partition
        for (int d = 0; d < _nDim; d++)
        {
            _meshMin[d] = min[d];
            _meshMax[d] = max[d];
        }

        // Compute mesh diagonal                 // FIXME: Is this necessary?
        double diagonal{};
        for (int d = 0; d < _nDim; d++)
            diagonal += _meshMax[d]-_meshMin[d];

        // If min = max, move them
        for (int d = 0; d < _nDim; d++)
        {
            if (_meshMax[d]-_meshMin[d] <= diagonal/1000.0)
            {
                _meshMin[d] -= diagonal/100.0;
                _meshMax[d] += diagonal/100.0;
            }
        }
    }

    void BVHElementLocator::_createElements()
    {
        // Initialize vector of elements and element idx
        _elems.resize(_loc_nElem);
        _elemsIdx.resize(_loc_nElem);
        std::iota(_elemsIdx.begin(), _elemsIdx.end(), 0);

        // Get element data
        for (int i = 0; i < _loc_nElem; i++)
        {
            // Compute min and max  <----------------------------------------------- FIXME: bsplines and subdiv
            int eNN = _disMesh->_adjcyEN->getNumNbors(i, IndexType::Local);
            vector<double> nborCoords = _disMesh->_elemNborMapCoords(i, IndexType::Local);
            for (int d = 0; d < _nDim; d++)
            {
                double min =  numeric_limits<double>::max();
                double max = -numeric_limits<double>::max();
                for (int n = 0; n < eNN; n++)
                {
                    double coord = nborCoords[n*_nDim+d];
                    if (coord < min)
                        min = coord;
                    if (coord > max)
                        max = coord;
                }
                _elems[i].min[d] = min; // FIXME: Add padding? // FIXME: float
                _elems[i].max[d] = max; // FIXME: Add padding? // FIXME: float
                _elems[i].cen[d] = (max-min)/2.0 + min;
            }
        }
    }

    void BVHElementLocator::_computeNodeBounds(const unsigned int nodeIdx)
    {
        // Initialize
        _node& node = _nodes[nodeIdx];
        node.aabbMin[0] =  nmax;
        node.aabbMin[1] =  nmax;
        node.aabbMin[2] =  nmax;
        node.aabbMax[0] = -nmax;
        node.aabbMax[1] = -nmax;
        node.aabbMax[2] = -nmax;

        // Compute min and max
        unsigned int first = node.leftFirst;
        for (unsigned int i = 0; i < node.elemCount; i++)
        {
            unsigned int leafElemIdx = _elemsIdx[first + i];
            _elem& leafElem = _elems[leafElemIdx];
            node.aabbMin[0] = min(node.aabbMin[0], leafElem.min[0]);
            node.aabbMin[1] = min(node.aabbMin[1], leafElem.min[1]);
            node.aabbMin[2] = min(node.aabbMin[2], leafElem.min[2]);
            node.aabbMax[0] = max(node.aabbMax[0], leafElem.max[0]);
            node.aabbMax[1] = max(node.aabbMax[1], leafElem.max[1]);
            node.aabbMax[2] = max(node.aabbMax[2], leafElem.max[2]);
        }
    }

    double BVHElementLocator::_computeSAH(_node& node, int axis, double pos)
    {
        // Create axis-aligned bounding box structure
        struct aabb
        {
            double bmin[3] = {numeric_limits<double>::max(),
                              numeric_limits<double>::max(),
                              numeric_limits<double>::max()};
            double bmax[3] = {-numeric_limits<double>::max(),
                              -numeric_limits<double>::max(),
                              -numeric_limits<double>::max()};
            void grow(double p[3])
            {
                bmin[0] = min(bmin[0], p[0]);
                bmin[1] = min(bmin[1], p[1]);
                bmin[2] = min(bmin[2], p[2]);
                bmax[0] = max(bmax[0], p[0]);
                bmax[1] = max(bmax[1], p[1]);
                bmax[2] = max(bmax[2], p[2]);
            }

            double area()
            {
                double extent[3];
                Math::subtraction(bmax, bmin, 3, extent);
                return Math::SNorm3D(extent);
            }

            double volume()
            {
                double extent[3];
                Math::subtraction(bmax, bmin, 3, extent);
                return extent[0]*extent[1]*extent[2];
            }
        };

        // Compute element counts and bounds for this split candidate
        aabb leftBox, rightBox;
        int leftCount{0}, rightCount{0};
        for (unsigned int i = 0; i < node.elemCount; i++)
        {
            _elem& elem = _elems[_elemsIdx[node.leftFirst + i]];
            if (elem.cen[axis] < pos)
            {
                leftCount++;
                leftBox.grow(elem.min);
                leftBox.grow(elem.max);
            }
            else
            {
                rightCount++;
                rightBox.grow(elem.min);
                rightBox.grow(elem.max);
            }
        }

        double cost = leftCount*leftBox.area() + rightCount*rightBox.area();
        // double cost = leftCount*leftBox.volume() + rightCount*rightBox.volume();
        return cost > 0 ? cost : nmax;
    }

    double BVHElementLocator::_computeBestSplitPlane(_node& node, int& axis, double& splitPos)
    {
        // // Naive approach
        // double bestCost = nmax;
        // double extent[3];
        // Math::subtraction(node.aabbMax, node.aabbMin, 3, extent);
        // axis = 0;
        // if (extent[1] > extent[0])
        //     axis = 1;
        // if (extent[2] > extent[axis])
        //     axis = 2;
        // splitPos = node.aabbMin[axis] + 0.5*extent[axis];

        // More accurate (no-binning) approach
        double bestCost = nmax;
        for (int d = 0; d < 3; d++)
        {
            for (unsigned int i = 0; i < node.elemCount; i++)
            {
                _elem& elem = _elems[_elemsIdx[node.leftFirst + i]];
                double pos  = elem.cen[d];
                double cost = _computeSAH(node, d, pos);
                if (cost < bestCost)
                {
                    axis = d;
                    splitPos = pos;
                    bestCost = cost;
                }
            }
        }

        return bestCost;
    }

    double BVHElementLocator::_computeNodeCost(_node& node)
    {
        double extent[3];
        Math::subtraction(node.aabbMax, node.aabbMin, 3, extent);

        double area = Math::SNorm3D(extent);
        return node.elemCount * area;

        // double vol = extent[0]*extent[1]*extent[2];
        // return node.elemCount * vol;
    }

    void BVHElementLocator::_subdivideNode(const unsigned int nodeIdx)
    {
        // Initialize
        _node& node = _nodes[nodeIdx];

        // Terminate recursion
        if (node.elemCount <= 2)
            return;

        // Determine split axis and position (Naive split)
        double extent[3];
        Math::subtraction(node.aabbMax, node.aabbMin, 3, extent);
        int axis{0};
        if (extent[1] > extent[0])
            axis = 1;
        if (extent[2] > extent[axis])
            axis = 2;
        double splitPos = node.aabbMin[axis] + 0.5*extent[axis];

        // Determine split axis and position (SAH split)
        // int axis;
        // double splitPos;
        // double splitCost = _computeBestSplitPlane(node, axis, splitPos);
        // double nosplitCost = _computeNodeCost(node);
        // if (splitCost >= nosplitCost)
        //     return;

        // In-place partition (sort element idx)
        int i = node.leftFirst;
        int j = i + node.elemCount - 1;
        while (i <= j)
        {
            if (_elems[_elemsIdx[i]].cen[axis] < splitPos)
                i++;
            else
                Array::swap(_elemsIdx[i], _elemsIdx[j--]);
        }

        // Abort split if one of the sides is empty
        int leftCount = i - node.leftFirst;
        if (leftCount == 0 || static_cast<size_t>(leftCount) == node.elemCount)
            return;

        // Create left child node
        int leftChildIdx = _nodesUsed++;
        _nodes[leftChildIdx].leftFirst = node.leftFirst;
        _nodes[leftChildIdx].elemCount = leftCount;
        _computeNodeBounds(leftChildIdx);

        // Create right child node
        int rightChildIdx = _nodesUsed++;
        _nodes[rightChildIdx].leftFirst = i;
        _nodes[rightChildIdx].elemCount = node.elemCount - leftCount;
        _computeNodeBounds(rightChildIdx);

        // Update node
        node.leftFirst = leftChildIdx;
        node.elemCount = 0;

        // Subdivide left and right child nodes
        _subdivideNode(leftChildIdx);
        _subdivideNode(rightChildIdx);
    }

    void BVHElementLocator::Update()
    {
        // Check distributed mesh exists
        if (_disMesh == nullptr)
            throw runtime_error("BVHElementLocator::Update: Distributed mesh not set.");

        // Initialize
        _nDim      = _disMesh->nDim();
        _pDim      = _disMesh->pDim();
        _nElem     = _disMesh->nElem();
        _loc_nElem = _disMesh->loc_nElem();
        _nPts      = _disMesh->nPts();
        _loc_nPts  = _disMesh->loc_nPts();

        // Create field structure
        if (_mapFieldStruct == Teuchos::null)
        {
            _disMesh->_mapFieldStruct = _disMesh->_nodeData;
            _disMesh->_mapCoordX_ptr = &DistributedMesh::nodeCoord;
            _disMesh->_mapCoordY_ptr = &DistributedMesh::nodeCoord;
            _disMesh->_mapCoordZ_ptr = &DistributedMesh::nodeCoord;
        }
        else
        {
            _disMesh->_mapFieldStruct = _mapFieldStruct;
            _disMesh->_mapFields = _mapFields;
            if (_disMesh->_mapFields.size() == 1)
            {
                _disMesh->_mapCoordX_ptr = &DistributedMesh::_mapCoordX;
                _disMesh->_mapCoordY_ptr = &DistributedMesh::nodeCoord;
                _disMesh->_mapCoordZ_ptr = &DistributedMesh::nodeCoord;
            }
            else if (_disMesh->_mapFields.size() == 2)
            {
                _disMesh->_mapCoordX_ptr = &DistributedMesh::_mapCoordX;
                _disMesh->_mapCoordY_ptr = &DistributedMesh::_mapCoordY;
                _disMesh->_mapCoordZ_ptr = &DistributedMesh::nodeCoord;
            }
            else if (_disMesh->_mapFields.size() == 3)
            {
                _disMesh->_mapCoordX_ptr = &DistributedMesh::_mapCoordX;
                _disMesh->_mapCoordY_ptr = &DistributedMesh::_mapCoordY;
                _disMesh->_mapCoordZ_ptr = &DistributedMesh::_mapCoordZ;
            }
            else
            {
                throw runtime_error("BVHElementLocator::Update: The number of fields is wrong.");
            }
        }

        // Create mesh bounds
        _computeMeshBounds();

        // Create elements
        _createElements();

        // Initialize nodes
        _nodes.resize(2*_loc_nElem);

        // Create root node
        _nodesUsed = 2;
        unsigned int rootNodeIdx = 0;
        _node & root = _nodes[rootNodeIdx];
        root.leftFirst = 0;
        root.elemCount = _loc_nElem;
        _computeNodeBounds(rootNodeIdx);

        // Create remaining nodes by recursive subdivision
        _subdivideNode(rootNodeIdx);

        // // Save node id to dhand
        // for (int j = 0; j < _nodesUsed; j++)
        // {
        //     _node& node = _nodes[j];
        //     if (node.isLeaf())
        //     {
        //         // cout << j << " elems: ";
        //         // for (int i = node.firstTriIdx; i < node.firstTriIdx + node.elemCount; i++)
        //         //     cout << _elemsIdx[i] << " ";
        //         // cout << endl;
        //         for (int i = node.firstTriIdx; i < node.firstTriIdx + node.elemCount; i++)
        //         {
        //             dhand->elemAuxF->setValue(0, _elemsIdx[i], IndexType::Local, j);
        //         }
        //     }
        // }

        // // Print leaves
        // for (int j = 0; j < _nodesUsed; j++)
        // {
        //     _node& node = _nodes[j];
        //     if (node.isLeaf())
        //     {
        //         _printNode(j);
        //     }
        // }
    }


    // Search
    bool _isPointWithinBounds(const double x[3], double bmin[3], double bmax[3])
    {
        // Check if the point is inside the bounds
        if (x[0] >= bmin[0] and x[0] <= bmax[0] and x[1] >= bmin[1] and x[1] <= bmax[1] and
            x[2] >= bmin[2] and x[2] <= bmax[2])
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    bool BVHElementLocator::_isPointWithinElementBounds(const double x[3], const unsigned int elemIdx)
    {
        // Initialize
        _elem& elem = _elems[elemIdx];

        return _isPointWithinBounds(x, elem.min, elem.max);
    }

    bool BVHElementLocator::_isPointWithinNodeBounds(const double x[3], const unsigned int nodeIdx)
    {
        // Initialize
        _node& node = _nodes[nodeIdx];

        return _isPointWithinBounds(x, node.aabbMin, node.aabbMax);
    }

    // Modified from vtkCellLocator
    // Note: Writing it in a loop makes it slower
    // Note: Using an array of 6 elements for the min and max makes it slightly slower  //THIS CHECK WAS DONE WITHOUT OPTIMIZATION FLAGS
    double BVHElementLocator::_distanceSqToBounds(const double x[3], double bmin[3], double bmax[3])
    {
        // Check if the point is inside the bounds
        if (x[0] >= bmin[0] and x[0] <= bmax[0] and x[1] >= bmin[1] and x[1] <= bmax[1] and
            x[2] >= bmin[2] and x[2] <= bmax[2])
        {
            return 0.0;
        }

        // Initialize delt
        double delt[3];
        delt[0] = delt[1] = delt[2] = 0.0;

        // delta x
        if (x[0] < bmin[0])
        {
            delt[0] = bmin[0] - x[0];
        }
        else if (x[0] > bmax[0])
        {
            delt[0] = x[0] - bmax[0];
        }

        // delta y
        if (x[1] < bmin[1])
        {
            delt[1] = bmin[1] - x[1];
        }
        else if (x[1] > bmax[1])
        {
            delt[1] = x[1] - bmax[1];
        }

        // delta z
        if (x[2] < bmin[2])
        {
            delt[2] = bmin[2] - x[2];
        }
        else if (x[2] > bmax[2])
        {
            delt[2] = x[2] - bmax[2];
        }

        return Math::SNorm3D(delt);
    }

    double BVHElementLocator::_distanceSqToElementBounds(const double x[3], const unsigned int elemIdx)
    {
        // Initialize
        _elem& elem = _elems[elemIdx];

        return _distanceSqToBounds(x, elem.min, elem.max);
    }

    double BVHElementLocator::_distanceSqToNodeBounds(const double x[3], const unsigned int nodeIdx)
    {
        // Initialize
        _node& node = _nodes[nodeIdx];

        return _distanceSqToBounds(x, node.aabbMin, node.aabbMax);
    }

    void BVHElementLocator::_searchElementCanditatesInBVH(const double x[3], const unsigned int nodeIdx, vector<int> &elemCandidates)
    {
        // Initialize
        _node& node = _nodes[nodeIdx];

        // Check if point is in node
        if (!_isPointWithinNodeBounds(x, nodeIdx))
            return;

        // If point is leaf find, otherwise recurs
        if (node.isLeaf())
        {
            for (size_t i = node.leftFirst; i < node.leftFirst + node.elemCount; i++)
            {
                int elemIdx = _elemsIdx[i];
                if (_isPointWithinElementBounds(x, elemIdx))
                    elemCandidates.push_back(elemIdx);
            }
        }
        else
        {
            _searchElementCanditatesInBVH(x, node.leftFirst, elemCandidates);
            _searchElementCanditatesInBVH(x, node.leftFirst+1, elemCandidates);
        }
    }


    double BVHElementLocator::_searchElementInBVH(int& elem, vector<double>& rCoords, vector<double> xCoords, double maxSqDist)
    {
        // Unused
        (void) maxSqDist;

        // Create priority queue
        auto compare = [](pair<int,double> p1, pair<int,double> p2){return p1.second > p2.second;};
        std::priority_queue<pair<int,double>,vector<pair<int,double>>, decltype(compare)> pQ(compare);

        // Compute distance to root node
        double d = _distanceSqToNodeBounds(xCoords.data(), 0);
        pQ.push({0, d});

        // Loop through queue
        double distSq = nmax;
        vector<double> rCoords0(_pDim);
        while (!pQ.empty())
        {
            // Get and remove top element of the queue
            pair<int,double> temp = pQ.top();
            pQ.pop();

            // If the distance is smaller
            if (temp.second < distSq)
            {
                int nodeIdx = temp.first;
                _node& node = _nodes[nodeIdx];
                if (node.isLeaf())
                {
                    // Order elements based on distance from point to element bounds
                    int nElemNode = node.elemCount;
                    vector<double> distsElBound(nElemNode, numeric_limits<double>::max());
                    for (int i = 0; i < nElemNode; i++)
                    {
                        // Initialize
                        int elemIdx = _elemsIdx[node.leftFirst+i];

                        // Compute distance
                        distsElBound[i] = _distanceSqToElementBounds(xCoords.data(), elemIdx);
                    }
                    std::vector<int> indices(nElemNode);
                    std::iota(indices.begin(), indices.end(), 0);
                    std::sort(indices.begin(), indices.end(), [&](int a, int b) -> bool{return distsElBound[a] < distsElBound[b];});

                    // Find element within node
                    for (int i = 0; i < nElemNode; i++)
                    {
                        // Initialize
                        int index = indices[i];
                        int loc_e = _elemsIdx[node.leftFirst+index];

                        // If the element is within distSq, invert mapping
                        if (distsElBound[index] < distSq)
                        {
                            // Invert mapping
                            vector<double> rCoords1(_pDim);
                            double distPt = (_disMesh->*(_disMesh->invertElementMapping))(rCoords1, loc_e, xCoords, rCoords0, IndexType::Local, true);

                            if (distPt < 0.0)
                                continue;
                            distPt *= distPt;

                            // Save
                            if (distPt < distSq)
                            {
                                distSq = distPt;
                                for (int i = 0; i < _pDim; i++)
                                    rCoords[i] = rCoords1[i];
                                int e = _disMesh->globalElemId(loc_e);
                                elem = e;
                            }
                        }
                    }
                }
                else
                {
                    double dl = _distanceSqToNodeBounds(xCoords.data(), node.leftFirst);
                    pQ.push({node.leftFirst, dl});
                    double dr = _distanceSqToNodeBounds(xCoords.data(), node.leftFirst+1);
                    pQ.push({node.leftFirst+1, dr});
                }
            }
        }

        return sqrt(distSq);

        // The following chunk is useful if we know that the point is inside the mesh
        // // Search element candidates
        // vector<int> elemCandidates;
        // _searchElementCanditatesInBVH(xCoords.data(), 0, elemCandidates);

        // // Initialize
        // vector<double> rCoords0(_pDim);
        // double minDistToPt = nmax;
        // for (auto loc_e: elemCandidates)
        // {
        //     // Invert mapping
        //     vector<double> rCoords1(_pDim);
        //     double distPt = _disMesh->invertElementMapping(rCoords1, loc_e, xCoords, rCoords0, IndexType::Local);
        //     if (distPt < 0.0)
        //         continue;
        //     // distPt *= distPt; // FIXME? We are not working with squared distances here

        //     // Save
        //     if (distPt < minDistToPt)
        //     {
        //         minDistToPt = distPt;
        //         for (int i = 0; i < _pDim; i++)
        //             rCoords[i] = rCoords1[i];
        //         int e = _disMesh->globalElemId(loc_e);
        //         elem = e;
        //     }
        // }

        // return minDistToPt;
    }

    vector<double> BVHElementLocator::searchElement(vector<int>& elems, vector<vector<double>>& rCoords, vector<vector<double>> xCoords)
    {
        // Get distances from points to partitions
        int nPoints = static_cast<int> (xCoords.size());
        vector<double> distSqToPartition(nPoints);
        for (int n = 0; n < nPoints; n++)
            distSqToPartition[n] = _distanceSqToBounds(xCoords[n].data(), _meshMin, _meshMax);

        // Compute minimum distances across partitions
        vector<double> min_distSqToPartitions(nPoints);
        MPI_Allreduce(distSqToPartition.data(), min_distSqToPartitions.data(), nPoints, MPI_DOUBLE, MPI_MIN, comm());

        // Initialize
        vector<double> dists(nPoints, numeric_limits<double>::max());
        elems.resize(nPoints);
        rCoords.resize(nPoints, vector<double>(_nDim));

        // Search element in predicted closest(s) processors
        for (int n = 0; n < nPoints; n++)
        {
            if ((min_distSqToPartitions[n] < 1e-6 and distSqToPartition[n] < 1e-6) or
                (min_distSqToPartitions[n] > 1e-6 and abs(min_distSqToPartitions[n]-distSqToPartition[n]) < 1e-6))
            {
                dists[n] = searchElementInPartition(elems[n], rCoords[n], xCoords[n]);
                dists[n] *= dists[n];
            }
        }

        // Compute minimum distances across partitions
        vector<double> min_dists(nPoints);
        MPI_Allreduce(dists.data(), min_dists.data(), nPoints, MPI_DOUBLE, MPI_MIN, comm());

        // If not found, look in nearby processors
        for (int n = 0; n < nPoints; n++)
        {
            if (min_dists[n] > 1e-6 and min_dists[n] >= distSqToPartition[n] and distSqToPartition[n] > 0.0)
            {
                dists[n] = _searchElementInBVH(elems[n], rCoords[n], xCoords[n], min_dists[n]);
                dists[n] *= dists[n];
            }
        }

        // Get (processor) location of the min distances
        struct distsAndProcs
        {
             double dist;
             int rank;
        };
        distsAndProcs * out = new distsAndProcs[nPoints];
        distsAndProcs * in  = new distsAndProcs[nPoints];
        for (int n = 0; n < nPoints; n++)
        {
            out[n].dist = dists[n];
            out[n].rank = _myRank;
        }
        MPI_Allreduce(out, in, nPoints, MPI_DOUBLE_INT, MPI_MINLOC, comm());

        // Share elems and rCoords //FIXME:: We are doing a loop, is there a more efficient way?
        for (int n = 0; n < nPoints; n++)
        {
            MPI_Bcast(&elems[n], 1, MPI_INT, in[n].rank, comm());
            MPI_Bcast(rCoords[n].data(), _pDim, MPI_DOUBLE, in[n].rank, comm());

            // Check
            if (in[n].dist < 0.0)
                throw runtime_error("ElementLocator::searchElement: Element not found");
        }

        // Delete
        delete[] out;
        delete[] in;

        return dists;  // FIXME:: This distance has not been shared among processors
    }

    // Ray tracing
    // jacco
    // https://tavianator.com/2011/ray_box.html
    // https://www.researchgate.net/publication/249716586_Ray_Tracing_Tools_for_High_Frequency_Electromagnetics_Simulations

    // void BVHElementLocator::_intersectTriangle(_ray& ray, const Tri& tri )
    // {
    //     const float3 edge1 = tri.vertex1 - tri.vertex0;
    //     const float3 edge2 = tri.vertex2 - tri.vertex0;
    //     const float3 h = cross( ray.D, edge2 );
    //     const float a = dot( edge1, h );
    //     if (a > -0.0001f && a < 0.0001f) return; // ray parallel to triangle
    //     const float f = 1 / a;
    //     const float3 s = ray.O - tri.vertex0;
    //     const float u = f * dot( s, h );
    //     if (u < 0 || u > 1) return;
    //     const float3 q = cross( s, edge1 );
    //     const float v = f * dot( ray.D, q );
    //     if (v < 0 || u + v > 1) return;
    //     const float t = f * dot( edge2, q );
    //     if (t > 0.0001f) ray.t = min( ray.t, t );
    // }

    // Segment tracing
    // Auxiliary
    void BVHElementLocator::_printNode(const unsigned int nodeIdx)
    {
        _node& node = _nodes[nodeIdx];
        cout << "Node id: " << nodeIdx << endl;
        cout << "    Min: ";
        Array::print(node.aabbMin, 3);
        cout << "    Max: ";
        Array::print(node.aabbMax, 3);
        if (!node.isLeaf())
        {
        cout << "   Left: " << node.leftFirst << endl;
        }
        else
        {
            cout << "  Range: " << node.leftFirst << " " << node.elemCount << endl;
            cout << "  elems: ";
            for (size_t i = node.leftFirst; i < node.leftFirst + node.elemCount; i++)
                cout << _elemsIdx[i] << " ";
            cout << endl;
        }
    }

    int BVHElementLocator::_computeBVHHeightAndBalance(const unsigned int nodeIdx, int &balanceFactor)
    {
        // Initialize
        _node& node = _nodes[nodeIdx];

        // If point is leaf find, otherwise recurs
        if (node.isLeaf())
        {
            balanceFactor = 0;
            return 0;
        }
        else
        {
            int lHeight = _computeBVHHeightAndBalance(node.leftFirst, balanceFactor);
            int rHeight = _computeBVHHeightAndBalance(node.leftFirst+1, balanceFactor);

            balanceFactor = max(balanceFactor, abs(lHeight-rHeight));

            if (lHeight > rHeight)
                return lHeight+1;
            else
                return rHeight+1;
        }
    }

    void BVHElementLocator::_printBVHcharacteristics()
    {
        // Print BVH characteristics
        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                // Compute number of leaves and max min number elements
                int nLeaves{}, nElemsMax{}, nElemsMin{20000};
                for (size_t j = 0; j < _nodesUsed; j++)
                {
                    _node& node = _nodes[j];
                    if (node.isLeaf())
                    {
                        nLeaves++;
                        int nElems = node.elemCount;
                        if (nElems > nElemsMax)
                            nElemsMax = nElems;
                        if (nElems < nElemsMin)
                            nElemsMin = nElems;
                    }
                }

                // Compute BVH height balance
                int bf{};
                int h = _computeBVHHeightAndBalance(0, bf);

                // Print
                cout << "BVH characteristics for rank " << _myRank << endl;
                cout << "  Height              :" << h << endl;
                cout << "  Balance factor      :" << bf << endl;
                cout << "  Number of leaves    :" << nLeaves << endl;
                cout << "  Max number of elems :" << nElemsMax << endl;
                cout << "  Min number of elems :" << nElemsMin << endl;
            }
            MPI_Barrier(_comm);
        }
    }
}
