/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>

#include "hl_ElementLocator.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    ElementLocator::ElementLocator(std::string tag, MPI_Comm comm): DistributedClass(tag, comm)
    {
    }

    vector<double> ElementLocator::searchElementInPartition(vector<int>& elems, vector<vector<double>>& rCoords, vector<vector<double>> xCoords)
    {
        // Initialize
        int nPoints = static_cast<int> (xCoords.size());
        vector<double> dists(nPoints);
        elems.resize(nPoints);
        rCoords.resize(nPoints, vector<double>(_nDim));

        // Loop over points
        for (int n = 0; n < nPoints; n++)
            dists[n] = searchElementInPartition(elems[n], rCoords[n], xCoords[n]);

        return dists;
    }

}
