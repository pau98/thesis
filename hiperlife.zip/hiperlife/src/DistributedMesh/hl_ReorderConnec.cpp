/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <stdexcept>
#include <unistd.h>

#include <iostream>
#include <algorithm>    // std::rotate


#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_IntSerialDenseVector.h>
#include <Epetra_FECrsMatrix.h>

#include "hl_DistributedMesh.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;

static int NBOR_REG = 7;


namespace hiperlife
{

    void DistributedMesh::_reorderConnecSubdivSurfs()
    {
        for (int e=0; e < _connec->loc_nElem(); e++)
        {
            auto& oldEConnec = _connec->getNborList(e, IndexType::Local);

            int firstNode  = oldEConnec[0];
            int secondNode = oldEConnec[1];
            int thirdNode  = oldEConnec[2];

            int crease1 = nodeCrease( firstNode, IndexType::Global);
            int crease2 = nodeCrease(secondNode, IndexType::Global);
            int crease3 = nodeCrease( thirdNode, IndexType::Global);

            int crease = std::max({crease1,crease2,crease3});

            if (crease > 0)
            {
                auto it = oldEConnec.begin();

                if ( crease1 == 0 )
                {
                    if ( crease2 > 0 )
                    {
                        if ( crease3 == 0 )
                            it = oldEConnec.begin()+2;
                    }
                }
                else
                {
                    if ( crease2 > 0 )
                    {
                        if ( crease3 == 0)
                            it = oldEConnec.begin()+2;
                        else if (crease3 > 0 )
                            throw runtime_error("reorderConnec: All nodes of an element are in the boundary... this cannot be possible.");
                    }
                    else
                        it = oldEConnec.begin()+1;
                }

                std::vector<int> newEConnec;
                newEConnec.reserve(oldEConnec.size());

                for (auto nIt = it; nIt < oldEConnec.end(); nIt++)
                    newEConnec.push_back(*nIt);
                for (auto nIt = oldEConnec.begin(); nIt < it; nIt++)
                    newEConnec.push_back(*nIt);

                int reordTag = static_cast<int>(it - oldEConnec.begin());

                if(reordTag > 3)
                    throw runtime_error("reorderConnec: reordTag > 3... are you inputting a square?");

                _connec->setNborList(e, newEConnec, IndexType::Local);
                setElemTag(0, e, IndexType::Local, reordTag);

            }
            else
            {
                auto& oldEConnec = _connec->getNborList(e, IndexType::Local);
                auto it = oldEConnec.begin();

                // We search the first irregular neighbor in the list
                for (it = oldEConnec.begin(); it < oldEConnec.end(); it++)
                {
                    if (_graph->getNumNbors(*it) != NBOR_REG)
                        break;
                }

                int reordTag = static_cast<int>(it - oldEConnec.begin());

                if(reordTag > 3)
                    throw runtime_error("reorderConnec: reordTag > 3... are you inputting a square?");
                else if (it ==  oldEConnec.end())
                    reordTag=0;
                else if ( reordTag > 0 )
                {
                    // Reorder to put the irregular node at the beginning
                    std::vector<int> newEConnec;
                    newEConnec.reserve(oldEConnec.size());

                    for (auto nIt = it; nIt < oldEConnec.end(); nIt++)
                        newEConnec.push_back(*nIt);
                    for (auto nIt = oldEConnec.begin(); nIt < it; nIt++)
                        newEConnec.push_back(*nIt);

                    _connec->setNborList(e, newEConnec, IndexType::Local);
                }

                setElemTag(0, e, IndexType::Local, reordTag);

            }
        }

    }

}
