/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#include <Teuchos_RCP.hpp>

#include <vtkPolyData.h>
#include <vtkCellArray.h>
#include <vtkUnstructuredGrid.h>

#include "hl_Timer.h"

#include "hl_vtkElementLocator.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    vtkElementLocator::vtkElementLocator(std::string tag, MPI_Comm comm): ElementLocator(tag, comm)
    {
    }

    void DecomposeCurve(int n, int p, vector<double> U, vector<vector<double>> Pw, int& nb, vector<vector<vector<double>>>& Qw)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; p. 174.

        /* Decompose curve into Bezier segments */
        /* Input: n,p,U,Pw */
        /* Output: nb,Qw */

        //Modify for hiperlife
        n--;
        int nDim = Pw[0].size();

        int m = n+p+1;
        int a = p;
        int b = p+1;
        nb = 0;
        for (int i = 0; i <= p; i++)
            for (int d = 0; d < nDim; d++)
                Qw[nb][i][d] = Pw[i][d];

        while (b < m)
        {
            int i = b;
            while (b < m && U[b+1] == U[b])
                b++;
            int mult = b-i+1;

            if (mult < p)
            {
                /* Compute and store alphas */
                double numer = U[b]-U[a]; /* Numerator of alpha */
                vector<double> alphas(p-mult);
                for (int j = p; j > mult; j--)
                    alphas[j-mult-1] = numer/(U[a+j]-U[a]);
                int r = p-mult;

                /* Insert knot r times */
                for (int j = 1; j <= r; j++)
                {
                    int save = r-j;
                    int s = mult+j; /* This many new points*/
                    for (int k = p; k >= s; k--)
                    {
                        double alpha = alphas[k-s];
                        for (int d = 0; d < nDim; d++)
                            Qw[nb][k][d] = alpha*Qw[nb][k][d] + (1.0-alpha)*Qw[nb][k-1][d];
                    }
                    if (b < m)
                    {
                        for (int d = 0; d < nDim; d++)
                            Qw[nb+1][save][d] = Qw[nb][p][d];
                    }
                }
            }
            nb = nb+1; //Bezier segment completed

            /* Initialize for next segment */
            if (b < m)
            {
                for (i=p-mult; i<=p; i++)
                    for (int d = 0; d < nDim; d++)
                        Qw[nb][i][d] = Pw[b-p+i][d];
                a = b;
                b = b+1;
            }
        }
    }

    void BezierSegment(int n, int p, vector<double> U, int e, vector<vector<double>>& Qw)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; p. 174.

        /* Decompose curve into Bezier segments */
        /* Input: n,p,U,Pw */
        /* Output: nb,Qw */

        //Modify for hiperlife
        n--;
        int nDim = Qw[0].size();

        // Initialize
        int m = n+p+1;
        int a = p+e;  // FIXME: findSpan?
        int b = p+1+e;
        int k = a; // Knot span

        //*************************************************************************
        // [0] Left knot insertion
        //*************************************************************************

        // Compute knot multiplicity
        int aa = a;
        while (aa >= 0 and U[aa-1] == U[aa])
            aa--;
        int s = a-aa+1;

        // Insert if multiplicity is less than order
        if (s < p)
        {
            // Number of times to insert
            int r = p-s;

            // Insert knot r times
            for (int j = 1; j <= r; j++)
            {
                int L = k-p+j;
                for (int i = 0; i <= p-j-s; i++)
                {
                    double alpha = (U[a]-U[L+i])/(U[i+k+1]-U[L+i]);
                    for (int d = 0; d < nDim; d++)
                        Qw[i][d] = alpha*Qw[i+1][d] + (1.0-alpha)*Qw[i][d];
                }
            }
        }


        //*************************************************************************
        // [1] Right knot insertion
        //*************************************************************************

        // Compute knot multiplicity
        int i = b;
        while (b < m && U[b+1] == U[b])
            b++;
        int mult = b-i+1;

        // Insert if multiplicity is less than order
        if (mult < p)
        {
            // Compute and store alphas
            vector<double> alphas(p-mult);
            double numer = U[b]-U[a];
            for (int j = p; j > mult; j--)
                alphas[j-mult-1] = numer/(U[a+j]-U[a]);
            int r = p-mult;

            // Insert knot r times
            for (int j = 1; j <= r; j++)
            {
                int s = mult+j; /* This many new points*/
                for (int k = p; k >= s; k--)
                {
                    double alpha = alphas[k-s];
                    for (int d = 0; d < nDim; d++)
                        Qw[k][d] = alpha*Qw[k][d] + (1.0-alpha)*Qw[k-1][d];
                }
            }
        }
    }


    void DecomposeSurface(int n, int p, vector<double> U, int m, int q, vector<double> V,vector<vector<double>> Pw, int dir, int& nb, vector<vector<vector<double>>>&Qw)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; p. 177.

        /* Decompose surface into Bezier patches */
        /* Input: n,p,U,m,q,V,Pw,dir */
        /* Output: nb,Qw */

        //Modify for hiperlife
        n--;
        m--;
        int nn = n+p+1;
        int mm = m+q+1;


        if (dir == 0)
        {
            int a = p;
            int b = p+1;
            nb = 0;
            for (int i = 0; i <= p; i++)
                for (int row = 0; row <= m; row++)
                    Qw[nb][i][row] = Pw[i][row];

            while (b < nn)
            {
                // Get multiplicity
                int i = b;
                while (b < nn && U[b+1] == U[b])
                    b++;
                int mult = b-i+1;

                // Insert if multiplicity is less than order
                if (mult < p)
                {
                    // get the numerator and the alphas;
                    vector<double> alphas(p-mult);
                    double numer = U[b]-U[a];
                    for (int j = p; j > mult; j--)
                        alphas[j-mult-1] = numer/(U[a+j]-U[a]);
                    int r = p-mult;

                    for (int j = 1; j <= r; j++)
                    {
                        int save= r-j;
                        int s = mult+j ;
                        for (int k = p; k >= s; k--)
                        {
                            double alpha = alphas[k-s];
                            for (int row = 0; row <= m; row++)
                                Qw[nb][k][row] = alpha*Qw[nb][k][row] + (1.0-alpha)*Qw[nb][k-1][row];
                        }
                        if (b < nn)
                        {
                            for (int row = 0; row <= m; row++)
                                Qw[nb+1][save][row] = Qw[nb][p][row];
                        }
                    }
                }

                /* Initialize for next segment */
                nb = nb+1;
                if (b < nn)
                {
                    for (i = p-mult; i<=p; i++)
                        for (int row = 0; row <= m; row++)
                            Qw[nb][i][row] = Pw[b-p+i][row];
                    a = b;
                    b = b+1;
                }
            }
        }
        else if (dir == 1)
        {
            int a = q;
            int b = q+1;
            nb = 0;
            for (int i = 0; i <= q; i++)
                for (int col = 0; col <= n; col++)
                    Qw[nb][col][i] = Pw[col][i];

            while (b < mm)
            {
                // Get multiplicity
                int i = b;
                while (b < mm && V[b+1] == V[b])
                    b++;
                int mult = b-i+1;

                // Insert if multiplicity is less than order
                if (mult < q)
                {
                    // get the numerator and the alphas;
                    vector<double> alphas(q-mult);
                    double numer = V[b]-V[a];
                    for (int j = q; j > mult; j--)
                        alphas[j-mult-1] = numer/(V[a+j]-V[a]);
                    int r = q-mult;

                    for (int j = 1; j <= r; j++)
                    {
                        int save= r-j;
                        int s = mult+j ;
                        for (int k = q; k >= s; k--)
                        {
                            double alpha = alphas[k-s];
                            for (int col = 0; col <= n; col++)
                                Qw[nb][col][k] = alpha*Qw[nb][col][k] + (1.0-alpha)*Qw[nb][col][k-1];
                        }
                        if (b < mm)
                        {
                            for (int col = 0; col <= n; col++)
                                Qw[nb+1][col][save] = Qw[nb][col][q];
                        }
                    }
                }

                /* Initialize for next segment */
                nb = nb+1;
                if (b < mm)
                {
                    for (i = q-mult; i<=q; i++)
                        for (int col = 0; col <= n; col++)
                            Qw[nb][col][i] = Pw[col][b-q+i];
                    a = b;
                    b = b+1;
                }
            }
        }
    }


    void vtkElementLocator::Update()
    {
        // Check distributed mesh exists
        // if (_disMesh == Teuchos::null)
        if (_disMesh == nullptr)
            throw runtime_error("vtkElementLocator::Update: Distributed mesh not set.");

        //*************************************************************************
        // [0] Initialize
        //*************************************************************************

        // Initialize
        _nDim      = _disMesh->nDim();
        _pDim      = _disMesh->pDim();
        _nElem     = _disMesh->nElem();
        _loc_nElem = _disMesh->loc_nElem();
        _nPts      = _disMesh->nPts();
        _loc_nPts  = _disMesh->loc_nPts();
        _nVert     = _disMesh->nVert();
        _eType     = _disMesh->elemType();
        _basisFuncType = _disMesh->basisFuncType();
        _bfOrder   = _disMesh->basisFuncOrder();
        vector<int> bfOrderDir = _disMesh->basisFuncOrderDir();
        _bfOrderX = bfOrderDir[0];
        _bfOrderY = bfOrderDir[1];
        _bfOrderZ = bfOrderDir[2];

        int vtkCellType = hlToVtkElemType(_eType, _basisFuncType, _bfOrder);
        // Timer timer({"CreateMesh", "CreateLocator", "Find"});

        //*************************************************************************
        // [1] Create VKT mesh
        //*************************************************************************

        // timer.start("CreateMesh");

        // Initialize vtk points and cells
        vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
        vtkSmartPointer<vtkCellArray> cells = vtkSmartPointer<vtkCellArray>::New();

        // Save vtk points and cells
        if (_basisFuncType == BasisFuncType::BSplines)
        {
            throw runtime_error("vtkElementLocator::Update:: Implementation not finished for BSplines");

            RCP<MeshCreator> _meshCrea = _disMesh->_meshCrea;
            RCP<ConnecStruct> _connec  = _disMesh->_connec;
            RCP<AdjcyENStruct> _adjcyEN = _disMesh->_adjcyEN;

            if (true)
            {
                if (_eType == ElemType::Line)
                {
                    // Initialize
                    int nnx = _disMesh->_meshCrea->_nEx + _bfOrderX;

                    // Rearrange and form projective control point vector // FIXME:: This wont work if the points moved
                    vector<vector<double>> xCP(nnx, vector<double>(3));
                    for (int k = 0; k < 1; k++)
                    {
                        for (int j = 0; j < 1; j++)
                        {
                            for (int i = 0; i < nnx; i++)
                            {
                                for (int d = 0; d < 3; d++)
                                    xCP[i][d] = _meshCrea->_CP[i][j][k][d];
                                for (int d = 0; d < 3; d++)
                                    xCP[i][d] *= _meshCrea->_CP[i][j][k][3];
                            }
                        }
                    }
                    // vector<double> xCP(nnx);
                    // for (int i = 0; i < nnx; i++)
                    // {
                    //     xCP[i] = _meshCrea->_CP[i][0][0][0];
                    //     xCP[i] *= _meshCrea->_CP[i][0][0][3];
                    // }
                    for (int i = 0; i < nnx; i++)
                        cout << xCP[i][0] << " " << xCP[i][1] << " " << xCP[i][2] << endl;
                    // cout << endl;

                    // Compute Bezier extraction
                    // int nb;
                    vector<vector<vector<double>>> Qw(_nElem, vector<vector<double>>(_bfOrder+1, vector<double>(3)));
                    // DecomposeCurve(nnx, _bfOrderX, _disMesh->_uKnot, xCP, nb, Qw);

                    // for (int e = 0; e < nElem(); e++)
                    // {
                    //     for (int i = 0; i < _bfOrderX+1; i++)
                    //         cout << Qw[e][i] << " ";
                    //     cout << endl;
                    // }
                    // cout << endl;

                    // Create VTK points and cells // FIXME: They are independent
                    vector<int> reorder = vtkReordering(_eType, BasisFuncType::Lagrangian, _bfOrder);
                    for (int e = 0; e < _nElem; e++)
                    {
                        if (_connec->isItemInPart(e))
                        {
                            // Local element
                            int loc_e = _adjcyEN->locIdx(e);

                            // Insert points of the cell
                            for (int i = 0; i < _bfOrderX+1; i++)
                                points->InsertNextPoint(Qw[e][i][0], Qw[e][i][1], Qw[e][i][2]);

                            // Compute neighbors
                            vector<int> loc_nbors(_nVert);
                            std::iota(loc_nbors.begin(), loc_nbors.end(), loc_e*(_bfOrderX+1));

                            cout << myRank() << ": " << e << " " << loc_e << " | ";
                            for (auto r: loc_nbors)
                                cout << r << " ";
                            cout << " | ";
                            for (auto r: Qw[e])
                            {
                                cout << "[";
                                for (int i = 0; i < 2; i++)
                                    cout << r[i] << " ";
                                cout << "], ";
                            }
                            cout << endl;

                            // Create cell using reordering
                            vtkSmartPointer<vtkIdList> cell = vtkSmartPointer<vtkIdList>::New();
                            for (auto r: reorder)
                                cell->InsertNextId(loc_nbors[r]);

                            // Insert cell
                            cells->InsertNextCell(cell);
                        }
                    }
                }
                else if (_eType == ElemType::Square)
                {
                    // // Initialize
                    // int nnx = _meshCrea->_nEx + _bfOrderX;
                    // int nny = _meshCrea->_nEy + _bfOrderY;

                    // // Rearrange and form projective control point vector // FIXME:: This wont work if the points moved
                    // vector<double> xyCP(nnx, vector<double>(nny));
                    // for (int j = 0; j < nny; j++)
                    // {
                    //     for (int i = 0; i < nnx; i++)
                    //     {
                    //         xCP[i][j] = _meshCrea->_CP[i][j][0][0];
                    //         xCP[i][j] *= _meshCrea->_CP[i][j][0][3];
                    //     }
                    // }
                    // // for (int i = 0; i < nnx; i++)
                    // //     cout << xCP[i] << " ";
                    // // cout << endl;

                    // // Compute Bezier extraction
                    // int nb;
                    // vector<vector<double>> Qw(nElem(), vector<double>(_bfOrder+1));
                    // DecomposeCurve(nnx, _bfOrderX, _uKnot, xCP, nb, Qw);


                    // // for (int e = 0; e < nElem(); e++)
                    // // {
                    // //     for (int i = 0; i < _bfOrderX+1; i++)
                    // //         cout << Qw[e][i] << " ";
                    // //     cout << endl;
                    // // }
                    // // cout << endl;

                    // // Create VTK points and cells // FIXME: They are independent
                    // vector<int> reorder = vtkReordering(_eType, BasisFuncType::Lagrangian, _bfOrder);
                    // for (int e = 0; e < nElem(); e++)
                    // {
                    //     if (_connec->isItemInPart(e))
                    //     {
                    //         // Local element
                    //         int loc_e = _adjcyEN->locIdx(e);

                    //         // Insert points of the cell
                    //         for (int i = 0; i < _bfOrderX+1; i++)
                    //             points->InsertNextPoint(Qw[e][i],0.0,0.0);

                    //         // Compute neighbors
                    //         vector<int> loc_nbors(_nVert);
                    //         std::iota(loc_nbors.begin(), loc_nbors.end(), loc_e*(_bfOrderX+1));

                    //         cout << myRank() << ": " << e << " " << loc_e << " | ";
                    //         for (auto r: loc_nbors)
                    //             cout << r << " ";
                    //         cout << " | ";
                    //         for (auto r: Qw[e])
                    //             cout << r << " ";
                    //         cout << endl;

                    //         // Create cell using reordering
                    //         vtkSmartPointer<vtkIdList> cell = vtkSmartPointer<vtkIdList>::New();
                    //         for (auto r: reorder)
                    //             cell->InsertNextId(loc_nbors[r]);

                    //         // Insert cell
                    //         cells->InsertNextCell(cell);
                    //     }
                    // }
                }
            }

            if (false)
            {
                // Initialize
                // int nnx = _meshCrea->_nEx + _bfOrderX;

                // Create VTK points and cells // FIXME: They are independent
                vector<int> reorder = vtkReordering(_eType, BasisFuncType::Lagrangian, _bfOrder);
                for (int loc_e = 0; loc_e < _loc_nElem; loc_e++)
                {
                    // Global element
                    int e = _adjcyEN->globIdx(loc_e);

                    // Get neighbor coordinates
                    vector<int> nbors = _connec->getNborList(e);
                    vector<vector<double>> nborCoords(nbors.size(), vector<double>(_nDim));
                    for (size_t n = 0; n < nbors.size(); n++)
                        nborCoords[n] = _disMesh->nodeCoords(nbors[n]);

                    // Compute Bezier extraction
                    vector<vector<double>> Qw(nbors.size(), vector<double>(_nDim));
                    // BezierSegment(nnx, _bfOrderX, _disMesh->_uKnot, _disMesh->elemTag(0, e), nborCoords);

                    // Insert points of the cell
                    for (int i = 0; i < _bfOrderX+1; i++)
                        points->InsertNextPoint(nborCoords[i][0], nborCoords[i][1], nborCoords[i][2]);

                    // Compute neighbors
                    vector<int> loc_nbors(_nVert);
                    std::iota(loc_nbors.begin(), loc_nbors.end(), loc_e*(_bfOrderX+1));

                    // Create cell using reordering
                    vtkSmartPointer<vtkIdList> cell = vtkSmartPointer<vtkIdList>::New();
                    for (auto r: reorder)
                        cell->InsertNextId(loc_nbors[r]);

                    // Insert cell
                    cells->InsertNextCell(cell);
                }
            }

            // throw runtime_error("Not implemented");
        }
        else if (_basisFuncType == BasisFuncType::SubdivSurfs or _basisFuncType == BasisFuncType::Nurbs)
        {
            throw runtime_error("vtkElementLocator::Update: Not implemented for subdivision or Nurbs.");
        }
        else
        {
            // Create VTK points
            for (int i = 0; i < _loc_nPts; i++)
                points->InsertNextPoint(_disMesh->nodeCoords(i, IndexType::Local).data());
            for (auto i: _disMesh->listGhosts())
                points->InsertNextPoint(_disMesh->nodeCoords(i, IndexType::Global).data());

            // Create VTK cells (== elements)
            vector<int> reorder = vtkReordering(_eType, _basisFuncType, _bfOrder);
            for (int e = 0; e < _loc_nElem; e++)
            {
                // Get local idx of neighbor nodes // FIXME:: Is there a function to do this?
                vector<int> loc_nbors(_nVert);
                vector<int> nbors = _disMesh->_connec->getNborList(e, IndexType::Local);
                for (int n = 0; n < _nVert; n++)
                {
                    if (_disMesh->_graph->isItemInPart(nbors[n]))
                        loc_nbors[n] = _disMesh->_graph->locIdx(nbors[n]);
                    else
                        loc_nbors[n] = _disMesh->_graph->locGhostIdx(nbors[n]) + _loc_nPts;
                }

                // Create cell using reordering
                vtkSmartPointer<vtkIdList> cell = vtkSmartPointer<vtkIdList>::New();
                for (auto r: reorder)
                    cell->InsertNextId(loc_nbors[r]);

                // Insert cell
                cells->InsertNextCell(cell);
            }
        }

        // Create mesh (unstructured grid)
        vtkSmartPointer<vtkUnstructuredGrid> mesh = vtkSmartPointer<vtkUnstructuredGrid>::New();
        mesh->SetPoints(points);
        mesh->SetCells(vtkCellType, cells);
        // timer.end("CreateMesh");


        // timer.start("CreateLocator");
        // Create VTK locator
        _myCellLocator = vtkSmartPointer<vtkCellLocator>::New();
        _myCellLocator->SetDataSet(mesh);
        _myCellLocator->BuildLocator();

        // Create VTK cell
        _myGenericCell = vtkSmartPointer<vtkGenericCell>::New();
        _myGenericCell->SetCellType(vtkCellType);
        // timer.end("CreateLocator");
    }

    double vtkElementLocator::searchElementInPartition(int& elems, vector<double>& rCoords, vector<double> xCoords)
    {
        // Initialize
        double dist;

        // Find closest point projection using VTK
        int subID{};
        vtkIdType id;
        double closestPoint[3]{};
        _myCellLocator->FindClosestPoint(xCoords.data(), closestPoint, _myGenericCell, id, subID, dist);

        // Find the reference coordinate of the point using VTK
        vector<double> weights(_nVert);
        vector<double> rCoords_vtk(3);
        double distb;
        _myGenericCell->EvaluatePosition(closestPoint, closestPoint, subID, rCoords_vtk.data(), distb, weights.data());

        // Rearrange and re-scale reference coordinates
        if (_basisFuncType == BasisFuncType::BSplines or _basisFuncType == BasisFuncType::Nurbs)
        {
            for (int d = 0; d < _nDim; d++)
                rCoords[d] = 2.0*rCoords_vtk[d] - 1.0;
        }
        else
        {
            if ((_eType == ElemType::Line and _bfOrder != 3) or _eType == ElemType::Square or _eType == ElemType::Parallelep) // VTK_CUBIC_LINE rCoords are already in [-1,1]
            {
                for (int d = 0; d < _nDim; d++)
                    rCoords[d] = 2.0*rCoords_vtk[d] - 1.0;
            }
            else
            {
                for (int d = 0; d < _nDim; d++)
                    rCoords[d] = rCoords_vtk[d];
            }
        }

        // Save element
        elems = id + _disMesh->_connec->offs_nItem(); // FIXME:: Replace by appropriate functions?

        return dist;
    }

    vector<double> vtkElementLocator::searchElement(vector<int>& elems, vector<vector<double>>& rCoords, vector<vector<double>> xCoords)
    {
        // Initialize
        int nPoints = static_cast<int> (xCoords.size());

        // Search elements in partition
        vector<double> dists = ElementLocator::searchElementInPartition(elems, rCoords, xCoords);

        // Get (processor) location of the min distances
        struct distsAndProcs
        {
             double dist;
             int rank;
        };
        distsAndProcs * out = new distsAndProcs[nPoints];
        distsAndProcs * in  = new distsAndProcs[nPoints];
        for (int n = 0; n < nPoints; n++)
        {
            out[n].dist = dists[n];
            out[n].rank = _myRank;
        }
        MPI_Allreduce(out, in, nPoints, MPI_DOUBLE_INT, MPI_MINLOC, comm());

        // Share elems and rCoords //FIXME:: We are doing a loop, is there a more efficient way?
        for (int n = 0; n < nPoints; n++)
        {
            MPI_Bcast(&elems[n], 1, MPI_INT, in[n].rank, comm());
            MPI_Bcast(rCoords[n].data(), _pDim, MPI_DOUBLE, in[n].rank, comm());

            // Check
            if (in[n].dist < 0.0)
                throw runtime_error("ElementLocator::searchElement: Element not found");
        }

        // Delete
        delete[] out;
        delete[] in;

        return dists;
    }

}
