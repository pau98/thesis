/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <mpi.h>
#include <string>
#include <algorithm>
#include <utility>

#include <unistd.h> //FIXME sleep function

#include <Teuchos_CommandLineProcessor.hpp>
#include <Teuchos_ParameterList.hpp>

#include "hl_DistributedClass.h"
#include "hl_DOFsHandler.h"

#include "hl_PostProc.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;


int main(int argc, char *argv[])
{
    MPI_Init(&argc, &argv);

    DistributedClass dis;

    string pathInFiles;
    string pathOutFiles;
    // bool verbose = true;


    // Reading Terminal Parameters
    Teuchos::CommandLineProcessor parser;
    parser.setDocString(
      "This executable takes files in hlfe parallel output format and converts them to Legacy Vtk ones\n");


    pathInFiles.assign("");
    parser.setOption("pathInFiles", &pathInFiles, "Path to the input files. In the place where rank number is, a $ should be set. If it contains an star '*', it will convert all the existing files that contains a number where the star is.");

    pathOutFiles.assign("");
    parser.setOption("pathOutFiles", &pathOutFiles, "Path to the output files. If the input path contains an star '*', this one needs also one.");

    Teuchos::CommandLineProcessor::EParseCommandLineReturn
        parseReturn= parser.parse( argc, argv );

    if (pathInFiles.find('$') == string::npos)
    {
        cout << pathInFiles << endl;
        parser.printHelpMessage(argv[0], cout);
        MPI_Finalize();
        return 0;
    }

    if ( (pathInFiles.find('*') == string::npos) != (pathOutFiles.find('*') == string::npos))
    {
        parser.printHelpMessage(argv[0], cout);
        MPI_Finalize();
        return 0;
    }


    if( parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED )
    {
        MPI_Finalize();
        return 0;
    }
    if( parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL   )
    {
        MPI_Finalize();
        return 0;
    }



    auto prefixes = PostProc::readPrefixes(pathInFiles);


    for (auto p : prefixes)
    {
        RCP<DOFsHandler> dhand = rcp(new DOFsHandler);

        dhand->setFilePrefix(p.first);
        dhand->Update();


        dhand->printFileLegacyVtk(PostProc::genLegOutName(pathOutFiles, p.second));

        if(dis.myRank() == 0)
            cout << "File " << PostProc::genLegOutName(pathOutFiles, p.second) << " generated." << endl;

    }


    MPI_Finalize();
    return 0;

}
