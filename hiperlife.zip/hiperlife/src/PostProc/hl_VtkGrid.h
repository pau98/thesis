/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HPLFE_VTKGRID_H
#define HPLFE_VTKGRID_H

#include <iostream>
#include <map>
#include <string>

#include <vtkVersion.h>
#include <vtkSmartPointer.h>
#include <vtkUnstructuredGrid.h>
#include <vtkCellArray.h>
#include <vtkPointData.h>
#include <vtkDoubleArray.h>

#include "hl_DistributedClass.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DOFsHandler.h"

namespace hiperlife
{
    namespace PostProc
    {

        /*!
         * \brief This class generates an unstructured vtk grid from a file in hiperlife's
         * own format.
         */

        class VtkGrid //: public DistributedClass //FIXME: I don't think it is necessary
        {
            public:

                /** @name Constructor / Destructor / Operator
                 * Copy constructors are deleted for memory safety but objects can be created from
                 *  temporal objects through move constructors
                 *  @{ */
                VtkGrid();
                VtkGrid(VtkGrid&& other) = default;
                VtkGrid(const VtkGrid& other) = delete;
                ~VtkGrid() = default;

                // Operators
                VtkGrid& operator=(const VtkGrid& other) = delete;
                VtkGrid& operator=(VtkGrid&& other) = default;
                /** @} */ // end of constructors

                /** @name Object Creation Management
                 *  @{
                 */
                inline void setFileName(std::string inFileName){_inFileName = inFileName;}
                void setMesh(Teuchos::RCP<MeshCreator> mesh);
                void setDOFsHandler(Teuchos::RCP<DOFsHandler> dHand);
                /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
                void Update();
                /** @} */ // end of object creation


                /** @name Vtk data access
                 *  @{
                 */
                /*! \brief Returns the unstructured grid.*/
                vtkSmartPointer<vtkUnstructuredGrid> unstructGrid(){return _grid;}
                /** @} */ // end of Vtk data access


            private:

                //Main variables
                std::string _inFileName = "";
                Teuchos::RCP<MeshCreator> _mesh  = Teuchos::null;
                Teuchos::RCP<StructMeshGenerator> _sMesh  = Teuchos::null;
                Teuchos::RCP<MeshLoader> _lMesh  = Teuchos::null;
                Teuchos::RCP<DOFsHandler> _dHand  = Teuchos::null;
                vtkSmartPointer<vtkUnstructuredGrid> _grid;

                //Update functions
                void _updateFile();
                void _updateMesh();
                void _updateSMesh();
                void _updateDHand();

                //Read functions
                void _readFile();
                void _readTimeData(std::istream &in, OutputMode mode);
                void _readGlobalData(std::istream &in, OutputMode mode);
                void _readDisMeshData(std::istream &in, OutputMode mode);
                void _readGraphData(std::istream &in, OutputMode mode);
                void _readConnec(std::istream &in, OutputMode mode);
                void _readNodeCoords(std::istream &in, OutputMode mode);
                void _readElemFlags(std::istream &in, OutputMode mode);
                void _readNodeDOFs(std::istream &in, OutputMode mode);
                void _readNodeAuxF(std::istream &in, OutputMode mode);
                void _readElemAuxF(std::istream &in, OutputMode mode);
                void _readNurbsData(std::istream &in, OutputMode mode);
                void _readMeshLinearConstraints(std::istream &in, OutputMode mode);

                //Auxiliary
                void _reorderConnec();

                //Create functions
                void _createGrid();
                void _createCoordsData();
                void _createCellsData();
                void _createFieldsData();
                void _createTimeData();
                void _createGlobalData();


                //Mesh variables
                int _nPts{};
                int _nElem{};
                int _loc_nPts{};
                int _loc_nElem{};
                int _m_loc_nElem{};
                int _ghosts_Pts{};
                int _ghosts_Elem{};
                int _nEx{-1}, _nEy{-1}, _nEz{-1};
                int _tot_locPts{};

                int _nDim{3};
                int _pDim{};
                int _nVert{};
                int _m_nVert{};

                int _bfOrder{-1};
                int _bfOrderX{-1}, _bfOrderY{-1}, _bfOrderZ{-1};

                ElemType _eType{ElemType::Undefined};
                BasisFuncType _bfType{BasisFuncType::Undefined};

                std::vector<double> _x_nodes;
                std::vector<double> _weights;
                std::vector<double> _uKnot;
                std::vector<double> _vKnot;
                std::vector<double> _wKnot;
                std::vector<int> _connec;

                int _nLinearConstraints{};

                int _nDOFs{};
                int _npFlag{2};
                int _neFlag{1};
                int _npAuxF{};
                int _neAuxF{};
                std::vector<double> _nodeDOFs;
                std::vector<int>    _elemFlag;
                std::vector<double> _nodeAuxF;
                std::vector<double> _elemAuxF;
                std::vector<std::string> _name_elemFlag;
                std::vector<std::string> _name_nodeDOFs;
                std::vector<std::string> _name_nodeAuxF;
                std::vector<std::string> _name_elemAuxF;


                std::map<int, int> _mapGtoL;
                double _time;
                std::vector<double> _gData;
                double _nGData;

                //Other variables
                int _rank;
                int _numProcs;

        };

    }

}

#endif
