/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iterator>

#include <vtkCellData.h>

#include "hl_TypeDefs.h"
#include "hl_VtkGrid.h"
#include "hl_IO_Aux.h"

using namespace std;
using namespace hiperlife;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    namespace PostProc
    {
        VtkGrid::VtkGrid()
        {

        }

        void VtkGrid::setMesh(RCP<MeshCreator> mesh)
        {
            _mesh = mesh;

            //Get common info
            _eType = _mesh->_eType;
            _bfType = _mesh->_bfType;
            _bfOrder = _mesh->_bfOrder;
            _bfOrderX = _mesh->_bfOrderX;
            _bfOrderY = _mesh->_bfOrderY;
            _bfOrderZ = _mesh->_bfOrderZ;
            _nEx = _mesh->_nEx;
            _nEy = _mesh->_nEy;
            _nEz = _mesh->_nEz;
            _weights = _mesh->_weights;
            _uKnot = _mesh->_uKnot;
            _vKnot = _mesh->_vKnot;
            _wKnot = _mesh->_wKnot;

            //Get specific info
            if (_mesh->nameTag() == "StructMeshGenerator")
            {
                _loc_nPts = _mesh->_loc_nPts;
                _tot_locPts = _loc_nPts;
                _loc_nElem = _mesh->_loc_nElem;
                _x_nodes = _mesh->_x_nodes;
                _connec = _mesh->_connec;
            }
            else if (_mesh->nameTag() == "MeshLoader")
            {
                _loc_nPts = mesh->_nPts;
                _tot_locPts = mesh->_nPts;
                _loc_nElem = mesh->_nElem;
                _x_nodes = _mesh->_glob_x_nodes;
                _connec = _mesh->_glob_connec;
            }

            //FIXME: I don't know about this one
            //Create fake elemflag
            for (int i = 0; i < _loc_nElem; i++)
                _elemFlag.push_back(i);

        }

        void VtkGrid::Update()
        {
            if (_inFileName != "")
                _updateFile();
            else if (_mesh != Teuchos::null)
                _updateMesh();
            else if (_dHand != Teuchos::null)
                _updateDHand();
            else
                throw runtime_error("VtkGrid::Update: There is no ready update method");
        }

        void VtkGrid::_updateFile()
        {
            //Read *.hl file
            _readFile();

            //Create grid
            _createGrid();
        }

        void VtkGrid::_updateMesh()
        {
            //Create grid
            _createGrid();
        }

        void VtkGrid::_updateDHand()
        {

        }

        void VtkGrid::_readFile()
        {

            //Prepare files
            string fname = _inFileName.substr(0, _inFileName.find_last_of("."));
            string outFileName = fname + ".vtu";
            ifstream inputFile(_inFileName);
            if (!inputFile.good())
                throw std::runtime_error("HPLFE_PP_OutputToVtk: The file: "+ _inFileName + " could not be opened. Check that and rerun, please. Goodbye!");

            //Get rank
            _rank = stoi(fname.substr(fname.find_last_of(".")+1));

            //Read input file
            string line;
            while (getline(inputFile, line))
            {
                // Checks
                if (line.empty())
                    continue;
                if (line.find_first_not_of(' ') == string::npos)
                    continue;

                // Get line
                std::istringstream iss(line);
                vector<string> tokens{istream_iterator<string>{iss}, istream_iterator<string>{}};

                //Read time
                if (tokens[0] == "Time" && tokens[1] == "time")
                    _readTimeData(inputFile, outputMode(tokens[2]));

                //Read global data
                if (tokens[0] == "GlobalData" && tokens[1] == "globaldata")
                    _readGlobalData(inputFile, outputMode(tokens[2]));

                //Read distributed mesh
                if (tokens[0] == "DisMesh" && tokens[1] == "DistributedMesh")
                    _readDisMeshData(inputFile, outputMode(tokens[2]));

                // Read graph
                if (tokens[0] == "Graph" && tokens[1] == "GraphStruct")
                    _readGraphData(inputFile, outputMode(tokens[2]));

                // Read connectivity
                if (tokens[0] == "Connec" && tokens[1] == "ConnecStruct")
                    _readConnec(inputFile, outputMode(tokens[2]));

                // Read node coordinates
                if (tokens[0] == "nodeData" && tokens[1] == "FieldStruct")
                    _readNodeCoords(inputFile, outputMode(tokens[2]));

                // Read element flags
                if (tokens[0] == "elemFlags" && tokens[1] == "IntFieldStruct")
                    _readElemFlags(inputFile, outputMode(tokens[2]));

                // Read node DOFs
                if (tokens[0] == "nodeDOFs" && tokens[1] == "FieldStruct")
                    _readNodeDOFs(inputFile, outputMode(tokens[2]));

                // Read node Aux
                if (tokens[0] == "nodeAuxF" && tokens[1] == "FieldStruct")
                    _readNodeAuxF(inputFile, outputMode(tokens[2]));

                // Read elem Aux
                if (tokens[0] == "elemAuxF" && tokens[1] == "FieldStruct")
                    _readElemAuxF(inputFile, outputMode(tokens[2]));

                // Read Nurbs
                if (tokens[0] == "Knots" && tokens[1] == "Weights")
                    _readNurbsData(inputFile, outputMode(tokens[2]));

                // Read mesh linear constraints
                if (tokens[0] == "Periodicity" && tokens[1] == "PeriodicBC")
                    _readMeshLinearConstraints(inputFile, outputMode(tokens[2]));

            }

        }

        void VtkGrid::_createGrid()
        {
            //Reorder connectivity
            _reorderConnec();

            //Create the vtk grid
            _grid = vtkSmartPointer<vtkUnstructuredGrid>::New();
            _createCoordsData();
            _createCellsData();
            _createFieldsData();
            _createTimeData();
            _createGlobalData();
        }

        void VtkGrid::_readTimeData(istream &in, OutputMode mode)
        {
            //Read time
            vector<double> ibuff(1);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _time = ibuff[0];
        }

        void VtkGrid::_readGlobalData(istream &in, OutputMode mode)
        {
            //Read number of global data
            vector<int> ibuff(1);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _nGData = ibuff[0];

            //Read global data
            _gData.resize(_nGData);
            IO::fillData(_gData.data(), in, _nGData, mode);
        }

        void VtkGrid::_readDisMeshData(istream &in, OutputMode mode)
        {
            // Read general mesh info
            vector<int> ibuff(7);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            //Save it
            _nDim = ibuff[0];
            _pDim = ibuff[1];
            _bfType = BasisFuncType(ibuff[2]);
            _bfOrder = ibuff[3];
            _bfOrderX = ibuff[4];
            _bfOrderY = ibuff[5];
            _bfOrderZ = ibuff[6];
        }

        void VtkGrid::_readGraphData(istream &in, OutputMode mode)
        {
            // Read general information of DistData [0]
            vector<int> ibuff(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _numProcs = ibuff[0];
            _nPts = ibuff[1];
            _loc_nPts = ibuff[2];
            _ghosts_Pts = ibuff[3];
            _tot_locPts = _loc_nPts + _ghosts_Pts;

            // Read general information of DistData [1]
            ibuff.resize(_numProcs);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            int offsRank = ibuff[_rank];

            // Create map with points
            for (int i = 0; i < _loc_nPts; i++)
                _mapGtoL.emplace(i + offsRank, i);

            // Read ghosts
            ibuff.resize(_ghosts_Pts);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            // Add ghosts to map
            for (int i = 0; i < _ghosts_Pts; i++)
                _mapGtoL.emplace(ibuff[i], _loc_nPts + i);
        }

        void VtkGrid::_readConnec(istream &in, OutputMode mode)
        {
            // Read general information of DistData
            vector<int> ibuff(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _numProcs = ibuff[0];
            _nElem = ibuff[1];
            _loc_nElem = ibuff[2];
            _ghosts_Elem = ibuff[3];

            // Perform checks

            // Read remaining general information of DistData [proc_Elems, offs_Elems, _ghosts_Elems]
            ibuff.resize(_numProcs);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            ibuff.resize(_ghosts_Elem);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            // Read general connectivity info
            ibuff.resize(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _nVert = ibuff[0];
            _eType = ElemType(ibuff[1]);
            int connecSize = ibuff[2];
            int locE = connecSize / _nVert;

            // Checks
            if (_loc_nElem != locE)
                throw runtime_error("VtkGrid::_readConnec: The number of elements of the connectivity does not match. (file: " + _inFileName + ")");
            if (connecSize % _nVert != 0)
                throw runtime_error("VtkGrid::_readConnec: Connectivity is wrong. (file: " + _inFileName + ")");

            // Read connectivity
            _connec.resize(connecSize);
            IO::fillData(_connec.data(), in, connecSize, mode);
        }

        void VtkGrid::_readNodeCoords(istream &in, OutputMode mode)
        {
            // Read general information of DistData
            vector<int> ibuff(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _numProcs = ibuff[0];
            _nPts = ibuff[1];
            _loc_nPts = ibuff[2];
            _ghosts_Pts = ibuff[3];

            // Perform checks
            // if ((mData.loc_nPts + mData.ngPts) != int(mData.mapGlobToLoc.size()))
            //     throw runtime_error(
            //         "HPLFE_PP_OutputToVtk:getVtkPoints: There is a problem in the file of rank " +
            //         to_string(mData.rank) + " or in the mapGlobToLoc.\n " +
            //         "numLocNPts: " + to_string(mData.loc_nPts) + "  - numGhosts: " + to_string(mData.ngPts) +
            //         "  - mapSize: " + to_string(mData.mapGlobToLoc.size()));

            // Read remaining general information of DistData [proc_Pts, offs_Pts, _ghosts_Pts]
            ibuff.resize(_numProcs);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            ibuff.resize(_ghosts_Pts);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            // Read nodeCoors info [numFlds, numFlds()*_loc_nItem, numFlds()*_nItem]
            ibuff.resize(3);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            int nDim = ibuff[0];
            int numPoints = _loc_nPts + _ghosts_Pts;
            int numTotItems = nDim * numPoints;

            // Read tags
            vector<string> tagBuff(nDim);
            IO::fillData(tagBuff.data(), in, tagBuff.size(), mode);

            // Read coordinates
            _x_nodes.resize(numTotItems);
            IO::fillData(_x_nodes.data(), in, numTotItems, mode);
        }

        void VtkGrid::_readElemFlags(istream &in, OutputMode mode)
        {
            // Read general information of DistData
            vector<int> ibuff(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _numProcs = ibuff[0];
            _nElem = ibuff[1];
            _loc_nElem = ibuff[2];
            _ghosts_Elem = ibuff[3];

            // Perform checks
            // FIXME: Implement check
            // if ((numLocElem + numGhosts) != mData.mapGlobToLoc.size())
            //     throw runtime_error(
            //         "HPLFE_PP_OutputToVtk:getVtkPoints: There is a problem in the file of rank " +
            //         to_string(mData.rank) + " or in the mapGlobToLoc.\n " +
            //         "numLocElem: " + to_string(numLocElem) + "  - numGhosts: " + to_string(numGhosts) +
            //         "  - mapSize: " + to_string(mData.mapGlobToLoc.size()));

            // Read remaining general information of DistData [proc_Pts, offs_Pts, _ghosts_Pts]
            ibuff.resize(_numProcs);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            ibuff.resize(_ghosts_Elem);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            // Read elemFlag info [numFlds, numFlds()*_loc_nItem, numFlds()*_nItem]
            ibuff.resize(3);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _neFlag = ibuff[0];
            int numElems = _loc_nElem + _ghosts_Elem;
            int numTotItems = _neFlag * numElems;

            // Read tags
            _name_elemFlag.resize(_neFlag);
            IO::fillData(_name_elemFlag.data(), in, _neFlag, mode);

            // Read elemFlag
            _elemFlag.resize(numTotItems);
            IO::fillData(_elemFlag.data(), in, numTotItems, mode);
        }

        void VtkGrid::_readNodeDOFs(istream &in, OutputMode mode)
        {
            // Read general information of DistData
            vector<int> ibuff(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _numProcs = ibuff[0];
            _nPts = ibuff[1];
            _loc_nPts = ibuff[2];
            _ghosts_Pts = ibuff[3];

            // Perform checks
            // if ((numLocNPts + numGhosts) != int(mData.mapGlobToLoc.size()))
            //     throw runtime_error("HPLFE_PP_OutputToVtk:getVtkPoints: There is a problem in the file of rank " +
            //                         to_string(mData.rank) + " or in the mapGlobToLoc.\n " +
            //                         "numLocNPts: " + to_string(numLocNPts) + "  - numGhosts: " + to_string(numGhosts) +
            //                         "  - mapSize: " + to_string(mData.mapGlobToLoc.size()));

            // Read remaining general information of DistData [proc_Pts, offs_Pts, _ghosts_Pts]
            ibuff.resize(_numProcs);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            ibuff.resize(_ghosts_Pts);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            // Read nodeDOFs info [numFlds, numFlds()*_loc_nItem, numFlds()*_nItem]
            ibuff.resize(3);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _nDOFs = ibuff[0];
            int numPoints = _loc_nPts + _ghosts_Pts;
            int numTotItems = _nDOFs * numPoints;

            // Read tags
            _name_nodeDOFs.resize(_nDOFs);
            IO::fillData(_name_nodeDOFs.data(), in, _nDOFs, mode);

            // Read nodeDOFs
            _nodeDOFs.resize(numTotItems);
            IO::fillData(_nodeDOFs.data(), in, numTotItems, mode);
        }

        void VtkGrid::_readNodeAuxF(istream &in, OutputMode mode)
        {
            // Read general information of DistData
            vector<int> ibuff(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _numProcs = ibuff[0];
            _nPts = ibuff[1];
            _loc_nPts = ibuff[2];
            _ghosts_Pts = ibuff[3];

            // Perform checks
            // if ((numLocNPts + numGhosts) != int(mData.mapGlobToLoc.size()))
            //     throw runtime_error(
            //         "HPLFE_PP_OutputToVtk:getVtkNodeAuxF: There is a problem in the file of rank " +
            //         to_string(mData.rank) + " or in the mapGlobToLoc.\n " +
            //         "numLocNPts: " + to_string(numLocNPts) + "  - numGhosts: " + to_string(numGhosts) +
            //         "  - mapSize: " + to_string(mData.mapGlobToLoc.size()));

            // Read remaining general information of DistData [proc_Pts, offs_Pts, _ghosts_Pts]
            ibuff.resize(_numProcs);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            ibuff.resize(_ghosts_Pts);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            // Read nodeAuxF info [numFlds, numFlds()*_loc_nItem, numFlds()*_nItem]
            ibuff.resize(3);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _npAuxF = ibuff[0];
            int numPoints = _loc_nPts + _ghosts_Pts;
            int numTotItems = _npAuxF * numPoints;

            // Read tags
            _name_nodeAuxF.resize(_npAuxF);
            IO::fillData(_name_nodeAuxF.data(), in, _npAuxF, mode);

            // Read nodeAuxF
            _nodeAuxF.resize(numTotItems);
            IO::fillData(_nodeAuxF.data(), in, numTotItems, mode);
        }

        void VtkGrid::_readElemAuxF(istream &in, OutputMode mode)
        {
            // Read general information of DistData
            vector<int> ibuff(4);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _numProcs = ibuff[0];
            _nElem = ibuff[1];
            _loc_nElem = ibuff[2];
            _ghosts_Elem = ibuff[3];

            // Perform checks
            // FIXME: Implement check
            // if ((numLocElem + numGhosts) != mData.mapGlobToLoc.size())
            //     throw runtime_error(
            //         "HPLFE_PP_OutputToVtk:getVtkPoints: There is a problem in the file of rank " +
            //         to_string(mData.rank) + " or in the mapGlobToLoc.\n " +
            //         "numLocElem: " + to_string(numLocElem) + "  - numGhosts: " + to_string(numGhosts) +
            //         "  - mapSize: " + to_string(mData.mapGlobToLoc.size()));

            // Read remaining general information of DistData [proc_Pts, offs_Pts, _ghosts_Pts]
            ibuff.resize(_numProcs);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            ibuff.resize(_ghosts_Elem);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);

            // Read elemAuxF info [numFlds, numFlds()*_loc_nItem, numFlds()*_nItem]
            ibuff.resize(3);
            IO::fillData(ibuff.data(), in, ibuff.size(), mode);
            _neAuxF = ibuff[0];
            int numElems = _loc_nElem + _ghosts_Elem;
            int numTotItems = _neAuxF * numElems;

            // Read tags
            _name_elemAuxF.resize(_neAuxF);
            IO::fillData(_name_elemAuxF.data(), in, _neAuxF, mode);

            // Read elemAuxF
            _elemAuxF.resize(numTotItems);
            IO::fillData(_elemAuxF.data(), in, numTotItems, mode);
        }

        void VtkGrid::_readNurbsData(istream &in, OutputMode mode)
        {
            //Get pdim and knot dimensions
            vector<int> buff(4);
            IO::fillData(buff.data(), in, buff.size(), mode);
            int uk_size = buff[0];
            int vk_size = buff[1];
            int wk_size = buff[2];
            int wei_size = buff[3];

            //Set number of elements per direction
            _nEx = uk_size - _bfOrderX*2 - 1;
            _nEy = vk_size - _bfOrderY*2 - 1;
            _nEz = wk_size - _bfOrderZ*2 - 1;

            //Read knots
            double * _tmp_uKnot = new double[uk_size];
            double * _tmp_vKnot = new double[vk_size];
            double * _tmp_wKnot = new double[wk_size];
            IO::fillData(_tmp_uKnot, in, uk_size, mode);
            if (_pDim > 1)
                IO::fillData(_tmp_vKnot, in, vk_size, mode);
            if (_pDim > 2)
                IO::fillData(_tmp_wKnot, in, wk_size, mode);

            //Set knots //FIXME: reserve should increase speed
            for (int k = 0; k < uk_size; k++)
                _uKnot.push_back(_tmp_uKnot[k]);
            for (int k = 0; k < vk_size; k++)
                _vKnot.push_back(_tmp_vKnot[k]);
            for (int k = 0; k < wk_size; k++)
                _wKnot.push_back(_tmp_wKnot[k]);

            //Read and set weights
            double * _tmp_weights = new double[wei_size];
            if (wei_size > 0)
            {
                IO::fillData(_tmp_weights, in, wei_size, mode);
                for (int k = 0; k < wei_size; k++)
                    _weights.push_back(_tmp_weights[k]);
            }

            //Delete
            delete[] _tmp_uKnot;
            delete[] _tmp_vKnot;
            delete[] _tmp_wKnot;
            delete[] _tmp_weights;
        }

        void VtkGrid::_readMeshLinearConstraints(istream &in, OutputMode mode)
        {
            //Get number of mesh linear constraint nodes
            vector<int> buff(1);
            IO::fillData(buff.data(), in, buff.size(), mode);
            _nLinearConstraints = buff[0];

            //Read masters
            buff.resize(_nLinearConstraints);
            IO::fillData(buff.data(), in, buff.size(), mode);

            //Read slaves
            IO::fillData(buff.data(), in, buff.size(), mode);
        }

        void VtkGrid::_reorderConnec()
        {
            //Save old connectivity
            vector<int> tmp_connec = _connec;
            _connec.clear();

            //Compute nVert
            if (_bfType != BasisFuncType::BSplines and _bfType != BasisFuncType::Nurbs)
                _nVert = computeNVert(_bfType, _eType, _bfOrder);
            else
                _nVert = computeNVert(_bfType, _eType, _bfOrderX, _bfOrderY, _bfOrderZ);

            // Reorder connectivity
            _m_nVert = _nVert;
            _m_loc_nElem = _loc_nElem;
            if ((_bfType == BasisFuncType::Lagrangian) and (_eType != ElemType::Tetrah))
            {
                vector<int> reorder = vtkReordering(_eType, _bfType, _bfOrder);
                int pos{};
                _connec.reserve(_loc_nElem*_nVert);
                for (int e = 0; e < _loc_nElem; e++)
                {
                    for (int v = 0; v < _nVert; v++)
                        _connec.push_back(tmp_connec[pos+reorder[v]]);
                    pos += _nVert;
                }
            }
            else if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            {
                //Initialize
                vector<int> myidx;
                switch(int (_eType))
                {
                    case static_cast<int>(ElemType::Line):
                        _m_nVert = 2;
                        myidx = {0, 1};
                        break;
                    case static_cast<int>(ElemType::Square):
                        _m_nVert = 4;
                        myidx = {0, 1, _bfOrderX+2, _bfOrderX+1};
                        break;
                    case static_cast<int>(ElemType::Parallelep):
                        _m_nVert = 8;
                        myidx = {0, 1, _bfOrderX+2, _bfOrderX+1, (_bfOrderX+1)*(_bfOrderY+1), (_bfOrderX+1)*(_bfOrderY+1)+1, (_bfOrderX+1)*(_bfOrderY+1)+_bfOrderX+2, (_bfOrderX+1)*(_bfOrderY+1)+_bfOrderX+1};
                        break;
                    default:
                        throw runtime_error("vtk: ElemType not set.");
                        break;
                }

                int pos{};
                _m_loc_nElem = 0;
                for (int e = 0; e < _loc_nElem; e++)
                {
                    vector<int> myNbor;
                    for (int v = 0; v < _nVert; v++)
                        myNbor.push_back(tmp_connec[pos+v]);
                    pos += _nVert;
                    int elem = _elemFlag[e];
                    int inex{}, iney{}, inez{};
                    int iimax{1}, jjmax{1}, kkmax{1};
                    switch(int (_eType))
                    {
                        case static_cast<int>(ElemType::Line):
                            inex = elem % _nEx;
                            if (inex == _nEx-1)
                                iimax = _bfOrderX;
                            for (int ii = 0; ii < iimax; ii++)
                            {
                                for (int m = 0; m < int(myidx.size()); m++)
                                    _connec.push_back(myNbor[ii+myidx[m]]);
                                _m_loc_nElem++;
                            }
                            break;
                        case static_cast<int>(ElemType::Square):
                            inex = elem % _nEx;
                            iney = (int) elem/_nEx;
                            if (inex == _nEx-1)
                                iimax = _bfOrderX;
                            if (iney == _nEy-1)
                                jjmax = _bfOrderY;
                            for (int jj = 0; jj < jjmax; jj++)
                            {
                                for (int ii = 0; ii < iimax; ii++)
                                {
                                    for (int m = 0; m < int(myidx.size()); m++)
                                        _connec.push_back(myNbor[jj*(_bfOrderX+1)+ii+myidx[m]]);
                                    _m_loc_nElem++;
                                }
                            }
                            break;
                        case static_cast<int>(ElemType::Parallelep):
                            inex = elem % _nEx;
                            iney = (elem%(_nEx*_nEy))/_nEx;
                            inez = (elem/(_nEx*_nEy));
                            if (inex == _nEx-1)
                                iimax = _bfOrderX;
                            if (iney == _nEy-1)
                                jjmax = _bfOrderY;
                            if (inez == _nEz-1)
                                kkmax = _bfOrderZ;
                            for (int kk = 0; kk < kkmax; kk++)
                            {
                                for (int jj = 0; jj < jjmax; jj++)
                                {
                                    for (int ii = 0; ii < iimax; ii++)
                                    {
                                        for (int m = 0; m < int(myidx.size()); m++)
                                            _connec.push_back(myNbor[kk*(_bfOrderX+1)*(_bfOrderY+1)+jj*(_bfOrderX+1)+ii+myidx[m]]);
                                        _m_loc_nElem++;
                                    }
                                }
                            }
                            break;
                        default:
                            throw runtime_error("vtk: ElemType not set.");
                            break;
                    }
                }
            }
            else if (_bfType == BasisFuncType::SubdivSurfs or _bfType == BasisFuncType::Linear)
            {
                _connec = tmp_connec;
            }
            else
            {
                throw runtime_error("CreateVtkGrid::getVtkConnec: Reorder connect not implemented yet for this bfType and elemType,");
            }
        }

        void VtkGrid::_createCoordsData()
        {
            // Create data
            vtkSmartPointer<vtkDoubleArray> data = vtkSmartPointer<vtkDoubleArray>::New();
            data->SetNumberOfComponents(_nDim);
            data->SetNumberOfTuples(_tot_locPts);
            if (_mesh != Teuchos::null and _mesh->nameTag() == "MeshLoader")
            {
                for (int d = 0; d < _nDim; d++)
                    for (int i = 0; i < _tot_locPts; i++)
                        data->SetComponent(i, d, _x_nodes[i*_nDim + d]);
            }
            else
            {
                for (int d = 0; d < _nDim; d++)
                    for (int i = 0; i < _tot_locPts; i++)
                        data->SetComponent(i, d, _x_nodes[d*_tot_locPts + i]);
            }
            //Create coords
            vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
            points->SetData(data);

            // Save to grid
            _grid->SetPoints(points);
        }

        void VtkGrid::_createCellsData()
        {
            //Create connectivity
            vtkSmartPointer<vtkCellArray> cellArray = vtkSmartPointer<vtkCellArray>::New();
            cellArray->Allocate(_m_loc_nElem);
            if (_inFileName != "")
            {
                for (int e = 0; e < _m_loc_nElem; e++)
                {
                    int idx = e * _m_nVert;
                    cellArray->InsertNextCell(_m_nVert);
                    for (int i = 0; i < _m_nVert; i++)
                        cellArray->InsertCellPoint(_mapGtoL[_connec[idx+i]]);
                }
            }
            else
            {
                for (int e = 0; e < _m_loc_nElem; e++)
                {
                    int idx = e * _m_nVert;
                    cellArray->InsertNextCell(_m_nVert);
                    for (int i = 0; i < _m_nVert; i++)
                        cellArray->InsertCellPoint(_connec[idx+i]);
                }
            }

            //Set connectivity (and cell type)
            _grid->SetCells(hlToVtkElemType(_eType, _bfType, _bfOrder), cellArray);
        }

        void VtkGrid::_createFieldsData()
        {
            //nodeDOFs
            for (int d = 0; d < _nDOFs; d++)
            {
                //Create data array
                vtkSmartPointer<vtkDoubleArray> data = vtkSmartPointer<vtkDoubleArray>::New();
                data->SetNumberOfComponents(1);
                data->SetNumberOfTuples(_tot_locPts);

                //Add field to data
                for (int i = 0; i < _tot_locPts; i++)
                    data->SetComponent(i, 0, _nodeDOFs[d*_tot_locPts + i]);

                //Set field name
                string stdname = "Field_" + to_string(d);
                string name = _name_nodeDOFs[d];
                if (_name_nodeDOFs[d] == stdname)
                    name = "DOF_" + to_string(d);
                data->SetName(name.c_str());
                //Add to grid
                _grid->GetPointData()->AddArray(data);
            }

            //nodeAuxF
            for (int d = 0; d < _npAuxF; d++)
            {
                //Create data array
                vtkSmartPointer<vtkDoubleArray> data = vtkSmartPointer<vtkDoubleArray>::New();
                data->SetNumberOfComponents(1);
                data->SetNumberOfTuples(_tot_locPts);

                //Add field to data
                for (int i = 0; i < _tot_locPts; i++)
                    data->SetComponent(i, 0, _nodeAuxF[d*_tot_locPts + i]);

                //Set field name
                string stdname = "Field_" + to_string(d);
                string name = _name_nodeAuxF[d];
                if (_name_nodeAuxF[d] == stdname)
                    name = "AUX_" + to_string(d);
                data->SetName(name.c_str());

                //Add to grid
                _grid->GetPointData()->AddArray(data);
            }

            //elemAuxF
            for (int d = 0; d < _neAuxF; d++)
            {
                //Create data array
                vtkSmartPointer<vtkDoubleArray> data = vtkSmartPointer<vtkDoubleArray>::New();
                data->SetNumberOfComponents(1);
                data->SetNumberOfTuples(_m_loc_nElem);

                //Add field to data
                for (int i = 0; i < _m_loc_nElem; i++)
                    data->SetComponent(i, 0, _elemAuxF[d*_m_loc_nElem + i]);

                //Set field name
                string stdname = "Field_" + to_string(d);
                string name = _name_elemAuxF[d];
                if (_name_elemAuxF[d] == stdname)
                    name = "AUX_" + to_string(d);
                data->SetName(name.c_str());

                //Add to grid
                _grid->GetCellData()->AddArray(data);
            }
        }

        void VtkGrid::_createTimeData()
        {
            vtkDoubleArray *t = vtkDoubleArray::New();
            t->SetName("Time");
            t->SetNumberOfTuples(1);
            t->SetTuple1(0, _time);
            _grid->GetFieldData()->AddArray(t);
        }

        void VtkGrid::_createGlobalData()
        {
            for (size_t i = 0; i < _gData.size(); i++)
            {
                vtkDoubleArray *g = vtkDoubleArray::New();
                std::string gName = "g"+to_string(i);
                g->SetName(gName.c_str());
                g->SetNumberOfTuples(1);
                g->SetTuple1(0, _gData[i]);
                _grid->GetFieldData()->AddArray(g);
            }
        }
    }
}
