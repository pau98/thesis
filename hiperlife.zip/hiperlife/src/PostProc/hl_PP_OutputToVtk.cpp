/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <algorithm>
#include <iostream>
#include <filesystem>
#include <mpi.h>
#include <string>
#include <utility>

#include <pugixml-1.8/src/pugixml.hpp>

#include <Teuchos_RCP.hpp>
#include <Teuchos_CommandLineProcessor.hpp>

#include <vtkSmartPointer.h>
#include <vtkXMLUnstructuredGridWriter.h>
#include <vtkXMLUnstructuredGridReader.h>
#include <vtkUnstructuredGrid.h>
#include <vtkCellData.h>

#include "hl_DistributedData.h"

#include "hl_PostProc.h"
#include "hl_VtkGrid.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;



pair<vector<string>,vector<string>> outputToVtu_singleFile(const string& inFileName)
{
    // Create output file name
    string nameWOext = inFileName.substr(0, inFileName.find_last_of('.'));
    string outFileName = nameWOext + ".vtu";

    // Read file and store it in a vtkUnstructuredGrid
    Teuchos::RCP<PostProc::VtkGrid> grid = Teuchos::rcp(new PostProc::VtkGrid);
    grid->setFileName(inFileName);
    grid->Update();
    vtkSmartPointer<vtkUnstructuredGrid> unstrucGrid = grid->unstructGrid();

    // Get all data arrays of the grid
    int numDataArrays = unstrucGrid->GetPointData()->GetNumberOfArrays();
    vector<string> dataArrays;
    for (int i = 0; i < numDataArrays; i++)
        dataArrays.emplace_back(unstrucGrid->GetPointData()->GetArrayName(i));

    // Get all cell arrays of the grid
    int numCellArrays = unstrucGrid->GetCellData()->GetNumberOfArrays();
    vector<string> cellArrays;
    for (int i = 0; i < numCellArrays; i++)
        cellArrays.emplace_back(unstrucGrid->GetCellData()->GetArrayName(i));

    // Write file
    vtkSmartPointer<vtkXMLUnstructuredGridWriter> writer = vtkSmartPointer<vtkXMLUnstructuredGridWriter>::New();
    writer->SetFileName(outFileName.c_str());
    writer->SetInputData(unstrucGrid);
    writer->SetDataModeToAscii();
    writer->Write();

    return {dataArrays, cellArrays};
}

pair<vector<string>, vector<string>> generateAllVtu(const string& pathFiles, bool overwrite)
{
    //Get file names and sort them
    vector<string> allTaskFiles;
    for (filesystem::recursive_directory_iterator end, dir(pathFiles);
         dir != end; ++dir )
    {
        if (PostProc::ends_with(dir->path().string(), ".hl"))
        {
            if (!overwrite)
            {
                string hlName = dir->path().string();
                string name = hlName.substr(0, hlName.find_last_of('.'));
                string nameVtu = name + ".vtu";
                std::ifstream infile(nameVtu);
                if (!infile.good())
                    allTaskFiles.push_back(dir->path().string());
            }
            else
            {
                allTaskFiles.push_back(dir->path().string());
            }
        }
    }
    sort(allTaskFiles.begin(), allTaskFiles. end());

    //Distribute files among processors
    DistributedData disData;
    disData.setNItem(static_cast<int>(allTaskFiles.size()));
    disData.Update();

    //Store file names of this processor
    vector<string> myTaskFiles;
    for (int i = 0; i < disData.loc_nItem(); i++)
    {
        int idx = i + disData.offs_nItem();
        myTaskFiles.push_back(allTaskFiles[idx]);
    }

    //Create files
    pair<vector<string>, vector<string>> dataArrays;
    for (const auto& a: myTaskFiles)
    {
        if (a == myTaskFiles[0])
            dataArrays = outputToVtu_singleFile(a);
        else
            outputToVtu_singleFile(a);
    }

    return dataArrays;
}

int generatePvtu(const string& pathFiles, pair<vector<string>, vector<string>>& dataArray)
{
    // Store pvtu prefixes and vtu file names
    vector<string> prefixes;
    vector<vector<string>> files;
    for (filesystem::recursive_directory_iterator end, dir(pathFiles);
        dir != end; ++dir )
    {
        //Check
        if (!PostProc::ends_with(dir->path().string(), ".vtu"))
            continue;

        //Save names
        string fileName = dir->path().string();
        string temp = fileName.substr(0, fileName.find_last_of('.'));
        string prefix = temp.substr(0, temp.find_last_of('.'));

        //Store them in a vector
        auto iter = find(prefixes.begin(), prefixes.end(), prefix);
        if (iter == prefixes.end())
        {
            prefixes.push_back(prefix);
            files.emplace_back();
            files[files.size()-1].push_back(fileName);
        }
        else
        {
            auto posPref = std::distance(prefixes.begin(), iter);
            files[posPref].push_back(fileName);
        }
    }

    // Print pvtu in xml format
    for (auto i = 0u; i < files.size(); i++)
    {
        // Sort files
        sort(files[i].begin(), files[i].end());

        // Output filenames
        cout << prefixes[i] << endl;
        for (const auto& f : files[i])
            cout << "* "  << f << endl;

        string name = prefixes[i] + ".pvtu";

        pugi::xml_document doc;

        auto declarationNode = doc.append_child(pugi::node_declaration);
        declarationNode.append_attribute("version")    = "1.0";

        //Header
        auto root = doc.append_child("VTKFile");
        root.append_attribute("type")    = "PUnstructuredGrid";
        root.append_attribute("version") = "0.1";
        root.append_attribute("byte_order") = "LittleEndian";
        root.append_attribute("compressor") = "vtkZLibDataCompressor";

        auto grid = root.append_child("PUnstructuredGrid");
        grid.append_attribute("GhostLevel") = "0";

        //Point data
        auto ppointdata = grid.append_child("PPointData");
        for (const auto& dataName : dataArray.first)
        {
            auto pdataArray1 = ppointdata.append_child("PDataArray");
            pdataArray1.append_attribute("type") = "Float64";
            pdataArray1.append_attribute("Name") = dataName.c_str();
        }

        //Cell data
        auto pcelldata = grid.append_child("PCellData");
        for (const auto& dataName : dataArray.second)
        {
            auto pcellArray1 = pcelldata.append_child("PDataArray");
            pcellArray1.append_attribute("type") = "Float64";
            pcellArray1.append_attribute("Name") = dataName.c_str();
        }

        //Points (mesh?)
        auto ppoints = grid.append_child("PPoints");
        auto pdataArray2 = ppoints.append_child("PDataArray");
        pdataArray2.append_attribute("type") = "Float64";
        pdataArray2.append_attribute("NumberOfComponents") = "3";

        //Files (vtus)
        for (const auto& f : files[i])
        {
            auto piece = grid.append_child("Piece");
            piece.append_attribute("Source") = f.c_str();
        }

        //End
        bool saveSucceeded = doc.save_file(name.c_str(), PUGIXML_TEXT("  "));
        assert(saveSucceeded);
    }

    return 0;
}

int generatePvd(const string& pathFiles)
{
    // Store pvtu prefixes and vtu file names
    vector<string> prefixes;
    vector<string> files;
    vector<double> times;
    string namepref;
    for (filesystem::recursive_directory_iterator end, dir(pathFiles);
        dir != end; ++dir)
    {
        //Check
        if (!PostProc::ends_with(dir->path().string(), ".pvtu"))
            continue;

        //Save names
        string fileName = dir->path().string();
        string prefix = fileName.substr(0, fileName.find_last_of('.'));
        namepref = prefix.substr(0, prefix.find_last_of('.'));

        //Store them in a vector
        auto iter = find(prefixes.begin(), prefixes.end(), prefix);
        if (iter == prefixes.end())
        {
            prefixes.push_back(prefix);
            files.push_back(fileName);
        }
        else
        {
            auto posPref = std::distance(prefixes.begin(), iter);
            files[posPref]= fileName;
        }

        //Get times
        string timestep = prefix.substr(prefix.find_last_of('.')+1);
        vtkSmartPointer<vtkXMLUnstructuredGridReader> reader =
            vtkSmartPointer<vtkXMLUnstructuredGridReader>::New();
        string fvtu = namepref + "." + timestep + ".0.vtu";
        reader->SetFileName(fvtu.c_str());
        reader->Update();
        double time{-1.0};
        if (reader->GetOutput()->GetFieldData()->GetArray("Time") != nullptr)
            time = reader->GetOutput()->GetFieldData()->GetArray("Time")->GetTuple1(0);

        if (time != -1.0)
        {
            times.push_back(time);
        }
        else
        {
            times.push_back(stod(timestep));
        }
    }

    // Sort vectors
    map<double, string> map;
    for (auto i = 0u; i < files.size(); i++)
        map.insert(std::pair<double,string>(times[i], files[i]));
    times.clear();
    files.clear();
    for (const auto& m: map)
    {
        times.push_back(m.first);
        files.push_back(m.second);
    }

    //Main doc
    pugi::xml_document doc;
    auto declarationNode = doc.append_child(pugi::node_declaration);
    declarationNode.append_attribute("version")    = "1.0";

    //Header
    auto root = doc.append_child("VTKFile");
    root.append_attribute("type")    = "Collection";
    root.append_attribute("version") = "0.1";
    root.append_attribute("byte_order") = "LittleEndian";
    root.append_attribute("compressor") = "vtkZLibDataCompressor";

    //Append files (vtus)
    auto grid = root.append_child("Collection");
    for (auto i = 0u; i < files.size(); i++)
    {
        auto piece = grid.append_child("DataSet");
        piece.append_attribute("timestep") = times[i];
        piece.append_attribute("file") = files[i].c_str();
    }

    //Save
    string name = namepref + ".pvd";
    bool saveSucceeded = doc.save_file(name.c_str(), PUGIXML_TEXT("  "));
    assert(saveSucceeded);

    return 0;
}


int main(int argc, char *argv[])
{

    MPI_Init(&argc, &argv);
    DistributedClass dis;

    //Terminal parameters
    Teuchos::CommandLineProcessor parser;

    //Help
    parser.setDocString("This executable takes files in hplfe parallel output format and converts them to vtu ones.\n");

    //Path to folder
    string dirHPLFEFiles;
    dirHPLFEFiles.assign(".");
    parser.setOption("pathInFiles", &dirHPLFEFiles, "Path to the input files.");
    bool overwrite = false;
    parser.setOption("no-overwrite","overwrite",
                     &overwrite,"Overwrite existing vtu files.");

    //Read parameters
    Teuchos::CommandLineProcessor::EParseCommandLineReturn
        parseReturn= parser.parse(argc, argv);

    //Print help
    if (parseReturn == Teuchos::CommandLineProcessor::PARSE_HELP_PRINTED)
    {
        MPI_Finalize();
        return 0;
    }

    //Check parameters
    if (parseReturn != Teuchos::CommandLineProcessor::PARSE_SUCCESSFUL)
    {
        MPI_Finalize();
        return 0;
    }

    //Check directory
    if (!filesystem::is_directory(filesystem::status(dirHPLFEFiles)))
    {
        cout << "The path introduced: " + dirHPLFEFiles + " does not contain a valid directory." << endl;
        parser.printHelpMessage(argv[0], cout);
        MPI_Finalize();
        return 0;
    }

    //Generate all vtus
    pair<vector<string>, vector<string>> dataArrays = generateAllVtu(dirHPLFEFiles, overwrite);

    //Generate pvtus
    if (dis.myRank() == 0)
        generatePvtu(dirHPLFEFiles, dataArrays);

    //Generate pvds
    if (dis.myRank() == 0)
        generatePvd(dirHPLFEFiles);

    //End
    MPI_Finalize();
    return 0;
}
