/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef AUX_POSTPROC_H
#define AUX_POSTPROC_H


#include <vector>
#include <string>
#include <utility>

namespace hiperlife::PostProc
{
    bool replace(std::string& str, const std::string& from, const std::string& to);
    std::vector<std::pair<std::string, int>> readPrefixes(const std::string& pathInFiles);
    std::string genLegOutName(const std::string &outFile, int step);

    bool ends_with(std::string const &str, std::string const &suffix);

}


#endif
