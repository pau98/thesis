/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <algorithm>
#include <filesystem>
#include <mpi.h>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include <Teuchos_RCP.hpp>

using namespace std;

using Teuchos::rcp;
using Teuchos::RCP;

namespace hiperlife
{
    namespace PostProc
    {

        bool replace(std::string& str, const std::string& from, const std::string& to)
        {
            size_t start_pos = str.find(from);

            if(start_pos == std::string::npos)
                return false;

            str.replace(start_pos, from.length(), to);

            return true;
        }

        vector<pair<string, int>> readPrefixes(const string& pathInFiles)
        {
            filesystem::path p(pathInFiles);
            filesystem::path dir = p.parent_path();

            string prefix = pathInFiles.substr(0, pathInFiles.find("$"));
            string end = pathInFiles.substr(pathInFiles.find('*') + 1);
            replace(end.begin(), end.end(), '$', '0');

            string start;
            bool oneFile;
            if (pathInFiles.find('*') == string::npos)
            {
                oneFile = true;
                start = pathInFiles.substr(0, pathInFiles.find('$'));
            }
            else
            {
                oneFile = false;
                start = pathInFiles.substr(0, pathInFiles.find('*'));
            }

            set<pair<string, int>> prefixes;

            for (filesystem::directory_iterator itr(dir); itr!=filesystem::directory_iterator(); ++itr)
            {

                auto str = itr->path().string();
                auto sB = str.find(start);

                if (sB == string::npos)
                    continue;

                int step{};
                string prefixStep = prefix;

                if (!oneFile)
                {
                    stringstream strS(str.substr(sB + start.size()));
                    strS >> step;
                    replace(prefixStep, "*", to_string(step));
                }

                prefixes.emplace(prefixStep, step);
            }

            vector<pair<string, int>> vec_prefixes;
            for (const auto& pp : prefixes)
                vec_prefixes.push_back(pp);

            return vec_prefixes;

        }

        string genLegOutName(const std::string& outFile, int step)
        {

            if (outFile.find('*') == string::npos)
                return outFile;

            string retStr = outFile;
            replace(retStr, "*", to_string(step));

            return retStr;
        }

        bool ends_with(std::string const &str, std::string const &suffix) {
            if (str.length() < suffix.length()) {
                return false;
            }
            return str.compare(str.length() - suffix.length(), suffix.length(), suffix) == 0;
        }

    }
}
