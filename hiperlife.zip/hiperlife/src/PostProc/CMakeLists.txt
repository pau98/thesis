#------------------------------------------------------------
# Source files for HiPerLIFE PostProc
#------------------------------------------------------------
file(GLOB SOURCES_H hl_*.h)
file(GLOB SOURCES_CPP hl_PostProc.cpp hl_VtkGrid.cpp)
file(GLOB EXEC_FILES hl_PP_*.cpp)
set(SOURCE_FILES ${SOURCES_H} ${SOURCES_CPP})

# Load vtk
if(VTK_FOUND)
    if(VTK_DOWNLOADING)
        include_directories(${VTK_INCLUDE_DIRS})
        message(STATUS "Waiting for VTK")
    endif(VTK_DOWNLOADING)
else()
  message(STATUS "Warning!! Vtk is not in the system. PostProc module is disabled.")
  return()
endif(VTK_FOUND)

#Save PostProc as a library
set(LIBNAME hlPostProc)
add_library(${LIBNAME} ${SOURCE_FILES})
target_link_libraries(${LIBNAME} ${MPI_LIB})
target_link_libraries(${LIBNAME} ${Trilinos_LIBRARIES})
if(VTK_FOUND)
    if(VTK_DOWNLOADING)
        add_dependencies(${LIBNAME} VTK)
        target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
    else(VTK_DOWNLOADING)
        target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
    endif(VTK_DOWNLOADING)
endif()

target_link_libraries(${LIBNAME} ${HPLFE_LIBRARIES})
install(TARGETS ${LIBNAME} DESTINATION lib EXPORT hiperlifeTargets)
install(FILES ${SOURCES_H} DESTINATION include)
set(HPLFE_LIBRARIES ${HPLFE_LIBRARIES} ${LIBNAME} CACHE INTERNAL "HPLFE_LIBRARIES")

#Executables
message(STATUS "Configuring PostProc")
foreach(source ${EXEC_FILES})
    # I used a simple string replace, to cut off .cpp.
    get_filename_component(name ${source} NAME)
    string(REPLACE ".cpp" "" name ${name})

    set(EXECNAME ${name})

    add_executable(${EXECNAME} ${source})

    target_link_libraries(${EXECNAME} ${MPI_LIB})
    if(VTK_FOUND)
        if(VTK_DOWNLOADING)
            add_dependencies(${EXECNAME} VTK)
            target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
        else(VTK_DOWNLOADING)
            target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
        endif(VTK_DOWNLOADING)
    endif()

    target_link_libraries(${EXECNAME} ${Trilinos_LIBRARIES})
    target_link_libraries(${EXECNAME} hlPostProc)

    install(TARGETS ${EXECNAME} DESTINATION bin)
endforeach(source ${EXEC_FILES})
