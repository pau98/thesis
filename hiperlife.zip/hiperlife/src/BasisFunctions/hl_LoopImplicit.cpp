/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <cmath>
#include <vector>
#include <string>

#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_LoopImplicit.h"
#include "hl_TypeDefs.h"


using namespace std;

namespace hiperlife
{
    // Default constructor
    LoopImplicit :: LoopImplicit()
    {
        //input
        _eval          = 0;
        _eigenFlag     = true;

        //auxiliary
        _pickingMat  = nullptr;
        _subDivMat   = nullptr;
        _Aaux1       = nullptr;
        _Aaux2       = nullptr;
        _Paux1       = nullptr;


        _ssEigenStruct.eigenval      = nullptr;
        _ssEigenStruct.Ieigenvec     = nullptr;
        _ssEigenStruct.Phi[0]        = nullptr;
        _ssEigenStruct.Phi[1]        = nullptr;
        _ssEigenStruct.Phi[2]        = nullptr;
    }

    LoopImplicit  :: ~LoopImplicit()
    {
        _clear();
    }


    // -------------------------------------------------------------------------------------
    // -------------------------------------------------------------------------------------
    void LoopImplicit::Update()
    {

        _checkSettings();

        //------------------------------------------------------------------------------------
        if ( _eval != 6 )
        {
            if ( _eigenFlag )
            {
                _setEigenStructureValence ( );
                _allocateAuxiliaryEigen   ( );
            }
            else
                _allocateAuxiliaryNoEigen ( );
        }

        return;
    }
    // -------------------------------------------------------------------------------------
    // -------------------------------------------------------------------------------------

    int LoopImplicit::_checkSettings()
    {
        using namespace std;

        if (_eval < 3 || _eval > 12)
            throw runtime_error("ERROR::Valence to each element is not/bad set 2<_eval=" + to_string(_eval) + "<13)");

        _clear();

        //All is OK
        return 0;
    }


    void LoopImplicit::_clear()
    {
        if( _eval != 6)
        {
            if ( _eigenFlag )
                _clearAuxiliaryEigen  ();
            else
                _clearAuxiliaryNoEigen();
        }
    }


    void LoopImplicit::_allocateAuxiliaryNoEigen ()
    {
        int i;

        // Allocate the matrices and initialize
        _pickingMat = new double *[12];
        _subDivMat  = new double *[_eval+12];
        _Paux1       = new double *[12];
        _Aaux1       = new double *[_eval+12];
        _Aaux2       = new double *[_eval+12];


        // allocate rows and set pointers to them
        _pickingMat  [0] = new double [12 * (_eval+12)];
        _subDivMat  [0] = new double [(_eval+12) * (_eval+12)];
        _Paux1 [0] = new double [12 *( _eval+12)];
        _Aaux1 [0] = new double [(_eval+12) * (_eval+12)];
        _Aaux2 [0] = new double [(_eval+12) * (_eval+12)];

        for ( i = 1; i<12; i++ )
        {
            _pickingMat [i] = _pickingMat [0] + i * (_eval+12);
            _Paux1[i] = _Paux1[0] + i * (_eval+12);
        }

        for ( i = 1; i<(_eval+12); i++ )
        {
            _subDivMat [i] = _subDivMat [0] + i * (_eval+12);
            _Aaux1[i] = _Aaux1[0] + i * (_eval+12);
            _Aaux2[i] = _Aaux2[0] + i * (_eval+12);
        }




    }

    void LoopImplicit::_allocateAuxiliaryEigen   ()
    {
        int i;

        // Allocate the matrices and initialize
        _pickingMat = new double *[12];
        _Paux1       = new double *[12];
        _Aaux1       = new double *[_eval+12];


        // allocate rows and set pointers to them
        _pickingMat  [0] = new double [12 * (_eval+6)];
        _Paux1 [0] = new double [12 *( _eval+6)];

        _Aaux1 [0] = new double [(_eval+12) * (_eval+12)];

        for ( i = 1; i<12; i++ )
        {
            _pickingMat [i] = _pickingMat [0] + i * (_eval+6);
            _Paux1[i] = _Paux1[0] + i * (_eval+6);
        }

        for ( i = 1; i<(_eval+12); i++ )
        {
            _Aaux1[i] = _Aaux1[0] + i * (_eval+12);
        }

    }
    void LoopImplicit::_clearAuxiliaryNoEigen ( )
    {
        if ( _subDivMat != nullptr )
        {
            delete [] _subDivMat[0];
            delete [] _subDivMat;
        }

        if ( _pickingMat != nullptr )
        {
            delete [] _pickingMat[0];
            delete [] _pickingMat;
        }
        if ( _Aaux1 != nullptr )
        {
            delete [] _Aaux1[0];
            delete [] _Aaux1;
        }
        if ( _Aaux2 != nullptr )
        {
            delete [] _Aaux2[0];
            delete [] _Aaux2;
        }
        if ( _Paux1 != nullptr )
        {
            delete [] _Paux1[0];
            delete [] _Paux1;
        }

        // dealocate temporary arrays
        _pickingMat  = nullptr;
        _subDivMat   = nullptr;
        _Aaux1        = nullptr;
        _Aaux2        = nullptr;
        _Paux1        = nullptr;

    }
    void LoopImplicit::_clearAuxiliaryEigen      ()
    {
        if (_ssEigenStruct.eigenval   != nullptr)
            delete []  _ssEigenStruct.eigenval;
        if (_ssEigenStruct.Ieigenvec  != nullptr)
            delete []  _ssEigenStruct.Ieigenvec;
        if (_ssEigenStruct.Phi[0]     != nullptr)
            delete []  _ssEigenStruct.Phi[0];
        if (_ssEigenStruct.Phi[1]     != nullptr)
            delete []  _ssEigenStruct.Phi[1];
        if (_ssEigenStruct.Phi[2]     != nullptr)
            delete []  _ssEigenStruct.Phi[2];

        _ssEigenStruct.eigenval      = nullptr;
        _ssEigenStruct.Ieigenvec     = nullptr;
        _ssEigenStruct.Phi[0]        = nullptr;
        _ssEigenStruct.Phi[1]        = nullptr;
        _ssEigenStruct.Phi[2]        = nullptr;

        if ( _pickingMat != nullptr )
        {
            delete [] _pickingMat[0];
            delete [] _pickingMat;
        }

        if ( _Paux1 != nullptr )
        {
            delete [] _Paux1[0];
            delete [] _Paux1;
        }
        if ( _Aaux1 != nullptr )
        {
            delete [] _Aaux1[0];
            delete [] _Aaux1;
        }
        // dealocate temporary arrays
        _pickingMat  = nullptr;
        _Paux1       = nullptr;
        _Aaux1       = nullptr;
    }

    void LoopImplicit::ComputeBasisFunctions (std::vector< std::vector<double> >& bf, double v, double w)
    {

#ifdef DEBUG
        if ( v>1.0 || v<0.0 )
        {
            throw runtime_error("ERROR::LoopImplicit::SubDivOneSample: A barycentric coordinate of the sample point is ill defined, " + to_string(v));
        }

        if ( w>1.0 || w< 0.0 )
        {
            throw runtime_error("ERROR::LoopImplicit::SubDivOneSample: A barycentric coordinate of the sample point is ill defined, " + to_string(w));
        }
#endif

        bf.resize(3);

        bf[0].resize(_eval+6);
        bf[1].resize((_eval+6)*2);
        bf[2].resize((_eval+6)*4);

        if ( _eval == 6 )
            _basisFunDerReg  (v, w, bf[0].data(), bf[1].data(), bf[2].data() );
        else
        {
                if ( _eigenFlag )
                    _basisFunDerIrregEigen   (v, w, bf[0].data(), bf[1].data(), bf[2].data() );
                else
                    _basisFunDerIrregNoEigen (v, w, bf[0].data(), bf[1].data(), bf[2].data() );
        }

        return;
    }

    // evaluate the first and second order derivatives of the
    // surface at any point (v,w)
    void LoopImplicit::
    _basisFunDerReg   (double v, double w, double *p_k, double *dp_k, double *hp_k )
    {
        int i, j;
        int jj[4]={0,2,2,1};  //for hessian copy
        double shap[12], shap1dr[2][12],  shap2dr[3][12];

        // evaluate shape functions for reg. mesh
        _boxSplinesFun(v,w,shap);

        p_k[0] = shap[3];   p_k[1] = shap[6];
        p_k[2] = shap[2];   p_k[3] = shap[0];
        p_k[4] = shap[1];   p_k[5] = shap[4];
        p_k[6] = shap[7];   p_k[7] = shap[10];
        p_k[8] = shap[9];   p_k[9] = shap[5];
        p_k[10]= shap[11];  p_k[11]= shap[8];

        // first order shape function derivatives for reg. mesh
        _boxSplinesDer (v, w, shap1dr);

        for (i=0; i<2; i++)
        {
            dp_k[i+2*0] = shap1dr[i][3];     dp_k[i+2*1] = shap1dr[i][6];
            dp_k[i+2*2] = shap1dr[i][2];     dp_k[i+2*3] = shap1dr[i][0];
            dp_k[i+2*4] = shap1dr[i][1];     dp_k[i+2*5] = shap1dr[i][4];
            dp_k[i+2*6] = shap1dr[i][7];     dp_k[i+2*7] = shap1dr[i][10];
            dp_k[i+2*8] = shap1dr[i][9];     dp_k[i+2*9] = shap1dr[i][5];
            dp_k[i+2*10]= shap1dr[i][11];    dp_k[i+2*11]= shap1dr[i][8];
        }

        // second order shape function derivatives for reg. mesh
        _boxSplinesHes (v, w, shap2dr);

        for (i=0; i<4; i++)
        {
            j = jj[i];
            hp_k[i+4*0] = shap2dr[j][3];     hp_k[i+4*1] = shap2dr[j][6];
            hp_k[i+4*2] = shap2dr[j][2];     hp_k[i+4*3] = shap2dr[j][0];
            hp_k[i+4*4] = shap2dr[j][1];     hp_k[i+4*5] = shap2dr[j][4];
            hp_k[i+4*6] = shap2dr[j][7];     hp_k[i+4*7] = shap2dr[j][10];
            hp_k[i+4*8] = shap2dr[j][9];     hp_k[i+4*9] = shap2dr[j][5];
            hp_k[i+4*10]= shap2dr[j][11];    hp_k[i+4*11]= shap2dr[j][8];
        }

        return;
    }



    void LoopImplicit::
    _basisFunDerIrregNoEigen (double v, double w, double *p_k, double *dp_k, double *hp_k)
    {

        int i,j;
        int    na, potenz;
        double jfac, u, pow2, min, max;
        double shap[12], shap1dr[2][12],  shap2dr[3][12];
        double sum_shape, sum_derx, sum_dery, sum_hessxx, sum_hessxy, sum_hessyy;

        u   = 1.0 - w - v;

        if ( abs(u-1.0) < _eps )
        {
            _basisFunctionsDerNode0  (p_k, dp_k, hp_k );
            return;
        }

        // evaluate the number of the required subdivisions ----------------------------------
        na  = 0;
        min = 0.0;
        max = 0.5;

        Array::Fill(_pickingMat[0], 12* (_eval+12), 0.0);
        Array::Fill(_subDivMat[0], (_eval+12)*(_eval+12), 0.0);

        while ( !((u>(min-_eps)) && (u<(max+_eps))) )
        {
            ++na;
            min  = max;
            max += pow(2.0,-na-1);
        }

        //barycentric coordinates after subdivision
        potenz = na+1;
        pow2   = pow(2.0, na);
        v     *= pow2;
        w     *= pow2;
        u      = 1.0 - v - w;

        //check new barycentric coordinates
        assert( (u<(0.5+_eps)) && (u>-_eps) );

        jfac = pow(2.0, na+1);
        // coordinate transformation ---------------------------------------------------------
        if (v > (0.5-_eps))
        {
            v    = 2.0*v - 1.0;
            w    = 2.0*w;
            _pickmtrx1();  //subpatch one contains the coordinates (v,w)
        }
        else if (w >(0.5-_eps))
        {
            v    = 2.0*v;
            w    = 2.0*w - 1.0;
            _pickmtrx3();  //subpatch three contains the coordinates (v,w)
        }
        else
        {
            v    = 1.0 - 2.0*v;
            w    = 1.0 - 2.0*w;
            _pickmtrx2();  //subpatch two contains the coordinates (v,w)
            jfac *= -1.0;
        }
        u    = 1.0 - v - w;

        //check new barycentric coordinates
        assert((u<(1.0+_eps))&&(u>-_eps));

        // allocate space for the subdivision matrix -----------------------------------------
        //create A and fill with s12 and s22
        _composesubmA ();

        // compute P=P*power(A,n)
        _subpowerA( potenz );

        // evaluate shape functions for reg. mesh
        _boxSplinesFun (v, w, shap);

        // first order shape function derivatives for reg. mesh
        _boxSplinesDer (v, w, shap1dr);

        // second order shape function derivatives for reg. mesh
        _boxSplinesHes (v, w, shap2dr);

        // compute the shape function values for irregular mesh (compute (P*A^n)*Co)
        for (j=0; j<(_eval+6); j++)
        {

            sum_shape  = 0.0;
            sum_derx   = 0.0;
            sum_dery   = 0.0;
            sum_hessxx = 0.0;
            sum_hessyy = 0.0;
            sum_hessxy = 0.0;

            for (i=0; i<12; i++)
            {
                sum_shape   += _pickingMat[i][j]*shap[i];
                sum_derx    += _pickingMat[i][j]*shap1dr[0][i];
                sum_dery    += _pickingMat[i][j]*shap1dr[1][i];
                sum_hessxx  += _pickingMat[i][j]*shap2dr[0][i];
                sum_hessyy  += _pickingMat[i][j]*shap2dr[1][i];
                sum_hessxy  += _pickingMat[i][j]*shap2dr[2][i];
            }

            p_k [j]     =  sum_shape;
            dp_k[j*2+0] =  sum_derx*jfac;
            dp_k[j*2+1] =  sum_dery*jfac;
            hp_k[j*4+0] =  sum_hessxx*jfac*jfac;
            hp_k[j*4+1] =  sum_hessxy*jfac*jfac;
            hp_k[j*4+2] =  sum_hessxy*jfac*jfac;
            hp_k[j*4+3] =  sum_hessyy*jfac*jfac;
        }

        return;
    }

    void LoopImplicit::
    _basisFunDerIrregEigen   (double v, double w, double *p_k, double *dp_k, double *hp_k)
    {

        int i,j;
        int    na, potenz;
        double jfac, u, pow2, min, max;
        double shap[12], shap1dr[2][12],  shap2dr[3][12];
        double sum_shape, sum_derx, sum_dery, sum_hessxx, sum_hessxy, sum_hessyy;
        double product1;


        u   = 1.0 - w - v;
        if ( abs(u-1.0) < _eps )
        {
            _basisFunctionsDerNode0  ( p_k, dp_k, hp_k );
            return;
        }
        // evaluate the number of the required subdivisions ----------------------------------

        na  = 0;
        min = 0.0;
        max = 0.5;

        Array::Fill(_pickingMat [0], 12* (_eval+6), 0.0);
        Array::Fill(_Paux1[0],12* (_eval+6), 0.0);

        Array::Fill(_Aaux1[0], (_eval+12)*(_eval+12), 0.0);


        while ( !((u>(min-_eps)) && (u<(max+_eps))) )
        {
            ++na;
            min  = max;
            max += pow(2.0,-na-1);
        }

        //barycentric coordinates after subdivision
        potenz = na+1;
        pow2   = pow(2.0, na);
        v     *= pow2;
        w     *= pow2;
        u      = 1.0 - v - w;

        //check new barycentric coordinates
        assert( (u<(0.5+_eps)) && (u>-_eps) );

        // coordinate transformation ---------------------------------------------------------
        jfac = pow(2.0, na+1);
        if (v > (0.5-_eps))
        {
            v    = 2.0*v - 1.0;
            w    = 2.0*w;
            Math::AXPY(_Paux1[0] , 12 * (_eval+6),1.0,_ssEigenStruct.Phi[0]);
        }
        else if (w >(0.5-_eps))
        {
            v    = 2.0*v;
            w    = 2.0*w - 1.0;
            Math::AXPY(_Paux1[0], 12 * (_eval+6),1.0,_ssEigenStruct.Phi[2] );
        }
        else
        {
            v    = 1.0 - 2.0*v;
            w    = 1.0 - 2.0*w;
            Math::AXPY(_Paux1[0], 12 * (_eval+6),1.0,_ssEigenStruct.Phi[1]);
            jfac *= -1.0;
        }

        u    = 1.0 - v - w;

        //check new barycentric coordinates
        assert((u<(1.0+_eps))&&(u>-_eps));

        for ( i=0; i < _eval+6; i++ )
        {
            product1 = 1.0;

            for (j=0; j<potenz-1; j++ )
            {
                product1 = product1 * _ssEigenStruct.eigenval[i];
            }

            for ( j=0; j < 12; j++ )
                _Paux1[j][i] = _Paux1[j][i]*product1;
        }

        Math::MatTranspo ( _Aaux1[0], (_eval+6), (_eval+6), _ssEigenStruct.Ieigenvec );

        Math::MatProduct(_pickingMat[0], 12,(_eval+6),(_eval+6),_Paux1[0],_Aaux1[0]);

        // evaluate shape functions for reg. mesh
        _boxSplinesFun (v, w, shap);

        // first order shape function derivatives for reg. mesh
        _boxSplinesDer (v, w, shap1dr);

        // second order shape function derivatives for reg. mesh
        _boxSplinesHes (v, w, shap2dr);


        // compute the shape function values for irregular mesh (compute (P*A^n)*Co)
        for (j=0; j<(_eval+6); j++)
        {

            sum_shape  = 0.0;
            sum_derx   = 0.0;
            sum_dery   = 0.0;
            sum_hessxx = 0.0;
            sum_hessyy = 0.0;
            sum_hessxy = 0.0;


            for (i=0; i<12; i++)
            {
                sum_shape   += _pickingMat[i][j]*shap[i];
                sum_derx    += _pickingMat[i][j]*shap1dr[0][i];
                sum_dery    += _pickingMat[i][j]*shap1dr[1][i];
                sum_hessxx  += _pickingMat[i][j]*shap2dr[0][i];
                sum_hessyy  += _pickingMat[i][j]*shap2dr[1][i];
                sum_hessxy  += _pickingMat[i][j]*shap2dr[2][i];
            }

            p_k [j]     =  sum_shape;
            dp_k[j*2+0] =  sum_derx*jfac;
            dp_k[j*2+1] =  sum_dery*jfac;
            hp_k[j*4+0] =  sum_hessxx*jfac*jfac;
            hp_k[j*4+1] =  sum_hessxy*jfac*jfac;
            hp_k[j*4+2] =  sum_hessxy*jfac*jfac;
            hp_k[j*4+3] =  sum_hessyy*jfac*jfac;
        }

        return;
    }

    // ---------------------------------------------------------------------------------------
    // box spline shape functions
    void LoopImplicit::_boxSplinesFun (double v, double w, double x[12])
    {
        double u;

        u=1.0-v-w;

        x[0]=(u*u*u*u+2.0*u*u*u*v)/12.0;

        x[1]=(u*u*u*u+2.0*u*u*u*w)/12.0;

        x[2]=(u*u*u*u+2.0*u*u*u*w+6.0*u*u*u*v+6.0*u*u*v*w+
                12.0*u*u*v*v+6.0*u*v*v*w+6.0*u*v*v*v+2.0*v*v*v*w+
                v*v*v*v)/12.0;

        x[3]=(6.0*u*u*u*u+24.0*u*u*u*w+24.0*u*u*w*w+8.0*u*w*w*w+
                w*w*w*w+24.0*u*u*u*v+60.0*u*u*v*w+36.0*u*v*w*w+
                6.0*v*w*w*w+24.0*u*u*v*v+36.0*u*v*v*w+12.0*v*v*w*w+
                8.0*u*v*v*v+6.0*v*v*v*w+v*v*v*v)/12.0;

        x[4]=(u*u*u*u+6.0*u*u*u*w+12.0*u*u*w*w+6.0*u*w*w*w+
                w*w*w*w+2.0*u*u*u*v+6.0*u*u*v*w+6.0*u*v*w*w+
                2.0*v*w*w*w)/12.0;

        x[5]=(2.0*u*v*v*v+v*v*v*v)/12.0;

        x[6]=(u*u*u*u+6.0*u*u*u*w+12.0*u*u*w*w+
                6.0*u*w*w*w+w*w*w*w+8.0*u*u*u*v+36.0*u*u*v*w+
                36.0*u*v*w*w+8.0*v*w*w*w+24.0*u*u*v*v+60.0*u*v*v*w+
                24.0*v*v*w*w+24.0*u*v*v*v+24.0*v*v*v*w+
                6.0*v*v*v*v)/12.0;

        x[7]=(u*u*u*u+8.0*u*u*u*w+24.0*u*u*w*w+24.0*u*w*w*w+
                6.0*w*w*w*w+6.0*u*u*u*v+36.0*u*u*v*w+60.0*u*v*w*w+
                24.0*v*w*w*w+12.0*u*u*v*v+36.0*u*v*v*w+
                24.0*v*v*w*w+6.0*u*v*v*v+8.0*v*v*v*w+v*v*v*v)/12;

        x[8] =(2.0*u*w*w*w+w*w*w*w)/12.0;

        x[9]=(2.0*v*v*v*w+v*v*v*v)/12.0;


        x[10]=(2.0*u*w*w*w+w*w*w*w+6.0*u*v*w*w+6.0*v*w*w*w+
                6.0*u*v*v*w+12.0*v*v*w*w+2.0*u*v*v*v+
                6.0*v*v*v*w+v*v*v*v)/12.0;

        x[11]=(w*w*w*w+2.0*v*w*w*w)/12.0;

        return;
    }


    // first order derivatives of the box spline shape functions
    // der[0][node] derivative with respect to v
    // der[1][node] derivative with respect to w
    void LoopImplicit::_boxSplinesDer (double v, double w, double der1[2][12])
    {
        double u;

        u=1.0-v-w;

        der1[0][0] = (-6.0*v*pow(u,2.0) - 2.0*pow(u,3.0))/12.0;
        der1[1][0] = (-6.0*v*pow(u,2.0) - 4.0*pow(u,3.0))/12.0;

        der1[0][1] = (-4.0*pow(u,3.0)-6.0*pow(u,2.0)*w)/12.0;
        der1[1][1] = (-2.0*pow(u,3.0)-6.0*pow(u,2.0)*w)/12.0;

        der1[0][2] = (-2.0*pow(v,3.0)-6.0*pow(v,2.0)*u
                    + 6.0*v*pow(u,2.0)+2.0*pow(u,3.0))/12.0;
        der1[1][2] = (-4.0*pow(v,3.0)-18.0*pow(v,2.0)*u
                    - 12.0*v*pow(u,2.0)-2.0*pow(u,3.0)
                    - 6.0*pow(v,2.0)*w-12.0*v*u*w
                    - 6.0*pow(u,2.0)*w)/12.0;

        der1[0][3] = (-4.0*pow(v,3.0)-24.0*pow(v,2.0)*u
                    - 24.0*v*pow(u,2.0)-18.0*pow(v,2.0)*w
                    - 48.0*v*u*w-12.0*pow(u,2.0)*w
                    - 12.0*v*pow(w,2.0) - 12.0*u*pow(w,2.0)
                    - 2.0*pow(w,3.0))/12.0;

        der1[1][3] = (-2.0*pow(v,3.0)-12.0*pow(v,2.0)*u
                    - 12.0*v*pow(u,2.0)-12.0*pow(v,2.0)*w
                    - 48.0*v*u*w-24.0*pow(u,2.0)*w
                    - 18.0*v*pow(w,2.0)-24.0*u*pow(w,2.0)
                    - 4.0*pow(w,3.0))/12.0;

        der1[0][4] = (-6.0*v*pow(u,2.0)-2.0*pow(u,3.0)
                    - 12.0*v*u*w-12.0*pow(u,2.0)*w
                    - 6.0*v*pow(w,2.0)-18.0*u*pow(w,2.0)
                    - 4.0*pow(w,3.0))/12.0;

        der1[1][4] = (2.0*pow(u,3.0)+6.0*pow(u,2.0)*w
                    - 6.0*u*pow(w,2.0)-2.0*pow(w,3.0))/12.0;

        der1[0][5] = (2.0*pow(v,3.0)+6.0*pow(v,2.0)*u)/12.0;
        der1[1][5] = -pow(v,3.0)/6.0;

        der1[0][6] = (24.0*pow(v,2.0)*u+24.0*v*pow(u,2.0)
                    + 4.0*pow(u,3.0)+12.0*pow(v,2.0)*w
                    + 48.0*v*u*w+18.0*pow(u,2.0)*w
                    + 12.0*v*pow(w,2.0)+12.0*u*pow(w,2.0)
                    + 2.0*pow(w,3.0))/12.0;

        der1[1][6] = (12.0*pow(v,2.0)*u+12.0*v*pow(u,2.0)
                    + 2.0*pow(u,3.0)-12.0*pow(v,2.0)*w
                    + 6.0*pow(u,2.0)*w-12.0*v*pow(w,2.0)
                    - 6.0*u*pow(w,2.0)-2.0*pow(w,3.0))/12.0;

        der1[0][7] = (-2.0*pow(v,3.0)-6.0*pow(v,2.0)*u
                    + 6.0*v*pow(u,2.0)+2.0*pow(u,3.0)
                    - 12.0*pow(v,2.0)*w+12.0*pow(u,2.0)*w
                    - 12.0*v*pow(w,2.0)+12.0*(1.0-v-w)*pow(w,2.0))/12.0;

        der1[1][7] = (2.0*pow(v,3.0)+12.0*pow(v,2.0)*u
                    + 18.0*v*pow(u,2.0)+4.0*pow(u,3.0)
                    + 12.0*pow(v,2.0)*w+48.0*v*u*w
                    + 24.0*pow(u,2.0)*w+12.0*v*pow(w,2.0)
                    + 24.0*u*pow(w,2.0))/12.0;

        der1[0][8] = -pow(w,3.0)/6.0;
        der1[1][8] = (6.0*u*pow(w,2.0)+2.0*pow(w,3.0))/12.0;

        der1[0][9] = (4.0*pow(v,3.0)+6.0*pow(v,2.0)*w)/12.0;
        der1[1][9] = pow(v,3.0)/6.0;

        der1[0][10]= (2.0*pow(v,3.0)+6.0*pow(v,2.0)*u
                    + 12.0*pow(v,2.0)*w+12.0*v*u*w
                    + 18.0*v*pow(w,2.0)+6.0*u*pow(w,2.0)
                    + 4.0*pow(w,3.0))/12.0;

        der1[1][10]= (4.0*pow(v,3.0)+6.0*pow(v,2.0)*u
                    + 18.0*pow(v,2.0)*w+12.0*v*u*w
                    + 12.0*v*pow(w,2.0)+6.0*u*pow(w,2.0)
                    + 2.0*pow(w,3.0))/12.0;

        der1[0][11] = pow(w,3.0)/6.0;
        der1[1][11] = (6.0*v*pow(w,2.0)+4.0*pow(w,3.0))/12.0;

        return ;
    }


    // second order derivatives of the box spline shape functions
    // der[0][node] derivative with respect to vv
    // der[1][node] derivative with respect to ww
    // der[2][node] derivative with respect to vw
    void LoopImplicit::_boxSplinesHes (double v, double w, double der2[3][12])
    {
        double u;

        u = 1.0-v-w;

        der2[0][0] = v*u;
        der2[1][0] = v*u+pow(u,2.0);
        der2[2][0] = (12.0*v*u+6.0*pow(u,2.0))/12.0;

        der2[0][1] = pow(u,2.0)+u*w;
        der2[1][1] = u*w;
        der2[2][1] = (6.0*pow(u,2.0)+12.0*u*w)/12.0;

        der2[0][2] = -2.0*v*u;
        der2[1][2] = pow(v,2.0)+v*u+v*w+u*w;
        der2[2][2] = (6.0*pow(v,2.0)-12.0*v*u
                    -6.0*pow(u,2.0))/12.0;

        der2[0][3] = pow(v,2.0)-2.0*pow(u,2.0)
                    + v*w-2.0*u*w;
        der2[1][3] = -2.0*v*u-2.0*pow(u,2.0)
                    + v*w+pow(w,2.0);
        der2[2][3] = (6.0*pow(v,2.0)-12.0*pow(u,2.0)
                    + 24.0*v*w+6.0*pow(w,2.0))/12.0;

        der2[0][4] = v*u+v*w+u*w+ pow(w,2.0);
        der2[1][4] = -2.0*u*w;
        der2[2][4] = (-6.0*pow(u,2.0)-12.0*u*w
                    + 6.0*pow(w,2.0))/12.0;

        der2[0][5] = v*u;
        der2[1][5] = 0.0;
        der2[2][5] = -pow(v,2.0)/2.0;

        der2[0][6] = (-24.0*pow(v,2.0)+12.0*pow(u,2.0)-24.0*v*w
                    + 12.0*u*w)/12.0;
        der2[1][6] = (-24.0*pow(v,2.0)-24.0*v*u-24.0*v*w
                    - 24.0*u*w)/12.0;
        der2[2][6] = (-12.0*pow(v,2.0)+6.0*pow(u,2.0)-24.0*v*w
                    - 12.0*u*w-6.0*pow(w,2.0))/12.0;

        der2[0][7] = -2.0*v*u-2.0*v*w-2.0*u*w
                    - 2.0*pow(w,2.0);
        der2[1][7] = v*u+pow(u,2.0)-2.0*v*w
                    - 2.0*pow(w,2.0);
        der2[2][7] = (-6.0*pow(v,2.0)-12.0*v*u+6.0*pow(u,2.0)
                    - 24.0*v*w-12.0*pow(w,2.0))/12.0;

        der2[0][8] = 0.0;
        der2[1][8] = u*w;
        der2[2][8] = -pow(w,2.0)/2.0;

        der2[0][9] = (12.0*pow(v,2.0)+12.0*v*w)/12.0;
        der2[1][9] = 0.0;
        der2[2][9] = pow(v,2.0)/2.0;

        der2[0][10]= (12.0*v*u+12.0*v*w+12.0*u*w
                    + 12.0*pow(w,2.0))/12.0;
        der2[1][10]= pow(v,2.0)+v*u+v*w+u*w;
        der2[2][10]= (6.0*pow(v,2.0)+12.0*v*u+24.0*v*w
                    + 12.0*u*w+6.0*pow(w,2.0))/12.0;

        der2[0][11]= 0.0;
        der2[1][11]= v*w+pow(w,2.0);
        der2[2][11]= pow(w,2.0)/2.0;

        return;
    }

    // multiply subdivision matrix A n times with itself
    // and multiply with the picking-matrix
    void LoopImplicit::_subpowerA ( int npot )
    {
        int    i, j, m, n;
        double sum;

        Array::Copy(_Aaux1[0], (_eval+12)*(_eval+12),_subDivMat[0]);

        // Power of Amat to the npot
        for ( n = 1; n < npot; n++ )
        {
            // Ah1 = A * A^(n-1)
            for ( i = 0; i < _eval+12; i++ )
            {
                for ( j = 0; j < _eval+12; j++ )
                {
                    sum = 0.0;
                    for ( m = 0; m < _eval+12; m++ )
                        sum += _Aaux1[i][m]*_subDivMat[m][j];
                    _Aaux2[i][j] = sum;
                }
            }

            //update Ah = A^n
            Array::Copy(_Aaux1[0], (_eval+12)*(_eval+12), _Aaux2[0]);
        }

        // multiply with the pickingmatrix: Pm1 = P*A^n
        for ( i = 0; i < 12; i++ )
        {
            for ( j = 0; j < _eval+12; j++ )
            {
                sum = 0.0;
                for ( m = 0; m <_eval+12; m++ )
                    sum += _pickingMat[i][m]*_Aaux1[m][j];
                _Paux1[i][j] = sum;
            }
        }

        Array::Copy(_pickingMat[0], 12*(_eval+12), _Paux1[0]);

        return;
    }

    void  LoopImplicit::_basisFunctionsDerNode0 ( double *p_s, double *dp_s, double *hp_s )
    {
        int i;

        double N,l, ci, si;


        N = static_cast<double>(_eval);

        double subParam{};

        subParam  = (0.375+0.25*cos(2.0*M_PI/N));
        subParam *= (-subParam);
        subParam += 0.625;
        subParam /= N;

        l = 1.0/(3.0/(8.0*subParam)+N);

        p_s  [0] = 1.0-N*l;
        dp_s [0] = 0.0;
        dp_s [1] = 0.0;
        hp_s [0] = 0.0;
        hp_s [1] = 0.0;
        hp_s [2] = 0.0;
        hp_s [3] = 0.0;

        for ( i = 1; i < _eval+1; i ++)
        {
            ci = cos(2.0*M_PI*(i-1)/N);
            si = sin(2.0*M_PI*(i-1)/N);
            p_s [i]     = l;
            dp_s[2*i+0] = 2.0*si/N;
            dp_s[2*i+1] = 2.0*ci/N;
            hp_s[4*i+0] = 0.0;
            hp_s[4*i+1] = 0.0;
            hp_s[4*i+2] = 0.0;
            hp_s[4*i+3] = 0.0;
        }
        for ( i = _eval+1; i < _eval+6; i ++)
        {
            p_s [i]     = 0.0;
            dp_s[2*i+0] = 0.0;
            dp_s[2*i+1] = 0.0;
            hp_s[4*i+0] = 0.0;
            hp_s[4*i+1] = 0.0;
            hp_s[4*i+2] = 0.0;
            hp_s[4*i+3] = 0.0;
        }

    }

}
