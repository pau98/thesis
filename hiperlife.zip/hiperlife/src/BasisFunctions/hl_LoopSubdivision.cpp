/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>

#include "hl_LoopSubdivision.h"
#include "hl_AdjcyENStruct.h"
#include "hl_TypeDefs.h"



using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void LoopSubdivision::Update()
    {
        //Check inputs to the class
        _checkSettings ( );

        // Parent parameters
        _BFTags = rcp(new Epetra_IntVector(_adjcyEN->_adjcyElemNodes->RowMap()));
        _BFTags->PutValue(0);

        _computeImplicitTags();
        _orderDers = 2;

        _auxRefBF.resize(_orderDers+1);
        _auxEleBF.resize(_orderDers+1);

        int maxnBors = _adjcyEN->maxNumNbors();

        // Allocate space for the basis functions
        _auxRefBF[0].reserve(maxnBors);
        _auxRefBF[1].reserve(maxnBors * _pDim);
        _auxRefBF[2].reserve(maxnBors * _pDim * _pDim);
        _auxEleBF[0].reserve(maxnBors);
        _auxEleBF[1].reserve(maxnBors * _pDim);
        _auxEleBF[2].reserve(maxnBors * _pDim * _pDim);

        for ( int i = 0; i < _nImplicitTags; i++ )
        {
            RCP<LoopImplicit> impBF = rcp(new LoopImplicit);
            impBF->setElementValence(_valences[i]);
            impBF->Update();

            _impBF.push_back(impBF);
        }

        for ( int e = 0; e < _adjcyEN->loc_nElem(); e++ )
        {
            //If the element tag is explicit (larger than number of implicit tags)
            if ( (*_BFTags)[e] >= _nImplicitTags )
            {
                RCP<LoopExplicit>  expBF = rcp( new LoopExplicit);
                expBF->SetElementIdentifier(e + _adjcyEN->offs_nElem());
                expBF->setNodeFlags(_nodeFlags);
                expBF->setAdjcyEN(_adjcyEN);
                expBF->Update();

                bool equal{false};
                for ( unsigned int i = 0; i < _expBF.size(); i++ )
                {
                    auto eBF = _expBF[i];

                    if ( eBF->isEqual(*expBF) )
                    {
                        (*_BFTags)[e] = _nImplicitTags + i;
                        equal = true;
                        break;
                    }
                }
                if (!equal)
                {
                    (*_BFTags)[e] = _nImplicitTags+_expBF.size();
                    _expBF.push_back(expBF);
                }
            }

        }

        _nExplicitTags=_expBF.size();
        _numTags=_nImplicitTags+_nExplicitTags;
    }

    void LoopSubdivision::_checkSettings ( )
    {
        if (_adjcyEN == null)
            throw runtime_error("Update Subdivision Surfaces: adjcyEN not set");

        _elemType = _adjcyEN->elemType();

        switch(int(_elemType))
        {
            case static_cast<int>(ElemType::Triang):
                _nVert = 3;
                _pDim = 2;
                break;

            default:
                throw runtime_error("Update Subdivision Surfaces: elem Type not set.");
        }
    }

    void LoopSubdivision::computeBasisFunctionsReference(std::vector< std::vector<double> >& bf, std::vector <double>& xSamples, int tag)
    {

        //If implicit:
        if ( tag < _nImplicitTags )
        {
            _impBF[tag]->ComputeBasisFunctions(bf, xSamples[0],xSamples[1]);

        }
        else
        {
            _expBF[tag-_nImplicitTags]->ComputeBasisFunctions(bf, xSamples[0],xSamples[1]);
        }

    }

    vector<vector<double>>& LoopSubdivision::computeBasisFunctionsReference(
                std::vector <double>& xSamples, int tag)
    {
        computeBasisFunctionsReference(_auxRefBF, xSamples, tag);

        return _auxRefBF;
    }

    void LoopSubdivision::_computeImplicitTags ( )
    {
        int loc_nElem = _adjcyEN->loc_nElem();
        RCP<AdjcyNEStruct> AdjcyNE = _adjcyEN->_adjcyNE;

        _nExplicitTags = 1;
        for (int e=0; e < loc_nElem; e++)
        {

            //[1] Check if any neighbor is marked as crease or corner
            bool expFlag = false;
            for ( int i = 0; i < _adjcyEN->getNumNbors(e, IndexType::Local); i++ )
            {
                int nbor = _adjcyEN->getNbor(e,i,IndexType::Local);
                if ( _nodeFlags->getValue(0,nbor,IndexType::Global) > 0 )
                    expFlag = true;
            }

            //If no crease or corner in the neighborhood
            if ( expFlag == false )
            {
                //[2] Check if there is only one irregular node in the triangle

                //Load the first two nodes in the triangle
                //the third one cannot be loaded until we know
                //the number of neighbors of i0
                int i0, i1, i2;
                i0 = _adjcyEN->getNbor(e, 0, IndexType::Local);
                i1 = _adjcyEN->getNbor(e, 1, IndexType::Local);

                //Load the number neighbors of i0 and load i2
                int ni0, ni1, ni2;
                ni0 = AdjcyNE->getNumNbors(i0, IndexType::Global);
                i2 = _adjcyEN->getNbor(e, ni0, IndexType::Local);

                //Load the remaining number of neighbors
                ni1 = AdjcyNE->getNumNbors(i1, IndexType::Global);
                ni2 = AdjcyNE->getNumNbors(i2, IndexType::Global);

                //If ni2 and ni3 = 6, then this is an implicit element with valence ni0
                if (ni1 == 6 && ni2 == 6)
                {
                    //Look for that valence in the valence vector
                    auto it = std::find(_valences.begin(), _valences.end(), ni0);

                    //If it does not exist, create it
                    if (it == _valences.end()) {
                        _valences.push_back(ni0);
                        (*_BFTags)[e] = _valences.size() - 1;
                    }
                        //If it exists, check position in valence list and set the tag to that value
                    else
                    {
                        auto posIdx = std::distance(_valences.begin(), it);
                        (*_BFTags)[e] = posIdx;
                    }
                }
                //If ni2 or ni3 != 6, then this is an explicit element (set the flag to the negative of previous explicit tags)
                else
                {
                    expFlag = true;
                }
            }

            //[3] In case there were creases or corners, or two or more of the nodes in the triangle were irregular, this element is explicit
            if ( expFlag )
            {
                (*_BFTags)[e] = -_nExplicitTags;
                _nExplicitTags++;
            }

        }

        //Count the number of implicit tags
        _nImplicitTags = _valences.size();

        //The explicit tags are now
        for (int e=0; e < loc_nElem; e++)
        {
            if ( (*_BFTags)[e] < 0 )
                (*_BFTags)[e] = _nImplicitTags - (*_BFTags)[e] - 1;

        }

    }

    int LoopSubdivision::getNumNbors(int tag)
    {
        if ( tag < _nImplicitTags )
            return _valences[tag] + 6;
        else
            return _expBF[tag-_nImplicitTags]->getNumberOfNearestNeighbors();
    }


}// end namespace
