/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LOOPIMPLICIT_H
#define LOOPIMPLICIT_H

#include <assert.h>
#include <vector>

#include "hl_TypeDefs.h"

namespace hiperlife
{
    /** \class LoopImplicit
    * \brief This is the master class for Subdivision Surfaces approximants
    * as described in [1,2] in the implicit case (no crease/corner and 1 irregular node per element).
    *
    * \b Reference: \n
    * [1] F Cirak, M Ortiz, P Schroder, Subdivision surfaces: a new paradigm for thin-shell
    *     finite-element analysis. International Journal for Numerical Methods in Engineering,
    *     47(12):2039-2072.
    * [2] J Stam, "Evaluation of Loop Subdivision Surfaces", SIGGRAPH'99 Course Notes, 1999.
    *
    */

    class LoopImplicit
    {
        public :

            /** Constructor */
            LoopImplicit(void);

            /** Destructor */
            virtual ~LoopImplicit();

            LoopImplicit(LoopImplicit &&other) = default;
            LoopImplicit& operator=(LoopImplicit&& other) = default;

            LoopImplicit& operator=(const LoopImplicit& other) = delete;
            LoopImplicit(const LoopImplicit& other) = delete;


            /** Set/Get EigenStructureFlag */
            void setEigenStructureFlag ( bool eigenFlag )
            {   this->_eigenFlag = eigenFlag;  }
            int getEigenStructureFlag ( )
            {   return this->_eigenFlag;  }


            /** Set/Get element valence */
            void setElementValence ( int eval )
            {   this->_eval = eval;  }
            int getElementValence ( )
            {   return this->_eval;  }

            /** Evaluate the first and second order derivatives of the
             *  surface at any point (v,w)*/
            void ComputeBasisFunctions (std::vector< std::vector<double> >& bf, double v, double w);

            /** Bring this algorithm's outputs up-to-date. */
            virtual void Update();

        protected:

            /** @name Inputs*/
            int     _eval;        ///< Valence of the element
            bool   _eigenFlag{};  ///< Use eigenstructures (true by default)
            double _eps{1.E-12};   ///< epsilon value to evaluate closeness of the point to the irregular vertex

            /** @name Outputs*/
            //@{
            std::vector< std::vector<double> > _BF;
            //@}


            /** Method to delete the preallocated member variables */
            virtual void _clear();

            /** This function is provided to avoid misleadings parameters, or to identify bad settings */
            int _checkSettings();


        private:

            double **_pickingMat; ///< picking matrix
            double **_subDivMat; ///< subdivision matrix

            double **_Paux1;                  ///< Auxiliary matrices
            double **_Aaux1,**_Aaux2;          ///< Auxiliary matrices

            /** This function returns the value of the 12 shape functions of a REGULAR patch
             *  in a point with barycentric coordinates v,w */
            static void _boxSplinesFun  (double v, double w, double [12]);

            /** This function returns the derivatives of the 12 shape functions of a REGULAR
             * patch in a point with barycentric coordinates v,w */
            static void _boxSplinesDer  (double v, double w, double [2][12]);

            /** This function returns the second derivatives of the 12 shape functions of a
             * REGULAR patch in a point with barycentric coordinates v,w */
            static void _boxSplinesHes (double v, double w, double [3][12]);

            /** This function returns, for a REGULAR PATCH, a ShapeFunStr object with the
             * value of the shape function and its first and second derivatives in a point
             * with barycentric coordinates v,w */
            void _basisFunDerReg   (double v, double w,double *p_k, double *dp_k, double *hp_k);

            /** This function returns, for a IRREGULAR PATCH, a ShapeFunStr object with the
             * value of the shape function and its first and second derivatives in a point
             * with barycentric coordinates v,w */
            void _basisFunDerIrregNoEigen (double v, double w, double *p_k, double *dp_k, double *hp_k);
            void _basisFunDerIrregEigen   (double v, double w, double *p_k, double *dp_k, double *hp_k);

            /** Picking matrices */
            void _pickmtrx1 ( );
            void _pickmtrx2 ( );
            void _pickmtrx3 ( );

            /** Subdivision submatrices */
            void _submtrxS   ( );
            void _submtrxS11 ( );
            void _submtrxS21 ( );

            /** Compose A, the subdivision matrix, from S, S11, S12, S21, S22*/
            void _composesubmA ( );

            /** This calculates the power of A to the number of subdivision (A^n)*/
            void _subpowerA ( int npot );

            typedef struct
            {
                double *eigenval;
                double *Ieigenvec;
                double *Phi[3];
            } SSEigenStruct;

            SSEigenStruct _ssEigenStruct;
            void _setEigenStructureValence ( );
            void _clearAuxiliaryEigen();
            void _clearAuxiliaryNoEigen();
            void _allocateAuxiliaryEigen();
            void _allocateAuxiliaryNoEigen();
            void _basisFunctionsDerNode0 ( double *p_s, double *dp_s, double *hp_s );

    };
}
#endif // LOOPIMPLICIT_H
