/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_Math.h"
#include "hl_AdjcyENStruct.h"
#include "hl_Nurbs.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void Nurbs::Update()
    {
        // Main sets
        _bfType = BasisFuncType::Nurbs;
        _numTags = 2; //FIXME: hard coded for now.
        if (_adjcyEN != null)
        {
            // Element, bfOrder per direction, knot vectors and weights
            _elemType = _adjcyEN->elemType();
            tie(_bfOrderX, _bfOrderY, _bfOrderZ) = _adjcyEN->basisFuncOrderDir();
            tie(_nEx, _nEy, _nEz) = _adjcyEN->nElemDir();
            tie(_uKnot, _vKnot, _wKnot) = _adjcyEN->knots();
            _weights = _adjcyEN->weights();

            // Basis function tags
            if (_elemFlags == null)
                throw runtime_error("BasisFunction::Nurbs: Update _elemFlags not set.");
            _BFTags = rcp(new Epetra_IntVector(_adjcyEN->_adjcyElemNodes->RowMap()));
            for (int e = 0; e < _adjcyEN->loc_nElem(); e++)
                (*_BFTags)[e] = _elemFlags->getValue(0, e, IndexType::Local);
        }

        // Check settings
        _checkSettings();

        // Set nVert and pDim
        _nVert = computeNVert(_bfType, _elemType, _bfOrderX, _bfOrderY, _bfOrderZ);
        _pDim = computePDim(_elemType);

        // Set derivative order
        if ((_bfOrderX != -1) and (_bfOrderY != -1) and (_bfOrderZ != -1))
            _orderDers = min(min(_bfOrderX, _bfOrderY), _bfOrderZ);
        else if ((_bfOrderX != -1) and (_bfOrderY != -1))
            _orderDers = min(_bfOrderX, _bfOrderY);
        else if (_bfOrderX != -1)
            _orderDers = _bfOrderX;

        // Allocate space for the basis functions
        _auxRefBF.resize(_orderDers+1);
        _auxEleBF.resize(_orderDers+1);
        for (int i = 0; i < _orderDers+1; i++)
        {
            _auxRefBF[i].resize(_nVert * pow(_pDim, i), 0.0);
            _auxEleBF[i].resize(_nVert * pow(_pDim, i), 0.0);
        }

        // Allocate space for 1D basis functions
        Nu.resize(_orderDers+1, vector<double>(_bfOrderX+1));
        Nv.resize(_orderDers+1, vector<double>(_bfOrderY+1));
        Nw.resize(_orderDers+1, vector<double>(_bfOrderZ+1));

        // Allocate space for product rule indices, its inverse and sum
        idx.resize(_pDim);
        for (auto vec: idx)
            vec.reserve(int(pow(2,_orderDers)));
        iidx.resize(_orderDers+1, vector<vector<int>>(_orderDers+1, vector<int>(_orderDers+1)));
    }

    void Nurbs::_checkSettings()
    {
        if (_elemType == ElemType::Line)
        {
            if ((_nEx == -1) or (_nEy != -1) or (_nEz != -1))
                throw runtime_error("BasisFunction::Nurbs: The number of elements of Line elements should (only) be set in x direction.");
            if ((_bfOrderX == -1) or (_bfOrderY != -1  or _bfOrderZ != -1))
                throw runtime_error("BasisFunction::Nurbs: The order of Line elements should (only) be set in x direction.");
            if (_uKnot.empty() or !_vKnot.empty() or !_wKnot.empty())
                throw runtime_error("BasisFunction::Nurbs: Knot vectors for Line elements should (only) be set in x direction.");
        }
        else if (_elemType == ElemType::Square)
        {
            if ((_nEx == -1) or (_nEy == -1) or (_nEz != -1))
                throw runtime_error("BasisFunction::Nurbs: The number of elements of Square elements should (only) be set in x and y directions.");
            if ((_bfOrderX == -1 or _bfOrderY == -1)  or _bfOrderZ != -1)
                throw runtime_error("BasisFunction::Nurbs: The order of Square elements should (only) be set in x and y directions.");
            if (_uKnot.empty() or _vKnot.empty() or !_wKnot.empty())
                throw runtime_error("BasisFunction::Nurbs: Knot vectors for Square elements should (only) be set in x and y directions.");
        }
        else if (_elemType == ElemType::Parallelep)
        {
            if ((_nEx == -1) or (_nEy == -1) or (_nEz == -1))
                throw runtime_error("BasisFunction::Nurbs: The number of elements of Parallelep elements should be set in x, y and z directions.");
            if (_bfOrderX == -1 or _bfOrderY == -1  or _bfOrderZ == -1)
                throw runtime_error("BasisFunction::Nurbs: The order of Parallelep elements should be set in x, y and z directions.");
            if (_uKnot.empty() or _vKnot.empty() or _wKnot.empty())
                throw runtime_error("BasisFunction::Nurbs: Knot vectors for Parallelep elements should be set in x, y and z directions.");
        }
        else
        {
            throw runtime_error("BasisFunction::Nurbs: Wrong element type.");
        }
        if (_weights.empty())
        {
            throw runtime_error("BasisFunction::Nurbs: Weights not set.");
        }
        if (_BFTags == null)
        {
            throw runtime_error("BasisFunction::Nurbs:Update _BFTags not set.");
        }
    }

    void computeProductRuleIndice(vector< vector<int> >&idx, int dir, int u, int dim, int der, int &n)
    {
        if (der>0)
        {
            for (int i=0; i<dim; i++)
            {
                if (i==dir)
                {
                    u++;
                    computeProductRuleIndice(idx, dir, u, dim, der-1, n);
                    u--;
                }
                else
                {
                    computeProductRuleIndice(idx, dir, u, dim, der-1, n);
                }
            }
        }
        else
        {
            idx[dir][n]=u;
            n++;
        }
    }

    void basisFunctionAndDerivatives(vector<vector<double>>& ders, int i, double u, int p, int n, vector<double> U)
    {
        // Algorithm from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; pp. 72-73.
        /* Compute nonzero basis functions and their */
        /* derivatives. First section is A2.3 modified*/
        /* to store functions and knot differences. */
        /* Input: i,u,p,n,U */
        /* Output: ders */

        //Initialize
        vector<vector<double>> ndu(p+1, vector<double>(p+1)), a(2, vector<double>(p+1));
        vector<double> left(p+1), right(p+1);

        //Compute basis functions
        ndu[0][0] = 1.0;
        for (int j = 1; j <= p; j++)
        {
            left[j] = u-U[i+1-j];
            right[j] = U[i+j]-u;

            double saved{}, temp{};
            for (int r = 0; r < j; r++)
            {
                /* Lower triangle */
                ndu[j][r] = right[r+1] + left[j-r];
                temp = ndu[r][j-1]/ndu[j][r];
                /* Upper triangle */
                ndu[r][j] = saved + right[r+1]*temp;
                saved = left[j-r]*temp;
            }
            ndu[j][j] = saved;
        }

        //Load basis functions
        for (int j = 0; j <= p; j++)
            ders[0][j] = ndu[j][p];

        //Compute derivatives
        for (int r = 0; r <= p; r++)
        {
            //Alternate rows in array a
            int s1{0};
            int s2{1};
            a[0][0] = 1.0;

            //Compute kth derivative
            for (int k = 1; k <= n; k++)
            {
                double d{};
                int rk = r-k;
                int pk = p-k;
                if (r >= k)
                {
                    a[s2][0] = a[s1][0]/ndu[pk+1][rk];
                    d = a[s2][0]*ndu[rk][pk];
                }
                int j1, j2;
                if (rk >= -1)
                    j1 = 1;
                else
                    j1 = -rk;
                if (r-1 <= pk)
                    j2 = k-1;
                else
                    j2 = p-r;
                for (int j = j1; j <= j2; j++)
                {
                    a[s2][j] = (a[s1][j]-a[s1][j-1])/ndu[pk+1][rk+j];
                    d += a[s2][j]*ndu[rk+j][pk];
                }
                if (r <= pk)
                {
                    a[s2][k] = -a[s1][k-1]/ndu[pk+1][r];
                    d += a[s2][k]*ndu[r][pk];
                }
                ders[k][r] = d;
                //Switch rows
                int j = s1;
                s1 = s2;
                s2 = j;
            }
        }

        //Multiply through by the correct factors
        int r = p;
        for (int k = 1; k <= n; k++)
        {
            for (int j = 0; j <= p; j++)
            {
                ders[k][j] *= r;
            }
            r *= (p-k);
        }

    }

    void Nurbs::computeBasisFunctionsReference(vector<vector<double>>& bf, vector<double>& xSamples, int tag)
    {
        //Initialize
        double u{}, v{}, w{};
        double u_hat{}, v_hat{}, w_hat{};
        int span_u{}, span_v{}, span_w{};
        int inex{}, iney{}, inez{};

        vector<vector<double>> del, del2;

        int n{};
        vector<vector<double>> sum;
        sum.resize(_orderDers+1);
        for (int d = 0; d < _orderDers+1; d++)
            sum[d].resize(int(pow(_pDim, d)), 0.0);
        switch (_pDim)
        {
            case 1:
                u = xSamples[0];
                inex = tag % _nEx;
                span_u = _bfOrderX+inex;
                u_hat = _uKnot[span_u] + (u+1)*(_uKnot[span_u+1]-_uKnot[span_u])/2.0;

                //Get 1D Bspline basis functions and derivatives
                basisFunctionAndDerivatives(Nu, span_u, u_hat, _bfOrderX, _orderDers, _uKnot);

                //Nurbs basis functions
                n = 0;
                for (int p = 0; p < _bfOrderX+1; p++)
                {
                    //Store partial results
                    for (int d = 0; d < _orderDers+1; d++)
                    {
                        bf[d][n] = Nu[d][p]*_weights[inex+p];
                        sum[d][0] += bf[d][n];
                    }

                    //Increase basis function number
                    n++;
                }

                del.resize(_orderDers+1);
                for (int i = 0; i < _orderDers+1; i++)
                    del[i].resize(_nVert * pow(_pDim, i), 0.0);
                del = bf;

                for (int j = 0; j < n; j++)
                {
                    for (int k = 0; k <= _orderDers; k++)
                    {
                        double uu = bf[k][j];
                        for (int i = 1; i <= k; i++)
                            uu -= static_cast<double>(Math::binomialCoeff(k, i))*sum[i][0]*bf[k-i][j];
                        bf[k][j] = uu/sum[0][0];
                    }
                }

                for (int i = 0; i < n; i++)
                {
                    if (_orderDers > 1)
                    {
                        del[2][i] = del[2][i]/sum[0][0]  - del[1][i]*sum[1][0]/sum[0][0]/sum[0][0]
                            - ((del[1][i]*sum[1][0] + del[0][i]*sum[2][0])/sum[0][0]/sum[0][0]
                               - 2.0*del[0][i]*sum[1][0]*sum[1][0]/sum[0][0]/sum[0][0]/sum[0][0]);
                    }
                    if (_orderDers > 0)
                        del[1][i] = del[1][i]/sum[0][0] - del[0][i]*sum[1][0]/sum[0][0]/sum[0][0];
                    del[0][i] /= sum[0][0];
                }

                for (int j = 0; j < n; j++)
                {
                    for (int k = 0; k < min(3, _orderDers+1); k++)
                    {
                        if (abs(bf[k][j]-del[k][j])/bf[k][j] > 1e-14)
                            cout << tag << " " << k << " " << abs(bf[k][j]-del[k][j])/bf[k][j] << " " << bf[k][j] << " " << del[k][j] << endl;
                    }
                }

                break;

            case 2:
                u = xSamples[0];
                inex = tag % _nEx;
                span_u = _bfOrderX+inex;
                u_hat = _uKnot[span_u] + (u+1)*(_uKnot[span_u+1]-_uKnot[span_u])/2.0;

                v = xSamples[1];
                iney = (int) tag/_nEx;
                span_v = _bfOrderY+iney;
                v_hat = _vKnot[span_v] + (v+1)*(_vKnot[span_v+1]-_vKnot[span_v])/2.0;

                // Compute 1D Bspline basis functions and derivatives
                basisFunctionAndDerivatives(Nu, span_u, u_hat, _bfOrderX, _orderDers, _uKnot);
                basisFunctionAndDerivatives(Nv, span_v, v_hat, _bfOrderY, _orderDers, _vKnot);

                // Nurbs basis functions
                n = 0;
                for (int q = 0; q < _bfOrderY+1; q++)
                {
                    for (int p = 0; p < _bfOrderX+1; p++)
                    {
                        int iw = (_nEx+_bfOrderX)*(iney+q) + inex + p;
                        for (int d = 0; d < _orderDers+1; d++)
                        {
                            int kk = int(pow(_pDim, d));

                            //Compute product rule derivative indices
                            for (int j = 0; j < _pDim; j++)
                            {
                                idx[j].resize(kk);
                                int h = 0;
                                computeProductRuleIndice(idx, j, 0, _pDim, d, h);
                            }

                            //Store basis functions and derivatives
                            for (int k = 0; k < kk; k++)
                            {
                                bf[d][kk*n+k] = Nu[idx[0][k]][p] * Nv[idx[1][k]][q] * _weights[iw];
                                sum[d][k] += bf[d][kk*n+k];
                            }
                        }

                        //Increase basis function number
                        n++;
                    }
                }

                if (_orderDers < 3)
                {
                    n = 0;
                    for (int q = 0; q < _bfOrderY+1; q++)
                    {
                        for (int p = 0; p < _bfOrderX+1; p++)
                        {
                            if (_orderDers > 1)
                            {
                                int d = 2;

                                //uu
                                int i  = int(pow(_pDim, d))*n;
                                int du = _pDim*n+0;
                                int dv = _pDim*n+1;
                                bf[d][i] =
                                + bf[d][i]
                                - bf[1][du]*sum[1][0]/sum[0][0]
                                - bf[1][du]*sum[1][0]/sum[0][0]
                                + 2.0*bf[0][n]*sum[1][0]*sum[1][0]/sum[0][0]/sum[0][0]
                                - bf[0][n]*sum[2][0]/sum[0][0];
                                bf[d][i] /= sum[0][0];

                                //uv
                                i++;
                                bf[d][i] =
                                + bf[d][i]
                                - bf[1][du]*sum[1][1]/sum[0][0]
                                - bf[1][dv]*sum[1][0]/sum[0][0]
                                + 2.0*bf[0][n]*sum[1][0]*sum[1][1]/sum[0][0]/sum[0][0]
                                - bf[0][n]*sum[2][1]/sum[0][0];
                                bf[d][i] /= sum[0][0];

                                //vu
                                i++;
                                bf[d][i] =
                                + bf[d][i]
                                - bf[1][dv]*sum[1][0]/sum[0][0]
                                - bf[1][du]*sum[1][1]/sum[0][0]
                                + 2.0*bf[0][n]*sum[1][1]*sum[1][0]/sum[0][0]/sum[0][0]
                                - bf[0][n]*sum[2][2]/sum[0][0];
                                bf[d][i] /= sum[0][0];

                                //vv
                                i++;
                                bf[d][i] =
                                + bf[d][i]
                                - bf[1][dv]*sum[1][1]/sum[0][0]
                                - bf[1][dv]*sum[1][1]/sum[0][0]
                                + 2.0*bf[0][n]*sum[1][1]*sum[1][1]/sum[0][0]/sum[0][0]
                                - bf[0][n]*sum[2][3]/sum[0][0];
                                bf[d][i] /= sum[0][0];
                            }
                            if (_orderDers > 0)
                            {
                                for (int k = 0; k < _pDim; k++)
                                {
                                    int i = _pDim*n + k;
                                    bf[1][i] = bf[1][i]/sum[0][0] - bf[0][n]*sum[1][k]/sum[0][0]/sum[0][0];
                                }
                            }
                            bf[0][n] /= sum[0][0];

                            //Increase basis function number
                            n++;
                        }
                    }
                }
                else
                {
                    n = 0;
                    for (int q = 0; q < _bfOrderY+1; q++)
                    {
                        for (int p = 0; p < _bfOrderX+1; p++)
                        {
                            for (int ii = 0; ii < _orderDers+1; ii++)
                            {
                                for (int jj = 0; jj < int(pow(_pDim, ii)); jj++)
                                {
                                    //Compute product rule derivative indices and inverse
                                    for (int j = 0; j < _pDim; j++)
                                    {
                                        idx[j].resize(int(pow(_pDim, ii)));
                                        int h = 0;
                                        computeProductRuleIndice(idx, j, 0, _pDim, ii, h);
                                    }
                                    iidx[idx[0][jj]][idx[1][jj]][0] = jj;

                                    int k = idx[0][jj];
                                    int l = idx[1][jj];
                                    int h = int(pow(_pDim, k+l))*n;
                                    double v = bf[k+l][h+iidx[k][l][0]];
                                    for (int j = 1; j <= l; j++)
                                    {
                                        h = int(pow(_pDim, k+l-j))*n;
                                        v -= static_cast<double>(Math::binomialCoeff(l, j))*sum[j][iidx[0][j][0]]*bf[k+l-j][h+iidx[k][l-j][0]];
                                    }
                                    for (int i = 1; i <= k; i++)
                                    {
                                        h = int(pow(_pDim, k-i+l))*n;
                                        v -= static_cast<double>(Math::binomialCoeff(k, i))*sum[i][iidx[i][0][0]]*bf[k-i+l][h+iidx[k-i][l][0]];
                                        double v2{};
                                        for (int j = 1; j <= l; j++)
                                        {
                                            h = int(pow(_pDim, k-i+l-j))*n;
                                            v2 += static_cast<double>(Math::binomialCoeff(l, j))*sum[i+j][iidx[i][j][0]]*bf[k-i+l-j][h+iidx[k-i][l-j][0]];
                                        }
                                        v -= static_cast<double>(Math::binomialCoeff(k, i))*v2;
                                    }
                                    h = int(pow(_pDim, k+l))*n;
                                    bf[k+l][h+iidx[k][l][0]] = v/sum[0][0];
                                }
                            }
                            n++;
                        }
                    }
                }

                // //Compare (FIXME::remove)
                // // for (int k = 0; k < bf.size(); k++)
                // for (int k = 0; k < min(3, _orderDers+1); k++)
                // {
                //     for (int j = 0; j < int(pow(_pDim, k)); j++)
                //     {
                //         if (abs(bf[k][j]-del[k][j])/bf[k][j] > 1e-14)
                //             cout << tag << " " << k << " " << j << " | "<< abs(bf[k][j]-del[k][j])/bf[k][j] << " " << bf[k][j] << " " << del[k][j] << endl;
                //     }
                // }

                break;

            case 3:
                u = xSamples[0];
                inex = tag % _nEx;
                span_u = _bfOrderX+inex;
                u_hat = _uKnot[span_u] + (u+1)*(_uKnot[span_u+1]-_uKnot[span_u])/2.0;

                v = xSamples[1];
                iney = (tag%(_nEx*_nEy))/_nEx;
                span_v = _bfOrderY+iney;
                v_hat = _vKnot[span_v] + (v+1)*(_vKnot[span_v+1]-_vKnot[span_v])/2.0;

                w = xSamples[2];
                inez = (tag/(_nEx*_nEy));
                span_w = _bfOrderZ+inez;
                w_hat = _wKnot[span_w] + (w+1)*(_wKnot[span_w+1]-_wKnot[span_w])/2.0;

                // Compute 1D Bspline basis functions and derivatives
                basisFunctionAndDerivatives(Nu, span_u, u_hat, _bfOrderX, _orderDers, _uKnot);
                basisFunctionAndDerivatives(Nv, span_v, v_hat, _bfOrderY, _orderDers, _vKnot);
                basisFunctionAndDerivatives(Nw, span_w, w_hat, _bfOrderZ, _orderDers, _wKnot);

                // cout << tag << " "  << inex << " "  << iney << " "  << inez << endl;

                // for (auto u:_uKnot)
                //     cout << " " << u;
                // cout << endl;

                // for (auto u:_vKnot)
                //     cout << " " << u;
                // cout << endl;

                // for (auto u:_wKnot)
                //     cout << " " << u;
                // cout << endl;

                // cout << " " << _bfOrderX << " " << u << " " << u_hat << " " << span_u << endl;
                // cout << " " << _bfOrderY << " " << v << " " << v_hat << " " << span_v << endl;
                // cout << " " << _bfOrderZ << " " << w << " " << w_hat << " " << span_w << endl;


                // for (int i = 0; i < Nu.size(); i++)
                // {
                //     cout << i << " ";
                //     for (int j= 0; j < Nu[i].size(); j++)
                //     {
                //         cout << Nu[i][j] << " ";
                //     }
                //     cout << endl;
                // }
                // cout << endl;


                //Nurbs basis functions
                n = 0;
                for (int r = 0; r < _bfOrderZ+1; r++)
                {
                    for (int q = 0; q < _bfOrderY+1; q++)
                    {
                        for (int p = 0; p < _bfOrderX+1; p++)
                        {
                            int iw = (_nEx+_bfOrderX)*(_nEy+_bfOrderY)*(inez+r) + (_nEx+_bfOrderX)*(iney+q) + inex + p;
                            for (int d = 0; d < _orderDers+1; d++)
                            {
                                int kk = int(pow(_pDim, d));

                                //Compute product rule derivative indices
                                for (int j = 0; j < _pDim; j++)
                                {
                                    idx[j].resize(kk);
                                    int h = 0;
                                    computeProductRuleIndice(idx, j, 0, _pDim, d, h);
                                }

                                //Store basis functions and derivatives
                                for (int k = 0; k < int(pow(_pDim,d)); k++)
                                {
                                    bf[d][kk*n+k] = Nu[idx[0][k]][p] * Nv[idx[1][k]][q] * Nw[idx[2][k]][r] * _weights[iw];
                                    sum[d][k] += bf[d][kk*n+k];
                                }
                            }

                            //Increase basis function number
                            n++;
                        }
                    }
                }

                //Old version by hand to compare (remove)
                del.resize(_orderDers+1);
                for (int i = 0; i < _orderDers+1; i++)
                    del[i].resize(_nVert * pow(_pDim, i), 0.0);
                del = bf;

                n = 0;
                for (int r = 0; r < _bfOrderZ+1; r++)
                {
                    for (int q = 0; q < _bfOrderY+1; q++)
                    {
                        for (int p = 0; p < _bfOrderX+1; p++)
                        {
                            if (_orderDers > 2)
                            {
                                throw runtime_error("Nurbs:: Order greater than 2 not implemented yet.");
                            }
                            if (_orderDers > 1)
                            {
                                int d = 2;

                                //uu
                                int k = 0;
                                int i = int(pow(_pDim, d))*n+k;
                                int du = int(pow(_pDim, 1))*n+0;
                                int dv = int(pow(_pDim, 1))*n+1;
                                int dw = int(pow(_pDim, 1))*n+2;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][du]*sum[1][0]/sum[0][0]
                                    - del[1][du]*sum[1][0]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][0]*sum[1][0]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][0]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //uv
                                k = 1;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][du]*sum[1][1]/sum[0][0]
                                    - del[1][dv]*sum[1][0]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][0]*sum[1][1]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][1]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //uw
                                k = 2;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][du]*sum[1][2]/sum[0][0]
                                    - del[1][dw]*sum[1][0]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][0]*sum[1][2]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][2]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //vu
                                k = 3;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][dv]*sum[1][0]/sum[0][0]
                                    - del[1][du]*sum[1][1]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][1]*sum[1][0]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][3]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //vv
                                k = 4;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][dv]*sum[1][1]/sum[0][0]
                                    - del[1][dv]*sum[1][1]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][1]*sum[1][1]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][4]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //vw
                                k = 5;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][dv]*sum[1][2]/sum[0][0]
                                    - del[1][dw]*sum[1][1]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][1]*sum[1][2]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][5]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //wu
                                k = 6;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][dw]*sum[1][0]/sum[0][0]
                                    - del[1][du]*sum[1][2]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][1]*sum[1][0]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][6]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //wv
                                k = 7;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][dw]*sum[1][1]/sum[0][0]
                                    - del[1][dv]*sum[1][2]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][1]*sum[1][1]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][7]/sum[0][0];
                                del[d][i] /= sum[0][0];

                                //ww
                                k = 8;
                                i = int(pow(_pDim, d))*n+k;
                                del[d][i] =
                                    + del[d][i]
                                    - del[1][dw]*sum[1][2]/sum[0][0]
                                    - del[1][dw]*sum[1][2]/sum[0][0]
                                    + 2.0*del[0][n]*sum[1][1]*sum[1][2]/sum[0][0]/sum[0][0]
                                    - del[0][n]*sum[2][8]/sum[0][0];
                                del[d][i] /= sum[0][0];

                            }
                            if (_orderDers > 0)
                            {
                                int d = 1;
                                for (int k = 0; k < int(pow(_pDim, d)); k++)
                                {
                                    int i = int(pow(_pDim, d))*n + k;
                                    // cout << d << " " << i << " " << del[d][i] << " " << sum[1][k] << endl;
                                    del[d][i] = del[d][i]/sum[0][0] - del[0][n]*sum[1][k]/sum[0][0]/sum[0][0];
                                }
                            }
                            del[0][n] /= sum[0][0];

                            //Increase basis function number
                            n++;
                        }
                    }
                }

                bf = del;

                // //Output
                // for (int i = 0; i < bf.size(); i++)
                // {
                //     for (int j = 0; j < bf[i].size(); j++)
                //     {
                //         cout << bf[i][j] << " ";
                //     }
                //     cout << endl;
                // }



                // //New version
                // n = 0;
                // for (int q = 0; q < _bfOrderY+1; q++)
                // {
                //     for (int p = 0; p < _bfOrderX+1; p++)
                //     {
                //         for (int ii = 0; ii < _orderDers+1; ii++)
                //         {
                //             for (int jj = 0; jj < int(pow(_pDim, ii)); jj++)
                //             {
                //                 //Compute product rule derivative indices and inverse
                //                 for (int j = 0; j < _pDim; j++)
                //                 {
                //                     idx[j].resize(int(pow(_pDim, ii)));
                //                     int h = 0;
                //                     computeProductRuleIndice(idx, j, 0, _pDim, ii, h);
                //                 }
                //                 iidx[idx[0][jj]][idx[1][jj]][0] = jj;

                //                 int k = idx[0][jj];
                //                 int l = idx[1][jj];
                //                 int h = int(pow(_pDim, k+l))*n;
                //                 double v = bf[k+l][h+iidx[k][l][0]];
                //                 for (int j = 1; j <= l; j++)
                //                 {
                //                     h = int(pow(_pDim, k+l-j))*n;
                //                     v -= bin(l, j)*sum[j][iidx[0][j][0]]*bf[k+l-j][h+iidx[k][l-j][0]];
                //                 }
                //                 for (int i = 1; i <= k; i++)
                //                 {
                //                     h = int(pow(_pDim, k-i+l))*n;
                //                     v -= bin(k, i)*sum[i][iidx[i][0][0]]*bf[k-i+l][h+iidx[k-i][l][0]];
                //                     double v2{};
                //                     for (int j = 1; j <= l; j++)
                //                     {
                //                         h = int(pow(_pDim, k-i+l-j))*n;
                //                         v2 += bin(l, j)*sum[i+j][iidx[i][j][0]]*bf[k-i+l-j][h+iidx[k-i][l-j][0]];
                //                     }
                //                     v -= bin(k, i)*v2;
                //                 }
                //                 h = int(pow(_pDim, k+l))*n;
                //                 bf[k+l][h+iidx[k][l][0]] = v/sum[0][0];

                //             }
                //         }
                //         n++;
                //     }
                // }

                // //Compare (remove)
                // // for (int k = 0; k < bf.size(); k++)
                // for (int k = 0; k < min(3, _orderDers+1); k++)
                // {
                //     for (int j = 0; j < int(pow(_pDim, k)); j++)
                //     {
                //         if (abs(bf[k][j]-del[k][j])/bf[k][j] > 1e-14)
                //             cout << tag << " " << k << " " << j << " | "<< abs(bf[k][j]-del[k][j])/bf[k][j] << " " << bf[k][j] << " " << del[k][j] << endl;
                //     }
                // }

                break;
        }

    }

    vector<vector<double>>& Nurbs::computeBasisFunctionsReference(vector<double>& xSamples, int tag)
    {
        computeBasisFunctionsReference(_auxRefBF, xSamples, tag);

        return _auxRefBF;
    }

}
