/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LINEAR_H
#define LINEAR_H

#include "hl_BasisFunctions.h"

namespace hiperlife
{

    /*!
     * \brief Basic implementation of Linear Basis Functions for triangular meshes
    */
    class Linear : public BasisFunctions
    {
        public:

            Linear() = default;
            Linear(Linear &&other) = default;
            ~Linear() = default;
            Linear& operator=(Linear&& other) = default;

            Linear& operator=(const Linear& other) = delete;
            Linear(const Linear& other) = delete;

            void Update() override;

            int getNumNbors(int tag) override {(void) tag; return _nVert;}


            void computeBasisFunctionsReference(std::vector<std::vector<double>>& bf, std::vector<double>& xSamples, int tag = 0) override;
            std::vector<std::vector<double>>& computeBasisFunctionsReference(std::vector<double>& xSamples, int tag = 0) override;


        private:
            void _checkSettings();
    };


}

#endif
