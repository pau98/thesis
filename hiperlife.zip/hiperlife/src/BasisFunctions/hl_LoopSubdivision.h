/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LOOPSUBDIVISION_H
#define LOOPSUBDIVISION_H

#include "hl_BasisFunctions.h"
#include "hl_LoopImplicit.h"
#include "hl_LoopExplicit.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of Loop Subdivision Surfaces. They are compatible with triangular meshes.
    */
    class LoopSubdivision : public BasisFunctions
    {
        public:

            LoopSubdivision() = default;
            LoopSubdivision(LoopSubdivision &&other) = default;
            ~LoopSubdivision() = default;
            LoopSubdivision& operator=(LoopSubdivision&& other) = default;

            LoopSubdivision& operator=(const LoopSubdivision& other) = delete;
            LoopSubdivision(const LoopSubdivision& other) = delete;

            void Update() override;

            int getNumNbors(int tag) override;


            void computeBasisFunctionsReference(std::vector<std::vector<double>>& bf, std::vector<double>& xSamples, int tag = 0) override;
            std::vector<std::vector<double>>& computeBasisFunctionsReference(std::vector<double>& xSamples, int tag = 0) override;


        private:
            int _nImplicitTags;
            int _nExplicitTags;

            std::vector <int> _valences;
            std::vector < Teuchos::RCP<LoopImplicit> > _impBF;
            std::vector < Teuchos::RCP<LoopExplicit> > _expBF;

            void _computeImplicitTags();
            void _checkSettings();
    };


}

#endif //LOOPSUBDIVISION_H
