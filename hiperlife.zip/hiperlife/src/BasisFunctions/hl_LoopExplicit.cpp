/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Daniel Millán
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <cmath>
#include <vector>
#include <string>

#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_LoopExplicit.h"
#include "hl_Math.h"
#include "hl_Array.h"
#include <stdio.h>

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;

namespace hiperlife
{
    // -------------------------------------------------------------------------------------
    // -------------------------------------------------------------------------------------
    void LoopExplicit::Update()
    {
        //Translate global variables to local variables in the element patch
        _global2Local();

        int maxnbor = std::max({_nNN0[0],_nNN0[1],_nNN0[0],6})+6;

        _creasesNbors_tmp.reserve(maxnbor);
        _subDivMat_step.reserve(maxnbor*maxnbor);
        _subDivMat_tmp.reserve(maxnbor*maxnbor);
        _nNN_tmp.reserve(maxnbor);
        _angles_tmp.reserve(maxnbor);
    }
    // -------------------------------------------------------------------------------------
    // -------------------------------------------------------------------------------------

    // Evaluate shape functions at one sample point
    void LoopExplicit::ComputeBasisFunctions (std::vector< std::vector<double> >& bf, double xi1, double xi2)
    {
        using namespace std;
#ifdef DEBUG
        if ( xi1>1.0 || xi1<0.0 )
        {
            throw runtime_error("ERROR::LoopImplicit::SubDivOneSample: A barycentric coordinate of the sample point is ill defined, " + to_string(xi1));
        }

        if ( xi2>1.0 || xi2< 0.0 )
        {
            throw runtime_error("ERROR::LoopImplicit::SubDivOneSample: A barycentric coordinate of the sample point is ill defined, " + to_string(xi2));
        }
#endif

        bf.resize(3);

        bf[0].resize(_eNN0);
        bf[1].resize(_eNN0*2);
        bf[2].resize(_eNN0*4);

        _basisFunctionAndDerivatives (xi1, xi2, bf[0].data(), bf[1].data(), bf[2].data());

    }

    //This is called by Update and SubDivOneSample to calculate the value of the Basis Functions and Derivatives
    void LoopExplicit::_basisFunctionAndDerivatives (double xi1, double xi2, double *p_k, double *dp_k, double *hp_k)
    {
        int i, j;
        int subtrian;
        double sum_shape, sum_derx, sum_dery, sum_hessxx, sum_hessxy, sum_hessyy;
        std::vector < std::vector <double> > impBFs;
        double *pl_k, *dpl_k, *hpl_k;
        double v,w,aux;
        bool limitMask;

        int Maux[4];
        double Daux1[4],Daux2[4], Daux3[4];

        RCP<LoopImplicit> ssimp = rcp ( new LoopImplicit ); ///< Subdivision implicit

        // Create the ssimp object (box splines of the implicit subdivision class with valence 6)
        v = xi1;
        w = xi2;

        //This is to scale the new gradients and hessians
        _factor2=1.0;

        //Set transform to identity
        _transform[0]=1;    _transform[1]=0;
        _transform[2]=0;    _transform[3]=1;

        _creaseFlag = _creaseFlag0;
        _nNN=_nNN0;
        _eNN = _eNN0;
        _creasesNbors=_creasesNbors0;
        _anglesNbors=_anglesNbors0;

        _subDivMat.resize(_eNN0*_eNN0);
        Array::Fill(_subDivMat.data(),_eNN0*_eNN0, 0.0);
        for( i = 0; i < _eNN0; i++ )
            _subDivMat[i*_eNN0+i] = 1.0;

        limitMask = false;

        while( ( _nNN[1] !=6 || _nNN[_nNN[0]] !=6 || _creaseFlag) && !limitMask )
        {
            //This is to scale the new gradients and hessians
            subtrian = idSubTrian (v,w);

            switch(subtrian)
            {
                case 0:
                    _subNodesInFirstRing0();
                    break;
                case 1:
                    _subNodesInFirstRing1();
                    break;
                case 2:
                    _subNodesInFirstRing2();
                    break;
                case 3:
                    _subNodesInFirstRing3();
                    break;
                // This is for the limit masks for nodes 1 and N when creased
                default:
                    limitMask=true;
                    break;
            }


            if(!_creaseFlag)
            {
                if(_nNN[0]==6&&_nNN[1]!=6&&_nNN[_nNN[0]]==6)
                {
                    _rotateTriangle();
                    aux = v;
                    v   = w;
                    w   = 1.0-aux-w;


                    Array::Copy(Maux,4,_transform);

                    _transform[0] = Maux[2];          _transform[1] = Maux[3];
                    _transform[2] = -Maux[0]-Maux[2]; _transform[3] = -Maux[1]-Maux[3];
                }
                else if(_nNN[0]==6&&_nNN[1]==6&&_nNN[_nNN[0]]!=6)
                {
                    _rotateTriangle();
                    aux = v;
                    v   = w;
                    w   = 1.0-aux-w;

                    Array::Copy(Maux,4,_transform);

                    _transform[0] = Maux[2];          _transform[1] = Maux[3];
                    _transform[2] = -Maux[0]-Maux[2]; _transform[3] = -Maux[1]-Maux[3];

                    _rotateTriangle();
                    aux = v;
                    v   = w;
                    w   = 1.0-aux-w;

                    Array::Copy(Maux,4,_transform);

                    _transform[0] = Maux[2];          _transform[1] = Maux[3];
                    _transform[2] = -Maux[0]-Maux[2]; _transform[3] = -Maux[1]-Maux[3];

                }
            }

        }

        if ( subtrian >= 0 )
        {
            ssimp->setElementValence(_nNN[0]);
            ssimp->Update();

            ssimp->ComputeBasisFunctions(impBFs,v,w);

            // Compute the Box-Splines basis functions and derivatives at v,w
            pl_k    = impBFs[0].data();
            dpl_k   = impBFs[1].data();
            hpl_k   = impBFs[2].data();
        }
        else
        {

            // LIMIT MASKS!
            if ( subtrian == -1 )
                _limitMaskNode1();
            else if ( subtrian == -2 )
                _limitMaskNodeN();

            pl_k    = _plimit_k.data();
            dpl_k   = _dplimit_k.data();
            hpl_k   = _hplimit_k.data();

        }

        for (j=0; j<_eNN0; j++)
        {
            sum_shape  = 0.0;
            sum_derx   = 0.0;
            sum_dery   = 0.0;
            sum_hessxx = 0.0;
            sum_hessyy = 0.0;
            sum_hessxy = 0.0;

            for (i=0; i<_eNN; i++)
            {
                sum_shape   += _subDivMat[i*_eNN0+j]* pl_k[i];
                sum_derx    += _subDivMat[i*_eNN0+j]* dpl_k[2*i+0];
                sum_dery    += _subDivMat[i*_eNN0+j]* dpl_k[2*i+1];
                sum_hessxx  += _subDivMat[i*_eNN0+j]* hpl_k[4*i+0];
                sum_hessyy  += _subDivMat[i*_eNN0+j]* hpl_k[4*i+3];
                sum_hessxy  += _subDivMat[i*_eNN0+j]* hpl_k[4*i+1];
            }

            p_k [j]       =  sum_shape;
            dp_k[j*2+0]   =  _factor2*(_transform[0]*sum_derx+_transform[2]*sum_dery);
            dp_k[j*2+1]   =  _factor2*(_transform[1]*sum_derx+_transform[3]*sum_dery);

            Daux1[0] = static_cast<double>(_transform[0]); Daux1[1] = static_cast<double>(_transform[1]);
            Daux1[2] = static_cast<double>(_transform[2]); Daux1[3] = static_cast<double>(_transform[3]);
            Daux2[0] = sum_hessxx;         Daux2[1] = sum_hessxy;
            Daux2[2] = sum_hessxy;         Daux2[3] = sum_hessyy;
            Math::MatTMult(Daux3,2,2,2,Daux1,Daux2);
            Math::MatProduct(Daux2,2,2,2,Daux3,Daux1);
            hp_k[j*4+0]   =  _factor2*_factor2*Daux2[0];
            hp_k[j*4+1]   =  _factor2*_factor2*Daux2[1];
            hp_k[j*4+2]   =  _factor2*_factor2*Daux2[2];
            hp_k[j*4+3]   =  _factor2*_factor2*Daux2[3];
        }
    }


    // This function translates the initial input with global node labels to local variables
    // within the first ring of neighbors of the element
    void LoopExplicit::_global2Local ()
    {
        // Set the creaseFlag0 to false (no creases in the element)
        _creaseFlag0 = false;

        // Calculate eInit and the number of nearest neighbors
        _eNN  = _adjcyEN->getNumNbors(_elemID,IndexType::Global);

        _nNN.resize(_eNN);
        _creasesNbors.resize(_eNN);
        _anglesNbors.resize(_eNN);
        for ( int i = 0; i < _eNN; i++ )
        {
            int nbor = _adjcyEN->getNbor(_elemID,i,IndexType::Global);
            _creasesNbors[i]  = _nodeFlags->getValue(0,nbor,IndexType::Global);
            _nNN[i] = _adjcyEN->_adjcyNE->getNumNbors(nbor,IndexType::Global);

            if ( _creasesNbors[i] > 0 )
                _nNN[i] += 1;

            if(_creasesNbors[i] == 0)
            {
                _anglesNbors[i] = 2.0*M_PI;
            }
            else if (_creasesNbors[i] == 1)
            {
                _anglesNbors[i] = M_PI;
            }
            else
            {
                _anglesNbors[i] = M_PI; //FIXME: cornerAngles[idN_corners[je_nodes[eInit+i]]];
            }
        }

        // Load the 0-subdivision level variables
        _eNN0 = _eNN;
        _nNN0 = _nNN;
        _creasesNbors0= _creasesNbors;
        _anglesNbors0= _anglesNbors;

        for (int i = 0; i < _eNN; i++ )
        {
            if (_creasesNbors[i] > 0)
            {
                _creaseFlag0 = true;
                break;
            }
        }
        _creaseFlag = _creaseFlag0;

    }

    /* Identify the subtriangle
    *     /  \
    *    / 0  \
    *   /------\
    *  /  \ 3/  \
    * / 1  \/  2 \
    *  ---------- */
    int LoopExplicit::idSubTrian (double &v, double &w)
    {
        int iD;
        double  eps, eps0=1.0e-6;
        double aux1, aux2;
        int Maux[4];

        // Special cases (for evaluation on the edges)

        eps = eps0 * _factor2;

        // NEAR THE CORNERS!!!!
        if ( ABS(1.0-v) < eps && _creasesNbors[1] > 0 )
        {
            _transform[0] = 1;  _transform[1] = 0;
            _transform[2] = 0;  _transform[3] = 1;
            return -1;
        }

        if ( ABS(1.0-w) < eps && _creasesNbors[_nNN[0]] > 0 )
        {
            _transform[0] = 1;  _transform[1] = 0;
            _transform[2] = 0;  _transform[3] = 1;
            return -2;
        }

        //If the evaluation is not at the border, then we subdivide:
        //This is to scale the new gradients and hessians
        _factor2 *=2.0;

        //IN THE BORDER (SPECIAL RULES TO AVOID OVERFLOW!)
        if (ABS(v + w - 1.0) < eps )
        {
            if( v > 0.5 )
            {
                iD = 1;
                v = 2.0*v-1.0;
                w = 1.0-v;
            }
            else if( w > 0.5 )
            {
                iD = 2;
                w = 2.0*w -1.0;
                v = 1.0-w;
            }
            else
            {
                iD = 3;
                v = 1.0-2.0*w;
                w = 1.0-v;

                Array::Copy(Maux,4,_transform);
                _transform[0] = -Maux[2];         _transform[1] = -Maux[3];
                _transform[2] = Maux[0]+Maux[2];  _transform[3] = Maux[1]+Maux[3];
            }
        }
        else
        {
            if( v + w < 0.5 )
            {
                iD = 0;
                v = 2.0*v;
                w = 2.0*w;
            }
            else if( v > 0.5 )
            {
                iD = 1;
                v = 2.0*v-1.0;
                w = 2.0*w;
            }
            else if( w > 0.5 )
            {
                iD = 2;
                v = 2.0*v;
                w = 2.0*w -1.0;
            }
            else
            {
                iD = 3;

                aux1 = v;
                aux2 = w;
                v = 1.0-2.0*aux2;
                w = 2.0*aux1+2.0*aux2-1.0;

                Array::Copy(Maux,4,_transform);
                _transform[0] = -Maux[2];         _transform[1] = -Maux[3];
                _transform[2] = Maux[0]+Maux[2];  _transform[3] = Maux[1]+Maux[3];
            }
        }


        return iD;
    }

    // ---------------------------------------------------------------------------------------
    //                ROOTS OF THE DEVIL (subdivision rules for each subtriangle)
    // ---------------------------------------------------------------------------------------
    // Satanic diagram:
    /*     /  \
     *    / 0  \
     *   /------\
     *  /  \ 3/  \
     * / 1  \/  2 \
     *  ---------- */
    // Subdivision rules for the first triangle (keeps node 0)
    // This is well commented. The rest are equivalent to this one so that they have less comments
    void LoopExplicit::_subNodesInFirstRing0()
    {
        _subDivMat_step.clear();
        _creasesNbors_tmp.clear();
        _angles_tmp.clear();
        _nNN_tmp.clear();

        // Set the number of neighbors to 0
        int eNN{};

        // Initialize the creaseFlag
        _creaseFlag = false;

        // [1] Create node 0 (old node 0)
        _remaskNode(0,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;


         // [1]  Create the node 1 (in the edge between 0 and 1)
        _createNodeAtEdge(0,1,2,_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [2]  Create the nodes in the edges that are joined to node0
        // This is not problematic. Apply Loop subdivision rules
        for ( int i = 2; i < _nNN[0]; i++ )
        {
            _createNodeAtEdge(0,i,i-1,i+1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            eNN++;
        }

        _createNodeAtEdge(0,_nNN[0],_nNN[0]-1,1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [3] Create the node nNN[0]+1 which is in the edge between 1 and nNN[0]:
        if(_nNN[0]+1 >= _nNN[0]+_nNN[1]-2)
            _createNodeAtEdge(1,_nNN[0],0,2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);

        else
            _createNodeAtEdge(1,_nNN[0],0,_nNN[0]+1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;


        // [4] Create the node nNN[0]+2 (old node 1)
        _remaskNode(1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        int opposite = _opposite12( );
        //[5] Create node nNN[0]+3. First check if the the edge 1-2 is a crease
        _createNodeAtEdge(1,2,0,opposite,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [6] Remask node nNN[0] -> node nNN[0]+4
        _remaskNode(_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        int sharedneighbors;
        opposite = _oppositeNNm1( sharedneighbors );

        // [7] The last node is in the edge between nodes nNN[0]-1 and nNN[0]
        _createNodeAtEdge(_nNN[0]-1,_nNN[0],0,opposite,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _subDivMat_tmp.resize(eNN*_eNN0);
        Math::MatProduct(_subDivMat_tmp.data(),eNN, _eNN, _eNN0, _subDivMat_step.data(), _subDivMat.data());
        _subDivMat = _subDivMat_tmp;
        _creasesNbors = _creasesNbors_tmp;
        _anglesNbors = _angles_tmp;
        _nNN = _nNN_tmp;
        _eNN = eNN;
    }

    // Subdivision rules for the second triangle (keeps node 1)
    void LoopExplicit::_subNodesInFirstRing1()
    {
        _subDivMat_step.clear();
        _creasesNbors_tmp.clear();
        _angles_tmp.clear();
        _nNN_tmp.clear();

        // New number of nearest neighbors of the element
        int eNN{};

        //Initialize the crease flag
        _creaseFlag = false;


        // [0] Node 0 is in the edge between nodes 0 and 1
        _createNodeAtEdge(0,1,2,_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;


        // [1] Node 1 is old node 1
        _remaskNode(1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [2] Node 2 is in the edge between nodes 1 and 2
        int opposite = _opposite12( );
        _createNodeAtEdge(1,2,0,opposite,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [3] Node 3 is in the edge between nodes 0 and 2
        _createNodeAtEdge(0,2,1,3,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [4]  Create the node 4 (old node 0)
        _remaskNode(0,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [5] Node 5 is in the edge between nodes 0 and nNN[0]
        _createNodeAtEdge(0,_nNN[0],1,_nNN[0]-1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // [6] Rotate around node 1!!! From 6 to 6+nNN[1]-2 nNN[1]-2
        int prev{}, next{};
        for ( int i = _nNN[0]; i < _nNN[0]+_nNN[1]-2; i++ )
        {
            if (i == _nNN[0] + _nNN[1]-3)
                next = 2;
            else
                next = i+1;

            _createNodeAtEdge(1,i,next, prev,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);


            if (_creasesNbors_tmp[eNN] > 0)
                prev = 2;
            else
                prev = i;

            eNN++;
        }


        // [7] Next node (if it exists) is in the edge nNN[0] - nNN[0]+1
        if (_creasesNbors[1] == 0 || _creasesNbors[_nNN[0]] == 0)
        {
            if (_nNN[0] + _nNN[1]-2 >= _eNN)
            {
                _createNodeAtEdge(_nNN[0],_nNN[0]+1,1,_nNN[0]-1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            }
            else
                _createNodeAtEdge(_nNN[0],_nNN[0]+1,1,_nNN[0] + _nNN[1]-2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            eNN++;
        }


        // [8] Create the node (nNN[0] + nNN[1]-2+1) (old node nNN[0]))
        _remaskNode(_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _subDivMat_tmp.resize(eNN*_eNN0);
        Math::MatProduct(_subDivMat_tmp.data(),eNN, _eNN, _eNN0, _subDivMat_step.data(), _subDivMat.data());
        _subDivMat = _subDivMat_tmp;
        _creasesNbors = _creasesNbors_tmp;
        _anglesNbors = _angles_tmp;
        _nNN = _nNN_tmp;
        _eNN = eNN;
    }

    // Subdivision rules for the third triangle (keeps node nNN[0])
    void LoopExplicit::_subNodesInFirstRing2()
    {

        _subDivMat_step.clear();
        _creasesNbors_tmp.clear();
        _angles_tmp.clear();
        _nNN_tmp.clear();

        _creaseFlag = false;

        // New number of nearest neighbors of the element
        int eNN{};

        _createNodeAtEdge(0,_nNN[0],1,_nNN[0]-1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _createNodeAtEdge(1,_nNN[0],0,_nNN[0]+1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _createNodeAtEdge(0,1,2,_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _remaskNode(0,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _createNodeAtEdge(0,_nNN[0]-1,_nNN[0],_nNN[0]-2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        int sharedneighbors{};
        int opposite = _oppositeNNm1( sharedneighbors );
        _createNodeAtEdge(_nNN[0]-1,_nNN[0],0,opposite,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _remaskNode(_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;


        // Add the other 2 nodes if possible
        if (_creasesNbors[1] == 0 || _creasesNbors[_nNN[0]] == 0)
        {
            if (_nNN[0] + _nNN[1]-2 >= _eNN)
                _createNodeAtEdge(_nNN[0],_nNN[0]+1,1,_nNN[0]-1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            else
                _createNodeAtEdge(_nNN[0],_nNN[0]+1,1,_nNN[0] + _nNN[1]-2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            eNN++;

            if (_nNN[0]+2 >= _nNN[0]+_nNN[1]-2)
                _createNodeAtEdge(1, _nNN[0]+1,_nNN[0],2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            else
                _createNodeAtEdge(1, _nNN[0]+1,_nNN[0],_nNN[0]+2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            eNN++;
        }

        _remaskNode(1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;


        int last{};
        if (_creasesNbors[1] == 0 || _creasesNbors[_nNN[0]] == 0)
        {
            if (_creasesNbors[_nNN[0]] == 0 || _creasesNbors[_nNN[0]+1] == 0)
            {
                last = _nNN[0]+1;
            }
            else
            {
                last = _nNN[0]-1;
            }
        }
        else
        {
            last = _nNN[0]-1;
        }


        //Rotate around node nNN[0]!!!
        int next{};
        for ( int i = _nNN[0]+_nNN[1]-2; i < _nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors; i++ )
        {
            if(i+1 == _eNN && _creasesNbors[_nNN[0]] == 0)
            {
                next = _nNN[0]-1;
            }
            else
            {
                next = i+1;
            }

            _createNodeAtEdge(_nNN[0],i,next,last,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);


            if (_creasesNbors_tmp[eNN] > 0)
                last = _nNN[0]-1;
            else
                last = i;

            eNN++;
        }

        _subDivMat_tmp.resize(eNN*_eNN0);
        Math::MatProduct(_subDivMat_tmp.data(),eNN, _eNN, _eNN0, _subDivMat_step.data(), _subDivMat.data());
        _subDivMat = _subDivMat_tmp;
        _creasesNbors = _creasesNbors_tmp;
        _anglesNbors = _angles_tmp;
        _nNN = _nNN_tmp;
        _eNN = eNN;
    }

    // Subdivision rules for the fourth (middle) triangle (it doesn't keep any original vexter of the element)
    void LoopExplicit::_subNodesInFirstRing3()
    {
        _subDivMat_step.clear();
        _creasesNbors_tmp.clear();
        _angles_tmp.clear();
        _nNN_tmp.clear();
        // New number of nearest neighbors of the element
        int eNN{};

        // Set the number of neighbors to 0
        _creaseFlag = false;


        _createNodeAtEdge(0,_nNN[0],1,_nNN[0]-1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _createNodeAtEdge(0,1,2,_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // Create node 2 (old node 0)
        _remaskNode(0,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // Node 3 is in the edge between nodes 0 and 1
        _createNodeAtEdge(0,_nNN[0]-1,_nNN[0],_nNN[0]-2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // Create nodes 4 and 5.
        int sharedneighbors{};
        int opposite = _oppositeNNm1( sharedneighbors );
        _createNodeAtEdge(_nNN[0]-1,_nNN[0],0,opposite,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _remaskNode(_nNN[0],_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;


        _createNodeAtEdge(1,_nNN[0],0,_nNN[0]+1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _remaskNode(1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        // Create the node 7 (old node 1)
        opposite = _opposite12( );
        _createNodeAtEdge(1,2,0,opposite,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;

        _createNodeAtEdge(0,2,1,3,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
        eNN++;


        // Add the other 2 nodes if possible
        if (_creasesNbors[1] == 0 || _creasesNbors[_nNN[0]] == 0)
        {
            if( _nNN[0]+2 >= _nNN[0]+_nNN[1]-2)
                _createNodeAtEdge(1,_nNN[0]+1,_nNN[0],2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            else
                _createNodeAtEdge(1,_nNN[0]+1,_nNN[0],_nNN[0]+2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            eNN++;

            if (_nNN[0] + _nNN[1]-2 >= _eNN)
                _createNodeAtEdge(_nNN[0], _nNN[0]+1,1,_nNN[0]-1,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            else
                _createNodeAtEdge(_nNN[0], _nNN[0]+1,1,_nNN[0] + _nNN[1]-2,_nNN_tmp,_creasesNbors_tmp,_angles_tmp, _subDivMat_step);
            eNN++;
        }

        _subDivMat_tmp.resize(eNN*_eNN0);
        Math::MatProduct(_subDivMat_tmp.data(),eNN, _eNN, _eNN0, _subDivMat_step.data(), _subDivMat.data());

        _subDivMat = _subDivMat_tmp;
        _creasesNbors = _creasesNbors_tmp;
        _anglesNbors = _angles_tmp;
        _nNN = _nNN_tmp;
        _eNN = eNN;
    }


    // ---------------------------------------------------------------------------------------
    // ---------------------------------------------------------------------------------------

    // ---------------------------------------------------------------------------------------
    // Limit masks (Appendix A of [4])
    // ---------------------------------------------------------------------------------------
    void LoopExplicit::_limitMaskNode1( )
    {
        int i,j;
            double ival; //Valence of node 1

        int crease;

        double c0, c1, c2, c3, c4;

        double xi, beta;
        double gamma,delta;

        int d;

        std::vector < std::vector <double> > impBFs;
        double *hpl_k;
        double *p_k, *dp_k, *hp_k;


        int Maux[4];
        Array::Copy(Maux,4,_transform);
        _transform[0] = Maux[2];         _transform[1] = Maux[3];
        _transform[2] = -(Maux[0]+Maux[2]);  _transform[3] = -(Maux[1]+Maux[3]);

        //---------------------------------------------
        //This is to compute the Hessians
        RCP<LoopImplicit> ssimp = rcp(new LoopImplicit);
        //In the case of a regular crease vertex, we can the hessians are well-defined
        if ( _nNN[1] == 4 )
        {
            //This is important, everything with the implicit class is going to be calculated with the oneSampleFLag
            //regardless whether the oneSampleFlag of the explicit class is ON or OFF.
            ssimp->setElementValence(6);
            ssimp->Update();

            impBFs.resize(3);
            ssimp->ComputeBasisFunctions(impBFs,0.0,0.0);

            // Compute the Box-Splines basis functions and derivatives at v,w
            hpl_k   = impBFs[2].data();
        }
        //---------------------------------------------

        _plimit_k.resize(_eNN);
        _dplimit_k.resize(2*_eNN);
        _hplimit_k.resize(4*_eNN);

        p_k    = _plimit_k.data();
        dp_k   = _dplimit_k.data();
        hp_k   = _hplimit_k.data();

        Array::Fill(p_k,_eNN, 0.0);
        Array::Fill(dp_k,2*_eNN, 0.0);
        Array::Fill(hp_k,4*_eNN, 0.0);

        // It is a creased node:
        if ( _creasesNbors[1] == 1 )
        {

            ival = static_cast<double>(_nNN[1]);

            //---------------------------------------------------------
            // Constants from [3]
            xi   = M_PI/(ival-1.0);


            delta = 1.0/8.0;
            gamma = 0.5 - 0.25*cos(xi);
            beta = acos( 0.5*(0.25 - gamma)/delta);

            c1 = (1.0 - 2.0*delta - gamma)/(3.0*(2.0*delta + gamma - 0.25));
            c2 = (2.0/3.0 - c1)/cos((ival-1.0)*beta/2.0);

            c3 = sin(xi)/(1.0 - cos(xi));
            c4 = cos( (ival-1.0)*beta/2.0 )*sin(xi)/(cos(beta) - cos(xi));

            c0 = 0.5;

            //---------------------------------------------------------
            //values on the creased node
            p_k[1]      = 2.0/3.0;
            dp_k[2*1+0] = 0.0;
            dp_k[2*1+1] = -2.0/(ival-1.0)*((2.0/3.0-c1)*c3-c2*c4);

            //In the case of a regular crease vertex, the hessians are well-defined
            if ( _nNN[1] == 4 )
            {
                hp_k[4*1+0] = hpl_k[4*0+0]+hpl_k[4*5+0]+hpl_k[4*6+0];
                hp_k[4*1+1] = hpl_k[4*0+1]+hpl_k[4*5+1]+hpl_k[4*6+1];
                hp_k[4*1+2] = hpl_k[4*0+2]+hpl_k[4*5+2]+hpl_k[4*6+2];
                hp_k[4*1+3] = hpl_k[4*0+3]+hpl_k[4*5+3]+hpl_k[4*6+3];
            }
            //---------------------------------------------------------

            // Look for the first crease in the neighborhood (the second is always the last one or 2!):
            for ( i = _nNN[0]; i < _nNN[0]+_nNN[1]-2; i++)
            {
                if (_creasesNbors[i] > 0)
                {
                    crease = i;
                    i =_nNN[0]+_nNN[1]-2; //Get me out of here!
                }
            }

            // Loop around node 1 to set the basis functions and derivatives
            for ( i = _nNN[0]; i < _nNN[0]+_nNN[1]-2; i++)
            {
                if (_creasesNbors[i] > 0)
                {
                    p_k[i]      = 1.0/6.0;
                    if( i == crease )
                        dp_k[2*i+0] = c0;
                    else
                        dp_k[2*i+0] = -c0;
                    dp_k[2*i+1] = -2.0/(ival-1.0) * ((0.5*c1+1.0/6.0)*c3+0.5*c2*c4);

                    //Hessians for regular node
                    if ( _nNN[1] == 4 )
                    {
                        if( i == crease )
                        {
                            hp_k[4*i+0] = hpl_k[4*1+0]+hpl_k[4*6+0];
                            hp_k[4*i+1] = hpl_k[4*1+1]+hpl_k[4*6+1];
                            hp_k[4*i+2] = hpl_k[4*1+2]+hpl_k[4*6+2];
                            hp_k[4*i+3] = hpl_k[4*1+3]+hpl_k[4*6+3];
                        }
                        else
                        {
                            hp_k[4*i+0] = hpl_k[4*4+0]+hpl_k[4*5+0];
                            hp_k[4*i+1] = hpl_k[4*4+1]+hpl_k[4*5+1];
                            hp_k[4*i+2] = hpl_k[4*4+2]+hpl_k[4*5+2];
                            hp_k[4*i+3] = hpl_k[4*4+3]+hpl_k[4*5+3];
                        }
                    }
                }
                else
                {
                    p_k[i]      = 0.0;
                    dp_k[2*i+0] = 0.0;

                    if (i < crease)
                        d = crease-i+1;
                    else
                        d = _nNN[0]+ _nNN[1]- 3 - i + 1 ;
                    dp_k[2*i+1] = 2.0/(ival-1.0)*sin(xi*(d-1.0));

                    //Hessians for regular node
                    if ( _nNN[1] == 4 )
                    {
                        if( ( i < crease && d == 2 ) || ( i > crease && d == 3 ) )
                        {
                            hp_k[4*i+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                            hp_k[4*i+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                            hp_k[4*i+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                            hp_k[4*i+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                        }
                        else
                        {
                            hp_k[4*i+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                            hp_k[4*i+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                            hp_k[4*i+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                            hp_k[4*i+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                        }
                    }

                }
            }

            // Node 2 and 0 (different if 2 is crease or not):
            if (_creasesNbors[2] > 0)
            {
                p_k[2]      = 1.0/6.0;
                dp_k[2*2+0] = -c0;
                dp_k[2*2+1] = -2.0/(ival-1.0) * ((0.5*c1+1.0/6.0)*c3+0.5*c2*c4);


                //Hessians for regular node
                if ( _nNN[1] == 4 )
                {
                    hp_k[4*2+0] = hpl_k[4*4+0]+hpl_k[4*5+0];
                    hp_k[4*2+1] = hpl_k[4*4+1]+hpl_k[4*5+1];
                    hp_k[4*2+2] = hpl_k[4*4+2]+hpl_k[4*5+2];
                    hp_k[4*2+3] = hpl_k[4*4+3]+hpl_k[4*5+3];
                }

                // Node 0:
                p_k[0]      = 0.0;
                dp_k[2*0+0] = 0.0;
                d = 2;
                dp_k[2*0+1] = 2.0/(ival-1.0)*sin(xi*(d-1.0));

                if ( _nNN[1] == 4 )
                {
                    hp_k[4*0+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                    hp_k[4*0+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                    hp_k[4*0+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                    hp_k[4*0+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                }
            }
            else
            {
                //Node 2:
                p_k[2]      = 0.0;
                dp_k[2*2+0] = 0.0;
                d = _nNN[0] + _nNN[1] - 3 - crease + 1;
                dp_k[2*2+1] = 2.0/(ival-1.0)*sin(xi*(d-1.0));

                if ( _nNN[1] == 4 )
                {
                    if  ( d == 3 )
                    {
                        hp_k[4*2+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                        hp_k[4*2+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                        hp_k[4*2+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                        hp_k[4*2+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                    }
                    else
                    {
                        hp_k[4*2+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                        hp_k[4*2+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                        hp_k[4*2+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                        hp_k[4*2+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                    }
                }

                // Node 0:
                p_k[0]      = 0.0;
                dp_k[2*0+0] = 0.0;
                d = _nNN[0] + _nNN[1] - 3 - crease + 2;
                dp_k[2*0+1] = 2.0/(ival-1.0)*sin(xi*(d-1.0));

                if ( _nNN[1] == 4 )
                {
                    if  ( d == 3 )
                    {
                        hp_k[4*0+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                        hp_k[4*0+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                        hp_k[4*0+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                        hp_k[4*0+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                    }
                    else
                    {
                        hp_k[4*0+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                        hp_k[4*0+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                        hp_k[4*0+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                        hp_k[4*0+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                    }
                }
            }


        }
        else // corner
        {
            //---------------------------------------------------------
            //values on the corner
            p_k[1]      = 1.0;
            dp_k[2*1+0] = -1.0;
            dp_k[2*1+1] = -1.0;
            //---------------------------------------------------------

            j = 0;
            // Loop around node 1 to set the basis functions and derivatives
            for ( i = _nNN[0]; i < _nNN[0]+_nNN[1]-2; i++)
            {
                if (_creasesNbors[i] > 0)
                {
                    p_k[i]  = 0.0;
                    dp_k[2*i+j] = 1.0;
                    j++;
                }
            }
            if (_creasesNbors[2] > 0)
            {
                p_k[2]  = 0.0;
                dp_k[2*2+j] = 1.0;
                j++;
            }
        }

    }

    void LoopExplicit::_limitMaskNodeN( )
    {
        int i,j;
        double ival; //Valence of node N

        int crease, nodeN, sharedneighbors;

        double c0, c1, c2, c3, c4;

        double xi, beta;

        double delta,gamma;

        int d;

        std::vector < std::vector <double> > impBFs;
        double *p_k, *dp_k, *hp_k;


        nodeN = _nNN[0];

        int Maux[4];
        Array::Copy(Maux,4,_transform);
        _transform[0] = Maux[2];             _transform[1] = Maux[3];
        _transform[2] = -(Maux[0]+Maux[2]);  _transform[3] = -(Maux[1]+Maux[3]);


        //---------------------------------------------
        //This is to compute the Hessians
        RCP<LoopImplicit> ssimp = rcp ( new LoopImplicit ); ///< Subdivision implicit
        double *hpl_k;
        //In the case of a regular crease vertex, we can the hessians are well-defined
        if ( _nNN[nodeN] == 4 )
        {
            //This is important, everything with the implicit class is going to be calculated with the oneSampleFLag
            //regardless whether the oneSampleFlag of the explicit class is ON or OFF.
            ssimp->setElementValence(6);
            ssimp->Update();

            impBFs.resize(3);
            ssimp->ComputeBasisFunctions(impBFs,0.0,0.0);

            // Compute the Box-Splines basis functions and derivatives at v,w
            hpl_k   = impBFs[2].data();
        }
        //---------------------------------------------

        _plimit_k.resize(_eNN);
        _dplimit_k.resize(2*_eNN);
        _hplimit_k.resize(4*_eNN);

        p_k    = _plimit_k.data();
        dp_k   = _dplimit_k.data();
        hp_k   = _hplimit_k.data();

        Array::Fill(p_k,_eNN, 0.0);
        Array::Fill(dp_k,2*_eNN, 0.0);
        Array::Fill(hp_k,4*_eNN, 0.0);

        // It is a creased node:
        if ( _creasesNbors[nodeN] == 1 )
        {

            ival = static_cast<double>(_nNN[_nNN[0]]);

            //---------------------------------------------------------
            // Constants from [3]
            xi   = M_PI/(ival-1.0);
            delta = 1.0/8.0;
            gamma = 0.5 - 0.25*cos(xi);
            beta = acos( 0.5*(0.25 - gamma)/delta);

            c1 = (1.0 - 2.0*delta - gamma)/(3.0*(2.0*delta + gamma - 0.25));
            c2 = (2.0/3.0 - c1)/cos((ival-1.0)*beta/2.0);
            c3 = sin(xi)/(1.0 - cos(xi));
            c4 = cos( (ival-1.0)*beta/2.0 )*sin(xi)/(cos(beta) - cos(xi));
            c0 = 0.5;

            //---------------------------------------------------------


            //---------------------------------------------------------
            //values on the creased node
            p_k[nodeN]      = 2.0/3.0;
            dp_k[2*nodeN+0] = 0.0;
            dp_k[2*nodeN+1] = -2.0/(ival-1.0)*((2.0/3.0-c1)*c3-c2*c4);

            //In the case of a regular crease vertex, we can the hessians are well-defined
            if ( _nNN[nodeN] == 4 )
            {
                hp_k[4*nodeN+0] = hpl_k[4*0+0]+hpl_k[4*5+0]+hpl_k[4*6+0];
                hp_k[4*nodeN+1] = hpl_k[4*0+1]+hpl_k[4*5+1]+hpl_k[4*6+1];
                hp_k[4*nodeN+2] = hpl_k[4*0+2]+hpl_k[4*5+2]+hpl_k[4*6+2];
                hp_k[4*nodeN+3] = hpl_k[4*0+3]+hpl_k[4*5+3]+hpl_k[4*6+3];
            }
            //---------------------------------------------------------

            //---------------------------------------------------------

            crease = -1;
            sharedneighbors = 4;

            // Look for the first crease!
            if (_creasesNbors[1] > 0)
            {

                crease =_nNN[0]+_nNN[1]-3;
                sharedneighbors = 3;
            }
            else if (_creasesNbors[nodeN+1] > 0)
            {
                crease =_nNN[0]+_nNN[1]-3;
            }


            // If the crease wasn't in one of the previous nodes let's look for it
            if ( crease < 0 )
            {
                // Look for the first crease in the neighborhood (the second is always the last one!):
                for ( i = _nNN[0]+_nNN[1]-2; i < _nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors; i++)
                {
                    if (_creasesNbors[i] > 0)
                    {
                        crease = i;
                        i =_nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors; //Get me out of here!
                    }
                }
            }

            // Node 0
            p_k[0]      = 0.0;
            dp_k[2*0+0] = 0.0;
            if ( sharedneighbors == 3 ) // crease in 1-N
                d = 2;
            else
                d = crease-(_nNN[0]+_nNN[1]-3-2)+1;
            dp_k[2*0+1] =2.0/(ival-1.0)*sin(xi*(d-1.0));

            //Hessians for regular node
            if ( _nNN[nodeN] == 4 )
            {
                if  ( d == 3 )
                {
                    hp_k[4*0+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                    hp_k[4*0+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                    hp_k[4*0+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                    hp_k[4*0+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                }
                else
                {
                    hp_k[4*0+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                    hp_k[4*0+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                    hp_k[4*0+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                    hp_k[4*0+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                }
            }

            if (_creasesNbors[1] > 0)
            {
                p_k[1]      = 1.0/6.0;
                dp_k[2*1+0] = -c0;
                dp_k[2*1+1] = -2.0/(ival-1.0) * ((0.5*c1+1.0/6.0)*c3+0.5*c2*c4);

                //Hessians for regular node
                if ( _nNN[nodeN] == 4 )
                {
                    hp_k[4*1+0] = hpl_k[4*4+0]+hpl_k[4*5+0];
                    hp_k[4*1+1] = hpl_k[4*4+1]+hpl_k[4*5+1];
                    hp_k[4*1+2] = hpl_k[4*4+2]+hpl_k[4*5+2];
                    hp_k[4*1+3] = hpl_k[4*4+3]+hpl_k[4*5+3];
                }
            }
            else
            {
                p_k[1]      = 0.0;
                dp_k[2*1+0] = 0.0;
                d = crease-(_nNN[0]+_nNN[1]-3-1)+1;
                dp_k[2*1+1] =2.0/(ival-1.0)*sin(xi*(d-1.0));

                //Hessians for regular node
                if ( _nNN[nodeN] == 4 )
                {
                    if  ( d == 3 )
                    {
                        hp_k[4*1+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                        hp_k[4*1+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                        hp_k[4*1+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                        hp_k[4*1+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                    }
                    else
                    {
                        hp_k[4*1+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                        hp_k[4*1+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                        hp_k[4*1+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                        hp_k[4*1+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                    }
                }

                if (_creasesNbors[nodeN+1] > 0)
                {
                    p_k[nodeN+1]      = 1.0/6.0;
                    dp_k[2*(nodeN+1)+0] = -c0;
                    dp_k[2*(nodeN+1)+1] = -2.0/(ival-1.0) * ((0.5*c1+1.0/6.0)*c3+0.5*c2*c4);

                    //Hessians for regular node
                    if ( _nNN[nodeN] == 4 )
                    {
                        hp_k[4*(nodeN+1)+0] = hpl_k[4*4+0]+hpl_k[4*5+0];
                        hp_k[4*(nodeN+1)+1] = hpl_k[4*4+1]+hpl_k[4*5+1];
                        hp_k[4*(nodeN+1)+2] = hpl_k[4*4+2]+hpl_k[4*5+2];
                        hp_k[4*(nodeN+1)+3] = hpl_k[4*4+3]+hpl_k[4*5+3];
                    }

                }
                else
                {
                    p_k[(nodeN+1)]      = 0.0;
                    dp_k[2*(nodeN+1)+0] = 0.0;
                    d = crease-(_nNN[0]+_nNN[1]-3)+1;
                    dp_k[2*(nodeN+1)+1] =2.0/(ival-1.0)*sin(xi*(d-1.0));

                    //Hessians for regular node
                    if ( _nNN[nodeN] == 4 )
                    {
                        if  ( d == 3 )
                        {
                            hp_k[4*(nodeN+1)+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                            hp_k[4*(nodeN+1)+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                            hp_k[4*(nodeN+1)+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                            hp_k[4*(nodeN+1)+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                        }
                        else
                        {
                            hp_k[4*(nodeN+1)+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                            hp_k[4*(nodeN+1)+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                            hp_k[4*(nodeN+1)+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                            hp_k[4*(nodeN+1)+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                        }
                    }

                }
            }

            if (_creasesNbors[nodeN-1] > 0)
            {
                p_k[nodeN-1]      = 1.0/6.0;
                dp_k[2*(nodeN-1)+0] = c0;
                dp_k[2*(nodeN-1)+1] = -2.0/(ival-1.0) * ((0.5*c1+1.0/6.0)*c3+0.5*c2*c4);

                //Hessians for regular node
                if ( _nNN[nodeN] == 4 )
                {
                    hp_k[4*(nodeN-1)+0] = hpl_k[4*1+0]+hpl_k[4*6+0];
                    hp_k[4*(nodeN-1)+1] = hpl_k[4*1+1]+hpl_k[4*6+1];
                    hp_k[4*(nodeN-1)+2] = hpl_k[4*1+2]+hpl_k[4*6+2];
                    hp_k[4*(nodeN-1)+3] = hpl_k[4*1+3]+hpl_k[4*6+3];
                }
            }
            else
            {
                p_k[(nodeN-1)]      = 0.0;
                dp_k[2*(nodeN-1)+0] = 0.0;
                if ( sharedneighbors == 3 )
                    d = 3.0;
                else
                    d = crease-(_nNN[0]+_nNN[1]-3-3)+1;
                dp_k[2*(nodeN-1)+1] =2.0/(ival-1.0)*sin(xi*(d-1.0));

                //Hessians for regular node
                if ( _nNN[nodeN] == 4 )
                {
                    if  ( d == 3 )
                    {
                        hp_k[4*(nodeN-1)+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                        hp_k[4*(nodeN-1)+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                        hp_k[4*(nodeN-1)+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                        hp_k[4*(nodeN-1)+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                    }
                    else
                    {
                        hp_k[4*(nodeN-1)+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                        hp_k[4*(nodeN-1)+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                        hp_k[4*(nodeN-1)+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                        hp_k[4*(nodeN-1)+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                    }
                }
            }

            // Loop around nodeN to set the basis functions and derivatives
            for ( i = _nNN[0]+_nNN[1]-2; i < _nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors; i++)
            {

                if (_creasesNbors[i] > 0)
                {
                    p_k[i]      = 1.0/6.0;
                    if (i == crease)
                        dp_k[2*i+0] = -c0;
                    else
                        dp_k[2*i+0] = c0;
                    dp_k[2*i+1] = -2.0/(ival-1.0) * ((0.5*c1+1.0/6.0)*c3+0.5*c2*c4);

                    //Hessians for regular node
                    if ( _nNN[nodeN] == 4 )
                    {
                        if( i != crease )
                        {
                            hp_k[4*i+0] = hpl_k[4*1+0]+hpl_k[4*6+0];
                            hp_k[4*i+1] = hpl_k[4*1+1]+hpl_k[4*6+1];
                            hp_k[4*i+2] = hpl_k[4*1+2]+hpl_k[4*6+2];
                            hp_k[4*i+3] = hpl_k[4*1+3]+hpl_k[4*6+3];
                        }
                        else
                        {
                            hp_k[4*i+0] = hpl_k[4*4+0]+hpl_k[4*5+0];
                            hp_k[4*i+1] = hpl_k[4*4+1]+hpl_k[4*5+1];
                            hp_k[4*i+2] = hpl_k[4*4+2]+hpl_k[4*5+2];
                            hp_k[4*i+3] = hpl_k[4*4+3]+hpl_k[4*5+3];
                        }
                    }
                }
                else
                {
                    p_k[i]      = 0.0;
                    dp_k[2*i+0] = 0.0;

                    if (i < crease)
                        d = crease-i+1;
                    else
                        d = _nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors-1-i+1;
                    dp_k[2*i+1] =2.0/(ival-1.0)*sin(xi*(d-1.0));

                    //Hessians for regular node
                    if ( _nNN[nodeN] == 4 )
                    {
                        if( (i<crease && d == 3) || (i>crease && d == 2) )
                        {
                            hp_k[4*i+0] = hpl_k[4*2+0]-hpl_k[4*6+0];
                            hp_k[4*i+1] = hpl_k[4*2+1]-hpl_k[4*6+1];
                            hp_k[4*i+2] = hpl_k[4*2+2]-hpl_k[4*6+2];
                            hp_k[4*i+3] = hpl_k[4*2+3]-hpl_k[4*6+3];
                        }
                        else
                        {
                            hp_k[4*i+0] = hpl_k[4*3+0]-hpl_k[4*5+0];
                            hp_k[4*i+1] = hpl_k[4*3+1]-hpl_k[4*5+1];
                            hp_k[4*i+2] = hpl_k[4*3+2]-hpl_k[4*5+2];
                            hp_k[4*i+3] = hpl_k[4*3+3]-hpl_k[4*5+3];
                        }
                    }
                }
            }

        }
        else // corner
        {
            //---------------------------------------------------------
            //values on the corner
            p_k[nodeN]      =  1.0;
            dp_k[2*nodeN+0] = -1.0;
            dp_k[2*nodeN+1] = -1.0;
            //---------------------------------------------------------

            j = 0;
            if (_creasesNbors[1] > 0)
            {
                p_k[1]  = 0.0;
                dp_k[2*1+j] = 1.0;
                j++;
                sharedneighbors = 3;
            }
            else
            {
                sharedneighbors = 4;
                if (_creasesNbors[nodeN+1] > 0)
                {
                    p_k[nodeN+1]  = 0.0;
                    dp_k[2*(nodeN+1)+j] = 1.0;
                    j++;
                }
            }
            if (_creasesNbors[nodeN-1] > 0)
            {
                p_k[nodeN-1]  = 0.0;
                dp_k[2*(nodeN-1)+j] = 1.0;
                j++;
            }

            // Loop around node 2 to set the basis functions and derivatives
            for ( i = _nNN[0]+_nNN[1]-2; i < _nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors; i++)
            {
                if (_creasesNbors[i] > 0)
                {
                    p_k[i]  = 0.0;
                    dp_k[2*i+j] = 1.0;
                    j++;
                }
            }
        }

    }

    // ---------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------
    //SUBDIVISION RULES!!!
    //This creates a new node at the edge given by nodeEdge0 and nodeEdge1. If the edge is not marked as crease,
    // nodeOp0 and nodeOp1 are the opposite nodes to the edge and nodeOut is the numbering of the new node in the new subdivision level
    // nNN, idN_creasesL, angles and Amat are the number of neighbors to each node, the id of the creases, the angles at each point and them
    // subdivision matrix at the new level of subdivision (these are updated by this function)
    void LoopExplicit::_createNodeAtEdge(int nodeEdge0, int nodeEdge1, int nodeOp0, int nodeOp1, std::vector<int>& nNN, std::vector<int>& idN_creasesL, std::vector<double>& angles, std::vector<double>& Amat)
    {
        double gamma;

        //Add new row
        int nodeOut = nNN.size();
        Amat.resize(Amat.size()+_eNN);

        //Case of creased edge
        if (_creasesNbors[nodeEdge0] > 0 && _creasesNbors[nodeEdge1] > 0) //CREASED EDGE
        {
            Amat[ nodeOut*_eNN+nodeEdge0 ] = 0.5;
            Amat[ nodeOut*_eNN+nodeEdge1 ] = 0.5;
            nNN.push_back(4);

            idN_creasesL.push_back(1);
            _creaseFlag = true;
            angles.push_back(M_PI);
        }
        else if (_creasesNbors[nodeEdge0] > 0 )
        {
            if(_anglesNbors[nodeEdge0]<M_PI)
                gamma = 0.5-0.25*cos(_anglesNbors[nodeEdge0]/static_cast<double>(_nNN[nodeEdge0]-1));
            else
                gamma = 0.5-0.25*cos((2.0*M_PI-_anglesNbors[nodeEdge0])/static_cast<double>(_nNN[nodeEdge0]-1));

            Amat[ nodeOut*_eNN+nodeEdge0 ] = 0.75-gamma;
            Amat[ nodeOut*_eNN+nodeEdge1 ] = gamma;
            Amat[ nodeOut*_eNN+nodeOp0   ] = 0.125;
            Amat[ nodeOut*_eNN+nodeOp1   ] = 0.125;

            idN_creasesL.push_back(0);
            nNN.push_back(6);
            angles.push_back(2.0*M_PI);
        }
        else if (_creasesNbors[nodeEdge1] > 0)
        {
            if(_anglesNbors[nodeEdge1]<M_PI)
                gamma = 0.5-0.25*cos(_anglesNbors[nodeEdge1]/static_cast<double>(_nNN[nodeEdge1]-1));
            else
                gamma = 0.5-0.25*cos((2.0*M_PI-_anglesNbors[nodeEdge1])/static_cast<double>(_nNN[nodeEdge1]-1));


            Amat[ nodeOut*_eNN+nodeEdge0 ] = gamma;
            Amat[ nodeOut*_eNN+nodeEdge1 ] = 0.75-gamma;
            Amat[ nodeOut*_eNN+nodeOp0   ] = 0.125;
            Amat[ nodeOut*_eNN+nodeOp1   ] = 0.125;

            idN_creasesL.push_back(0);
            nNN.push_back(6);
            angles.push_back(2.0*M_PI);
        }
        else //ABSENCE OF TAGS -> STANDARD RULE
        {

            Amat[ nodeOut*_eNN+nodeEdge0 ] = 0.375;
            Amat[ nodeOut*_eNN+nodeEdge1 ] = 0.375;
            Amat[ nodeOut*_eNN+nodeOp0   ] = 0.125;
            Amat[ nodeOut*_eNN+nodeOp1   ] = 0.125;

            idN_creasesL.push_back(0);
            nNN.push_back(6);
            angles.push_back(2.0*M_PI);
        }

        return;

    }

    // This puts and old node (with label nodeIn) in the new subdivision level nodeOut.
    // nNN, idN_creasesL, angles and Amat are the number of neighbors to each node, the id of the creases, the angles at each point and them
    // subdivision matrix at the new level of subdivision (these are updated by this function)
    void LoopExplicit::_remaskNode(int nodeIn, std::vector<int>& nNN, std::vector<int>& idN_creasesL, std::vector<double>& angles, std::vector<double>& Amat)
    {
        using namespace std;

        double subParam{};


        int nodeOut = nNN.size();
        Amat.resize(Amat.size()+_eNN);
        _neighbors(nodeIn);

        if (_creasesNbors[nodeIn] == 0)
        {
            subParam  = (0.375+0.25*cos(2.0*M_PI/_nNN[nodeIn]));
            subParam *= subParam;
            subParam  = 0.625-subParam;
            subParam /= static_cast<double>(_nNN[nodeIn]);

            Amat[ nodeOut*_eNN+nodeIn ] = 1.0-_nNN[nodeIn]*subParam;
            for (int i = 0; i < _nNN[nodeIn]; i++ )
            {
                Amat[ nodeOut*_eNN+_neighborsNode_tmp[i] ] = subParam;
            }
        }
        else if (_creasesNbors[nodeIn] == 1)
        {
            Amat[ nodeOut*_eNN+nodeIn ] = 0.75;
            for (int i = 0; i < _nNN[nodeIn]; i++ )
            {
                if(_creasesNbors[_neighborsNode_tmp[i]] > 0)
                    Amat[ nodeOut*_eNN+_neighborsNode_tmp[i] ] = 0.125;
            }

            _creaseFlag = true;
        }
        else if (_creasesNbors[nodeIn] == 2)
        {
            Amat[ nodeOut*_eNN+nodeIn ] = 1.0;

            _creaseFlag = true;
        }

        idN_creasesL.push_back(_creasesNbors[nodeIn]);
        nNN.push_back(_nNN[nodeIn]);
        angles.push_back(_anglesNbors[nodeIn]);
    }
    //----------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------
    //AUXILIARY!!!

    // Rotate the triangle to put the irregular node at position 0
    void LoopExplicit::_rotateTriangle( )
    {
        _creasesNbors_tmp.resize(_eNN);
        _subDivMat_step.resize(_eNN*_eNN);
        _subDivMat_tmp.resize(_eNN*_eNN0);
        _nNN_tmp.resize(_eNN);
        _angles_tmp.resize(_eNN);

        std::fill(_subDivMat_step.begin(),_subDivMat_step.end(),0.0);

        //WE ASSUME NO CREASE/CORNER IN THE TRIANGLE!!!!!
        //Rotate the IntegType::Master triangle
        // 0  <- 1
        // 1  <- N
        // N' <- 0
        _nNN_tmp[0]                = _nNN[1];
        _nNN_tmp[1]                = _nNN[_nNN[0]];
        _nNN_tmp[_nNN_tmp[0]]          = _nNN[0];
        _creasesNbors_tmp[0]       = _creasesNbors[1];
        _creasesNbors_tmp[1]       = _creasesNbors[_nNN[0]];
        _creasesNbors_tmp[_nNN_tmp[0]] = _creasesNbors[0];
        _angles_tmp[0] = _anglesNbors[1];
        _angles_tmp[1] = _anglesNbors[_nNN[0]];
        _angles_tmp[_nNN_tmp[0]] = _anglesNbors[0];
        _subDivMat_step[ 0*_eNN      +1           ] = 1.0;
        _subDivMat_step[ 1*_eNN      +_nNN[0]] = 1.0;
        _subDivMat_step[ _nNN_tmp[0]*_eNN+0           ] = 1.0;


        //2 is now the old N+1
        for ( int i = 1; i < _nNN_tmp[0] - 2; i++)
        {
            _creasesNbors_tmp[1+i] = _creasesNbors[_nNN[0]+i];
            _angles_tmp[1+i]       = _anglesNbors[_nNN[0]+i];
            _nNN_tmp[1+i]          = _nNN[1+i];
            _subDivMat_step[(i+1)*_eNN+_nNN[0]+i ] = 1.0;
        }
        _creasesNbors_tmp[_nNN_tmp[0] - 1] = _creasesNbors[2];
        _angles_tmp[_nNN_tmp[0] - 1] = _anglesNbors[2];
        _nNN_tmp[_nNN_tmp[0] - 1] = _nNN[2];
        _subDivMat_step[(_nNN_tmp[0]-1)*_eNN+2] = 1.0;

        _creasesNbors_tmp[_nNN_tmp[0] + 1] = _creasesNbors[_nNN[0]-1];
        _angles_tmp[_nNN_tmp[0] + 1] = _anglesNbors[_nNN[0]-1];
        _nNN_tmp[_nNN_tmp[0] + 1] = _nNN[_nNN[0]-1];
        _subDivMat_step[(_nNN_tmp[0]+1)*_eNN+_nNN[0]-1] = 1.0;

        for ( int i = 1; i < _nNN_tmp[1]-3; i++ )
        {
             _creasesNbors_tmp[_nNN_tmp[0] + i + 1] = _creasesNbors[_eNN-i];
             _angles_tmp[_nNN_tmp[0] + i + 1] = _anglesNbors[_eNN-i];
             _nNN_tmp[_nNN_tmp[0] + i + 1] = _nNN[_eNN-i];
             _subDivMat_step[(_nNN_tmp[0] + i + 1)*_eNN+_eNN-i] = 1.0;
        }

        for ( int i = 0; i < _nNN_tmp[_nNN_tmp[0]]-4; i++ )
        {
             _creasesNbors_tmp[_nNN_tmp[0] + _nNN_tmp[1] -2 + i] = _creasesNbors[_nNN[0]-2-i];
             _angles_tmp[_nNN_tmp[0] + _nNN_tmp[1] -2 + i] = _anglesNbors[_nNN[0]-2-i];
             _nNN_tmp[_nNN_tmp[0] + _nNN_tmp[1] -2 + i] = _nNN[_nNN[0]-2-i];
             _subDivMat_step[(_nNN_tmp[0] + _nNN_tmp[1] -2 + i)*_eNN+_nNN[0]-2-i] = 1.0;
        }
        Math::MatProduct(_subDivMat_tmp.data(),_eNN, _eNN, _eNN0, _subDivMat_step.data(), _subDivMat.data());
        _subDivMat = _subDivMat_tmp;
        _creasesNbors = _creasesNbors_tmp;
        _anglesNbors = _angles_tmp;
        _nNN = _nNN_tmp;
    }

    //This function computes the neighbors of the node (this node HAS to lie on the primary element)
    void LoopExplicit::_neighbors(int node)
    {

        int sharedneighbors{};

        _neighborsNode_tmp.clear();

        if(node == 0)
        {
            for(int i = 0; i < _nNN[0]; i++)
            {
                _neighborsNode_tmp.push_back(i+1);
            }
        }
        else if (node==1)
        {
            _neighborsNode_tmp.push_back(0);
            _neighborsNode_tmp.push_back(2);
            for (int i = 0; i < _nNN[1]-2; i++ )
            {
                _neighborsNode_tmp.push_back(_nNN[0]+i);
            }
        }
        else if (node == _nNN[0])
        {
            if (_creasesNbors[_nNN[0]] == 0)
            {
                sharedneighbors = 4;
            }
            else
            {

                if (_creasesNbors[1] > 0)
                {
                    // If there is a crease in the edge 1-nNN[0], then there is only three neighbors of node nNN[0] that are shared with nodes 0 and 1
                    // (node nNN[0]+1 is not a neighbor of node nNN[0] as it is for a patch without creases).
                    sharedneighbors = 3;
                }
                else
                {
                    // Normal number of shared neighbors!
                    sharedneighbors = 4;
                }
            }
            _neighborsNode_tmp.push_back(0);
            _neighborsNode_tmp.push_back(1);
            _neighborsNode_tmp.push_back(_nNN[0]-1);
            if(sharedneighbors==4)
                _neighborsNode_tmp.push_back(_nNN[0]+1);
            for ( int i = 0; i < _nNN[_nNN[0]]-sharedneighbors; i++ )
            {
                _neighborsNode_tmp.push_back(_nNN[0]+_nNN[1]-2+i);
            }
        }

        return;
    }

    //This gives the opposite node to the edge N N-1 (different than 0) and also computes the number of
    //shared neighbors between nodes N, 0 and 1
    int LoopExplicit::_oppositeNNm1( int &sharedneighbors )
    {
        int opposite{-1};  // This is the node neighbor to node nNN[0] that is opposite to the edge nNN[0]-1 - nNN[0] and is not the node 0 (it does not exist if there is a crease between nodes nNN[0]-1 and nNN[0], but in this case it doesn't matter since we only use this information if there is no crease between them)

        if (_creasesNbors[_nNN[0]] == 0)
        {
            opposite = _eNN-1;
            sharedneighbors = 4;
        }
        else
        {
            if (_creasesNbors[1] > 0)
            {
                // If there is a crease in the edge 1-nNN[0], then there is only three neighbors of node nNN[0] that are shared with nodes 0 and 1
                // (node nNN[0]+1 is not a neighbor of node nNN[0] as it is for a patch without creases).
                sharedneighbors = 3;
                opposite = _nNN[0]+_nNN[1]-2;
            }
            else
            {
                // Normal number of shared neighbors!
                sharedneighbors = 4;
                if (_creasesNbors[_nNN[0]+1] > 0)
                {
                    opposite = _nNN[0]+_nNN[1]-2;
                }
            }
            if (opposite  == -1)
            {
                for ( int i = _nNN[0]+_nNN[1]-2; i < _nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors; i++ )
                {
                    if(_creasesNbors[i] > 0)
                    {
                        opposite = i+1;
                        i = _nNN[0]+_nNN[1]-2+_nNN[_nNN[0]]-sharedneighbors;
                    }
                }
            }
        }

        return opposite;
    }

    //This computes the opposite node to the edge 1-2 that is not 0
    int LoopExplicit::_opposite12( )
    {
        int opposite{-1};

        // Calculate the opposite node to 0 from the edge 1-2 !!!
        if (_creasesNbors[1] == 0)
        {
            opposite = _nNN[0]+_nNN[1]-3;
        }
        else
        {
            for ( int i = _nNN[0]; i < _nNN[0]+_nNN[1]-2; i++ )
            {
                if(_creasesNbors[i] > 0)
                {
                    opposite = i+1;
                    i = _nNN[0]+_nNN[1]-2; // get me out of here!
                }
            }
        }

        return opposite;
    }

    bool LoopExplicit::isEqual( LoopExplicit& another )
    {
        bool equal{true};

        if ( _eNN0 != another._eNN0 )
        {
            equal = false;
        }
        else if ( _creasesNbors0 != another._creasesNbors0 )
        {
            equal = false;
        }
        else
        {
            if (_nNN0[0] != another._nNN0[0])
                equal = false;
            else if ( _nNN0[1] != another._nNN0[1] )
                equal = false;
            else if ( _nNN0[_nNN0[0]] != another._nNN0[_nNN0[0]] )
                equal = false;

            if ( equal )
            {
                for ( int i = 0; i < _eNN0; i++ )
                {
                    if ( _creasesNbors0[i] > 0 )
                    {
                        if ( _nNN0[i] != another._nNN0[i] )
                        {
                            equal = false;
                            break;
                        }
                    }
                }
            }
        }

        return equal;
    }

}
