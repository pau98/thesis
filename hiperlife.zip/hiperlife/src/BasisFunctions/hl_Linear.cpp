/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_Linear.h"
#include "hl_AdjcyENStruct.h"



using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void Linear::Update()
    {
        // Main parameters
        _numTags = 1;
        _bfType = BasisFuncType::Linear;
        if (_adjcyEN != null)
        {
            _elemType = _adjcyEN->elemType();
            _BFTags = rcp(new Epetra_IntVector(_adjcyEN->_adjcyElemNodes->RowMap()));
            _BFTags->PutValue(0);
        }

        // Save basis function type and order
        _bfOrder = 1;
        _orderDers = 1;

        // Check settings
        _checkSettings();

        // Set nVert and pDim
        _nVert = computeNVert(_bfType, _elemType, _bfOrder);
        _pDim = computePDim(_elemType);

        // Allocate space for the basis functions
        _auxRefBF.resize(2);
        _auxEleBF.resize(2);
        _auxRefBF[0].resize(_nVert, 0.0);
        _auxRefBF[1].resize(_nVert * _pDim, 0.0);
        _auxEleBF[0].resize(_nVert, 0.0);
        _auxEleBF[1].resize(_nVert * _pDim, 0.0);
    }

    void Linear::_checkSettings()
    {
        if (_elemType == ElemType::Undefined)
            throw runtime_error("BasisFunction::Linear::Update _elemType not set.");
        if ((_elemType == ElemType::Square) or (_elemType == ElemType::Parallelep))
            throw runtime_error("BasisFunctions::Linear::Update: only works with lines, triangles and tetrahedron.");
        if (_BFTags == null)
            throw runtime_error("BasisFunction::Linear::Update _BFTags not set.");
    }

    void Linear::computeBasisFunctionsReference(vector<vector<double>>& bf, vector<double>& xSamples, int tag)
    {
        // Initialize
        double u{0.0}, v{0.0}, w{0.0};
        (void) tag;

        bf.resize(_orderDers+1);

        // Compute the basis functions for each case
        switch (_pDim)
        {

            case 1:

                u = xSamples[0];

                bf[0].resize(2);
                bf[0][0] = (1.0-u);
                bf[0][1] = u;

                if (_orderDers < 1)
                    break;

                bf[1].resize(2);
                bf[1][0] = -1.0;
                bf[1][1] =  1.0;

                break;

            case 2:

                u = xSamples[0];
                v = xSamples[1];

                bf[0].resize(3);

                bf[0][0] = 1.0-u-v;
                bf[0][1] =     u  ;
                bf[0][2] =     v  ;

                if (_orderDers < 1)
                    break;

                bf[1].resize(6);

                bf[1][0] = -1.0;
                bf[1][1] = -1.0;

                bf[1][2] =  1.0;
                bf[1][3] =  0.0;

                bf[1][4] =  0.0;
                bf[1][5] =  1.0;

                break;


            case 3:

                u = xSamples[0];
                v = xSamples[1];
                w = xSamples[2];

                bf[0].resize(4);

                bf[0][0] = 1.0-u-v-w;
                bf[0][1] =         u;
                bf[0][2] =         v;
                bf[0][3] =         w;

                if (_orderDers < 1)
                    break;

                bf[1].resize(12);

                bf[1][0] = -1.0;
                bf[1][1] = -1.0;
                bf[1][2] = -1.0;

                bf[1][3] =  1.0;
                bf[1][4] =  0.0;
                bf[1][5] =  0.0;

                bf[1][6] =  0.0;
                bf[1][7] =  1.0;
                bf[1][8] =  0.0;

                bf[1][9] =  0.0;
                bf[1][10] =  0.0;
                bf[1][11] =  1.0;

                break;

        }
    }

    vector<vector<double>>& Linear::computeBasisFunctionsReference(vector<double>& xSamples, int tag)
    {
        computeBasisFunctionsReference(_auxRefBF, xSamples, tag);

        return _auxRefBF;
    }

}// end namespace
