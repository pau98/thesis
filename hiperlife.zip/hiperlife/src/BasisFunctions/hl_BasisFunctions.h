/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef BASISFUNCTIONS_H
#define BASISFUNCTIONS_H


#include <Teuchos_RCP.hpp>
#include <Teuchos_Array.hpp>

#include "hl_DistributedClass.h"
#include "hl_TypeDefs.h"
#include "hl_AdjcyENStruct.h"
#include "hl_IntFieldStruct.h"



namespace hiperlife
{

    /*!
     * \brief Virtual class that is the base for all the BasisFunctions implemented in <b>hiperlife</b>.
    */
    class BasisFunctions
    {

        public:
            BasisFunctions() = default;
            BasisFunctions(BasisFunctions &&other) = default;
            virtual ~BasisFunctions() = default;
            BasisFunctions& operator=(BasisFunctions&& other) = default;

            BasisFunctions& operator=(const BasisFunctions& other) = delete;
            BasisFunctions(const BasisFunctions& other) = delete;


            // Setters
            void setAdjcyEN(Teuchos::RCP<AdjcyENStruct> adjcy){_adjcyEN = adjcy;}
            void setNodeFlags(Teuchos::RCP<IntFieldStruct> flags){_nodeFlags = flags;}
            void setElemFlags(Teuchos::RCP<IntFieldStruct> flags){_elemFlags = flags;}

            // Setters for expert users
            void setElementType(ElemType eType){_elemType = eType;}
            void setBasisFunctionOrder(int bfOrder){_bfOrder = bfOrder;}
            void setBasisFunctionTags(Teuchos::RCP<Epetra_IntVector> BFTags){_BFTags = BFTags;}


            // Update
            virtual void Update() = 0;

            // Getters
            int numTags() {return _numTags;}
            int getTag(int e,  IndexType it = IndexType::Global)
            {
                int locE = (it==IndexType::Local)?e:_BFTags->Map().LID(e);
                return (*_BFTags)[locE];
            }
            virtual int getNumNbors(int tag) = 0;
            int orderDers() {return _orderDers;}
            int pDim()  {return _pDim;}
            ElemType elemType() {return _elemType;}
            int bfOrder()  {return _bfOrder;}

            virtual void computeBasisFunctionsReference(std::vector<std::vector<double>>& bf, std::vector<double>& xSamples, int tag = 0) = 0;
            virtual std::vector<std::vector<double>>& computeBasisFunctionsReference(std::vector<double>& xSamples, int tag = 0) = 0;
            inline std::vector<std::vector<double>>& computeBasisFunctionsReference(std::vector<double>& xSamples, int tag, int nDers)
            {
                // Check
                if (nDers > _orderDers)
                    throw std::runtime_error("BasisFunctions::computeBasisFunctionsReference: The requested number of derivatives is greater than the order of the basis functions.");

                // Save old order
                int orderDers = _orderDers;

                // Set number of derivatives
                _orderDers = nDers;

                // Get basis functions
                computeBasisFunctionsReference(_auxRefBF, xSamples, tag);

                // Restore order of derivatives
                _orderDers = orderDers;

                return _auxRefBF;
            }

            Teuchos::RCP<AdjcyENStruct>  _adjcyEN;
            Teuchos::RCP<IntFieldStruct> _nodeFlags;
            Teuchos::RCP<IntFieldStruct> _elemFlags;
            std::vector<std::vector<double>> _auxRefBF;
            std::vector<std::vector<double>> _auxEleBF;


            Teuchos::RCP<Epetra_IntVector> _BFTags;
            int _numTags;
            int _orderDers;

        protected:
            int _pDim;
            int _nVert;
            BasisFuncType _bfType;
            ElemType _elemType;
            int _bfOrder;
    };

}

#endif // BASISFUNCTIONS_H
