/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef BSPLINES_H
#define BSPLINES_H

#include "hl_BasisFunctions.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of BSplines until third-order. They are compatible with lines, squares and parallelepipeds
    */
    class BSplines : public BasisFunctions
    {
        public:

            BSplines() = default;
            BSplines(BSplines &&other) = default;
            ~BSplines() = default;
            BSplines& operator=(BSplines&& other) = default;

            BSplines& operator=(const BSplines& other) = delete;
            BSplines(const BSplines& other) = delete;

            // Setters for expert users
            inline void setNElemDir(int nEx, int nEy = -1, int nEz = -1){_nEx = nEx; _nEy = nEy; _nEz = nEz;}
            inline void setBasisFunctionOrderDir(int bfOrderX, int bfOrderY, int bfOrderZ){_bfOrderX = bfOrderX; _bfOrderY = bfOrderY; _bfOrderZ = bfOrderZ;}
            inline void setGlobKnots(std::vector<double> uKnot, std::vector<double> vKnot = std::vector<double> (), std::vector<double> wKnot = std::vector<double> ()){_uKnot = uKnot; _vKnot = vKnot; _wKnot = wKnot;}

            // Update
            void Update() override;

            // Getters
            int getNumNbors(int tag) override {(void) tag; return _nVert;}
            std::tuple<int, int, int> nElemDir() const {return std::make_tuple(_nEx, _nEy, _nEz);};
            std::tuple<int, int, int> bfOrderDir() const {return std::make_tuple(_bfOrderX, _bfOrderY, _bfOrderZ);};
            std::tuple<std::vector<double>,std::vector<double>,std::vector<double>> knots() const {return std::make_tuple(_uKnot, _vKnot, _wKnot);}


            void computeBasisFunctionsReference(std::vector<std::vector<double>>& bf, std::vector<double>& xSamples, int tag = 0) override;
            std::vector<std::vector<double>>& computeBasisFunctionsReference(std::vector<double>& xSamples, int tag = 0) override;


        private:
            int _nEx{-1}, _nEy{-1}, _nEz{-1};
            int _bfOrderX, _bfOrderY, _bfOrderZ;
            std::vector<double> _uKnot, _vKnot, _wKnot;
            std::vector<int> _vCrv;
            void _checkSettings();

            std::vector<std::vector<double>> Nu, Nv, Nw;
            std::vector<std::vector<int>> idx;

    };


}

#endif
