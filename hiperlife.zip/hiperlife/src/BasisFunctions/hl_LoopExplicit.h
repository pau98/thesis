/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Daniel Millán
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LOOPEXPLICIT_H
#define LOOPEXPLICIT_H

#include "hl_IntFieldStruct.h"
#include "hl_AdjcyENStruct.h"
#include "hl_LoopImplicit.h"
#include <vector>

#include "hl_TypeDefs.h"

namespace hiperlife
{


/**
 * \brief This is the master class for Subdivision Surfaces approximants
 * as described in [1,2] in the explicit case (crease/corner and more than 1 irregular node per element).
 *
 * \b Reference: \n
 * [1] F Cirak, M Ortiz, P Schroder, Subdivision surfaces: a new paradigm for thin-shell
 *     finite-element analysis. International Journal for Numerical Methods in Engineering,
 *     47(12):2039-2072.
 * [2] J Stam, "Evaluation of Loop Subdivision Surfaces", SIGGRAPH'99 Course Notes, 1999.
 * [3] F Cirak, Q Long, Subdivision shells with exact boundary control and non-manifold
 *     geometry.  International Journal for Numerical Methods in Engineering, 88:897-923
 * [4] H Biermann, A Levin, D Zorin, Piecewise Smooth Subdivision Surfaces with Normal Control,
 *     SIGGRAPH
 */
    class LoopExplicit
    {
        public :

        /** Constructor */
        LoopExplicit() = default;
        /** Destructor */
        ~LoopExplicit() = default;

        LoopExplicit(LoopExplicit &&other) = default;
        LoopExplicit& operator=(LoopExplicit&& other) = default;

        LoopExplicit& operator=(const LoopExplicit& other) = delete;
        LoopExplicit(const LoopExplicit& other) = delete;

        /** Set/Get the label of the element  where the sample points are */
        //@{
        void SetElementIdentifier (int elemID)
        {   this->_elemID = elemID;   }
        int GetElementIdentifier ( )
        {   return this->_elemID;   }
        //@}

        void setAdjcyEN(Teuchos::RCP<AdjcyENStruct> adjcy){_adjcyEN = adjcy;}
        void setNodeFlags(Teuchos::RCP<IntFieldStruct> flags){_nodeFlags = flags;}

        std::vector<int> getNumberOfNeighborsOfNodes()
        {   return this->_nNN0;  }

        int getNumberOfNearestNeighbors() const
        {   return this->_eNN0;  }

        std::vector<int> getLocalCreaseTags() const
        {   return this->_creasesNbors0; }


        std::vector<double> getNodeAngles ( void )
        {   return this->_anglesNbors0;   }

        /** Bring this algorithm's outputs up-to-date. */
        virtual void Update();

        /** Identify the subdivision triangle */
        int idSubTrian (double &v, double &w);

        /** Evaluate the first and second order derivatives of the
         *  surface at any point (v,w)*/
        void ComputeBasisFunctions (std::vector< std::vector<double> >& bf, double v, double w);

        /** Evaluate if another LoopExplicit object is equivalent to this one (to reduce storage)
         *  it returns true if both are equal and false otherwise */
        bool isEqual( LoopExplicit& another );

        protected:

        /** @name Inputs*/
        //@{
        int     _elemID{};                       ///< actual element identifier

        Teuchos::RCP<AdjcyENStruct>  _adjcyEN;   ///<list of neighbors of the element
        Teuchos::RCP<IntFieldStruct> _nodeFlags; ///<flags of the node (creases)
        //@}

        /** @name Outputs*/
        //@{
        // Basis functions and derivatives
        std::vector< std::vector<double> > _BF;

        std::vector<double> _plimit_k;               ///< basis functions and derivatives for limit masks
        std::vector<double> _dplimit_k;
        std::vector<double> _hplimit_k;

        // Required for subdivision
        std::vector<double> _subDivMat;          ///< subdivision matrix (this keeps all the information when subdividing)
        std::vector<int> _creasesNbors;     ///< IndexType::Local idN_creases (it is updated after each subdivision)
        std::vector<int> _creasesNbors0;    ///< local idN_creases for the 0-th subdivision level
        std::vector<int> _nNN;              ///< number of nearest neighbors for the nodes in each triangle (it is updated after each subdivision)
        std::vector<int> _nNN0;             ///< number of nearest neighbors for the nodes in each triangle for the 0-th subdivision level
        std::vector<double>  _anglesNbors0;   ///< local values of the angles at 0 subdivision level
        std::vector<double>  _anglesNbors;    ///< local values of the angles at the actual subdivision level
        int     _eNN{};                       ///< number of nearest neighbors of an element (it is updated after each subdivision)
        int     _eNN0{};                      ///< number of nearest neighbors of an element for the 0-th subdivision level


        std::vector<double> _subDivMat_step;  ///< subdivision matrix for the current step
        std::vector<double> _subDivMat_tmp;   ///< tmp subdivision matrix
        std::vector<int> _creasesNbors_tmp;   ///< tmp creases in neighbors (new step, built during the subdivision process)
        std::vector<int> _nNN_tmp;            ///< tmp number of nearest neighbors of neighbors (new step, built during the subdivision process)
        std::vector<double> _angles_tmp;      ///< tmp angles

        std::vector<int> _neighborsNode_tmp;  ///< vector to store the neighbors of a node

        double _factor2{};                     ///< This stores the factor to scale the Jacobian and the Hessian
        int    _transform[4]={};               ///< This stores the rotations in the Jacobian and Hessian

        bool   _creaseFlag{};    ///< True if there are creases/corners in the subdivided neighborhood
        bool   _creaseFlag0{};   ///< True if there are creases/corners in the initial neighborhood

        //@}

        /** This function translates the initial input with global node labels to local variables
         * within the first ring of neighbors of the element*/
        void _global2Local();

        /** @name ROOTS OF ALL EVIL*/
        /* ---------------------------------------------------------------------------------------
        *        ROOTS OF ALL EVIL (subdivision rules for each subtriangle and limit masks)
        * ---------------------------------------------------------------------------------------
        * Satanic diagram:
        * Identify the subtriangle
        *     /  \
        *    / 0  \
        *   /------\
        *  /  \ 3/  \
        * / 1  \/  2 \
        *  ---------- */
        void _subNodesInFirstRing0( );
        void _subNodesInFirstRing1( );
        void _subNodesInFirstRing2( );
        void _subNodesInFirstRing3( );
        void _limitMaskNode1( );
        void _limitMaskNodeN( );

        void _basisFunctionAndDerivatives (double, double, double *p_k, double *dp_k, double *hp_k);

        /** @name SUBDIVISION RULES*/
        /** This creates a new node at the edge given by nodeEdge0 and nodeEdge1. If the edge is not marked as crease,
         *  nodeOp0 and nodeOp1 are the opposite nodes to the edge and nodeOut is the numbering of the new node in the new subdivision level
         *  nNN_, idN_creasesL_, angles_ and Amat_ are the number of neighbors to each node, the id of the creases, the angles at each point and them
         *  subdivision matrix at the new level of subdivision (these are updated by this function)*/
        void _createNodeAtEdge(int nodeEdge0, int nodeEdge1, int nodeOp0, int nodeOp1, std::vector<int>& nNN_, std::vector<int>& idN_creasesL_, std::vector<double>& angles_, std::vector<double>& Amat_);

        /** This puts and old node (with label nodeIn) in the new subdivision level nodeOut.
         * nNN_, idN_creasesL_, angles_ and Amat_ are the number of neighbors to each node, the id of the creases, the angles at each point and them
         * subdivision matrix at the new level of subdivision (these are updated by this function) */
        void _remaskNode(int nodeIn, std::vector<int>& nNN_, std::vector<int>& idN_creasesL_, std::vector<double>& angles_, std::vector<double>& Amat_);

        /** @name AUXILIARY*/

        /** Rotate the triangle to put the irregular node at position 0 */
        void _rotateTriangle( );

        /** This function computes the neighbors of the node (this node HAS to lie on the primary element)*/
        void _neighbors(int node);

        /** This gives the opposite node to the edge N N-1 (different than 0) and also computes the number of
         * shared neighbors between nodes N, 0 and 1 */
        int _oppositeNNm1( int &sharedneighbors );

        /** This computes the opposite node to the edge 1-2 that is not 0 */
        int _opposite12( );

    };
}
#endif // LOOPEXPLICIT_H
