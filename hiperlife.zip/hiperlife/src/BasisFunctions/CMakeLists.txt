#------------------------------------------------------------
# hiperlife's BasisFunctions Shared library
#------------------------------------------------------------

#------------------------------------------------------------
# Glob Source files
#------------------------------------------------------------
file(GLOB SOURCES_H   *.h)
file(GLOB SOURCES_CPP *.cpp)
set(SOURCE_FILES ${SOURCES_H} ${SOURCES_CPP})
set(LIBNAME hlBasisFunctions)


#------------------------------------------------------------
# Building the LIBRARY
#------------------------------------------------------------
add_library(${LIBNAME} ${SOURCE_FILES})

target_link_libraries(${LIBNAME} ${MPI_LIB})
target_link_libraries(${LIBNAME} ${Trilinos_LIBRARIES})
target_link_libraries(${LIBNAME} ${HPLFE_LIBRARIES})

install(TARGETS ${LIBNAME} DESTINATION lib EXPORT hiperlifeTargets)
install(FILES ${SOURCES_H} DESTINATION include)


#------------------------------------------------------------
# Storing the Library
#------------------------------------------------------------
set(HPLFE_LIBRARIES ${HPLFE_LIBRARIES} ${LIBNAME} CACHE INTERNAL "HPLFE_LIBRARIES")
