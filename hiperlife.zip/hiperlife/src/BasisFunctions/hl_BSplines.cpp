/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_BSplines.h"
#include "hl_AdjcyENStruct.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void productRuleIndices(vector<vector<int>>& idx, int ders, int dim)
    {
        for (int i = 0; i < dim; i++)
            idx[0][i] = 0;
        for (int d = 1; d < ders+1; d++)
        {
            for (int k = 0; k < pow(dim, d); k++)
            {
                int kprev = k/dim;
                for (int i = 0; i < dim; i++)
                {
                    if (i == k%dim)
                    {
                        idx[d][k*dim+i] = idx[d-1][kprev*dim+i]+1;
                    }
                    else
                    {
                        idx[d][k*dim+i] = idx[d-1][kprev*dim+i];
                    }

                }
            }
        }
    }

    void BSplines::Update()
    {
        // Main sets
        _bfType = BasisFuncType::BSplines;
        _numTags = 2; //FIXME: hard coded for now.
        if (_adjcyEN != null)
        {
            // Element, bfOrder per direction and knot vectors
            _elemType = _adjcyEN->elemType();
            tie(_bfOrderX, _bfOrderY, _bfOrderZ) = _adjcyEN->basisFuncOrderDir();
            tie(_nEx, _nEy, _nEz) = _adjcyEN->nElemDir();
            tie(_uKnot, _vKnot, _wKnot) = _adjcyEN->knots();
            _vCrv = _adjcyEN->vCrv();
            // Basis function tags
            if (_elemFlags == null)
                throw runtime_error("BasisFunction::BSplines: Update _elemFlags not set.");
            _BFTags = rcp(new Epetra_IntVector(_adjcyEN->_adjcyElemNodes->RowMap()));
            for (int e = 0; e < _adjcyEN->loc_nElem(); e++)
                (*_BFTags)[e] = _elemFlags->getValue(0, e, IndexType::Local);
        }

        // Check settings
        _checkSettings();

        // Set nVert and pDim
        _nVert = computeNVert(_bfType, _elemType, _bfOrderX, _bfOrderY, _bfOrderZ);
        _pDim = computePDim(_elemType);

        // Set derivative order
        if ((_bfOrderX != -1) and (_bfOrderY != -1) and (_bfOrderZ != -1))
            _orderDers = min(min(_bfOrderX, _bfOrderY), _bfOrderZ);
        else if ((_bfOrderX != -1) and (_bfOrderY != -1))
            _orderDers = min(_bfOrderX, _bfOrderY);
        else if (_bfOrderX != -1)
            _orderDers = _bfOrderX;

        // Allocate space for the basis functions
        _auxRefBF.resize(_orderDers+1);
        _auxEleBF.resize(_orderDers+1);
        for (int i = 0; i < _orderDers+1; i++)
        {
            _auxRefBF[i].resize(_nVert * pow(_pDim, i), 0.0);
            _auxEleBF[i].resize(_nVert * pow(_pDim, i), 0.0);
        }

        // Allocate space for 1D basis functions
        Nu.resize(_orderDers+1, vector<double>(_bfOrderX+1));
        Nv.resize(_orderDers+1, vector<double>(_bfOrderY+1));
        Nw.resize(_orderDers+1, vector<double>(_bfOrderZ+1));

        // Compute product rule indices
        idx.resize(_orderDers+1);
        for (int d = 0; d < _orderDers+1; d++)
            idx[d].resize(static_cast<unsigned long>(_pDim*pow(_pDim, d)));
        productRuleIndices(idx, _orderDers, _pDim);
    }

    void BSplines::_checkSettings()
    {
        if (_elemType == ElemType::Line)
        {
            if ((_nEx == -1) or (_nEy != -1) or (_nEz != -1))
                throw runtime_error("BasisFunction::BSplines: The number of elements of Line elements should (only) be set in x direction.");
            if ((_bfOrderX == -1) or (_bfOrderY != -1  or _bfOrderZ != -1))
                throw runtime_error("BasisFunction::BSplines: The order of Line elements should (only) be set in x direction.");
            if (_uKnot.empty() or !_vKnot.empty() or !_wKnot.empty())
                throw runtime_error("BasisFunction::BSplines: Knot vectors for Line elements should (only) be set in x direction.");
        }
        else if (_elemType == ElemType::Square)
        {
            if ((_nEx == -1) or (_nEy == -1) or (_nEz != -1))
                throw runtime_error("BasisFunction::BSplines: The number of elements of Square elements should (only) be set in x and y directions.");
            if ((_bfOrderX == -1 or _bfOrderY == -1)  or _bfOrderZ != -1)
                throw runtime_error("BasisFunction::BSplines: The order of Square elements should (only) be set in x and y directions.");
            if (_uKnot.empty() or _vKnot.empty() or !_wKnot.empty())
                throw runtime_error("BasisFunction::BSplines: Knot vectors for Square elements should (only) be set in x and y directions.");
        }
        else if (_elemType == ElemType::Parallelep)
        {
            if ((_nEx == -1) or (_nEy == -1) or (_nEz == -1))
                throw runtime_error("BasisFunction::BSplines: The number of elements of Parallelep elements should be set in x, y and z directions.");
            if (_bfOrderX == -1 or _bfOrderY == -1  or _bfOrderZ == -1)
                throw runtime_error("BasisFunction::BSplines: The order of Parallelep elements should be set in x, y and z directions.");
            if (_uKnot.empty() or _vKnot.empty() or _wKnot.empty())
                throw runtime_error("BasisFunction::BSplines: Knot vectors for Parallelep elements should be set in x, y and z directions.");
        }
        else
        {
            throw runtime_error("BasisFunction::BSplines: Wrong element type.");
        }
        if (_BFTags == null)
        {
            throw runtime_error("BasisFunction::BSplines:Update _BFTags not set.");
        }
    }

    void basisFunctionAndDers(vector<vector<double>>& ders, int i, double u, int p, int n, vector<double> U)
    {
        // Algorithm from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; pp. 72-73.
        /* Compute nonzero basis functions and their */
        /* derivatives. First section is A2.3 modified*/
        /* to store functions and knot differences. */
        /* Input: i,u,p,n,U */
        /* Output: ders */

        //Initialize
        vector<vector<double>> ndu(p+1, vector<double>(p+1)), a(2, vector<double>(p+1));
        vector<double> left(p+1), right(p+1);

        //Compute basis functions
        ndu[0][0] = 1.0;
        for (int j = 1; j <= p; j++)
        {
            left[j] = u-U[i+1-j];
            right[j] = U[i+j]-u;

            double saved{}, temp{};
            for (int r = 0; r < j; r++)
            {
                /* Lower triangle */
                ndu[j][r] = right[r+1] + left[j-r];
                temp = ndu[r][j-1]/ndu[j][r];
                /* Upper triangle */
                ndu[r][j] = saved + right[r+1]*temp;
                saved = left[j-r]*temp;
            }
            ndu[j][j] = saved;
        }

        //Load basis functions
        for (int j = 0; j <= p; j++)
            ders[0][j] = ndu[j][p];

        //Compute derivatives
        for (int r = 0; r <= p; r++)
        {
            //Alternate rows in array a
            int s1{0};
            int s2{1};
            a[0][0] = 1.0;

            //Compute kth derivative
            for (int k = 1; k <= n; k++)
            {
                double d{};
                int rk = r-k;
                int pk = p-k;
                if (r >= k)
                {
                    a[s2][0] = a[s1][0]/ndu[pk+1][rk];
                    d = a[s2][0]*ndu[rk][pk];
                }
                int j1, j2;
                if (rk >= -1)
                    j1 = 1;
                else
                    j1 = -rk;
                if (r-1 <= pk)
                    j2 = k-1;
                else
                    j2 = p-r;
                for (int j = j1; j <= j2; j++)
                {
                    a[s2][j] = (a[s1][j]-a[s1][j-1])/ndu[pk+1][rk+j];
                    d += a[s2][j]*ndu[rk+j][pk];
                }
                if (r <= pk)
                {
                    a[s2][k] = -a[s1][k-1]/ndu[pk+1][r];
                    d += a[s2][k]*ndu[r][pk];
                }
                ders[k][r] = d;
                //Switch rows
                int j = s1;
                s1 = s2;
                s2 = j;
            }
        }

        //Multiply through by the correct factors
        int r = p;
        for (int k = 1; k <= n; k++)
        {
            for (int j = 0; j <= p; j++)
            {
                ders[k][j] *= r;
            }
            r *= (p-k);
        }

    }

    void BSplines::computeBasisFunctionsReference(vector<vector<double>>& bf, vector <double>& xSamples, int tag)
    {
        //Initialize
        double u{}, v{}, w{};
        double u_hat{}, v_hat{}, w_hat{};
        int span_u{}, span_v{}, span_w{};
        int inex{}, iney{}, inez{};

        int n{};

        int offU = 0;

        switch (_pDim)
        {
            case 1:
                u = xSamples[0];
                inex = tag % _nEx;
                for(int i = 0; i < (int)_vCrv.size(); i++)
                {
                    if (inex < _vCrv[i])
                    {
                        break;
                    }
                    offU += 7;
                }
                span_u = _bfOrderX+offU+inex;
                u_hat = _uKnot[span_u] + (u+1)*(_uKnot[span_u+1]-_uKnot[span_u])/2.0;

                // Compute 1D Bspline basis functions and derivatives
                basisFunctionAndDers(Nu, span_u, u_hat, _bfOrderX, _orderDers, _uKnot);

                // Rearrange basis functions
                n = 0;
                for (int p = 0; p < _bfOrderX+1; p++)
                {
                    for (int d = 0; d < _orderDers+1; d++)
                        bf[d][n] = Nu[d][p];

                    //Increase basis function number
                    n++;
                }

                break;

            case 2:
                u = xSamples[0];
                inex = tag % _nEx;
                span_u = _bfOrderX+inex;
                u_hat = _uKnot[span_u] + (u+1)*(_uKnot[span_u+1]-_uKnot[span_u])/2.0;

                v = xSamples[1];
                iney = (int) tag/_nEx;
                span_v = _bfOrderY+iney;
                v_hat = _vKnot[span_v] + (v+1)*(_vKnot[span_v+1]-_vKnot[span_v])/2.0;

                // Compute 1D Bspline basis functions and derivatives
                basisFunctionAndDers(Nu, span_u, u_hat, _bfOrderX, _orderDers, _uKnot);
                basisFunctionAndDers(Nv, span_v, v_hat, _bfOrderY, _orderDers, _vKnot);

                // Compute basis functions and derivatives
                n = 0;
                for (int q = 0; q < _bfOrderY+1; q++)
                {
                    for (int p = 0; p < _bfOrderX+1; p++)
                    {
                        // Basis functions
                        bf[0][n] = Nu[0][p]*Nv[0][q];

                        // First-order derivatives
                        if (_orderDers > 0)
                        {
                            bf[1][2*n+0] = Nu[1][p]*Nv[0][q];
                            bf[1][2*n+1] = Nu[0][p]*Nv[1][q];
                        }

                        // Second-order derivatives
                        if (_orderDers > 1)
                        {
                            bf[2][4*n+0] = Nu[2][p]*Nv[0][q];
                            bf[2][4*n+1] = Nu[1][p]*Nv[1][q];
                            bf[2][4*n+2] = Nu[1][p]*Nv[1][q];
                            bf[2][4*n+3] = Nu[0][p]*Nv[2][q];
                        }

                        // Third-order derivatives
                        if (_orderDers > 2)
                        {
                            bf[3][8*n+0] = Nu[3][p]*Nv[0][q];
                            bf[3][8*n+1] = Nu[2][p]*Nv[1][q];
                            bf[3][8*n+2] = Nu[2][p]*Nv[1][q];
                            bf[3][8*n+3] = Nu[1][p]*Nv[2][q];
                            bf[3][8*n+4] = Nu[2][p]*Nv[1][q];
                            bf[3][8*n+5] = Nu[1][p]*Nv[2][q];
                            bf[3][8*n+6] = Nu[1][p]*Nv[2][q];
                            bf[3][8*n+7] = Nu[0][p]*Nv[3][q];
                        }

                        // Higher-order derivatives
                        if (_orderDers > 3)
                        {
                            for (int d = 4; d < _orderDers+1; d++)
                            {
                                //Store basis functions and derivatives
                                int kk = int(pow(_pDim,d));
                                for (int k = 0; k < kk; k++)
                                {
                                    bf[d][kk*n+k] = Nu[idx[d][k]][p] * Nv[idx[d][kk+k]][q];
                                }
                            }
                        }

                        //Increase basis function number
                        n++;
                    }
                }

                break;

            case 3:
                u = xSamples[0];
                inex = tag % _nEx;
                span_u = _bfOrderX+inex;
                u_hat = _uKnot[span_u] + (u+1)*(_uKnot[span_u+1]-_uKnot[span_u])/2.0;

                v = xSamples[1];
                iney = (tag%(_nEx*_nEy))/_nEx;
                span_v = _bfOrderY+iney;
                v_hat = _vKnot[span_v] + (v+1)*(_vKnot[span_v+1]-_vKnot[span_v])/2.0;

                w = xSamples[2];
                inez = (tag/(_nEx*_nEy));
                span_w = _bfOrderZ+inez;
                w_hat = _wKnot[span_w] + (w+1)*(_wKnot[span_w+1]-_wKnot[span_w])/2.0;

                // Compute 1D Bspline basis functions and derivatives
                basisFunctionAndDers(Nu, span_u, u_hat, _bfOrderX, _orderDers, _uKnot);
                basisFunctionAndDers(Nv, span_v, v_hat, _bfOrderY, _orderDers, _vKnot);
                basisFunctionAndDers(Nw, span_w, w_hat, _bfOrderZ, _orderDers, _wKnot);

                // Compute basis functions and derivatives
                n = 0;
                for (int r = 0; r < _bfOrderZ+1; r++)
                {
                    for (int q = 0; q < _bfOrderY+1; q++)
                    {
                        for (int p = 0; p < _bfOrderX+1; p++)
                        {
                            // Basis functions
                            bf[0][n] = Nu[0][p]*Nv[0][q]*Nw[0][r];

                            // First-order derivatives
                            if (_orderDers > 0)
                            {
                                bf[1][3*n+0] = Nu[1][p]*Nv[0][q]*Nw[0][r];
                                bf[1][3*n+1] = Nu[0][p]*Nv[1][q]*Nw[0][r];
                                bf[1][3*n+2] = Nu[0][p]*Nv[0][q]*Nw[1][r];
                            }

                            // Second-order derivatives
                            if (_orderDers > 1)
                            {
                                bf[2][9*n+0] = Nu[2][p]*Nv[0][q]*Nw[0][r];
                                bf[2][9*n+1] = Nu[1][p]*Nv[1][q]*Nw[0][r];
                                bf[2][9*n+2] = Nu[1][p]*Nv[0][q]*Nw[1][r];
                                bf[2][9*n+3] = Nu[1][p]*Nv[1][q]*Nw[0][r];
                                bf[2][9*n+4] = Nu[0][p]*Nv[2][q]*Nw[0][r];
                                bf[2][9*n+5] = Nu[0][p]*Nv[1][q]*Nw[1][r];
                                bf[2][9*n+6] = Nu[1][p]*Nv[0][q]*Nw[1][r];
                                bf[2][9*n+7] = Nu[0][p]*Nv[1][q]*Nw[1][r];
                                bf[2][9*n+8] = Nu[0][p]*Nv[0][q]*Nw[2][r];
                            }

                            // Third-order derivatives
                            if (_orderDers > 2)
                            {
                                bf[3][27*n+0]  = Nu[3][p]*Nv[0][q]*Nw[0][r];
                                bf[3][27*n+1]  = Nu[2][p]*Nv[1][q]*Nw[0][r];
                                bf[3][27*n+2]  = Nu[2][p]*Nv[0][q]*Nw[1][r];
                                bf[3][27*n+3]  = Nu[2][p]*Nv[1][q]*Nw[0][r];
                                bf[3][27*n+4]  = Nu[1][p]*Nv[2][q]*Nw[0][r];
                                bf[3][27*n+5]  = Nu[1][p]*Nv[1][q]*Nw[1][r];
                                bf[3][27*n+6]  = Nu[2][p]*Nv[0][q]*Nw[1][r];
                                bf[3][27*n+7]  = Nu[1][p]*Nv[1][q]*Nw[1][r];
                                bf[3][27*n+8]  = Nu[1][p]*Nv[0][q]*Nw[2][r];
                                bf[3][27*n+9]  = Nu[2][p]*Nv[1][q]*Nw[0][r];
                                bf[3][27*n+10] = Nu[1][p]*Nv[2][q]*Nw[0][r];
                                bf[3][27*n+11] = Nu[1][p]*Nv[1][q]*Nw[1][r];
                                bf[3][27*n+12] = Nu[1][p]*Nv[2][q]*Nw[0][r];
                                bf[3][27*n+13] = Nu[0][p]*Nv[3][q]*Nw[0][r];
                                bf[3][27*n+14] = Nu[0][p]*Nv[2][q]*Nw[1][r];
                                bf[3][27*n+15] = Nu[1][p]*Nv[1][q]*Nw[1][r];
                                bf[3][27*n+16] = Nu[0][p]*Nv[2][q]*Nw[1][r];
                                bf[3][27*n+17] = Nu[0][p]*Nv[1][q]*Nw[2][r];
                                bf[3][27*n+18] = Nu[2][p]*Nv[0][q]*Nw[1][r];
                                bf[3][27*n+19] = Nu[1][p]*Nv[1][q]*Nw[1][r];
                                bf[3][27*n+20] = Nu[1][p]*Nv[0][q]*Nw[2][r];
                                bf[3][27*n+21] = Nu[1][p]*Nv[1][q]*Nw[1][r];
                                bf[3][27*n+22] = Nu[0][p]*Nv[2][q]*Nw[1][r];
                                bf[3][27*n+23] = Nu[0][p]*Nv[1][q]*Nw[2][r];
                                bf[3][27*n+24] = Nu[1][p]*Nv[0][q]*Nw[2][r];
                                bf[3][27*n+25] = Nu[0][p]*Nv[1][q]*Nw[2][r];
                                bf[3][27*n+26] = Nu[0][p]*Nv[0][q]*Nw[3][r];
                            }

                            // Higher-order derivatives
                            if (_orderDers > 3)
                            {
                                for (int d = 4; d < _orderDers+1; d++)
                                {
                                    //Store basis functions and derivatives
                                    int kk = int(pow(_pDim,d));
                                    for (int k = 0; k < kk; k++)
                                    {
                                        bf[d][kk*n+k] = Nu[idx[d][k]][p] * Nv[idx[d][kk+k]][q];
                                    }
                                }
                            }

                            //Increase basis function number
                            n++;
                        }
                    }
                }

                break;
        }

    }

    vector<vector<double>>& BSplines::computeBasisFunctionsReference(vector<double>& xSamples, int tag)
    {
        computeBasisFunctionsReference(_auxRefBF, xSamples, tag);

        return _auxRefBF;
    }

}
