/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_Lagrangian.h"
#include "hl_AdjcyENStruct.h"



using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;

namespace hiperlife
{
    void Lagrangian::Update()
    {
        // Main sets
        _bfType = BasisFuncType::Lagrangian;
        _numTags = 1;
        if (_adjcyEN != null)
        {
            _elemType = _adjcyEN->elemType();
            _bfType   = _adjcyEN->basisFuncType(); // This is here for Global Constraints
            _bfOrder  = _adjcyEN->basisFuncOrder();
            _BFTags   = rcp(new Epetra_IntVector(_adjcyEN->_adjcyElemNodes->RowMap()));
            _BFTags->PutValue(0);
        }

        // Check settings
        _checkSettings();

        // Set nVert and pDim
        _nVert = computeNVert(_bfType, _elemType, _bfOrder);
        _pDim = computePDim(_elemType);

        // Set derivative order
        _orderDers = _bfOrder; //FIXME

        // Allocate space for the basis functions
        _auxRefBF.resize(_bfOrder+1);
        _auxEleBF.resize(_bfOrder+1);
        for (int i=0; i < _bfOrder+1; i++)
        {
            _auxRefBF[i].resize(_nVert * pow(_pDim,i), 0.0);
            _auxEleBF[i].resize(_nVert * pow(_pDim,i), 0.0);
        }

        // Allocate space for 1D basis functions
        Nu.resize(_orderDers+1);
        Nv.resize(_orderDers+1);
        Nw.resize(_orderDers+1);
        Nt.resize(_orderDers+1);

        // Allocate space for product rule indices
        idx.resize(_pDim);
        for (auto vec: idx)
            vec.reserve(int(pow(2,_orderDers)));

    }

    void Lagrangian::_checkSettings()
    {
        if (_elemType == ElemType::Undefined)
            throw runtime_error("BasisFunction::Lagrangian::Update: _elemType not set.");
        if (_bfOrder <= 0 and _bfType != BasisFuncType::GlobConstr)
            throw runtime_error("BasisFunction::Lagrangian::Update: _bfOrder not set.");
        if (_BFTags == null)
            throw runtime_error("BasisFunction::Lagrangian::Update: _BFTags not set.");
    }

    double lagrangePolynomial(double chi, double chi_a, vector<int> index, int nen)
    {
        double L = 1.0;
        bool skip;
        for (int b=0; b<nen; b++)
        {
            skip = false;
            for (int j=0; j<int(index.size()); j++)
                if (b==index[j])
                    skip=true;
            if (skip)
                continue;
            double chi_b = -1.0 + float(b)*2.0/float(nen-1);
            L *= (chi-chi_b)/(chi_a-chi_b);
        }
        return L;
    }

    double lagrangeDerivatives(double chi, double chi_a, vector<int> index, int nen, int der)
    {
        double L, dL;
        bool skip;
        dL = 0.0;
        for (int c=0; c<nen; c++)
        {
            index[der-1]=c;
            skip = false;
            for (int j=der; j<int(index.size()); j++)
                if (c==index[j])
                    skip=true;
            if (skip)
                continue;
            if (der-1>0)
                L = lagrangeDerivatives(chi, chi_a, index, nen, der-1);
            else
                L = lagrangePolynomial(chi, chi_a, index, nen);
            double chi_c = -1.0 + float(c)*2.0/float(nen-1);
            dL += L/(chi_a-chi_c);
        }
        return dL;
    }

    double lagrangePolynomialAndDerivatives(double chi, int a, int ord, int der)
    {
        int nen = ord+1;
        vector<int> index(der+1);
        double chi_a = -1.0 + float(a)*2.0/float(nen-1);
        index[der]=a;
        if (der==0)
            return lagrangePolynomial(chi, chi_a, index, nen);
        else
            return lagrangeDerivatives(chi, chi_a, index, nen, der);
    }

    double triangularPolynomialAndDerivatives(double chi, int a, int der, int bfOrder)
    {
        double T;
        if (a==0)
        {
            if (der==0)
                T = 1.0;
            else
                T = 0.0;
        }
        else
        {
            double chi_a, chi_mod, dchi_mod;
            chi_a = float(a)/float(bfOrder);
            chi_mod = (2.0*chi/chi_a-1.0);
            dchi_mod = 2.0/chi_a;
            T = lagrangePolynomialAndDerivatives(chi_mod, a, a, der)*pow(dchi_mod,der);
        }
        return T;
    }

    void computeProdRuleIndices(vector<vector<int>>& idx, int dir, int u, int dim, int der, int &n)
    {
        if (der>0)
        {
            for (int i=0; i<dim; i++)
            {
                if (i==dir)
                {
                    u++;
                    computeProdRuleIndices(idx, dir, u, dim, der-1, n);
                    u--;
                }
                else
                {
                    computeProdRuleIndices(idx, dir, u, dim, der-1, n);
                }
            }
        }
        else
        {
            idx[dir][n]=u;
            n++;
        }
    }

    void Lagrangian::computeBasisFunctionsReference(vector<vector<double>>& bf, vector<double>& xSamples, int tag)
    {
        (void) tag;
        double u{0.0}, v{0.0}, w{0.0}, t{0.0};

        if (_bfOrder == 1)
        {
            if (_elemType == ElemType::Point)
            {
                if (_bfType != BasisFuncType::GlobConstr)
                    cout << "Warning: HPLFE_Lagrangian: Point case not implemented" << endl;
            }
            else if (_elemType == ElemType::Line)
            {
                u = xSamples[0];

                // Shape functions
                bf[0][0] = 0.5*(1.0-u);
                bf[0][1] = 0.5*(1.0+u);

                // Derivatives
                if (_orderDers > 0)
                {
                    bf[1][0] = -0.5;
                    bf[1][1] =  0.5;
                }
            }
            else if (_elemType == ElemType::Square)
            {
                u = xSamples[0];
                v = xSamples[1];

                // Shape functions
                bf[0][0] = 0.25*(1.0-u)*(1.0-v);
                bf[0][1] = 0.25*(1.0+u)*(1.0-v);
                bf[0][2] = 0.25*(1.0-u)*(1.0+v);
                bf[0][3] = 0.25*(1.0+u)*(1.0+v);

                // Derivatives
                if (_orderDers > 0)
                {
                    bf[1][0] = -0.25*(1.0-v);
                    bf[1][1] = -0.25*(1.0-u);
                    bf[1][2] =  0.25*(1.0-v);
                    bf[1][3] = -0.25*(1.0+u);
                    bf[1][4] = -0.25*(1.0+v);
                    bf[1][5] =  0.25*(1.0-u);
                    bf[1][6] =  0.25*(1.0+v);
                    bf[1][7] =  0.25*(1.0+u);
                }
            }
            else if (_elemType == ElemType::Parallelep)
            {
                u = xSamples[0];
                v = xSamples[1];
                w = xSamples[2];

                // Shape functions
                bf[0][0] = 0.125*(1.0-u)*(1.0-v)*(1.0-w);
                bf[0][1] = 0.125*(1.0+u)*(1.0-v)*(1.0-w);
                bf[0][2] = 0.125*(1.0-u)*(1.0+v)*(1.0-w);
                bf[0][3] = 0.125*(1.0+u)*(1.0+v)*(1.0-w);
                bf[0][4] = 0.125*(1.0-u)*(1.0-v)*(1.0+w);
                bf[0][5] = 0.125*(1.0+u)*(1.0-v)*(1.0+w);
                bf[0][6] = 0.125*(1.0-u)*(1.0+v)*(1.0+w);
                bf[0][7] = 0.125*(1.0+u)*(1.0+v)*(1.0+w);

                // Derivatives
                if (_orderDers > 0)
                {
                    bf[1][0]  = -0.125*(1.0-v)*(1.0-w);
                    bf[1][1]  = -0.125*(1.0-u)*(1.0-w);
                    bf[1][2]  = -0.125*(1.0-u)*(1.0-v);
                    bf[1][3]  =  0.125*(1.0-v)*(1.0-w);
                    bf[1][4]  = -0.125*(1.0+u)*(1.0-w);
                    bf[1][5]  = -0.125*(1.0+u)*(1.0-v);
                    bf[1][6]  = -0.125*(1.0+v)*(1.0-w);
                    bf[1][7]  =  0.125*(1.0-u)*(1.0-w);
                    bf[1][8]  = -0.125*(1.0-u)*(1.0+v);
                    bf[1][9]  =  0.125*(1.0+v)*(1.0-w);
                    bf[1][10] =  0.125*(1.0+u)*(1.0-w);
                    bf[1][11] = -0.125*(1.0+u)*(1.0+v);
                    bf[1][12] = -0.125*(1.0-v)*(1.0+w);
                    bf[1][13] = -0.125*(1.0-u)*(1.0+w);
                    bf[1][14] =  0.125*(1.0-u)*(1.0-v);
                    bf[1][15] =  0.125*(1.0-v)*(1.0+w);
                    bf[1][16] = -0.125*(1.0+u)*(1.0+w);
                    bf[1][17] =  0.125*(1.0+u)*(1.0-v);
                    bf[1][18] = -0.125*(1.0+v)*(1.0+w);
                    bf[1][19] =  0.125*(1.0-u)*(1.0+w);
                    bf[1][20] =  0.125*(1.0-u)*(1.0+v);
                    bf[1][21] =  0.125*(1.0+v)*(1.0+w);
                    bf[1][22] =  0.125*(1.0+u)*(1.0+w);
                    bf[1][23] =  0.125*(1.0+u)*(1.0+v);
                }
            }
            else if (_elemType == ElemType::Triang)
            {
                u = xSamples[0];
                v = xSamples[1];

                // Shape functions
                bf[0][0] = 1.0-u-v;
                bf[0][1] =     u  ;
                bf[0][2] =     v  ;

                // Derivatives
                if (_orderDers > 0)
                {
                    bf[1][0] = -1.0;
                    bf[1][1] = -1.0;
                    bf[1][2] =  1.0;
                    bf[1][3] =  0.0;
                    bf[1][4] =  0.0;
                    bf[1][5] =  1.0;
                }
            }
            else if (_elemType == ElemType::Tetrah)
            {
                u = xSamples[0];
                v = xSamples[1];
                w = xSamples[2];

                // Shape functions
                bf[0][0] = 1.0-u-v-w;
                bf[0][1] =         u;
                bf[0][2] =         v;
                bf[0][3] =         w;

                // Derivatives
                if (_orderDers > 0)
                {
                    bf[1][0]  = -1.0;
                    bf[1][1]  = -1.0;
                    bf[1][2]  = -1.0;

                    bf[1][3]  =  1.0;
                    bf[1][4]  =  0.0;
                    bf[1][5]  =  0.0;

                    bf[1][6]  =  0.0;
                    bf[1][7]  =  1.0;
                    bf[1][8]  =  0.0;

                    bf[1][9]  =  0.0;
                    bf[1][10] =  0.0;
                    bf[1][11] =  1.0;
                }
            }
            else
            {
                throw runtime_error("BasisFunctions::Lagrangian: elem Type not set.");
            }
        }
        else
        {
            // Compute
            int n = 0;
            switch(int(_elemType))
            {
                case static_cast<int>(ElemType::Point):
                    if (_bfType != BasisFuncType::GlobConstr)
                        cout << "Warning: HPLFE_Lagrangian: Point case not implemented" << endl;
                    break;

                case static_cast<int>(ElemType::Line):
                    u = xSamples[0];
                    for (int p = 0; p < _bfOrder+1; p++)
                    {
                        for (int d = 0; d < _orderDers+1; d++)
                        {
                            // 1D Lagrange functions and derivatives
                            Nu[d] = lagrangePolynomialAndDerivatives(u, p, _bfOrder, d);

                            // Store basis functions and derivatives
                            bf[d][n] = Nu[d];
                        }

                        //Increase basis function number
                        n++;
                    }
                    break;

                case static_cast<int>(ElemType::Square):
                    u = xSamples[0];
                    v = xSamples[1];

                    for (int q = 0; q < _bfOrder+1; q++)
                    {
                        for (int p = 0; p < _bfOrder+1; p++)
                        {
                            for (int d = 0; d < _orderDers+1; d++)
                            {
                                int kk = int(pow(_pDim,d));

                                // 1D Lagrange functions and derivatives
                                Nu[d] = lagrangePolynomialAndDerivatives(u, p, _bfOrder, d);
                                Nv[d] = lagrangePolynomialAndDerivatives(v, q, _bfOrder, d);

                                // Compute product rule derivative indices
                                for (int j = 0; j < _pDim; j++)
                                {
                                    idx[j].resize(kk);
                                    int h = 0;
                                    computeProdRuleIndices(idx, j, 0, _pDim, d, h);
                                }

                                // Store basis functions and derivatives
                                for (int k = 0; k < kk; k++)
                                    bf[d][kk*n+k] = Nu[idx[0][k]] * Nv[idx[1][k]];
                            }

                            //Increase basis function number
                            n++;
                        }
                    }

                    break;

                case static_cast<int>(ElemType::Parallelep):
                    u = xSamples[0];
                    v = xSamples[1];
                    w = xSamples[2];
                    for (int r = 0; r < _bfOrder+1; r++)
                    {
                        for (int q = 0; q < _bfOrder+1; q++)
                        {
                            for (int p = 0; p < _bfOrder+1; p++)
                            {
                                for (int d = 0; d < _orderDers+1; d++)
                                {
                                    int kk = int(pow(_pDim,d));

                                    // 1D Lagrange functions and derivatives
                                    Nu[d] = lagrangePolynomialAndDerivatives(u, p, _bfOrder, d);
                                    Nv[d] = lagrangePolynomialAndDerivatives(v, q, _bfOrder, d);
                                    Nw[d] = lagrangePolynomialAndDerivatives(w, r, _bfOrder, d);

                                    // Compute product rule derivative indices
                                    for (int j = 0; j < _pDim; j++)
                                    {
                                        idx[j].resize(kk);
                                        int h = 0;
                                        computeProdRuleIndices(idx, j, 0, _pDim, d, h);
                                    }

                                    // Store basis functions and derivatives
                                    for (int k = 0; k < kk; k++)
                                        bf[d][kk*n+k] = Nu[idx[0][k]] * Nv[idx[1][k]] * Nw[idx[2][k]];
                                }

                                // Increase basis function number
                                n++;
                            }
                        }
                    }
                    break;

                case static_cast<int>(ElemType::Triang):
                    u = xSamples[0];
                    v = xSamples[1];
                    t = 1.0 - u - v;
                    for (int q = 0; q < _bfOrder+1; q++)
                    {
                        for (int p = 0; p < _bfOrder+1-q; p++)
                        {
                            int s = _bfOrder - p - q;

                            // 1D Lagrange functions and derivatives
                            for (int i=0; i<_orderDers+1; i++)
                            {
                                Nu[i] = triangularPolynomialAndDerivatives(u, p, i, _bfOrder);
                                Nv[i] = triangularPolynomialAndDerivatives(v, q, i, _bfOrder);
                                Nt[i] = triangularPolynomialAndDerivatives(t, s, i, _bfOrder);
                            }

                            // Basis functions and derivatives
                            bf[0][n] = Nu[0]*Nv[0]*Nt[0];

                            // First-order derivatives
                            if (_orderDers>0)
                            {
                                bf[1][2*n+0] = Nu[1]*Nv[0]*Nt[0] - Nu[0]*Nv[0]*Nt[1];
                                bf[1][2*n+1] = Nu[0]*Nv[1]*Nt[0] - Nu[0]*Nv[0]*Nt[1];
                            }

                            // Second-order derivatives
                            if (_orderDers > 1)
                            {
                                bf[2][4*n+0] =
                                Nu[2]*Nv[0]*Nt[0] - Nu[1]*Nv[0]*Nt[1]
                                - Nu[1]*Nv[0]*Nt[1] + Nu[0]*Nv[0]*Nt[2];
                                bf[2][4*n+1] =
                                Nu[1]*Nv[1]*Nt[0] - Nu[0]*Nv[1]*Nt[1]
                                - Nu[1]*Nv[0]*Nt[1] + Nu[0]*Nv[0]*Nt[2];
                                bf[2][4*n+2] =
                                Nu[1]*Nv[1]*Nt[0] - Nu[1]*Nv[0]*Nt[1]
                                - Nu[0]*Nv[1]*Nt[1] + Nu[0]*Nv[0]*Nt[2];
                                bf[2][4*n+3] =
                                Nu[0]*Nv[2]*Nt[0] - Nu[0]*Nv[1]*Nt[1]
                                - Nu[0]*Nv[1]*Nt[1] + Nu[0]*Nv[0]*Nt[2];
                            }

                            // Third-order derivatives
                            if (_orderDers > 2)
                            {
                                bf[3][8*n+0] =
                                Nu[3]*Nv[0]*Nt[0] - Nu[2]*Nv[0]*Nt[1]
                                - Nu[2]*Nv[0]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                - Nu[2]*Nv[0]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                + Nu[1]*Nv[0]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                                bf[3][8*n+1] =
                                Nu[2]*Nv[1]*Nt[0] - Nu[1]*Nv[1]*Nt[1]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                - Nu[2]*Nv[0]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                + Nu[1]*Nv[0]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                                bf[3][8*n+2] =
                                Nu[2]*Nv[1]*Nt[0] - Nu[1]*Nv[1]*Nt[1]
                                - Nu[2]*Nv[0]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                + Nu[1]*Nv[0]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                                bf[3][8*n+3] =
                                Nu[1]*Nv[2]*Nt[0] - Nu[0]*Nv[2]*Nt[1]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                + Nu[1]*Nv[0]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                                bf[3][8*n+4] =
                                Nu[2]*Nv[1]*Nt[0] - Nu[2]*Nv[0]*Nt[1]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                + Nu[0]*Nv[1]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                                bf[3][8*n+5] =
                                Nu[1]*Nv[2]*Nt[0] - Nu[1]*Nv[1]*Nt[1]
                                - Nu[0]*Nv[2]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                + Nu[0]*Nv[1]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                                bf[3][8*n+6] =
                                Nu[1]*Nv[2]*Nt[0] - Nu[1]*Nv[1]*Nt[1]
                                - Nu[1]*Nv[1]*Nt[1] + Nu[1]*Nv[0]*Nt[2]
                                - Nu[0]*Nv[2]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                + Nu[0]*Nv[1]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                                bf[3][8*n+7] =
                                Nu[0]*Nv[3]*Nt[0] - Nu[0]*Nv[2]*Nt[1]
                                - Nu[0]*Nv[2]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                - Nu[0]*Nv[2]*Nt[1] + Nu[0]*Nv[1]*Nt[2]
                                + Nu[0]*Nv[1]*Nt[2] - Nu[0]*Nv[0]*Nt[3];
                            }

                            // Higher-order
                            if (_orderDers > 3)
                            {
                                if (_adjcyEN != null)
                                {
                                    if (_adjcyEN->myRank() == 0)
                                        cout << "Lagrangian::computeBasisFunctionsReference:: Basis function derivatives higher than 3 not implemented for triang." << endl;
                                }
                                else
                                {
                                    cout << "Lagrangian::computeBasisFunctionsReference:: Basis function derivatives higher than 3 not implemented for triang." << endl;
                                }
                            }

                            //Increase basis function number
                            n++;
                        }
                    }
                    break;
                case static_cast<int>(ElemType::Tetrah):
                    u = xSamples[0];
                    v = xSamples[1];
                    w = xSamples[2];
                    t = 1.0 - u - v - w;
                    for (int r = 0; r < _bfOrder+1; r++)
                    {
                        for (int q = 0; q < _bfOrder+1-r; q++)
                        {
                            for (int p = 0; p < _bfOrder+1-q-r; p++)
                            {
                                int s = _bfOrder - p - q - r;

                                // 1D Lagrange functions and derivatives
                                for (int i=0; i<_orderDers+1; i++)
                                {
                                    Nu[i] = triangularPolynomialAndDerivatives(u, p, i, _bfOrder);
                                    Nv[i] = triangularPolynomialAndDerivatives(v, q, i, _bfOrder);
                                    Nw[i] = triangularPolynomialAndDerivatives(w, r, i, _bfOrder);
                                    Nt[i] = triangularPolynomialAndDerivatives(t, s, i, _bfOrder);
                                }

                                // Basis functions
                                bf[0][n] = Nu[0]*Nv[0]*Nw[0]*Nt[0];

                                // First-order derivatives
                                if (_orderDers > 0)
                                {
                                    bf[1][3*n+0] = Nu[1]*Nv[0]*Nw[0]*Nt[0] - Nu[0]*Nv[0]*Nw[0]*Nt[1];
                                    bf[1][3*n+1] = Nu[0]*Nv[1]*Nw[0]*Nt[0] - Nu[0]*Nv[0]*Nw[0]*Nt[1];
                                    bf[1][3*n+2] = Nu[0]*Nv[0]*Nw[1]*Nt[0] - Nu[0]*Nv[0]*Nw[0]*Nt[1];
                                }

                                // Second-order derivatives
                                if (_orderDers > 1)
                                {
                                    bf[2][9*n+0] =
                                    Nu[2]*Nv[0]*Nw[0]*Nt[0] - Nu[1]*Nv[0]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[0]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+1] =
                                    Nu[1]*Nv[1]*Nw[0]*Nt[0] - Nu[0]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[0]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+2] =
                                    Nu[1]*Nv[0]*Nw[1]*Nt[0] - Nu[0]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[0]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+3] =
                                    Nu[1]*Nv[1]*Nw[0]*Nt[0] - Nu[1]*Nv[0]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+4] =
                                    Nu[0]*Nv[2]*Nw[0]*Nt[0] - Nu[0]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+5] =
                                    Nu[0]*Nv[1]*Nw[1]*Nt[0] - Nu[0]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+6] =
                                    Nu[1]*Nv[0]*Nw[1]*Nt[0] - Nu[1]*Nv[0]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+7] =
                                    Nu[0]*Nv[1]*Nw[1]*Nt[0] - Nu[0]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                    bf[2][9*n+8] =
                                    Nu[0]*Nv[0]*Nw[2]*Nt[0] - Nu[0]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[0]*Nt[2];
                                }

                                // Third-order derivatives
                                if (_orderDers > 2)
                                {
                                    bf[3][27*n+0] =
                                    Nu[3]*Nv[0]*Nw[0]*Nt[0] - Nu[2]*Nv[0]*Nw[0]*Nt[1]
                                    - Nu[2]*Nv[0]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[2]*Nv[0]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+1] =
                                    Nu[2]*Nv[1]*Nw[0]*Nt[0] - Nu[1]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[2]*Nv[0]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+2] =
                                    Nu[2]*Nv[0]*Nw[1]*Nt[0] - Nu[1]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[2]*Nv[0]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+3] =
                                    Nu[2]*Nv[1]*Nw[0]*Nt[0] - Nu[1]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[2]*Nv[0]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+4] =
                                    Nu[1]*Nv[2]*Nw[0]*Nt[0] - Nu[0]*Nv[2]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+5] =
                                    Nu[1]*Nv[1]*Nw[1]*Nt[0] - Nu[0]*Nv[1]*Nw[1]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+6] =
                                    Nu[2]*Nv[0]*Nw[1]*Nt[0] - Nu[1]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[2]*Nv[0]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+7] =
                                    Nu[1]*Nv[1]*Nw[1]*Nt[0] - Nu[0]*Nv[1]*Nw[1]*Nt[1]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+8] =
                                    Nu[1]*Nv[0]*Nw[2]*Nt[0] - Nu[0]*Nv[0]*Nw[2]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[1]*Nv[0]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+9] =
                                    Nu[2]*Nv[1]*Nw[0]*Nt[0] - Nu[2]*Nv[0]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+10] =
                                    Nu[1]*Nv[2]*Nw[0]*Nt[0] - Nu[1]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[2]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+11] =
                                    Nu[1]*Nv[1]*Nw[1]*Nt[0] - Nu[1]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+12] =
                                    Nu[1]*Nv[2]*Nw[0]*Nt[0] - Nu[1]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[2]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+13] =
                                    Nu[0]*Nv[3]*Nw[0]*Nt[0] - Nu[0]*Nv[2]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[2]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[2]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+14] =
                                    Nu[0]*Nv[2]*Nw[1]*Nt[0] - Nu[0]*Nv[1]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[0]*Nv[2]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+15] =
                                    Nu[1]*Nv[1]*Nw[1]*Nt[0] - Nu[1]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[1]*Nv[1]*Nw[0]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+16] =
                                    Nu[0]*Nv[2]*Nw[1]*Nt[0] - Nu[0]*Nv[1]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[2]*Nw[0]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+17] =
                                    Nu[0]*Nv[1]*Nw[2]*Nt[0] - Nu[0]*Nv[0]*Nw[2]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[0]*Nv[1]*Nw[0]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+18] =
                                    Nu[2]*Nv[0]*Nw[1]*Nt[0] - Nu[2]*Nv[0]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+19] =
                                    Nu[1]*Nv[1]*Nw[1]*Nt[0] - Nu[1]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+20] =
                                    Nu[1]*Nv[0]*Nw[2]*Nt[0] - Nu[1]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[0]*Nw[2]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+21] =
                                    Nu[1]*Nv[1]*Nw[1]*Nt[0] - Nu[1]*Nv[1]*Nw[0]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+22] =
                                    Nu[0]*Nv[2]*Nw[1]*Nt[0] - Nu[0]*Nv[2]*Nw[0]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+23] =
                                    Nu[0]*Nv[1]*Nw[2]*Nt[0] - Nu[0]*Nv[1]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[0]*Nw[2]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+24] =
                                    Nu[1]*Nv[0]*Nw[2]*Nt[0] - Nu[1]*Nv[0]*Nw[1]*Nt[1]
                                    - Nu[1]*Nv[0]*Nw[1]*Nt[1] + Nu[1]*Nv[0]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[0]*Nw[2]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+25] =
                                    Nu[0]*Nv[1]*Nw[2]*Nt[0] - Nu[0]*Nv[1]*Nw[1]*Nt[1]
                                    - Nu[0]*Nv[1]*Nw[1]*Nt[1] + Nu[0]*Nv[1]*Nw[0]*Nt[2]
                                    - Nu[0]*Nv[0]*Nw[2]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];
                                    bf[3][27*n+26] =
                                    Nu[0]*Nv[0]*Nw[3]*Nt[0] - Nu[0]*Nv[0]*Nw[2]*Nt[1]
                                    - Nu[0]*Nv[0]*Nw[2]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    - Nu[0]*Nv[0]*Nw[2]*Nt[1] + Nu[0]*Nv[0]*Nw[1]*Nt[2]
                                    + Nu[0]*Nv[0]*Nw[1]*Nt[2] - Nu[0]*Nv[0]*Nw[0]*Nt[3];

                                }

                                // Higher-order
                                if (_orderDers > 3)
                                {
                                    if (_adjcyEN != null)
                                    {
                                        if (_adjcyEN->myRank() == 0)
                                            cout << "Lagrangian::computeBasisFunctionsReference:: Basis function derivatives higher than 3 not implemented for tetrah." << endl;
                                    }
                                    else
                                    {
                                        cout << "Lagrangian::computeBasisFunctionsReference:: Basis function derivatives higher than 3 not implemented for tetrah." << endl;
                                    }
                                }

                                //Increase basis function number
                                n++;
                            }
                        }
                    }
                    break;
                default:
                    throw runtime_error("BasisFunctions::Lagrangian: elem Type not set.");
                    break;
            }
        }
    }

    vector<vector<double>>& Lagrangian::computeBasisFunctionsReference(vector<double>& xSamples, int tag)
    {
        computeBasisFunctionsReference(_auxRefBF, xSamples, tag);

        return _auxRefBF;
    }

}// end namespace
