/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef NURBS_H
#define NURBS_H

#include "hl_BasisFunctions.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of NURBS until third-order. They are compatible with lines, squares and parallelepipeds.
    */
    class Nurbs : public BasisFunctions
    {
        public:

            Nurbs() = default;
            Nurbs(Nurbs &&other) = default;
            ~Nurbs() = default;
            Nurbs& operator=(Nurbs&& other) = default;

            Nurbs& operator=(const Nurbs& other) = delete;
            Nurbs(const Nurbs& other) = delete;

            // Setters for expert users
            inline void setNElemDir(int nEx, int nEy = -1, int nEz = -1){_nEx = nEx; _nEy = nEy; _nEz = nEz;}
            inline void setBasisFunctionOrderDir(int bfOrderX, int bfOrderY, int bfOrderZ){_bfOrderX = bfOrderX; _bfOrderY = bfOrderY; _bfOrderZ = bfOrderZ;}
            inline void setGlobKnots(std::vector<double> uKnot, std::vector<double> vKnot = std::vector<double> (), std::vector<double> wKnot = std::vector<double> ()){_uKnot = uKnot; _vKnot = vKnot; _wKnot = wKnot;}
            inline void setGlobWeights(std::vector<double> weights){_weights = weights;}

            // Update
            void Update() override;

            // Getters
            int getNumNbors(int tag) override {(void) tag; return _nVert;}
            std::tuple<int, int, int> nElemDir() const {return std::make_tuple(_nEx, _nEy, _nEz);};
            std::tuple<int, int, int> bfOrderDir() const {return std::make_tuple(_bfOrderX, _bfOrderY, _bfOrderZ);};
            std::tuple<std::vector<double>,std::vector<double>,std::vector<double>> knots() const {return std::make_tuple(_uKnot, _vKnot, _wKnot);}
            std::vector<double> weights() const {return _weights;}


            void computeBasisFunctionsReference(std::vector<std::vector<double>>& bf, std::vector<double>& xSamples, int tag = 0) override;
            std::vector<std::vector<double>>& computeBasisFunctionsReference(std::vector<double>& xSamples, int tag = 0) override;


        private:
            int _nEx{-1}, _nEy{-1}, _nEz{-1};
            int _bfOrderX, _bfOrderY, _bfOrderZ;
            std::vector<double> _uKnot, _vKnot, _wKnot;
            std::vector<double> _weights;
            void _checkSettings();

            std::vector<std::vector<double>> Nu, Nv, Nw;
            std::vector<std::vector<int>> idx;
            std::vector<std::vector<std::vector<int>>> iidx;
    };


}

#endif
