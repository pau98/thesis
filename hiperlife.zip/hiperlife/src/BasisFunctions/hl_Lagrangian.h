/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LAGRANGIAN_H
#define LAGRANGIAN_H

#include "hl_BasisFunctions.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of arbitrary order Lagrangian basis functions compatible with any mesh.
    */
    class Lagrangian : public BasisFunctions
    {
        public:

            Lagrangian() = default;
            Lagrangian(Lagrangian &&other) = default;
            ~Lagrangian() = default;
            Lagrangian& operator=(Lagrangian&& other) = default;

            Lagrangian& operator=(const Lagrangian& other) = delete;
            Lagrangian(const Lagrangian& other) = delete;

            void Update() override;

            int getNumNbors(int tag) override {(void) tag; return _nVert;}


            void computeBasisFunctionsReference(std::vector<std::vector<double>>& bf, std::vector<double>& xSamples, int tag = 0) override;
            std::vector<std::vector<double>>& computeBasisFunctionsReference(std::vector<double>& xSamples, int tag = 0) override;


        private:
            void _checkSettings();

            std::vector<double> Nu, Nv, Nw, Nt;
            std::vector<std::vector<int>> idx;

    };


}

#endif
