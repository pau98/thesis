/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <vector>
#include <array>

#include <Teuchos_RCP.hpp>

#include "hl_SubFillStructure.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{
    void SubFillStructure::Update()
    {
        // Checks
        if (dhandDHand == null && dhandCubas == null && dhandBFSet == null)
            throw runtime_error("SubFillStructure::Update: Structures are not set.");

        // Set variables that do not change
        nDim = dhandDHand->mesh->nDim();
        pDim = dhandDHand->mesh->_basisFunctions->pDim();
        numDOFs = dhandDHand->numDOFs();
        numAuxF = dhandDHand->numNodeAuxF();

        // Resize integration point coordinates
        x_sample.resize(static_cast<unsigned long>(pDim));

        // Reserve space for vectors based on maxNumNbors
        maxNbors = dhandDHand->mesh->_adjcyEN->maxNumNbors();
        nborCoords.reserve(maxNbors * nDim);
        nborAuxF.reserve(maxNbors * numAuxF);
        nborDOFs0.reserve(maxNbors * numDOFs);
        nborDOFs.reserve(maxNbors * numDOFs);

        // FIXME Check passSols!!!
        passSol0 = true;
        passSol  = true;
        passAuxF = true;
    }

    void SubFillStructure::resizeVectors(int nbors)
    {
        nborCoords.resize(nbors * nDim);
        nborAuxF.resize(nbors * numAuxF);
        nborDOFs0.resize(nbors * numDOFs);
        nborDOFs.resize(nbors * numDOFs);
    }

    double* SubFillStructure::nborBasisFunctionsDerivatives(int order)
    {
        int j_intPt{0};
        for (int d = 0; d < order; d++)
            j_intPt = j_intPt * pDim + 1;
        j_intPt = j_intPt * eNN;

        return &bfs[j_intPt];
    }

    double* SubFillStructure::nborBFsDers(int order)
    {
        int j_intPt{0};
        for (int d = 0; d < order; d++)
            j_intPt = j_intPt * pDim + 1;
        j_intPt = j_intPt * eNN;

        return &bfs[j_intPt];
    }

    vector<double> SubFillStructure::tangentsBoundaryRef()
    {
        vector<double> tangents;

        if (cubaInfo.cubaName == "CubatureBorderGauss")
        {
            if (dhandDHand->mesh->elemType() == ElemType::Line)
            {
                tangents.resize(2);

                if (cubaInfo.cubaType == 1)      // xMin
                {
                    tangents[0] = 0.0;
                    tangents[1] = -1.0;
                }
                else if (cubaInfo.cubaType == 2) // xMax
                {
                    tangents[0] = 0.0;
                    tangents[1] = 1.0;
                }
                else
                {
                    throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                }
            }
            else if (dhandDHand->mesh->elemType() == ElemType::Triang)
            {
                tangents.resize(2);

                if (cubaInfo.cubaType == 1) //horizontal line
                {
                    tangents[0] = 1.0;
                    tangents[1] = 0.0;
                }
                else if (cubaInfo.cubaType == 2) //tilted line
                {
                    tangents[0] = -1.0/sqrt(2.0);
                    tangents[1] = 1.0/sqrt(2.0);
                }
                else if (cubaInfo.cubaType == 3) //vertical line
                {
                    tangents[0] = 0.0;
                    tangents[1] = -1.0;
                }
                else
                {
                    throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                }
            }
            else if (dhandDHand->mesh->elemType() == ElemType::Square)
            {
                tangents.resize(2);

                if (cubaInfo.cubaType == 1) //Ymin
                {
                    tangents[0] = 1.0;
                    tangents[1] = 0.0;
                }
                else if (cubaInfo.cubaType == 2) //Xmax
                {
                    tangents[0] = 0.0;
                    tangents[1] = 1.0;
                }
                else if (cubaInfo.cubaType == 3) //Ymax
                {
                    tangents[0] = -1.0;
                    tangents[1] = 0.0;
                }
                else if (cubaInfo.cubaType == 4) //Xmin
                {
                    tangents[0] = 0.0;
                    tangents[1] = -1.0;
                }
                else
                {
                    throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + "undefined");
                }
            }
            else if (dhandDHand->mesh->elemType() == ElemType::Tetrah)
            {
                tangents.resize(6);

                if (cubaInfo.cubaType == 1) // Zmin
                {
                    tangents[0] = 0.0;
                    tangents[1] = 1.0;
                    tangents[2] = 0.0;

                    tangents[3] = 1.0;
                    tangents[4] = 0.0;
                    tangents[5] = 0.0;
                }
                else if (cubaInfo.cubaType == 2) // Ymin
                {
                    tangents[0] = 1.0;
                    tangents[1] = 0.0;
                    tangents[2] = 0.0;

                    tangents[3] = 0.0;
                    tangents[4] = 0.0;
                    tangents[5] = 1.0;
                }
                else if (cubaInfo.cubaType == 3) // tilted vertical plane
                {
                    tangents[0] = 1.0/sqrt(2.0);
                    tangents[1] = 0.0;
                    tangents[2] = -1.0/sqrt(2.0);

                    tangents[3] = 0.0;
                    tangents[4] = 1.0/sqrt(2.0);
                    tangents[5] = -1.0/sqrt(2.0);
                }
                else if (cubaInfo.cubaType == 4) // Xmin
                {
                    tangents[0] = 0.0;
                    tangents[1] = 0.0;
                    tangents[2] = 1.0;

                    tangents[3] = 0.0;
                    tangents[4] = 1.0;
                    tangents[5] = 0.0;
                }
                else
                {
                    throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + "undefined");
                }
            }
            else if (dhandDHand->mesh->elemType() == ElemType::Parallelep)
            {
                tangents.resize(6);

                if (cubaInfo.cubaType == 1) //lower horizontal plane (Zmin)
                {
                    tangents[0] = 0.0;
                    tangents[1] = -1.0;
                    tangents[2] = 0.0;

                    tangents[3] = -1.0;
                    tangents[4] = 0.0;
                    tangents[5] = 0.0;
                }
                else if (cubaInfo.cubaType == 2) //lower vertical plane (Ymin)
                {
                    tangents[0] = -1.0;
                    tangents[1] = 0.0;
                    tangents[2] = 0.0;

                    tangents[3] = 0.0;
                    tangents[4] = 0.0;
                    tangents[5] = -1.0;
                }
                else if (cubaInfo.cubaType == 3) //right vertical plane (Xmin)
                {
                    tangents[0] = 0.0;
                    tangents[1] = 0.0;
                    tangents[2] = -1.0;

                    tangents[3] = 0.0;
                    tangents[4] = -1.0;
                    tangents[5] = 0.0;
                }
                else if (cubaInfo.cubaType == 4) //upper vertical plane (Ymax)
                {
                    tangents[0] = 0.0;
                    tangents[1] = 0.0;
                    tangents[2] = 1.0;

                    tangents[3] = 1.0;
                    tangents[4] = 0.0;
                    tangents[5] = 0.0;
                }
                else if (cubaInfo.cubaType == 5) //left vertical plane (Xmax)
                {
                    tangents[0] = 0.0;
                    tangents[1] = 1.0;
                    tangents[2] = 0.0;

                    tangents[3] = 0.0;
                    tangents[4] = 0.0;
                    tangents[5] = 1.0;
                }
                else if (cubaInfo.cubaType == 6) //upper horizontal plane (Zmax)
                {
                    tangents[0] = 1.0;
                    tangents[1] = 0.0;
                    tangents[2] = 0.0;

                    tangents[3] = 0.0;
                    tangents[4] = 1.0;
                    tangents[5] = 0.0;
                }
                else
                {
                    throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + "undefined");
                }
            }
            else
            {
                throw runtime_error("SubFillStructure::tangentsBoundaryRef: elem Type " + str(dhandDHand->mesh->elemType()) + " not programmed yet");
            }
        }
        else if (cubaInfo.cubaName == "CubatureBorderIntersection")
        {
            switch (static_cast<int>(dhandDHand->mesh->elemType()))
            {
                case static_cast<int>(ElemType::Triang):
                    tangents.resize(4);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // XminYmin
                            // Tangent from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = -1.0;

                            // Tangent from Ymin
                            tangents[2] = -1.0;
                            tangents[3] = 0.0;

                            break;
                        case 1: // Xmax
                            // Tangent from tilted edge
                            tangents[0] = 1.0 / sqrt(2);
                            tangents[1] = -1.0 / sqrt(2);

                            // Tangent from Ymin
                            tangents[2] = 1.0;
                            tangents[3] = 0.0;

                            break;
                        case 2: // Ymax
                            // Tangent from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = 1.0;

                            // Tangent from tilted edge
                            tangents[2] = -1.0 / sqrt(2);
                            tangents[3] = 1.0 / sqrt(2);

                            break;
                        default:
                            throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + "undefined on border intersections.");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Square):
                    tangents.resize(4);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // XminYmin
                            // Tangent from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = -1.0;

                            // Tangent from Ymin
                            tangents[2] = -1.0;
                            tangents[3] = 0.0;

                            break;
                        case 1: // XmaxYmin
                            // Tanget from Xmax
                            tangents[0] = 0.0;
                            tangents[1] = -1.0;

                            // Tangent from Ymin
                            tangents[2] = 1.0;
                            tangents[3] = 0.0;

                            break;
                        case 2: // XminYmax
                            // Tanget from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = 1.0;

                            // Tangent from Ymax
                            tangents[2] = -1.0;
                            tangents[3] = 0.0;

                            break;
                        case 3: // XmaxYmax
                            // Tanget from Xmax
                            tangents[0] = 0.0;
                            tangents[1] = 1.0;

                            // Tangent from Ymax
                            tangents[2] = 1.0;
                            tangents[3] = 0.0;

                            break;
                        default:
                            throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + "undefined on border intersections.");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Tetrah):
                    tangents.resize(12);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // YminZmin
                            // Tangents from Ymin
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = -1.0;

                            tangents[3] = 1.0;
                            tangents[4] = 0.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmin
                            tangents[6] = 0.0;
                            tangents[7] = -1.0;
                            tangents[8] = 0.0;

                            tangents[9] = -1.0;
                            tangents[10] = 0.0;
                            tangents[11] = 0.0;

                            break;
                        case 1: // XminZmin
                            // Tangents from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = -1.0;

                            tangents[3] = 0.0;
                            tangents[4] = -1.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmin
                            tangents[6] = -1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 1.0;
                            tangents[11] = 0.0;

                            break;
                        case 2: // XminYmin
                            // Tangents from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = -1.0;
                            tangents[2] = 0.0;

                            tangents[3] = 0.0;
                            tangents[4] = 0.0;
                            tangents[5] = 1.0;

                            // Tangents from Ymin
                            tangents[6] = -1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 0.0;
                            tangents[11] = -1.0;

                            break;
                        case 3: // Xmin
                            // Tangents from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = 1.0 / sqrt(2.0);
                            tangents[2] = 1.0 / sqrt(2.0);

                            tangents[3] = 0.0;
                            tangents[4] = 1.0 / sqrt(2.0);
                            tangents[5] = -1.0 / sqrt(2.0);

                            // Tangents from tilted Plane
                            tangents[6] = -sqrt(0.6e1) / 0.3e1;
                            tangents[7] = sqrt(0.6e1) / 0.6e1;
                            tangents[8] = sqrt(0.6e1) / 0.6e1;

                            tangents[9] = 0.0;
                            tangents[10] = -1.0 / sqrt(2.0);
                            tangents[11] = 1.0 / sqrt(2.0);

                            break;
                        case 4: // Ymin
                            // Tangents from Ymin
                            tangents[0] = 1.0 / sqrt(2.0);
                            tangents[1] = 0.0;
                            tangents[2] = 1.0 / sqrt(2.0);

                            tangents[3] = -1.0 / sqrt(2.0);
                            tangents[4] = 0.0;
                            tangents[5] = 1.0 / sqrt(2.0);

                            // Tangents from tilted Plane
                            tangents[6] = sqrt(0.6e1) / 0.6e1;
                            tangents[7] = -sqrt(0.6e1) / 0.3e1;
                            tangents[8] = sqrt(0.6e1) / 0.6e1;

                            tangents[9] = 1.0 / sqrt(2.0);
                            tangents[10] = 0.0;
                            tangents[11] = -1.0 / sqrt(2.0);

                            break;
                        case 5: // Zmin
                            // Tangents from Zmin
                            tangents[0] = 1.0 / sqrt(2.0);
                            tangents[1] = 1.0 / sqrt(2.0);
                            tangents[2] = 0.0;

                            tangents[3] = 1.0 / sqrt(2.0);
                            tangents[4] = -1.0 / sqrt(2.0);
                            tangents[5] = 0.0;

                            // Tangents from tilted Plane
                            tangents[6] = sqrt(0.6e1) / 0.6e1;
                            tangents[7] = sqrt(0.6e1) / 0.6e1;
                            tangents[8] = -sqrt(0.6e1) / 0.3e1;

                            tangents[9] = -1.0 / sqrt(2.0);
                            tangents[10] = 1.0 / sqrt(2.0);
                            tangents[11] = 0.0;

                            break;
                        default:
                            throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + "undefined on border intersections.");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Parallelep):
                    tangents.resize(12);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // YminZmin
                            // Tangents from Zmin (1)
                            tangents[0] = 0.0;
                            tangents[1] = -1.0;
                            tangents[2] = 0.0;

                            tangents[3] = -1.0;
                            tangents[4] = 0.0;
                            tangents[5] = 0.0;

                            // Tangents from Ymin (2)
                            tangents[6] = 0.0;
                            tangents[7] = 0.0;
                            tangents[8] = -1.0;

                            tangents[9] = 1.0;
                            tangents[10] = 0.0;
                            tangents[11] = 0.0;

                            break;
                        case 1: // XmaxZmin
                            // Tangents from Xmax
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = -1.0;

                            tangents[3] = 0.0;
                            tangents[4] = 1.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmin
                            tangents[6] = 1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = -1.0;
                            tangents[11] = 0.0;

                            break;
                        case 2: // YmaxZmin
                            // Tangents from Ymax
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = -1.0;

                            tangents[3] = -1.0;
                            tangents[4] = 0.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmin
                            tangents[6] = 0.0;
                            tangents[7] = 1.0;
                            tangents[8] = 0.0;

                            tangents[9] = 1.0;
                            tangents[10] = 0.0;
                            tangents[11] = 0.0;

                            break;
                        case 3: // XminZmin
                            // Tangents from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = -1.0;

                            tangents[3] = 0.0;
                            tangents[4] = -1.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmin
                            tangents[6] = -1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 1.0;
                            tangents[11] = 0.0;

                            break;
                        case 4: // YminZmax
                            // Tangents from Ymin
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = 1.0;

                            tangents[3] = -1.0;
                            tangents[4] = 0.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmax
                            tangents[6] = 0.0;
                            tangents[7] = -1.0;
                            tangents[8] = 0.0;

                            tangents[9] = 1.0;
                            tangents[10] = 0.0;
                            tangents[11] = 0.0;

                            break;
                        case 5: // XmaxZmax
                            // Tangents from Xmax
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = 1.0;

                            tangents[3] = 0.0;
                            tangents[4] = -1.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmax
                            tangents[6] = 1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 1.0;
                            tangents[11] = 0.0;

                            break;
                        case 6: // YmaxZmax
                            // Tangents from Ymax
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = 1.0;

                            tangents[3] = 1.0;
                            tangents[4] = 0.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmax
                            tangents[6] = 0.0;
                            tangents[7] = 1.0;
                            tangents[8] = 0.0;

                            tangents[9] = -1.0;
                            tangents[10] = 0.0;
                            tangents[11] = 0.0;

                            break;
                        case 7: // XminZmax
                            // Tangents from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = 0.0;
                            tangents[2] = 1.0;

                            tangents[3] = 0.0;
                            tangents[4] = 1.0;
                            tangents[5] = 0.0;

                            // Tangents from Zmax
                            tangents[6] = -1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = -1.0;
                            tangents[11] = 0.0;

                            break;
                        case 8: // XminYmin
                            // Tangents from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = -1.0;
                            tangents[2] = 0.0;

                            tangents[3] = 0.0;
                            tangents[4] = 0.0;
                            tangents[5] = 1.0;

                            // Tangents from Ymin
                            tangents[6] = -1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 0.0;
                            tangents[11] = -1.0;

                            break;
                        case 9: // XmaxYmin
                            // Tangents from Xmax
                            tangents[0] = 0.0;
                            tangents[1] = -1.0;
                            tangents[2] = 0.0;

                            tangents[3] = 0.0;
                            tangents[4] = 0.0;
                            tangents[5] = -1.0;

                            // Tangents from Ymin
                            tangents[6] = 1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 0.0;
                            tangents[11] = 1.0;

                            break;
                        case 10: // XmaxYmax
                            // Tangents from Xmax
                            tangents[0] = 0.0;
                            tangents[1] = 1.0;
                            tangents[2] = 0.0;

                            tangents[3] = 0.0;
                            tangents[4] = 0.0;
                            tangents[5] = 1.0;

                            // Tangents from Ymax
                            tangents[6] = 1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 0.0;
                            tangents[11] = -1.0;

                            break;
                        case 11: // XminYmax
                            // Tangents from Xmin
                            tangents[0] = 0.0;
                            tangents[1] = 1.0;
                            tangents[2] = 0.0;

                            tangents[3] = 0.0;
                            tangents[4] = 0.0;
                            tangents[5] = -1.0;

                            // Tangents from Ymax
                            tangents[6] = -1.0;
                            tangents[7] = 0.0;
                            tangents[8] = 0.0;

                            tangents[9] = 0.0;
                            tangents[10] = 0.0;
                            tangents[11] = 1.0;

                            break;
                        default:
                            throw runtime_error("SubFillStructure::tangentsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + "undefined on border intersections.");
                            break;
                    }
                    break;
                default:
                    throw runtime_error("SubFillStructure::tangentsBoundaryRef: elem Type " + str(dhandDHand->mesh->elemType()) + " not programmed yet for border intersetions");
                    break;
            }
        }
        else
        {
            throw runtime_error("SubFillStructure::tangentsBoundaryRef: Tangent vectors not implemented for this cubature name: " + cubaInfo.cubaName + ".\n");
        }
        return tangents;
    }

    vector<double> SubFillStructure::normalsBoundaryRef()
    {
        vector<double> normals{};
        if (cubaInfo.cubaName == "CubatureBorderGauss")
        {
            switch (static_cast<int>(dhandDHand->mesh->elemType()))
            {
                case static_cast<int>(ElemType::Line):
                    normals.resize(2);
                    switch (cubaInfo.cubaType)
                    {
                    case 1:
                        normals[0] = -1.0;
                        normals[1] = 0.0;
                        break;

                    case 2:
                        normals[0] = 1.0;
                        normals[1] = 0.0;
                        break;

                    default:
                        throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                        break;
                    }
                    break;
                case static_cast<int>(ElemType::Triang):
                    normals.resize(2);
                    switch (cubaInfo.cubaType)
                    {
                        case 1:
                            normals[0] = 0.0;
                            normals[1] = -1.0;
                            break;
                        case 2:
                            normals[0] = 1.0 / sqrt(2);
                            normals[1] = 1.0 / sqrt(2);
                            break;
                        case 3:
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Square):
                    normals.resize(2);
                    switch (cubaInfo.cubaType)
                    {
                        case 1:
                            normals[0] = 0.0;
                            normals[1] = -1.0;
                            break;
                        case 2:
                            normals[0] = 1.0;
                            normals[1] = 0.0;
                            break;
                        case 3:
                            normals[0] = 0.0;
                            normals[1] = 1.0;
                            break;
                        case 4:
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Tetrah):
                    normals.resize(3);
                    switch (cubaInfo.cubaType)
                    {
                        case 1:
                            normals[0] = 0.0;
                            normals[1] = 0.0;
                            normals[2] = -1.0;
                            break;
                        case 2:
                            normals[0] = 0.0;
                            normals[1] = -1.0;
                            normals[2] = 0.0;
                            break;
                        case 3:
                            normals[0] = 1.0 / sqrt(3.0);
                            normals[1] = 1.0 / sqrt(3.0);
                            normals[2] = 1.0 / sqrt(3.0);
                            break;
                        case 4:
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Parallelep):
                    normals.resize(3);
                    switch (cubaInfo.cubaType)
                    {
                        case 1:
                            normals[0] = 0.0;
                            normals[1] = 0.0;
                            normals[2] = -1.0;
                            break;
                        case 2:
                            normals[0] = 0.0;
                            normals[1] = -1.0;
                            normals[2] = 0.0;
                            break;
                        case 3:
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;
                            break;
                        case 4:
                            normals[0] = 0.0;
                            normals[1] = 1.0;
                            normals[2] = 0.0;
                            break;
                        case 5:
                            normals[0] = 1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;
                            break;
                        case 6:
                            normals[0] = 0.0;
                            normals[1] = 0.0;
                            normals[2] = 1.0;
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                default:
                    throw runtime_error("SubFillStructure::normalsBoundaryRef: elem Type " + str(dhandDHand->mesh->elemType()) + "not programmed yet for border intersetions");
                    break;
            }
        }
        else if (cubaInfo.cubaName == "CubatureBorderIntersection")
        {
            switch (static_cast<int>(dhandDHand->mesh->elemType()))
            {
                case static_cast<int>(ElemType::Triang):
                    normals.resize(4);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // XminYmin
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;

                            // Normal from Ymin
                            normals[3] = 0.0;
                            normals[4] = -1.0;
                            break;
                        case 1: // Xmax
                            // Normal from tilted edge
                            normals[0] = 1.0 / sqrt(2);
                            normals[1] = 1.0 / sqrt(2);

                            // Normal from Ymin
                            normals[3] = 0.0;
                            normals[4] = -1.0;
                            break;
                        case 2: // Ymax
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;

                            // Normal from tilted edge
                            normals[3] = 1.0 / sqrt(2);
                            normals[4] = 1.0 / sqrt(2);
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Square):
                    normals.resize(4);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // XminYmin
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;

                            // Normal from Ymin
                            normals[2] = 0.0;
                            normals[3] = -1.0;
                            break;
                        case 1: // XmaxYmin
                            // Normal from Xmax
                            normals[0] = 1.0;
                            normals[1] = 0.0;

                            // Normal from Ymin
                            normals[2] = 0.0;
                            normals[3] = -1.0;
                            break;
                        case 2: // XminYmax
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;

                            // Normal from Ymax
                            normals[2] = 0.0;
                            normals[3] = 1.0;
                            break;
                        case 3: // XmaxYmax
                            // Normal from Xmax
                            normals[0] = 1.0;
                            normals[1] = 0.0;

                            // Normal from Ymax
                            normals[2] = 0.0;
                            normals[3] = 1.0;
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Tetrah):
                    normals.resize(6);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // YminZmin
                            // Normal from Ymin
                            normals[0] = 0.0;
                            normals[1] = -1.0;
                            normals[2] = 0.0;

                            // Normal from Zmin
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = -1.0;
                            break;
                        case 1: // XminZmin
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Zmin
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = -1.0;
                            break;
                        case 2: // XminYmin
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Ymin
                            normals[3] = 0.0;
                            normals[4] = -1.0;
                            normals[5] = 0.0;
                            break;
                        case 3: // Xmin
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from tilted Plane
                            normals[3] = 1.0 / sqrt(3.0);
                            normals[4] = 1.0 / sqrt(3.0);
                            normals[5] = 1.0 / sqrt(3.0);
                            break;
                        case 4: // Ymin
                            // Normal from Ymin
                            normals[0] = 0.0;
                            normals[1] = -1.0;
                            normals[2] = 0.0;

                            // Normal from tilted Plane
                            normals[3] = 1.0 / sqrt(3.0);
                            normals[4] = 1.0 / sqrt(3.0);
                            normals[5] = 1.0 / sqrt(3.0);
                            break;
                        case 5: // Zmin
                            // Normal from Zmin
                            normals[0] = 0.0;
                            normals[1] = 0.0;
                            normals[2] = -1.0;

                            // Normal from tilted Plane
                            normals[3] = 1.0 / sqrt(3.0);
                            normals[4] = 1.0 / sqrt(3.0);
                            normals[5] = 1.0 / sqrt(3.0);
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Parallelep):
                    normals.resize(6);
                    switch (cubaInfo.cubaType)
                    {
                        case 0: // YminZmin
                            // Normal from Zmin
                            normals[0] = 0.0;
                            normals[1] = 0.0;
                            normals[2] = -1.0;

                            // Normal from Ymin
                            normals[3] = 0.0;
                            normals[4] = -1.0;
                            normals[5] = 0.0;
                            break;
                        case 1: // XmaxZmin
                            // Normal from Xmax
                            normals[0] = 1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Zmin
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = -1.0;
                            break;
                        case 2: // YmaxZmin
                            // Normal from Ymax
                            normals[0] = 0.0;
                            normals[1] = 1.0;
                            normals[2] = 0.0;

                            // Normal from Zmin
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = -1.0;
                            break;
                        case 3: // XminZmin
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Zmin
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = -1.0;
                            break;
                        case 4: // YminZmax
                            // Normal from Ymin
                            normals[0] = 0.0;
                            normals[1] = -1.0;
                            normals[2] = 0.0;

                            // Normal from Zmax
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = 1.0;
                            break;
                        case 5: // XmaxZmax
                            // Normal from Xmax
                            normals[0] = 1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Zmax
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = 1.0;
                            break;
                        case 6: // YmaxZmax
                            // Normal from Ymax
                            normals[0] = 0.0;
                            normals[1] = 1.0;
                            normals[2] = 0.0;

                            // Normal from Zmax
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = 1.0;
                            break;
                        case 7: // XminZmax
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Zmax
                            normals[3] = 0.0;
                            normals[4] = 0.0;
                            normals[5] = 1.0;
                            break;
                        case 8: // XminYmin
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Ymin
                            normals[3] = 0.0;
                            normals[4] = -1.0;
                            normals[5] = 0.0;
                            break;
                        case 9: // XmaxYmin
                            // Normal from Xmax
                            normals[0] = 1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Ymin
                            normals[3] = 0.0;
                            normals[4] = -1.0;
                            normals[5] = 0.0;
                            break;
                        case 10: // XmaxYmax
                            // Normal from Xmax
                            normals[0] = 1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Ymax
                            normals[3] = 0.0;
                            normals[4] = 1.0;
                            normals[5] = 0.0;
                            break;
                        case 11: // XminYmax
                            // Normal from Xmin
                            normals[0] = -1.0;
                            normals[1] = 0.0;
                            normals[2] = 0.0;

                            // Normal from Ymax
                            normals[0] = 0.0;
                            normals[1] = 1.0;
                            normals[2] = 0.0;
                            break;
                        default:
                            throw runtime_error("SubFillStructure::normalsBoundaryRef: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(dhandDHand->mesh->elemType()) + " is undefined");
                            break;
                    }
                    break;
                default:
                    break;
            }
        }
        return normals;
    }

    double SubFillStructure::_jacobianParentElementToParameterSpace(int loc_elem)
    {
        //Get cubaname
        string& cubaName = dhandCubas->cubaInfo(0).cubaName;

        //Check bft
        BasisFuncType bft = dhandDHand->mesh->_basisFuncType;
        if (cubaName == "CubatureBorderImmersed")
            return 0.5;// bft = dhandDHand->mesh->_childMesh->_basisFuncType;
        if ((bft != BasisFuncType::BSplines and bft != BasisFuncType::Nurbs))
            return 1.0;

        //Get mesh variables
        RCP<DistributedMesh> mesh = dhandDHand->mesh;
        if (cubaName == "CubatureBorderImmersed")
            mesh = rcp(dhandDHand->mesh->_childMesh);
        int nex{}, ney{}, nez{}, _bfOrderX{}, _bfOrderY{}, _bfOrderZ{};
        tie(nex, ney, nez) = mesh->_adjcyEN->nElemDir();
        tie(_bfOrderX, _bfOrderY, _bfOrderZ) = mesh->_adjcyEN->basisFuncOrderDir();
        int elem{};
        if (cubaName != "CubatureBorderImmersed")
        {
            elem = mesh->_adjcyEN->globIdx(loc_elem);
        }
        // else
        // {
        //     //Get local ids of the child elements
        //     double jac = 1;
        //     return jac;
        //     vector<int> loc_elems_child = dhandDHand->mesh->_mapToChild->directMap(loc_elem, IndexType::Local);
        //     //Get which element corresponds to this integration point
        //     int loc_elem_child = loc_elems_child[0];
        //     cout << "EEOO: " << loc_elem_child<< endl;
        //     // throw runtime_error("SubFillStructure::_jacobianParentElementToParameterSpace: Bsplines in the immersed mesh implementation not finished. We need to know which element of the immersed mesh corresponds to this integration point");
        //     // elem = mesh->_adjcyEN->globIdx(loc_elem_child);
        //     elem = 0;
        //     cout << elem << endl;

        // }

        //Compute jacobian
        double jac{1.0};
        if (cubaName == "CubatureGauss" or cubaName == "CubatureBorderImmersed" or cubaName == "CubatureCutCellNonConforming") //FIXME: is CubatureCutCellNonConforming in the right place?
        {
            int inex = elem % nex;
            jac = (mesh->_uKnot[_bfOrderX+inex+1]-mesh->_uKnot[_bfOrderX+inex])/2.0;
            if (mesh->pDim() == 2)
            {
                int iney = (int) elem/nex;
                jac *= (mesh->_vKnot[_bfOrderY+iney+1]-mesh->_vKnot[_bfOrderY+iney])/2.0;
            }
            else if (mesh->pDim() == 3)
            {
                int iney = (elem%(nex*ney))/nex;
                jac *= (mesh->_vKnot[_bfOrderY+iney+1]-mesh->_vKnot[_bfOrderY+iney])/2.0;
                int inez = (elem/(nex*ney));
                jac *= (mesh->_wKnot[_bfOrderZ+inez+1]-mesh->_wKnot[_bfOrderZ+inez])/2.0;
            }
        }
        else if (cubaName == "CubatureBorderGauss")
        {
            if (mesh->elemType() == ElemType::Line)
            {
                jac = 1.0;
            }
            else if (mesh->elemType() == ElemType::Square)
            {
                if (cubaInfo.cubaType == 0)
                {
                    jac = 1.0;
                }
                else if (cubaInfo.cubaType == 1 or cubaInfo.cubaType == 3)  //Horizontal lines
                {
                    int inex = elem % nex;
                    jac = (mesh->_uKnot[_bfOrderX+inex+1]-mesh->_uKnot[_bfOrderX+inex])/2.0;
                }
                else if (cubaInfo.cubaType == 2 or cubaInfo.cubaType == 4)  //Vertical lines
                {
                    int iney = (int) elem/nex;
                    jac = (mesh->_vKnot[_bfOrderY+iney+1]-mesh->_vKnot[_bfOrderY+iney])/2.0;
                }
                else
                {
                    throw runtime_error("SubFillStructure::_jacobianParentElementToParameterSpace: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(mesh->elemType()) + " undefined");
                }

            }
            else if (mesh->elemType() == ElemType::Parallelep)
            {
                if (cubaInfo.cubaType == 0)
                {
                    jac = 1.0;
                }
                else if (cubaInfo.cubaType == 1 or cubaInfo.cubaType == 6) //XY planes
                {
                    int inex = elem % nex;
                    int iney = (elem%(nex*ney))/nex;
                    jac = (mesh->_uKnot[_bfOrderX+inex+1]-mesh->_uKnot[_bfOrderX+inex])/2.0;
                    jac *= (mesh->_vKnot[_bfOrderY+iney+1]-mesh->_vKnot[_bfOrderY+iney])/2.0;
                }
                else if (cubaInfo.cubaType == 2 or cubaInfo.cubaType == 4) //XZ planes
                {
                    int inex = elem % nex;
                    int inez = (elem/(nex*ney));
                    jac = (mesh->_uKnot[_bfOrderX+inex+1]-mesh->_uKnot[_bfOrderX+inex])/2.0;
                    jac *= (mesh->_wKnot[_bfOrderZ+inez+1]-mesh->_wKnot[_bfOrderZ+inez])/2.0;
                }
                else if (cubaInfo.cubaType == 3 or cubaInfo.cubaType == 5) //YZ planes
                {
                    int iney = (elem%(nex*ney))/nex;
                    int inez = (elem/(nex*ney));
                    jac = (mesh->_vKnot[_bfOrderY+iney+1]-mesh->_vKnot[_bfOrderY+iney])/2.0;
                    jac *= (mesh->_wKnot[_bfOrderZ+inez+1]-mesh->_wKnot[_bfOrderZ+inez])/2.0;
                }
                else
                {
                    throw runtime_error("SubFillStructure::_jacobianParentElementToParameterSpace: cubaType " + to_string(cubaInfo.cubaType) + " for elem Type " + str(mesh->elemType()) + "undefined");
                }
            }
            else
            {
                throw runtime_error("SubFillStructure::_jacobianParentElementToParameterSpace: Wrong type of element for BSplines/Nurbs.");
            }

        }
        else if (cubaName == "CubatureBorderIntersection")
        {
            if (mesh->elemType() == ElemType::Square)
                jac = 1.0;
            if (mesh->elemType() == ElemType::Parallelep)
                throw runtime_error("SubFillStructure::_jacobianParentElementToParameterSpace: Not implemented for Parallelep!");
        }
        else
        {
            throw runtime_error("SubFillStructure::_jacobianParentElementToParameterSpace: Not implemented for this cubature: " + cubaName);
        }

        return jac;
    }
}
