/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef _FILLTYPE_IMPL_H
#define _FILLTYPE_IMPL_H


#include <iostream>


using namespace std;


namespace hiperlife
{

    template<>
    inline void matrixFill<FillType::TrilFill>(Teuchos::RCP<Epetra_FECrsMatrix> A, int row, int column, double value)
    {

        #ifdef DEBUG
            int err = A->SumIntoGlobalValues(row, 1, &value, &column);

            if (err < 0)
                throw runtime_error("FillType::matrixFill: The value cannot be added to the global matrix.");
        #else
            A->SumIntoGlobalValues(row, 1, &value, &column);
        #endif
    }


    template<>
    inline void matrixFill<FillType::TrilCreat>(Teuchos::RCP<Epetra_FECrsMatrix> A, int row, int column, double value)
    {

        #ifdef DEBUG
            int err = A->InsertGlobalValues(row, 1, &value, &column);

            if (err < 0)
                throw runtime_error("FillType::matrixFill: The value cannot be inserted to the global matrix.");
        #else
            A->InsertGlobalValues(row, 1, &value, &column);
        #endif

    }

}

#endif
