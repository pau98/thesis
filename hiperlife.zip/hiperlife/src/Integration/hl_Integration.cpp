/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>


#include <hl_TypeDefs.h>
#include <hl_Cubature.h>
#include "hl_Integration.h"
#include <hl_BVHElementLocator.h>
#include <hl_DistributedMesh.h>
#include <hl_Geometry.h>

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::ParameterList;
using Teuchos::parameterList;

namespace hiperlife
{
    void Integration::setCubatureParameters(size_t cubaId, cubaParams& params)
    {
        // Check whether added cubature is compatible with existing ones
        if (_params.size() != 0)
        {
            if (!areCubaTypesCompatible(_params[0].type, params.type))
                throw std::runtime_error("Integration::setCubatureParameters: cubaId " + std::to_string(cubaId) + " of type " + str(params.type) + " is not compatible with the existing cubature " + str(_params[0].type) + ".");
        }

        // Set or add cubature parameters
        if (cubaId == _params.size())
            _params.emplace_back(params);
        else if (cubaId < _params.size())
            _params[cubaId] = params;
        else
            throw std::runtime_error("Integration::setCubatureParameters: cubaId "+std::to_string(cubaId)+" does not exist or is larger than the number of cuba types existing (it cannot be added)");
    }

    void Integration::Update()
    {
        //Checks
        if (numDOFsHands() == 0)
            throw runtime_error("Integration::Update: You have not set any DOFsHandler for this integration.");
        if (LinSystemByElement == nullptr and StiffnessMatrixByElement == nullptr and RightHandSideByElement == nullptr)
            throw runtime_error("HiPerProblem::setElemFillings: All the introduced element filling functions are null.");

        //Set the size of all vectors
        _cubaSets.resize(numDOFsHands());
        _BFSets.resize(numDOFsHands());

        //Create CubaSet for the first (primary) DOFsHandler
        for (auto i = 0u; i < _params.size(); i++)
        {
            if (_params[i].type == CubaType::Gauss)
                _genCubaSetGauss(i);
            else if (_params[i].type == CubaType::BorderGauss)
                _genCubaSetBorderGauss(i);
            else if (_params[i].type == CubaType::BorderIntersections)
                _genCubaSetBorderIntersection(i);
            else if (_params[i].type == CubaType::IrregSubdivSurf)
                _genCubaSetIrregularSubdiv(i);
            else if (_params[i].type == CubaType::CutCellNonConforming or
                     _params[i].type == CubaType::CutCellConforming)
                _genCubaSetCutCell(i);
            else if (_params[i].type == CubaType::BorderImmersed)
                _genCubaSetBorderImmersed(i);
            else if (_params[i].type == CubaType::UserDefined)
                _genCubaSetUserDefined(i);
            else if (_params[i].type == CubaType::InteriorFacet)
                _genFacetPairs(i);
            else if (_params[i].type == CubaType::GhostPenalty)
                _genGhostPenaltyPairs(i);
            else
                throw runtime_error("Integration::Update: CubaType has been left undefined");
        }

        //Create CubaSets for the remaining DOFsHandlers
        for (int i = 1; i < numDOFsHands(); i++)
        {
            if (_meshMaps[i]->nameTag() == "MeshMap_Trivial")
                _cubaSets[i] = _cubaSets[0];
            else  if (_meshMaps[i]->nameTag() == "MeshMap_Macro")
                _genCubaSetLagrMultiplMacroElems(i, _cubaSets[0].getRawPtr());
            else  if (_meshMaps[i]->nameTag() == "MeshMap_Immersed")
                _genCubaSetImmersed(i);
            else
                throw runtime_error("Integration::Update: _meshMap invalid.");
        }

        //Create BasisFunctionsSet for all DOFsHandlers
        for (int i = 0; i < numDOFsHands(); i++)
        {
            _BFSets[i] = rcp(new BasisFunctionsSet);
            _BFSets[i]->setAdjcyEN(_dhands[i]->mesh->_adjcyEN);
            _BFSets[i]->setBasisFunctions(_dhands[i]->mesh->_basisFunctions);
            _BFSets[i]->setCubaSet(_cubaSets[i]);
            _BFSets[i]->Update();
        }

        //Create FillStructure
        _fillStr = rcp(new FillStructure);
        _fillStr->paramStr        = paramStr;
        _fillStr->_dhandsTagIdx  = _dhandsTagIdx;
        _fillStr->_consDOFsHandlers   = _consDOFsHandlers;
        _fillStr->_consDOFs           = _consDOFs;
        _fillStr->_consCheckType      = _consCheckType;
        _fillStr->_consCheckGlobInteg = _consCheckGlobInteg;
        _fillStr->_consCheckTol       = _consCheckTol;
        _fillStr->_consCheckDelta     = _consCheckDelta;
        _fillStr->_subFills.resize(numDOFsHands());
        for (int i = 0u; i < numDOFsHands(); i++)
        {
            _fillStr->_subFills[i] = rcp(new SubFillStructure);
            (*_fillStr)[i].setDOFsHandlers(_dhands[i]);
            (*_fillStr)[i].setCubatureSet(_cubaSets[i]);
            (*_fillStr)[i].setBasisFunctionSet(_BFSets[i]);
            (*_fillStr)[i].setMeshMap(_meshMaps[i]);
            (*_fillStr)[i].Update();
        }
        _fillStr->Update();

        // InteriorFacet / GhostPenalty with a single registered DOFsHandler: synthesize a
        // "guest" slot so that fillStr[1] and _Ae(R,C) for R,C ∈ {0,1} work in the user's
        // filling function and in _partialFillLinearSystem.
        if (_needsTwoSlots && numDOFsHands() == 1)
        {
            // Duplicate dhands/set pointers so _partialFillLinearSystem(A, rhs, 1, *, ...) works
            _dhands.push_back(_dhands[0]);
            _cubaSets.push_back(_cubaSets[0]);
            _BFSets.push_back(_BFSets[0]);
            _meshMaps.push_back(_meshMaps[0]);

            // Second SubFillStructure (guest) backed by the same DOFsHandler
            _fillStr->_subFills.push_back(rcp(new SubFillStructure));
            (*_fillStr)[1].setDOFsHandlers(_dhands[0]);
            (*_fillStr)[1].setCubatureSet(_cubaSets[0]);
            (*_fillStr)[1].setBasisFunctionSet(_BFSets[0]);
            (*_fillStr)[1].setMeshMap(_meshMaps[0]);
            (*_fillStr)[1].Update();

            // Add a synthetic tag so FillStructure::numDOFsHands() returns 2,
            // which makes _Ae(i,j) index _A_e[j*2+i] correctly for all 4 blocks.
            _fillStr->_dhandsTagIdx.emplace("__pair_guest__", 1);

            // Expand buffer arrays from 1-slot to 2-slot layout.
            // The actual element-level sizes are set by assign() calls in the fill loop.
            _fillStr->_B_k.resize(2);
            _fillStr->_A_k.resize(4);
            _fillStr->_B_e.resize(2);
            _fillStr->_A_e.resize(4);
            _fillStr->dhandChangeElem.resize(2, true);
        }
    }

    void Integration::_genCubaSetGauss(int cubaId)
    {
        // Generate cubature info
        RCP<CubatureGauss> cuba = rcp(new CubatureGauss);
        cuba->setElemType(_dhands[0]->mesh->elemType());
        cuba->setNumIntPts(_params[cubaId].iPts);
        cuba->Update();
        CubatureInfo cubaInfo = cuba->cubatureInfo();

        // Generate cubaSet for the primary DOFsHandler
        if (_cubaSets[0] == Teuchos::null)
        {
            _cubaSets[0] = rcp(new CubatureSet);
            _cubaSets[0]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);
            _cubaSets[0]->Update();
        }

        // Add cubaInfo to cubaSet
        _cubaSets[0]->addCubaInfo(cubaId, cubaInfo, _params[cubaId].elems, _params[cubaId].idxType);
    }

    void Integration::_genCubaSetBorderGauss(int cubaId)
    {
        //Compute number of sides
        int nSides{};
        if (_dhands[0]->mesh->elemType() == ElemType::Line)
            nSides = 2;
        else if (_dhands[0]->mesh->elemType() == ElemType::Triang)
            nSides = 3;
        else if (_dhands[0]->mesh->elemType() == ElemType::Square or _dhands[0]->mesh->elemType() == ElemType::Tetrah)
            nSides = 4;
        else if (_dhands[0]->mesh->elemType() == ElemType::Parallelep)
            nSides = 6;

        //Generate cubature info using the CubatureBorderGauss per side + empty one for elements in the bulk
        vector<CubatureInfo> cubaInfo(nSides+1);
        cubaInfo[0].cubaName = "CubatureBorderGauss";
        for (int s = 0; s < nSides; s++)
        {
            RCP<CubatureBorderGauss> cuba = rcp(new CubatureBorderGauss);
            cuba->setElemType(_dhands[0]->mesh->elemType());
            cuba->setNumIntPts(_params[cubaId].iPts);
            cuba->setSide(s);
            cuba->Update();

            cubaInfo[s+1] = cuba->cubatureInfo();
            cubaInfo[s+1].cubaType = s+1;
        }

        // Generate cubaSet for the primary DOFsHandler
        if (_cubaSets[0] == Teuchos::null)
        {
            _cubaSets[0] = rcp(new CubatureSet);
            _cubaSets[0]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);
            _cubaSets[0]->setCubaInfo(cubaInfo);
            _cubaSets[0]->Update();
        }

        //Convert axes set to vector
        vector<MAxis> axes(_params[cubaId].axes.begin(), _params[cubaId].axes.end());

        //Add cubaInfo to each side
        for (int e = 0; e < _dhands[0]->mesh->loc_nElem(); e++)
        {
            //Get vector of sides for this element
            vector<int> sides = _dhands[0]->mesh->_getMeshBoundariesOfElement(e, IndexType::Local, axes);

            //Add 0 (empty cubainfo) if there are no sides
            if (sides.empty())
                sides.push_back(0);

            //Add cubaInfo to cubaSet
            for (auto s: sides)
                _cubaSets[0]->addCubaInfo(s, cubaInfo[s], {static_cast<size_t>(e)}, IndexType::Local);
        }
    }

    void Integration::_genCubaSetBorderIntersection(int cubaId)
    {
        // Set the number of boundary intersections for each element
        // In 0D/1D: There is no boundary intersection
        // In 2D: Boundary intersections are vertices of the element
        // In 3D: Boundary intersections are edges of the element
        int nBorderIntersec{};
        switch (_dhands[0]->mesh->elemType())
        {
            case ElemType::Triang:
                nBorderIntersec = 3;
                break;
            case ElemType::Square:
                nBorderIntersec = 4;
                break;
            case ElemType::Tetrah:
                nBorderIntersec = 6;
                break;
            case ElemType::Parallelep:
                nBorderIntersec = 12;
                break;
            default:
                throw runtime_error("Integration::_genCubaSetBorderIntersection There are no boundary intersections in 1D problems!");
                break;
        }

        // Generate cubature info using the "CubatureBorderIntersection" per Border
        vector<CubatureInfo> cubaInfo(nBorderIntersec);
        cubaInfo[0].cubaName = "CubatureBorderIntersec";
        for (int iBI{0}; iBI < nBorderIntersec; ++iBI)
        {
            RCP<CubatureBorderIntersection> cuba = rcp(new CubatureBorderIntersection);
            cuba->setElemType(_dhands[0]->mesh->elemType());
            cuba->setNumIntPts(_params[cubaId].iPts);
            cuba->setBorderIntersec(iBI);
            cuba->Update();

            cubaInfo[iBI] = cuba->cubatureInfo();
            cubaInfo[iBI].cubaType = iBI;
        }

        // Generate cubaSet for the primary DOFsHandler
        if (_cubaSets[0] == Teuchos::null)
        {
            _cubaSets[0] = rcp(new CubatureSet);
            _cubaSets[0]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);
            _cubaSets[0]->setCubaInfo(cubaInfo);
            _cubaSets[0]->Update();
        }

        // Add cubaInfo to each Boundary Intersection
        for (int e = 0; e < _dhands[0]->mesh->loc_nElem(); e++)
        {
            // Get ids of the corner nodes
            auto corners = _dhands[0]->mesh->_getElementCornerNodes(e, IndexType::Local);

            // Get vector of boundary intersections for this element
            vector<int> borderInter = {};
            switch (static_cast<int>(_dhands[0]->mesh->elemType()))
            {
                case static_cast<int>(ElemType::Triang):
                {
                    int axis0 = _dhands[0]->mesh->nodeMAxis(corners[0], IndexType::Global);
                    int axis1 = _dhands[0]->mesh->nodeMAxis(corners[1], IndexType::Global);
                    int axis2 = _dhands[0]->mesh->nodeMAxis(corners[2], IndexType::Global);

                    for (auto ax : _params[cubaId]._BorderIntersections)
                    {
                        int iax = getBorderIntersections(ax);

                        if (axis0 == iax)
                            borderInter.push_back(0);
                        if (axis1 == iax)
                            borderInter.push_back(1);
                        if (axis2 == iax)
                            borderInter.push_back(2);
                    }
                    break;
                }

                case static_cast<int>(ElemType::Square):
                {
                    int axis0 = _dhands[0]->mesh->nodeMAxis(corners[0], IndexType::Global);
                    int axis1 = _dhands[0]->mesh->nodeMAxis(corners[1], IndexType::Global);
                    int axis2 = _dhands[0]->mesh->nodeMAxis(corners[2], IndexType::Global);
                    int axis3 = _dhands[0]->mesh->nodeMAxis(corners[3], IndexType::Global);

                    for (auto ax : _params[cubaId]._BorderIntersections)
                    {
                        int iax = getBorderIntersections(ax);

                        if (axis0 == iax)
                            borderInter.push_back(0);
                        if (axis1 == iax)
                            borderInter.push_back(1);
                        if (axis2 == iax)
                            borderInter.push_back(2);
                        if (axis3 == iax)
                            borderInter.push_back(3);
                    }
                    break;
                }

                case static_cast<int>(ElemType::Tetrah):
                {
                    int axis0 = _dhands[0]->mesh->nodeMAxis(corners[0], IndexType::Global);
                    int axis1 = _dhands[0]->mesh->nodeMAxis(corners[1], IndexType::Global);
                    int axis2 = _dhands[0]->mesh->nodeMAxis(corners[2], IndexType::Global);
                    int axis3 = _dhands[0]->mesh->nodeMAxis(corners[3], IndexType::Global);

                    for (auto ax : _params[cubaId]._BorderIntersections)
                    {
                        int iax = getBorderIntersections(ax);

                        if (axis0 == iax and axis1 == iax)
                            borderInter.push_back(0);
                        if (axis0 == iax and axis2 == iax)
                            borderInter.push_back(1);
                        if (axis0 == iax and axis3 == iax)
                            borderInter.push_back(2);
                        if (axis2 == iax and axis3 == iax)
                            borderInter.push_back(3);
                        if (axis1 == iax and axis3 == iax)
                            borderInter.push_back(4);
                        if (axis1 == iax and axis2 == iax)
                            borderInter.push_back(5);
                    }
                    break;
                }

                case static_cast<int>(ElemType::Parallelep):
                {
                    int axis0 = _dhands[0]->mesh->nodeMAxis(corners[0], IndexType::Global);
                    int axis1 = _dhands[0]->mesh->nodeMAxis(corners[1], IndexType::Global);
                    int axis2 = _dhands[0]->mesh->nodeMAxis(corners[2], IndexType::Global);
                    int axis3 = _dhands[0]->mesh->nodeMAxis(corners[3], IndexType::Global);
                    int axis4 = _dhands[0]->mesh->nodeMAxis(corners[4], IndexType::Global);
                    int axis5 = _dhands[0]->mesh->nodeMAxis(corners[5], IndexType::Global);
                    int axis6 = _dhands[0]->mesh->nodeMAxis(corners[6], IndexType::Global);
                    int axis7 = _dhands[0]->mesh->nodeMAxis(corners[7], IndexType::Global);

                    for (auto ax : _params[cubaId]._BorderIntersections)
                    {
                        int iax = getBorderIntersections(ax);
                        if (axis0 == iax and axis1 == iax)
                            borderInter.push_back(0);
                        if (axis1 == iax and axis3 == iax)
                            borderInter.push_back(1);
                        if (axis3 == iax and axis2 == iax)
                            borderInter.push_back(2);
                        if (axis0 == iax and axis2 == iax)
                            borderInter.push_back(3);
                        if (axis4 == iax and axis5 == iax)
                            borderInter.push_back(4);
                        if (axis5 == iax and axis7 == iax)
                            borderInter.push_back(5);
                        if (axis6 == iax and axis7 == iax)
                            borderInter.push_back(6);
                        if (axis4 == iax and axis6 == iax)
                            borderInter.push_back(7);
                        if (axis0 == iax and axis4 == iax)
                            borderInter.push_back(8);
                        if (axis5 == iax and axis1 == iax)
                            borderInter.push_back(9);
                        if (axis3 == iax and axis7 == iax)
                            borderInter.push_back(10);
                        if (axis6 == iax and axis6 == iax)
                            borderInter.push_back(11);
                    }
                    break;
                }

                default:
                    throw runtime_error("Integration::Update: Border intersection integration for element " + str(_dhands[0]->mesh->elemType()) + " not programmed!");
                    break;
            }

            // Add cubaInfo to cubaSet
            for (auto s : borderInter)
                _cubaSets[0]->addCubaInfo(s, cubaInfo[s], {static_cast<size_t>(e)}, IndexType::Local);
        }
    }

    void Integration::_genCubaSetIrregularSubdiv(int cubaId)
    {

        RCP<CubatureGauss> cubaGauss = rcp(new CubatureGauss);
        cubaGauss->setElemType(_dhands[0]->mesh->elemType());
        cubaGauss->setNumIntPts(_params[cubaId].iPts);
        cubaGauss->Update();
        CubatureInfo cubaInfoGauss = cubaGauss->cubatureInfo();


        RCP<CubatureIrregSubdivSurf> cubaIrr = rcp(new CubatureIrregSubdivSurf);
        cubaIrr->setElemType(_dhands[0]->mesh->elemType());
        cubaIrr->setNumIntPts(_params[cubaId].iPts);
        cubaIrr->setMaxSubdiv(_params[cubaId].nSubdiv);
        cubaIrr->Update();
        CubatureInfo cubaInfoIrr = cubaIrr->cubatureInfo();

        // Generate cubaSet for the primary DOFsHandler
        if (_cubaSets[0] == Teuchos::null)
        {
            _cubaSets[0] = rcp(new CubatureSet);
            _cubaSets[0]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);
            _cubaSets[0]->Update();
        }

        auto mesh = _dhands[0]->mesh;

        set<size_t> regElem{};
        set<size_t> irrElem{};
        for(int e = 0; e < mesh->loc_nElem(); e++)
        {
            int  eNN  = mesh->_adjcyEN->getNumNbors(e, IndexType::Local);

            bool expl{false};
            for(auto i: mesh->_adjcyEN->getNborList(e, IndexType::Local))
            {
                if (mesh->nodeCrease(i, IndexType::Global) > 0)
                {
                    expl = true;
                    break;
                }
            }

            if (expl or eNN == 12)
                regElem.insert(static_cast<size_t>(e));
            else
                irrElem.insert(static_cast<size_t>(e));
        }

        if (!regElem.empty())
            _cubaSets[0]->addCubaInfo(0, cubaInfoGauss, regElem, IndexType::Local);
        if (!irrElem.empty())
            _cubaSets[0]->addCubaInfo(1, cubaInfoIrr,   irrElem, IndexType::Local);

    }

    void Integration::_genCubaSetCutCell(int cubaId)
    {
        //Initialize
        auto backMesh = _dhands[0]->mesh;
        auto immMesh = backMesh->_childMesh;

        // Checks
        if (immMesh == 0)
            throw runtime_error("Integration::_genCubaSetCutCell: Immersed mesh is null.");
        if (immMesh->elemType() != ElemType::Triang and backMesh->_pDim == 3 and immMesh->basisFunctionOrder() != 1)
            throw runtime_error("Integration::_genCubaSetCutCell: 3D immersed method works with linear triangle elements for immersed geometry.");
        if (backMesh->elemType() != ElemType::Square and backMesh->elemType() != ElemType::Parallelep)
            throw runtime_error("Integration::_genCubaSetCutCell: The background mesh can only be made of square or parallelep elemtents.");

        // Generate cubaSet for the primary DOFsHandler
        if (_cubaSets[0] == Teuchos::null)
        {
            _cubaSets[0] = rcp(new CubatureSet);
            _cubaSets[0]->setAdjcyEN(backMesh->_adjcyEN);
            _cubaSets[0]->Update();
        }

        // Create Gauss cubature info
        RCP<CubatureGauss> cubaGauss = rcp(new CubatureGauss);
        cubaGauss->setElemType(backMesh->elemType());
        cubaGauss->setNumIntPts(_params[cubaId].iPts);
        cubaGauss->Update();
        CubatureInfo cubaInfoGauss = cubaGauss->cubatureInfo();

        // Add Gauss cubature info to interior elements
        int ctag = 1;
        if (!_params[cubaId].intElems.empty())
            _cubaSets[0]->addCubaInfo(0, cubaInfoGauss, _params[cubaId].intElems, IndexType::Local);
        else
            ctag = 0;

        // Get axis
        vector<MAxis> axes = immMesh->_vMAx;

        // Compute bound node ordering //FIXME: Higher-order //FIXME:: Move to hl_TypeDefs.h?
        int numCorners = numElemNodeType(immMesh->elemType(), immMesh->basisFuncType(), immMesh->_bfOrder)[2];
        vector<int> reorder = vtkReordering(immMesh->elemType(), immMesh->basisFuncType(), immMesh->_bfOrder, false);
        vector<int> bOrder(reorder.begin(), reorder.begin()+numCorners);
        bOrder.push_back(bOrder[0]);

        // 2D ImmersedBoundary with regions: the polygons of the region in each cut element come from the
        // immersed curves (exact polyline, no tolerances nor corner flags), the same geometry as the region
        // fractions of the aggregation. Otherwise, from the immersed segments and the corner flags
        int iTagPolygons = -1;
        if (_params[cubaId].type == CubaType::CutCellConforming and backMesh->_pDim == 2 and
            immMesh->_meshRel == MeshRelation::ImmersedBoundary and backMesh->elemType() == ElemType::Square)
        {
            vector<int> tagsInternal = {3,5,7,11};
            for (size_t i = 0; i < tagsInternal.size(); i++)
            {
                if (tagsInternal[i] == _params[cubaId].regionTag and i < backMesh->_regionTags().size())
                    iTagPolygons = i;
            }
            if (iTagPolygons != -1 and !backMesh->_buildImmersedCurves())
                iTagPolygons = -1;
        }

        // Integration points for cut elements
        vector<CubatureInfo> cubaInfoCut(_params[cubaId].cutElems.size() + 1);
        if (!_params[cubaId].cutElems.empty())
        {
            vector<vector<double>> rCorners = referenceCoordsElemCorners(backMesh->elemType());
            for (auto elem : _params[cubaId].cutElems)
            {
                // Get global coordinates of the immersed elements on the cut element
                vector<int> immElems = backMesh->_mapToChild->directMap(elem, IndexType::Local);
                vector<vector<vector<double>>> immersedSegments;
                vector<vector<double>> immPts; // 3D immersed points used for detecting cut subelems in 3D
                if (backMesh->_pDim == 2)
                {
                    if (immMesh->_meshRel == MeshRelation::ImmersedBoundary) // TODO IMMBOUND
                    {
                        // Same segments the mesh uses for the region fractions of the aggregation
                        immersedSegments = backMesh->_cutCellImmersedSegments(elem);
                    }
                    else
                    {
                        // Compute local number of immersed segments
                        int localNumSeg{};
                        for (size_t i = 0; i < immElems.size(); ++i)
                        {
                            // Get neighbors
                            vector<int> nbors = immMesh->_connec->getNborList(immElems[i], IndexType::Local);

                            // Loop through boundaries
                            for (size_t b = 0; b < bOrder.size()-1; b++)
                            {
                                if (axes.empty())
                                {
                                    int cr0 = immMesh->nodeCrease(nbors[bOrder[b]], IndexType::Global);
                                    int cr1 = immMesh->nodeCrease(nbors[bOrder[b+1]], IndexType::Global);
                                    if (cr0 > 0 and cr1 > 0)
                                        localNumSeg++;
                                }
                                else
                                {
                                    int ax0 = immMesh->nodeMAxis(nbors[bOrder[b]], IndexType::Global);
                                    int ax1 = immMesh->nodeMAxis(nbors[bOrder[b+1]], IndexType::Global);
                                    for (auto ax: axes)
                                    {
                                        if (ax0%getMAxis(ax) == 0 and ax1%getMAxis(ax) == 0)
                                        {
                                            localNumSeg++;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        immersedSegments.resize(localNumSeg, vector<vector<double>>(2, vector<double>(3)));

                        // Compute immersed segments
                        int counter{};
                        for (size_t i = 0; i < immElems.size(); ++i)
                        {
                            // Get neighbors
                            vector<int> nbors = immMesh->_connec->getNborList(immElems[i], IndexType::Local);

                            // Loop through boundaries
                            for (size_t b = 0; b < bOrder.size()-1; b++)
                            {
                                // Get node ids
                                int n0 = nbors[bOrder[b]];
                                int n1 = nbors[bOrder[b+1]];

                                // Check if segment is boundary
                                bool boundSegment{false};
                                if (axes.empty())
                                {
                                    int cr0 = immMesh->nodeCrease(n0, IndexType::Global);
                                    int cr1 = immMesh->nodeCrease(n1, IndexType::Global);
                                    if (cr0 > 0 and cr1 > 0)
                                        boundSegment = true;
                                }
                                else
                                {
                                    int ax0 = immMesh->nodeMAxis(n0, IndexType::Global);
                                    int ax1 = immMesh->nodeMAxis(n1, IndexType::Global);
                                    for (auto ax: axes)
                                    {
                                        if (ax0%getMAxis(ax) == 0 and ax1%getMAxis(ax) == 0)
                                        {
                                            boundSegment = true;
                                        }
                                    }
                                }

                                // Save segment
                                if (boundSegment)
                                {
                                    immersedSegments[counter][0] = immMesh->nodeCoords(n0);
                                    immersedSegments[counter][1] = immMesh->nodeCoords(n1);
                                    counter++;
                                }
                            }
                        }
                    }
                }
                else if (backMesh->_pDim == 3)
                {
                    int numPts = 25; // number of points to be distributed on each direction on immersed element
                    immersedSegments.resize(immElems.size(), vector<vector<double>>(3, vector<double>(3)));
                    for (size_t i = 0; i < immElems.size(); ++i)
                    {
                        vector<int> immElemNodeList = immMesh->_connec->getNborList(immElems[i]);
                        for(size_t j = 0; j< immElemNodeList.size(); ++j)
                        {
                            immersedSegments[i][j] = immMesh->nodeCoords(immElemNodeList[j]);
                        }
                        // Distribute points of the immersed triangular element
                        vector<vector<double>> ip = SGeometry::distributedPointsOnTriangle(immersedSegments[i][0], immersedSegments[i][1], immersedSegments[i][2], numPts, numPts);
                        immPts.insert(immPts.end(), ip.begin(), ip.end());
                    }

                }

                // Get coordinates of the corners of the background element
                vector<vector<double>> globalCornerCoords(rCorners.size(), vector<double>(3));
                for (size_t i = 0; i < rCorners.size(); ++i)
                {
                    globalCornerCoords[i] = backMesh->interpolatePosition(elem, rCorners[i], IndexType::Local);
                }

                // Transform segments to parametric space of the background mesh
                // FIXME: This assumes flat geometry and Square/Parallelep and
                //        straight element sides
                vector<double> side(3);
                // cout << "Background elem: "<< elem<< endl;
                for (int d = 0; d < _dhands[0]->mesh->_pDim; d++)
                    side[d] = globalCornerCoords[rCorners.size()-1][d] - globalCornerCoords[0][d];
                for (size_t i = 0; i < immersedSegments.size(); ++i)
                {
                    for (size_t j = 0; j < immersedSegments[i].size(); ++j)
                    {
                        // Invert mapping
                        vector<double> xCoords = {immersedSegments[i][j][0], immersedSegments[i][j][1]};
                        vector<double> rCoords1(2);
                        vector<double> rCoords2(2);
                        vector<double> rCoords0(2);
                        double distPt = backMesh->DistributedMesh::_invertElementMapping_RegSquare(rCoords1, elem, xCoords, IndexType::Local, false);
                        // else if (backMesh->basisFuncOrder() == 2)
                        //     double distPt = backMesh->DistributedMesh::_invertElementMapping_RegSquare(rCoords1, elem, xCoords, rCoords0, IndexType::Local, false);

                        for (int d = 0; d < _dhands[0]->mesh->_pDim; d++)
                        {
                            // immersedSegments[i][j][d] = (immersedSegments[i][j][d] - globalCornerCoords[0][d] - side[d] / 2.0) * 2.0 / side[d];
                            immersedSegments[i][j][d] = rCoords1[d];
                            // cout << rCoords1[d] << ", ";
                        }
                    }
                    // cout << endl;
                }

                // Transform the immPts to the parametric space of the back mesh
                if (!immPts.empty())
                {
                    for (size_t i = 0; i < immPts.size(); ++i)
                    {
                        // Invert mapping
                        vector<double> xCoords = {immPts[i][0], immPts[i][1]};
                        vector<double> rCoords1(2);
                        vector<double> rCoords0(2);

                        // double distPt = backMesh->DistributedMesh::_invertElementMapping_LinearSquare(rCoords1, elem, xCoords, rCoords0, IndexType::Local, false);
                        double distPt = backMesh->DistributedMesh::_invertElementMapping_RegSquare(rCoords1, elem, xCoords, IndexType::Local, false);

                        for (int d = 0; d < _dhands[0]->mesh->_pDim; d++)
                        {
                            // immPts[i][d] = (immPts[i][d] - globalCornerCoords[0][d] - side[d] / 2.0) * 2.0 / side[d];
                            immPts[i][d] = rCoords1[d];
                        }
                    }
                }

                // Get flags of the corners of the element (0: exterior, 1:interior)
                /*
                    cFlag numbering:
                    2        3
                    o--------o
                    |        |     y
                    |        |     |
                    |        |     +--x
                    o--------o
                    0        1

                       4        6
                       +--------+
                      /|       /|
                     / |      / |        z
                  5 +--------+ 7|        |
                    |  | 0   |  | 2      |
                    |  +-----|--+        + ----y
                    | /      | /        /
                    |/       |/        /
                    +--------+        x
                    1        3
                */

                // Get local corner flags of back elements
                vector<int> cFlags = backMesh->_immersedCornerFlags(elem, IndexType::Local);

                // Compute cubature
                if (_params[cubaId].type == CubaType::CutCellNonConforming)
                {
                    // Create NonConforming cubature
                    RCP<CubatureCutCellNonConforming> cubaNC = rcp(new CubatureCutCellNonConforming);
                    cubaNC->setElemType(backMesh->elemType());
                    cubaNC->setNumIntPts(_params[cubaId].iPts2);
                    cubaNC->setNumSubdiv(_params[cubaId].nSubdiv);
                    cubaNC->setCornerFlags(cFlags);
                    cubaNC->setImmersedSegments(immersedSegments);
                    cubaNC->setImmersedPoints(immPts);
                    cubaNC->Update();
                    if (cubaNC->iPts() == 0)
                        cout << "_genCubaSetCutCellNonConforming: Element " + to_string(elem) + " has no integration points." << endl;
                    // throw runtime_error("_genCubaSetCutCellNonConforming: Element " + to_string(elem) + " has no integration points.");

                    // Save cubature info
                    cubaInfoCut[ctag] = cubaNC->cubatureInfo();
                }
                else if (_params[cubaId].type == CubaType::CutCellConforming)
                {
                    // Create conforming cubature
                    RCP<CubatureCutCellConforming> cubaC = rcp(new CubatureCutCellConforming);
                    cubaC->setElemType(backMesh->elemType());
                    cubaC->setNumIntPts(_params[cubaId].iPts2);
                    cubaC->setIntegrationOrder(_params[cubaId].iPts2);
                    cubaC->setCornerFlags(cFlags);
                    cubaC->setRegionTag(_params[cubaId].regionTag);
                    if (iTagPolygons != -1)
                        cubaC->setPolygons(backMesh->_cutCellRegionPolygons(elem, iTagPolygons));
                    else
                    {
                        cubaC->setImmersedSegments(immersedSegments);
                        cubaC->setImmersedPoints(immPts);
                    }
                    cubaC->Update();
                    if (cubaC->iPts() == 0)
                        cout << "_genCubaSetCutCellConforming: Element " + to_string(elem) + " has no integration points." << endl;
                    // throw runtime_error("_genCubaSetCutCellNonConforming: Element " + to_string(elem) + " has no integration points.");

                    // Save cubature info
                    cubaInfoCut[ctag] = cubaC->cubatureInfo();
                }

                // Add cubature info
                _cubaSets[0]->addCubaInfo(ctag, cubaInfoCut[ctag], {elem}, IndexType::Local);

                // Increase cubatag
                ctag++;
            }
        }
    }

    void Integration::_genCubaSetBorderImmersed(int cubaId)
    {
        // Initialize
        auto backMesh = _dhands[0]->mesh;
        auto immMesh  = backMesh->_childMesh;
        IndexType idxType = _params[cubaId].idxType;
        int iPts = _params[cubaId].iPts; //FIXME: Is this right?
        int backNDim = backMesh->nDim();
        int immPDim = immMesh->pDim();
        immMesh->_immTangents.clear();
        immMesh->_immTangents.resize(backMesh->nElem());
        immMesh->_immElemID.clear();
        immMesh->_immElemID.resize(backMesh->nElem());
        immMesh->_immLocalParam.clear();
        immMesh->_immLocalParam.resize(backMesh->nElem());
        auto immElemType = immMesh->elemType();

        // Checks
        if (immMesh == 0)
            throw runtime_error("Integration::_genCubaSetBorderImmersed: Immersed mesh is null.");

        // Generate cubaSet for the primary DOFsHandler
        if (_cubaSets[0] == Teuchos::null)
        {
            _cubaSets[0] = rcp(new CubatureSet);
            _cubaSets[0]->setAdjcyEN(backMesh->_adjcyEN);
            _cubaSets[0]->Update();
        }

        // Generate cubature of the immersed mesh for the ImmersedBoundary
        RCP<CubatureGauss> immCuba = rcp(new CubatureGauss);
        if (immMesh->_meshRel == MeshRelation::ImmersedBoundary) // TODO IMMBOUND
        {
            immCuba->setElemType(immElemType);
            immCuba->setNumIntPts(iPts);
            immCuba->Update();
        }
        
        // Compute number of sides
        int nSides{};
        if (immMesh->_meshRel == MeshRelation::ImmersedMesh)
        {
            if (immElemType == ElemType::Triang)
                nSides = 3;
            else if (immElemType == ElemType::Square or immElemType == ElemType::Tetrah)
                nSides = 4;
            else if (immElemType == ElemType::Parallelep)
                nSides = 6;
            else
                throw runtime_error("Integration::_genCubaSetBorderImmersed for element " + str(immMesh->elemType()) + " not programmed for MeshRelation::ImmersedMesh!");
        }

        // Generate CubatureBorderGauss per side
        vector<RCP<CubatureBorderGauss>> cubaSide(nSides);
        for (int s = 0; s < nSides; s++)
        {
            cubaSide[s] = rcp(new CubatureBorderGauss);
            cubaSide[s]->setElemType(immElemType);
            cubaSide[s]->setNumIntPts(iPts);
            cubaSide[s]->setSide(s);
            cubaSide[s]->Update();
        }

        // Get axis
        vector<MAxis> axes = immMesh->_vMAx;

        // Generate cubature border immersed
        vector<vector<double>> rCorners = referenceCoordsElemCorners(backMesh->elemType());
        vector<CubatureInfo> cubaInfos(_params[cubaId].cutElems.size());

        // Initialze vectors for duplicate integration points
        vector<double> elemTemp;
        vector<double> iCoordsTemp;
        vector<double> iWeightsTemp;
        int ctag = 0;

        for (auto elem: _params[cubaId].cutElems)
        {
            // Get coordinates of the corners of the background element
            vector<vector<double>> cCoords(rCorners.size(), vector<double>(backNDim));
            for (size_t n = 0; n < rCorners.size(); n++)
                cCoords[n] = backMesh->interpolatePosition(elem, rCorners[n], idxType);

            // Get immersed elements
            vector<int> immElems = backMesh->_mapToChild->directMap(elem, idxType);
            // vector<int> immElems = _meshMaps[cubaId]->directMap(elem, idxType);
            // vector<int> immElems = _meshMaps[cubaId+1]->directMap(elem, idxType); // FIXME: This was here probably for the global constraint mesh (pressure), but it does not work for Poisson ImmersedBoundary (at least)

            // Get coordinates of the integration points of the immersed mesh
            vector<double> iCoords;
            vector<double> iWeights;
            // cout << "Background elem: "<< elem << endl;
            for (size_t ie = 0; ie < immElems.size(); ie++)
            {

                // Immersed mesh element
                int iElem = immElems[ie];
                // cout << "Immersed elem: "<< iElem << endl;

                // Get coordinates and tangents
                if (immMesh->_meshRel == MeshRelation::ImmersedBoundary)
                {
                    // Check if whole Immersed Element in Background Element
                    vector<int> backElems = immMesh->_mapToParent->directMap(iElem,idxType);
                    int numNbors = immMesh->_connec->getNumNbors(iElem, idxType);
                    int nbor1 = immMesh->_connec->getNbor(iElem, 0);
                    int nbor2 = immMesh->_connec->getNbor(iElem, 1);
                    vector<double> n1Coords = immMesh->nodeCoords(nbor1);
                    vector<double> n2Coords = immMesh->nodeCoords(nbor2);
                    vector<double> x1Coords = {n1Coords[0], n1Coords[1]};
                    vector<double> x2Coords = {n2Coords[0], n2Coords[1]};
                    vector<double> r1Coords(2);
                    vector<double> r2Coords(2);
                    double distPt1 = backMesh->DistributedMesh::_invertElementMapping_RegSquare(r1Coords, elem, x1Coords, IndexType::Local, false);
                    double distPt2 = backMesh->DistributedMesh::_invertElementMapping_RegSquare(r2Coords, elem, x2Coords, IndexType::Local, false);
                    vector<double> r1Coords0 = r1Coords;
                    vector<double> r2Coords0 = r2Coords;
                    vector<double> uRng = {-1,1};
                    double jac = 1;
                    if (backElems.size() > 1)
                    {
                        if(immMesh->basisFunctionType() == BasisFuncType::Lagrangian)
                        {
                            if (numNbors == 2)
                            {
                                if (abs(r2Coords[0]-r1Coords[0])>1e-15)
                                {
                                    double a = (r2Coords[1]-r1Coords[1])/(r2Coords[0]-r1Coords[0]);
                                    double b = r1Coords[1]-a*r1Coords[0];
                                    if (r1Coords[0] < rCorners[0][0])
                                    {
                                        r1Coords[0] = rCorners[0][0];
                                        r1Coords[1] = -a+b;
                                    }
                                    else if (r1Coords[0] > rCorners[3][0])
                                    {
                                        r1Coords[0] = rCorners[3][0];
                                        r1Coords[1] = a+b;
                                    }
                                    if(r1Coords[1] < rCorners[0][1])
                                    {
                                        r1Coords[0] = (-1.-b)/a;
                                        r1Coords[1] = rCorners[0][1];
                                    }
                                    else if (r1Coords[1] > rCorners[3][1])
                                    {
                                        r1Coords[0] = (1.-b)/a;
                                        r1Coords[1] = rCorners[3][1];
                                    }

                                    if (r2Coords[0] < rCorners[0][0])
                                    {
                                        r2Coords[0] = rCorners[0][0];
                                        r2Coords[1] = -a+b;
                                    }
                                    else if (r2Coords[0] > rCorners[3][0])
                                    {
                                        r2Coords[0] = rCorners[3][0];
                                        r2Coords[1] = a+b;
                                    }
                                    if(r2Coords[1] < rCorners[0][1])
                                    {
                                        r2Coords[0] = (-1.-b)/a;
                                        r2Coords[1] = rCorners[0][1];
                                    }
                                    else if (r2Coords[1] > rCorners[3][1])
                                    {
                                        r2Coords[0] = (1.-b)/a;
                                        r2Coords[1] = rCorners[3][1];
                                    }
                                }
                                else
                                {
                                    if(r1Coords[1] < rCorners[0][1])
                                    {
                                        r1Coords[0] = r1Coords[0];
                                        r1Coords[1] = rCorners[0][1];
                                    }
                                    else if (r1Coords[1] > rCorners[3][1])
                                    {
                                        r1Coords[0] = r1Coords[0];
                                        r1Coords[1] = rCorners[3][1];
                                    }

                                    if(r2Coords[1] < rCorners[0][1])
                                    {
                                        r2Coords[0] = r2Coords[0];
                                        r2Coords[1] = rCorners[0][1];
                                    }
                                    else if (r2Coords[1] > rCorners[3][1])
                                    {
                                        r2Coords[0] = r2Coords[0];
                                        r2Coords[1] = rCorners[3][1];
                                    }
                                }
                            }
                            else
                                cout << "NOT IMPLEMENTED" << endl;
                            jac = sqrt((r1Coords[0]-r2Coords[0])*(r1Coords[0]-r2Coords[0])+(r1Coords[1]-r2Coords[1])*(r1Coords[1]-r2Coords[1]))/
                                sqrt((r1Coords0[0]-r2Coords0[0])*(r1Coords0[0]-r2Coords0[0])+(r1Coords0[1]-r2Coords0[1])*(r1Coords0[1]-r2Coords0[1]));
                        }
                        else if(immMesh->basisFunctionType() == BasisFuncType::BSplines)
                        {
                            // Check fraction of u in (-1,1) inside element
                            vector<double> abcd = immMesh->_compBsplineEq(immMesh,iElem);
                        
                            vector<double> abcdx = {abcd[0],abcd[2],abcd[4],abcd[6]};
                            vector<double> abcdy = {abcd[1],abcd[3],abcd[5],abcd[7]};
                            
                            // Check crossing with top, bottom, left, right faces if any compute the u value
                            vector<double> lSols = SGeometry::cubicLineIntersect(abcdx,cCoords[0][0]);
                            vector<double> rSols = SGeometry::cubicLineIntersect(abcdx,cCoords[3][0]);
                            vector<double> bSols = SGeometry::cubicLineIntersect(abcdy,cCoords[0][1]);
                            vector<double> tSols = SGeometry::cubicLineIntersect(abcdy,cCoords[3][1]);
                            for(int i = 0; i < lSols.size(); i++) /// Check cross with left side
                            {
                                double t = lSols[i];
                                if (t>-1 and t<1)
                                {
                                    double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(yt>cCoords[0][1] and yt<cCoords[3][1])
                                    {
                                        double dxdt = 3.*abcdx[0]*t*t+2.*abcdx[1]*t+abcdx[2];
                                        if (dxdt > 0)
                                            uRng[0] = max(t,uRng[0]);
                                        else if (dxdt < 0)
                                            uRng[1] = min(t,uRng[1]);
                                    }
                                }
                            }

                            for(int i = 0; i < rSols.size(); i++)
                            {
                                double t = rSols[i];
                                if (t>-1 and t<1)
                                {
                                    // xsol = abcdx[0]*t*t*t+abcdx[1]*t*t+abcdx[2]*t+abcdx[3];
                                    double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(yt>cCoords[0][1] and yt<cCoords[3][1])
                                    {
                                        double dxdt = 3.*abcdx[0]*t*t+2.*abcdx[1]*t+abcdx[2];
                                        if (dxdt > 0)
                                            uRng[1] = min(t,uRng[1]);
                                        else if (dxdt < 0)
                                            uRng[0] = max(t,uRng[0]);
                                    }
                                }
                            }

                            for(int i = 0; i < bSols.size(); i++)
                            {
                                double t = bSols[i];
                                if (t>-1 and t<1)
                                {
                                    double xt = abcdx[0]*t*t*t+abcdx[1]*t*t+abcdx[2]*t+abcdx[3];
                                    // double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(xt>cCoords[0][0] and xt<cCoords[3][0])
                                    {
                                        double dydt = 3.*abcdy[0]*t*t+2.*abcdy[1]*t+abcdy[2];
                                        if (dydt > 0)
                                            uRng[0] = max(t,uRng[0]);
                                        else if (dydt < 0)
                                            uRng[1] = min(t,uRng[1]);
                                    }
                                }
                            }

                            for(int i = 0; i < tSols.size(); i++)
                            {
                                double t = tSols[i];
                                if (t>-1 and t<1)
                                {
                                    double xt = abcdx[0]*t*t*t+abcdx[1]*t*t+abcdx[2]*t+abcdx[3];
                                    // double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(xt>cCoords[0][0] and xt<cCoords[3][0])
                                    {
                                        double dydt = 3.*abcdy[0]*t*t+2.*abcdy[1]*t+abcdy[2];
                                        if (dydt > 0)
                                            uRng[1] = min(t,uRng[1]);
                                        else if (dydt < 0)
                                            uRng[0] = max(t,uRng[0]);
                                    }
                                }
                            }
                           
                        }
                    }

                    // cout << "Immersed Element: " << iElem << "-> " << "("<<uRng[0]<<", "<<uRng[1]<<")"<< endl;
                    vector<double> xSamples(immPDim);
                    // cout<< "Elem = " << elem << endl;
                    for (int i = 0; i < iPts; i++)
                    {
                        // Get parametric coordinates of the integration point
                        for (int p = 0; p < immPDim; p++)
                            xSamples[p] = immCuba->_xSamples[immPDim*i + p];
                        // cout << xSamples[0] << endl;
                        // Compute bf at integration point
                        vector<vector<double>>& bf = immMesh->_basisFunctions->computeBasisFunctionsReference(xSamples, immMesh->_basisFunctions->getTag(iElem, idxType));

                        // cout << "Basis functions: ("<<bf[0][0]<<", " <<bf[0][1]<<", " <<bf[0][2]<<", " <<bf[0][3]<<")";
                        // Compute coordinates of integration point
                        vector<double> iC(backMesh->nDim());
                        for (int n = 0; n < numNbors; n++)
                        {
                            int nbor = immMesh->_connec->getNbor(iElem, n);
                            for (int d = 0; d < backNDim; d++)
                                iC[d] += immMesh->nodeCoord(nbor, d)*bf[0][n];
                        }

                        // Check if the integration point is in the background element
                        // FIXME: We are assuming squares with straight sides. Use
                        //        searchElement (more expensive) to fix it
                        
                        // Invert mapping
                        vector<double> xCoords = {iC[0], iC[1]};
                        vector<double> rCoords(2); // Coordinates of the integration point on the reference space of the BG element
                        vector<double> dbfg(2,0); // Parametric derivative of the curve
                        double jac2 = 0;
                        if (immMesh->basisFunctionType() == BasisFuncType::Lagrangian)
                        {
                            // double distPt = backMesh->DistributedMesh::_invertElementMapping_LinearSquare(rCoords, elem, xCoords, rCoords0, IndexType::Local, false);
                            double distPt = backMesh->DistributedMesh::_invertElementMapping_RegSquare(rCoords, elem, xCoords, IndexType::Local, false);
                            rCoords = {bf[0][0]*r1Coords[0]+bf[0][1]*r2Coords[0],bf[0][0]*r1Coords[1]+bf[0][1]*r2Coords[1]};
                        }
                        else if (immMesh->basisFunctionType() == BasisFuncType::BSplines)
                        {
                            // Check fraction of u in (0,1) inside element
                            double u0 = uRng[0];
                            double u1 = uRng[1];
                            double a = 0.5*(u1-u0);
                            double b = 0.5*(u1+u0);

                            int inex = immMesh->_oldElementIndex(iElem);
                            int offU = 0;
                            for(int i = 0; i < (int)immMesh->_vCrv.size(); i++)
                            {
                                if (inex < immMesh->_vCrv[i])
                                {
                                    break;
                                }
                                offU += 7;
                            }
                            inex += offU;
                            double elLngth = (immMesh->_uKnot[3+inex+1]-immMesh->_uKnot[3+inex]);

                            jac = (uRng[1]-uRng[0])*elLngth/2.;
                            jac2 = (uRng[1]-uRng[0])/2.;

                            xSamples[0] = a*xSamples[0]+b;

                            vector<vector<double>>& bf = immMesh->_basisFunctions->computeBasisFunctionsReference(xSamples, immMesh->_basisFunctions->getTag(iElem, idxType));

                            rCoords[0] = 0; 
                            rCoords[1] = 0;
                            vector<double> gCoords(2,0);
                            for (int i = 0; i<4; i++)
                            {
                                int nbor = immMesh->_connec->getNbor(iElem, i);
                                vector<double> nCoords = immMesh->nodeCoords(nbor);
                                rCoords[0] += bf[0][i]*(2./(cCoords[3][0]-cCoords[0][0])*nCoords[0]+(-cCoords[3][0]-cCoords[0][0])/(cCoords[3][0]-cCoords[0][0]));
                                rCoords[1] += bf[0][i]*(2./(cCoords[3][1]-cCoords[0][1])*nCoords[1]+(-cCoords[3][1]-cCoords[0][1])/(cCoords[3][1]-cCoords[0][1]));
                                gCoords[0] += bf[0][i]*nCoords[0];
                                gCoords[1] += bf[0][i]*nCoords[1];
                                dbfg[0] += bf[1][i]*nCoords[0];
                                dbfg[1] += bf[1][i]*nCoords[1];
                            }
                            // cout <<gCoords[0]<<", "<<gCoords[1]<<", " <<  dbfg[0] <<", "<<dbfg[1]<<endl; 
                        } 

                        switch (backMesh->_pDim)
                        {
                            case 2:
                                if (rCoords[0] >= rCorners[0][0] and rCoords[0] <= rCorners[3][0] and
                                    rCoords[1] >= rCorners[0][1] and rCoords[1] <= rCorners[3][1])
                                {
                                    // Save integration point coords and weights
                                    iCoords.push_back(rCoords[0]);
                                    iCoords.push_back(rCoords[1]);
                                    iWeights.push_back(immCuba->_wSamples[i]*jac);

                                    // Save tangents
                                    vector<double> t(3, 0.0);

                                    if (immMesh->basisFunctionType() == BasisFuncType::Lagrangian)
                                    {
                                        vector<double> coords;
                                        for (int n = 0; n < numNbors; n++)
                                        {
                                            int nbor = immMesh->_connec->getNbor(iElem, n);
                                            for (int d = 0; d < backNDim; d++)
                                                coords.push_back(immMesh->nodeCoord(nbor, d));
                                        }
                                        for (int n = 0; n < numNbors; n++)
                                        {
                                            for (int d = 0; d < backNDim; d++)
                                                t[d] += coords[backNDim * n + d] * bf[1][n];
                                        }
                                    }
                                    else if (immMesh->basisFunctionType() == BasisFuncType::BSplines)
                                    {
                                        t[0] = dbfg[0];
                                        t[1] = dbfg[1];
                                        t[2] = 0;

                                    }

                                    immMesh->_immTangents[elem].push_back(-t[0]);
                                    immMesh->_immTangents[elem].push_back(-t[1]);
                                    immMesh->_immTangents[elem].push_back(-t[2]);

                                    immMesh->_immElemID[elem].push_back(iElem);
                                    immMesh->_immLocalParam[elem].push_back(xSamples[0]);

                                }
                                break;

                            case 3:
                                if (iC[0] >= cCoords[0][0] and iC[0] <= cCoords[7][0] and
                                    iC[1] >= cCoords[0][1] and iC[1] <= cCoords[7][1] and
                                    iC[2] >= cCoords[0][2] and iC[2] <= cCoords[7][2])
                                {
                                    // Avoid the repetition of integration points that are
                                    // on the left/top border of the elements, but keep
                                    // those that are on the left/top of the geometry
                                    // FIXME: This assumes unit square geometry
                                    if (iC[0] == cCoords[7][0] and iC[0] != 1.0)
                                        continue;
                                    if (iC[1] == cCoords[7][1] and iC[1] != 1.0)
                                        continue;
                                    if (iC[2] == cCoords[7][2] and iC[2] != 1.0)
                                        continue;

                                    // Save integration point coords and weights
                                    double sideX = cCoords[7][0] - cCoords[0][0];
                                    double sideY = cCoords[7][1] - cCoords[0][1];
                                    double sideZ = cCoords[7][2] - cCoords[0][2];
                                    iCoords.push_back((iC[0] - cCoords[0][0] - sideX / 2.0) / sideX * 2.0);
                                    iCoords.push_back((iC[1] - cCoords[0][1] - sideY / 2.0) / sideY * 2.0);
                                    iCoords.push_back((iC[2] - cCoords[0][2] - sideZ / 2.0) / sideY * 2.0);
                                    iWeights.push_back(immCuba->_wSamples[i]);

                                    // Get coordinate of each node
                                    vector<vector<double>> nodeXYZ(numNbors, vector<double>(3));
                                    for (int node{}; node < numNbors; ++node)
                                    {
                                        int globalNodeNumber = immMesh->_connec->getNbor(iElem, node);
                                        nodeXYZ[node] = immMesh->nodeCoords(globalNodeNumber);
                                    }

                                    // Compute tangent using the derivatives of basis functions
                                    vector<vector<double>> t(2, vector<double>(3));
                                    for (int d{}; d < backNDim; d++) // Loop over x, y, and z
                                    {
                                        for (int A{}; A < numNbors; ++A) // Loop over nodes
                                        {
                                            t[0][d] += nodeXYZ[A][d] * bf[1][2 * A];
                                            t[1][d] += nodeXYZ[A][d] * bf[1][2 * A + 1];
                                        }
                                    }

                                    // Save tangents
                                    for (size_t j{}; j < t.size(); j++)
                                    {
                                        for (size_t d{}; d < t[j].size(); d++)
                                        {
                                            immMesh->_immTangents[elem].push_back(t[j][d]);
                                        }
                                    }
                                }
                                break;

                            default:
                                throw runtime_error ("Integration::_genCubaSetBorderImmersed: 1D immersed method not implemented.");
                                break;
                        }
                    }
                }
                else
                {
                    // Get vector of sides for this element
                    vector<int> sides = immMesh->_getMeshBoundariesOfElement(iElem, IndexType::Local, axes);

                    // Get coordinates and tangents
                    vector<double> xSamples(immPDim);
                    int numNbors = immMesh->_connec->getNumNbors(iElem, idxType);
                    for (auto s: sides)
                    {
                        for (int i = 0; i < iPts; i++)
                        {
                            // Get parametric coordinates of the integration point
                            for (int p = 0; p < immPDim; p++)
                                xSamples[p] = cubaSide[s-1]->_xSamples[immPDim*i + p];

                            // Compute bf at integration point
                            vector<vector<double>>& bf = immMesh->_basisFunctions->computeBasisFunctionsReference(xSamples, immMesh->_basisFunctions->getTag(iElem, idxType));

                            // Compute coordinates of integration point
                            vector<double> iC(backMesh->nDim());
                            for (int n = 0; n < numNbors; n++)
                            {
                                int nbor = immMesh->_connec->getNbor(iElem, n);
                                for (int d = 0; d < backNDim; d++)
                                    iC[d] += immMesh->nodeCoord(nbor, d)*bf[0][n];
                            }
                        
                            // Invert mapping
                            vector<double> xCoords = {iC[0], iC[1]};
                            vector<double> rCoords1(2);
                            vector<double> rCoords0(2);
                            // double distPt = backMesh->DistributedMesh::_invertElementMapping_LinearSquare(rCoords1, elem, xCoords, rCoords0, IndexType::Local, false);
                            double distPt = backMesh->DistributedMesh::_invertElementMapping_RegSquare(rCoords1, elem, xCoords, IndexType::Local, false);

                            // Check if the integration point is in the background element
                            switch (backMesh->_pDim)
                            {
                                case 2:
                                    if (rCoords1[0] >= rCorners[0][0] and rCoords1[0] <= rCorners[3][0] and
                                        rCoords1[1] >= rCorners[0][1] and rCoords1[1] <= rCorners[3][1])
                                    {
                                        // Avoid the repetition of integration points that are
                                        // on the border of the element. Store them on a vector 
                                        // to then broadcast between ranks and removes duplicates.
                                        bool borderX = (rCoords1[0] == rCorners[3][0]) or (rCoords1[0] == rCorners[1][0]);
                                        bool borderY = (rCoords1[1] == rCorners[3][1]) or (rCoords1[1] == rCorners[1][1]);
                                        bool dupl = 0;
                                        if (borderX or borderY)
                                        {
                                            for (int jj = 0; jj < size(elemTemp); jj++)
                                            {
                                                if (1e-14 < (iCoordsTemp[2*jj]-xCoords[0])*(iCoordsTemp[2*jj]-xCoords[0])+(iCoordsTemp[2*jj+1]-xCoords[1])*(iCoordsTemp[2*jj+1]-xCoords[1]))
                                                {
                                                    bool dupl = 1;
                                                    break;
                                                }
                                            }
                                            elemTemp.push_back(elem);
                                            iCoordsTemp.push_back(xCoords[0]);
                                            iCoordsTemp.push_back(xCoords[1]);
                                        }
                                        if (!dupl)
                                        {
                                            // Save integration point coords and weights
                                            iCoords.push_back(rCoords1[0]);
                                            iCoords.push_back(rCoords1[1]);
                                            iWeights.push_back(cubaSide[s-1]->_wSamples[i]);

                                            // Save tangents
                                            vector<double> coords;
                                            for (int n = 0; n < numNbors; n++)
                                            {
                                                int nbor = immMesh->_connec->getNbor(iElem, n);
                                                for (int d = 0; d < backNDim; d++)
                                                    coords.push_back(immMesh->nodeCoord(nbor, d));
                                            }
                                            vector<double> t(3, 0.0);
                                            for (int n = 0; n < numNbors; n++)
                                            {
                                                for (int d = 0; d < backNDim; d++)
                                                    t[d] += coords[backNDim * n + d] * bf[1][n];
                                            }

                                            immMesh->_immTangents[elem].push_back(-t[0]);
                                            immMesh->_immTangents[elem].push_back(-t[1]);
                                            immMesh->_immTangents[elem].push_back(-t[2]);

                                            immMesh->_immElemID[elem].push_back(iElem);
                                            immMesh->_immLocalParam[elem].push_back(xSamples[0]);
                                        }
                                    }
                                    break;

                                case 3:
                                    if (iC[0] >= cCoords[0][0] and iC[0] <= cCoords[7][0] and
                                        iC[1] >= cCoords[0][1] and iC[1] <= cCoords[7][1] and
                                        iC[2] >= cCoords[0][2] and iC[2] <= cCoords[7][2])
                                    {
                                        // Avoid the repetition of integration points that are
                                        // on the left/top border of the elements, but keep
                                        // those that are on the left/top of the geometry
                                        // FIXME: This assumes unit square geometry
                                        if (iC[0] == cCoords[7][0] and iC[0] != 1.0)
                                            continue;
                                        if (iC[1] == cCoords[7][1] and iC[1] != 1.0)
                                            continue;
                                        if (iC[2] == cCoords[7][2] and iC[2] != 1.0)
                                            continue;

                                        // Save integration point coords and weights
                                        double sideX = cCoords[7][0] - cCoords[0][0];
                                        double sideY = cCoords[7][1] - cCoords[0][1];
                                        double sideZ = cCoords[7][2] - cCoords[0][2];
                                        iCoords.push_back((iC[0] - cCoords[0][0] - sideX / 2.0) / sideX * 2.0);
                                        iCoords.push_back((iC[1] - cCoords[0][1] - sideY / 2.0) / sideY * 2.0);
                                        iCoords.push_back((iC[2] - cCoords[0][2] - sideZ / 2.0) / sideY * 2.0);
                                        iWeights.push_back(cubaSide[s-1]->_wSamples[i]);

                                        // Get coordinate of each node
                                        vector<vector<double>> nodeXYZ(numNbors, vector<double>(3));
                                        for (int node{}; node < numNbors; ++node)
                                        {
                                            int globalNodeNumber = immMesh->_connec->getNbor(iElem, node);
                                            nodeXYZ[node] = immMesh->nodeCoords(globalNodeNumber);
                                        }

                                        // Compute tangent using the derivatives of basis functions
                                        vector<vector<double>> t(2, vector<double>(3));
                                        for (int d{}; d < backNDim; d++) // Loop over x, y, and z
                                        {
                                            for (int A{}; A < numNbors; ++A) // Loop over nodes
                                            {
                                                t[0][d] += nodeXYZ[A][d] * bf[1][2 * A];
                                                t[1][d] += nodeXYZ[A][d] * bf[1][2 * A + 1];
                                            }
                                        }

                                        // Save tangents
                                        for (size_t j{}; j < t.size(); j++)
                                        {
                                            for (size_t d{}; d < t[j].size(); d++)
                                            {
                                                immMesh->_immTangents[elem].push_back(t[j][d]);
                                            }
                                        }
                                    }
                                    break;

                                default:
                                    throw runtime_error ("Integration::_genCubaSetBorderImmersed: 1D immersed method not implemented.");
                                break;
                            }
                        }
                    }
                }
            }

            // Generate borderImmersed cubature
            RCP<CubatureBasic> cuba = rcp(new CubatureBasic);
            cuba->setElemType(backMesh->elemType());
            cuba->setIntegrationPoints(iCoords);
            cuba->setIntegrationWeights(iWeights);
            cuba->Update();
            if (cuba->iPts() == 0)
                cout << "_genCubaSetBorderImmersed: Element " + to_string(elem) + " has no integration points." << endl;
            //     throw runtime_error("_genCubaSetBorderImmersed: Element " + to_string(elem) + " has no integration points.");

            // Save cubature info
            cubaInfos[ctag] = cuba->cubatureInfo();
            cubaInfos[ctag].cubaName = "CubatureBorderImmersed";

            // Add cubature info to cubaset
            _cubaSets[0]->addCubaInfo(ctag, cubaInfos[ctag], {elem}, idxType);

            // Increase cubatag
            ctag++;
        }
    }

    void Integration::_genCubaSetUserDefined(int cubaId)
    {
        // Generate cubature info
        RCP<CubatureBasic> cuba = rcp(new CubatureBasic);
        cuba->setIntegrationPoints(_params[cubaId].rCoords);
        cuba->setIntegrationWeights(_params[cubaId].weights);
        cuba->setElemType(_dhands[0]->mesh->elemType());
        cuba->Update();
        CubatureInfo cubaInfo = cuba->cubatureInfo();

        // Generate cubaSet for the primary DOFsHandler
        if (_cubaSets[0] == Teuchos::null)
        {
            _cubaSets[0] = rcp(new CubatureSet);
            _cubaSets[0]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);
            _cubaSets[0]->Update();
        }

        // Add cubaInfo
        _cubaSets[0]->addCubaInfo(cubaId, cubaInfo, _params[cubaId].elems, _params[cubaId].idxType);
    }

    void Integration::_genCubaSetLagrMultiplMacroElems(int numDHand, CubatureSet* cubaSetMast)
    {
        static int i = numDHand;

        int N = _dhands[0]->mesh->nElem() / _dhands[i]->mesh->nElem();

        auto masterCubaInfo = cubaSetMast->cubaInfo(0);

        map<vector<int>, int> cubaSets;
        vector<int> defReord (4, 0);
        vector<int> defSlavTag (8, 0);
        cubaSets.emplace(defSlavTag, 0);
        vector<CubatureInfo> defCubaInfos (4, masterCubaInfo);

        CubatureInfo slaveInfo = generateMacroCubaInfo(defCubaInfos, N, 0, defReord);

        _cubaSets[i] = rcp(new CubatureSet);
        _cubaSets[i]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);
        _cubaSets[i]->Update();

        _cubaSets[i]->addCubaInfo(0, slaveInfo);


        for (int e = 0; e < _dhands[i]->mesh->loc_nElem(); e++)
        {
            auto mastGloElems = _meshMaps[i]->inverseMap(e, IndexType::Local);
            auto mastReord = _dhands[0]->mesh->elemTag(0, mastGloElems, IndexType::Global);

            /// If the slave element is also rotated respect to the original connectivity we need to take this in account.
            auto slaveRot = _dhands[i]->mesh->elemTag(0, e, IndexType::Local);

            //FIXME: extend to other elements...
            if (_dhands[i]->mesh->elemType() == ElemType::Triang)
            {
                switch (slaveRot)
                {
                    case 0:
                        break;
                    case 1:
                        mastReord[0]=(mastReord[0]+1)%3;
                        mastReord[1]=(mastReord[1]+2)%3;
                        mastReord[2]=mastReord[2];
                        mastReord[3]=(mastReord[3]+2)%3;
                        break;
                    case 2:
                        mastReord[0]=(mastReord[0]+1)%3;
                        mastReord[1]= mastReord[1];
                        mastReord[2]=(mastReord[2]+2)%3;
                        mastReord[3]=(mastReord[3]+1)%3;
                        break;
                    default:
                        break;
                }
            }
            else if (_dhands[i]->mesh->elemType() == ElemType::Line)
            {

            }
            else
            {
                throw std::runtime_error("CubatureInfo::_generateCubatureLagrMultiplMacroElems: only working for triangles at the moment...");
            }

            /// Slave tag is the masterTag + Reordering
            vector<int> currSlavTag;
            currSlavTag.reserve(2*mastGloElems.size()+1);
            for (int i = 0; i < int(mastGloElems.size()); i++)
                currSlavTag.push_back(cubaSetMast->cubaTag(mastGloElems[i], IndexType::Global)[0]);
            for (int i = 0; i < int(mastGloElems.size()); i++)
                currSlavTag.push_back(mastReord[i]);
            currSlavTag.push_back(slaveRot);

            vector<CubatureInfo> currCubaInfos;
            for (int i = 0; i < int(mastGloElems.size()); i++)
                currCubaInfos.push_back(cubaSetMast->cubaInfo(currSlavTag[i]));

            auto it = cubaSets.find(currSlavTag);

            if (it == cubaSets.end())
            {
                CubatureInfo currSlaveInfo = generateMacroCubaInfo(currCubaInfos, N, slaveRot, mastReord);

                size_t cubaTag = _cubaSets[i]->numCubas();
                _cubaSets[i]->addCubaInfo(cubaTag, currSlaveInfo,{static_cast<size_t>(e)}, IndexType::Local);
                cubaSets.emplace(currSlavTag, cubaTag);
            }
            else
            {
                CubatureInfo currSlaveInfo = _cubaSets[i]->cubaInfo(it->second);
                _cubaSets[i]->addCubaInfo(it->second, slaveInfo,{static_cast<size_t>(e)}, IndexType::Local);
            }

        }
    }

    void Integration::_genCubaSetImmersed(int cubaId)
    {
        // Initialize
        auto backMesh = _dhands[0]->mesh;
        auto immMesh = backMesh->_childMesh;
    
        cubaParams params = _params[0];
        int iPts = params.iPts;
        IndexType idxType = params.idxType;
        int backNDim = backMesh->nDim();
        int immPDim = immMesh->pDim();
        auto immElemType = immMesh->elemType();
        _meshMaps[cubaId]->_kmap.resize(backMesh->loc_nElem());
        _meshMaps[cubaId]->_offsetmap.resize(backMesh->loc_nElem());
        _meshMaps[cubaId]->_idxCuba.resize(backMesh->loc_nElem());

        // Generate cubature of the immersed mesh for the ImmersedBoundary
        RCP<CubatureGauss> immCuba = rcp(new CubatureGauss);
        if (immMesh->_meshRel == MeshRelation::ImmersedBoundary)
        {
            immCuba->setElemType(immMesh->elemType());
            immCuba->setNumIntPts(iPts);
            immCuba->Update();
        }

        // Compute number of sides
        int nSides{};
        if (immMesh->_meshRel == MeshRelation::ImmersedMesh)
        {
            if (immElemType == ElemType::Triang)
                nSides = 3;
            else if (immElemType == ElemType::Square or immElemType == ElemType::Tetrah)
                nSides = 4;
            else if (immElemType == ElemType::Parallelep)
                nSides = 6;
            else
                throw runtime_error("Integration::_genCubaSetBorderImmersed for element " + str(immMesh->elemType()) + " not programmed for MeshRelation::ImmersedMesh!");
        }

        // Generate CubatureBorderGauss per side
        vector<RCP<CubatureBorderGauss>> cubaSide(nSides);
        for (int s = 0; s < nSides; s++)
        {
            cubaSide[s] = rcp(new CubatureBorderGauss);
            cubaSide[s]->setElemType(immElemType);
            cubaSide[s]->setNumIntPts(iPts);
            cubaSide[s]->setSide(s);
            cubaSide[s]->Update();
        }

        // Get axis
        vector<MAxis> axes = immMesh->_vMAx;
        // Initialze vectors for duplicate integration points
        vector<double> elemTemp;
        vector<double> iCoordsTemp;
        vector<double> iWeightsTemp;
        // Generate mappings
        vector<vector<double>> rCorners = referenceCoordsElemCorners(backMesh->elemType());
        for (auto elem: params.cutElems)
        {
            // Get coordinates of the corners of the background element
            vector<vector<double>> cCoords(rCorners.size(), vector<double>(backNDim));
            for (size_t n = 0; n < rCorners.size(); n++)
                cCoords[n] = backMesh->interpolatePosition(elem, rCorners[n], idxType);

            // Get mapping between elements and int point and their offset
            vector<int> immElems = backMesh->_mapToChild->directMap(elem, idxType);
            for (size_t ie = 0; ie < immElems.size(); ie++)
            {
                // Immersed mesh element
                int iElem = immElems[ie];

                // Get coordinates and tangents
                if (immMesh->_meshRel == MeshRelation::ImmersedBoundary)
                {
                    // Check if whole Immersed Element in Background Element
                    vector<int> backElems = immMesh->_mapToParent->directMap(iElem,idxType);
                    int numNbors = immMesh->_connec->getNumNbors(iElem, idxType);
                    int nbor1 = immMesh->_connec->getNbor(iElem, 0);
                    int nbor2 = immMesh->_connec->getNbor(iElem, 1);
                    vector<double> n1Coords = immMesh->nodeCoords(nbor1);
                    vector<double> n2Coords = immMesh->nodeCoords(nbor2);
                    vector<double> x1Coords = {n1Coords[0], n1Coords[1]};
                    vector<double> x2Coords = {n2Coords[0], n2Coords[1]};
                    vector<double> r1Coords(2);
                    vector<double> r2Coords(2);
                    double distPt1 = backMesh->DistributedMesh::_invertElementMapping_RegSquare(r1Coords, elem, x1Coords, IndexType::Local, false);
                    double distPt2 = backMesh->DistributedMesh::_invertElementMapping_RegSquare(r2Coords, elem, x2Coords, IndexType::Local, false);
                    vector<double> r1Coords0 = r1Coords;
                    vector<double> r2Coords0 = r2Coords;
                    vector<double> uRng = {-1,1};

                    if (backElems.size() > 1)
                    {
                        if(immMesh->basisFunctionType() == BasisFuncType::Lagrangian)
                        {
                            if (numNbors == 2)
                            {
                                if (abs(r2Coords[0]-r1Coords[0])>1e-15)
                                {
                                    double a = (r2Coords[1]-r1Coords[1])/(r2Coords[0]-r1Coords[0]);
                                    double b = r1Coords[1]-a*r1Coords[0];
                                    if (r1Coords[0] < rCorners[0][0])
                                    {
                                        r1Coords[0] = rCorners[0][0];
                                        r1Coords[1] = -a+b;
                                    }
                                    else if (r1Coords[0] > rCorners[3][0])
                                    {
                                        r1Coords[0] = rCorners[3][0];
                                        r1Coords[1] = a+b;
                                    }
                                    if(r1Coords[1] < rCorners[0][1])
                                    {
                                        r1Coords[0] = (-1.-b)/a;
                                        r1Coords[1] = rCorners[0][1];
                                    }
                                    else if (r1Coords[1] > rCorners[3][1])
                                    {
                                        r1Coords[0] = (1.-b)/a;
                                        r1Coords[1] = rCorners[3][1];
                                    }

                                    if (r2Coords[0] < rCorners[0][0])
                                    {
                                        r2Coords[0] = rCorners[0][0];
                                        r2Coords[1] = -a+b;
                                    }
                                    else if (r2Coords[0] > rCorners[3][0])
                                    {
                                        r2Coords[0] = rCorners[3][0];
                                        r2Coords[1] = a+b;
                                    }
                                    if(r2Coords[1] < rCorners[0][1])
                                    {
                                        r2Coords[0] = (-1.-b)/a;
                                        r2Coords[1] = rCorners[0][1];
                                    }
                                    else if (r2Coords[1] > rCorners[3][1])
                                    {
                                        r2Coords[0] = (1.-b)/a;
                                        r2Coords[1] = rCorners[3][1];
                                    }
                                }
                                else
                                {
                                    if(r1Coords[1] < rCorners[0][1])
                                    {
                                        r1Coords[0] = r1Coords[0];
                                        r1Coords[1] = rCorners[0][1];
                                    }
                                    else if (r1Coords[1] > rCorners[3][1])
                                    {
                                        r1Coords[0] = r1Coords[0];
                                        r1Coords[1] = rCorners[3][1];
                                    }

                                    if(r2Coords[1] < rCorners[0][1])
                                    {
                                        r2Coords[0] = r2Coords[0];
                                        r2Coords[1] = rCorners[0][1];
                                    }
                                    else if (r2Coords[1] > rCorners[3][1])
                                    {
                                        r2Coords[0] = r2Coords[0];
                                        r2Coords[1] = rCorners[3][1];
                                    }
                                }
                            }
                            else
                                cout << "NOT IMPLEMENTED" << endl;
                        }
                        else if(immMesh->basisFunctionType() == BasisFuncType::BSplines)
                        {
                            // Check fraction of u in (-1,1) inside element
                            vector<double> abcd = immMesh->_compBsplineEq(immMesh,iElem);
                        
                            vector<double> abcdx = {abcd[0],abcd[2],abcd[4],abcd[6]};
                            vector<double> abcdy = {abcd[1],abcd[3],abcd[5],abcd[7]};
                            
                            // Check crossing with top, bottom, left, right faces if any compute the u value
                            vector<double> lSols = SGeometry::cubicLineIntersect(abcdx,cCoords[0][0]);
                            vector<double> rSols = SGeometry::cubicLineIntersect(abcdx,cCoords[3][0]);
                            vector<double> bSols = SGeometry::cubicLineIntersect(abcdy,cCoords[0][1]);
                            vector<double> tSols = SGeometry::cubicLineIntersect(abcdy,cCoords[3][1]);
                            for(int i = 0; i < lSols.size(); i++) /// Check cross with left side
                            {
                                double t = lSols[i];
                                if (t>-1 and t<1)
                                {
                                    double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(yt>cCoords[0][1] and yt<cCoords[3][1])
                                    {
                                        double dxdt = 3.*abcdx[0]*t*t+2.*abcdx[1]*t+abcdx[2];
                                        if (dxdt > 0)
                                            uRng[0] = max(t,uRng[0]);
                                        else if (dxdt < 0)
                                            uRng[1] = min(t,uRng[1]);
                                    }
                                }
                            }

                            for(int i = 0; i < rSols.size(); i++)
                            {
                                double t = rSols[i];
                                if (t>-1 and t<1)
                                {
                                    // xsol = abcdx[0]*t*t*t+abcdx[1]*t*t+abcdx[2]*t+abcdx[3];
                                    double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(yt>cCoords[0][1] and yt<cCoords[3][1])
                                    {
                                        double dxdt = 3.*abcdx[0]*t*t+2.*abcdx[1]*t+abcdx[2];
                                        if (dxdt > 0)
                                            uRng[1] = min(t,uRng[1]);
                                        else if (dxdt < 0)
                                            uRng[0] = max(t,uRng[0]);
                                    }
                                }
                            }

                            for(int i = 0; i < bSols.size(); i++)
                            {
                                double t = bSols[i];
                                if (t>-1 and t<1)
                                {
                                    double xt = abcdx[0]*t*t*t+abcdx[1]*t*t+abcdx[2]*t+abcdx[3];
                                    // double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(xt>cCoords[0][0] and xt<cCoords[3][0])
                                    {
                                        double dydt = 3.*abcdy[0]*t*t+2.*abcdy[1]*t+abcdy[2];
                                        if (dydt > 0)
                                            uRng[0] = max(t,uRng[0]);
                                        else if (dydt < 0)
                                            uRng[1] = min(t,uRng[1]);
                                    }
                                }
                            }

                            for(int i = 0; i < tSols.size(); i++)
                            {
                                double t = tSols[i];
                                if (t>-1 and t<1)
                                {
                                    double xt = abcdx[0]*t*t*t+abcdx[1]*t*t+abcdx[2]*t+abcdx[3];
                                    // double yt = abcdy[0]*t*t*t+abcdy[1]*t*t+abcdy[2]*t+abcdy[3];
                                    if(xt>cCoords[0][0] and xt<cCoords[3][0])
                                    {
                                        double dydt = 3.*abcdy[0]*t*t+2.*abcdy[1]*t+abcdy[2];
                                        if (dydt > 0)
                                            uRng[1] = min(t,uRng[1]);
                                        else if (dydt < 0)
                                            uRng[0] = max(t,uRng[0]);
                                    }
                                }
                            }
                           
                        }
                    }

                    vector<double> xSamples(immPDim);
                    for (int i = 0; i < iPts; i++)
                    {
                        // Get parametric coordinates of the integration point
                        for (int p = 0; p < immPDim; p++)
                            xSamples[p] = immCuba->_xSamples[immPDim*i + p];

                        // Compute bf at integration point
                        vector<vector<double>>& bf = immMesh->_basisFunctions->computeBasisFunctionsReference(xSamples, immMesh->_basisFunctions->getTag(iElem, idxType));

                        // Compute coordinates of integration point
                        vector<double> iC(backMesh->nDim());
                        for (int n = 0; n < numNbors; n++)
                        {
                            int nbor = immMesh->_connec->getNbor(iElem, n);
                            for (int d = 0; d < backNDim; d++)
                                iC[d] += immMesh->nodeCoord(nbor, d)*bf[0][n];
                        }
                         // Invert mapping
                        vector<double> xCoords = {iC[0], iC[1]};
                        vector<double> rCoords1(2);
                        vector<double> dbfg(2,0);
                        double jac = 0;
                        double jac2 = 0;
                        
                        if (immMesh->basisFunctionType() == BasisFuncType::Lagrangian)
                        {
                            // double distPt = backMesh->DistributedMesh::_invertElementMapping_LinearSquare(rCoords, elem, xCoords, rCoords0, IndexType::Local, false);
                            double distPt = backMesh->DistributedMesh::_invertElementMapping_RegSquare(rCoords1, elem, xCoords, IndexType::Local, false);
                            rCoords1 = {bf[0][0]*r1Coords[0]+bf[0][1]*r2Coords[0],bf[0][0]*r1Coords[1]+bf[0][1]*r2Coords[1]};
                        }
                        else if (immMesh->basisFunctionType() == BasisFuncType::BSplines)
                        {
                            // Check fraction of u in (0,1) inside element
                            double u0 = uRng[0];
                            double u1 = uRng[1];
                            double a = 0.5*(u1-u0);
                            double b = 0.5*(u1+u0);

                            int inex = immMesh->_oldElementIndex(iElem);
                            int offU = 0;
                            for(int i = 0; i < (int)immMesh->_vCrv.size(); i++)
                            {
                                if (inex < immMesh->_vCrv[i])
                                {
                                    break;
                                }
                                offU += 7;
                            }
                            inex += offU;
                            double elLngth = (immMesh->_uKnot[3+inex+1]-immMesh->_uKnot[3+inex]);

                            jac = (uRng[1]-uRng[0])*elLngth/2.;
                            jac2 = (uRng[1]-uRng[0])/2.;

                            xSamples[0] = a*xSamples[0]+b;

                            vector<vector<double>>& bf = immMesh->_basisFunctions->computeBasisFunctionsReference(xSamples, immMesh->_basisFunctions->getTag(iElem, idxType));

                            rCoords1[0] = 0;
                            rCoords1[1] = 0;
                            vector<double> gCoords(2,0);
                            for (int i = 0; i<4; i++)
                            {
                                int nbor = immMesh->_connec->getNbor(iElem, i);
                                vector<double> nCoords = immMesh->nodeCoords(nbor);
                                rCoords1[0] += bf[0][i]*(2./(cCoords[3][0]-cCoords[0][0])*nCoords[0]+(-cCoords[3][0]-cCoords[0][0])/(cCoords[3][0]-cCoords[0][0]));
                                rCoords1[1] += bf[0][i]*(2./(cCoords[3][1]-cCoords[0][1])*nCoords[1]+(-cCoords[3][1]-cCoords[0][1])/(cCoords[3][1]-cCoords[0][1]));
                            }
                        }

                        // Check if the integration point is in the background element
                        switch (backMesh->_pDim)
                        {
                            case 2:
                                if (rCoords1[0] >= rCorners[0][0] and rCoords1[0] <= rCorners[3][0] and
                                    rCoords1[1] >= rCorners[0][1] and rCoords1[1] <= rCorners[3][1])
                                {                                  
                                    // Save kmap
                                    _meshMaps[cubaId]->_kmap[elem].push_back(iElem);
                                    _meshMaps[cubaId]->_offsetmap[elem].push_back(i);
                                    _meshMaps[cubaId]->_idxCuba[elem].push_back(0);
                                }
                                break;

                            case 3:
                                if (iC[0] >= cCoords[0][0] and iC[0] <= cCoords[7][0] and
                                    iC[1] >= cCoords[0][1] and iC[1] <= cCoords[7][1] and
                                    iC[2] >= cCoords[0][2] and iC[2] <= cCoords[7][2])
                                {
                                    // Avoid the repetition of integration points that are
                                    // on the left/top border of the elements, but keep
                                    // those that are on the left/top of the geometry
                                    // FIXME: This assumes unit square geometry
                                    if (iC[0] == cCoords[7][0] and iC[0] != 1.0)
                                        continue;
                                    if (iC[1] == cCoords[7][1] and iC[1] != 1.0)
                                        continue;
                                    if (iC[2] == cCoords[7][2] and iC[2] != 1.0)
                                        continue;

                                    // Save kmap
                                    _meshMaps[cubaId]->_kmap[elem].push_back(iElem);
                                    _meshMaps[cubaId]->_offsetmap[elem].push_back(i);
                                    _meshMaps[cubaId]->_idxCuba[elem].push_back(0);
                                }
                                break;

                            default:
                                throw runtime_error ("Integration::_genCubaSetBorderImmersed: 1D immersed method not implemented.");
                                break;
                        }
                    }
                }
                else
                {
                    // Get vector of sides for this element
                    vector<int> sides = immMesh->_getMeshBoundariesOfElement(iElem, IndexType::Local, axes);

                    // Loop over integration points
                    vector<double> xSamples(immPDim);
                    int numNbors = immMesh->_connec->getNumNbors(iElem, idxType);
                    int iCuba{0};
                    for (auto s: sides)
                    {
                        for (int i = 0; i < iPts; i++)
                        {
                            // Get parametric coordinates of the integration point
                            for (int p = 0; p < immPDim; p++)
                                xSamples[p] = cubaSide[s-1]->_xSamples[immPDim*i + p];

                            // Compute bf at integration point
                            vector<vector<double>>& bf = immMesh->_basisFunctions->computeBasisFunctionsReference(xSamples, immMesh->_basisFunctions->getTag(iElem, idxType));

                            // Compute coordinates of integration point
                            vector<double> iC(backMesh->nDim());
                            for (int n = 0; n < numNbors; n++)
                            {
                                int nbor = immMesh->_connec->getNbor(iElem, n);
                                for (int d = 0; d < backNDim; d++)
                                    iC[d] += immMesh->nodeCoord(nbor, d)*bf[0][n];
                            }

                            // Invert mapping
                            vector<double> xCoords = {iC[0], iC[1]};
                            vector<double> rCoords1(2);
                            vector<double> rCoords0(2);
                            // double distPt = backMesh->DistributedMesh::_invertElementMapping_LinearSquare(rCoords1, elem, xCoords, rCoords0, IndexType::Local, false);
                            double distPt = backMesh->DistributedMesh::_invertElementMapping_RegSquare(rCoords1, elem, xCoords, IndexType::Local, false);

                            // Check if the integration point is in the background element
                            switch (backMesh->_pDim)
                            {
                                case 2:
                                    if (rCoords1[0] >= rCorners[0][0] and rCoords1[0] <= rCorners[3][0] and
                                        rCoords1[1] >= rCorners[0][1] and rCoords1[1] <= rCorners[3][1])
                                    {
                                        /// Avoid the repetition of integration points that are
                                        // on the border of the element. Store them on a vector 
                                        // to then broadcast between ranks and removes duplicates.
                                        bool borderX = (rCoords1[0] == rCorners[3][0]) or (rCoords1[0] == rCorners[1][0]);
                                        bool borderY = (rCoords1[1] == rCorners[3][1]) or (rCoords1[1] == rCorners[1][1]);
                                        bool dupl = 0;
                                        if (borderX or borderY)
                                        {
                                            for (int jj = 0; jj < size(elemTemp); jj++)
                                            {
                                                if (1e-14 < (iCoordsTemp[2*jj]-xCoords[0])*(iCoordsTemp[2*jj]-xCoords[0])+(iCoordsTemp[2*jj+1]-xCoords[1])*(iCoordsTemp[2*jj+1]-xCoords[1]))
                                                {
                                                    bool dupl = 1;
                                                    break;
                                                }
                                            }
                                            elemTemp.push_back(elem);
                                            iCoordsTemp.push_back(xCoords[0]);
                                            iCoordsTemp.push_back(xCoords[1]);
                                        }
                                        if (!dupl)
                                        {
                                            // Save kmap
                                            _meshMaps[cubaId]->_kmap[elem].push_back(iElem);
                                            _meshMaps[cubaId]->_offsetmap[elem].push_back(i);
                                            _meshMaps[cubaId]->_idxCuba[elem].push_back(iCuba);
                                        }
                                    }
                                    break;

                                case 3:
                                    if (iC[0] >= cCoords[0][0] and iC[0] <= cCoords[7][0] and
                                        iC[1] >= cCoords[0][1] and iC[1] <= cCoords[7][1] and
                                        iC[2] >= cCoords[0][2] and iC[2] <= cCoords[7][2])
                                    {
                                        // Avoid the repetition of integration points that are
                                        // on the left/top border of the elements, but keep
                                        // those that are on the left/top of the geometry
                                        // FIXME: This assumes unit square geometry
                                        if (iC[0] == cCoords[7][0] and iC[0] != 1.0)
                                            continue;
                                        if (iC[1] == cCoords[7][1] and iC[1] != 1.0)
                                            continue;
                                        if (iC[2] == cCoords[7][2] and iC[1] != 2.0)
                                            continue;

                                        // Save kmap
                                        _meshMaps[cubaId]->_kmap[elem].push_back(iElem);
                                        _meshMaps[cubaId]->_offsetmap[elem].push_back(i);
                                        _meshMaps[cubaId]->_idxCuba[elem].push_back(iCuba);
                                    }
                                    break;

                                default:
                                    throw runtime_error ("Integration::_genCubaSetBorderImmersed: 1D immersed method not implemented.");
                                    break;
                            }
                        }
                        iCuba++;
                    }
                }
            }
        }

        // Generate cuba info
        if (immMesh->_meshRel == MeshRelation::ImmersedBoundary)
        {
            // Generate integration
            RCP<CubatureGauss> cuba = rcp(new CubatureGauss);
            cuba->setElemType(_dhands[cubaId]->mesh->elemType());
            cuba->setNumIntPts(_params[0].iPts);
            cuba->Update();
            CubatureInfo cubaInfo = cuba->cubatureInfo();

            //Generate cubaset
            _cubaSets[cubaId] = rcp(new CubatureSet);
            // _cubaSets[cubaId]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);  // This is wrong!!! If nElems of immersed > back then it fails
            _cubaSets[cubaId]->setAdjcyEN(immMesh->_adjcyEN);  // This is wrong!!! If nElems of immersed > back then it fails
            _cubaSets[cubaId]->Update();
            _cubaSets[cubaId]->addCubaInfo(0, cubaInfo);
        }
        else
        {
            // Generate cubature info using the CubatureBorderGauss per side + empty one for elements in the bulk
            vector<CubatureInfo> cubaInfo(nSides+1);
            cubaInfo[0].cubaName = "CubatureBorderGauss";
            for (int s = 0; s < nSides; s++)
            {
                RCP<CubatureBorderGauss> cuba = rcp(new CubatureBorderGauss);
                cuba->setElemType(immElemType);
                cuba->setNumIntPts(iPts);
                cuba->setSide(s);
                cuba->Update();

                cubaInfo[s+1] = cuba->cubatureInfo();
                cubaInfo[s+1].cubaType = s+1;
            }

            // Generate cubaSet
            _cubaSets[cubaId] = rcp(new CubatureSet);
            // _cubaSets[cubaId]->setAdjcyEN(_dhands[0]->mesh->_adjcyEN);
            _cubaSets[cubaId]->setAdjcyEN(immMesh->_adjcyEN);
            _cubaSets[cubaId]->setCubaInfo(cubaInfo);
            _cubaSets[cubaId]->Update();

            // Add cubaInfo to each side
            for (int e = 0; e < immMesh->loc_nElem(); e++)
            {
                // Get vector of sides for this element
                vector<int> sides = immMesh->_getMeshBoundariesOfElement(e, IndexType::Local, axes);

                // Add 0 (empty cubainfo) if there are no sides
                if (sides.empty())
                    sides.push_back(0);

                // Add cubaInfo to cubaSet
                for (auto s: sides)
                    _cubaSets[cubaId]->addCubaInfo(s, cubaInfo[s], {static_cast<size_t>(e)}, IndexType::Local);
            }
        }
    }
    void Integration::_genFacetPairs(int cubaId)
    {
        auto& mesh = _dhands[0]->mesh;
        ElemType eType = mesh->elemType();

        if (eType != ElemType::Square)
            throw runtime_error("Integration::_genFacetPairs: Only Square elements are supported.");

        // Infer Lagrangian order p from the number of nodes of the first local element
        int eNN0 = mesh->_adjcyEN->getNumNbors(0, IndexType::Local);
        int p = static_cast<int>(round(sqrt(static_cast<double>(eNN0)))) - 1;

        // Corner local-node indices for each of the 4 sides of a Q_p square:
        //   Side 0 (v=-1, Ymin): local nodes  0  and  p
        //   Side 1 (u=+1, Xmax): local nodes  p  and  p*(p+2)  [= (p+1)^2 - 1]
        //   Side 2 (v=+1, Ymax): local nodes  p*(p+2)  and  p*(p+1)
        //   Side 3 (u=-1, Xmin): local nodes  p*(p+1) and  0
        vector<array<int,2>> sideCorners = {
            {0,       p         },
            {p,       p*(p+2)   },
            {p*(p+2), p*(p+1)   },
            {p*(p+1), 0         }
        };
        int nSides = 4;

        // Generate per-side BorderGauss CubatureInfo
        _interiorFacetCubaInfo.resize(nSides);
        for (int s = 0; s < nSides; s++)
        {
            RCP<CubatureBorderGauss> cuba = rcp(new CubatureBorderGauss);
            cuba->setElemType(eType);
            cuba->setNumIntPts(_params[cubaId].iPts);
            cuba->setSide(s);
            cuba->Update();
            
            _interiorFacetCubaInfo[s] = cuba->cubatureInfo();
            _interiorFacetCubaInfo[s].cubaType = s+1;
        }

        // Build the CubatureSet: every element gets all 4 sides registered
        // (needed so BasisFunctionsSet can precompute BFs at every side's integration points)
        _cubaSets[0] = rcp(new CubatureSet);
        _cubaSets[0]->setAdjcyEN(mesh->_adjcyEN);
        _cubaSets[0]->setCubaInfo(_interiorFacetCubaInfo);
        _cubaSets[0]->Update();
        for (int e = 0; e < mesh->loc_nElem(); e++)
            for (int s = 0; s < nSides; s++)
                _cubaSets[0]->addCubaInfo(s, _interiorFacetCubaInfo[s], {static_cast<size_t>(e)}, IndexType::Local);

        // Convert user-provided global element pairs to local (elem, side) pairs
        int offs = mesh->offs_nElem();
        for (auto& [gElem1, gElem2] : _params[cubaId].facetElemPairs)
        {
            // Convert to local indices (skip pairs that are not fully local in this partition)
            int e1 = gElem1 - offs;
            int e2 = gElem2 - offs;
            if (e1 < 0 || e1 >= mesh->loc_nElem() || e2 < 0 || e2 >= mesh->loc_nElem())
                continue;

            // Find which sides of e1 and e2 share the same edge (matching corner nodes)
            int side1 = -1, side2 = -1;
            for (int s1 = 0; s1 < nSides && side1 == -1; s1++)
            {
                int gA1 = mesh->_adjcyEN->getNbor(e1, sideCorners[s1][0], IndexType::Global);
                int gB1 = mesh->_adjcyEN->getNbor(e1, sideCorners[s1][1], IndexType::Global);

                for (int s2 = 0; s2 < nSides; s2++)
                {
                    int gA2 = mesh->_adjcyEN->getNbor(e2, sideCorners[s2][0], IndexType::Global);
                    int gB2 = mesh->_adjcyEN->getNbor(e2, sideCorners[s2][1], IndexType::Global);

                    if ((gA1 == gA2 && gB1 == gB2) || (gA1 == gB2 && gB1 == gA2))
                    {
                        side1 = s1;
                        side2 = s2;
                        break;
                    }
                }
            }

            if (side1 == -1)
                throw runtime_error("Integration::_genFacetPairs: Elements "
                    + to_string(gElem1) + " and " + to_string(gElem2)
                    + " do not share a common edge.");

            _facetPairs.push_back({e1, e2, side1, side2});
        }
        _needsTwoSlots = true;
    }

    void Integration::_genGhostPenaltyPairs(int cubaId)
    {
        auto& mesh = _dhands[0]->mesh;
        ElemType eType = mesh->elemType();

        if (eType != ElemType::Square)
            throw runtime_error("Integration::_genGhostPenaltyPairs: Only Square elements are supported.");

        // Store polynomial order for on-the-fly extended BF evaluation
        _ghostPenaltyBFOrder = mesh->_adjcyEN->basisFuncOrder();

        // Build a standard volume Gauss rule and register it for ALL local elements
        RCP<CubatureGauss> cuba = rcp(new CubatureGauss);
        cuba->setElemType(eType);
        cuba->setNumIntPts(_params[cubaId].iPts);
        cuba->Update();
        _ghostPenaltyVolumeCubaInfo = cuba->cubatureInfo();

        _cubaSets[0] = rcp(new CubatureSet);
        _cubaSets[0]->setAdjcyEN(mesh->_adjcyEN);
        _cubaSets[0]->Update();
        // cubaTag 0 → all elements
        _cubaSets[0]->addCubaInfo(0, _ghostPenaltyVolumeCubaInfo, {}, IndexType::Global);

        // Convert user-provided global element pairs to local pairs;
        // skip any pair where either element is not owned by this partition
        int offs = mesh->offs_nElem();
        for (auto& [gElem1, gElem2] : _params[cubaId].facetElemPairs)
        {
            int e1 = gElem1 - offs;
            int e2 = gElem2 - offs;
            if (e1 < 0 || e1 >= mesh->loc_nElem() || e2 < 0 || e2 >= mesh->loc_nElem())
                continue;
            _ghostPenaltyPairs.push_back({e1, e2});
        }
        _needsTwoSlots = true;
    }

} // namespace hiperlife
