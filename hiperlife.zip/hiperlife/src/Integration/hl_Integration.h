/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#ifndef HPLFE_INTEGRATION_H
#define HPLFE_INTEGRATION_H

#include "hl_TypeDefs.h"
#include "hl_DistributedClass.h"
#include "hl_DOFsHandler.h"
#include "hl_CubatureSet.h"
#include "hl_BasisFunctionsSet.h"
#include "hl_FillStructure.h"
#include "hl_FillType.h"
#include "hl_WeightedAdjcyStruct.h"
#include "hl_HiperIndexConverter.h"
#include "hl_Geometry.h"

namespace hiperlife
{

    enum class fillType {trilCreat, trilFill};

    /*! \brief Pair of local element indices for ghost-penalty patch integration (one per shared facet). */
    struct GhostPenaltyPair
    {
        int elem1;  ///< local element index (K+)
        int elem2;  ///< local element index (K-)
    };

    /*! \brief Pair of local element indices sharing an interior facet, with the local side index on each. */
    struct InteriorFacetPair
    {
        int elem1;  ///< local element index
        int elem2;  ///< local element index
        int side1;  ///< side of elem1 facing the shared facet (0–3 for Square)
        int side2;  ///< side of elem2 facing the shared facet (0–3 for Square)
    };

    struct cubaParams
    {
        CubaType type;

        int iPts{};
        int iPts2{};
        int nSubdiv{};
        int regionTag{};

        std::set<MAxis> axes{};
        std::set<BorderIntersections> _BorderIntersections{};
        std::set<size_t> elems{};
        std::set<size_t> intElems{};
        std::set<size_t> cutElems{};
        std::vector<int> elemIDs;
        std::vector<double> rCoords;
        std::vector<double> weights;

        /*! \brief For CubaType::InteriorFacet: pairs of global element IDs (elem+, elem-). */
        std::vector<std::pair<int,int>> facetElemPairs;

        IndexType idxType{IndexType::Global};
    };

    /*!
     * \brief Class that controls the integration of equations over one mesh.
    */
    class Integration : public DistributedClass
    {
        public:
            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            Integration(std::string tag ="Integration", MPI_Comm comm = MPI_COMM_WORLD) : DistributedClass(tag, comm) {}
            Integration(Integration&& other) = default;
            Integration(const Integration& other) = delete;
            ~Integration() = default;

            Integration& operator=(const Integration& other) = delete;
            Integration& operator=(Integration&& other) = default;
            /** @} */ // end of constructors


            std::vector<Teuchos::RCP<DOFsHandler>>  _dhands;
            std::vector<Teuchos::RCP<CubatureSet>> _cubaSets;
            std::vector<Teuchos::RCP<BasisFunctionsSet>> _BFSets;

            Teuchos::RCP<FillStructure> _fillStr;
            std::vector<Teuchos::RCP<MeshMap>> _meshMaps;
            std::map<std::string, int> _dhandsTagIdx;


            Teuchos::RCP<std::vector<Teuchos::RCP<DOFsHandler>>>  _dhandsFullList; // full list of DOFsHandlers from HiperProblem. This is needed because, apart from integration, sometimes we need to read information from other DOFsHandler outside this integration when imposing constraints

            int numDOFsHands() { return static_cast<int>(_dhandsTagIdx.size());}


//            std::vector<CubaType> _cubaTypes;
//            std::vector<int> _cubaPts;
//            std::vector<std::set<int>> _cubaElems;

            std::vector<cubaParams> _params{};

            std::vector<int> _consDOFsHandlers;
            std::vector<std::vector<int>> _consDOFs;
            ConsistencyCheckType _consCheckType = ConsistencyCheckType::Undefined;
            int _consCheckGlobInteg{-1};
            double _consCheckTol{};
            double _consCheckDelta{};

            /*! \brief Sets the function to be used to fill the Linear System by element.*/
            void (* LinSystemByElement)(FillStructure&) = nullptr;
            /*! \brief Sets the function to be used to fill the Stiffness Matrix by element.*/
            void (* StiffnessMatrixByElement)(FillStructure&) = nullptr;
            /*! \brief Sets the function to be used to fill the Right Hand Side by element.*/
            void (* RightHandSideByElement)(FillStructure&) = nullptr;

            /*! \brief Sets the UserStructure that introduces the user's parameters in the library. */
            void setParamStruct(SmartPtr<ParamStructure> parStr)   {  paramStr = parStr;}

            /*! \brief Sets or adds parameters of one cubature. */
            void setCubatureParameters(size_t cubaId, cubaParams& params);

            /*! \brief Get number of cubatures*/
            inline size_t numCubas() { return _params.size(); }

            void Update();

            Teuchos::RCP<ParamStructure> paramStr = Teuchos::null;

            template <FillType F> void _loadData_and_FillGlobLinSys(Teuchos::RCP<Epetra_FECrsMatrix> A,
                                              Teuchos::RCP<Epetra_FEVector> rhs, int kPt, int e, IndexType idxtype);
//            void _createStiffMatStruct(Teuchos::RCP<Epetra_FECrsMatrix> A);


            template <FillType F> void _partialFillLinearSystem(Teuchos::RCP<Epetra_FECrsMatrix> A,
                                          Teuchos::RCP<Epetra_FEVector> rhs,
                                          int idxDHandR, int idxDHandC,
                                          int elemR, int elemC,
                                          IndexType type);

            Teuchos::RCP<WeightedAdjcyStruct> _LCWgraph = Teuchos::null;
            std::vector<double> _LCvalues;

//            void _partialCreateStiffMatrix(Teuchos::RCP<Epetra_FECrsMatrix> A, int idxDHandR, int idxDHandC,
//                                           int elemR, int elemC, IndexType type);


            /*! \brief Method that fills the global Linear System.*/
            template <FillType F> void _fillLinearSystem(Teuchos::RCP<Epetra_FECrsMatrix> A, Teuchos::RCP<Epetra_FEVector> rhs);
            /*! \brief Method that fills the global Stiffness Matrix.*/
            void _fillStiffMatrix(Teuchos::RCP<Epetra_FECrsMatrix> A);
            /*! \brief Method that fills the global Right Hand Side.*/
            void _fillRHS(Teuchos::RCP<Epetra_FEVector> rhs);


            Teuchos::RCP<HiperIndexConverter> hiperIndexConverter;

            /*! \brief List of interior facet pairs built by _genFacetPairs(). */
            std::vector<InteriorFacetPair> _facetPairs;
            /*! \brief Per-side CubatureInfo used for interior facet integration (indexed by side id). */
            std::vector<CubatureInfo> _interiorFacetCubaInfo;

            /*! \brief Fills the global Linear System looping over interior facet pairs. */
            template <FillType F> void _fillLinearSystem_InteriorFacet(
                Teuchos::RCP<Epetra_FECrsMatrix> A, Teuchos::RCP<Epetra_FEVector> rhs);

            /*! \brief Element pairs for ghost-penalty patch integration. */
            std::vector<GhostPenaltyPair> _ghostPenaltyPairs;
            /*! \brief Volume Gauss CubatureInfo shared by all elements in ghost-penalty integration. */
            CubatureInfo _ghostPenaltyVolumeCubaInfo;
            /*! \brief Lagrangian polynomial order used for extended BF evaluation. */
            int _ghostPenaltyBFOrder{1};

            /*! \brief Fills the global Linear System looping over ghost-penalty element pairs. */
            template <FillType F> void _fillLinearSystem_GhostPenalty(
                Teuchos::RCP<Epetra_FECrsMatrix> A, Teuchos::RCP<Epetra_FEVector> rhs);

            /*! \brief True when InteriorFacet or GhostPenalty integration is active with a single
             *  registered DOFsHandler.  Set by _genFacetPairs / _genGhostPenaltyPairs; causes
             *  Integration::Update() to synthesize a second "guest" slot in _fillStr so that
             *  fillStr[1] works in the user's filling function. */
            bool _needsTwoSlots{false};

        private:
            void _genCubaSetGauss(int cubaId);
            void _genCubaSetBorderGauss(int cubaId);
            void _genCubaSetBorderIntersection(int cubaId);
            void _genCubaSetIrregularSubdiv(int cubaId);
            void _genCubaSetCutCell(int cubaId);
            void _genCubaSetBorderImmersed(int cubaId);
            void _genCubaSetUserDefined(int cubaId);
            void _genCubaSetLagrMultiplMacroElems(int numDHand, CubatureSet* cubaSetMast);
            void _genCubaSetImmersed(int cubaId);
            void _genFacetPairs(int cubaId);
            void _genGhostPenaltyPairs(int cubaId);
    };

} // namespace hiperlife

#include "hl_Integration-impl.h"



#endif //HPLFE_INTEGRATION_H
