/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <vector>
#include <algorithm>
#include <Teuchos_RCP.hpp>

#include "hl_FillStructure.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void FillStructure::Update()
    {

        _B_k.resize(numDOFsHands());
        _A_k.resize(numDOFsHands() * numDOFsHands());
        _B_e.resize(numDOFsHands());
        _A_e.resize(numDOFsHands() * numDOFsHands());

        _globInteg.resize(_globIntegTagIdx.size());

        for (auto i = 0; i < numDOFsHands(); i++)
        {
            int i_numDOFs = _subFills[i]->dhandDHand->numDOFs();
            int i_maxNbors = _subFills[i]->maxNbors;

            _B_k[i].reserve(i_numDOFs * i_maxNbors);
            _B_e[i].reserve(i_numDOFs * i_maxNbors);
            for (int j = 0; j < numDOFsHands(); j++)
            {
                int j_numDOFs = _subFills[j]->dhandDHand->numDOFs();
                int j_maxNbors = _subFills[j]->maxNbors;

                Ak(i, j).reserve(static_cast<unsigned int>(i_numDOFs * i_maxNbors * j_numDOFs * j_maxNbors));
                _Ae(i, j).reserve(static_cast<unsigned int>(i_numDOFs * i_maxNbors * j_numDOFs * j_maxNbors));
            }

        }


        dhandChangeElem.resize(numDOFsHands());
//        vec_e.reserve(maxNbors * DOF);
//        Aaux_e.reserve(maxNbors * DOF);
//        Baux_e.reserve(maxNbors * DOF);

    }


    void FillStructure::init_elem(RCP<SubFillStructure> subFill)
    {
        //Initialize
        int nDim = subFill->nDim;
        int numDOFs = subFill->numDOFs;
        int numAuxF = subFill->numAuxF;
        int eNN = subFill->dhandDHand->mesh->_adjcyEN->getNumNbors(subFill->loc_elemID, IndexType::Local);
        vector<int> nbors = subFill->dhandDHand->mesh->_adjcyEN->getNborList(subFill->loc_elemID, IndexType::Local);

        //Store eNN in subFill
        subFill->eNN = eNN;

        // //Store kInfSize in subFill  //FIXME:: Not used!
        // subFill->kInfSize = subFill->dhandBFSet->intPtSize(subFill->loc_elemID, subFill->idxCuba, IndexType::Local);

        //Store cubaInfo in subFill
        subFill->cubaInfo = subFill->dhandCubas->cubaInfo(subFill->loc_elemID, IndexType::Local)[subFill->idxCuba];

        //Store node coordinates, DOFs and AuxF in subFill
        subFill->resizeVectors(eNN);
        for (int i = 0; i < eNN; i++)
        {
            //Node coordinates
            int iD = i * nDim;
            for (auto j = 0; j < nDim; j++)
                subFill->nborCoords[iD+j] = subFill->dhandDHand->mesh->nodeCoord(nbors[i], j);

            //Node DOFs and DOFs0
            iD = i * numDOFs;
            if (subFill->passSol0)
            {
                for (auto j = 0; j < numDOFs; j++)
                    subFill->nborDOFs0[iD+j] = subFill->dhandDHand->nodeDOFs0->getValue(j, nbors[i]);
            }
            if (subFill->passSol)
            {
                for (auto j = 0; j < numDOFs; j++)
                    subFill->nborDOFs[iD+j] = subFill->dhandDHand->nodeDOFs->getValue(j, nbors[i]);
            }

            //Node AuxF
            if (subFill->passAuxF)
            {
                int iA = i * numAuxF;
                for (auto j = 0; j < numAuxF; j++)
                    subFill->nborAuxF[iA+j] = subFill->dhandDHand->nodeAuxF->getValue(j, nbors[i]);
            }
        }
    }

    void FillStructure::init_k(RCP<SubFillStructure> subFill, int mastGloElem, int kPt)
    {
        int idxCuba = subFill->idxCuba;

        //Store kPt in subFill
        if (subFill->mapMasterToMe->nameTag() == "MeshMap_Trivial")
        {
            subFill->kPt = kPt;
        }
        else if (subFill->mapMasterToMe->nameTag() == "MeshMap_Macro")
        {
            auto fineElems = subFill->mapMasterToMe->inverseMap(subFill->loc_elemID, IndexType::Local);

            int N = static_cast<int>(fineElems.size());
            int n = static_cast<int>(std::find(fineElems.begin(), fineElems.end(), mastGloElem) - fineElems.begin());

            #ifdef DEBUG
            if (n == N)
                throw runtime_error("FillStructure::init_k: There is a problem in the MacroElem map at masterElem:" + to_string(mastGloElem) + ".");
            #endif
            //int mastIntPts = subFill->dhandCubas->cubaInfo(0).iPts / N;

            subFill->kPt = subFill->cubaInfo.macroOffsets[n] + kPt;
        }
        else if (subFill->mapMasterToMe->nameTag() == "MeshMap_Immersed")
        {
            //FIXME:: kPt and the resulting subFill->kPt with the offset seem to be the same
            //        subFill->kPt = kPt
            //        Why is it necessary?
            int loc_mastGloElem = mastGloElem - subFill->dhandDHand->mesh->_parentMesh->offs_nElem();
            subFill->kPt = subFill->mapMasterToMe->_offsetmap[loc_mastGloElem][kPt];

            subFill->idxCuba = subFill->mapMasterToMe->_idxCuba[loc_mastGloElem][kPt];
            subFill->cubaInfo = subFill->dhandCubas->cubaInfo(subFill->loc_elemID, IndexType::Local)[subFill->idxCuba];
        }
        else
        {
            throw runtime_error("FillStructure::init_k: The map from the master is unknown");
        }

        //Store integration weights and points in subFill
        subFill->wk_sample = subFill->cubaInfo.wSamples[subFill->kPt];
        double *p = &subFill->cubaInfo.xSamples[subFill->kPt*subFill->pDim];
        subFill->x_sample = vector<double>(p, p + subFill->pDim);

        //Store basis functions of this kPt in subFill
        subFill->bfs = subFill->dhandBFSet->basisFunctionRef(subFill->loc_elemID, subFill->idxCuba, IndexType::Local, subFill->kPt);
        subFill->idxCuba = idxCuba;
    }

    void FillStructure::init_fill()
    {
        //Initialize global integrals
        _globInteg.resize(_globIntegTagIdx.size());
        fill(_globInteg.begin(), _globInteg.end(), 0.0);

        // Clear contribution per element of the global integrals
        if (_savePerElems)
        {
            auto& masterSubFill = this->operator[](0);
            for (size_t i = 0; i < _globInteg.size(); i++)
                masterSubFill.dhandDHand->elemAuxF->setValue(_globIntegToElemAux[i], 0.0);
        }

        //Restart element numbers
        for (int R = 0; R < numDOFsHands(); R++)
        {
            _subFills[R]->elemID = -1;
            _subFills[R]->loc_elemID = -1;
        }
    }


    void FillStructure::addToGlobalIntegral(int idx, double contr)
    {
        //Initialize
        double wk = _subFills[0]->wk_sample;

        //Get jacobian of the transformation (parent element to parameter space) in BSplines and Nurbs
        double jac = _subFills[0]->_jacobianParentElementToParameterSpace(_subFills[0]->loc_elemID);

        //Save global integral contribution
        _globInteg[idx] += jac * wk * contr;

        //Save contribution per element
        if (_savePerElems)
        {
            auto& masterSubFill = this->operator[](0);
            int locElem = masterSubFill.loc_elemID;
            int elemAuxIdx = _globIntegToElemAux[idx];
            masterSubFill.dhandDHand->elemAuxF->addValue(elemAuxIdx, locElem, IndexType::Local, jac * wk * contr);
        }
    }

}
