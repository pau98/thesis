/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include "hl_FillType.h"


using namespace std;


namespace hiperlife
{

    std::ostream &operator<<(std::ostream &os, const FillType &ft)
    {
        if (ft == FillType::TrilCreat)
            os << "TrilCreat";
        else if (ft == FillType::TrilFill)
            os << "TrilFill";
        else if (ft == FillType::PetscCreat)
            os << "PetscCreat";
        else if (ft == FillType::PetscFill)
            os << "PetscFill";
        else
            os << "Unknown FillType";

        return os;
    }

}
