/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef FILLSTRUCTURE_H
#define FILLSTRUCTURE_H


#include <vector>

#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_ParamStructure.h"
#include "hl_DistributedMesh.h"
#include "hl_CubatureSet.h"
#include "hl_BasisFunctionsSet.h"
#include "hl_SubFillStructure.h"


namespace hiperlife
{
    /*!
     * \class FillStructure
     * \brief Class that handles the main interactions with the integration functions.
     *
     * It controls the input information and stores the output data
     *
    */
    class FillStructure
    {
        public:
            /** @name Constructor / Destructor / Operator
             * Copy constructors are deleted for memory safety but objects can be
             * created from temporal objects through move constructors
             *  @{ */
            FillStructure() = default;
            FillStructure(FillStructure&& other) = default;
            FillStructure(const FillStructure& other) = delete;
            ~FillStructure() = default;
            // Operators
            FillStructure& operator=(const FillStructure& other) = delete;
            FillStructure& operator=(FillStructure&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             *  @{ */
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update();
            /** @} */ // end of object creation


            /** @name Information access methods
            *  @{ */
            inline int numDOFsHands(){return static_cast<int>(_dhandsTagIdx.size());}
            inline std::vector<double>& _Ae(int i, int j){return _A_e[j*numDOFsHands()+i];}
            inline std::vector<double>&  Ak(int i, int j){return _A_k[j*numDOFsHands()+i];}
            inline std::vector<double>& _Be(int i){return _B_e[i];}
            inline std::vector<double>&  Bk(int i){return _B_k[i];}
            inline bool RC_hasChangeElem(bool row, bool column) const {return row or column;}
            inline bool RC_hasChangeElem(int row, int column) const
            {
                return RC_hasChangeElem(dhandChangeElem[row], dhandChangeElem[column]);
            }
            inline bool RC_hasChangeElem(int dhand) const{return dhandChangeElem[dhand];}
            SubFillStructure& operator[](std::size_t idx){return *_subFills[idx];}
            SubFillStructure& operator[](std::string tag){return *_subFills[_dhandsTagIdx.at(tag)];}
            /** @} */ // end of information access methods


            /** @name Global integrals
            *  @{ */
            void addToGlobalIntegral(int idx, double contr);
            void addToGlobalIntegral(std::string tag, double contr){addToGlobalIntegral(_globIntegTagIdx.at(tag), contr);};
            [[deprecated("This function is deprecated and will be removed in the next release. Please use addToGlobalIntegral(same arguments) instead.")]]
            void addContribGlobInteg(std::string tag, double contr){addToGlobalIntegral(tag, contr);};
            /** @} */ // end of Global integrals


            /** @name Expert users and developers only functions
            *  @{ */
            void init_fill();
            void init_k(Teuchos::RCP<SubFillStructure> subFill, int mastGloElem, int kPt);
            void init_elem(Teuchos::RCP<SubFillStructure> subFill);
            /** @} */ // end of Expert users and developers only functions

            template<typename T> inline T getParameter(int i) {
                if constexpr (std::is_same<T, double>::value)
                    return paramStr->getParameter<double>(i);
                else if constexpr (std::is_same<T, int>::value)
                    return paramStr->getParameter<int>(i);
                else if constexpr (std::is_same<T, std::string>::value)
                    return paramStr->getParameter<std::string>(i);
                else if constexpr (std::is_same<T, bool>::value)
                    return paramStr->getBoolParameter(i);
                else
                    throw std::runtime_error("Error! Parameter type not valid.");
            }

            inline double getRealParameter(int i)
            {
                return getParameter<double>(i);
            }

            inline int getIntParameter(int i)
            {
                return getParameter<int>(i);
            }

            inline std::string getStringParameter(int i)
            {
                return getParameter<std::string>(i);
            }

            inline bool getBoolParameter(int i)
            {
                return getParameter<bool>(i);
            }

            /** @name Expert users and developers only variables
            *  @{ */
            /*! \brief structure provided by the USER that passes information related with a specific problem.*/
            Teuchos::RCP<ParamStructure> paramStr;
            /*! \brief Vector that stores the integrals over the whole elements.*/
            std::vector<double> _globInteg;
            /*! \brief Tag that controls if the global integrals are saved for each element.*/
            bool _savePerElems;
            /*! \brief Contribution of elementary matrix from the integration point, size:(eNN x DOF)^2.*/
            std::vector<std::vector<double>> _A_k;
            /*! \brief Contribution to the elementary right hand side computed at this integration point filled at a given element, size eNN x DOF.*/
            std::vector<std::vector<double>> _B_k;
            /*! \brief smat: Elementary matrix, computed internally from the contributions of all integration points, size: (eNN x DOF)^2.*/
            std::vector<std::vector<double>> _A_e;
            /*! \brief Elementary right hand side, computed internally from the contributions of all integration points, size eNN x DOF.*/
            std::vector<std::vector<double>> _B_e;
            std::vector<bool> dhandChangeElem;
            std::vector<Teuchos::RCP<SubFillStructure>> _subFills;
            std::map<std::string, int> _dhandsTagIdx;
            std::map<std::string, int> _globIntegTagIdx;
            std::vector<int> _globIntegToElemAux;

            std::vector<int> _consDOFsHandlers;
            std::vector<std::vector<int>> _consDOFs;
            ConsistencyCheckType _consCheckType = ConsistencyCheckType::Undefined;
            int _consCheckGlobInteg{-1};
            double _consCheckTol{};
            double _consCheckDelta{};
            /** @} */ // end of Expert users and developers only variables
    };
}

#endif //FILLSTRUCTURE_H
