/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HPLFE_INTEGRATION_IMPL_H
#define HPLFE_INTEGRATION_IMPL_H

#include <cmath>

#include "hl_TypeDefs.h"
#include "hl_DistributedClass.h"
#include <hl_DOFsHandler.h>
#include "hl_CubatureSet.h"
#include "hl_BasisFunctionsSet.h"
#include "hl_FillStructure.h"
#include "hl_FillType.h"
#include "hl_FillType-impl.h"

// ── Ghost-penalty helpers (anonymous namespace — one copy per TU) ────────────
namespace {

// 1-D Lagrangian polynomial at x for node a of a (p+1)-node uniform rule on [-1,1].
inline double _gp_lagr1D(double x, int a, int p)
{
    int nen = p + 1;
    double xa = (p == 0) ? 0.0 : -1.0 + 2.0 * a / p;
    double val = 1.0;
    for (int b = 0; b < nen; b++)
    {
        if (b == a) continue;
        double xb = (p == 0) ? 0.0 : -1.0 + 2.0 * b / p;
        val *= (x - xb) / (xa - xb);
    }
    return val;
}

// Derivative of the 1-D Lagrangian at x for node a.
inline double _gp_dlagr1D(double x, int a, int p)
{
    int nen = p + 1;
    double xa = (p == 0) ? 0.0 : -1.0 + 2.0 * a / p;
    double dval = 0.0;
    for (int c = 0; c < nen; c++)
    {
        if (c == a) continue;
        double xc = (p == 0) ? 0.0 : -1.0 + 2.0 * c / p;
        double term = 1.0 / (xa - xc);
        for (int b = 0; b < nen; b++)
        {
            if (b == a || b == c) continue;
            double xb = (p == 0) ? 0.0 : -1.0 + 2.0 * b / p;
            term *= (x - xb) / (xa - xb);
        }
        dval += term;
    }
    return dval;
}

// Evaluate all Q_p Square basis functions and their reference-space gradients
// at the reference point (xi, eta).
//
// buf layout: [eNN values]  [eNN*2 gradient values, interleaved as ∂/∂ξ, ∂/∂η per node]
// Caller must allocate buf with size eNN*(1+2).
inline void _gp_evalSquareBFs(double xi, double eta, int p, int eNN, double* buf)
{
    int nen = p + 1;
    for (int j = 0; j < nen; j++)         // η direction
    {
        double Lj  = _gp_lagr1D (eta, j, p);
        double dLj = _gp_dlagr1D(eta, j, p);
        for (int i = 0; i < nen; i++)     // ξ direction
        {
            int node = j * nen + i;
            double Li  = _gp_lagr1D (xi, i, p);
            double dLi = _gp_dlagr1D(xi, i, p);
            buf[node]               = Li  * Lj;   // φ value
            buf[eNN + node * 2 + 0] = dLi * Lj;  // ∂φ/∂ξ
            buf[eNN + node * 2 + 1] = Li  * dLj;  // ∂φ/∂η
        }
    }
}

// Newton iteration: find reference coords (xiGuest[2]) of a point given in
// physical space (physCoords[2]) inside a 2-D Q_p Square element whose node
// physical coordinates are guestCoords[eNN*2].
// The iteration is initialised at the element centre (0,0) and typically
// converges in one step for bilinear elements and a few steps for higher order.
inline void _gp_inverseMapSquare(const double* physCoords,
                                 const double* guestCoords,
                                 int p, int eNN,
                                 double* xiGuest)
{
    xiGuest[0] = 0.0;
    xiGuest[1] = 0.0;

    std::vector<double> tmp(eNN * 3);  // values + 2-D gradients

    for (int iter = 0; iter < 25; iter++)
    {
        _gp_evalSquareBFs(xiGuest[0], xiGuest[1], p, eNN, tmp.data());
        double F0 = -physCoords[0], F1 = -physCoords[1];
        double J00 = 0.0, J01 = 0.0, J10 = 0.0, J11 = 0.0;
        for (int i = 0; i < eNN; i++)
        {
            double phi    = tmp[i];
            double dphi_u = tmp[eNN + i * 2 + 0];
            double dphi_v = tmp[eNN + i * 2 + 1];
            F0  += guestCoords[i * 2 + 0] * phi;
            F1  += guestCoords[i * 2 + 1] * phi;
            J00 += guestCoords[i * 2 + 0] * dphi_u;
            J01 += guestCoords[i * 2 + 0] * dphi_v;
            J10 += guestCoords[i * 2 + 1] * dphi_u;
            J11 += guestCoords[i * 2 + 1] * dphi_v;
        }
        if (F0 * F0 + F1 * F1 < 1e-24) break;

        double det = J00 * J11 - J01 * J10;
        xiGuest[0] -= ( J11 * F0 - J01 * F1) / det;
        xiGuest[1] -= (-J10 * F0 + J00 * F1) / det;
    }
}

} // anonymous namespace
// ─────────────────────────────────────────────────────────────────────────────

namespace hiperlife
{

    template <FillType F>
    void Integration::_partialFillLinearSystem(Teuchos::RCP<Epetra_FECrsMatrix> A, Teuchos::RCP<Epetra_FEVector> rhs,
                                               int idxDHandR, int idxDHandC, int elemR, int elemC, IndexType type)
    {
        auto& dhandR = *_dhands[idxDHandR];
        auto& dhandC = *_dhands[idxDHandC];

        auto KRC = _fillStr->_Ae(idxDHandR, idxDHandC);

        int nborsR = dhandR.mesh->_adjcyEN->getNumNbors(elemR, type);
        int nborsC = dhandC.mesh->_adjcyEN->getNumNbors(elemC, type);

        int ndofsR = dhandR.numDOFs();
        int ndofsC = dhandC.numDOFs();

        bool fillRhs = rhs != Teuchos::null;
        bool fillA   = A != Teuchos::null;


        for (int i = 0; i < nborsR; i++)
        {
            int ii = dhandR.mesh->_adjcyEN->getNbor(elemR, i, IndexType::Local);

            for (int dI = 0; dI <  ndofsR; dI++)
            {
                int  iD = i * ndofsR + dI;
                int hiD = dhandR.hiperIdx(dI, ii, IndexType::Global);

                bool constrR = dhandR.constrFlag(dI, ii, IndexType::Global);

                int nlcR = _LCWgraph->getNumNbors(hiD, IndexType::Global);

                if (constrR == false and nlcR == 0)
                {
                    for (int j = 0; j < nborsC; j++)
                    {
                        int jj = dhandC.mesh->_adjcyEN->getNbor(elemC, j, IndexType::Local);

                        for (int dJ = 0; dJ < ndofsC; dJ++)
                        {
                            int jD  = j * ndofsC + dJ;
                            int hjD = dhandC.hiperIdx(dJ, jj, IndexType::Global);

                            bool constrC = dhandC.constrFlag(dJ, jj, IndexType::Global);
                            int nlcC = _LCWgraph->getNumNbors(hjD, IndexType::Global);

                            if (constrC)
                            {
                                if (fillRhs)
                                {
                                    double valConstr = dhandC.constrValue(dJ, jj, IndexType::Global);
                                    double value = -valConstr * KRC[iD * nborsC * ndofsC + jD];

                                    rhs->SumIntoGlobalValues(1, &hiD, &value);
                                }
                            }
                            else if (nlcC > 0)
                            {

                                for ( int nbC = 0; nbC < nlcC; nbC++ )
                                {
                                    const int    hjD_mast = _LCWgraph->getNbor(hjD, nbC, IndexType::Global);
                                    const double hjD_weig = _LCWgraph->getWeight(hjD, nbC, IndexType::Global);


                                    auto chIdxM = hiperIndexConverter->getCompHiPerIndex(hjD_mast);
                                    bool constrM = (*_dhandsFullList)[chIdxM.dhand]->constrFlag(chIdxM.idof, chIdxM.index, IndexType::Global);
                                    if ( constrM == false )
                                    {
                                        if (fillA)
                                        {
                                            matrixFill<F>(A, hiD, hjD_mast, KRC[iD * nborsC * ndofsC + jD] * hjD_weig);
                                        }
                                    }
                                    else
                                    {
                                        if (fillRhs)
                                        {
                                            double valConstr = (*_dhandsFullList)[chIdxM.dhand]->constrValue(chIdxM.idof, chIdxM.index, IndexType::Global);
                                            double value = -valConstr * KRC[iD * nborsC * ndofsC + jD] * hjD_weig;
                                            rhs->SumIntoGlobalValues(1, &hiD, &value);
                                        }
                                    }

                                }

                            }
                            else if(fillA)
                            {
                                matrixFill<F>(A, hiD, hjD, KRC[iD * nborsC * ndofsC + jD]);
                            }
                        }
                    }

                    if (idxDHandR == idxDHandC and fillRhs) // FIXME: Please, optimize me!
                    {
                        double value = _fillStr->_B_e[idxDHandR][iD];
                        rhs->SumIntoGlobalValues(1, &hiD, &value);
                    }
                }
                else if ( constrR == false and nlcR > 0 )
                {

                    for ( int nbR = 0; nbR < nlcR; nbR++ )
                    {
                        const int    hiD_mast = _LCWgraph->getNbor(hiD, nbR, IndexType::Global);
                        const double hiD_weig = _LCWgraph->getWeight(hiD, nbR, IndexType::Global);

                        auto chIdxMiD = hiperIndexConverter->getCompHiPerIndex(hiD_mast);
                        bool constrMiD = (*_dhandsFullList)[chIdxMiD.dhand]->constrFlag(chIdxMiD.idof, chIdxMiD.index, IndexType::Global);

                        if ( constrMiD == false )
                        {
                            for (int j = 0; j < nborsC; j++)
                            {
                                const int jj = dhandC.mesh->_adjcyEN->getNbor(elemC, j, IndexType::Local);

                                for (int dJ = 0; dJ < ndofsC; dJ++)
                                {
                                    const int jD = j * ndofsC + dJ;
                                    const int hjD = dhandC.hiperIdx(dJ, jj, IndexType::Global);

                                    bool constrC = dhandC.constrFlag(dJ, jj, IndexType::Global);
                                    int nlcC = _LCWgraph->getNumNbors(hjD, IndexType::Global);

                                    if (constrC)
                                    {
                                        if (fillRhs)
                                        {
                                            const double valConstr = dhandC.constrValue(dJ, jj, IndexType::Global);
                                            const double value = -valConstr * KRC[iD * nborsC * ndofsC + jD] * hiD_weig;

                                            rhs->SumIntoGlobalValues(1, &hiD_mast, &value);
                                        }
                                    }
                                    else if (nlcC>0)
                                    {
                                        for ( int nbC = 0; nbC < nlcC; nbC++ )
                                        {
                                            const int    hjD_mast = _LCWgraph->getNbor(hjD, nbC, IndexType::Global);
                                            const double hjD_weig = _LCWgraph->getWeight(hjD, nbC, IndexType::Global);


                                            auto chIdxMjD = hiperIndexConverter->getCompHiPerIndex(hjD_mast);
                                            bool constrMjD = (*_dhandsFullList)[chIdxMjD.dhand]->constrFlag(chIdxMjD.idof, chIdxMjD.index, IndexType::Global);
                                            if ( constrMjD == false )
                                            {
                                                if (fillA)
                                                {
                                                    matrixFill<F>(A, hiD_mast, hjD_mast, KRC[iD * nborsC * ndofsC + jD] * hiD_weig * hjD_weig);
                                                }
                                            }
                                            else
                                            {
                                                if (fillRhs)
                                                {
                                                    double valConstr = (*_dhandsFullList)[chIdxMjD.dhand]->constrValue(chIdxMjD.idof, chIdxMjD.index, IndexType::Global);
                                                    double value = -valConstr * KRC[iD * nborsC * ndofsC + jD] * hiD_weig * hjD_weig;
                                                    rhs->SumIntoGlobalValues(1, &hiD_mast, &value);
                                                }
                                            }
                                        }
                                    }
                                    else if (fillA)
                                    {
                                        matrixFill<F>(A, hiD_mast, hjD, KRC[iD * nborsC * ndofsC + jD] * hiD_weig );
                                    }
                                }

                            }

                            if (idxDHandR == idxDHandC and fillRhs) // FIXME: Please, optimize me!
                            {
                                const double value = _fillStr->_B_e[idxDHandR][iD] * hiD_weig;
                                rhs->SumIntoGlobalValues(1, &hiD_mast, &value);
                            }

                        }

                    }

                }


            }

        }

    }

    template <FillType F>
    void Integration::_fillLinearSystem_InteriorFacet(Teuchos::RCP<Epetra_FECrsMatrix> A,
                                                      Teuchos::RCP<Epetra_FEVector> rhs)
    {
        _fillStr->init_fill();

        int offs = _dhands[0]->mesh->offs_nElem();

        for (auto& fp : _facetPairs)
        {
            // --- Initialize elem1 (slot 0) ---
            auto& sf0 = *_fillStr->_subFills[0];
            sf0.elemID     = fp.elem1 + offs;
            sf0.loc_elemID = fp.elem1;
            sf0.idxCuba    = fp.side1;
            _fillStr->init_elem(_fillStr->_subFills[0]);

            // --- Initialize elem2 (slot 1) ---
            auto& sf1 = *_fillStr->_subFills[1];
            sf1.elemID     = fp.elem2 + offs;
            sf1.loc_elemID = fp.elem2;
            sf1.idxCuba    = fp.side2;
            _fillStr->init_elem(_fillStr->_subFills[1]);

            // --- Resize and zero elemental buffers ---
            for (int R = 0; R < 2; R++)
            {
                int szR = _fillStr->_subFills[R]->eNN * _fillStr->_subFills[R]->numDOFs;
                _fillStr->_B_k[R].assign(static_cast<size_t>(szR), 0.0);
                _fillStr->_B_e[R].assign(static_cast<size_t>(szR), 0.0);
                for (int C = 0; C < 2; C++)
                {
                    int szC = _fillStr->_subFills[C]->eNN * _fillStr->_subFills[C]->numDOFs;
                    _fillStr->Ak(R, C).assign(static_cast<size_t>(szR * szC), 0.0);
                    _fillStr->_Ae(R, C).assign(static_cast<size_t>(szR * szC), 0.0);
                }
            }

            int iPts = _interiorFacetCubaInfo[fp.side1].iPts;
            double jac0 = sf0._jacobianParentElementToParameterSpace(fp.elem1);

            // --- Integration point loop ---
            for (int k = 0; k < iPts; k++)
            {
                _fillStr->init_k(_fillStr->_subFills[0], sf0.elemID, k);
                _fillStr->init_k(_fillStr->_subFills[1], sf1.elemID, k);

                // Zero k-level buffers
                for (int R = 0; R < 2; R++)
                {
                    std::fill(_fillStr->_B_k[R].begin(), _fillStr->_B_k[R].end(), 0.0);
                    for (int C = 0; C < 2; C++)
                        std::fill(_fillStr->Ak(R, C).begin(), _fillStr->Ak(R, C).end(), 0.0);
                }

                if (F != FillType::TrilCreat)
                {
                    if (LinSystemByElement != nullptr)
                        LinSystemByElement(*_fillStr);
                    else if (StiffnessMatrixByElement != nullptr && RightHandSideByElement != nullptr)
                    {
                        StiffnessMatrixByElement(*_fillStr);
                        RightHandSideByElement(*_fillStr);
                    }
                    else if (StiffnessMatrixByElement != nullptr)
                        StiffnessMatrixByElement(*_fillStr);
                    else if (RightHandSideByElement != nullptr)
                        RightHandSideByElement(*_fillStr);
                    else
                        throw std::runtime_error("Integration::_fillLinearSystem_InteriorFacet: No element filling function set.");

                    double wk = sf0.wk_sample * jac0;
                    for (int R = 0; R < 2; R++)
                    {
                        for (auto i = 0u; i < _fillStr->_B_e[R].size(); i++)
                            _fillStr->_B_e[R][i] += wk * _fillStr->_B_k[R][i];
                        for (int C = 0; C < 2; C++)
                        {
                            auto K = _fillStr->Ak(R, C);
                            for (auto i = 0u; i < K.size(); i++)
                                _fillStr->_Ae(R, C)[i] += wk * K[i];
                        }
                    }
                }
            }

            // --- Assemble all 4 coupling blocks into the global system ---
            _partialFillLinearSystem<F>(A, rhs, 0, 0, fp.elem1, fp.elem1, IndexType::Local);
            _partialFillLinearSystem<F>(A, rhs, 0, 1, fp.elem1, fp.elem2, IndexType::Local);
            _partialFillLinearSystem<F>(A, rhs, 1, 0, fp.elem2, fp.elem1, IndexType::Local);
            _partialFillLinearSystem<F>(A, rhs, 1, 1, fp.elem2, fp.elem2, IndexType::Local);
        }
    }

    // ── Ghost-penalty patch integration ──────────────────────────────────────
    //
    // For each pair (K+, K-) two sub-loops are executed:
    //   sub-loop 0: integrate over K+'s volume Gauss points.
    //               slot 0 = K+ (standard BFs),  slot 1 = K- (extended BFs).
    //   sub-loop 1: integrate over K-'s volume Gauss points.
    //               slot 0 = K- (standard BFs),  slot 1 = K+ (extended BFs).
    // After each sub-loop all 4 coupling blocks are assembled into the global
    // matrix with the correct element-DOF mapping.
    template <FillType F>
    void Integration::_fillLinearSystem_GhostPenalty(
        Teuchos::RCP<Epetra_FECrsMatrix> A, Teuchos::RCP<Epetra_FEVector> rhs)
    {
        _fillStr->init_fill();

        int offs = _dhands[0]->mesh->offs_nElem();
        int p    = _ghostPenaltyBFOrder;
        int nen  = p + 1;
        int eNN  = nen * nen;
        int nDim = _dhands[0]->mesh->nDim();

        // extended-BF buffer: [eNN values,  eNN*pDim reference gradients]
        // (pDim = 2 for 2-D Square elements)
        std::vector<double> extBuf(static_cast<size_t>(eNN * 3));

        for (auto& gp : _ghostPenaltyPairs)
        {
            for (int sub = 0; sub < 2; sub++)
            {
                int hostLocal  = (sub == 0) ? gp.elem1 : gp.elem2;
                int guestLocal = (sub == 0) ? gp.elem2 : gp.elem1;
                int hostGlobal  = hostLocal  + offs;
                int guestGlobal = guestLocal + offs;

                // --- load host into slot 0 ---
                auto& sf0 = *_fillStr->_subFills[0];
                sf0.elemID     = hostGlobal;
                sf0.loc_elemID = hostLocal;
                sf0.idxCuba    = 0;
                _fillStr->init_elem(_fillStr->_subFills[0]);

                // --- load guest coords/DOFs into slot 1 (bfs will be overridden) ---
                auto& sf1 = *_fillStr->_subFills[1];
                sf1.elemID     = guestGlobal;
                sf1.loc_elemID = guestLocal;
                sf1.idxCuba    = 0;
                _fillStr->init_elem(_fillStr->_subFills[1]);

                // --- zero elemental accumulators ---
                for (int R = 0; R < 2; R++)
                {
                    int szR = _fillStr->_subFills[R]->eNN * _fillStr->_subFills[R]->numDOFs;
                    _fillStr->_B_k[R].assign(static_cast<size_t>(szR), 0.0);
                    _fillStr->_B_e[R].assign(static_cast<size_t>(szR), 0.0);
                    for (int C = 0; C < 2; C++)
                    {
                        int szC = _fillStr->_subFills[C]->eNN * _fillStr->_subFills[C]->numDOFs;
                        _fillStr->Ak(R, C).assign(static_cast<size_t>(szR * szC), 0.0);
                        _fillStr->_Ae(R, C).assign(static_cast<size_t>(szR * szC), 0.0);
                    }
                }

                int iPts = _ghostPenaltyVolumeCubaInfo.iPts;
                double jac0 = sf0._jacobianParentElementToParameterSpace(hostLocal);

                // --- integration-point loop ---
                for (int k = 0; k < iPts; k++)
                {
                    // init_k sets sf0.wk_sample, sf0.x_sample, sf0.bfs
                    _fillStr->init_k(_fillStr->_subFills[0], hostGlobal, k);

                    // Compute physical coordinates of this Gauss point from the host BFs
                    double* hostBFs    = sf0.bfs;
                    double* hostCoords = sf0.nborCoords.data();
                    vector<double> xPhys   = {0.0, 0.0, 0.0};
                    for (int i = 0; i < eNN; i++)
                        for (int a = 0; a < nDim; a++)
                            xPhys[a] += hostCoords[i * nDim + a] * hostBFs[i];

                    // Find reference coordinates in the guest element (Newton iteration)
                    double* guestCoords = sf1.nborCoords.data();
                    vector<double> xiGuest  = {0.0, 0.0, 0.0};
                    int eH = sf0.elemID;
                    int eG = sf1.elemID;

                    // _gp_inverseMapSquare(xPhys, guestCoords, p, eNN, xiGuest);

                    double distPt = sf0.dhandDHand->mesh->DistributedMesh::_invertElementMapping_RegSquare(xiGuest, eG, xPhys, IndexType::Local, false);

                    // Evaluate guest BFs at xiGuest and put them into extBuf
                    std::vector<std::vector<double>>& extBf =  sf1.dhandDHand->mesh->_basisFunctions->computeBasisFunctionsReference(xiGuest, eG);
                    _gp_evalSquareBFs(xiGuest[0], xiGuest[1], p, eNN, extBuf.data());


                    size_t rows = extBf.size();
                    size_t cols = extBf[0].size();
                    std::vector<double> eBf;
                    eBf.reserve(rows * cols);

                    for (const auto& row : extBf)
                        eBf.insert(eBf.end(), row.begin(), row.end());

                    double* eBfA = eBf.data();
                    // Override guest slot's BF pointer with the extended data
                    sf1.bfs       = eBfA;
                    sf1.x_sample  = {xiGuest[0], xiGuest[1]};
                    sf1.kPt       = k;

                    // zero k-level buffers
                    for (int R = 0; R < 2; R++)
                    {
                        std::fill(_fillStr->_B_k[R].begin(), _fillStr->_B_k[R].end(), 0.0);
                        for (int C = 0; C < 2; C++)
                            std::fill(_fillStr->Ak(R, C).begin(), _fillStr->Ak(R, C).end(), 0.0);
                    }

                    if (F != FillType::TrilCreat)
                    {
                        if (LinSystemByElement != nullptr)
                            LinSystemByElement(*_fillStr);
                        else if (StiffnessMatrixByElement != nullptr && RightHandSideByElement != nullptr)
                        { StiffnessMatrixByElement(*_fillStr); RightHandSideByElement(*_fillStr); }
                        else if (StiffnessMatrixByElement != nullptr)
                            StiffnessMatrixByElement(*_fillStr);
                        else if (RightHandSideByElement != nullptr)
                            RightHandSideByElement(*_fillStr);
                        else
                            throw std::runtime_error("Integration::_fillLinearSystem_GhostPenalty: No filling function set.");

                        double wk = sf0.wk_sample * jac0;
                        for (int R = 0; R < 2; R++)
                        {
                            for (auto i = 0u; i < _fillStr->_B_e[R].size(); i++)
                                _fillStr->_B_e[R][i] += wk * _fillStr->_B_k[R][i];
                            for (int C = 0; C < 2; C++)
                            {
                                auto& K = _fillStr->Ak(R, C);
                                for (auto i = 0u; i < K.size(); i++)
                                    _fillStr->_Ae(R, C)[i] += wk * K[i];
                            }
                        }
                    }
                }

                // --- assemble all 4 coupling blocks ---
                // slot 0 = host, slot 1 = guest (by construction above)
                _partialFillLinearSystem<F>(A, rhs, 0, 0, hostLocal,  hostLocal,  IndexType::Local);
                _partialFillLinearSystem<F>(A, rhs, 0, 1, hostLocal,  guestLocal, IndexType::Local);
                _partialFillLinearSystem<F>(A, rhs, 1, 0, guestLocal, hostLocal,  IndexType::Local);
                _partialFillLinearSystem<F>(A, rhs, 1, 1, guestLocal, guestLocal, IndexType::Local);
            }
        }
    }

    template <FillType F>
    void Integration::_fillLinearSystem(Teuchos::RCP<Epetra_FECrsMatrix> A,
                                        Teuchos::RCP<Epetra_FEVector> rhs)
    {
        // Interior facet integration uses its own dedicated loop
        if (!_facetPairs.empty())
        {
            _fillLinearSystem_InteriorFacet<F>(A, rhs);
            return;
        }

        // Ghost-penalty patch integration uses its own dedicated loop
        if (!_ghostPenaltyPairs.empty())
        {
            _fillLinearSystem_GhostPenalty<F>(A, rhs);
            return;
        }

        // Initialize FillStructure
        _fillStr->init_fill();

        // The element loop is controlled by the master DOFsHandler
        for (int e = 0; e < _dhands[0]->mesh->loc_nElem(); e++)
        {
            //Loop over cubature infos for this element
            int idxCuba{};
            for (auto info: _cubaSets[0]->cubaInfo(e, IndexType::Local))
            {
                // We are taking the cubaInfo in the FillStructure::init_elem using the idxCuba
                _fillStr->_subFills[0]->cubaInfo = info;
                _fillStr->_subFills[0]->idxCuba = idxCuba;

                //Save idxCuba
                for (int R = 0; R < numDOFsHands(); R++)
                    _fillStr->_subFills[R]->idxCuba = idxCuba;

                //Jacobian of the transformation (parent element to parameter space) in BSplines and Nurbs
                double jac = _fillStr->_subFills[0]->_jacobianParentElementToParameterSpace(e);

                //Loop over integration points
                for (int k = 0; k < info.iPts; k++)
                {
                    _fillStr->_subFills[0]->idxCuba = idxCuba;
                    //Update info of the int. point and fill if we change element
                    _loadData_and_FillGlobLinSys<F>(A, rhs, k, e, IndexType::Local);

                    //Fill elemental matrix/rhs
                    if (F != FillType::TrilCreat)
                    {
                        //Fill matrix/rhs at this integration point
                        if (LinSystemByElement != nullptr)
                        {
                            LinSystemByElement(*_fillStr);
                        }
                        else if (StiffnessMatrixByElement != nullptr and RightHandSideByElement != nullptr)
                        {
                            StiffnessMatrixByElement(*_fillStr);
                            RightHandSideByElement(*_fillStr);
                        }
                        else if (StiffnessMatrixByElement != nullptr)
                        {
                            StiffnessMatrixByElement(*_fillStr);
                        }
                        else if (RightHandSideByElement != nullptr)
                        {
                            RightHandSideByElement(*_fillStr);
                        }
                        else
                        {
                            throw std::runtime_error("DOFsHandler::FillLinearSystem: There is a problem with the functions per Element.");
                        }

                        //Add contribution from int point to elemental matrix (* wk)
                        double wk = _fillStr->_subFills[0]->wk_sample * jac;
                        for (int R = 0; R < numDOFsHands(); R++)
                        {
                            //Rhs
                            for (auto i = 0u; i < _fillStr->_B_e[R].size(); i++)
                                _fillStr->_B_e[R][i] += wk * _fillStr->_B_k[R][i];

                            //Matrix
                            for (int C = 0; C < numDOFsHands(); C++)
                            {
                                auto K = _fillStr->Ak(R, C);
                                for (auto i = 0u; i < K.size(); i++)
                                    _fillStr->_Ae(R, C)[i] += wk * K[i];
                            }
                        }

                    }
                }

                //Increase idxCuba
                idxCuba++;
            }
        }

        //Fill the linear system with elemental matrix/rhs (for the last element)
        for (int R = 0; R < numDOFsHands(); R++)
        {
            for (int C = 0; C < numDOFsHands(); C++)
            {
                //Get local element
                int e_R = _fillStr->_subFills[R]->loc_elemID;
                int e_C = _fillStr->_subFills[C]->loc_elemID;

                //Fill
                _partialFillLinearSystem<F>(A, rhs, R, C, e_R, e_C, IndexType::Local);
            }
        }

    }

    template <FillType F>
    void Integration::_loadData_and_FillGlobLinSys(Teuchos::RCP<Epetra_FECrsMatrix> A,
                                                   Teuchos::RCP<Epetra_FEVector> rhs,
                                                   int kPt, int e, IndexType idxtype)
    {
        bool init = _fillStr->_subFills[0]->elemID != -1;
        std::vector<int> temp_elemID(_dhands.size());

        // Check if elements change for this integration point
        //  (true: release buffer and load info; false: change the needed info)
        for (auto i = 0u; i < _dhands.size(); i++)
        {
            //Get mapping from master to slave element for this integration point
            auto mapElem = _meshMaps[i]->directMap(e, idxtype);
            if (mapElem.size() == 1)
                temp_elemID[i] = mapElem[0];
            else if (mapElem.size() > 1)
                temp_elemID[i] = _meshMaps[i]->_kmap[e][kPt];

            //Check if element has changed
            auto &subFill = (*_fillStr)[i];
            bool changed = subFill.elemID != temp_elemID[i];
            _fillStr->dhandChangeElem[i] = changed;
        }

        // If we change the element, send buffer to global filling
        for (int R = 0; R < numDOFsHands(); R++)
        {
            for (int C = 0; C < numDOFsHands(); C++)
            {
                if (_fillStr->RC_hasChangeElem(R, C) and init)
                {
                    //Get local elements
                    int e_R = _fillStr->_subFills[R]->loc_elemID;
                    int e_C = _fillStr->_subFills[C]->loc_elemID;

                    //Fill
                    _partialFillLinearSystem<F>(A, rhs, R, C, e_R, e_C, IndexType::Local);
                }
            }
        }

        // If we change the element, initialize the new one
        for (int R = 0; R < numDOFsHands(); R++)
        {
            if (_fillStr->RC_hasChangeElem(R))
            {
                //Save local and global element
                auto &subFill = (*_fillStr)[R];
                subFill.elemID = temp_elemID[R];
                subFill.loc_elemID = subFill.elemID - subFill.dhandDHand->mesh->offs_nElem();

                //Initialize the element
                _fillStr->init_elem(_fillStr->_subFills[R]);
            }
        }

        // Resize the output structure of those DOFsHandler that change the element
        for (int R = 0; R < numDOFsHands(); R++)
        {
            for (int C = 0; C < numDOFsHands(); C++)
            {
                // If we have changed the element, we need to load all the information
                if (_fillStr->RC_hasChangeElem(R, C) == false)
                    continue;

                //Resize k- and ele-mental matrices and fill the last one with zeros
                int size = _fillStr->_subFills[R]->eNN * _fillStr->_subFills[R]->numDOFs * _fillStr->_subFills[C]->eNN * _fillStr->_subFills[C]->numDOFs;
                _fillStr->Ak(R, C).resize(static_cast<unsigned long>(size));
                _fillStr->_Ae(R, C).resize(static_cast<unsigned long>(size));
                std::fill(_fillStr->_Ae(R, C).begin(), _fillStr->_Ae(R, C).end(), 0.0);

                //Resize k- and ele-mental rhs and fill the last one with zeros
                if (R == C)
                {
                    // Filling the Buffer elementary objects
                    _fillStr->_B_k[R].resize(static_cast<unsigned int>(_fillStr->_subFills[R]->eNN * _fillStr->_subFills[R]->numDOFs));
                    _fillStr->_B_e[R].resize(static_cast<unsigned int>(_fillStr->_subFills[R]->eNN * _fillStr->_subFills[R]->numDOFs));
                    std::fill(_fillStr->_B_e[R].begin(), _fillStr->_B_e[R].end(), 0.0);
                }
            }
        }

        // Load info at integration point and initialize k-mental rhs/matrix
        for (int R = 0; R < numDOFsHands(); R++)
        {
            //Load info for this integration point into the subfill structures
            int eGl = e + _dhands[0]->mesh->offs_nElem();
            _fillStr->init_k(_fillStr->_subFills[R], eGl, kPt);

            //Initialize k-mental rhs/matrix to zero
            std::fill(_fillStr->_B_k[R].begin(), _fillStr->_B_k[R].end(), 0.0);
            for (int C = 0; C < numDOFsHands(); C++)
                std::fill(_fillStr->Ak(R, C).begin(), _fillStr->Ak(R, C).end(), 0.0);
        }
    }
}

#endif //HPLFE_INTEGRATION_IMPL_H
