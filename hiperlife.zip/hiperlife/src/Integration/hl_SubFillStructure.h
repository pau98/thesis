/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef SUBFILLSTRUCTURE_H
#define SUBFILLSTRUCTURE_H


#include <vector>
#include <array>

#include <Teuchos_RCP.hpp>
#include <hl_DOFsHandler.h>

#include "hl_TypeDefs.h"
#include "hl_ParamStructure.h"
#include "hl_DistributedMesh.h"
#include "hl_CubatureSet.h"
#include "hl_BasisFunctionsSet.h"


namespace hiperlife
{
    class SubFillStructure
    {
        public:
            SubFillStructure() = default;
            SubFillStructure(SubFillStructure&& other) = default;
            SubFillStructure(const SubFillStructure& other) = delete;
            ~SubFillStructure() = default;

            // Operators
            SubFillStructure& operator=(const SubFillStructure& other) = delete;
            SubFillStructure& operator=(SubFillStructure&& other) = default;

            void Update();
            void resizeVectors(int nbors);

            void setDOFsHandlers(Teuchos::RCP<DOFsHandler> dhand) {dhandDHand = dhand;}
            void setCubatureSet(Teuchos::RCP<CubatureSet> cubas) {dhandCubas = cubas;}
            void setBasisFunctionSet(Teuchos::RCP<BasisFunctionsSet> bfs) {dhandBFSet = bfs;}
            void setMeshMap(Teuchos::RCP<MeshMap> meshMap) {mapMasterToMe = meshMap;}

            [[deprecated("This function is deprecated and will be removed in the next release. Please use nborBasisFunctionsDerivatives(same arguments), nborBFsDers(same arguments) or the new functions for each derivative instead.")]]
            double* getDer(int order){return nborBasisFunctionsDerivatives(order);};
            double* nborBasisFunctionsDerivatives(int order);
            double* nborBasisFunctions(){return nborBasisFunctionsDerivatives(0);};
            double* nborBasisFunctionsGradients(){return nborBasisFunctionsDerivatives(1);};
            double* nborBasisFunctionsHessians(){return nborBasisFunctionsDerivatives(2);};
            double* nborBFsDers(int order);
            double* nborBFs(){return nborBasisFunctionsDerivatives(0);};
            double* nborBFsGrads(){return nborBasisFunctionsDerivatives(1);};
            double* nborBFsHess(){return nborBasisFunctionsDerivatives(2);};

            std::vector<double> tangentsBoundaryRef();
            std::vector<double> normalsBoundaryRef();
            double _jacobianParentElementToParameterSpace(int e);

            // Max numbers for allocation
            int maxNbors;

            bool passSol0{false};
            bool passSol{false};
            bool passAuxF{false};

            Teuchos::RCP<DOFsHandler>       dhandDHand = Teuchos::null;
            Teuchos::RCP<CubatureSet>       dhandCubas = Teuchos::null;
            Teuchos::RCP<BasisFunctionsSet> dhandBFSet = Teuchos::null;

            Teuchos::RCP<MeshMap> mapMasterToMe = Teuchos::null;



            /** @name ELEMENT INPUT (1). The following variables are going to be provided at the element.  */
            //@{
            int     nDim;        ///< spatial dimension where the data points are living
            int     pDim;        ///< tangent dimension (parametric dimension) of the problem
            int     numDOFs;     ///< number of degrees of freedom of the physical variable at each node
            int     numAuxF;     ///< number of auxiliar degrees of freedom  at each node
            int     kPt;         ///< index of the current integration point
            // int     kInfSize;    ///< size of the information for the current kpts.
            int     eNN;         ///< number of nearest nodes to the actual element

            int     elemID;      ///< element identifier
            int     loc_elemID;  ///< element identifier


            std::vector<double> nborCoords; ///< nearest neighbor nodes coordinates in the physical space, size: eNN x nDim
            std::vector<double> nborDOFs;   ///< nearest neighbor nodes coordinates in the \b deformed configuration, size: eNN x DOF
            std::vector<double> nborDOFs0;  ///< nearest neighbor nodes coordinates in the \b reference configuration, size: eNN x DOF
            std::vector<double> nborAuxF;   ///< auxiliary variables at each nearest node in the physical space, size: eNN x nDim
            CubatureInfo cubaInfo;          ///< Info that stores all the information related with kpoints for the current element
            int idxCuba{};                  ///< Index in the integrationInfo vector that corresponds to current cubature in element e

            double wk_sample;               ///< weight value of the current integration point.
            std::vector<double> x_sample;   ///< vector that stores the coordinates of the current k point

            double* bfs; ///< Basis functions at each element and their spatial derivatives
            //@}

    };


}


#endif
