/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef _FILLTYPE_H
#define _FILLTYPE_H

#include <ostream>
#include <stdexcept>
#include <Teuchos_RCP.hpp>
#include <Epetra_FECrsMatrix.h>


namespace hiperlife
{


    /** @enum FillType
     *  @brief Type of filling of the IndexType::Global LA object
     *  @details Only TrilCreat and TrilFill are valid now. Petsc is NOT supported.
     */
    enum class FillType {TrilCreat, TrilFill, PetscCreat, PetscFill};

    std::ostream& operator<<(std::ostream& os, const FillType& ft);


    /**
     *  @brief Specific method for perform the matrix filling
     *  @tparam val This template function only has been implemented for FillType::TrilCreat and FillType::TrilFill
     *  @arg A The global matrix to fill
     *  @arg row the global row to fill
     *  @arg column the global column to fill
     *  @arg value the value to fill
     */
    template <FillType val> inline void matrixFill(Teuchos::RCP<Epetra_FECrsMatrix> A, int row, int column, double value);

}

#endif //FILLTYPE_H
