/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_TypeDefs.h"
#include "hl_MeshCreator.h"

using std::runtime_error;
using std::vector;
using std::map;
using std::string;

namespace hiperlife
{
    void MeshCreator::_checkMesh()
    {
        //Check sets
        if (_nDim == 0)
            throw runtime_error("The number of dimensions is zero.");
        if (_eType == ElemType::Undefined)
            throw runtime_error("The element type is undefined.");
        if (_bfType == BasisFuncType::Undefined)
            throw runtime_error("The basis function type is undefined.");
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
        {
            if (_bfOrderX < 0 && _bfOrderY < 0 && _bfOrderZ < 0)
                throw runtime_error("The basis function order per direction is zero.");
        }
        else
        {
            if (_bfOrder < 0)
                throw runtime_error("The basis function order is zero or negative.");
        }
        if (_meshType == MeshType::Undefined)
            throw runtime_error("The mesh type is undefined.");

        //The BasicMeshGenerator does not check more
        if (nameTag() == "BasicMeshGenerator")
            return;

        //Check mesh generated variables
        if (_meshType == MeshType::Parallel)
        {
            if (_x_nodes.empty())
                throw runtime_error("Node coordinates not set.");
            if (_connec.empty())
                throw runtime_error("Connectivity not set.");
            if (_creases.empty())
                throw runtime_error("Creases not set.");
            if (_eflags.empty())
                throw runtime_error("Element flags not set.");
        }
        else
        {
            if (_glob_x_nodes.empty())
                throw runtime_error("Node coordinates not set.");
            if (_glob_connec.empty())
                throw runtime_error("Connectivity not set.");
            if (_glob_creases.empty())
                throw runtime_error("Creases not set.");
            if (_glob_eflags.empty())
                throw runtime_error("Element flags not set.");
        }

        if (_nPts == 0)
            throw runtime_error("Global number of points is zero.");
        if (_nElem == 0)
            throw runtime_error("Global number of elements is zero.");
        if (_nVert == 0)
            throw runtime_error("Number of vertices is zero.");
        if (_pDim == 0)
            throw runtime_error("Parametric dimension is zero.");

        if (_meshType == MeshType::Parallel)
        {
            if (_loc_nPts == 0)
                throw runtime_error("Local number of points is zero.");
            if (_loc_nElem == 0)
                throw runtime_error("Local number of elements is zero.");
        }

        if (nameTag() == "StructMeshGenerator")
        {
            if ((_eType == ElemType::Line) && (_nEx == -1))
                throw runtime_error("Number of elements not set.");
            if ((_eType == ElemType::Square) && ((_nEx == -1) || (_nEy == -1)))
                throw runtime_error("Number of elements per direction not set.");
            if ((_eType == ElemType::Parallelep) && ((_nEx == -1) || (_nEy == -1) || (_nEz == -1)))
                throw runtime_error("Number of elements per direction not set.");
        }

        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
        {
            if ((_eType == ElemType::Line) && (_uKnot.empty()))
                throw runtime_error("Knots not set.");
            if ((_eType == ElemType::Square) && (_uKnot.empty() || _vKnot.empty()))
                throw runtime_error("Knots not set.");
            if ((_eType == ElemType::Parallelep) && (_uKnot.empty() || _vKnot.empty() || _wKnot.empty()))
                throw runtime_error("Knots not set.");
            if (_CP.empty())
                throw runtime_error("Control points not set.");
        }
        if ((_bfType == BasisFuncType::Nurbs) && (_weights.empty()))
            throw runtime_error("Weights not set.");

    }

    void MeshCreator::_performOrderChecks()
    {
        using namespace std;

        //Order zero is not allowed
        if (_bfOrder == 0 || _bfOrderX == 0 || _bfOrderY == 0 || _bfOrderZ == 0)
            throw runtime_error("StructMeshGenerator: In the current implementation, the order of the basis functions cannot be zero.");

        //Linear elements: Check order or set it to one if the user did not
        if (_bfType == BasisFuncType::Linear)
        {
            if ((_bfOrder > 1) or (_bfOrder == 0))
                throw runtime_error("StructMeshGenerator: The order of linear elements must be set to one or not set.");
            else if (_bfOrder == -1)
                _bfOrder = 1;
            if (_bfOrderX != -1 or _bfOrderY != -1 or _bfOrderZ != -1)
                throw runtime_error("StructMeshGenerator: setBasisFuncOrderDir: Order per direction cannot be set for linear elements.");
        }

        //Subdivision surfaces: Set order to one if it was not set or if it is 2 (distributed mesh will make it two)
        if (_bfType == BasisFuncType::SubdivSurfs)
        {
            if ((_isBfOrderSubSet == false) and ((_bfOrder == -1) or (_bfOrder == 2)))
            {
                _bfOrder = 1;
                _isBfOrderSubSet = true;
            }
            else if ((_pRefinedMesh) or (_hRefinedMesh))
            {
                _bfOrder = 1;
                _isBfOrderSubSet = true;
            }
            else
            {
                throw runtime_error("StructMeshGenerator: The order of subdivision surfaces should be either not set or set to two.");
            }

            if (_bfOrderX != -1 or _bfOrderY != -1 or _bfOrderZ != -1)
                throw runtime_error("StructMeshGenerator: setBasisFuncOrderDir: Order per direction cannot be set for subdivision surfaces.");
        }

        //Lagrangian elements
        if (_bfType == BasisFuncType::Lagrangian)
        {
            if (_bfOrderX != -1 or _bfOrderY != -1 or _bfOrderZ != -1)
                throw runtime_error("StructMeshGenerator: setBasisFuncOrderDir: Order per direction cannot be set for Lagrangian elements.");
        }

        //Bsplines and Nurbs
        if ((_bfType == BasisFuncType::BSplines) or (_bfType == BasisFuncType::Nurbs))
        {
            if (_bfOrder != -1)
            {
                switch (int(_eType))
                {
                    case static_cast<int>(ElemType::Line):
                        _bfOrderX = _bfOrder;
                        break;
                    case static_cast<int>(ElemType::Square):
                    case static_cast<int>(ElemType::Triang):
                        _bfOrderX = _bfOrder;
                    _bfOrderY = _bfOrder;
                    break;
                    case static_cast<int>(ElemType::Parallelep):
                    case static_cast<int>(ElemType::Tetrah):
                        _bfOrderX = _bfOrder;
                    _bfOrderY = _bfOrder;
                    _bfOrderZ = _bfOrder;
                    break;
                    default:
                        throw runtime_error("StructMeshGenerator: Element type is wrong or has not been set.");
                }
            }
            else
            {
                _bfOrder = std::max({_bfOrderX, _bfOrderY, _bfOrderZ}); //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs
            }

            switch (int(_eType))
            {
                case static_cast<int>(ElemType::Line):
                    if ((_bfOrderX == -1) || (_bfOrderY != -1  || _bfOrderZ != -1))
                        throw runtime_error("StructMeshGenerator: The order of Line elements should (only) be set in x direction.");
                    break;
                case static_cast<int>(ElemType::Triang):
                    if ((_bfOrderX == -1 || _bfOrderY == -1)  || _bfOrderZ != -1)
                        throw runtime_error("StructMeshGenerator: The order of Triang elements should (only) be set  in x and y direction.");
                    break;
                case static_cast<int>(ElemType::Square):
                    if ((_bfOrderX == -1 || _bfOrderY == -1)  || _bfOrderZ != -1)
                        throw runtime_error("StructMeshGenerator: The order of Square elements should (only) be set in x and y direction.");
                    break;
                case static_cast<int>(ElemType::Tetrah):
                    if (_bfOrderX == -1 || _bfOrderY == -1  || _bfOrderZ == -1)
                        throw runtime_error("StructMeshGenerator: The order of Tetrah elements should be set in x, y and z direction.");
                    break;
                case static_cast<int>(ElemType::Parallelep):
                    if (_bfOrderX == -1 || _bfOrderY == -1  || _bfOrderZ == -1)
                        throw runtime_error("StructMeshGenerator: The order of Parallelep elements should be set in x, y and z direction.");
                    break;
                default:
                    throw runtime_error("StructMeshGenerator: Wrong element type.");
            }
        }
    }

    bool MeshCreator::_isMeshGenerated()
    {
        if ((_nPts == 0) || (_nElem == 0) || (_nVert == 0) || (_pDim == 0))
            return false;

        if ((_bfType != BasisFuncType::BSplines) and (_bfType != BasisFuncType::Nurbs))
        {
            if (nameTag() == "StructMeshGenerator")
            {
                if ((_x_nodes.empty()) || (_creases.empty()) || (_connec.empty()) || (_eflags.empty()))
                    return false;

                if ((_loc_nPts == 0) || (_loc_nElem == 0))
                    return false;
            }
            else
            {
                if ((_glob_x_nodes.empty()) || (_glob_creases.empty()) || (_glob_connec.empty()) || (_glob_eflags.empty()))
                    return false;
            }
        }
        else
        {
            if ((_eType == ElemType::Line) && (_uKnot.empty() || (_nEx == -1)))
                return false;
            if ((_eType == ElemType::Square) && (_uKnot.empty() || _vKnot.empty() || (_nEx == -1) || (_nEy == -1)))
                return false;
            if ((_eType == ElemType::Parallelep) && (_uKnot.empty() || _vKnot.empty() || _wKnot.empty() || (_nEx == -1) || (_nEy == -1) || (_nEz == -1)))
                return false;
            if (_CP.empty())
                return false;
        }

        if ((_bfType == BasisFuncType::Nurbs) && (_weights.empty()))
            return false;

        return true;
    }

    void MeshCreator::_checkFileExists(const string& fname)
    {
        if (FILE *file = fopen(fname.c_str(), "r"))
            fclose(file);
        else
            throw runtime_error("MeshCreator: The input file (" + fname + ") does not exist");
    }

    string MeshCreator::_getFileExtension(const string& fname)
    {
        size_t i = fname.rfind('.', fname.length());
        if (i != string::npos)
        {
            return(fname.substr(i+1, fname.length() - i));
        }

        return("");
    }

    void MeshCreator::_removeRepeatedNodes(map<int,int> removeMap)
    {
        // Checks
        if (_meshType == MeshType::Sequential) //FIXME
            throw runtime_error("MeshCreator::_removeRepeatedNodes: Only implemented for MeshType::Sequential meshes.");

        // Relabel repeated nodes from connectivity
        for (size_t i = 0; i < _connec.size(); i++)
        {
            auto it = removeMap.find(_connec[i]);
            if (it != removeMap.end())
                _connec[i] = it->second;
        }

        // Construct vector of repeated nodes //FIXME: binary tree
        vector<int> removeVec(removeMap.size());
        int n{};
        for (auto it = removeMap.begin(); it != removeMap.end(); ++it)
        {
            removeVec[n] = it->first;
            n++;
        }

        // Shift connectivity
        for (size_t i = 0; i < _connec.size(); i++)
        {
            auto c = _connec[i];
            auto upper = std::upper_bound(removeVec.begin(), removeVec.end(), c);
            auto count = distance(removeVec.begin(), upper);
            _connec[i] = _connec[i] - count;
        }

        // Remove repeated nodes from coordinates and creases
        int idx{};
        _x_nodes.erase(std::remove_if(_x_nodes.begin(), _x_nodes.end(), [&](double x){
                                                                            (void) x;
                                                                            idx %= _loc_nPts;
                                                                            int glob_idx = idx + _disPts.offs_nItem();
                                                                            idx++;
                                                                            auto it = removeMap.find(glob_idx);
                                                                            return (it != removeMap.end());
                                                                        }), _x_nodes.end());
        _creases.erase(std::remove_if(_creases.begin(), _creases.end(), [&](int x){
                                                                            (void) x;
                                                                            idx %= _loc_nPts;
                                                                            int glob_idx = idx + _disPts.offs_nItem();
                                                                            idx++;
                                                                            auto it = removeMap.find(glob_idx);
                                                                            return (it != removeMap.end());
                                                                        }), _creases.end());

        // Update number of nodes
        _nPts -= removeMap.size();
        for (auto rit = removeMap.rbegin(); rit != removeMap.rend(); ++rit)
            if (_disPts.isItemInPart(rit->first))
                _loc_nPts--;

        // Update node distribution
        _disPts.setLocNItem(_loc_nPts);
        _disPts.setNItem(0);
        _disPts.Update();
    }

    vector<int> MeshCreator::_createNodeGhosts()
    {
        // Checks
        if (_meshType == MeshType::Sequential) //FIXME
            throw runtime_error("MeshCreator::_createNodeGhosts: Only implemented for MeshType::Sequential meshes.");

        // Create ghosts set
        std::set<int> set_ghosts;
        for (int e = 0; e < _nElem; e++)
        {
            if (_disElem.isItemInPart(e))
            {
                int loc_el = _disElem.locIdx(e);
                for (int i = 0; i < _nVert; i++)
                {
                    int nbor = _connec[loc_el*_nVert+i];
                    bool owned = _disPts.isItemInPart(nbor);
                    if (owned == false)
                        set_ghosts.insert(nbor);
                }
            }
        }

        // Convert set to vector
        vector<int> ghosts(set_ghosts.size());
        std::copy(set_ghosts.begin(), set_ghosts.end(), ghosts.begin());

        return ghosts;
    }
}
