/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef BASICMESHGENERATOR_H
#define BASICMESHGENERATOR_H

#include <vector>
#include <functional>
#include <deque>

#include "hl_DistributedData.h"
#include "hl_TypeDefs.h"

#include "hl_MeshCreator.h"


namespace hiperlife
{

    /*!
     * \class BasicMeshGenerator
     * \brief Class to generate user defined meshes
     */

    class BasicMeshGenerator : public MeshCreator
    {
        public:

            /** @name Constructor / Destructor / Operator
             *   Copy constructors are deleted for memory safety but objects can be created from
             *   temporal objects throught move constructors
             *  @{ */
            BasicMeshGenerator(std::string tag = "BasicMeshGenerator", MPI_Comm comm = MPI_COMM_WORLD) : MeshCreator(tag, comm)
                {
                    _x_nodes.resize(1);
                    _connec.resize(1);
                    _creases.resize(1);
                    _eflags.resize(1);
                };
            BasicMeshGenerator(BasicMeshGenerator&& other) = default;
            BasicMeshGenerator(const BasicMeshGenerator& other) = delete;
            ~BasicMeshGenerator() = default;
            BasicMeshGenerator& operator=(const BasicMeshGenerator& other) = delete;
            BasicMeshGenerator& operator=(BasicMeshGenerator&& other) = default;
            /** @} */ // end of constructors

            /** @name Object creation management
             *  @{
             */
            // Setters - Updates
            /*! \brief Sets the type of mesh. */
            void setMeshType(MeshType meshType) {_meshType = meshType;};
            /*! \brief Sets the type of mesh. */
            [[deprecated("Replaced by setMeshType(MeshType meshType)")]]
            void setIndexType(IndexType indexType)
            {
                if (indexType == IndexType::Local)
                    _meshType = MeshType::Parallel;
                else
                    _meshType = MeshType::Sequential;
            };
            /*! \brief Sets the global number of points. */
            void setNPts(int nPts) {_nPts = nPts;};
            /*! \brief Sets the global number of elements. */
            void setNElem(int nElem) {_nElem = nElem;};
            // /*! \brief Sets the global number of elements per direction. */
            // void setNElemDir(int nEx, int nEy, int nEz){_nEx = nEx; _nEy = nEy; _nEz = nEz;};
            // /*! \brief Sets the global NURBS weights. */
            // void setGlobWeights(std::vector<double> weights){_weights = weights;};
            // /*! \brief Sets the global knot vectors. */
            // void setGlobKnots(std::vector<double> uKnot, std::vector<double> vKnot, std::vector<double> wKnot){_uKnot = uKnot; _vKnot = vKnot; _wKnot = wKnot;};
            /*! \brief Sets an array with the global coordinates. */
            // void setGlobCoords(double* x_nodes);
            /*! \brief Sets a vector with the global coordinates. */
            void setGlobCoords(std::vector<double> glob_x_nodes){_glob_x_nodes = glob_x_nodes;};
            /*! \brief Sets an array with the global creases. */
            // void setGlobCreases(int* creases);
            /*! \brief Sets a vector with the global creases. */
            void setGlobCreases(std::vector<int> glob_creases){_glob_creases = glob_creases;};
            /*! \brief Sets an array with the element flags. */
            // void setGlobElemFlags(int* eflags);
            /*! \brief Sets a vector with the element flags. */
            void setGlobElemFlags(std::vector<int> glob_eflags){_glob_eflags = glob_eflags;};
            /*! \brief Sets an array with the global connectivity. */
            // void setGlobConnec(int* connec);
            /*! \brief Sets a vector with the global connectivity. */
            void setGlobConnec(std::vector<int> glob_connec){_glob_connec = glob_connec;};

            /*! \brief Sets the local number of points. */
            void setLocNPts(int loc_nPts) {_loc_nPts = loc_nPts;};
            /*! \brief Sets the local number of elements. */
            void setLocNElem(int loc_nElem) {_loc_nElem = loc_nElem;};
            /*! \brief Sets a vector with the coordinates locally distributed.*/
            void setDistCoords(double* x_nodes);
            /*! \brief Sets a vector with the coordinates locally distributed.*/
            void setDistCoords(std::vector<double> x_nodes){_x_nodes = x_nodes;};
            /*! \brief Sets an array with the creases locally distributed.*/
            void setDistCreases(int* creases);
            /*! \brief Sets a vector with the creases locally distributed.*/
            void setDistCreases(std::vector<int> creases){_creases = creases;};
            /*! \brief Sets an array with the element flags locally distributed.*/
            void setDistElemFlags(int* eflags);
            /*! \brief Sets a vector with the element flags locally distributed.*/
            void setDistElemFlags(std::vector<int> eflags){_eflags = eflags;};
            /*! \brief Sets an array with the connectivity locally distributed.*/
            void setDistConnec(int* connec);
            /*! \brief Sets a vector with the creases locally distributed.*/
            void setDistConnec(std::vector<int> connec){_connec = connec;};
            /** @} */ // end of setters

            //Auxiliary functions
            void printMesh(const std::string& mssg){_printMesh(mssg);};

    private:

            // Interface functions
            void _saveMesh() override;
            void _reloadMesh() override;

            void _getPRefinedMesh(int orderInc) override;
            void _getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ) override;
            void _getHRefinedMesh(int refLevel) override;
            void _getBoundaryMesh(std::vector<MAxis> vMAx) override;

            // Checks
            void _performChecks(int nEx, int nEy, int nEz);
            void _performSettingChecks();
            void _performElementChecks(int nEx, int nEy, int nEz);

            // Utils
            void _printMesh(const std::string& input);
    };

}
#endif
