/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <numeric>

#include "hl_MpiHelpers.h"
#include "hl_TypeDefs.h"
#include "hl_Math.h"
#include "hl_MultiPatchMeshGenerator.h"

using std::cout;
using std::endl;
using std::vector;
using std::runtime_error;
using std::map;
using std::to_string;

namespace hiperlife
{

    //Save and reload mesh
    void MultiPatchMeshGenerator::_saveMesh()
    {
        return;
    }

    void MultiPatchMeshGenerator::_reloadMesh()
    {
        return;
    }

    //Derived meshes
    void MultiPatchMeshGenerator::_getPRefinedMesh(int orderInc)
    {
        (void) orderInc;
        throw runtime_error("MultiPatchMeshGenerator::getPRefinedMesh:  Not implemented.");

        return;
    }

    void MultiPatchMeshGenerator::_getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ)
    {
        (void) orderIncX;
        (void) orderIncY;
        (void) orderIncZ;
        throw runtime_error("MultiPatchMeshGenerator::getPRefinedMesh: Not implemented.");

        return;
    }

    void MultiPatchMeshGenerator::_getHRefinedMesh(int refLevel)
    {
        (void) refLevel;
        throw runtime_error("MultiPatchMeshGenerator::getHRefinedMesh: Not implemented.");

        return;
    }

    void MultiPatchMeshGenerator::_getBoundaryMesh(vector<MAxis> vMAx)
    {
        (void) vMAx;
        throw runtime_error("MultiPatchMeshGenerator::getBoundaryMesh: Not implemented.");

        return;
    }

    //Setters
    void MultiPatchMeshGenerator::setMeshes(vector<Teuchos::RCP<MeshCreator>> meshCreators, MultiPatchConnectivity mpConn, vector<vector<int>> map)
    {
        // Checks
        if (mpConn == MultiPatchConnectivity::Undefined)
            throw runtime_error("MultiPatchMeshGenerator::setMeshes: MultiPatchConnectivity not defined. Please select one.");

        // Set mesh creators
        _mCreators = meshCreators;

        // Set map
        _mpConn = mpConn;
        _createMapping = false;
        _mul_map = map;
    }

    void MultiPatchMeshGenerator::setMeshes(vector<Teuchos::RCP<MeshCreator>> meshCreators, MultiPatchConnectivity mpConn, double tolerance)
    {
        // Checks
        if (mpConn == MultiPatchConnectivity::Undefined)
            throw runtime_error("MultiPatchMeshGenerator::setMeshes: MultiPatchConnectivity not defined. Please select one.");

        // Set mesh creators
        _mCreators = meshCreators;

        // Set map
        _mpConn = mpConn;
        if (_mpConn != MultiPatchConnectivity::Disconnected)
        {
            _createMapping = true;
            _tolerance = tolerance;
            if (_tolerance < 0.0)
                throw runtime_error("MultiPatchMeshGenerator::setMeshes: Tolerance not defined. Please set a value.");
        }
    }

    void MultiPatchMeshGenerator::_shareBoundaryNodes(vector<int>& glob_bNodes, vector<double>& glob_bCoords, vector<int>& glob_slaves)
    {
        //*************************************************************************
        // [0] Share boundary nodes ids
        //*************************************************************************

        // Get boundary nodes ids
        vector<int> bNodes;
        for (int i = 0; i < _loc_nPts; i++)
        {
            if (_creases[i] > 0)
                bNodes.push_back(_disPts.globIdx(i));
        }

        // Share local boundary nodes ids
        glob_bNodes = MpiHelpers::allgatherv(bNodes, _numProcs, _myRank);


        //*************************************************************************
        // [1] Share boundary nodes coordinates
        //*************************************************************************

        // Get boundary nodes coordinates (**note change of ordering)
        vector<double> bCoords(3*bNodes.size());
        int n = 0;
        for (int i = 0; i < _loc_nPts; i++)
        {
            if (_creases[i] > 0)
            {
                for (int d = 0; d < _nDim; d++)
                    bCoords[_nDim*n+d] = _x_nodes[_loc_nPts*d+i];
                n++;
            }
        }

        // Share local boundary nodes coordinates
        glob_bCoords = MpiHelpers::allgatherv(bCoords, _numProcs, _myRank);


        //*************************************************************************
        // [2] Share slave node ids
        //*************************************************************************

        // Get slave node ids
        vector<int> slaves(_mul_map.size());
        for (size_t i = 0; i < _mul_map.size(); i++)
            slaves[i] = _mul_map[i][1];

        // Share local slave node ids
        glob_slaves = MpiHelpers::allgatherv(slaves, _numProcs, _myRank);
    }

    void MultiPatchMeshGenerator::_appendSequentialMeshes()
    {
        // Set main variables that wont change from the first mesh creator
        _nameTag = _mCreators[0]->_nameTag;
        _meshType = _mCreators[0]->_meshType;
        _nDim = _mCreators[0]->_nDim;
        _pDim = _mCreators[0]->_pDim;
        _eType = _mCreators[0]->_eType;
        _bfType = _mCreators[0]->_bfType;
        _bfOrder = _mCreators[0]->_bfOrder;
        _bfOrderX = _mCreators[0]->_bfOrderX;
        _bfOrderY = _mCreators[0]->_bfOrderY;
        _bfOrderZ = _mCreators[0]->_bfOrderZ;
        _nVert = _mCreators[0]->_nVert;

        // Save variables from the first mesh creator
        _nElem = _mCreators[0]->_nElem;
        _nEx   = _mCreators[0]->_nEx;
        _nEy   = _mCreators[0]->_nEy;
        _nEz   = _mCreators[0]->_nEz;
        _nPts  = _mCreators[0]->_nPts;
        _loc_nElem = _mCreators[0]->_loc_nElem;
        _loc_nPts  = _mCreators[0]->_loc_nPts;
        _glob_connec  = _mCreators[0]->_glob_connec;
        _glob_x_nodes = _mCreators[0]->_glob_x_nodes;
        _glob_creases = _mCreators[0]->_glob_creases;
        _glob_eflags  = _mCreators[0]->_glob_eflags;

        // Get new values and vectors
        if (_myRank == 0)
        {
            for (size_t m = 1; m < _mCreators.size(); m++)
            {
                // Save mesh
                _mCreators[m]->_saveMesh();

                // Create mapping
                if (_createMapping)
                {
                    // Get boundary nodes ids
                    vector<int> bNodes;
                    for (int i = 0; i < _nPts; i++)
                    {
                        if (_glob_creases[_nCreases*i] > 0)
                            bNodes.push_back(i); // FIXME: Count & resize
                    }

                    // Get slave node ids // FIXME: Do I really need it??
                    vector<int> slaves(_mul_map.size());
                    for (size_t i = 0; i < _mul_map.size(); i++)
                        slaves[i] = _mul_map[i][1];

                    // Find nodes that are closer than the tolerance
                    for (int i = 0; i < _mCreators[m]->_nPts; i++)
                    {
                        if (_mCreators[m]->_glob_creases[_nCreases*i] > 0)
                        {
                            // Get coordinates of the boundary nodes of the new mesh
                            vector<double> bCoords(3);
                            for (int d = 0; d < _nDim; d++)
                                bCoords[d] = _mCreators[m]->_glob_x_nodes[_mCreators[m]->_nDim*i+d];

                            // Find nodes in other partitions
                            for (size_t j = 0; j < bNodes.size(); j++)
                            {
                                // Get vector of coordinates of the boundary nodes of the old mesh
                                vector<double> c(3);
                                for (int d = 0; d < _nDim; d++)
                                    c[d] = _glob_x_nodes[_nDim*bNodes[j]+d];

                                // Check distance
                                if (Math::Dist3D(bCoords.data(), c.data()) < _tolerance)
                                {
                                    int master = bNodes[j];
                                    int slave  = i +_nPts;

                                    // Check if the node is already a slave
                                    std::vector<int>::iterator it = find(slaves.begin(), slaves.end(), master);
                                    if (it == slaves.end())
                                    {
                                        _mul_map.push_back({master, slave});
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                // Relabel connectivity
                for (size_t i = 0; i < _mCreators[m]->_glob_connec.size(); i++)
                {
                    _mCreators[m]->_glob_connec[i] += _nPts;
                }

                // Add it to the connectivity of the multipatch mesh
                int s = _glob_connec.size();
                _glob_connec.reserve(s+_mCreators[m]->_glob_connec.size());
                _glob_connec.insert(_glob_connec.begin()+s, _mCreators[m]->_glob_connec.begin(), _mCreators[m]->_glob_connec.end());

                // Append new coordinates
                s = _glob_x_nodes.size();
                _glob_x_nodes.reserve(s+_mCreators[m]->_glob_x_nodes.size());
                _glob_x_nodes.insert(_glob_x_nodes.begin()+s, _mCreators[m]->_glob_x_nodes.begin(), _mCreators[m]->_glob_x_nodes.end());

                // Creases
                s = _glob_creases.size();
                _glob_creases.reserve(s+_mCreators[m]->_glob_creases.size());
                _glob_creases.insert(_glob_creases.begin()+s, _mCreators[m]->_glob_creases.begin(), _mCreators[m]->_glob_creases.end());

                // Element flags
                s = _glob_eflags.size();
                _glob_eflags.reserve(s+_mCreators[m]->_glob_eflags.size());
                _glob_eflags.insert(_glob_eflags.begin()+s, _mCreators[m]->_glob_eflags.begin(), _mCreators[m]->_glob_eflags.end());

                // Update integers
                _nElem += _mCreators[m]->_nElem;
                _nPts += _mCreators[m]->_nPts;
                _loc_nElem += _mCreators[m]->_loc_nElem;
                _loc_nPts += _mCreators[m]->_loc_nPts;

                //Reload mesh
                _mCreators[m]->_reloadMesh();
            }
        }
    }

    void MultiPatchMeshGenerator::_appendParallelMeshes()
    {
        // Set main variables that wont change from the first mesh creator
        _nameTag = _mCreators[0]->_nameTag;
        _meshType = _mCreators[0]->_meshType;
        _nDim = _mCreators[0]->_nDim;
        _pDim = _mCreators[0]->_pDim;
        _eType = _mCreators[0]->_eType;
        _bfType = _mCreators[0]->_bfType;
        _bfOrder = _mCreators[0]->_bfOrder;
        _bfOrderX = _mCreators[0]->_bfOrderX;
        _bfOrderY = _mCreators[0]->_bfOrderY;
        _bfOrderZ = _mCreators[0]->_bfOrderZ;
        _nVert = _mCreators[0]->_nVert;

        // Save variables from the first mesh creator
        _nElem = _mCreators[0]->_nElem;
        _nEx   = _mCreators[0]->_nEx;
        _nEy   = _mCreators[0]->_nEy;
        _nEz   = _mCreators[0]->_nEz;
        _nPts  = _mCreators[0]->_nPts;
        _loc_nElem = _mCreators[0]->_loc_nElem;
        _loc_nPts  = _mCreators[0]->_loc_nPts;
        _connec  = _mCreators[0]->_connec;
        _x_nodes = _mCreators[0]->_x_nodes;
        _creases = _mCreators[0]->_creases;
        _eflags  = _mCreators[0]->_eflags;

        //Get new values and vectors
        for (size_t m = 1; m < _mCreators.size(); m++)
        {
            //Save mesh
            _mCreators[m]->_saveMesh();

            //Update distributed points
            _disPts.setNItem(0);
            _disPts.setLocNItem(_loc_nPts);
            _disPts.Update();

            // Create mapping
            if (_createMapping)
            {
                // Share boundary nodes of the old mesh
                vector<int> glob_bNodes, glob_slaves;
                vector<double> glob_bCoords;
                _shareBoundaryNodes(glob_bNodes, glob_bCoords, glob_slaves);

                // Save old mul_map size for later relabeling
                int mSize = _mul_map.size();

                // Find nodes that are closer than the tolerance
                for (int i = 0; i < _mCreators[m]->_loc_nPts; i++)
                {
                    if (_mCreators[m]->_creases[i] > 0)
                    {
                        // Get coordinates of the boundary nodes of the new mesh
                        vector<double> bCoords(3);
                        for (int d = 0; d < _nDim; d++)
                            bCoords[d] = _mCreators[m]->_x_nodes[_mCreators[m]->_loc_nPts*d+i];

                        // Find nodes in other partitions
                        for (size_t j = 0; j < glob_bNodes.size(); j++)
                        {
                            // Get vector of coordinates of the boundary nodes of the old mesh
                            vector<double> c(3);
                            for (int d = 0; d < _nDim; d++)
                                c[d] = glob_bCoords[_nDim*j+d];

                            // Check distance
                            if (Math::Dist3D(bCoords.data(), c.data()) < _tolerance)
                            {
                                int master = glob_bNodes[j];
                                int slave  = _mCreators[m]->_disPts.globIdx(i);

                                // Check if the node is already a slave
                                std::vector<int>::iterator it = find(glob_slaves.begin(), glob_slaves.end(), master);
                                if (it == glob_slaves.end())
                                {
                                    _mul_map.push_back({master, slave});
                                    break;
                                }
                            }
                        }
                    }
                }

                // Relabel mult_map
                for (size_t i = 0; i < _mul_map.size(); i++)
                {
                    // Master
                    int pm = _disPts.getItemPartition(_mul_map[i][0]);
                    _mul_map[i][0] += _mCreators[m]->_disPts.offs_nItem(pm);

                    // Slave
                    if (i < static_cast<size_t>(mSize))
                    {
                        int ps = _disPts.getItemPartition(_mul_map[i][1]);
                        _mul_map[i][1] += _mCreators[m]->_disPts.offs_nItem(ps);
                    }
                    else
                    {

                        int ps = _mCreators[m]->_disPts.getItemPartition(_mul_map[i][1])+1;
                        if (ps < numProcs())
                            _mul_map[i][1] += _disPts.offs_nItem(ps);
                        else
                            _mul_map[i][1] += _nPts;
                    }
                }
            }

            //Relabel old connectivity
            for (size_t i = 0; i < _connec.size(); i++)
            {
                int p = _disPts.getItemPartition(_connec[i]);
                _connec[i] += _mCreators[m]->_disPts.offs_nItem(p); // FIXME: This wont work if mesh is clamped?
            }

            //Relabel new connectivity
            for (size_t i = 0; i < _mCreators[m]->_connec.size(); i++)
            {
                int p = _mCreators[m]->_disPts.getItemPartition(_mCreators[m]->_connec[i])+1;
                if (p < numProcs())
                    _mCreators[m]->_connec[i] += _disPts.offs_nItem(p); // FIXME: This wont work if mesh is clamped?
                else
                    _mCreators[m]->_connec[i] += _nPts;
            }

            //Connectivity
            int s = _connec.size();
            _connec.reserve(s+_mCreators[m]->_connec.size());
            _connec.insert(_connec.begin()+s, _mCreators[m]->_connec.begin(), _mCreators[m]->_connec.end());

            //Coordinates
            s = _x_nodes.size();
            _x_nodes.reserve(s+_mCreators[m]->_x_nodes.size());
            for (int d = 0; d < _nDim; d++)
                _x_nodes.insert(_x_nodes.begin() + _loc_nPts + d*(_loc_nPts+_mCreators[m]->_loc_nPts),
                                _mCreators[m]->_x_nodes.begin()+d*_mCreators[m]->_loc_nPts,
                                _mCreators[m]->_x_nodes.begin()+(d+1)*_mCreators[m]->_loc_nPts);

            //Creases
            s = _creases.size();
            _creases.reserve(s+_mCreators[m]->_creases.size());
            for (int c = 0; c < _mCreators[m]->_nCreases; c++)
                _creases.insert(_creases.begin() + _loc_nPts + c*(_loc_nPts+_mCreators[m]->_loc_nPts),
                                _mCreators[m]->_creases.begin()+c*_mCreators[m]->_loc_nPts,
                                _mCreators[m]->_creases.begin()+(c+1)*_mCreators[m]->_loc_nPts);

            //Element flags
            s = _eflags.size();
            _eflags.reserve(s+_mCreators[m]->_eflags.size());
            _eflags.insert(_eflags.begin()+s, _mCreators[m]->_eflags.begin(), _mCreators[m]->_eflags.end());

            //Update integers
            _nElem += _mCreators[m]->_nElem;
            _nPts += _mCreators[m]->_nPts;
            _loc_nElem += _mCreators[m]->_loc_nElem;
            _loc_nPts += _mCreators[m]->_loc_nPts;

            //Reload mesh
            _mCreators[m]->_reloadMesh();
        }

        //Create distributions
        _disPts.setNItem(0);
        _disPts.setLocNItem(_loc_nPts);
        _disPts.Update();
        _disElem.setLocNItem(_loc_nElem);
        _disElem.Update();
    }

    void MultiPatchMeshGenerator::_appendMeshes()
    {
        if (_mCreators[0]->_meshType == MeshType::Sequential)
            _appendSequentialMeshes();
        else
            _appendParallelMeshes();
    }

    void MultiPatchMeshGenerator::_createLinearConstraints()
    {
        // // Temporal check
        // if (_meshType == MeshType::Sequential)
        //     throw runtime_error("Not checked");

        _linearConstraints.resize(_mul_map.size());
        for (size_t i = 0; i < _mul_map.size(); i++)
            _linearConstraints[i] = {_mul_map[i][1], {_mul_map[i][0]}, {1.0}, 0.0};
    }

    void MultiPatchMeshGenerator::_unclampSequentialMeshes()
    {
        // Create map from vector _mul_map
        map<int,int> _map;
        for (size_t i = 0; i < _mul_map.size(); i++)
        {
            int m = _mul_map[i][0];
            int s = _mul_map[i][1];
            _map.emplace(s, m);
        }

        // Relabel repeated nodes from connectivity
        map<int,int>::iterator it;
        for (size_t i = 0; i < _glob_connec.size(); i++)
        {
            it = _map.find(_glob_connec[i]);
            if (it != _map.end())
            {
                _glob_connec[i] = it->second;
            }
        }

        // Shift connectivity after removal
        map<int,int>::reverse_iterator rit;
        for (size_t i = 0; i < _glob_connec.size(); i++)
        {
            // Get shifts of this processor
            int j{};
            for (rit = _map.rbegin(); rit != _map.rend(); ++rit)
            {
                if (_glob_connec[i] > rit->first)
                    break;
                j++;
            }
            j = _map.size()-j;

            // Update value
            _glob_connec[i] -= j;
        }

        // Remove repeated nodes from coordinates
        for (rit = _map.rbegin(); rit != _map.rend(); ++rit)
        {
            for (int d = _nDim-1; d >= 0; d--)
            {
                _glob_x_nodes.erase(_glob_x_nodes.begin() + _nDim*rit->first + d);
            }
        }

        // Remove repeated nodes from creases and update their value
        for (rit = _map.rbegin(); rit != _map.rend(); ++rit)
        {
            for (int d = _nCreases-1; d >= 0; d--)
            {
                _glob_creases.erase(_glob_creases.begin() + _nCreases*rit->first + d);
                int id = _nCreases*rit->second + d;
                if ((d == 0) and (_glob_creases[id] != 0))
                    _glob_creases[id] -= 1;
                if (d == 1)
                    _glob_creases[id] = -1;
            }
        }

        // Update number of nodes
        _nPts -= _map.size();
    }

    void MultiPatchMeshGenerator::_unclampParallelMeshes()
    {
        //*************************************************************************
        // [0] Share mapping
        //*************************************************************************

        // Rearrange _mult_map in vector
        vector<int> v_mul_map(2*_mul_map.size());
        for (size_t i = 0; i < _mul_map.size(); i++)
        {
            v_mul_map[2*i]   = _mul_map[i][0];
            v_mul_map[2*i+1] = _mul_map[i][1];
        }

        // Share local v_mul_map
        vector<int> glob_v_mul_map = MpiHelpers::allgatherv(v_mul_map, _numProcs, _myRank);

        // Create map from vector glob_v_mul_map
        map<int,int> _map;
        for (size_t i = 0; i < glob_v_mul_map.size()/2; i++)
        {
            int m = glob_v_mul_map[2*i];
            int s = glob_v_mul_map[2*i+1];
            _map.emplace(s, m);
        }


        //*************************************************************************
        // [1] Remove repeated nodes
        //*************************************************************************

        // Relabel repeated nodes from connectivity
        map<int,int>::iterator it;
        for (size_t i = 0; i < _connec.size(); i++)
        {
            it = _map.find(_connec[i]);
            if (it != _map.end())
                _connec[i] = it->second;
        }

        // Shift connectivity after removal
        map<int,int>::reverse_iterator rit;
        for (size_t i = 0; i < _connec.size(); i++)
        {
            // Get shifts of this processor
            int j{};
            for (rit = _map.rbegin(); rit != _map.rend(); ++rit)
            {
                if (_connec[i] > rit->first)
                    break;
                j++;
            }
            j = _map.size()-j;

            // Update value
            _connec[i] -= j;
        }

        // Remove repeated nodes from coordinates
        for (int d = _nDim-1; d >= 0; d--)
        {
            for (rit = _map.rbegin(); rit != _map.rend(); ++rit)
            {
                if (_disPts.isItemInPart(rit->first))
                    _x_nodes.erase(_x_nodes.begin() + d*_loc_nPts + _disPts.locIdx(rit->first));
            }
        }

        // Remove repeated nodes from creases and update their value
        for (int d = _nCreases-1; d >= 0; d--)
        {
            for (rit = _map.rbegin(); rit != _map.rend(); ++rit)
            {
                if (_disPts.isItemInPart(rit->first))
                    _creases.erase(_creases.begin() + d*_loc_nPts + _disPts.locIdx(rit->first));
                if (_disPts.isItemInPart(rit->second))
                {
                    int id = d*_loc_nPts + _disPts.locIdx(rit->second);
                    if ((d == 0) and (_creases[id] != 0))
                        _creases[id] -= 1;
                    if (d == 1)
                        _creases[id] = -1;
                }
            }
        }

        // Update number of nodes
        _nPts -= _map.size();
        for (rit = _map.rbegin(); rit != _map.rend(); ++rit)
            if (_disPts.isItemInPart(rit->first))
                _loc_nPts--;
    }

    void MultiPatchMeshGenerator::_unclampMeshes()
    {
        if (_mCreators[0]->_meshType == MeshType::Sequential)
            _unclampSequentialMeshes();
        else
            _unclampParallelMeshes();
    }


    void MultiPatchMeshGenerator::Update()
    {
        cout << "MultiPatchMeshGenerator:: This class is still work in progress. Expect things to break and functionality and interface functions to change." << endl;

        // Temporary checks
        if (_mCreators[0]->_bfType != BasisFuncType::Lagrangian)
            throw runtime_error("MultiPatchMeshGenerator::Update: Only Lagrangian implemented.");
        for (size_t m = 0; m < _mCreators.size(); m++)
        {
            Teuchos::RCP<MeshCreator> _meshCrea = _mCreators[m];
            if (_meshCrea->_periodicInX or _meshCrea->_periodicInY or _meshCrea->_periodicInZ)
                throw runtime_error("MultiPatchMeshGenerator::Update: MultiPatch for periodic meshes not implemented.");
        }

        // Perform checks
        if (_mCreators.size() < 2)
            throw runtime_error("MultiPatchMeshGenerator::setMultiPatchMesh: At least two meshes should be specified.");
        for (size_t m = 1; m < _mCreators.size(); m++)
        {
            Teuchos::RCP<MeshCreator> _meshCrea = _mCreators[m];

            if (_mCreators[0]->_meshType != _meshCrea->_meshType)
                throw runtime_error("MultiPatchMeshGenerator:: The mesh type of patch" + to_string(m) + " does not match with other patches.");
            if (_mCreators[0]->nameTag() != _meshCrea->nameTag())
                throw runtime_error("MultiPatchMeshGenerator:: The mesh creator type of patch" + to_string(m) + " does not match with other patches.");
            if (_mCreators[0]->_nDim != _meshCrea->_nDim)
                throw runtime_error("MultiPatchMeshGenerator:: The number of dimensions of patch" + to_string(m) + " does not match with other patches.");
            if (_mCreators[0]->_eType != _meshCrea->_eType)
                throw runtime_error("MultiPatchMeshGenerator:: The element type of patch" + to_string(m) + " does not match with other patches.");
            if (_mCreators[0]->_bfType != _meshCrea->_bfType)
                throw runtime_error("MultiPatchMeshGenerator:: The basis function type of patch" + to_string(m) + " does not match with other patches.");
            if ((_mCreators[0]->_bfOrder != _meshCrea->_bfOrder) and (_meshCrea->_bfType != BasisFuncType::SubdivSurfs))
                throw runtime_error("MultiPatchMeshGenerator:: The basis function order of patch" + to_string(m) + " does not match with other patches.");
            if (_mCreators[0]->_bfOrderX != _meshCrea->_bfOrderX)
                throw runtime_error("MultiPatchMeshGenerator:: The basis function order in x direction of patch" + to_string(m) + " does not match with other patches.");
            if (_mCreators[0]->_bfOrderY != _meshCrea->_bfOrderY)
                throw runtime_error("MultiPatchMeshGenerator:: The basis function order in y direction of patch" + to_string(m) + " does not match with other patches.");
            if (_mCreators[0]->_bfOrderZ != _meshCrea->_bfOrderZ)
                throw runtime_error("MultiPatchMeshGenerator:: The basis function order in z direction of patch" + to_string(m) + " does not match with other patches.");
        }

        // Append meshes
        _appendMeshes();

        // Modify connectivity
        if (_mpConn == MultiPatchConnectivity::LinearConstraints)
            _createLinearConstraints();
        else if (_mpConn == MultiPatchConnectivity::Unclamped)
            _unclampMeshes();
    }


    //Checks
    void MultiPatchMeshGenerator::_performChecks(int nEx, int nEy, int nEz)
    {
        _performSettingChecks();
        _performElementChecks(nEx, nEy, nEz);
        _performOrderChecks();
    }

    void MultiPatchMeshGenerator::_performSettingChecks()
    {

        if (_nDim == 0)
            throw runtime_error("MultiPatchMeshGenerator: nDim has not been set.");

        if (_eType == ElemType::Undefined)
            throw runtime_error("MultiPatchMeshGenerator: Element type has not been set");

        if (_bfType == BasisFuncType::Undefined)
            throw runtime_error("MultiPatchMeshGenerator: Basis functions type has not been set");

        if (_bfOrder < 0 && _bfOrderX < 0 && _bfOrderY < 0 && _bfOrderZ < 0 && _bfType != BasisFuncType::Linear && _bfType != BasisFuncType::SubdivSurfs)
            throw runtime_error("MultiPatchMeshGenerator: The order of the basis functions has not been set or it is negative.");

    }

    void MultiPatchMeshGenerator::_performElementChecks(int nEx, int nEy, int nEz)
    {
        if (nEx < -1 && nEy < -1 && nEz < -1)
            throw runtime_error("MultiPatchMeshGenerator: Number of elements should be positive.");
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (nEx == -1 || nEy != -1 || nEz != -1)
                    throw runtime_error("MultiPatchMeshGenerator: Line elements should (only) have elements in x direction.");
                break;
            case static_cast<int>(ElemType::Triang):
                if ((nEx == -1 || nEy == -1) || (nEz != -1))
                    throw runtime_error("MultiPatchMeshGenerator: Triang elements should (only) have elements in x and y directions.");
                break;
            case static_cast<int>(ElemType::Square):
                if ((nEx == -1 || nEy == -1) || (nEz != -1))
                    throw runtime_error("MultiPatchMeshGenerator: Square elements should (only) have elements in x and y directions.");
                break;
            case static_cast<int>(ElemType::Tetrah):
                if (nEx == -1 || nEy == -1 || nEz == -1)
                    throw runtime_error("MultiPatchMeshGenerator: Tetrah elements should have elements in x, y and z directions.");
                break;
            case static_cast<int>(ElemType::Parallelep):
                if (nEx == -1 || nEy == -1 || nEz == -1)
                    throw runtime_error("MultiPatchMeshGenerator: Parallelep elements should have elements in x, y and z directions.");
                break;
            default:
                throw runtime_error("MultiPatchMeshGenerator: Wrong element type.");
        }
    }


    //Utils
    void MultiPatchMeshGenerator::_printMesh(const std::string& mssg)
    {
        if (_meshType == MeshType::Sequential)
        {
            if (_myRank == 0)
            {
                cout << endl << mssg << endl;
                cout << " bf: " << str(_bfType) << endl;
                cout << " eType: " << str(_eType) << endl;

                cout << " nPts: " << _nPts << " " << _loc_nPts << endl;
                cout << " nEle: " << _nElem << " " << _loc_nElem << " ("<< _nEx << ", " <<  _nEy << ", " <<  _nEz << ")" << endl;
                cout << " Ord:  "<< _bfOrder << " ("<< _bfOrderX << ", " << _bfOrderY << ", " << _bfOrderZ << ")" << endl;

                cout << " xnodes:" << endl;
                for (int i = 0; i < _nPts; i++)
                {
                    cout << "   " << i << " - ";
                    for (int j = 0; j < _nDim; j++)
                        cout << _glob_x_nodes[_nDim * i + j] << " ";
                    cout << endl;
                }

                cout << " connec:" << endl;
                for (int i = 0; i < _nElem; i++)
                {
                    cout << "   "  << i << " - ";
                    for (int j = 0; j < _nVert; j++)
                        cout << _glob_connec[_nVert * i + j] << " ";
                    cout << endl;
                }

                cout << " creases:" << endl;
                for (int i = 0; i < _nPts; i++)
                {
                    cout << "   " << i << " - ";
                    for (int j = 0; j < _nCreases; j++)
                        cout << _glob_creases[_nCreases * i + j] << " ";
                    cout << endl;
                }

            }
        }
        else
        {
            if (_myRank == 0)
                cout << endl << mssg << endl;

            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    cout << "Processor: " << p << endl;
                    cout << " bf: " << str(_bfType) << endl;
                    cout << " eType: " << str(_eType) << endl;

                    cout << " nPts: " << _nPts << " " << _loc_nPts << endl;
                    cout << " nEle: " << _nElem << " " << _loc_nElem << " ("<< _nEx << ", " <<  _nEy << ", " <<  _nEz << ")" << endl;
                    cout << " Ord:  "<< _bfOrder << " ("<< _bfOrderX << ", " << _bfOrderY << ", " << _bfOrderZ << ")" << endl;

                    cout << " xnodes:" << endl;
                    int n = 0;
                    for (int i = 0; i < _nPts; i++)
                    {
                        if(_disPts.isItemInPart(n))
                        {
                            int locN = _disPts.locIdx(n);
                            cout << "   " << i << " - ";
                            for (int j = 0; j < _nDim; j++)
                                cout << _x_nodes[_loc_nPts * j + locN] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    cout << " connec:" << endl;
                    n = 0;
                    for (int i = 0; i < _nElem; i++)
                    {
                        if(_disElem.isItemInPart(n))
                        {
                            int locN = _disElem.locIdx(n);
                            cout << "   "  << i << " - ";
                            for (int j = 0; j < _nVert; j++)
                                cout << _connec[locN * _nVert + j] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    cout << " creases:" << endl;
                    n = 0;
                    for (int i = 0; i < _nPts; i++)
                    {
                        if(_disPts.isItemInPart(n))
                        {
                            int locN = _disPts.locIdx(n);
                            cout << "   " << i << " - ";
                            for (int j = 0; j < _nCreases; j++)
                                cout << _creases[_loc_nPts * j + locN] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    cout << " eflags:" << endl;
                    n = 0;
                    for (int i = 0; i < _nElem; i++)
                    {
                        if(_disElem.isItemInPart(n))
                        {
                            int locN = _disElem.locIdx(n);
                            cout << "   "  << i << " - ";
                            for (int j = 0; j < _nEFlags; j++)
                                cout << _eflags[locN * _nEFlags + j] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    if ((_bfType == BasisFuncType::Nurbs) || (_bfType == BasisFuncType::BSplines))
                    {
                        cout << " U : " << endl << "   ";
                        for (auto u: _uKnot)
                            cout << u << " ";
                        cout << endl;
                        cout << " V : " << endl << "   ";
                        for (auto u: _vKnot)
                            cout << u << " ";
                        cout << endl;
                        cout << " W : " << endl << "   ";
                        for (auto u: _wKnot)
                            cout << u << " ";
                        cout << endl;
                        cout << " CP :" << endl;
                        for (auto i = 0u; i < _CP.size(); i++)
                        {
                            for (auto j = 0u; j < _CP[i].size(); j++)
                            {
                                for (auto k = 0u; k < _CP[i][j].size(); k++)
                                {
                                    cout << "  ";
                                    for (int d = 0; d < 4; d++)
                                    {
                                        cout << " " << _CP[i][j][k][d];
                                    }
                                    cout << endl;
                                }
                            }
                        }
                    }

                }
                Barrier();
            }

        }
    }


}
