/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francesco Greco and Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef STRUCTMESHGENERATOR_H
#define STRUCTMESHGENERATOR_H

#include <vector>
#include <functional>
#include <deque>

#include "hl_DistributedData.h"
#include "hl_TypeDefs.h"

#include "hl_MeshCreator.h"


namespace hiperlife
{

    /*!
     * \class StructMeshGenerator
     * \brief Class to generate different types of structured meshes
     *
     * StructMeshGenerator is a class that generates different types of structured meshes that are fully compatible with hiperlife.
     * It can generate meshes for finite elements, subdivision surfaces, BSplines and Nurbs. This class is composed
     * by generators and transformations and should be used in that order: First generate a mesh, which can be a
     * predefined mesh (eg. square, circle or torus) or user-defined, and then apply the desired transformations.
     *
     */

    class StructMeshGenerator : public MeshCreator
    {
        public:

            /** @name Constructor / Destructor / Operator
             *   Copy constructors are deleted for memory safety but objects can be created from
             *   temporal objects through move constructors
             *  @{ */
            StructMeshGenerator(std::string tag = "StructMeshGenerator", MPI_Comm comm = MPI_COMM_WORLD) : MeshCreator(tag, comm){_meshType= MeshType::Parallel;};
            StructMeshGenerator(StructMeshGenerator&& other) = default;
            StructMeshGenerator(const StructMeshGenerator& other) = delete;
            ~StructMeshGenerator() = default;
            StructMeshGenerator& operator=(const StructMeshGenerator& other) = delete;
            StructMeshGenerator& operator=(StructMeshGenerator&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             *   Main functions to set structured meshes
             *  @{*/
            /*! \brief Set periodic boundary conditions for given vector of axis*/
            void setPeriodicBoundaryCondition(std::vector<Axis> axes)
            {
                if (_bfType == BasisFuncType::SubdivSurfs)
                    throw std::runtime_error("StructMeshGenerator::setPeriodicBoundaryCondition: Not implemented yet for this type of basis functions.");

                for (size_t it = 0; it < axes.size(); ++it)
                {
                    switch (axes[it])
                    {
                        case Axis::Xaxis:
                            _periodicInX = true;
                            break;
                        case Axis::Yaxis:
                            _periodicInY = true;
                            break;
                        case Axis::Zaxis:
                            _periodicInZ = true;
                            break;
                        default:
                            throw std::runtime_error("StructMeshGenerator::setPeriodicBoundaryCondition: Axis not set.");
                            break;
                    }
                }
            }
            /** @} */ // end of object creation management



            /** @name Generators for every basis function
             *   Functions to generate meshes valid for every basis function.
             *  @{*/
            /*! \brief Generate a structured unitary line, rectangle or cube with nEdir elements per direction.*/
            inline void genStructMesh(int nEdir)
            {
                int pDim = computePDim(_eType);
                if (pDim == 1)
                    genStructMesh(nEdir, -1, -1);
                else if (pDim == 2)
                    genStructMesh(nEdir, nEdir, -1);
                else
                    genStructMesh(nEdir, nEdir, nEdir);
            };
            /*! \brief Generate a structured unitary square with nEx*nEy elements.*/
            inline void genStructMesh(int nEx, int nEy){genStructMesh(nEx, nEy, -1);};

            /*! \brief Generate a structured unitary cube with nEx*nEy*nEz elements.*/
            void genStructMesh(int nEx, int nEy, int nEz);
            /*! \brief Generate a line of length Lx with nEx elements.*/
            void genLine(int nEx, double Lx = 1.0);
            /*! \brief Generate a line from point \a p0 to point \a p1 with nEx elements.*/
            void genLine(int nEx, std::vector<double> p0, std::vector<double> p1);
            /*! \brief Generate the perimeter of a square, with side \a side, with nEl elements per edge.*/
            void genSquareLine(int nEl, double side);
            /*! \brief Generate a polygonal curve given by a set of points and refine it refLevel times.*/
            void genPolygonalCurve(std::string fname, bool closeCurve = false);
            /*! \brief Generate a polygonal curve given by a set of points.*/
            void genPolygonalCurve(std::vector<double> xCoords,std::vector<double> yCoords, bool closeCurve);
            /*! \brief Generate a square of side \a side with nEx*nEy elements.*/
            void genSquare(int nEx, int nEy, double side);
            /*! \brief Generate a square of side \a side with nEdir elements per direction.*/
            inline void genSquare(int nEdir, double side)
            {
                genSquare(nEdir, nEdir, side);
            };
            /*! \brief Generate a rectangle with nEx*nEy elements for given side lengths /a sidex and /a sidey.*/
            void genRectangle(int nEx, int nEy, double sidex, double sidey);
            /*! \brief Generate a ruled surface starting from 4 vertices.*/
            void genRuledSurface(int nEx, int nEy, std::vector<double> p1, std::vector<double> p2, std::vector<double> p3, std::vector<double> p4);
            /*! \brief Generate a cube of side \a side with nEdir elements per direction.*/
            void genCube(int nEdir, double side = 1.0);
            /*! \brief Generate a hexahedron of side \a side with nEdir elements per direction.*/
            inline void genHexahedron(int nEdir, double side = 1.0){genCube(nEdir, side);};
            /*! \brief Generate a rectangular parallelepiped with nEx*nEy*nEz elements for given side lengths /a sidex,  /a sidey, /a sidez.*/
            void genRectangularParallelepiped(int nEx, int nEy, int nEz, double sidex, double sidey, double sidez);
            /*! \brief Generate a circular arc with nEx elements for a given radius (radius) and from an initial angle to an end angle (phiEnd). The sum of the angles must be less than 2*PI*/
            void genCircularArc(int nEx, double radius, double phiIni, double phiEnd);
            /*! \brief Generate a circular arc with nEx elements for a given radius (radius) and angle (phi<2*PI).*/
            inline void genCircularArc(int nEx, double radius, double phi)
            {
                genCircularArc(nEx, radius, 0.0, phi);
            };
            /*! \brief Generate a circle with nEx elements for a given radius (radius).*/
            inline void genCircle(int nEx, double radius)
            {
                genCircularArc(nEx, radius, 0.0, 2.0*M_PI);
            };
            /*! \brief Generate an annular sector with nEx*nEy elements for a given internal radius (rInt), external radius (rExt), initial angle (phiIni), and end angle (phiEnd).*/
            void genAnnularSector(int nEx, int nEy, double rInt, double rExt, double phiIni, double phiEnd);
            /*! \brief Generate an annular sector with nEx*nEy elements for a given internal radius (rInt), external radius (rExt), and angle (phi<2*PI).*/
            inline void genAnnularSector(int nEx, int nEy, double rInt, double rExt, double phi)
            {
                genAnnularSector(nEx, nEy, rInt, rExt, 0.0, phi);
            };
            /*! \brief Generate an annulus with nEx*nEy elements for a given internal radius (rInt) and external radius (rExt).*/
            inline void genAnnulus(int nEx, int nEy, double rInt, double rExt)
            {
                genAnnularSector(nEx, nEy, rInt, rExt, 0.0, 2.0*M_PI);
            };
            /*! \brief Generate a disk with nEx*nEy elements for a given radius (rInt).
             *
             * This approach generates a disk revolving a line around one of its edges.
             */
            void genDisk_Polar(int nEx, int nEy, double radius);
            /* void genCircularSector_Polar(); */
            /*! \brief Generate a disk with nEx*nEy elements for a given radius (radius).
             *
             * This approach degenerates a square into a disk, similar to inflating a balloon
             * (the square) into a recipient (the circle).
             */
            void genDisk_Squared(int nEx, int nEy, double radius);
            /*! \brief Generate an annular sector with nEx*nEy elements for a given side length (side) and hole radius (radius).*/
            inline void genQuarterPlateWithCircularHole(int nEx, int nEy, double side, double radius)
            {
                genQuarterPlateWithCircularHole(nEx, nEy, side, side, radius);
            };
            /*! \brief Generate an annular sector with nEx*nEy elements for a given side length per direction (sidex and sidey) and hole radius (radius).*/
            void genQuarterPlateWithCircularHole(int nEx, int nEy, double sidex, double sidey, double radius);
            /*! \brief Generate a sector of a patch of a torus surface with nEx*nEy elements. The generatrix is defined by its radius (rGen), initial angle (phiIni) and end angle (phiEnd). Similarly, the directrix is defined by its radius (rDir), initial angle (thetaIni) and end angle (thetaEnd). Both the generatrix and the directrix are circular arcs.*/
            void genTorusSurfacePatchSector(int nEx, int nEy, double rGen, double phiIni, double phiEnd, double rDir, double thetaIni, double thetaEnd);
            /*! \brief Generate a sector of a patch of a torus surface with nEx*nEy elements for a given radius (rGen) and angle (phi) of the generatrix and for a given radius (rDir) and angle (theta) of the directrix. Both the generatrix and the directrix are circular arcs.*/
            inline void genTorusSurfacePatchSector(int nEx, int nEy, double rGen, double phi, double rDir, double theta)
            {
                genTorusSurfacePatchSector(nEx, nEy, rGen, 0.0, phi, rDir, 0.0, theta);
            };
            /*! \brief Generate a sector of a torus surface with nEx*nEy elements. The generatrix is defined by its radius (rGen). The directrix is defined by its radius (rDir), initial angle (thetaIni) and end angle (thetaEnd). Both the generatrix and the directrix are circular arcs.*/
            inline void genTorusSurfaceSector(int nEx, int nEy, double rGen, double rDir, double thetaIni, double thetaEnd)
            {
                genTorusSurfacePatchSector(nEx, nEy, rGen, 0.0, 2.0*M_PI, rDir, thetaIni, thetaEnd);
            };
            /*! \brief Generate a sector of a torus surface with nEx*nEy elements for a given radius (rGen) of the generatrix and for a given radius (rDir) and angle (theta) of the directrix. Both the generatrix and the directrix are circular arcs.*/
            inline void genTorusSurfaceSector(int nEx, int nEy, double rGen, double rDir, double theta)
            {
                genTorusSurfacePatchSector(nEx, nEy, rGen, 0.0, 2.0*M_PI, rDir, 0.0, theta);
            };
            /*! \brief Generate the surface of torus with nEx*nEy elements for a given radius of the generatrix (rGen) and directrix (rDir).*/
            void genTorusSurface(int nEx, int nEy, double rGen, double rDir)
            {
                genTorusSurfacePatchSector(nEx, nEy, rGen, 0.0, 2.0*M_PI, rDir, 0.0, 2.0*M_PI);
            };
            /*! \brief Generate a sector of a solid torus with nEx*nEy*nEz elements. The generatrix is defined by its radius (rGen). The directrix is defined by its radius (rDir), initial angle (thetaIni) and end angle (thetaEnd). Both the generatrix and the directrix are circular arcs.*/
            void genTorusSolidSector(int nEx, int nEy, int nEz, double rGen, double rDir, double thetaIni, double thetaEnd);
            /*! \brief Generate a sector of a solid torus with nEx*nEy*nEz elements for a given radius of the generatrix (rGen) and a given radius (rDir) and angle (theta) of the directrix (rDir).*/
            void genTorusSolidSector(int nEx, int nEy, int nEz, double rGen, double rDir, double theta)
            {
                genTorusSolidSector(nEx, nEy, nEz, rGen, rDir, 0.0, theta);
            };
            /*! \brief Generate a quarter of a solid torus with nEx*nEy*nEz elements for a given radius of directrix (rGen) and a given radius of generatrix (rDir).*/
            void genTorusSolidQuarter(int nEx, int nEy, int nEz, double rGen, double rDir)
            {
                genTorusSolidSector(nEx, nEy, nEz, rGen, rDir, 0.0, M_PI/2.0);
            };
            /*! \brief Generate a torus with nEx*nEy*nEz elements for a given radius of the generatrix (rGen) and directrix (rDir).*/
            void genTorusSolid(int nEx, int nEy, int nEz, double rGen, double rDir)
            {
                genTorusSolidSector(nEx, nEy, nEz, rGen, rDir, 0.0, 2.0*M_PI);
            };

            /*! \brief Generate a vermouth cup*/
            void genVermouth();

            /*! \brief Generate a quarter of a solid rectangle with nEr*nEy*nEz elements given its side (side) and height (height), with a cylindrical hole of radius \var radius */
            void genSolidQuarterPlateWithCylindricalHole(int nEx, int nEy, int nEz, double side, double height, double radius);

            /** @} */ // end of generators


            /** @name Generators for Nurbs and BSplines
             *   Functions to generate meshes only valid for Nurbs and BSplines
             *  @{*/
            /*! \brief Generate a Nurbs curve given a knot vector (U) and a vector of control points (CP).*/
            void genNurbsFree(std::vector<double> U, std::vector<std::vector<std::vector<std::vector<double>>>> CP);
            /*! \brief Generate a Nurbs surface given two knot vectors (U and V) and a vector of control points (CP).*/
            void genNurbsFree(std::vector<double> U, std::vector<double> V, std::vector<std::vector<std::vector<std::vector<double>>>> CP);
            /*! \brief Generate a Nurbs solid given three knot vectors (U, V and W) and a vector of control points (CP).*/
            void genNurbsFree(std::vector<double> U, std::vector<double> V, std::vector<double> W, std::vector<std::vector<std::vector<std::vector<double>>>> CP);

            /*! \brief Generate a B-Splines closed curve given a knot vector (U) and a vector of control points (CP).*/
            void genBsplinesClosedCurve(std::vector<double> U, std::vector<std::vector<std::vector<std::vector<double>>>> CP);
            
            /*! \brief Generate N B-Splines closed curves given a knot vector (vU[i]) and a vector of control points (vCP[i]).*/
            void genBsplinesNClosedCurves(std::vector<std::vector<double>> vU, std::vector<std::vector<std::vector<std::vector<std::vector<double>>>>> vCP);

            /** @} */ // end of generators Nurbs


            //Unclamp //FIXME comment
            void unclamp(Axis axis){std::vector<Axis> axes={axis}; unclamp(axes);};
            void unclamp(std::vector<Axis> axes);

            //Revolve //FIXME comment
            inline void revolve(int nEr, int order_r, ElemType eType, double phi, Axis axis)
            {
                if (axis == Axis::Xaxis)
                    revolve(nEr, order_r, eType, phi, {0, 0, 0}, {1, 0, 0});
                else if (axis == Axis::Yaxis)
                    revolve(nEr, order_r, eType, phi, {0, 0, 0}, {0, 1, 0});
                else if (axis == Axis::Zaxis)
                    revolve(nEr, order_r, eType, phi, {0, 0, 0}, {0, 0, 1});
            };
            inline void revolve(int nEr, int order_r, ElemType eType, double phi, std::vector<double> point, Axis axis)
            {
                if (axis == Axis::Xaxis)
                    revolve(nEr, order_r, eType, phi, point, {1, 0, 0});
                else if (axis == Axis::Yaxis)
                    revolve(nEr, order_r, eType, phi, point, {0, 1, 0});
                else if (axis == Axis::Zaxis)
                    revolve(nEr, order_r, eType, phi, point, {0, 0, 1});
            };
            void revolve(int nEr, int order_r, ElemType eType, double phi, std::vector<double> point, std::vector<double> dir);


            // Linear extrusion
            void extrudeSurfaceLinear(int nEz, double height);

            // FE refinement
            void threeRefine(std::map<int, int> nodeSubdivLevels, IndexType idxType = IndexType::Global);
            void threeRefine(std::function<double(double, double, double)> fxyz, int maxSubdivisionLevel = -1, std::vector<int> nSamplesDirLevel = {});


            /** @name Nurbs- and BSpline-specific transformations
             *    Functions to perform transformations specific of Nurbs and Bsplines
             *  @{ */
            //Uniformly refine
            /*! \brief h-Refine Nurbs/BSpline uniformly in x direction given the new total number of elements (newTotalnEx).*/
            inline void uniformlyRefineNurbs(int newTotalnEx){_uniformlyRefineNurbs(newTotalnEx, -1, -1);};
            /*! \brief h-Refine Nurbs/BSpline uniformly in x and y directions given the new total number of elements per direction (newTotalnEx and newTotalnEy, respectively).*/
            inline void uniformlyRefineNurbs(int newTotalnEx, int newTotalnEy){_uniformlyRefineNurbs(newTotalnEx, newTotalnEy, -1);};
            /*! \brief h-Refine Nurbs/BSpline uniformly in x, y and z directions given the new total number of elements per direction (newTotalnEx, newTotalnEy and newTotalnEz, respectively).*/
            inline void uniformlyRefineNurbs(int newTotalnEx, int newTotalnEy, int newTotalnEz){_uniformlyRefineNurbs(newTotalnEx, newTotalnEy, newTotalnEz);};

            //Subdivide
            /*! \brief Subdivide Nurbs/BSpline each knot span given the level of subdivision (subLevel).*/
            inline void subdivideNurbs(int subLevel)
            {
                if (_pDim == 1)
                    subdivideNurbs(subLevel, 0, 0);
                else if (_pDim == 2)
                    subdivideNurbs(subLevel, subLevel, 0);
                else
                    subdivideNurbs(subLevel, subLevel, subLevel);
            };
            /*! \brief Subdivide Nurbs/BSpline each knot span in x and y directions given the level of subdivision (subLevelx and subLevely, respectively).*/
            inline void subdivideNurbs(int subLevelx, int subLevely){_subdivideNurbs(subLevelx, subLevely, -1);};
            /*! \brief Subdivide Nurbs/BSpline each knot span in x, y and z directions given the level of subdivision (subLevelx, subLevely and subLevelz, respectively).*/
            inline void subdivideNurbs(int subLevelx, int subLevely, int subLevelz){_subdivideNurbs(subLevelx, subLevely, subLevelz);};

            //Degree elevate
            /*! \brief Degree elevate Nurbs/BSpline in x direction given the order increment (orderIncX).*/
            inline void degreeElevateNurbs(int orderIncX){_degreeElevateNurbs(orderIncX, -1, -1);};
            /*! \brief Degree elevate Nurbs/BSpline in x and y directions given the order increment per direction (orderIncX and orderIncY, respectively).*/
            inline void degreeElevateNurbs(int orderIncX, int orderIncY){_degreeElevateNurbs(orderIncX, orderIncY, -1);};
            /*! \brief Degree elevate Nurbs/BSpline in x, y and z directions given the order increment per direction (orderIncX, orderIncY and orderIncZ, respectively).*/
            inline void degreeElevateNurbs(int orderIncX, int orderIncY, int orderIncZ){_degreeElevateNurbs(orderIncX, orderIncY, orderIncZ);};

            /** @} */ // end of Nurbs transformations


            /** @name Element stretch
             *    Functions to stretch elements within the generated geometry
             *  @{ */
            //Symmetric
            /*! \brief Stretch elements symmetrically in x direction by a ratio (ratioX). A positive ratio stretches the elements in the center, compressing the exterior ones, and vice versa.*/
            inline void stretchElemsSymmetricX(double ratioX){stretchElemsSymmetric(ratioX, 0.0, 0.0);};
            /*! \brief Stretch elements symmetrically in y direction by a ratio (ratioY). A positive ratio stretches the elements in the center, compressing the exterior ones, and vice versa.*/
            inline void stretchElemsSymmetricY(double ratioY){stretchElemsSymmetric(0.0, ratioY, 0.0);};
            /*! \brief Stretch elements symmetrically in z direction by a ratio (ratioZ). A positive ratio stretches the elements in the center, compressing the exterior ones, and vice versa.*/
            inline void stretchElemsSymmetricZ(double ratioZ){stretchElemsSymmetric(0.0, 0.0, ratioZ);};
            /*! \brief Stretch elements symmetrically in x and y directions by a ratio per direction (ratioX and ratioY, respectively). Positive ratios stretch elements in the center, compressing the exterior ones, and vice versa.*/
            inline void stretchElemsSymmetricXY(double ratioX, double ratioY){stretchElemsSymmetric(ratioX, ratioY, 0.0);};
            /*! \brief Stretch elements symmetrically in every direction by a ratio (ratio). Positive ratios stretch elements in the center, compressing the exterior ones, and vice versa.*/
            inline void stretchElemsSymmetric(double ratio){stretchElemsSymmetric(ratio, ratio, ratio);};
            /*! \brief Stretch elements symmetrically in x, y and z directions by a ratio per direction (ratioX, ratioY and ratioZ, respectively). Positive ratios stretch elements in the center, compressing the exterior ones, and vice versa.*/
            void stretchElemsSymmetric(double ratioX, double ratioY, double ratioZ);

            //Asymmetric
            /*! \brief Stretch elements asymmetrically in x direction by a ratio (ratioX). A positive ratio stretches the elements in positive x direction and vice versa.*/
            inline void stretchElemsAsymmetricX(double ratioX){stretchElemsAsymmetric(ratioX, 0.0, 0.0);};
            /*! \brief Stretch elements asymmetrically in y direction by a ratio (ratioY). A positive ratio stretches the elements in positive y direction and vice versa.*/
            inline void stretchElemsAsymmetricY(double ratioY){stretchElemsAsymmetric(0.0, ratioY, 0.0);};
            /*! \brief Stretch elements asymmetrically in z direction by a ratio (ratioZ). A positive ratio stretches the elements in positive z direction and vice versa.*/
            inline void stretchElemsAsymmetricZ(double ratioZ){stretchElemsAsymmetric(0.0, 0.0, ratioZ);};
            /*! \brief Stretch elements asymmetrically in x and y directions by a ratio per direction (ratioX and ratioY, respectively). Positive ratios stretches elements in positive axis direction and vice versa.*/
            inline void stretchElemsAsymmetricXY(double ratioX, double ratioY){stretchElemsAsymmetric(ratioX, ratioY, 0.0);};
            /*! \brief Stretch elements asymmetrically in every direction by a ratio (ratio). Positive ratios stretch elements in positive axis direction and vice versa.*/
            inline void stretchElemsAsymmetric(double ratio){stretchElemsAsymmetric(ratio, ratio, ratio);};
            /*! \brief Stretch elements asymmetrically in x, y and z directions by a ratio per direction (ratioX, ratioY and ratioZ, respectively). Positive ratios stretch elements in positive axis direction and vice versa.*/
            void stretchElemsAsymmetric(double ratioX, double ratioY, double ratioZ);
            //Free
            /*! \brief Stretch elements in x direction following a function (fx).*/
            inline void stretchElemsX(std::function<double(double)> fx){stretchElems(fx, nullptr, nullptr);};
            /*! \brief Stretch elements in y direction following a function (fy).*/
            inline void stretchElemsY(std::function<double(double)> fy){stretchElems(nullptr, fy, nullptr);};
            /*! \brief Stretch elements in z direction following a function (fz).*/
            inline void stretchElemsZ(std::function<double(double)> fz){stretchElems(nullptr, nullptr, fz);};
            /*! \brief Stretch elements in x and y directions following a function per direction (fx and fy).*/
            inline void stretchElemsXY(std::function<double(double)> fx, std::function<double(double)> fy){stretchElems(fx, fy, nullptr);};
            /*! \brief Stretch elements in every direction following a function (f).*/
            inline void stretchElems(std::function<double(double)> f){stretchElems(f, f, f);};
            /*! \brief Stretch elements in x, y and z directions following a function per direction (fx, fy and fz, respectively).*/
            void stretchElems(std::function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz);
            /** @} */ // end of element stretch


            //Auxiliary functions
            void printMesh(const std::string& mssg){_printMesh(mssg);};

    private:

            // Interface functions
            void _saveMesh() override;
            void _reloadMesh() override;

            void _getPRefinedMesh(int orderInc) override;
            void _getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ) override;
            void _getHRefinedMesh(int refLevel) override;
            void _getBoundaryMesh(std::vector<MAxis> vMAx) override;
            /* void _getBoundaryMesh(Teuchos::RCP<DistributedMesh>& disMesh, std::function<double(double)> fx); */
            /* void _getBoundaryMesh(Teuchos::RCP<DistributedMesh>& disMesh, std::function<std::tuple<double, double>(double, double)> fxy); */
            /* void _getBoundaryMesh(Teuchos::RCP<DistributedMesh>& disMesh, std::function<std::tuple<double, double, double>(double, double, double)> fxyz); */

            // Checks
            void _performChecks(int nEx, int nEy, int nEz);
            void _performSettingChecks();
            void _performElementChecks(int nEx, int nEy, int nEz);

            // Utils
            void _printMesh(const std::string& input);
            void _distConnec(int nn, int value);

            // Generators for FE and subdivision surfaces
            void _flipTriangles(int i, int j);
            void _genLineStructMesh(int nEx);
            void _genTriangStructMesh(int nEx, int nEy);
            void _genSquareStructMesh(int nEx, int nEy);
            void _genTetrahStructMesh(int nEx, int nEy, int nEz);
            void _genParallelepStructMesh(int nEx, int nEy, int nEz);
            void _genRuledSurface(int nEx, int nEy, std::vector<double> p1, std::vector<double> p2, std::vector<double> p3, std::vector<double> p4);
            void _genSquareLine(int nEl, double side);


            void _genCircularArc(int nEx, double radius, double phi);
            void _genAnnularSector(int nEx, int nEy, double rInt, double rExt, double phi);
            void _genAnnulus(int nEx, int nEy, double rInt, double rExt);
            void _genDisk_Polar(int nEx, int nEy, double radius);
            void _genDisk_Squared(int nEx, int nEy, double radius);
            void _genQuarterPlateWithCircularHole(int nEx, int nEy, double sidex, double sidey, double radius);
            void _genTorusSurfacePatchSector(int nEx, int nEy, double rGen, double phiIni, double phiEnd, double rDir, double theta);
            void _genTorusSolidSector(int nEx, int nEy, int nEz, double rGen, double rDir, double theta);

            void _genBoundaryMesh(std::vector<MAxis> vMAx);
            void _genDotBoundary(MAxis ax);
            void _genLineBoundary(MAxis ax);
            void _genTriangBoundary(MAxis ax);
            void _genSquareBoundary(MAxis ax);

            void _genPRefinedMesh_nonPeriodic(int orderInc);
            void _genPRefinedMesh(int orderInc);
            void _genHRefinedMesh(int refLevel);

            // Generators for Nurbs and Bsplines
            void _genNurbsCurve(int order_x, std::vector<double> U, std::vector<std::vector<std::vector<std::vector<double>>>> CP);
            void _genNurbsSurface(int order_x, int order_y, std::vector<double> U, std::vector<double> V, std::vector<std::vector<std::vector<std::vector<double>>>> CP);
            void _genNurbsSolid(int order_x, int order_y, int order_z, std::vector<double> U, std::vector<double> V, std::vector<double> W, std::vector<std::vector<std::vector<std::vector<double>>>> CP);

            void _genNurbsClosedCurve(int order_x, std::vector<double> U, std::vector<std::vector<std::vector<std::vector<double>>>> CP);
            void _genNurbsNClosedCurves(int order_x, std::vector<std::vector<double>> vU, std::vector<std::vector<std::vector<std::vector<std::vector<double>>>>> vCP);

            inline void _genNurbsFree(int order_x, std::vector<double> U, std::vector<std::vector<std::vector<std::vector<double>>>> CP){_genNurbsFree(order_x, -1, -1, U, {}, {}, CP);};
            inline void _genNurbsFree(int order_x, int order_y, std::vector<double> U, std::vector<double> V, std::vector<std::vector<std::vector<std::vector<double>>>> CP){_genNurbsFree(order_x, order_y, -1, U, V, {}, CP);};
            void _genNurbsFree(int order_x, int order_y, int order_z, std::vector<double> U, std::vector<double> V, std::vector<double> W, std::vector<std::vector<std::vector<std::vector<double>>>> CP);

            void _genBezierCurve();
            void _genBezierSurface();
            void _genBezierSolid();

            void _genCircularArcNurbs(int nEx, double radius, double phi);
            void _genAnnularSectorNurbs(int nEx, int nEy, double rInt, double rExt, double phi);
            void _genAnnulusNurbs(int nEx, int nEy, double rInt, double rExt);
            void _genDiskNurbs_Polar(int nEx, int nEy, double radius);
            void _genDiskNurbs_Squared(int nEx, int nEy, double radius);
            void _genQuarterPlateWithCircularHoleNurbs(int nEx, int nEy, double sidex, double sidey, double radius);
            void _genTorusSurfacePatchSectorNurbs(int nEx, int nEy, double rGen, double phiIni, double phiEnd, double rDir, double theta);
            void _genTorusSolidSectorNurbs(int nEx, int nEy, int nEz, double rGen, double rDir, double theta);
            void _genQuarterTorusSolidNurbs(int nEx, int nEy, int nEz, double rDisk, double rCircle);
            void _genRuledSurfaceNurbs(int nEx, int nEy, std::vector<double> p1, std::vector<double> p2, std::vector<double> p3, std::vector<double> p4);
            void _genSquareLineNurbs(int nEl, double side);
            void _genPRefinedMeshNurbs(int orderIncX, int orderIncY, int orderIncZ);
            void _genHRefinedMeshNurbs(int refLevel);

            // Transformations for every basis function
            void _reorderConnec();
            void _reorderConnecTriang();
            void _reorderConnecSquare();
            void _reorderConnecTetrah();
            void _reorderConnecParallelep();
            void _periodic();

            // Transformations for FE and subdivision surfaces
            void _stretchElems(std::function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz);
            void _unclampCurve();
            void _unclampSurface(Axis axis);
            void _unclampSolid(Axis axis);
            void _unclamp(std::vector<Axis> axes);
            void _revolveCurve(int nEy, int order_y, ElemType eType, double phi, std::vector<double> point, std::vector<double> dir);
            void _revolveSurface(int nEz, int order_z, ElemType eType, double phi, std::vector<double> point, std::vector<double> dir);
            void _revolve(int nEr, int order_r, ElemType eType, double phi, std::vector<double> point, std::vector<double> dir);
            void _periodicCurve();
            void _periodicSurface();
            void _periodicSolid();
            void _extrudeSurfaceLinear(int nEz, double height);
            void _threeRefine(std::map<int, int> nodeSubdivLevels);
            void _hRefine(std::map<int, int> nodeSubdivLevels);
            void _hangingNodesConstraints();

            // Transformations for Nurbs and Bsplines
            void _refineNurbsCurve(std::vector<double> X);
            void _refineNurbsSurface(std::vector<double> X, std::vector<double> Y);
            void _refineNurbsSolid(std::vector<double> X, std::vector<double> Y, std::vector<double> Z);

            void _uniformlyRefineNurbsCurve(int nEx);
            void _uniformlyRefineNurbsSurface(int nEx, int nEy);
            void _uniformlyRefineNurbsSolid(int nEx, int nEy, int nEz);
            void _uniformlyRefineNurbs(int nEx, int nEy, int nEz);

            void _subdivideNurbsCurve(int levelx);
            void _subdivideNurbsSurface(int levelx, int levely);
            void _subdivideNurbsSolid(int levelx, int levely, int levelz);
            void _subdivideNurbs(int levelx, int levely, int levelz);

            void _freelyRefineNurbsCurve(int nEx, std::function<double(double)> fx);
            void _freelyRefineNurbsSurface(int nEx, int nEy, std::function<double(double)> fx, std::function<double(double)> fy);
            void _freelyRefineNurbsSolid(int nEx, int nEy, int nEz, std::function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz);
            void _freelyRefineNurbs(int nEx_new, int nEy_new, int nEz_new, std::function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz, bool saveHist);


            void _degreeElevateNurbsCurve(int orderIncX);
            void _degreeElevateNurbsSurface(int orderIncX, int orderIncY);
            void _degreeElevateNurbsSolid(int orderIncX, int orderIncY, int orderIncZ);
            void _degreeElevateNurbs(int orderIncX, int orderIncY, int orderIncZ);

            void _unclampNurbsCurve();
            void _unclampNurbsSurface(int unclampX, int unclampY);
            void _unclampNurbsSolid(int unclampX, int unclampY, int unclampZ);
            void _unclampNurbs(std::vector<Axis> axes);

            void _revolveNurbsCurve(int nEy, int order_y, double phi, std::vector<double> point, std::vector<double> dir);
            void _revolveNurbsSurface(int nEz, int order_z, double phi, std::vector<double> point, std::vector<double> dir);
            void _revolveNurbs(int nEr, int order_r, double phi, std::vector<double> point, std::vector<double> dir);

            void _periodicCurveNurbs();
            void _periodicSurfaceNurbs();
            void _periodicSolidNurbs();

            void _extrudeSurfaceLinearNurbs(int nEz, double height);

            //Test distributed
            std::map<int, int> _mapEl;
            void _genElementMap();
            int _getElem(int e);


            //Min
            ElemType _eType_min{ElemType::Undefined};
            std::vector<std::vector<std::vector<std::vector<double>>>> _CP_min;
            std::vector<double> _uKnot_min;
            std::vector<double> _vKnot_min;
            std::vector<double> _wKnot_min;

            //Copy (temporal) variables
            int _nDim_tmp{};
            int _bfOrder_tmp{};
            int _bfOrderX_tmp{}, _bfOrderY_tmp{}, _bfOrderZ_tmp{};
            int _bfOrderX_min_tmp{-1}, _bfOrderY_min_tmp{-1}, _bfOrderZ_min_tmp{-1};
            bool _isBfOrderSubSet_tmp{false};
            ElemType _eType_tmp{ElemType::Undefined};
            ElemType _eType_min_tmp{ElemType::Undefined};
            BasisFuncType _bfType_tmp{BasisFuncType::Undefined};

            std::vector<double> _x_nodes_tmp;
            std::vector<double> _weights_tmp;
            std::vector<double> _uKnot_tmp;
            std::vector<double> _vKnot_tmp;
            std::vector<double> _wKnot_tmp;
            std::vector<double> _uKnot_min_tmp;
            std::vector<double> _vKnot_min_tmp;
            std::vector<double> _wKnot_min_tmp;
            std::vector<int> _connec_tmp;
            std::vector<int> _creases_tmp;
            std::vector<int> _eflags_tmp;
            std::vector<int> _elMap_newToOld_tmp;

            int _nPts_tmp{};
            int _nElem_tmp{};
            int _loc_nPts_tmp{};
            int _loc_nElem_tmp{};
            int _nVert_tmp{};
            int _pDim_tmp{};
            int _nCreases_tmp = 2;
            int _nEFlags_tmp = 1;

            int _nEx_tmp = -1;
            int _nEy_tmp = -1;
            int _nEz_tmp = -1;

            bool _hRefinedMesh_tmp = false;
            bool _pRefinedMesh_tmp = false;

            bool _unclampedX_tmp{false};
            bool _unclampedY_tmp{false};
            bool _unclampedZ_tmp{false};

            std::vector<std::vector<std::vector<std::vector<double>>>> _CP_tmp;
            std::vector<std::vector<std::vector<std::vector<double>>>> _CP_min_tmp;
            std::deque<std::function<void()>> _history_tmp;
            std::vector<std::string> _history_names_tmp;

            bool _periodicInX_tmp{false};
            bool _periodicInY_tmp{false};
            bool _periodicInZ_tmp{false};
            std::vector<linearConstraint> _linearConstraints_tmp;
    };

}
#endif
