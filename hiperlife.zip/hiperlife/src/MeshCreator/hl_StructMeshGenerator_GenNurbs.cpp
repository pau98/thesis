/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francesco Greco and Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <string>
#include <vector>
#include <functional>
#include <deque>

#include <Teuchos_RCP.hpp>

#include "hl_TypeDefs.h"
#include "hl_Math.h"
#include "hl_Geometry.h"

#include "hl_StructMeshGenerator.h"

using std::cout;
using std::endl;
using std::vector;
using std::runtime_error;

namespace hiperlife
{

    //Basic generators
    void StructMeshGenerator::_genNurbsCurve(int order_x, vector<double> U, vector<vector<vector<vector<double>>>> CP)
    {
        //Checks
        if (CP.size()+order_x+1 != U.size())
            throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of U knots is not compatible with the number of control points.");
        for (auto i = 0u; i < CP.size(); i++)
        {
            if (CP[i].size() != 1)
                throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of knots is not compatible with the number of control points.");
            for (auto j = 0u; j < CP[i].size(); j++)
            {
                if (CP[i][j].size() != 1)
                    throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of knots is not compatible with the number of control points.");
                for (auto k = 0u; k < CP[i][j].size(); k++)
                {
                    if (CP[i][j][k].size() != 4)
                        throw runtime_error("StructMeshGenerator: _genNurbsCurve: The control points should have 3 coordinates plus one weight.");
                }
            }
        }

        //Dimensions
        _pDim = 1;

        //Set element
        _nEx = U.size() - 2*order_x - 1;
        _performElementChecks(_nEx, -1, -1);

        //Order
        _bfOrderX = order_x;
        _bfOrder = _bfOrderX; //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs

        //Vertices
        _nVert = (order_x + 1);

        //Number of corner nodes
        int nx = _nEx + 1;

        //Number of basis functions/control points
        int nnx = _nEx + order_x;
        int nny = 1;
        int nnz = 1;

        //Total number of points (control points) and elements
        _nPts  = nnx;
        _nElem = _nEx;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Knots
        _uKnot.resize(U.size());
        _uKnot = U;

        //Control point vector
        _CP.clear();
        _CP.resize(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        _CP = CP;

        //Nodal (control point) coordinates
        int n = 0;
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        if (_bfType == BasisFuncType::Nurbs)
            _weights.resize(_nPts, 0.0);
        // _weights.resize(_loc_nPts, 0.0);
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        _x_nodes[_loc_nPts * 0 + locN] = _CP[i][j][k][0];
                        _x_nodes[_loc_nPts * 1 + locN] = _CP[i][j][k][1];
                        _x_nodes[_loc_nPts * 2 + locN] = _CP[i][j][k][2];
                        // _weights[_loc_nPts * 0 + locN] = _CP[i][j][k][3];
                    }
                    if (_bfType == BasisFuncType::Nurbs)
                        _weights[_nPts * 0 + n] = _CP[i][j][k][3];
                    n++;
                }
            }
        }

        //Connectivity
        _connec.clear();
        _connec.resize(static_cast<unsigned long>(_loc_nElem * _nVert), 0);
        int nn = 0;
        for (int eX = 0; eX < nx - 1; eX++)
        {
            for (int i = 0; i < _bfOrderX+1; i++)
            {
                _distConnec(nn, eX+i);
                nn++;
            }
        }

        //Creases
        _creases.clear();
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        nn = 0;
        for (int i = 0; i < nnx; i++)
        {
            if(_disPts.isItemInPart(nn))
            {
                int locN = _disPts.locIdx(nn);
                // Edges = 1
                if(i==0)
                    _creases[_loc_nPts * 0 + locN] = 1;
                else if(i==ex)
                    _creases[_loc_nPts * 0 + locN] = 1;
                else
                    _creases[_loc_nPts * 0 + locN] = 0;
                // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                if(i==0)
                    _creases[_loc_nPts * 1 + locN] = 2;
                else if(i==ex)
                    _creases[_loc_nPts * 1 + locN] = 3;
                else
                    _creases[_loc_nPts * 1 + locN] = -1;
            }
            nn++;
        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);
        for (int eX = 0; eX < nx - 1; eX++)
        {
            if (_disElem.isItemInPart(eX))
                _eflags[_disElem.locIdx(eX)] = eX;
        }

        //Impose periodicity
        _periodic();
    }

    void StructMeshGenerator::_genNurbsClosedCurve(int order_x, vector<double> U, vector<vector<vector<vector<double>>>> CP)
    {
        //Checks
        // if (CP.size()+order_x+1 != U.size())
        //     throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of U knots is not compatible with the number of control points.");
        // for (auto i = 0u; i < CP.size(); i++)
        // {
        //     if (CP[i].size() != 1)
        //         throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of knots is not compatible with the number of control points.");
        //     for (auto j = 0u; j < CP[i].size(); j++)
        //     {
        //         if (CP[i][j].size() != 1)
        //             throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of knots is not compatible with the number of control points.");
        //         for (auto k = 0u; k < CP[i][j].size(); k++)
        //         {
        //             if (CP[i][j][k].size() != 4)
        //                 throw runtime_error("StructMeshGenerator: _genNurbsCurve: The control points should have 3 coordinates plus one weight.");
        //         }
        //     }
        // }

        //Dimensions
        _pDim = 1;

        //Set element
        _nEx = U.size() - 1;
        _performElementChecks(_nEx, -1, -1);

        //Order
        _bfOrderX = order_x;
        _bfOrder = _bfOrderX; //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs

        //Vertices
        _nVert = (order_x + 1);

        //Number of corner nodes
        int nx = _nEx + 1;

        //Number of basis functions/control points
        int nnx = _nEx; // + order_x;
        int nny = 1;
        int nnz = 1;

        //Total number of points (control points) and elements
        _nPts  = _nEx;
        _nElem = _nEx;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Knots
        vector<double> UU(U.size()+2*_bfOrder,0);
        UU[0] = U[_nEx-3]-U[_nEx];
        UU[1] = U[_nEx-2]-U[_nEx];
        UU[2] = U[_nEx-1]-U[_nEx];

        for (int ii = 0; ii < UU.size()-3; ii++)
        {
            if (ii < _nEx)
                UU[ii+3] = U[ii]; 
            else
            {
                UU[ii+3] = U[ii%_nEx]+U[_nEx];
                // cout << ii << " " << ii%_nEx << endl;
            }
        }
        // for (int ii = 0; ii < UU.size(); ii++)
        // {
        //     cout << "UU("<< ii << "): "<< UU[ii] << endl;
        // }

        // UU[0] = 0; //U[_nEx-3]-U[_nEx];
        // UU[1] = 0; //U[_nEx-2]-U[_nEx];
        // UU[2] = 0; //U[_nEx-1]-U[_nEx];
        _uKnot.resize(UU.size());
        _uKnot = UU;

        //Control point vector
        _CP.clear();
        _CP.resize(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        _CP = CP;

        //Nodal (control point) coordinates
        int n = 0;
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);

        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        _x_nodes[_loc_nPts * 0 + locN] = _CP[i][j][k][0];
                        _x_nodes[_loc_nPts * 1 + locN] = _CP[i][j][k][1];
                        _x_nodes[_loc_nPts * 2 + locN] = _CP[i][j][k][2];
                    }
                    n++;
                }
            }
        }
        // cout << "Local number of elements: " << _loc_nElem << endl;
        // cout << "Local number of Points: " << _loc_nPts << endl;
        //Connectivity
        _connec.clear();
        _connec.resize(static_cast<unsigned long>(_loc_nElem * _nVert), 0);
        int nn = 0;
        for (int eX = 0; eX < _nElem; eX++) // Number of elements
        {
            for (int i = 0; i < _bfOrderX+1; i++) // Element node
            {
                int el = nn/_nVert;
                if (_disElem.isItemInPart(el) == true)
                {
                    int locEl  = _disElem.locIdx(el);
                    int numNbor = nn % _nVert;

                    _connec[locEl * _nVert + numNbor] = (eX+i)%_nElem;
                }   
                // _distConnec(nn, eX+i);
                nn++;
            }
        }

        //Creases
        _creases.clear();
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        nn = 0;
        for (int i = 0; i < nnx; i++)
        {
            if(_disPts.isItemInPart(nn))
            {
                int locN = _disPts.locIdx(nn);
                _creases[_loc_nPts * 0 + locN] = 0;
                _creases[_loc_nPts * 1 + locN] = -1;
            }
            nn++;
        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);
        for (int eX = 0; eX < nx - 1; eX++)
        {
            if (_disElem.isItemInPart(eX))
                _eflags[_disElem.locIdx(eX)] = eX;
        }

        //Impose periodicity
        _periodic();
    }

    void StructMeshGenerator::_genNurbsNClosedCurves(int order_x, vector<vector<double>> vU, vector<vector<vector<vector<vector<double>>>>> vCP)
    {
        //Checks
        // if (CP.size()+order_x+1 != U.size())
        //     throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of U knots is not compatible with the number of control points.");
        // for (auto i = 0u; i < CP.size(); i++)
        // {
        //     if (CP[i].size() != 1)
        //         throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of knots is not compatible with the number of control points.");
        //     for (auto j = 0u; j < CP[i].size(); j++)
        //     {
        //         if (CP[i][j].size() != 1)
        //             throw runtime_error("StructMeshGenerator: _genNurbsCurve: The number of knots is not compatible with the number of control points.");
        //         for (auto k = 0u; k < CP[i][j].size(); k++)
        //         {
        //             if (CP[i][j][k].size() != 4)
        //                 throw runtime_error("StructMeshGenerator: _genNurbsCurve: The control points should have 3 coordinates plus one weight.");
        //         }
        //     }
        // }

        //N curves
        int nC = vU.size();

        //Dimensions
        _pDim = 1;

        
        //Set element
        _nEx = 0;
        vector<int> vnEx(nC);
        int uSize = 0;
        for (int i = 0; i < nC; i++)
        {
            _nEx += vU[i].size() - 1;
            vnEx[i] = vU[i].size() - 1;
            uSize += vU[i].size()+2.*order_x;
            // cout << "U i size: " << vU[i].size() <<endl;
            // cout << uSize <<" " << order_x << endl;
        }
        _performElementChecks(_nEx, -1, -1);
        // cout << "U size: " << uSize<<endl;;
        //Order
        _bfOrderX = order_x;
        _bfOrder = _bfOrderX; //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs

        //Vertices
        _nVert = (order_x + 1);

        //Number of corner nodes
        int nx = _nEx + 1;

        //Number of basis functions/control points
        int nnx = _nEx; // + order_x;
        int nny = 1;
        int nnz = 1;

        //Total number of points (control points) and elements
        _nPts  = _nEx;
        _nElem = _nEx;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Knots
        vector<double> UU(uSize);
        int Uprev = 0;
        for (int i = 0; i < nC; i++)
        {
            vector<double> U = vU[i];
            UU[0+Uprev] = U[vnEx[i]-3]-U[vnEx[i]];
            UU[1+Uprev] = U[vnEx[i]-2]-U[vnEx[i]];
            UU[2+Uprev] = U[vnEx[i]-1]-U[vnEx[i]];
  
            for (int ii = 0; ii < U.size()+3; ii++)
            {
                if (ii < vnEx[i])
                    UU[ii+3+Uprev] = U[ii]; 
                else
                {
                    UU[ii+3+Uprev] = U[ii%vnEx[i]]+U[vnEx[i]];
                }
            }
            Uprev += U.size()+2*3;
            // cout << Uprev << endl;
        }
        // for (int ii = 0; ii < UU.size(); ii++)
        // {
        //     cout << "UU("<< ii << "): "<< UU[ii] << endl;
        // }


        _uKnot.resize(UU.size());
        _uKnot = UU;

        //Control point vector
        _CP.clear();
        _CP.resize(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        vector<vector<vector<vector<double>>>> CCP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        int Eprev = 0;
        for (int i = 0; i < nC; i++)
        {
            vector<vector<vector<vector<double>>>> CP = vCP[i];
            for (int ii = 0; ii < vnEx[i]; ii++)
            {
                CCP[ii+Eprev] = CP[ii]; 
            }
            Eprev += vnEx[i];
        }

        _CP = CCP;

        //Nodal (control point) coordinates
        int n = 0;
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);

        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        _x_nodes[_loc_nPts * 0 + locN] = _CP[i][j][k][0];
                        _x_nodes[_loc_nPts * 1 + locN] = _CP[i][j][k][1];
                        _x_nodes[_loc_nPts * 2 + locN] = _CP[i][j][k][2];
                    }
                    n++;
                }
            }
        }

        
        //Connectivity
        _connec.clear();
        _connec.resize(static_cast<unsigned long>(_loc_nElem * _nVert), 0);
        Eprev = 0;
        for (int i = 0; i < nC; i++)
        {
            int nn = 0;
            for (int eX = 0; eX < vnEx[i]; eX++) // Number of elements
            {
                for (int ii = 0; ii < _bfOrderX+1; ii++) // Element node
                {
                    int el = nn/_nVert+Eprev;
                    if (_disElem.isItemInPart(el) == true)
                    {
                        int locEl  = _disElem.locIdx(el);
                        int numNbor = nn % _nVert;

                        _connec[locEl * _nVert + numNbor] = (eX+ii)%vnEx[i]+Eprev;
                    }   
                    // _distConnec(nn, eX+i);
                    nn++;
                }
            }
            Eprev += vnEx[i];
        }

        // for (int i = 0; i < _loc_nElem * _nVert; i++)
        // {
        //     cout << i<<": "<<_connec[i]<<endl;
        // }

        //Creases
        _creases.clear();
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        int nn = 0;
        for (int i = 0; i < nnx; i++)
        {
            if(_disPts.isItemInPart(nn))
            {
                int locN = _disPts.locIdx(nn);
                _creases[_loc_nPts * 0 + locN] = 0;
                _creases[_loc_nPts * 1 + locN] = -1;
            }
            nn++;
        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);
        for (int eX = 0; eX < nx - 1; eX++)
        {
            if (_disElem.isItemInPart(eX))
                _eflags[_disElem.locIdx(eX)] = eX;
        }

        //Impose periodicity
        _periodic();
    }

    void StructMeshGenerator::_genNurbsSurface(int order_x, int order_y, vector<double> U, vector<double> V, vector<vector<vector<vector<double>>>> CP)
    {
        //Checks
        if (CP.size()+order_x+1 != U.size())
            throw runtime_error("StructMeshGenerator: _genNurbsSurface: The number of U knots is not compatible with the number of control points.");
        for (auto i = 0u; i < CP.size(); i++)
        {
            if (CP[i].size()+order_y+1 != V.size())
                throw runtime_error("StructMeshGenerator: _genNurbsSurface: The number of V knots is not compatible with the number of control points.");
            for (auto j = 0u; j < CP[i].size(); j++)
            {
                if (CP[i][j].size() != 1)
                    throw runtime_error("StructMeshGenerator: _genNurbsSurface: The number of knots is not compatible with the number of control points.");
                for (auto k = 0u; k < CP[i][j].size(); k++)
                {
                    if (CP[i][j][k].size() != 4)
                        throw runtime_error("StructMeshGenerator: _genNurbsSurface: The control points should have 3 coordinates plus one weight.");
                }
            }
        }

        //Dimensions
        _pDim = 2;

        //Set elements
        _nEx = U.size() - 2*order_x - 1;
        _nEy = V.size() - 2*order_y - 1;
        _performElementChecks(_nEx, _nEy, -1);

        //Orders
        _bfOrderX = order_x;
        _bfOrderY = order_y;
        _bfOrder = std::max({_bfOrderX, _bfOrderY}); //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs

        //Vertices
        _nVert = (order_x + 1) * (order_y + 1);

        //Number of basis functions/control points
        int nnx = _nEx + order_x;
        int nny = _nEy + order_y;
        int nnz = 1;

        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;

        //Total number of points (control points) and elements
        _nPts  = nnx * nny;
        _nElem = _nEx * _nEy;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Knot vectors
        _uKnot.resize(U.size());
        _uKnot = U;
        _vKnot.resize(V.size());
        _vKnot = V;

        //Control point vector
        _CP.clear();
        _CP.resize(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        _CP = CP;

        //Nodal (control point) coordinates
        int n = 0;
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        if (_bfType == BasisFuncType::Nurbs)
            _weights.resize(_nPts, 0.0);
        // _weights.resize(_loc_nPts, 0.0);
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        _x_nodes[_loc_nPts * 0 + locN] = _CP[i][j][k][0];
                        _x_nodes[_loc_nPts * 1 + locN] = _CP[i][j][k][1];
                        _x_nodes[_loc_nPts * 2 + locN] = _CP[i][j][k][2];
                        // _weights[_loc_nPts * 0 + locN] = _CP[i][j][k][3];
                    }
                    if (_bfType == BasisFuncType::Nurbs)
                        _weights[_nPts * 0 + n] = _CP[i][j][k][3];
                    n++;
                }
            }
        }

        //Connectivity
        _connec.clear();
        _connec.resize(_loc_nElem*_nVert, 0);
        int nn = 0;
        for (int eY = 0; eY < ny - 1; eY++)
        {
            for (int eX = 0; eX < nx - 1; eX++)
            {
                for (int j = 0; j < _bfOrderY+1; j++)
                {
                    for (int i = 0; i < _bfOrderX+1; i++)
                    {
                        _distConnec(nn, nnx*(eY+j) + eX+i);
                        nn++;
                    }
                }
            }
        }

        //Creases
        _creases.clear();
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        int ey = nny - 1;
        nn = 0;
        for (int j = 0; j < nny; j++)
        {
            for (int i = 0; i < nnx; i++)
            {
                if(_disPts.isItemInPart(nn))
                {
                    int locN = _disPts.locIdx(nn);
                    // Creases: Edges = 1; Corners = 2
                    if(i==0 && j==0)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==0 && j == ey)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==ex && j == 0)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==ex && j == ey)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==0)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(j==0)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(i==ex)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(j==ey)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else
                        _creases[_loc_nPts * 0 + locN] = 0;
                    // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                    //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                    if(i==0 && j==0)
                        _creases[_loc_nPts * 1 + locN] = 10;
                    else if(i==0 && j == ey)
                        _creases[_loc_nPts * 1 + locN] = 14;
                    else if(i==ex && j == 0)
                        _creases[_loc_nPts * 1 + locN] = 15;
                    else if(i==ex && j == ey)
                        _creases[_loc_nPts * 1 + locN] = 21;
                    else if(i==0)
                        _creases[_loc_nPts * 1 + locN] = 2;
                    else if(i==ex)
                        _creases[_loc_nPts * 1 + locN] = 3;
                    else if(j==0)
                        _creases[_loc_nPts * 1 + locN] = 5;
                    else if(j==ey)
                        _creases[_loc_nPts * 1 + locN] = 7;
                    else
                        _creases[_loc_nPts * 1 + locN] = -1;
                }
                nn++;
            }
        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);
        for (int eY = 0; eY < ny - 1; eY++)
        {
            for (int eX = 0; eX < nx - 1; eX++)
            {
                int el = eY*_nEx+eX;
                if (_disElem.isItemInPart(el))
                {
                    _eflags[_disElem.locIdx(el)] = el;
                }
            }
        }

        //Impose periodicity
        _periodic();
    }

    void StructMeshGenerator::_genNurbsSolid(int order_x, int order_y, int order_z, vector<double> U, vector<double> V, vector<double> W, vector<vector<vector<vector<double>>>> CP)
    {
        //Checks
        if (CP.size()+order_x+1 != U.size())
            throw runtime_error("StructMeshGenerator: _genNurbsSolid: The number of U knots is not compatible with the number of control points.");
        for (auto i = 0u; i < CP.size(); i++)
        {
            if (CP[i].size()+order_y+1 != V.size())
                throw runtime_error("StructMeshGenerator: _genNurbsSolid: The number of V knots is not compatible with the number of control points.");
            for (auto j = 0u; j < CP[i].size(); j++)
            {
                if (CP[i][j].size()+order_z+1 != W.size())
                    throw runtime_error("StructMeshGenerator: _genNurbsSolid: The number of W knots is not compatible with the number of control points.");
                for (auto k = 0u; k < CP[i][j].size(); k++)
                {
                    if (CP[i][j][k].size() != 4)
                        throw runtime_error("StructMeshGenerator: _genNurbsSolid: The control points should have 3 coordinates plus one weight.");
                }
            }
        }

        //Dimensions
        _pDim = 3;

        //Set elements
        _nEx = static_cast<int>(U.size() - 2 * order_x - 1);
        _nEy = static_cast<int>(V.size() - 2 * order_y - 1);
        _nEz = static_cast<int>(W.size() - 2 * order_z - 1);
        _performElementChecks(_nEx, _nEy, _nEz);

        //Orders
        _bfOrderX = order_x;
        _bfOrderY = order_y;
        _bfOrderZ = order_z;
        _bfOrder = std::max({_bfOrderX, _bfOrderY, _bfOrderZ}); //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs

        //Vertices
        _nVert = (order_x + 1) * (order_y + 1) * (order_z + 1);

        //Number of basis functions/control points
        int nnx = _nEx + order_x;
        int nny = _nEy + order_y;
        int nnz = _nEz + order_z;

        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;
        int nz = _nEz + 1;

        //Total number of points (control points) and elements
        _nPts  = nnx * nny * nnz;
        _nElem = _nEx * _nEy * _nEz;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Knot vectors
        _uKnot.resize(U.size());
        _uKnot = U;
        _vKnot.resize(V.size());
        _vKnot = V;
        _wKnot.resize(W.size());
        _wKnot = W;

        //Control point vector
        _CP.clear();
        _CP.resize(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        _CP = CP;

        //Nodal (control point) coordinates
        int n = 0;
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        if (_bfType == BasisFuncType::Nurbs)
            _weights.resize(_nPts, 0.0);
        // _weights.resize(_loc_nPts, 0.0);
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        _x_nodes[_loc_nPts * 0 + locN] = _CP[i][j][k][0];
                        _x_nodes[_loc_nPts * 1 + locN] = _CP[i][j][k][1];
                        _x_nodes[_loc_nPts * 2 + locN] = _CP[i][j][k][2];
                        // _weights[_loc_nPts * 0 + locN] = _CP[i][j][k][3];
                    }
                    if (_bfType == BasisFuncType::Nurbs)
                        _weights[_nPts * 0 + n] = _CP[i][j][k][3];
                    n++;
                }
            }
        }

        //Connectivity
        vector<vector<vector<int>>> B(nnx, vector<vector<int>>(nny, vector<int>(nnz)));
        n = 0;
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {

                    B[i][j][k] = n;
                    n++;
                }
            }
        }
        _connec.clear();
        _connec.resize(_loc_nElem*_nVert, 0);
        int nn = 0;
        for (int eZ = 0; eZ < nz - 1; eZ++)
        {
            for (int eY = 0; eY < ny - 1; eY++)
            {
                for (int eX = 0; eX < nx - 1; eX++)
                {
                    for (int k = 0; k < _bfOrderZ+1; k++)
                    {
                        for (int j = 0; j < _bfOrderY+1; j++)
                        {
                            for (int i = 0; i < _bfOrderX+1; i++)
                            {
                                _distConnec(nn, nnx*nny*(eZ+k) + nnx*(eY+j) + eX+i);
                                nn++;
                            }
                        }
                    }
                }
            }
        }

        //Creases
        _creases.clear();
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        int ey = nny - 1;
        int ez = nnz - 1;
        nn = 0;
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if(_disPts.isItemInPart(nn))
                    {
                        int locN = _disPts.locIdx(nn);
                        //Creases: Edges = 1; Corners = 2; Faces = 3
                        if(i==0 && j==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==ey && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==ey && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==0 && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==ey && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==0 && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==ey && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0 && j == ey)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && j == 0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && j == ey)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0 && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && k == 0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==0 && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==ey && k == 0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==ey && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(j==0)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(k==0)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(i==ex)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(j==ey)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(k==ez)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else
                            _creases[_loc_nPts * 0 + locN] = 0;
                        // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                        //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                        //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                        if(i==0 && j==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 2*5*11;
                        else if(i==0 && j==0 && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 2*5*13;
                        else if(i==0 && j==ey && k==0)
                            _creases[_loc_nPts * 1 + locN] = 2*7*11;
                        else if(i==0 && j==ey && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 2*7*13;
                        else if(i==ex && j==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 3*5*11;
                        else if(i==ex && j==0 && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 3*5*13;
                        else if(i==ex && j==ey && k==0)
                            _creases[_loc_nPts * 1 + locN] = 3*7*11;
                        else if(i==ex && j==ey && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 3*7*13;
                        else if(i==0 && j==0)
                            _creases[_loc_nPts * 1 + locN] = 2*5;
                        else if(i==0 && j == ey)
                            _creases[_loc_nPts * 1 + locN] = 2*7;
                        else if(i==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 2*11;
                        else if(i==0 && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 2*13;
                        else if(i==ex && j == 0)
                            _creases[_loc_nPts * 1 + locN] = 3*5;
                        else if(i==ex && j == ey)
                            _creases[_loc_nPts * 1 + locN] = 3*7;
                        else if(i==ex && k == 0)
                            _creases[_loc_nPts * 1 + locN] = 3*11;
                        else if(i==ex && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 3*13;
                        else if(j==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 5*11;
                        else if(j==0 && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 5*13;
                        else if(j==ey && k == 0)
                            _creases[_loc_nPts * 1 + locN] = 7*11;
                        else if(j==ey && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 7*13;
                        else if(i==0)
                            _creases[_loc_nPts * 1 + locN] = 2;
                        else if(i==ex)
                            _creases[_loc_nPts * 1 + locN] = 3;
                        else if(j==0)
                            _creases[_loc_nPts * 1 + locN] = 5;
                        else if(j==ey)
                            _creases[_loc_nPts * 1 + locN] = 7;
                        else if(k==0)
                            _creases[_loc_nPts * 1 + locN] = 11;
                        else if(k==ez)
                            _creases[_loc_nPts * 1 + locN] = 13;
                        else
                            _creases[_loc_nPts * 1 + locN] = -1;
                    }
                    nn++;
                }
            }

        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);
        for (int eZ = 0; eZ < nz - 1; eZ++)
        {
            for (int eY = 0; eY < ny - 1; eY++)
            {
                for (int eX = 0; eX < nx - 1; eX++)
                {
                    int el = eZ*_nEx*_nEy + eY*_nEx+eX;
                    if (_disElem.isItemInPart(el))
                    {
                        _eflags[_disElem.locIdx(el)] = el;
                    }
                }
            }
        }

        //Impose periodicity
        _periodic();
    }


    //Free generators
    void StructMeshGenerator::_genNurbsFree(int order_x, int order_y, int order_z, vector<double> U, vector<double> V, vector<double> W, vector<vector<vector<vector<double>>>> CP)
    {
        //Checks
        _performSettingChecks();

        //Save variables
        _bfOrderX_min = order_x;
        _bfOrderY_min = order_y;
        _bfOrderZ_min = order_z;
        _uKnot_min = U;
        _vKnot_min = V;
        _wKnot_min = W;
        _CP_min = CP;
        _eType_min = _eType;

        //Set knots and control points
        if (order_y == -1 && order_z ==-1)
            _genNurbsCurve(order_x, U, CP);
        else if (order_z == -1)
            _genNurbsSurface(order_x, order_y, U, V, CP);
        else
            _genNurbsSolid(order_x, order_y, order_z, U, V, W, CP);

    }

    void StructMeshGenerator::genNurbsFree(vector<double> U, vector<vector<vector<vector<double>>>> CP)
    {

        //Checks
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            throw runtime_error("HPLFE_StructMeshGenerator: genNurbsFree: Basis function type is not Bspline neither Nurbs.");
        _performOrderChecks();
        int nEx = U.size() - 2*_bfOrderX - 1;
        _performElementChecks(nEx, -1, -1);

        //Generate mesh
        _genNurbsFree(_bfOrderX, U, CP);

    }

    void StructMeshGenerator::genBsplinesClosedCurve(vector<double> U, vector<vector<vector<vector<double>>>> CP)
    {

        //Checks
        if ((_bfType != BasisFuncType::BSplines))
            throw runtime_error("HPLFE_StructMeshGenerator: genNurbsFree: Basis function type is not Bspline.");
        _performOrderChecks();
        int nEx = U.size()-1;
        _performElementChecks(nEx, -1, -1);

        //Generate mesh
        _genNurbsClosedCurve(_bfOrderX, U, CP);
    }


    void StructMeshGenerator::genBsplinesNClosedCurves(vector<vector<double>> vU, vector<vector<vector<vector<vector<double>>>>> vCP)
    {

        //Checks
        if ((_bfType != BasisFuncType::BSplines))
            throw runtime_error("HPLFE_StructMeshGenerator: genNurbsFree: Basis function type is not Bspline.");
        _performOrderChecks();

        //N curves
        int nC = vU.size();
        for (int i = 0; i < nC; i++)
        {
            int nEx = vU[i].size()-1;
            _performElementChecks(nEx, -1, -1);
        }

        //Generate mesh
        _genNurbsNClosedCurves(_bfOrderX, vU, vCP);
    }

    void StructMeshGenerator::genNurbsFree(vector<double> U, vector<double> V, vector<vector<vector<vector<double>>>> CP)
    {

        //Checks
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            throw runtime_error("HPLFE_StructMeshGenerator: genNurbsFree: Basis function type is not Bspline neither Nurbs.");
        _performOrderChecks();
        int nEx = U.size() - 2*_bfOrderX - 1;
        int nEy = V.size() - 2*_bfOrderY - 1;
        _performElementChecks(nEx, nEy, -1);

        //Set knots and control points
        _genNurbsFree(_bfOrderX, _bfOrderY, U, V, CP);

    }

    void StructMeshGenerator::genNurbsFree(vector<double> U, vector<double> V, vector<double> W, vector<vector<vector<vector<double>>>> CP)
    {

        //Checks
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            throw runtime_error("HPLFE_StructMeshGenerator: genNurbsFree: Basis function type is not Bspline neither Nurbs.");
        _performOrderChecks();
        int nEx = U.size() - 2*_bfOrderX - 1;
        int nEy = V.size() - 2*_bfOrderY - 1;
        int nEz = W.size() - 2*_bfOrderZ - 1;
        _performElementChecks(nEx, nEy, nEz);

        //Set knots and control points
        _genNurbsFree(_bfOrderX, _bfOrderY, _bfOrderZ, U, V, W, CP);

    }


    //Bezier generators
    void StructMeshGenerator::_genBezierCurve()
    {
        //Define knots
        vector<double> U = {0.0, 0.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(2, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        CP[0][0][0] = {0.0, 0.0, 0.0, 1.0};
        CP[1][0][0] = {1.0, 0.0, 0.0, 1.0};

        //Set knots and control points
        _genNurbsFree(1, U, CP);
    }

    void StructMeshGenerator::_genBezierSurface()
    {
        //Define knots
        vector<double> U = {0.0, 0.0, 1.0, 1.0};
        vector<double> V = {0.0, 0.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(2, vector<vector<vector<double>>>(2, vector<vector<double>>(1, vector<double>(4))));
        CP[0][0][0] = {0.0, 0.0, 0.0, 1.0};
        CP[0][1][0] = {0.0, 1.0, 0.0, 1.0};
        CP[1][0][0] = {1.0, 0.0, 0.0, 1.0};
        CP[1][1][0] = {1.0, 1.0, 0.0, 1.0};

        //Set knots and control points
        _genNurbsFree(1, 1, U, V, CP);

    }

    void StructMeshGenerator::_genBezierSolid()
    {
        //Define knots
        vector<double> U = {0.0, 0.0, 1.0, 1.0};
        vector<double> V = {0.0, 0.0, 1.0, 1.0};
        vector<double> W = {0.0, 0.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(2, vector<vector<vector<double>>>(2, vector<vector<double>>(2, vector<double>(4))));
        CP[0][0][0] = {0.0, 0.0, 0.0, 1.0};
        CP[1][0][0] = {1.0, 0.0, 0.0, 1.0};
        CP[0][1][0] = {0.0, 1.0, 0.0, 1.0};
        CP[1][1][0] = {1.0, 1.0, 0.0, 1.0};
        CP[0][0][1] = {0.0, 0.0, 1.0, 1.0};
        CP[1][0][1] = {1.0, 0.0, 1.0, 1.0};
        CP[0][1][1] = {0.0, 1.0, 1.0, 1.0};
        CP[1][1][1] = {1.0, 1.0, 1.0, 1.0};

        //Set knots and control points
        _genNurbsFree(1, 1, 1, U, V, W, CP);

    }

    //Other generators
    void StructMeshGenerator::_genSquareLineNurbs(int nEl, double side)
    {
        //Checks
        _performOrderChecks();

        //Save order
        int orderIncX = _bfOrderX - 1;

        //Define knots
        vector<double> U = {0.0, 0.0, 0.25, 0.50, 0.75, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(5, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        CP[0][0][0] = {0,0,0, 1.0};
        CP[1][0][0] = {side,0,0, 1.0};
        CP[2][0][0] = {side,side,0, 1.0};
        CP[3][0][0] = {0,side,0, 1.0};
        CP[4][0][0] = {0,0,0, 1.0};

        //Set knots and control points
        _genNurbsFree(1, U, CP);

        //Order elevate
        if (orderIncX > 0)
            degreeElevateNurbs(orderIncX);

        //Refine
        uniformlyRefineNurbs(4*nEl);
    }

    void _makeNurbsCircle(vector<double> O, vector<double> X, vector<double> Y, double r, double ths, double the, vector<double> &U, vector<vector<vector<vector<double>>>> &CP)
    {
        //From Piegl page 308 Algorithm A7.1

        //Get angle
        if (the < ths)
            the = 2.0*M_PI + the;
        double theta = the-ths;

        // Get number of arcs
        int narcs{};
        if (theta <= M_PI/2.0)
            narcs = 1;
        else if (theta <= M_PI)
            narcs = 2;
        else if (theta <= 3.0*M_PI/2.0)
            narcs = 3;
        else
            narcs = 4;

        //dtheta/2 is base angle
        double dtheta = theta/narcs;

        //Control points (n+1)
        int n = 2*narcs;

        //Create control points for narcs segments
        CP.resize(n+1, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        double w1 = cos(dtheta/2.0);
        vector<double> PO(3), P1(3), P2(3), TO(3), T1(3), T2(3);
        for (int d = 0; d < 3; d++)
        {
            PO[d] = O[d] + r*cos(ths)*X[d] + r*sin(ths)*Y[d];
            TO[d] = -sin(ths)*X[d] + cos(ths)*Y[d];
            CP[0][0][0][d] = PO[d];
        }
        CP[0][0][0][3] = 1.0;
        int index = 0;
        double angle = ths;
        for (int i = 1; i <= narcs; i++)
        {
            angle = angle + dtheta;
            for (int d = 0; d < 3; d++)
            {
                P2[d] = O[d] + r*cos(angle)*X[d] + r*sin(angle)*Y[d];
                CP[index+2][0][0][d] = P2[d];
                T2[d] = -sin(angle)*X[d] + cos(angle)*Y[d];
            }
            CP[index+2][0][0][3] = 1.0;
            int ierr = SGeometry::intersect3DLines(PO, TO, P2, T2, P1);
            if (ierr == 0)
                throw runtime_error("StructMeshGenerator::makeNurbsCircle: Lines do not intersect");
            for (int d = 0; d < 3; d++)
                CP[index+1][0][0][d] = P1[d]; //w1*P1[d];
            CP[index+1][0][0][3] = w1;
            index = index + 2;
            if (i < narcs)
            {
                PO = P2;
                TO = T2;
            }
        }

        //Create knot vector
        U.resize(6+2*(narcs-1));
        int j = 2*narcs+1;
        for (int i = 0; i < 3; i++)
        {
            U[i] = 0.0;
            U[i+j] = 1.0;
        }
        switch (narcs)
        {
            case 1:
                break;
            case 2:
                U[3] = U[4] = 0.5;
                break;
            case 3:
                U[3] = U[4] = 1.0/3.0;
                U[5] = U[6] = 2.0/3.0;
                break;
            case 4:
                U[3] = U[4] = 0.25;
                U[5] = U[6] = 0.5;
                U[7] = U[8] = 0.75;
                break;
        }

    }

    void StructMeshGenerator::_genCircularArcNurbs(int nEx, double radius, double phi)
    {
        //Checks
        _performOrderChecks();
        if (_bfOrderX < 2)
            throw runtime_error("StructMeshGenerator: CircularArc currently works only with order = 2.");
        if (phi > 2*M_PI)
            throw runtime_error("StructMeshGenerator: CircularArc currently works only with phi <= 2*PI.");

        //Save order
        int orderIncX = _bfOrderX - 2;

        if (phi == M_PI)
        {
            if (_bfOrderX == 2) // From Piegl1997, Figure 7.20
            {
                // Warning
                if (nEx%2 != 0)
                    cout << "_genCircularArcNurbs::Warning. Please, consider using an even number of elements or a higher order basis function." << endl;

                // Define knots
                vector<double> U = {0.0, 0.0, 0.0, 0.5, 1.0, 1.0, 1.0};

                // Define control points
                vector<vector<vector<vector<double>>>> CP(4, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
                CP[0][0][0] = {1.0, 0.0, 0.0, 1.0};
                CP[1][0][0] = {1.0, 1.0, 0.0, 0.5};
                CP[2][0][0] = {-1.0, 1.0, 0.0, 0.5};
                CP[3][0][0] = {-1.0, 0.0, 0.0, 1.0};

                // Set knots and control points
                _genNurbsFree(2, U, CP);
            }
            else // From Piegl1997, Example 7.7
            {
                // Recompute increment
                orderIncX = _bfOrderX - 3;
                // Define knots
                vector<double> U = {0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0};

                // Define control points
                vector<vector<vector<vector<double>>>> CP(4, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
                CP[0][0][0] = {1.0, 0.0, 0.0, 1.0};
                CP[1][0][0] = {1.0, 2.0, 0.0, 1.0/3.0};
                CP[2][0][0] = {-1.0, 2.0, 0.0, 1.0/3.0};
                CP[3][0][0] = {-1.0, 0.0, 0.0, 1.0};

                // Set knots and control points
                _genNurbsFree(3, U, CP);
            }
        }
        else if (phi == 2.0*M_PI)
        {
            // Warning
            cout << "_genCircularArcNurbs::Warning: Please, consider implementing a circle using a basis function of degree higher than two in order to avoid having 4 points with C^1 continuity." << endl;

            // Make Nurbs circle
            vector<double> U;
            vector<vector<vector<vector<double>>>> CP;
            _makeNurbsCircle({0, 0, 0}, {1, 0, 0}, {0, 1, 0}, radius, 0.0, phi, U, CP);

            // Set knots and control points
            _genNurbsFree(2, U, CP);
        }
        else // From Piegl1997, section 7.3
        {
            // Compute data
            double cord = 2.0*radius*sin(phi/2.0);
            double sagi = radius*(1.0-cos(phi/2.0));
            double e = cord/2.0;
            double alpha = 2.0*atan2(sagi, e);
            double h = e*tan(alpha);
            double w1 = cos(alpha);

            // Define knots
            vector<double> U = {0.0, 0.0, 0.0, 1.0, 1.0, 1.0};

            // Define control points
            vector<vector<vector<vector<double>>>> CP(3, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
            CP[0][0][0] = {  e, 0.0, 0.0, 1.0};
            CP[1][0][0] = {0.0,   h, 0.0,  w1};
            CP[2][0][0] = { -e, 0.0, 0.0, 1.0};

            // Set knots and control points
            _genNurbsFree(2, U, CP);

            // Start at (0,0)
            translateY(radius-sagi);
            if (phi < M_PI)
                rotate2D(phi/2.0-M_PI/2.0);
            else if (phi < 3.0*M_PI/4.0)
                rotate2D(-phi/2.0+M_PI/2.0);
            else
                rotate2D(phi/2.0);
        }

        // Order elevate
        if (orderIncX > 0)
            degreeElevateNurbs(orderIncX);

        // Refine
        uniformlyRefineNurbs(nEx);

        // Unclamp it
        if (phi == 2.0*M_PI)
            unclamp(Axis::Xaxis);
    }

    void StructMeshGenerator::_genRuledSurfaceNurbs(int nEx, int nEy, vector<double> p1, vector<double> p2, vector<double> p3, vector<double> p4)
    {
        //Checks
        _performOrderChecks();

        //Save order
        int orderIncX = _bfOrderX - 1;
        int orderIncY = _bfOrderY - 1;

        //Define knots
        vector<double> U = {0.0, 0.0, 1.0, 1.0};
        vector<double> V = {0.0, 0.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(2, vector<vector<vector<double>>>(2, vector<vector<double>>(1, vector<double>(4))));
        CP[0][0][0] = {p1[0], p1[1], p1[2], 1.0};
        CP[1][0][0] = {p2[0], p2[1], p2[2], 1.0};
        CP[0][1][0] = {p4[0], p4[1], p4[2], 1.0};
        CP[1][1][0] = {p3[0], p3[1], p3[2], 1.0};

        //Set knots and control points
        _genNurbsFree(1, 1, U, V, CP);

        //Order elevate
        if (orderIncX > 0 || orderIncY > 0)
            degreeElevateNurbs(orderIncX, orderIncY);

        //Refine
        uniformlyRefineNurbs(nEx, nEy);
    }

    void StructMeshGenerator::_genAnnularSectorNurbs(int nEx, int nEy, double rInt, double rExt, double phi)
    {
        //Checks
        _performOrderChecks();
        if (_bfOrderX < 1 || _bfOrderY < 2)
            throw runtime_error("StructMeshGenerator: AnnularSectorNurbs minimum orders are order_x = 1 and order_y = 2.");
        if (phi > 2.0*M_PI)
            throw runtime_error("StructMeshGenerator: AnnularSectorNurbs currently works only with phi <= 2*PI.");

        //Save requested order
        int order_y = _bfOrderY;
        _bfOrderY = -1;
        _bfOrder = -1;

        //Save element type
        ElemType eType = _eType;

        //Generate a line
        _eType = ElemType::Line;
        genLine(1, {rInt, 0.0, 0.0}, {rExt, 0.0, 0.0});

        //Revolve around Z axis
        revolve(1, order_y, eType, phi, Axis::Zaxis);

        //Refine
        uniformlyRefineNurbs(nEx, nEy);
    }

    void StructMeshGenerator::_genDiskNurbs_Polar(int nEx, int nEy, double r)
    {
        //Checks
        _performOrderChecks();
        if (_bfOrderX < 2 || _bfOrderY < 1)
            throw runtime_error("StructMeshGenerator: DiskNurbs_Polar minimum orders are order_x = 2 and order_y = 1.");

        //Save requested order
        int order_y = _bfOrderY;
        _bfOrderY = -1;
        _bfOrder = -1;

        //Save element type
        ElemType eType = _eType;

        //Generate a circular arc
        _eType = ElemType::Line;
        genLine(1, r);

        //Revolve around Z axis
        revolve(1, order_y, eType, 2.0*M_PI, Axis::Zaxis);

        //Refine
        uniformlyRefineNurbs(nEx, nEy);
    }

    void StructMeshGenerator::_genDiskNurbs_Squared(int nEx, int nEy, double r)
    {
        //Checks
        _performOrderChecks();
        if (_bfOrderX < 2 || _bfOrderY < 2)
            throw runtime_error("StructMeshGenerator: Disk_Squared currently works only with order = 2.");

        //Save order
        int orderIncX = _bfOrderX-2;
        int orderIncY = _bfOrderY-2;

        //Define knots
        vector<double> U = {0.0, 0.0, 0.0, 1.0, 1.0, 1.0};
        vector<double> V = {0.0, 0.0, 0.0, 1.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(3, vector<vector<vector<double>>>(3, vector<vector<double>>(1, vector<double>(4))));
        CP[0][0][0] = {-r, 0.0, 0.0, 1.0};
        CP[1][0][0] = {-r, -r, 0.0, 1.0/sqrt(2.0)};
        CP[2][0][0] = {0.0, -r, 0.0, 1.0};

        CP[0][1][0] = {-r, r, 0.0, 1.0/sqrt(2.0)};
        CP[1][1][0] = {0.0, 0.0, 0.0, 1.0};
        CP[2][1][0] = {r, -r, 0.0, 1.0/sqrt(2.0)};

        CP[0][2][0] = {0.0, r, 0.0, 1.0};
        CP[1][2][0] = {r, r, 0.0, 1.0/sqrt(2.0)};
        CP[2][2][0] = {r, 0.0, 0.0, 1.0};

        //Set knots and control points
        _genNurbsFree(2, 2, U, V, CP);

        //Order elevate
        if (orderIncX > 0 || orderIncY > 0)
            degreeElevateNurbs(orderIncX, orderIncY);

        //Refine
        uniformlyRefineNurbs(nEx, nEy);

    }

    void StructMeshGenerator::_genQuarterPlateWithCircularHoleNurbs(int nEx, int nEy, double sx, double sy, double r)
    {
        //Checks
        _performOrderChecks();
        if (_bfOrderX < 2 || _bfOrderY < 2)
            throw runtime_error("StructMeshGenerator: QuarterPlateWithCircularHole currently works only with order = 2.");

        //Save order
        int orderIncX = _bfOrderX-2;
        int orderIncY = _bfOrderY-2;

        //Define knots
        vector<double> U = {0.0, 0.0, 0.0, 0.5, 1.0, 1.0, 1.0};
        vector<double> V = {0.0, 0.0, 0.0, 1.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(4, vector<vector<vector<double>>>(3, vector<vector<double>>(1, vector<double>(4))));
        CP[0][0][0] = {-r, 0.0, 0.0, 1.0};
        CP[1][0][0] = {-r, r*(sqrt(2.0)-1.0), 0.0, (1.0+1.0/sqrt(2.0))/2.0};
        CP[2][0][0] = {-r*(sqrt(2.0)-1.0), r, 0.0, (1.0+1.0/sqrt(2.0))/2.0};
        CP[3][0][0] = {0.0, r, 0.0, 1.0};

        CP[0][1][0] = {-2.5/3.0*(sx-r), 0.0, 0.0, 1.0};
        CP[1][1][0] = {-2.5/3.0*(sx-r), 0.75/3.0*(sy-r), 0.0, 1.0};
        CP[2][1][0] = {-0.75/3.0*(sx-r), 2.5/3.0*(sy-r), 0.0, 1.0};
        CP[3][1][0] = {0.0, 2.5/3.0*(sy-r), 0.0, 1.0};

        CP[0][2][0] = {-sx, 0.0, 0.0, 1.0};
        CP[1][2][0] = {-sx, sy, 0.0, 1.0};
        CP[2][2][0] = {-sx, sy, 0.0, 1.0};
        CP[3][2][0] = {0.0, sy, 0.0, 1.0};

        //Set knots and control points
        _genNurbsFree(2, 2, U, V, CP);

        //Order elevate
        if (orderIncX > 0 || orderIncY > 0)
            degreeElevateNurbs(orderIncX, orderIncY);

        //Refine
        uniformlyRefineNurbs(nEx, nEy);

    }

    void StructMeshGenerator::_genTorusSurfacePatchSectorNurbs(int nEx, int nEy, double rGen, double phiIni, double phiEnd, double rDir, double theta)
    {
        //Checks
        _performOrderChecks();
        if (_bfOrderX < 2 || _bfOrderY < 2)
            throw runtime_error("StructMeshGenerator: AnnularSectorNurbs: Minimum order is 2 per direction.");

        //Save requested order
        int order_y = _bfOrderY;
        _bfOrderY = -1;
        _bfOrder = -1;

        //Save element type
        ElemType eType = _eType;

        //Generate a circular arc
        _eType = ElemType::Line;
        genCircularArc(1, rGen, phiIni, phiEnd);

        //Put it vertical and translate it
        rotateX(M_PI/2.0);
        translateX(rDir);

        //Revolve around Z axis
        revolve(1, order_y, eType, theta, Axis::Zaxis);

        //Refine
        uniformlyRefineNurbs(nEx, nEy);
    }

    void StructMeshGenerator::_genTorusSolidSectorNurbs(int nEx, int nEy, int nEz, double rGen, double rDir, double theta)
    {
        //Checks
        _performOrderChecks();
        if ((_bfOrderX < 2) || (_bfOrderY < 2) | (_bfOrderZ < 2))
            throw runtime_error("StructMeshGenerator: AnnularSectorNurbs: Minimum 2 for every direction.");

        //Save requested order
        int order_z = _bfOrderZ;
        _bfOrderZ = -1;
        _bfOrder = -1;

        //Save element type
        ElemType eType = _eType;

        //Generate a disk
        _eType = ElemType::Square;
        genDisk_Squared(1, 1, rGen);

        //Put it vertical and translate it
        rotateX(M_PI/2.0);
        translateX(rDir);

        //Revolve around Z axis
        revolve(1, order_z, eType, theta, Axis::Zaxis);

        //Refine
        uniformlyRefineNurbs(nEx, nEy, nEz);
    }

    void StructMeshGenerator::_genQuarterTorusSolidNurbs(int nEx, int nEy, int nEz, double r, double R)
    {

        //Checks
        _performOrderChecks();
        if (_bfOrderX < 2 || _bfOrderY < 2 || _bfOrderZ < 2)
            throw runtime_error("StructMeshGenerator: QuarterTorusSolidNurbs: works only with order = 2.");

        //Save order
        int orderIncX = _bfOrderX-2;
        int orderIncY = _bfOrderY-2;
        int orderIncZ = _bfOrderZ-2;

        //Define knots
        vector<double> U = {0.0, 0.0, 0.0, 1.0, 1.0, 1.0};
        vector<double> V = {0.0, 0.0, 0.0, 1.0, 1.0, 1.0};
        vector<double> W = {0.0, 0.0, 0.0, 1.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(3, vector<vector<vector<double>>>(3, vector<vector<double>>(3, vector<double>(4))));
        CP[0][0][0] = {R-r, 0.0, 0.0, 1.0};
        CP[1][0][0] = {R-r, 0.0, -r, 1.0/sqrt(2.0)};
        CP[2][0][0] = {R, 0.0, -r, 1.0};
        CP[0][1][0] = {R-r, 0.0, r, 1.0/sqrt(2.0)};
        CP[1][1][0] = {R, 0.0, 0.0, 1.0};
        CP[2][1][0] = {R+r, 0.0, -r, 1.0/sqrt(2.0)};
        CP[0][2][0] = {R, 0.0, r, 1.0};
        CP[1][2][0] = {R+r, 0.0, r, 1.0/sqrt(2.0)};
        CP[2][2][0] = {R+r, 0.0, 0.0, 1.0};

        CP[0][0][1] = {R-r, R-r, 0.0, 1.0/sqrt(2.0)};
        CP[1][0][1] = {R-r, R-r, -r, 1.0/2.0};
        CP[2][0][1] = {R, R, -r, 1.0/sqrt(2.0)};
        CP[0][1][1] = {R-r, R-r, r, 1.0/2.0};
        CP[1][1][1] = {R, R, 0.0, 1.0/sqrt(2.0)};
        CP[2][1][1] = {R+r, R+r, -r, 1.0/2.0};
        CP[0][2][1] = {R, R, r, 1.0/sqrt(2.0)};
        CP[1][2][1] = {R+r, R+r, r, 1.0/2.0};
        CP[2][2][1] = {R+r, R+r, 0.0, 1.0/sqrt(2.0)};

        CP[0][0][2] = {0.0, R-r, 0.0, 1.0};
        CP[1][0][2] = {0.0, R-r, -r, 1.0/sqrt(2.0)};
        CP[2][0][2] = {0.0, R, -r, 1.0};
        CP[0][1][2] = {0.0, R-r, r, 1.0/sqrt(2.0)};
        CP[1][1][2] = {0.0, R, 0.0, 1.0};
        CP[2][1][2] = {0.0, R+r, -r, 1.0/sqrt(2.0)};
        CP[0][2][2] = {0.0, R, r, 1.0};
        CP[1][2][2] = {0.0, R+r, r, 1.0/sqrt(2.0)};
        CP[2][2][2] = {0.0, R+r, 0.0, 1.0};

        //Set knots and control points
        _genNurbsFree(2, 2, 2,  U, V, W, CP);

        //Order elevate
        if (orderIncX > 0 || orderIncY > 0 || orderIncZ > 0)
            degreeElevateNurbs(orderIncX, orderIncY, orderIncZ);

        //Refine
        uniformlyRefineNurbs(nEx, nEy, nEz);

    }


    //p-Refined mesh
    void StructMeshGenerator::_genPRefinedMeshNurbs(int orderIncX, int orderIncY, int orderIncZ)
    {
        //Warning
        cout << "StructMeshGenerator: PRefinedMesh can only be used with straight elements." << endl;

        //Checks
        if (orderIncX <= 0 || orderIncY <= 0 || orderIncZ <= 0)
            throw runtime_error("StructMeshGenerator: _getPRefinedMesh: Currently, the order of BSpline/NURBS can only be increased.");

        //Generate elemental mesh
        _genNurbsFree(_bfOrderX_min, _bfOrderY_min, _bfOrderZ_min, _uKnot_min, _vKnot_min, _wKnot_min, _CP_min);

        //Elevate order
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                _degreeElevateNurbsCurve(orderIncX);
                break;
            case static_cast<int>(ElemType::Square):
                _degreeElevateNurbsSurface(orderIncX, orderIncY);
                break;
            case static_cast<int>(ElemType::Parallelep):
                _degreeElevateNurbsSolid(orderIncX, orderIncY, orderIncZ);
                break;
            default:
                throw runtime_error("StructMeshGenerator: _getPRefinedMeshNurbs: Wrong element type.");
        }
        _bfOrder = std::max({_bfOrderX, _bfOrderY, _bfOrderZ}); //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs

        //Apply history
        for (auto& f : _history)
        {
            f();
            _bfOrder = std::max({_bfOrderX, _bfOrderY, _bfOrderZ}); //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs
        }

    }

    //h-Refined mesh
    void StructMeshGenerator::_genHRefinedMeshNurbs(int refLevel)
    {

        //Warning
        cout << "StructMeshGenerator: h-Refined mesh can only be used with certain element/processor ratios." << endl;

        //Refine mesh
        subdivideNurbs(refLevel);

        //Reorder connectivity
        _reorderConnec();

    }

}
