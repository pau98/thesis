/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francesco Greco and Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <functional>
#include <deque>

#include <Teuchos_RCP.hpp>
#include <Epetra_LocalMap.h>

#include "hl_MpiHelpers.h"
#include "hl_Math.h"
#include "hl_TypeDefs.h"
#include "hl_Linear.h"
#include "hl_Lagrangian.h"
#include "hl_FieldStruct.h"

#include "hl_StructMeshGenerator.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{

    //Utils
    void StructMeshGenerator::_flipTriangles(int i, int j)
    {
        int nn = j*2*_nEx*_nVert + i*2*_nVert;
        int nx = _nEx + 1;
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        for (int ii=_bfOrder; ii>=0; ii--)
        {
            for (int jj=0; jj<=ii ; jj++)
            {
                _distConnec(nn, j*nnx*_bfOrder + jj*nnx + i*_bfOrder + ii);
                nn++;
            }
        }
        for (int ii=0; ii<_bfOrder+1; ii++)
        {
            for (int jj=_bfOrder; jj>=ii ; jj--)
            {
                _distConnec(nn, j*nnx*_bfOrder + jj*nnx + i*_bfOrder + ii);
                nn++;
            }
        }

    }


    //Basic generators
    void StructMeshGenerator::_genLineStructMesh(int nEx)
    {
        //Dimensions
        _pDim = 1;

        //Set elements
        _nEx = nEx;

        //Vertices
        _nVert = (_bfOrder+1);

        //Number of corner nodes
        int nx = _nEx + 1;

        //Total number of points and elements
        _nPts  = (_bfOrder*nx-(_bfOrder-1));
        _nElem = _nEx;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Nodal coordinates
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        double hhx = 1.0 / (nnx-1);
        double x;
        int n = 0;
        for (int i = 0; i < nnx; i++)
        {
            if(_disPts.isItemInPart(n))
            {
                int locN = _disPts.locIdx(n);
                x = hhx*i;
                _x_nodes[_loc_nPts * 0 + locN] = x;
                _x_nodes[_loc_nPts * 1 + locN] = 0.0;
                _x_nodes[_loc_nPts * 2 + locN] = 0.0;
            }
            n++;
        }

        //Connectivity
        _connec.resize(_loc_nElem*_nVert, 0);
        int nn = 0;
        for (int i=0; i<nx-1; i++)
        {
            for (int ii=0; ii<_bfOrder+1 ; ii++)
            {
                _distConnec(nn, i*_bfOrder + ii);
                nn++;
            }
        }

        //Creases
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        nn = 0;
        for (int i = 0; i < nnx; i++)
        {
            if(_disPts.isItemInPart(nn))
            {
                int locN = _disPts.locIdx(nn);
                // Edges = 1
                if(i==0)
                    _creases[_loc_nPts * 0 + locN] = 1;
                else if(i==ex)
                    _creases[_loc_nPts * 0 + locN] = 1;
                else
                    _creases[_loc_nPts * 0 + locN] = 0;
                // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                if(i==0)
                    _creases[_loc_nPts * 1 + locN] = 2;
                else if(i==ex)
                    _creases[_loc_nPts * 1 + locN] = 3;
                else
                    _creases[_loc_nPts * 1 + locN] = -1;
            }
            nn++;
        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);

        //Impose periodicity
        _periodic();
    }

    void StructMeshGenerator::_genTriangStructMesh(int nEx, int nEy)
    {
        //Dimensions
        _pDim = 2;

        //Set elements
        _nEx = nEx;
        _nEy = nEy;

        //Vertices
        _nVert = ((_bfOrder+1)*(_bfOrder+1)+(_bfOrder+1))/2;

        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;

        //Total number of points and elements
        _nPts  = (_bfOrder*nx-(_bfOrder-1))*(_bfOrder*ny-(_bfOrder-1));
        _nElem = 2 * _nEx * _nEy;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Nodal coordinates
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        int nny = (_bfOrder*ny-(_bfOrder-1));
        double hhx = 1.0 / (nnx-1);
        double hhy = 1.0 / (nny-1);
        double x, y;
        int n = 0;
        for (int j = 0; j < nny; j++)
        {
            y = hhy*j;
            for (int i = 0; i < nnx; i++)
            {
                if(_disPts.isItemInPart(n))
                {
                    int locN = _disPts.locIdx(n);
                    x = hhx*i;
                    _x_nodes[_loc_nPts * 0 + locN] = x;
                    _x_nodes[_loc_nPts * 1 + locN] = y;
                    _x_nodes[_loc_nPts * 2 + locN] = 0.0;
                }
                n++;
            }
        }

        //Connectivity
        _connec.resize(_loc_nElem*_nVert, 0);
        int nn = 0;
        for (int j=0; j<ny-1; j++)
        {
            for (int i=0; i<nx-1; i++)
            {
                //Lower triangle
                for (int jj=0; jj<_bfOrder+1 ; jj++)
                {
                    for (int ii=0; ii<_bfOrder+1-jj ; ii++)
                    {
                        _distConnec(nn, j*nnx*_bfOrder + jj*nnx + i*_bfOrder + ii);
                        nn++;
                    }
                }
                //Upper triangle
                for (int jj=_bfOrder; jj>=0; jj--)
                {
                    for (int ii=_bfOrder; ii>=_bfOrder-jj; ii--)
                    {
                        _distConnec(nn, j*nnx*_bfOrder + jj*nnx + i*_bfOrder + ii);
                        nn++;
                    }
                }
            }
        }

        //Change the first and last triangles so that the node in the corner is not isolated
        _flipTriangles(0, 0);
        _flipTriangles(nx-2, ny-2);

        //Creases
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        int ey = nny - 1;
        nn = 0;
        for (int j = 0; j < nny; j++)
        {
            for (int i = 0; i < nnx; i++)
            {
                if(_disPts.isItemInPart(nn))
                {
                    int locN = _disPts.locIdx(nn);
                    // Creases: Edges = 1; Corners = 2
                    if(i==0 && j==0)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==0 && j == ey)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==ex && j == 0)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==ex && j == ey)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==0)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(j==0)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(i==ex)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(j==ey)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else
                        _creases[_loc_nPts * 0 + locN] = 0;
                    // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                    //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                    if(i==0 && j==0)
                        _creases[_loc_nPts * 1 + locN] = 10;
                    else if(i==0 && j == ey)
                        _creases[_loc_nPts * 1 + locN] = 14;
                    else if(i==ex && j == 0)
                        _creases[_loc_nPts * 1 + locN] = 15;
                    else if(i==ex && j == ey)
                        _creases[_loc_nPts * 1 + locN] = 21;
                    else if(i==0)
                        _creases[_loc_nPts * 1 + locN] = 2;
                    else if(i==ex)
                        _creases[_loc_nPts * 1 + locN] = 3;
                    else if(j==0)
                        _creases[_loc_nPts * 1 + locN] = 5;
                    else if(j==ey)
                        _creases[_loc_nPts * 1 + locN] = 7;
                    else
                        _creases[_loc_nPts * 1 + locN] = -1;
                }
                nn++;
            }
        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);

        //Impose periodicity
        _periodic();
    }

    void StructMeshGenerator::_genSquareStructMesh(int nEx, int nEy)
    {
        //Dimensions
        _pDim = 2;

        //Set elements
        _nEx = nEx;
        _nEy = nEy;

        //Vertices
        _nVert = (_bfOrder+1)*(_bfOrder+1);

        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;

        //Total number of points and elements
        _nPts  = (_bfOrder*nx-(_bfOrder-1))*(_bfOrder*ny-(_bfOrder-1));
        _nElem = _nEx * _nEy;

        //Create trivial distributions
        if (_hRefinedMesh == false)
        {
            _disPts.setLocNItem(0);
            _disPts.setNItem(_nPts);
            _disPts.Update();
            _loc_nPts = _disPts.loc_nItem();
            _disElem.setLocNItem(0);
            _disElem.setNItem(_nElem);
            _disElem.Update();
            _loc_nElem = _disElem.loc_nItem();
        }
        else
        {
            _disPts.setLocNItem(0);
            _disPts.setNItem(_nPts);
            _disPts.Update();
            _loc_nPts = _disPts.loc_nItem();
            _disElem.setLocNItem(4*_loc_nElem_tmp);
            _disElem.setNItem(_nElem);
            _disElem.Update();
            _loc_nElem = _disElem.loc_nItem();
        }

        //Create test distribution
        // _genElementMap();

        //Nodal coordinates
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        int nny = (_bfOrder*ny-(_bfOrder-1));
        double hhx = 1.0 / (nnx-1);
        double hhy = 1.0 / (nny-1);
        double x, y;
        int n = 0;
        for (int j = 0; j < nny; j++)
        {
            y = hhy*j;
            for (int i = 0; i < nnx; i++)
            {
                if(_disPts.isItemInPart(n))
                {
                    int locN = _disPts.locIdx(n);
                    x = hhx*i;
                    _x_nodes[_loc_nPts * 0 + locN] = x;
                    _x_nodes[_loc_nPts * 1 + locN] = y;
                    _x_nodes[_loc_nPts * 2 + locN] = 0.0;
                }
                n++;
            }
        }

        //Connectivity
        _connec.resize(_loc_nElem*_nVert, 0);
        int nn = 0;
        for (int j=0; j<ny-1; j++)
        {
            for (int i=0; i<nx-1; i++)
            {
                for (int jj=0; jj<_bfOrder+1 ; jj++)
                {
                    for (int ii=0; ii<_bfOrder+1 ; ii++)
                    {
                        _distConnec(nn, j*nnx*_bfOrder + jj*nnx + i*_bfOrder + ii);

                        nn++;
                    }
                }
            }
        }

        //Creases
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        int ey = nny - 1;
        nn = 0;
        for (int j = 0; j < nny; j++)
        {
            for (int i = 0; i < nnx; i++)
            {
                if(_disPts.isItemInPart(nn))
                {
                    int locN = _disPts.locIdx(nn);
                    // Creases: Edges = 1; Corners = 2
                    if(i==0 && j==0)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==0 && j == ey)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==ex && j == 0)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==ex && j == ey)
                        _creases[_loc_nPts * 0 + locN] = 2;
                    else if(i==0)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(j==0)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(i==ex)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else if(j==ey)
                        _creases[_loc_nPts * 0 + locN] = 1;
                    else
                        _creases[_loc_nPts * 0 + locN] = 0;
                    // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                    //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                    if(i==0 && j==0)
                        _creases[_loc_nPts * 1 + locN] = 10;
                    else if(i==0 && j == ey)
                        _creases[_loc_nPts * 1 + locN] = 14;
                    else if(i==ex && j == 0)
                        _creases[_loc_nPts * 1 + locN] = 15;
                    else if(i==ex && j == ey)
                        _creases[_loc_nPts * 1 + locN] = 21;
                    else if(i==0)
                        _creases[_loc_nPts * 1 + locN] = 2;
                    else if(i==ex)
                        _creases[_loc_nPts * 1 + locN] = 3;
                    else if(j==0)
                        _creases[_loc_nPts * 1 + locN] = 5;
                    else if(j==ey)
                        _creases[_loc_nPts * 1 + locN] = 7;
                    else
                        _creases[_loc_nPts * 1 + locN] = -1;
                }
                nn++;
            }
        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);

        //Impose periodicity
        _periodic();
    }

    void StructMeshGenerator::_genTetrahStructMesh(int nEx, int nEy, int nEz)
    {
        (void)nEx; (void)nEy; (void)nEz;
        throw runtime_error("StructMeshGenerator: Tetrah mesh generator not implemented. You are kindly invited to implement it yourself.");
    }

    void StructMeshGenerator::_genParallelepStructMesh(int nEx, int nEy, int nEz)
    {
        //Dimensions
        _pDim = 3;

        //Set elements
        _nEx = nEx;
        _nEy = nEy;
        _nEz = nEz;

        //Vertices
        _nVert = (_bfOrder+1)*(_bfOrder+1)*(_bfOrder+1);

        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;
        int nz = _nEz + 1;

        //Total number of points and elements
        _nPts  = (_bfOrder*nx-(_bfOrder-1))*(_bfOrder*ny-(_bfOrder-1))*(_bfOrder*nz-(_bfOrder-1));
        _nElem = _nEx * _nEy * _nEz;

        //Create trivial distributions
        _disPts.setLocNItem(0);
        _disPts.setNItem(_nPts);
        _disPts.Update();
        _loc_nPts = _disPts.loc_nItem();
        _disElem.setLocNItem(0);
        _disElem.setNItem(_nElem);
        _disElem.Update();
        _loc_nElem = _disElem.loc_nItem();

        //Nodal coordinates
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        int nny = (_bfOrder*ny-(_bfOrder-1));
        int nnz = (_bfOrder*nz-(_bfOrder-1));
        double hhx = 1.0 / (nnx-1);
        double hhy = 1.0 / (nny-1);
        double hhz = 1.0 / (nnz-1);
        double x, y, z;
        int n = 0;
        for (int k = 0; k < nnz; k++)
        {
            z = hhz*k;
            for (int j = 0; j < nny; j++)
            {
                y = hhy*j;
                for (int i = 0; i < nnx; i++)
                {
                    if(_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        x = hhx*i;
                        _x_nodes[_loc_nPts * 0 + locN] = x;
                        _x_nodes[_loc_nPts * 1 + locN] = y;
                        _x_nodes[_loc_nPts * 2 + locN] = z;
                    }
                    n++;
                }
            }
        }

        //Connectivity
        _connec.resize(_loc_nElem*_nVert, 0);
        int nn = 0;
        for (int k=0; k<nz-1; k++)
        {
            for (int j=0; j<ny-1; j++)
            {
                for (int i=0; i<nx-1; i++)
                {
                    for (int kk=0; kk<_bfOrder+1 ; kk++)
                    {
                        for (int jj=0; jj<_bfOrder+1 ; jj++)
                        {
                            for (int ii=0; ii<_bfOrder+1 ; ii++)
                            {
                                _distConnec(nn, k*nnx*nny*_bfOrder + kk*nnx*nny + j*nnx*_bfOrder + jj*nnx + i*_bfOrder + ii);
                                nn++;
                            }
                        }
                    }
                }
            }
        }

        //Creases
        _creases.resize(_loc_nPts*_nCreases, 0);
        int ex = nnx - 1;
        int ey = nny - 1;
        int ez = nnz - 1;
        nn = 0;
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if(_disPts.isItemInPart(nn))
                    {
                        int locN = _disPts.locIdx(nn);
                        //Creases: Edges = 1; Corners = 2; Faces = 3
                        if(i==0 && j==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==ey && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==ey && k==0)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==0 && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==ey && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==0 && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==ex && j==ey && k==ez)
                            _creases[_loc_nPts * 0 + locN] = 2;
                        else if(i==0 && j==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0 && j == ey)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && j == 0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && j == ey)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0 && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && k == 0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==0 && k==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==0 && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==ey && k == 0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==ey && k == ez)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==0)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(j==0)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(k==0)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(i==ex)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(j==ey)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else if(k==ez)
                            _creases[_loc_nPts * 0 + locN] = 3;
                        else
                            _creases[_loc_nPts * 0 + locN] = 0;
                        // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                        //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                        //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                        if(i==0 && j==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 2*5*11;
                        else if(i==0 && j==0 && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 2*5*13;
                        else if(i==0 && j==ey && k==0)
                            _creases[_loc_nPts * 1 + locN] = 2*7*11;
                        else if(i==0 && j==ey && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 2*7*13;
                        else if(i==ex && j==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 3*5*11;
                        else if(i==ex && j==0 && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 3*5*13;
                        else if(i==ex && j==ey && k==0)
                            _creases[_loc_nPts * 1 + locN] = 3*7*11;
                        else if(i==ex && j==ey && k==ez)
                            _creases[_loc_nPts * 1 + locN] = 3*7*13;
                        else if(i==0 && j==0)
                            _creases[_loc_nPts * 1 + locN] = 2*5;
                        else if(i==0 && j == ey)
                            _creases[_loc_nPts * 1 + locN] = 2*7;
                        else if(i==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 2*11;
                        else if(i==0 && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 2*13;
                        else if(i==ex && j == 0)
                            _creases[_loc_nPts * 1 + locN] = 3*5;
                        else if(i==ex && j == ey)
                            _creases[_loc_nPts * 1 + locN] = 3*7;
                        else if(i==ex && k == 0)
                            _creases[_loc_nPts * 1 + locN] = 3*11;
                        else if(i==ex && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 3*13;
                        else if(j==0 && k==0)
                            _creases[_loc_nPts * 1 + locN] = 5*11;
                        else if(j==0 && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 5*13;
                        else if(j==ey && k == 0)
                            _creases[_loc_nPts * 1 + locN] = 7*11;
                        else if(j==ey && k == ez)
                            _creases[_loc_nPts * 1 + locN] = 7*13;
                        else if(i==0)
                            _creases[_loc_nPts * 1 + locN] = 2;
                        else if(i==ex)
                            _creases[_loc_nPts * 1 + locN] = 3;
                        else if(j==0)
                            _creases[_loc_nPts * 1 + locN] = 5;
                        else if(j==ey)
                            _creases[_loc_nPts * 1 + locN] = 7;
                        else if(k==0)
                            _creases[_loc_nPts * 1 + locN] = 11;
                        else if(k==ez)
                            _creases[_loc_nPts * 1 + locN] = 13;
                        else
                            _creases[_loc_nPts * 1 + locN] = -1;
                    }
                    nn++;
                }
            }

        }

        //Element flags
        _eflags.resize(_loc_nElem*_nEFlags, 0);

        //Impose periodicity
        _periodic();
    }


    //Other generators
    void StructMeshGenerator::_genSquareLine(int nEl, double side)
    {
        //Generate regular mesh
        genStructMesh(4*nEl, -1);

        //Transform
        transformFree([side](double x, double y){
            vector<double> p(2);
            (void) y;
            if (x<=0.25)
            {
                p[0]=x*4*side;
                p[1]=0;
            }
            else if (x<=0.5)
            {
                p[0]=side;
                p[1]=(x-0.25)*4*side;
            }
            else if (x<=0.75)
            {
                p[0]=side-(x-0.5)*4*side;
                p[1]=side;
            }
            else
            {
                p[0]=0;
                p[1]=side-(x-0.75)*4*side;
            }

            return std::make_tuple(p[0], p[1]);
        });
    }

    void StructMeshGenerator::_genRuledSurface(int nEx, int nEy, vector<double> p1, vector<double> p2, vector<double> p3, vector<double> p4)
    {
        //Generate regular mesh
        genStructMesh(nEx, nEy, -1);

        //Transform
        transformFree([p1,p2,p3,p4](double x, double y, double z){
            vector<double> p(3);
            (void) z;
            double pl, pr;
            for (int i=0; i<3; i++)
            {
                pl = p1[i] * (1-y) + p4[i]  *y;
                pr = p2[i]  * (1-y) + p3[i]  *y;
                p[i]  = pl * (1-x) + pr *x;
            }

            return std::make_tuple(p[0],p[1],p[2]);
        });
    }

    void StructMeshGenerator::_genCircularArc(int nEx, double radius, double phi)
    {
        //Generate regular mesh
        genStructMesh(nEx);

        //Modify node location
        transformFree([radius, phi](double x, double y){
                (void)y;
                double theta = phi*(1.0-x);
                return std::make_tuple(radius*cos(theta), radius*sin(theta));
            });

        //Unclamp it
        if (phi == 2.0*M_PI)
            unclamp(Axis::Xaxis);
    }

    void StructMeshGenerator::_genAnnularSector(int nEx, int nEy, double rInt, double rExt, double phi)
    {
        //Generate regular mesh
        genStructMesh(nEx, nEy);

        //Modify node location
        transformFree([rInt, rExt, phi](double x, double y){
                double x2 = x * (rExt -rInt) + rInt;
                double y2 = y * phi;
                return std::make_tuple(x2*cos(y2), x2*sin(y2));
            });
    }

    void StructMeshGenerator::_genQuarterPlateWithCircularHole(int nEx, int nEy, double sx, double sy, double r)
    {
        // Checks
        if (nEx%2 != 0 or nEy%2 != 0)
            throw runtime_error("StructMeshGenerator::_genQuarterPlateWithCircularHole: Please use an even number of elements.");
        if (sx != sy)
            throw runtime_error("StructMeshGenerator::_genQuarterPlateWithCircularHole: sx and sy don't match, under development.");

        // Generate annular sector
        _genAnnularSector(nEx, nEy, r, sx, M_PI/2);

        // Transform annular sector to plate
        transformFree([r, sx](double x, double y){
                          double theta = std::atan2(y, x);
                          double r0    = sqrt(x*x+y*y);
                          double alpha = pow((r0-r)/(sx-r), 4.0);
                          double r1{};
                          if (theta <= M_PI/4.0)
                              r1 = r0*pow(1.0/cos(theta), alpha);
                          else
                              r1 = r0*pow(1.0/sin(theta), alpha);
                          return std::make_tuple(r1*cos(theta), r1*sin(theta));
                      });
    }

    void StructMeshGenerator::_genDisk_Polar(int nEx, int nEy, double r)
    {
        //Save element type
        ElemType eType = _eType;

        //Generate a circular arc
        _eType = ElemType::Line;
        genLine(nEx, r);

        //Revolve around Z axis
        revolve(nEy, 0, eType, 2.0*M_PI, Axis::Zaxis);
    }

    void StructMeshGenerator::_genDisk_Squared(int nEx, int nEy, double r)
    {
        (void)nEx; (void)nEy; (void)r;
        throw runtime_error("StructMeshGenerator: Disk_Squared: Only implemented for Bspline and Nurbs.");
    }



    void StructMeshGenerator::_genTorusSurfacePatchSector(int nEx, int nEy, double rGen, double phiIni, double phiEnd, double rDir, double theta)
    {
        //Save mesh info
        ElemType eType = _eType;
        BasisFuncType bfType = _bfType;

        //Generate a circular arc (use the private function so that it is not unclamped)
        _eType = ElemType::Line;
        if (bfType == BasisFuncType::SubdivSurfs) //FIXME: These changes are not stored. They don't work for mesh relations
        {
            _bfType  = BasisFuncType::Lagrangian;
            _bfOrder = 1;
        }
        _genCircularArc(nEx, rGen, phiEnd-phiIni);

        //Put it vertical and translate it
        rotateX(M_PI/2.0);
        translateX(rDir);

        //Revolve around Z axis
        revolve(nEy, 0, eType, theta, Axis::Zaxis);

        //Unclamp it
        if (phiEnd - phiIni == 2.0*M_PI)
            _unclamp({Axis::Xaxis});
        if (theta == 2.0*M_PI)
            _unclamp({Axis::Yaxis});

        //Restore basis function type
        if (bfType == BasisFuncType::SubdivSurfs) //FIXME: These changes are not stored. They don't work for mesh relations
        {
            _bfType  = bfType;
            _bfOrder = 2;
        }
    }

    void StructMeshGenerator::_genTorusSolidSector(int nEx, int nEy, int nEz, double rGen, double rDir, double theta)
    {
        //Save element type
        ElemType eType = _eType;

        //Generate a disk (use the private function so that it is not unclamped)
        _eType = ElemType::Square;
        _genDisk_Polar(nEx, nEy, rGen);
        // genRectangle(10, 10, 0.2, 0.3);

        //Put it vertical and translate it
        rotateX(M_PI/2.0);
        translateX(rDir);

        //Revolve around Z axis
        revolve(nEz, 0, eType, theta, Axis::Zaxis);

        //Unclamp it
        _unclamp({Axis::Yaxis});
        if (theta == 2.0*M_PI)
            _unclamp({Axis::Zaxis});
    }


    //p-Refined mesh
    void StructMeshGenerator::_genPRefinedMesh_nonPeriodic(int orderInc)
    {
        using namespace MpiHelpers;

        // Checks
        if (_eType == ElemType::Tetrah) // FIXME
            throw runtime_error("StructMeshGenerator::_genPRefinedMesh2D Tetrah never checked.");

        //*******************************************************************
        // [0.0] Initialize: Basic sets
        //*******************************************************************

        // Basic sets
        _pRefinedMesh = true;
        setBasisFuncOrder(_bfOrder+orderInc);
        _performOrderChecks();

        //*******************************************************************
        // [0.1] Initialize: Create coords and creases field and basis funcs
        //*******************************************************************

        // Create nodeData
        RCP<FieldStruct> _nodeData = rcp(new FieldStruct("nodeData", _comm));
        _nodeData->setBlockMap(_disPts.map());
        // _nodeData->setBlockMap(_graph->map());
        _nodeData->setNFlds(_nDim);
        double *_tmp_distXnodes = _x_nodes.data();
        _nodeData->setDistFields(_tmp_distXnodes);
        // _nodeData->setDistFields(&*_x_nodes.data());
        _nodeData->Update();

        // Create creases
        RCP<IntFieldStruct> _nodeFlags = rcp(new IntFieldStruct("nodeFlags", _comm));
        _nodeFlags->setBlockMap(_disPts.map());
        // _nodeData->setBlockMap(_graph->map());
        _nodeFlags->setNFlds(_nCreases_tmp);
        int *_tmp_distCreases = _creases.data();
        _nodeFlags->setDistFields(_tmp_distCreases);
        // _nodeData->setDistFields(&*_x_nodes.data());
        _nodeFlags->Update();

        // Create and update ghosts on node data and flags
        vector<int> ghosts = _createNodeGhosts();
        _nodeData->UpdateGhosts(ghosts);
        _nodeFlags->UpdateGhosts(ghosts);

        // Share ghosts
        vector<int> glob_ghosts_vec = allgatherv(ghosts, _numProcs, _myRank);
        set<int> glob_ghosts(glob_ghosts_vec.begin(), glob_ghosts_vec.end());

        // Set number of vertices (has to be done after _createNodeGhosts())
        _nVert = computeNVert(_bfType, _eType, _bfOrder);

        // Create BasisFunctions for one element of the old mesh
        RCP<BasisFunctions> basisFunctions;
        if (_bfType == BasisFuncType::Linear)
            basisFunctions = rcp(new Linear);
        else if (_bfType == BasisFuncType::Lagrangian)
            basisFunctions = rcp(new Lagrangian);
        RCP<Epetra_LocalMap> OneMap = rcp(new Epetra_LocalMap(1, 0, *_epComm));
        Teuchos::RCP<Epetra_IntVector> _BFTags = rcp(new Epetra_IntVector(*OneMap));
        basisFunctions->setBasisFunctionTags(_BFTags);
        basisFunctions->setElementType(_eType);
        basisFunctions->setBasisFunctionOrder(_bfOrder_tmp);
        basisFunctions->Update();

        // Pre-compute basis functions for a higher-order element // FIXME: Move to typedefs?
        vector<vector<double>> bfs(_nVert, vector<double>(_nVert_tmp));
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
            {
                for (int i = 0; i < _bfOrder+1; i++)
                {
                    vector<double> rCoords = {2.0*i/double(_bfOrder)-1.0};
                    bfs[i] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                }

                break;
            }
            case static_cast<int>(ElemType::Triang):
            {
                int n{};
                for (int j = 0; j < _bfOrder+1; j++)
                {
                    for (int i = 0; i < _bfOrder+1-j; i++)
                    {
                        vector<double> rCoords(_pDim);
                        rCoords[0] = i/double(_bfOrder);
                        rCoords[1] = j/double(_bfOrder);
                        bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                        n++;
                    }
                }

                break;
            }
            case static_cast<int>(ElemType::Square):
            {
                int n{};
                for (int j = 0; j < _bfOrder+1; j++)
                {
                    for (int i = 0; i < _bfOrder+1; i++)
                    {
                        vector<double> rCoords(_pDim);
                        rCoords[0] = 2.0*i/double(_bfOrder)-1.0;
                        rCoords[1] = 2.0*j/double(_bfOrder)-1.0;
                        bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                        n++;
                    }
                }

                break;
            }
            case static_cast<int>(ElemType::Tetrah):
            {
                int n{};
                for (int k = 0; k < _bfOrder+1; k++)
                {
                    for (int j = 0; j < _bfOrder+1-k; j++)
                    {
                        for (int i = 0; i < _bfOrder+1-j; i++)
                        {
                            vector<double> rCoords(_pDim);
                            rCoords[0] = i/double(_bfOrder);
                            rCoords[1] = j/double(_bfOrder);
                            rCoords[2] = k/double(_bfOrder);
                            bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                            n++;
                        }
                    }
                }

                break;
            }
            case static_cast<int>(ElemType::Parallelep):
            {
                int n{};
                for (int k = 0; k < _bfOrder+1; k++)
                {
                    for (int j = 0; j < _bfOrder+1; j++)
                    {
                        for (int i = 0; i < _bfOrder+1; i++)
                        {
                            vector<double> rCoords(_pDim);
                            rCoords[0] = 2.0*i/double(_bfOrder)-1.0;
                            rCoords[1] = 2.0*j/double(_bfOrder)-1.0;
                            rCoords[2] = 2.0*k/double(_bfOrder)-1.0;
                            bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                            n++;
                        }
                    }
                }
                break;
            }

            default:
                break;
        }


        //*******************************************************************
        // [0.2] Initialize: hl2vtk, vtk2hl, edges, faces and allocate
        //*******************************************************************

        // Save element corners ids of the old mesh
        vector<int> cornerId_old = elemCornerId(_eType, _bfType, _bfOrder_tmp);
        int nCorners = cornerId_old.size();
        vector<int> vtk2hl_old = vtkReordering(_eType, _bfType, _bfOrder_tmp, true);
        vector<int> hl2vtk_old = vtkReordering(_eType, _bfType, _bfOrder_tmp, false);
        vector<int> cornerId_vtk_old(hl2vtk_old.begin(), hl2vtk_old.begin()+nCorners);
        vector<int> nType_vtk_old = elemNodeTypeVtk(_eType, _bfType, _bfOrder_tmp);
        vector<int> nType_old(_nVert_tmp);
        for (int i = 0; i < _nVert_tmp; i++)
            nType_old[i] = nType_vtk_old[vtk2hl_old[i]];

        // Save element node type of the new mesh
        vector<int> nType_vtk = elemNodeTypeVtk(_eType, _bfType, _bfOrder);
        vector<int> vtk2hl = vtkReordering(_eType, _bfType, _bfOrder, true);
        vector<int> hl2vtk = vtkReordering(_eType, _bfType, _bfOrder, false);
        vector<int> nType(_nVert);
        for (int i = 0; i < _nVert; i++)
            nType[i] = nType_vtk[vtk2hl[i]];
        vector<int> numNType = numElemNodeType(_eType, _bfType, _bfOrder);

        // Count number of corners
        vector<int> connec_c = _connec_tmp;
        int nid{-1};
        connec_c.erase(remove_if(connec_c.begin(), connec_c.end(),
                                 [&](int n){
                                     (void) n;
                                     nid++;
                                     int el_n = nid%_nVert_tmp;
                                     return (nType_old[el_n] != 2);
                                 }), connec_c.end());
        int loc_nPts_c = std::set<int>(connec_c.begin(), connec_c.end()).size();

        // Save element edges
        vector<pair<int,int>> elem_edges_vtk;
        if (_eType == ElemType::Triang)
        {
            elem_edges_vtk = {{0,1},{1,2},{2,0}};
        }
        else if (_eType == ElemType::Square)
        {
            elem_edges_vtk = {{0,1},{1,2},{2,3},{3,0}};
        }
        else if (_eType == ElemType::Tetrah)
        {
            elem_edges_vtk = {{0,1},{1,2},{2,0},
                              {0,3},{1,3},{2,3}};
        }
        else if (_eType == ElemType::Parallelep)
        {
            elem_edges_vtk = {{0,1},{1,2},{2,3},{3,0},
                              {4,5},{5,6},{6,7},{7,4},
                              {0,4},{1,5},{3,7},{2,6}};
        }
        int numNodesOnEdge = numNType[1]/elem_edges_vtk.size();

        // Compute edges
        map<pair<int,int>,int> edges;
        for (int loc_e = 0; loc_e < _loc_nElem_tmp; loc_e++)
        {
            for (size_t i = 0; i < elem_edges_vtk.size(); i++)
            {
                int c0 = hl2vtk_old[elem_edges_vtk[i].first];
                int c1 = hl2vtk_old[elem_edges_vtk[i].second];
                c0 = _connec_tmp[loc_e*_nVert_tmp+c0];
                c1 = _connec_tmp[loc_e*_nVert_tmp+c1];
                int s = edges.size();
                edges.emplace(make_pair(min(c0, c1), max(c0, c1)),s);
            }
        }

        // Save element faces
        vector<vector<int>> elem_faces_vtk;
        int numNodesOnFace{0};
        if (_eType == ElemType::Tetrah)
        {
            elem_faces_vtk = {{0,1,3},{0,3,2},
                              {0,1,2},{1,2,3}};
            numNodesOnFace = numNType[3]/elem_faces_vtk.size();
        }
        else if (_eType == ElemType::Parallelep)
        {
            elem_faces_vtk = {{3,0,7,4},{2,1,6,5},
                              {0,1,4,5},{3,2,7,6},
                              {0,1,3,2},{4,5,7,6}};
            numNodesOnFace = numNType[3]/elem_faces_vtk.size();
        }

        // Compute faces
        map<vector<int>,int> faces;
        for (int loc_e = 0; loc_e < _loc_nElem_tmp; loc_e++)
        {
            for (size_t i = 0; i < elem_faces_vtk.size(); i++)
            {
                vector<int> cFaces(elem_faces_vtk[i].size());
                for (size_t j = 0; j < cFaces.size(); j++)
                {
                    int c = hl2vtk_old[elem_faces_vtk[i][j]];
                    cFaces[j] = _connec_tmp[loc_e*_nVert_tmp+c];
                }
                sort(cFaces.begin(), cFaces.end());
                int s = faces.size();
                faces.emplace(cFaces, s);
            }
        }

        // Save old node distribution
        DistributedData _disPts_tmp;
        _disPts_tmp.setLocNItem(_loc_nPts_tmp);
        _disPts_tmp.setNItem(0);
        _disPts_tmp.Update();

        // Update node distribution
        if (_pDim == 1)
            _loc_nPts = loc_nPts_c + _loc_nElem*numNType[0];
        else if (_pDim == 2)
            _loc_nPts = loc_nPts_c + edges.size()*numNodesOnEdge + _loc_nElem*numNType[0];
        else
            _loc_nPts = loc_nPts_c + edges.size()*numNodesOnEdge + faces.size()*numNodesOnFace + _loc_nElem*(numNType[0]);
        _disPts.setLocNItem(_loc_nPts);
        _disPts.setNItem(0);
        _disPts.Update();
        _nPts = _disPts.nItem();

        // Allocate vectors
        _connec.clear();
        _connec.resize(_loc_nElem*_nVert, -1);
        _x_nodes.clear();
        _x_nodes.resize(_nDim*_loc_nPts);
        _creases.clear();
        _creases.resize(_loc_nPts*_nCreases, 0);
        for (int i = 0; i < _loc_nPts; i++)
            _creases[_loc_nPts*1+i] = -1;


        //*******************************************************************
        // [1] Create higher-order elements and save repeated nodes
        //*******************************************************************

        // Loop over the elements, create second-order elements and mark repeated nodes
        vector<int> i_repeated;
        vector<vector<double>> x_repeated;
        map<int,int> inserted_corners;
        vector<vector<int>> inserted_edges(edges.size(), vector<int>(numNodesOnEdge, -1));
        vector<vector<int>> inserted_faces(faces.size(), vector<int>(numNodesOnFace, -1));
        int lastLabel{_disPts.offs_nItem()};
        for (int e = 0; e < _loc_nElem;  e++)
        {
            // Get nbors
            vector<int> nbors(_nVert_tmp);
            for (int i = 0; i < _nVert_tmp; i++)
                nbors[i] = _connec_tmp[e*_nVert_tmp+i];

            // Loop over nodes to insert
            for (int i = 0; i < _nVert; i++)
            {
                // Compute coordinates
                vector<double> xCoords(_nDim, 0.0);
                for (int n = 0; n < _nVert_tmp; n++)
                {
                    int nbor = nbors[n];
                    for (int d = 0; d < _nDim; d++)
                    {
                        double nborCoord = _nodeData->getValue(d, nbor, IndexType::Global);
                        xCoords[d] += nborCoord*bfs[i][n];
                    }
                }

                // Save connectivity and creases
                if (nType[i] == 2) // Corner
                {
                    // Get corner number in the old mesh
                    int cId_el = hl2vtk_old[vtk2hl[i]];
                    int cId = nbors[cId_el];

                    // Insert corner and crease
                    if (inserted_corners.find(cId) == inserted_corners.end())
                    {
                        // Insert creases and nodes
                        int loc_n = lastLabel - _disPts.offs_nItem();
                        for (int c = 0; c < _nCreases; c++)
                            _creases[_loc_nPts*c+loc_n] = _nodeFlags->getValue(c, cId, IndexType::Global);
                        _connec[e*_nVert+i] = lastLabel;

                        // Save repeated candidates
                        if (glob_ghosts.find(cId) != glob_ghosts.end())
                        {
                            i_repeated.push_back(lastLabel);
                            x_repeated.push_back(xCoords);
                        }

                        // Update
                        inserted_corners[cId] = lastLabel;
                        lastLabel++;
                    }
                    else
                    {
                        _connec[e*_nVert+i] = inserted_corners[cId];
                        continue;
                    }
                }
                else if (nType[i] == 1) // Edges
                {
                    // Get edge number in the element
                    int edgeNum = vtk2hl[i]-nCorners;

                    // Get node on edge number
                    int nNodeEdge = edgeNum%numNodesOnEdge;

                    // Get corners
                    int elemEdgeId = int(edgeNum/numNodesOnEdge);
                    int c0 = hl2vtk_old[elem_edges_vtk[elemEdgeId].first];
                    int c1 = hl2vtk_old[elem_edges_vtk[elemEdgeId].second];
                    c0 = nbors[c0];
                    c1 = nbors[c1];

                    // Get edge
                    int edge = edges[make_pair(min(c0,c1),max(c0,c1))];

                    // Insert edge and creases
                    if (inserted_edges[edge][nNodeEdge] == -1)
                    {
                        // Creases
                        for (int c = 0; c < _nCreases; c++)
                        {
                            // Get creases of the corners
                            vector<int> creases(2);
                            creases[0] = _nodeFlags->getValue(c, c0, IndexType::Global);
                            creases[1] = _nodeFlags->getValue(c, c1, IndexType::Global);

                            // Modify for faces
                            int crease = *min_element(creases.begin(), creases.end());
                            if (c == 0 and crease != 0 and *max_element(creases.begin(), creases.end()) == 3)
                                crease = 3;

                            int loc_n = lastLabel - _disPts.offs_nItem();
                            _creases[_loc_nPts*c+loc_n] = crease;
                        }

                        // Node
                        _connec[e*_nVert+i] = lastLabel;

                        // Save repeated candidates
                        if (glob_ghosts.find(c0) != glob_ghosts.end() or glob_ghosts.find(c1) != glob_ghosts.end())
                        {
                            i_repeated.push_back(lastLabel);
                            x_repeated.push_back(xCoords);
                        }

                        // Update
                        inserted_edges[edge][nNodeEdge] = lastLabel;
                        lastLabel++;
                    }
                    else
                    {
                        _connec[e*_nVert+i] = inserted_edges[edge][nNodeEdge];
                        continue;
                    }
                }
                else if (nType[i] == 3) // Faces
                {
                    // Get face number in the element
                    int faceNum = vtk2hl[i]-nCorners-numNType[1];

                    // Get node on face number
                    int nNodeFace = faceNum%numNodesOnFace;

                    // Get corners
                    int elemFaceId = int(faceNum/numNodesOnFace);
                    int numCornersOnFace = elem_faces_vtk[0].size();
                    vector<int> cFace(numCornersOnFace);
                    for (int j = 0; j < numCornersOnFace; j++)
                    {
                        int c = hl2vtk_old[elem_faces_vtk[elemFaceId][j]];
                        cFace[j] = nbors[c];
                    }
                    sort(cFace.begin(),cFace.end());

                    // Get face
                    int face = faces[cFace];

                    // Insert face and creases
                    if (inserted_faces[face][nNodeFace] == -1)
                    {
                        // Creases
                        for (int c = 0; c < _nCreases; c++)
                        {
                            // Get creases of the corners
                            vector<int> creases(numCornersOnFace);
                            for (int j = 0; j < numCornersOnFace; j++)
                                creases[j] = _nodeFlags->getValue(c, cFace[j], IndexType::Global);
                            int crease = *min_element(creases.begin(), creases.end());

                            // Modify for faces
                            if (c == 0 and crease != 0 and *max_element(creases.begin(), creases.end()) == 3)
                                crease = 3;

                            int loc_n = lastLabel - _disPts.offs_nItem();
                            _creases[_loc_nPts*c+loc_n] = crease;
                        }

                        // Node
                        _connec[e*_nVert+i] = lastLabel;

                        // Save repeated candidates
                        bool save{false};
                        for (auto cF: cFace)
                        {
                            if (glob_ghosts.find(cF) != glob_ghosts.end())
                                save = true;
                        }
                        if (save)
                        {
                            i_repeated.push_back(lastLabel);
                            x_repeated.push_back(xCoords);
                        }

                        // Update
                        inserted_faces[face][nNodeFace] = lastLabel;
                        lastLabel++;
                    }
                    else
                    {
                        _connec[e*_nVert+i] = inserted_faces[face][nNodeFace];
                        continue;
                    }
                }
                else
                {
                    _connec[e*_nVert+i] = lastLabel;
                    lastLabel++;
                }

                // Save x_nodes
                for (int d = 0; d < _nDim; d++)
                {
                    // x_nodes.push_back(xCoords[d]);
                    int loc_n = lastLabel - 1 - _disPts.offs_nItem();
                    _x_nodes[_loc_nPts*d+loc_n] = xCoords[d];
                }
            }
        }

        //*******************************************************************
        // [2] Remove repeated nodes across partitions
        //*******************************************************************

        // Share repeated node ids
        vector<int> glob_i_repeated = allgatherv(i_repeated, _numProcs, _myRank);

        // Rearrange repeated nodes coordinates
        vector<double> coord_repeated(x_repeated.size()*_nDim);
        int n = 0;
        for (size_t i = 0; i < x_repeated.size(); i++)
        {
            for (int j = 0; j < _nDim; j++)
            {
                coord_repeated[n] = x_repeated[i][j];
                n++;
            }
        }

        // Share repeated node coordinates
        vector<double> glob_x_repeated = allgatherv(coord_repeated, _numProcs, _myRank);

        // Initialize original index locations
        int n_rep = static_cast<int> (glob_i_repeated.size());
        vector<size_t> idx(n_rep);
        iota(idx.begin(), idx.end(), 0);

        // Sort indexes based on coords order
        stable_sort(idx.begin(), idx.end(),
                    [&glob_x_repeated](size_t i1, size_t i2) {
                        if (glob_x_repeated[i1*3+0] != glob_x_repeated[i2*3+0])
                            return glob_x_repeated[i1*3+0] < glob_x_repeated[i2*3+0];
                        if (glob_x_repeated[i1*3+1] != glob_x_repeated[i2*3+1])
                            return glob_x_repeated[i1*3+1] < glob_x_repeated[i2*3+1];
                        return glob_x_repeated[i1*3+2] < glob_x_repeated[i2*3+2];
                    });

        // Save repeated nodes, knowing that they are ordered according to idx
        map<int, int> map_repeatedNodes;
        for (int i = 0; i < n_rep-1; i++)
        {
            // First coord
            int i1 = idx[i];
            vector<double> coords1(glob_x_repeated.begin()+3*i1, glob_x_repeated.begin()+3*i1+3);

            // Second coords
            int j{1};
            bool found{true};
            while (found and i+j != n_rep)
            {
                int i2 = idx[i+j];
                vector<double> coords2(glob_x_repeated.begin()+3*i2, glob_x_repeated.begin()+3*i2+3);
                if (Math::Dist3D(coords1.data(), coords2.data()) < 1e-6)
                    map_repeatedNodes[glob_i_repeated[i1]] = glob_i_repeated[i2];
                else
                    found = false;
                j++;
            }
        }

        // Remove repeated nodes
        _removeRepeatedNodes(map_repeatedNodes);

        return;
    }

    void StructMeshGenerator::_genPRefinedMesh(int orderInc)
    {
        //Initialize
        int new_order = _bfOrder_tmp + orderInc;

        //Checks
        if (new_order <= 0)
            throw runtime_error("StructMeshGenerator: Your p-refined mesh should be at least order one.");

        if (_periodicInX or _periodicInY or _periodicInZ) //FIXME
        {
            //Warning
            cout << "StructMeshGenerator: p-Refined mesh can only be used with straight elements." << endl;

            //Change order
            setBasisFuncOrder(new_order);
            _performOrderChecks();

            //Generate mesh
            genStructMesh(_nEx, _nEy, _nEz);

            //Apply history
            for (auto& f : _history)
                f();
        }
        else
        {
            _genPRefinedMesh_nonPeriodic(orderInc);
        }
    }

    //h-Refined mesh
    void StructMeshGenerator::_genHRefinedMesh(int refLevel)
    {
        //Warning
        cout << "StructMeshGenerator: h-Refined mesh can only be used with straight elements, meshes generated ONLY with affine transformations and certain element/processor ratios." << endl;

        //Remove order for subdivision
        if (_bfType == BasisFuncType::SubdivSurfs)
            _bfOrder = -1;

        //Generate mesh
        int nEx = _nEx*2*refLevel;
        int nEy = std::max(_nEy, _nEy*2*refLevel);
        int nEz = std::max(_nEz, _nEz*2*refLevel);
        genStructMesh(nEx, nEy, nEz);

        //Apply history
        for (auto& f : _history)
            f();

        //Reorder connectivity
        _reorderConnec();

    }


    //Boundary mesh
    void StructMeshGenerator::_genBoundaryMesh(vector<MAxis> vMAx)
    {

        //Initialize
        int _nElem_B = 0;
        int _loc_nElem_B = 0;
        int _loc_nPts_B = 0;
        int _nEx_B = 0;
        vector<int> _connec_B;
        vector<double> _x_nodes_B;
        vector<int> _creases_B;
        //_nPts = _nPts_tmp;
        //_elMap_newToOld.resize(_loc_nElem, 0);

        //Loop through axis
        int it{};
        for (auto& ax : vMAx)
        {
            //Generate one-axis boundary mesh
            switch (int(_eType_tmp))
            {
                case static_cast<int>(ElemType::Line):
                   //_eType = Dot;
                   _genDotBoundary(ax);
                   break;
                case static_cast<int>(ElemType::Triang):
                case static_cast<int>(ElemType::Square):
                    _eType = ElemType::Line;
                    _genLineBoundary(ax);
                    break;
                case static_cast<int>(ElemType::Tetrah):
                    _eType = ElemType::Triang;
                    _genTriangBoundary(ax);
                    break;
                case static_cast<int>(ElemType::Parallelep):
                    _eType = ElemType::Square;
                    _genSquareBoundary(ax);
                    break;
                default:
                    throw runtime_error("StructMeshGenerator: Wrong element type.");
            }

            //Get element offset for connectivity
            int offSet = _nElem_B*_bfOrder + it;

            //Add connectivity
            for (auto& c : _connec)
                _connec_B.push_back(c + offSet);

            //Add x_nodes and creases
            vector<double>::iterator iter, iter2;
            vector<int>::iterator iiter, iiter2;
            if (it == 0)
            {
                for (auto& x : _x_nodes)
                    _x_nodes_B.push_back(x);
                for (auto& c : _creases)
                    _creases_B.push_back(c);
            }
            else
            {
                for (int m = 0; m < _nDim; m++)
                {
                    iter = _x_nodes_B.begin() + (m+1)*_loc_nPts_B + m*_loc_nPts;
                    iter2 = _x_nodes.begin() + m*_loc_nPts;

                    _x_nodes_B.insert(iter,iter2,iter2+_loc_nPts);
                }
                for (int m = 0; m < _nCreases; m++)
                {
                    iiter = _creases_B.begin() + (m+1)*_loc_nPts_B + m*_loc_nPts;
                    iiter2 = _creases.begin() + m*_loc_nPts;

                    _creases_B.insert(iiter,iiter2,iiter2+_loc_nPts);
                }
            }

            //Update mesh values
            _nElem_B += _nElem;
            _loc_nElem_B +=_loc_nElem;
            _loc_nPts_B += _loc_nPts;
            _nEx_B += _nEx;

            //Update
            it++;
        }

        //Rewrite
        _nElem = _nElem_B;
        _loc_nElem =_loc_nElem_B;
        _loc_nPts = _loc_nPts_B;
        _nEx = _nEx_B;
        _connec.resize(_loc_nElem * _nVert, 0);
        _connec = _connec_B;
        _x_nodes.resize(_loc_nPts * _nDim, 0.0);
        _x_nodes = _x_nodes_B;
        _creases.resize(_loc_nPts * _nCreases, 0);
        _creases = _creases_B;

    }

    void StructMeshGenerator::_genDotBoundary(MAxis ax)
    {
        (void)ax;
        throw runtime_error("StructMeshGenerator: 0-dimensional boundary mesh has not been done yet. You are kindly invited to implement it yourself.");
    }

    void StructMeshGenerator::_genLineBoundary(MAxis ax)
    {
        //Get axis extreme
        int myMAxis = getMAxis(ax);

        //Number of vertices
        _nVert = (_bfOrder+1);

        //Old mesh: IndexType::Local number of nodes and local number of elements per direction
        int nx_tmp = _nEx_tmp + 1;
        int ny_tmp = _nEy_tmp + 1;
        DistributedData disPts_tmp;
        disPts_tmp.setNItem(_nPts_tmp);
        disPts_tmp.Update();
        DistributedData disElem_tmp;
        disElem_tmp.setNItem(_nElem_tmp);
        disElem_tmp.Update();

        //Get number of local points
        int nnx = (_bfOrder_tmp*nx_tmp-(_bfOrder_tmp-1));
        int nny = (_bfOrder_tmp*ny_tmp-(_bfOrder_tmp-1));
        int nn_tmp = 0;
        _loc_nPts = 0;
        for (int j = 0; j < nny; j++)
        {
            for (int i = 0; i < nnx; i++)
            {
                if(disPts_tmp.isItemInPart(nn_tmp))
                {
                    int locN_tmp = disPts_tmp.locIdx(nn_tmp);
                    int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + locN_tmp];
                    if (MAxis % myMAxis == 0)
                        _loc_nPts++;
                }
                nn_tmp++;
            }
        }

        //Number of global elements
        int myAxis = getAxis(ax);
        if (myAxis == 0)
            _nEx = _nEx_tmp;
        else if (myAxis == 1)
            _nEx = _nEy_tmp;
        _nEy = -1;
        _nEz = -1;
        _nElem = _nEx;

        //Number of local elements
        nn_tmp = 0;
        _loc_nElem = 0;
        for (int j = 0; j < ny_tmp-1; j++)
        {
            for (int i = 0; i < nx_tmp-1; i++)
            {
                bool BoundElem = false;
                for (int jj = 0; jj < _bfOrder_tmp+1; jj++)
                {
                    for (int ii = 0; ii < _bfOrder_tmp+1; ii++)
                    {
                        if (disElem_tmp.isItemInPart(nn_tmp / _nVert_tmp) == true)
                        {
                            int locIdx_tmp  = disElem_tmp.locIdx(nn_tmp / _nVert_tmp);
                            int numNbor_tmp = nn_tmp % _nVert_tmp;
                            int Pts_tmp = _connec_tmp[locIdx_tmp * _nVert_tmp + numNbor_tmp];
                            if (disPts_tmp.isItemInPart(Pts_tmp) == true)
                            {
                                int loc_Pts_tmp = disPts_tmp.locIdx(Pts_tmp);
                                int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + loc_Pts_tmp];
                                if (MAxis % myMAxis == 0)
                                    BoundElem = true;
                            }
                        }
                        nn_tmp++;
                    }
                }
                if (BoundElem == true)
                    _loc_nElem++;
            }
        }

        //Check
        if (_loc_nPts == 0 || _loc_nElem == 0)
            throw runtime_error("StructMeshGenerator: FIXME, I'm a processor without points or elements.");

        //Element mapping (new to old)
        _elMap_newToOld.resize(_loc_nElem, 0);
        nn_tmp = 0;
        int loc_el = 0;
        for (int j=0; j<ny_tmp-1; j++)
        {
            for (int i=0; i<nx_tmp-1; i++)
            {
                bool BoundElem = false;
                for (int jj=0; jj<_bfOrder_tmp+1 ; jj++)
                {
                    for (int ii=0; ii<_bfOrder_tmp+1 ; ii++)
                    {
                        if (disElem_tmp.isItemInPart(nn_tmp / _nVert_tmp) == true)
                        {
                            int locIdx_tmp  = disElem_tmp.locIdx(nn_tmp / _nVert_tmp);
                            int numNbor_tmp = nn_tmp % _nVert_tmp;
                            int Pts_tmp = _connec_tmp[locIdx_tmp * _nVert_tmp + numNbor_tmp];
                            if (disPts_tmp.isItemInPart(Pts_tmp) == true)
                            {
                                int loc_Pts_tmp = disPts_tmp.locIdx(Pts_tmp);
                                int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + loc_Pts_tmp];
                                if (MAxis % myMAxis == 0)
                                {
                                    _elMap_newToOld[loc_el] = nn_tmp / _nVert_tmp;
                                    BoundElem = true;
                                }
                            }
                        }
                        nn_tmp++;
                    }
                }
                if (BoundElem == true)
                    loc_el++;
            }
        }

        //Communicate new element offsets
        vector<int> elOffSets_s, elOffSets;
        elOffSets_s.resize(numProcs(), 0);
        elOffSets.resize(numProcs(), 0);
        elOffSets_s[myRank()] = _loc_nElem;
        MPI_Allreduce(elOffSets_s.data(), elOffSets.data(), numProcs(), MPI_INT, MPI_MAX, MPI_COMM_WORLD);

        //Get my offsets
        int myOffset{};
        for (int m = 0; m < myRank(); m++)
            myOffset += elOffSets[m];

        //Connectivity
        _connec.resize(_loc_nElem * _nVert, 0);
        int nx = _nEx + 1;
        nnx = (_bfOrder*nx-(_bfOrder-1));
        int nn = 0;
        int el = 0;
        for (int i = 0; i < nx-1; i++)
        {
            int locElm = el - myOffset;
            for (int ii = 0; ii < _bfOrder+1; ii++)
            {
                int numNbor = (nn) % _nVert;
                if (locElm >= 0)
                    _connec[locElm * _nVert + numNbor] = i*_bfOrder + ii;
                nn++;
            }
            el++;
        }

        //Coordinates and creases
        _x_nodes.resize(_loc_nPts * _nDim, 0.0);
        _creases.resize(_loc_nPts * _nCreases, 0);
        nn_tmp = 0;
        int locN = 0;
        for (int j = 0; j < nny; j++)
        {
            for (int i = 0; i < nnx; i++)
            {
                if(disPts_tmp.isItemInPart(nn_tmp))
                {
                    int locN_tmp = disPts_tmp.locIdx(nn_tmp);
                    int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + locN_tmp];
                    if (MAxis % myMAxis == 0)
                    {
                        for (int m = 0; m < _nDim; m++)
                            _x_nodes[_loc_nPts * m + locN] = _x_nodes_tmp[_loc_nPts_tmp * m + locN_tmp];

                        for (int m = 0; m < _nCreases; m++)
                            _creases[_loc_nPts * m + locN] = _creases_tmp[_loc_nPts_tmp * m + locN_tmp];

                        locN ++;
                    }
                }
                nn_tmp++;
            }
        }

        /*
        //Reverse to keep normal vector consistent
        if ((myMAxis % 2 == 0) || (myMAxis % 7 == 0))
        {
            vector<double>::iterator iter_d;
            for (int m = 0; m < _nDim; m++)
            {
                iter_d = _x_nodes.begin() + m*_loc_nPts;
                reverse(iter_d, iter_d + _loc_nPts);
            }
            vector<int>::iterator iter_i;
            for (int m = 0; m < _nCreases; m++)
            {
                iter_i = _creases.begin() + m*_loc_nPts;
                reverse(iter_i, iter_i + _loc_nPts);
            }
        }
        */

    }

    void StructMeshGenerator::_genTriangBoundary(MAxis ax)
    {
        (void)ax;
        throw runtime_error("StructMeshGenerator: Triangular boundary mesh has not been done yet. You are kindly invited to implement it yourself.");
    }

    void StructMeshGenerator::_genSquareBoundary(MAxis ax)
    {

        //Get axis extreme
        int myMAxis = getMAxis(ax);

        //Number of vertices
        _nVert = (_bfOrder+1)*(_bfOrder+1);

        //Old mesh: IndexType::Local number of nodes and local number of elements per direction
        int nx_tmp = _nEx_tmp + 1;
        int ny_tmp = _nEy_tmp + 1;
        int nz_tmp = _nEz_tmp + 1;
        DistributedData disPts_tmp;
        disPts_tmp.setNItem(_nPts_tmp);
        disPts_tmp.Update();
        DistributedData disElem_tmp;
        disElem_tmp.setNItem(_nElem_tmp);
        disElem_tmp.Update();

        //Get number of local points
        int nnx = (_bfOrder_tmp*nx_tmp-(_bfOrder_tmp-1));
        int nny = (_bfOrder_tmp*ny_tmp-(_bfOrder_tmp-1));
        int nnz = (_bfOrder_tmp*nz_tmp-(_bfOrder_tmp-1));
        int nn_tmp = 0;
        _loc_nPts = 0;
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if(disPts_tmp.isItemInPart(nn_tmp))
                    {
                        int locN_tmp = disPts_tmp.locIdx(nn_tmp);
                        int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + locN_tmp];
                        if (MAxis % myMAxis == 0)
                            _loc_nPts++;
                    }
                    nn_tmp++;
                }
            }
        }

        //Number of global elements
        int myAxis = getAxis(ax);
        if (myAxis == 0)
        {
            _nEx = _nEy_tmp;
            _nEy = _nEz_tmp;
        }
        else if (myAxis == 1)
        {
            _nEx = _nEx_tmp;
            _nEy = _nEz_tmp;
        }
        else
        {
            _nEx = _nEx_tmp;
            _nEy = _nEy_tmp;
        }
        _nEz = -1;
        _nElem = _nEx*_nEy;

        //Number of local elements
        nn_tmp = 0;
        _loc_nElem = 0;
        for (int k=0; k<nz_tmp-1; k++)
        {
            for (int j = 0; j < ny_tmp-1; j++)
            {
                for (int i = 0; i < nx_tmp-1; i++)
                {
                    bool BoundElem = false;
                    for (int kk = 0; kk < _bfOrder_tmp+1; kk++)
                    {
                        for (int jj = 0; jj < _bfOrder_tmp+1; jj++)
                        {
                            for (int ii = 0; ii < _bfOrder_tmp+1; ii++)
                            {
                                if (disElem_tmp.isItemInPart(nn_tmp / _nVert_tmp) == true)
                                {
                                    int locIdx_tmp  = disElem_tmp.locIdx(nn_tmp / _nVert_tmp);
                                    int numNbor_tmp = nn_tmp % _nVert_tmp;
                                    int Pts_tmp = _connec_tmp[locIdx_tmp * _nVert_tmp + numNbor_tmp];
                                    if (disPts_tmp.isItemInPart(Pts_tmp) == true)
                                    {
                                        int loc_Pts_tmp = disPts_tmp.locIdx(Pts_tmp);
                                        int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + loc_Pts_tmp];
                                        if (MAxis % myMAxis == 0)
                                            BoundElem = true;
                                    }
                                }
                                nn_tmp++;
                            }
                        }
                    }
                    if (BoundElem == true)
                    _loc_nElem++;
                }
            }
        }

        //Check
        if (_loc_nPts == 0 || _loc_nElem == 0)
            throw runtime_error("StructMeshGenerator: FIXME, I'm a processor without points or elements.");

        //Element mapping (new to old)
        _elMap_newToOld.resize(_loc_nElem, 0);
        nn_tmp = 0;
        int loc_el = 0;
        for (int k=0; k<nz_tmp-1; k++)
        {
            for (int j=0; j<ny_tmp-1; j++)
            {
                for (int i=0; i<nx_tmp-1; i++)
                {
                    bool BoundElem = false;
                    for (int kk = 0; kk < _bfOrder_tmp+1; kk++)
                    {
                        for (int jj = 0; jj < _bfOrder_tmp+1 ; jj++)
                        {
                            for (int ii = 0; ii < _bfOrder_tmp+1 ; ii++)
                            {
                                if (disElem_tmp.isItemInPart(nn_tmp / _nVert_tmp) == true)
                                {
                                    int locIdx_tmp  = disElem_tmp.locIdx(nn_tmp / _nVert_tmp);
                                    int numNbor_tmp = nn_tmp % _nVert_tmp;
                                    int Pts_tmp = _connec_tmp[locIdx_tmp * _nVert_tmp + numNbor_tmp];
                                    if (disPts_tmp.isItemInPart(Pts_tmp) == true)
                                    {
                                        int loc_Pts_tmp = disPts_tmp.locIdx(Pts_tmp);
                                        int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + loc_Pts_tmp];
                                        if (MAxis % myMAxis == 0)
                                        {
                                            _elMap_newToOld[loc_el] = nn_tmp / _nVert_tmp;

                                            BoundElem = true;
                                        }
                                    }
                                }
                                nn_tmp++;
                            }
                        }
                    }
                    if (BoundElem == true)
                        loc_el++;
                }
            }
        }

        //Communicate new element offsets
        vector<int> elOffSets_s, elOffSets;
        elOffSets_s.resize(numProcs(), 0);
        elOffSets.resize(numProcs(), 0);
        elOffSets_s[myRank()] = _loc_nElem;
        MPI_Allreduce(elOffSets_s.data(), elOffSets.data(), numProcs(), MPI_INT, MPI_MAX, MPI_COMM_WORLD);

        //Get my offsets
        int myOffset{};
        for (int m = 0; m < myRank(); m++)
            myOffset += elOffSets[m];

        //Connectivity
        _connec.resize(_loc_nElem * _nVert, 0);
        int nx = _nEx + 1;
        int ny = _nEy + 1;
        nnx = (_bfOrder*nx-(_bfOrder-1));
        nny = (_bfOrder*ny-(_bfOrder-1));
        int nn = 0;
        int el = 0;
        for (int j = 0; j < ny-1; j++)
        {
            for (int i = 0; i < nx-1; i++)
            {
                int locElm = el - myOffset;
                for (int jj = 0; jj < _bfOrder+1; jj++)
                {
                    for (int ii = 0; ii < _bfOrder+1; ii++)
                    {
                        int numNbor = (nn) % _nVert;
                        if (locElm >= 0)
                            _connec[locElm * _nVert + numNbor] = j*nnx*_bfOrder + jj*nnx + i*_bfOrder + ii;
                        nn++;
                    }
                }
                el++;
            }
        }

        //Coordinates and creases
        _x_nodes.resize(_loc_nPts * _nDim, 0.0);
        _creases.resize(_loc_nPts * _nCreases, 0);
        nn_tmp = 0;
        int locN = 0;
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if(disPts_tmp.isItemInPart(nn_tmp))
                    {
                        int locN_tmp = disPts_tmp.locIdx(nn_tmp);
                        int MAxis = _creases_tmp[_loc_nPts_tmp * 1 + locN_tmp];
                        if (MAxis % myMAxis == 0)
                        {
                            for (int m = 0; m < _nDim; m++)
                                _x_nodes[_loc_nPts * m + locN] = _x_nodes_tmp[_loc_nPts_tmp * m + locN_tmp];

                            for (int m = 0; m < _nCreases; m++)
                                _creases[_loc_nPts * m + locN] = _creases_tmp[_loc_nPts_tmp * m + locN_tmp];

                            locN ++;
                        }
                    }
                    nn_tmp++;
                }
            }
        }

    }


}
