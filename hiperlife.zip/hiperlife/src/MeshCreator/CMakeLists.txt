#============================================================
# hiperlife's MeshCreator Shared library
#============================================================

#------------------------------------------------------------
# Get source files
#------------------------------------------------------------
file(GLOB SOURCES_H_hl  hl_Mesh*.h hl_Struct*.h hl_Basic*.h hl_Multi*.h)
file(GLOB SOURCES_CPP_hl hl_Mesh*.cpp hl_Struct*.cpp hl_Basic*.cpp hl_Multi*.cpp)

if(GMSH_FOUND)
  #Include directories
  include_directories(SYSTEM ${GMSH_INCLUDE_DIRS})

  #Glob Source files
  file(GLOB SOURCES_H_GMSH  hl_UnstructGmsh*.h)
  file(GLOB SOURCES_CPP_GMSH hl_UnstructGmsh*.cpp)
else()
  message(STATUS "Warning!! Gmsh module is disabled.")
endif()

if(VTK_FOUND)
  #Include directories
  include_directories(SYSTEM ${VTK_INCLUDE_DIRS})

  #Glob Source files
  file(GLOB SOURCES_H_VTK  vtk*.h hl_UnstructVtk*.h)
  file(GLOB SOURCES_CPP_VTK vtk*.cpp hl_UnstructVtk*.cpp)
else()
  message(STATUS "Warning!! VTK module is disabled.")
endif()


#Set source files
set(SOURCES_H ${SOURCES_H_hl} ${SOURCES_H_VTK} ${SOURCES_H_GMSH})
set(SOURCES_CPP ${SOURCES_CPP_hl} ${SOURCES_CPP_VTK} ${SOURCES_CPP_GMSH})
set(SOURCE_FILES ${SOURCES_H} ${SOURCES_CPP})

#------------------------------------------------------------
# Build the library
#------------------------------------------------------------
set(LIBNAME hlMeshCreator)
add_library(${LIBNAME} ${SOURCE_FILES})

target_link_libraries(${LIBNAME} ${MPI_LIB})
target_link_libraries(${LIBNAME} ${Trilinos_LIBRARIES})
target_link_libraries(${LIBNAME} ${HPLFE_LIBRARIES})

if(GMSH_LIB)
  if(GMSH_DOWNLOADING)
    add_dependencies(${LIBNAME} Gmsh)
  endif(GMSH_DOWNLOADING)
  target_link_libraries(${LIBNAME} ${GMSH_LIB})
endif()

if(VTK_FOUND)
  if(VTK_DOWNLOADING)
    add_dependencies(${LIBNAME} VTK)
    target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
  endif(VTK_DOWNLOADING)
  target_link_libraries(${LIBNAME} ${VTK_LIBRARIES})
endif(VTK_FOUND)


install(TARGETS ${LIBNAME} DESTINATION lib EXPORT hiperlifeTargets)
install(FILES ${SOURCES_H} DESTINATION include)


#------------------------------------------------------------
# Store the Library
#------------------------------------------------------------
set(HPLFE_LIBRARIES ${HPLFE_LIBRARIES} ${LIBNAME} CACHE INTERNAL "HPLFE_LIBRARIES")
