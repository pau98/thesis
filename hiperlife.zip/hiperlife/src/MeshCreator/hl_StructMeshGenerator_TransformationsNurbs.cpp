/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francisco Javier Gual
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <vector>
#include <deque>

#include "hl_TypeDefs.h"
#include "hl_Math.h"
#include "hl_Geometry.h"

#include "hl_StructMeshGenerator.h"

using std::cout;
using std::endl;
using std::vector;
using std::function;
using std::runtime_error;

namespace hiperlife
{

    //h-refinement
    int _findSpan(vector<double> &U, int p, int n, double u)
    {
        // Algorithm from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; pp. 68.
        // Determine the knot span index */
        // Input:
        // u are the coordinates.
        // U is the knot vector.
        // p is the interpolation order.
        // Return: the knot span index.

        double low, mid, high;

        if (abs(u-U[n+1]) < 1e-6) return n;
        //* Special case */
        low = p;
        high = n+1;
        //* Do binary search */
        mid =(low+high)/2;
        while (u < U[mid] || u >= U[mid+1])
        {
            if (u < U[mid])
                high = mid;
            else
                low = mid;
            mid = (low+high)/2;
        }

        return mid;

    }

    void _refineKnotVectCurve(vector<double> &Ubar, vector<vector<double>> &Qw, int n, int p, vector<double> &U, vector<vector<double>> &Pw, vector<double> &X, int r)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; p. 164.
        /* Refine curve knot vector */
        /* Input: n,p,U,Pw,X,r */
        /* Output: Ubar,Qw */

        //Modify for HPLFE
        n--;
        r--;
        int s = Pw[0].size();

        //Find interval of inserted knots
        int a = _findSpan(U, p, n, X[0]);
        int b = _findSpan(U, p, n, X[r]);

        //Save unaltered knots and control points outside this interval
        b = b + 1;
        for (int j = 0; j <= a; j++)
            Ubar[j] = U[j];
        for (int j = b+p; j <= n+p+1; j++)
            Ubar[j+r+1] = U[j];
        for (int j = 0; j <= a-p; j++)
            for (int d = 0; d < s; d++)
                Qw[j][d] = Pw[j][d];
        for (int j = b-1; j <= n; j++)
            for (int d = 0; d < s; d++)
                Qw[j+r+1][d] = Pw[j][d];

        //Compute new knots and control points
        int i = b+p-1;
        int k = b+p+r;
        for (int j = r; j >= 0; j--)
        {

            while (X[j] <= U[i] && i > a)
            {
                Ubar[k] = U[i];
                for (int d = 0; d < s; d++)
                    Qw[k-p-1][d] = Pw[i-p-1][d];
                k = k-1;
                i = i-1;
            }

            for (int d = 0; d < s; d++)
                Qw[k-p-1][d] = Qw[k-p][d];

            for (int l = 1; l <= p; l++)
            {
                int ind = k-p+l;
                double alfa = Ubar[k+l]-X[j];
                if (abs(alfa) == 0.0)
                {
                    for (int d = 0; d < s; d++)
                        Qw[ind-1][d] = Qw[ind][d];
                }
                else
                {
                    alfa = alfa/(Ubar[k+l]-U[i-p+l]);
                    for (int d = 0; d < s; d++)
                        Qw[ind-1][d] = alfa*Qw[ind-1][d] + (1.0-alfa)*Qw[ind][d];
                }
            }
            Ubar[k] = X[j];
            k = k-1;
        }

    }

    void _refineKnotVectSurf(vector<double> &Ubar, vector<double> &Vbar, vector<vector<vector<double>>> &Qw, int n, int p, vector<double> &U, int m, int q, vector<double> &V, vector<vector<vector<double>>> &Pw, vector<double> &X, int r, int dir)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; p. 167.
        /* Input: n,p,U,m,q,V,Pw,X,r,dir */
        /* Output: Ubar, Vbar, Qw */

        //Modify for HPLFE
        n--;
        m--;
        r--;
        int s = static_cast<int>(Pw[0][0].size());

        if (dir == 0)
        {
            //Find indexes a and b;
            int a = _findSpan(U, p, n, X[0]);
            int b = _findSpan(U, p, n, X[r]);
            //Initialize Ubar;
            for (int j = 0; j <= a; j++)
                Ubar[j] = U[j];
            for (int j = b+p; j <= n+p+1; j++) //Not sure of n
                Ubar[j+r+1] = U[j];

            //Copy V into Vbar;
            for (auto j = 0u; j < V.size(); j++)
                Vbar[j] = V[j];

            //Save unaltered control points
            for (int row = 0; row <= m; row++)
            {
                for (int k = 0; k <= a-p; k++)
                    for (int d = 0; d < s; d++)
                        Qw[k][row][d] = Pw[k][row][d];
                for (int k = b-1; k <= n; k++)
                    for (int d = 0; d < s; d++)
                        Qw[k+r+1][row][d] = Pw[k][row][d];
            }

            int i = b+p-1;
            int k = b+p+r;
            for (int j = r; j >= 0; j--)
            {
                while (X[j] <= U[i] && i > a)
                {
                    Ubar[k] = U[i];
                    for (int row = 0; row <= m; row++)
                        for (int d = 0; d < s; d++)
                            Qw[k-p-1][row][d] = Pw[i-p-1][row][d];
                    k = k-1;
                    i = i-1;
                }

                for (int row = 0; row <= m; row++)
                    for (int d = 0; d < s; d++)
                        Qw[k-p-1][row][d] = Qw[k-p][row][d];

                for (int l = 1; l <= p; l++)
                {
                    int ind = k-p+l;
                    double alfa = Ubar[k+l]-X[j];
                    if (abs(alfa) == 0.0)
                    {
                        for (int row = 0; row <= m; row++)
                            for (int d = 0; d < s; d++)
                                Qw[ind-1][row][d] = Qw[ind][row][d];
                    }
                    else
                    {
                        alfa = alfa/(Ubar[k+l]-U[i-p+l]);
                        for (int row = 0; row <= m; row++)
                            for (int d = 0; d < s; d++)
                                Qw[ind-1][row][d] = alfa*Qw[ind-1][row][d]+(1.0-alfa)*Qw[ind][row][d];
                    }
                }
                Ubar[k] = X[j];
                k = k-1;
            }
        }
        if (dir == 1)
        {
            //Find indexes a and b;
            int a = _findSpan(V, q, m, X[0]);
            int b = _findSpan(V, q, m, X[r]);
            //Initialize Vbar;
            for (int j = 0; j <= a; j++)
                Vbar[j] = V[j];
            for (int j = b+q; j <= m+q+1; j++)
                Vbar[j+r+1] = V[j];
            //Copy U into Ubar;
            for (auto j = 0u; j < V.size(); j++)
                Ubar[j] = U[j];

            //Save unaltered control points
            for (int col = 0; col <= n; col++)
            {
                for (int k = 0; k <= a-q; k++)
                    for (int d = 0; d < s; d++)
                        Qw[col][k][d] = Pw[col][k][d];
                for (int k = b-1; k <= m; k++)
                    for (int d = 0; d < s; d++)
                        Qw[col][k+r+1][d] = Pw[col][k][d];
            }

            int i = b+q-1;
            int k = b+q+r;
            for (int j = r; j >= 0; j--)
            {
                while (X[j] <= V[i] && i > a)
                {
                    Vbar[k] = V[i];
                    for (int col = 0; col <= n; col++)
                        for (int d = 0; d < s; d++)
                            Qw[col][k-q-1][d] = Pw[col][i-q-1][d];
                    k = k-1;
                    i = i-1;
                }

                for (int col = 0; col <= n; col++)
                    for (int d = 0; d < s; d++)
                        Qw[col][k-q-1][d] = Qw[col][k-q][d];

                for (int l = 1; l <= q; l++)
                {
                    int ind = k-q+l;
                    double alfa = Vbar[k+l]-X[j];
                    if (abs(alfa) == 0.0)
                    {
                        for (int col = 0; col <= n; col++)
                            for (int d = 0; d < s; d++)
                                Qw[col][ind-1][d] = Qw[col][ind][d];
                    }
                    else
                    {
                        alfa = alfa/(Vbar[k+l]-V[i-q+l]);
                        for (int col = 0; col <= n; col++)
                            for (int d = 0; d < s; d++)
                                Qw[col][ind-1][d] = alfa*Qw[col][ind-1][d]+(1.0-alfa)*Qw[col][ind][d];
                    }
                }
                Vbar[k] = X[j];
                k = k-1;
            }
        }

    }

    void _refineKnotVectSolid(vector<double> &Ubar, vector<double> &Vbar, vector<double> &Wbar, vector<vector<vector<vector<double>>>> &Qw, int nnx, int order_x, vector<double> &U, int nny, int order_y, vector<double> &V, int nnz, int order_z, vector<double> &W, vector<vector<vector<vector<double>>>> &CP, vector<double> &X, int r, int dir)
    {
        /* Adapted from Austin Cottrell's fortran code */

        int s = static_cast<int>(CP[0][0][0].size());

        if (dir == 0)
        {
            //Initialize
            vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny,vector<double>(s)));
            vector<vector<vector<double>>> xyCPbar(nnx+r, vector<vector<double>>(nny, vector<double>(s)));

            //For each k
            for (int k = 0; k < nnz; k++)
            {
                //Save control net
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            xyCP[i][j][d] = CP[i][j][k][d];
                        }
                    }
                }

                //Refine
                _refineKnotVectSurf(Ubar, Vbar, xyCPbar, nnx, order_x, U, nny, order_y, V, xyCP, X, r, 0);

                //Update control net
                for (int i = 0; i < nnx+r; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            Qw[i][j][k][d] = xyCPbar[i][j][d];
                        }
                    }
                }

            }

        }
        else if (dir == 1)
        {
            //Initialize
            vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny,vector<double>(s)));
            vector<vector<vector<double>>> xyCPbar(nnx, vector<vector<double>>(nny+r, vector<double>(s)));

            //For each k
            for (int k = 0; k < nnz; k++)
            {
                //Save control net
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            xyCP[i][j][d] = CP[i][j][k][d];
                        }
                    }
                }

                //Refine
                _refineKnotVectSurf(Ubar, Vbar, xyCPbar, nnx, order_x, U, nny, order_y, V, xyCP, X, r, 1);

                //Update control net
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny+r; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            Qw[i][j][k][d] = xyCPbar[i][j][d];
                        }
                    }
                }

            }

        }
        else if (dir == 2)
        {
            //Initialize
            vector<vector<vector<double>>> zxCP(nnz, vector<vector<double>>(nnx,vector<double>(s)));
            vector<vector<vector<double>>> zxCPbar(nnz+r, vector<vector<double>>(nnx, vector<double>(s)));

            //For each k
            for (int j = 0; j < nny; j++)
            {
                //Save control net
                for (int k = 0; k < nnz; k++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            zxCP[k][i][d] = CP[i][j][k][d];
                        }
                    }
                }

                //Refine
                _refineKnotVectSurf(Wbar, Ubar, zxCPbar, nnz, order_z, W, nnx, order_x, U, zxCP, X, r, 0);

                //Update control net
                for (int k = 0; k < nnz+r; k++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            Qw[i][j][k][d] = zxCPbar[k][i][d];
                        }
                    }
                }

            }

        }

    }

    void StructMeshGenerator::_refineNurbsCurve(vector<double> X)
    {
        //Initialize
        int rx = static_cast<int>(X.size());
        int order_x = _bfOrderX;
        int lengthUKnot = _nEx + 1 + 2*order_x;
        int nnx = _nEx + order_x;

        //Rearrange and form projective control point vector
        vector<vector<double>> xCP(nnx, vector<double>(4));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        xCP[i][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        xCP[i][d] *= xCP[i][3];
                    }
                }
            }
        }

        //New knot and control point vectors
        vector<double> Ubar(lengthUKnot+rx);
        vector<vector<double>> xCPbar(nnx+rx, vector<double>(4));

        //Refine in x
        if (rx > 0)
        {
            _refineKnotVectCurve(Ubar, xCPbar, nnx, order_x, _uKnot, xCP, X, rx);
        }
        else
        {
            xCPbar = xCP;
            Ubar = _uKnot;
        }

        //Convert projective coordinates into physical coordinates
        vector<vector<vector<vector<double>>>> CP(nnx+rx, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        for (int i = 0; i < nnx+rx; i++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int k = 0; k < 1; k++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = xCPbar[i][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Generate mesh
        _genNurbsCurve(_bfOrderX, Ubar, CP);

    }

    void StructMeshGenerator::_refineNurbsSurface(vector<double> X, vector<double> Y)
    {
        //Initialize
        int rx = static_cast<int>(X.size());
        int order_x = _bfOrderX;
        int lengthUKnot = _nEx + 1 + 2*order_x;
        int nnx = _nEx + order_x;
        int ry = static_cast<int>(Y.size());
        int order_y = _bfOrderY;
        int lengthVKnot = _nEy + 1 + 2*order_y;
        int nny = _nEy + order_y;

        //Rearrange and form projective control point vector
        vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny, vector<double>(4)));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        xyCP[i][j][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        xyCP[i][j][d] *= xyCP[i][j][3];
                    }
                }
            }
        }

        //New knot and control point vectors
        vector<double> Ubar(lengthUKnot+rx);
        vector<double> Vbar(lengthVKnot+ry);
        vector<vector<vector<double>>> xyCPbarx(nnx+rx, vector<vector<double>>(nny, vector<double>(4)));
        vector<vector<vector<double>>> xyCPbar(nnx+rx, vector<vector<double>>(nny+ry, vector<double>(4)));

        //Refine in x
        if (rx > 0)
        {
            _refineKnotVectSurf(Ubar, _vKnot, xyCPbarx, nnx, order_x, _uKnot, nny, order_y, _vKnot, xyCP, X, rx, 0);
        }
        else
        {
            xyCPbarx = xyCP;
            Ubar = _uKnot;
        }

        //Refine in y
        if (ry > 0)
        {
            _refineKnotVectSurf(Ubar, Vbar, xyCPbar, nnx+rx, order_x, Ubar, nny, order_y, _vKnot, xyCPbarx, Y, ry, 1);
        }
        else
        {
            xyCPbar = xyCPbarx;
            Vbar = _vKnot;
        }

        //Convert projective coordinates into physical coordinates
        vector<vector<vector<vector<double>>>> CP(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(1, vector<double>(4))));
        for (int i = 0; i < nnx+rx; i++)
        {
            for (int j = 0; j < nny+ry; j++)
            {
                for (int k = 0; k < 1; k++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = xyCPbar[i][j][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Generate mesh
        _genNurbsSurface(order_x, order_y, Ubar, Vbar, CP);

    }

    void StructMeshGenerator::_refineNurbsSolid(vector<double> X, vector<double> Y, vector<double> Z)
    {
        //Initialize
        int rx = static_cast<int>(X.size());
        int order_x = _bfOrderX;
        int lengthUKnot = _nEx + 1 + 2*order_x;
        int nnx = _nEx + order_x;
        int ry = static_cast<int>(Y.size());
        int order_y = _bfOrderY;
        int lengthVKnot = _nEy + 1 + 2*order_y;
        int nny = _nEy + order_y;
        int rz = static_cast<int>(Z.size());
        int order_z = _bfOrderZ;
        int lengthWKnot = _nEz + 1 + 2*order_z;
        int nnz = _nEz + order_z;

        //Rearrange and form projective control point vector
        vector<vector<vector<vector<double>>>> CP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] *= CP[i][j][k][3];
                    }
                }
            }
        }

        //New knot and control point vectors
        vector<double> Ubar(lengthUKnot+rx);
        vector<double> Vbar(lengthVKnot+ry);
        vector<double> Wbar(lengthWKnot+rz);
        vector<vector<vector<vector<double>>>> CPbarx(nnx+rx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        vector<vector<vector<vector<double>>>> CPbarxy(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(nnz, vector<double>(4))));
        vector<vector<vector<vector<double>>>> CPbar(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(nnz+rz, vector<double>(4))));

        //Refine in x
        if (rx > 0)
        {
            _refineKnotVectSolid(Ubar, _vKnot, _wKnot, CPbarx, nnx, order_x, _uKnot, nny, order_y, _vKnot, nnz, order_z, _wKnot, CP, X, rx, 0);
        }
        else
        {
            CPbarx = CP;
            Ubar = _uKnot;
        }

        //Refine in y
        if (ry > 0)
        {
            _refineKnotVectSolid(Ubar, Vbar, _wKnot, CPbarxy, nnx+rx, order_x, Ubar, nny, order_y, _vKnot, nnz, order_z, _wKnot, CPbarx, Y, ry, 1);
        }
        else
        {
            CPbarxy = CPbarx;
            Vbar = _vKnot;
        }

        //Refine in z
        if (rz > 0)
        {
            _refineKnotVectSolid(Ubar, Vbar, Wbar, CPbar, nnx+rx, order_x, Ubar, nny+ry, order_y, Vbar, nnz, order_z, _wKnot, CPbarxy, Z, rz, 2);
        }
        else
        {
            CPbar = CPbarxy;
            Wbar = _wKnot;
        }

        //Convert projective coordinates into physical coordinates
        CP.clear();
        CP.resize(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(nnz+rz, vector<double>(4))));
        for (int k = 0; k < nnz+rz; k++)
        {
            for (int j = 0; j < nny+ry; j++)
            {
                for (int i = 0; i < nnx+rx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = CPbar[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Generate mesh
        _genNurbsSolid(order_x, order_y, order_z, Ubar, Vbar, Wbar, CP);

    }


    //Uniform refinement
    void StructMeshGenerator::_uniformlyRefineNurbsCurve(int nEx)
    {
        //Get number of elements with non-zero length
        int nn0Ex{};
        for (auto i = 0u; i < _uKnot.size()-1; i++)
        {
            double u0 = _uKnot[i];
            double u1 = _uKnot[i+1];
            if (abs(u1-u0) > 1.e-6)
                nn0Ex++;
        }

        //Checks
        if (nEx == nn0Ex)
            return;
        // if ((nEx < nn0Ex) && (nEx > -1))
        // {
        //     return; //FIXME: ????
        //     throw runtime_error("StructMeshGenerator: _uniformlyRefineNurbsCurve: You cannot refine a curve with less elements.");
        // }
        // if ((nEx % nn0Ex != 0) && (nEx > -1))
        //     throw runtime_error("StructMeshGenerator: _uniformlyRefineNurbsCurve: Uniform refinement can only be achieved when the new number of elements is a multiple of the original one.");

        //Increase the size of the knot vector with the number of elements
        if (nEx > 1)
        {
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= nEx/double(nn0Ex);
        }

        //New knots to be inserted
        vector<double> X;
        if (nEx > 1 and nEx > nn0Ex)
        {
            double uLength = _uKnot.back() - _uKnot.front();
            for (int i = 0; i < nEx-1; i++)
            {
                if ((i+1) % (nEx/nn0Ex) != 0)
                    X.push_back((i+1)/(double) nEx * uLength);
            }
        }

        //Refine
        _refineNurbsCurve(X);
    }

    void StructMeshGenerator::_uniformlyRefineNurbsSurface(int nEx, int nEy)
    {
        //Get number of elements with non-zero length
        int nn0Ex{};
        for (auto i = 0u; i < _uKnot.size()-1; i++)
        {
            double u0 = _uKnot[i];
            double u1 = _uKnot[i+1];
            if (abs(u1-u0) > 1.e-6)
                nn0Ex++;
        }
        int nn0Ey{};
        for (auto i = 0u; i < _vKnot.size()-1; i++)
        {
            double v0 = _vKnot[i];
            double v1 = _vKnot[i+1];
            if (abs(v1-v0) > 1.e-6)
                nn0Ey++;
        }

        //Checks
        if ((nEx == nn0Ex) and (nEy == nn0Ey))
            return;
        // if (((nEx < nn0Ex) && (nEx > 0)) || ((nEy < nn0Ey) && (nEy > 0)))
        // {
        //     return; //FIXME: ????
        //     if (_hRefinedMesh == true) //FIXME: ????
        //         return;
        //     throw runtime_error("StructMeshGenerator: _uniformlyRefineNurbsSurface: You cannot refine a curve with less elements.");
        // }
        // if (((nEx % nn0Ex != 0) && (nEx > 0)) || ((nEy % nn0Ey != 0) && (nEy > 0)))
        //     throw runtime_error("StructMeshGenerator: _uniformlyRefineNurbsSurface: Uniform refinement can only be achieved when the new number of elements is a multiple of the original one.");

        //Increase the size of the knot vectors with the number of elements
        if (nEx > 1)
        {
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= nEx/double(nn0Ex);
        }
        if (nEy > 1)
        {
            for (auto i = 0u; i < _vKnot.size(); i++)
                _vKnot[i] *= nEy/double(nn0Ey);
        }

        //New knots to be inserted
        vector<double> X, Y;
        if (nEx > 1 and nEx > nn0Ex)
        {
            double uLength = _uKnot.back() - _uKnot.front();
            for (int i = 0; i < nEx-1; i++)
            {
                if ((i+1) % (nEx/nn0Ex) != 0)
                    X.push_back((i+1)/(double) nEx * uLength);
            }
        }
        if (nEy > 1 and nEy > nn0Ey)
        {
            double vLength = _vKnot.back() - _vKnot.front();
            for (int i = 0; i < nEy-1; i++)
            {
                if ((i+1) % (nEy/nn0Ey) != 0)
                    Y.push_back((i+1)/(double) nEy * vLength);
            }
        }

        //Refine
        _refineNurbsSurface(X, Y);
    }

    void StructMeshGenerator::_uniformlyRefineNurbsSolid(int nEx, int nEy, int nEz)
    {
        //Get number of elements with non-zero length //FIXME:: I don't think this is necessary (change everywhere)
        int nn0Ex{};
        for (auto i = 0u; i < _uKnot.size()-1; i++)
        {
            double u0 = _uKnot[i];
            double u1 = _uKnot[i+1];
            if (abs(u1-u0) > 1.e-6)
                nn0Ex++;
        }
        int nn0Ey{};
        for (auto i = 0u; i < _vKnot.size()-1; i++)
        {
            double v0 = _vKnot[i];
            double v1 = _vKnot[i+1];
            if (abs(v1-v0) > 1.e-6)
                nn0Ey++;
        }
        int nn0Ez{};
        for (auto i = 0u; i < _wKnot.size()-1; i++)
        {
            double w0 = _wKnot[i];
            double w1 = _wKnot[i+1];
            if (abs(w1-w0) > 1.e-6)
                nn0Ez++;
        }

        //Checks
        if ((nEx == nn0Ex) and (nEy == nn0Ey) and (nEz == nn0Ez))
            return;
        // if (((nEx < nn0Ex) && (nEx > 0)) || ((nEy < nn0Ey) && (nEy > 0)) || ((nEz < nn0Ez) && (nEz > 0)))
        // {
        //     return; //FIXME: ????
        //     throw runtime_error("StructMeshGenerator: _uniformlyRefineNurbsSolid: You cannot refine a curve with less elements.");
        // }
        // if (((nEx % nn0Ex != 0) && (nEx > 0)) || ((nEy % nn0Ey != 0) && (nEy > 0)) || ((nEz % nn0Ez != 0) && (nEz > 0)))
        //     throw runtime_error("StructMeshGenerator: _uniformlyRefineNurbsSolid: Uniform refinement can only be achieved when the new number of elements is a multiple of the original one.");

        //Increase the size of the knot vectors with the number of elements
        if (nEx > 1)
        {
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= nEx/double(nn0Ex);
        }
        if (nEy > 1)
        {
            for (auto i = 0u; i < _vKnot.size(); i++)
                _vKnot[i] *= nEy/double(nn0Ey);
        }
        if (nEz > 1)
        {
            for (auto i = 0u; i < _wKnot.size(); i++)
                _wKnot[i] *= nEz/double(nn0Ez);
        }

        //New knots to be inserted
        vector<double> X, Y, Z;
        if (nEx > 1 and nEx > nn0Ex)
        {
            double uLength = _uKnot.back() - _uKnot.front();
            for (int i = 0; i < nEx-1; i++)
            {
                if ((i+1) % (nEx/nn0Ex) != 0)
                    X.push_back((i+1)/(double) nEx * uLength);
            }
        }
        if (nEy > 1 and nEy > nn0Ey)
        {
            double vLength = _vKnot.back() - _vKnot.front();
            for (int i = 0; i < nEy-1; i++)
            {
                if ((i+1) % (nEy/nn0Ey) != 0)
                    Y.push_back((i+1)/(double) nEy * vLength);
            }
        }
        if (nEz > 1 and nEz > nn0Ez)
        {
            double wLength = _wKnot.back() - _wKnot.front();
            for (int i = 0; i < nEz-1; i++)
            {
                if ((i+1) % (nEz/nn0Ez) != 0)
                    Z.push_back((i+1)/(double) nEz * wLength);
            }
        }

        //Refine
        _refineNurbsSolid(X, Y, Z);

    }

    void StructMeshGenerator::_uniformlyRefineNurbs(int newTotalnEx, int newTotalnEy, int newTotalnEz)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator: Cannot perform transformation before generating the mesh.");
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (newTotalnEx < -1 || newTotalnEy != -1 || newTotalnEz != -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _uniformlyRefineNurbs: Line elements can only be refined in x direction.");
                _uniformlyRefineNurbsCurve(newTotalnEx);
                break;
            case static_cast<int>(ElemType::Square):
                if (newTotalnEx < -1 || newTotalnEy < -1 || newTotalnEz != -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _uniformlyRefineNurbs: Square elements can only be refined in x and y directions.");
                _uniformlyRefineNurbsSurface(newTotalnEx, newTotalnEy);
                break;
            case static_cast<int>(ElemType::Parallelep):
                if (newTotalnEx < -1 || newTotalnEy < -1 || newTotalnEz < -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _uniformlyRefineNurbs: Square elements can only be refined in x, y and z directions.");
                _uniformlyRefineNurbsSolid(newTotalnEx, newTotalnEy, newTotalnEz);
                break;
            default:
                throw runtime_error("StructMeshGenerator: _uniformlyRefineNurbs: Wrong element type.");
        }

        //Save history
        _history.emplace_back([=](){_uniformlyRefineNurbs(newTotalnEx, newTotalnEy, newTotalnEz);});
        _history_names.push_back(__FUNCTION__);

    }

    //Refinement by subdivision
    void StructMeshGenerator::_subdivideNurbsCurve(int levelx)
    {
        //New knots to be inserted
        vector<double> X;
        if (levelx > 0)
        {
            //Increase the size of the knot vector with the number of elements
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= levelx;

            //Create new knots
            for (auto i = 0u; i < _uKnot.size()-1; i++)
            {
                double u0 = _uKnot[i];
                double u1 = _uKnot[i+1];
                if (u0 == u1)
                    continue;
                for (int j = 0; j < levelx; j++)
                    X.push_back(u0 + (u1-u0)/(double) (levelx+1));
            }
        }

        //Refine
        _refineNurbsCurve(X);
    }

    void StructMeshGenerator::_subdivideNurbsSurface(int levely, int levelx)
    {
        //New knots to be inserted
        vector<double> X, Y;
        if (levelx > 0)
        {
            //Increase the size of the knot vector with the number of elements
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= levelx;

            //Create new knots
            for (auto i = 0u; i < _uKnot.size()-1; i++)
            {
                double u0 = _uKnot[i];
                double u1 = _uKnot[i+1];
                if (u0 == u1)
                    continue;
                for (int j = 0; j < levelx; j++)
                    X.push_back(u0 + (u1-u0)/(double) (levelx+1));
            }
        }
        if (levely > 0)
        {
            //Increase the size of the knot vector with the number of elements
            for (auto i = 0u; i < _vKnot.size(); i++)
                _vKnot[i] *= levely;

            //Create new knots
            for (auto i = 0u; i < _vKnot.size()-1; i++)
            {
                double v0 = _vKnot[i];
                double v1 = _vKnot[i+1];
                if (v0 == v1)
                    continue;
                for (int j = 0; j < levely; j++)
                    Y.push_back(v0 + (v1-v0)/(double) (levely+1));
            }
        }

        //Refine
        _refineNurbsSurface(X, Y);

    }

    void StructMeshGenerator::_subdivideNurbsSolid(int levelx, int levely, int levelz)
    {

        //New knots to be inserted
        vector<double> X, Y, Z;
        if (levelx > 0)
        {
            //Increase the size of the knot vector with the number of elements
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= levelx;

            //Create new knots
            for (auto i = 0u; i < _uKnot.size()-1; i++)
            {
                double u0 = _uKnot[i];
                double u1 = _uKnot[i+1];
                if (u0 == u1)
                    continue;
                for (int j = 0; j < levelx; j++)
                    X.push_back(u0 + (u1-u0)/(double) (levelx+1));
            }
        }
        if (levely > 0)
        {
            //Increase the size of the knot vector with the number of elements
            for (auto i = 0u; i < _vKnot.size(); i++)
                _vKnot[i] *= levely;

            //Create new knots
            for (auto i = 0u; i < _vKnot.size()-1; i++)
            {
                double v0 = _vKnot[i];
                double v1 = _vKnot[i+1];
                if (v0 == v1)
                    continue;
                for (int j = 0; j < levely; j++)
                    Y.push_back(v0 + (v1-v0)/(double) (levely+1));
            }
        }
        if (levelz > 0)
        {
            //Increase the size of the knot vector with the number of elements
            for (auto i = 0u; i < _wKnot.size(); i++)
                _wKnot[i] *= levelz;

            //Create new knots
            for (auto i = 0u; i < _wKnot.size()-1; i++)
            {
                double w0 = _wKnot[i];
                double w1 = _wKnot[i+1];
                if (w0 == w1)
                    continue;
                for (int j = 0; j < levelz; j++)
                    Z.push_back(w0 + (w1-w0)/(double) (levelz+1));
            }
        }

        //Refine
        _refineNurbsSolid(X, Y, Z);

    }

    void StructMeshGenerator::_subdivideNurbs(int levelx, int levely, int levelz)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator: Cannot perform transformation before generating the mesh.");
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (levelx < 1 || levely != 0 || levelz != 0)
                    throw runtime_error("StructMeshGenerator_Transformations: _subdivideNurbs: Line elements can only be subdivided in x direction.");
                _subdivideNurbsCurve(levelx);
                break;
            case static_cast<int>(ElemType::Square):
                if (levelx < 1 || levely < 1 || levelz != 0)
                    throw runtime_error("StructMeshGenerator_Transformations: _subdivideNurbs: Square elements can only be subdivided in x and y directions.");
                _subdivideNurbsSurface(levelx, levely);
                break;
            case static_cast<int>(ElemType::Parallelep):
                if (levelx < 1 || levely < 1 || levelz < 1)
                    throw runtime_error("StructMeshGenerator_Transformations: _subdivideNurbs: Square elements can only be subdivided in x, y and z directions.");
                _subdivideNurbsSolid(levelx, levely, levelz);
                break;
            default:
                throw runtime_error("StructMeshGenerator: _subdivideNurbs: Wrong element type.");
        }

        //Save history
        _history.emplace_back([=](){_subdivideNurbs(levelx, levely, levelz);});
        _history_names.push_back(__FUNCTION__);

    }


    //Free refinement
    void StructMeshGenerator::_freelyRefineNurbsCurve(int nEx, function<double(double)> fx)
    {
        //Get number of elements with non-zero length
        int nn0Ex{};
        for (auto i = 0u; i < _uKnot.size()-1; i++)
        {
            double u0 = _uKnot[i];
            double u1 = _uKnot[i+1];
            if (abs(u1-u0) > 1.e-6)
                nn0Ex++;
        }

        //Checks
        if (nEx == nn0Ex)
            return;
        // if ((nEx < nn0Ex) && (nEx > 0))
        // {
        //     return; //FIXME: ????
        //     if (_hRefinedMesh == true) //FIXME: ????
        //         return;
        //     throw runtime_error("StructMeshGenerator: _freelyRefineNurbsSurface: You cannot refine a curve with less elements.");
        // }
        // if (((nEx % nn0Ex != 0) && (nEx > 0)) || ((nEy % nn0Ey != 0) && (nEy > 0)))
        //     throw runtime_error("StructMeshGenerator: _freelyRefineNurbsSurface: Free refinement can only be achieved when the new number of elements is a multiple of the original one.");

        //Increase the size of the knot vectors with the number of elements
        if (nEx > 1)
        {
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= nEx/double(nn0Ex);
        }

        //New knots to be inserted
        vector<double> X;
        if ((nEx > 1) and (fx != nullptr))
        {
            double uLength = _uKnot.back() - _uKnot.front();
            for (int i = 0; i < nEx-1; i++)
            {
                double x = fx((i+1)/(double) nEx) * uLength;

                std::vector<double>::iterator it;
                it = find (_uKnot.begin(), _uKnot.end(), x);
                if (it == _uKnot.end())
                    X.push_back(x);
            }
        }

        //Refine
        _refineNurbsCurve(X);
    }

    void StructMeshGenerator::_freelyRefineNurbsSurface(int nEx, int nEy, function<double(double)> fx, function<double(double)> fy)
    {
        //Get number of elements with non-zero length
        int nn0Ex{};
        for (auto i = 0u; i < _uKnot.size()-1; i++)
        {
            double u0 = _uKnot[i];
            double u1 = _uKnot[i+1];
            if (abs(u1-u0) > 1.e-6)
                nn0Ex++;
        }
        int nn0Ey{};
        for (auto i = 0u; i < _vKnot.size()-1; i++)
        {
            double v0 = _vKnot[i];
            double v1 = _vKnot[i+1];
            if (abs(v1-v0) > 1.e-6)
                nn0Ey++;
        }

        //Checks
        if ((nEx == nn0Ex) and (nEy == nn0Ey))
            return;
        // if (((nEx < nn0Ex) && (nEx > 0)) || ((nEy < nn0Ey) && (nEy > 0)))
        // {
        //     return; //FIXME: ????
        //     if (_hRefinedMesh == true) //FIXME: ????
        //         return;
        //     throw runtime_error("StructMeshGenerator: _freelyRefineNurbsSurface: You cannot refine a curve with less elements.");
        // }
        // if (((nEx % nn0Ex != 0) && (nEx > 0)) || ((nEy % nn0Ey != 0) && (nEy > 0)))
        //     throw runtime_error("StructMeshGenerator: _freelyRefineNurbsSurface: Free refinement can only be achieved when the new number of elements is a multiple of the original one.");

        //Increase the size of the knot vectors with the number of elements
        if (nEx > 1)
        {
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= nEx/double(nn0Ex);
        }
        if (nEy > 1)
        {
            for (auto i = 0u; i < _vKnot.size(); i++)
                _vKnot[i] *= nEy/double(nn0Ey);
        }

        //New knots to be inserted
        vector<double> X, Y;
        if ((nEx > 1) and (fx != nullptr))
        {
            double uLength = _uKnot.back() - _uKnot.front();
            for (int i = 0; i < nEx-1; i++)
            {
                double x = fx((i+1)/(double) nEx) * uLength;

                std::vector<double>::iterator it;
                it = find (_uKnot.begin(), _uKnot.end(), x);
                if (it == _uKnot.end())
                    X.push_back(x);
            }
        }
        if ((nEy > 1) and (fy != nullptr))
        {
            double vLength = _vKnot.back() - _vKnot.front();
            for (int i = 0; i < nEy-1; i++)
            {
                double y = fy((i+1)/(double) nEy) * vLength;

                std::vector<double>::iterator it;
                it = find (_vKnot.begin(), _vKnot.end(), y);
                if (it == _vKnot.end())
                    Y.push_back(y);
            }
        }

        //Refine
        _refineNurbsSurface(X, Y);

    }

    void StructMeshGenerator::_freelyRefineNurbsSolid(int nEx, int nEy, int nEz, function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz)
    {
        //Get number of elements with non-zero length //FIXME:: I don't think this is necessary (change everywhere)
        int nn0Ex{};
        for (auto i = 0u; i < _uKnot.size()-1; i++)
        {
            double u0 = _uKnot[i];
            double u1 = _uKnot[i+1];
            if (abs(u1-u0) > 1.e-6)
                nn0Ex++;
        }
        int nn0Ey{};
        for (auto i = 0u; i < _vKnot.size()-1; i++)
        {
            double v0 = _vKnot[i];
            double v1 = _vKnot[i+1];
            if (abs(v1-v0) > 1.e-6)
                nn0Ey++;
        }
        int nn0Ez{};
        for (auto i = 0u; i < _wKnot.size()-1; i++)
        {
            double w0 = _wKnot[i];
            double w1 = _wKnot[i+1];
            if (abs(w1-w0) > 1.e-6)
                nn0Ez++;
        }

        //Checks
        if ((nEx == nn0Ex) and (nEy == nn0Ey) and (nEz == nn0Ez))
            return;
        // if (((nEx < nn0Ex) && (nEx > 0)) || ((nEy < nn0Ey) && (nEy > 0)) || ((nEz < nn0Ez) && (nEz > 0)))
        // {
        //     return; //FIXME: ????
        //     throw runtime_error("StructMeshGenerator: _freelyRefineNurbsSolid: You cannot refine a curve with less elements.");
        // }
        // if (((nEx % nn0Ex != 0) && (nEx > 0)) || ((nEy % nn0Ey != 0) && (nEy > 0)) || ((nEz % nn0Ez != 0) && (nEz > 0)))
        //     throw runtime_error("StructMeshGenerator: _freelyRefineNurbsSolid: Free refinement can only be achieved when the new number of elements is a multiple of the original one.");

        //Increase the size of the knot vectors with the number of elements
        if (nEx > 1)
        {
            for (auto i = 0u; i < _uKnot.size(); i++)
                _uKnot[i] *= nEx/double(nn0Ex);
        }
        if (nEy > 1)
        {
            for (auto i = 0u; i < _vKnot.size(); i++)
                _vKnot[i] *= nEy/double(nn0Ey);
        }
        if (nEz > 1)
        {
            for (auto i = 0u; i < _wKnot.size(); i++)
                _wKnot[i] *= nEz/double(nn0Ez);
        }

        //New knots to be inserted
        vector<double> X, Y, Z;
        if ((nEx > 1) and (fx != nullptr))
        {
            double uLength = _uKnot.back() - _uKnot.front();
            for (int i = 0; i < nEx-1; i++)
            {
                double x = fx((i+1)/(double) nEx) * uLength;

                std::vector<double>::iterator it;
                it = find (_uKnot.begin(), _uKnot.end(), x);
                if (it == _uKnot.end())
                    X.push_back(x);
            }
        }
        if ((nEy > 1) and (fy != nullptr))
        {
            double vLength = _vKnot.back() - _vKnot.front();
            for (int i = 0; i < nEy-1; i++)
            {
                double y = fy((i+1)/(double) nEy) * vLength;

                std::vector<double>::iterator it;
                it = find (_vKnot.begin(), _vKnot.end(), y);
                if (it == _vKnot.end())
                    Y.push_back(y);
            }
        }
        if ((nEz > 1) and (fz != nullptr))
        {
            double wLength = _wKnot.back() - _wKnot.front();
            for (int i = 0; i < nEz-1; i++)
            {
                double z = fz((i+1)/(double) nEz) * wLength;

                std::vector<double>::iterator it;
                it = find (_wKnot.begin(), _wKnot.end(), z);
                if (it == _wKnot.end())
                    Z.push_back(z);
            }
        }

        //Refine
        _refineNurbsSolid(X, Y, Z);
    }

    void StructMeshGenerator::_freelyRefineNurbs(int newTotalnEx, int newTotalnEy, int newTotalnEz, std::function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz, bool saveHistory)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator: Cannot perform transformation before generating the mesh.");
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (newTotalnEx < -1 || newTotalnEy != -1 || newTotalnEz != -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _freelyRefineNurbs: Line elements can only be refined in x direction.");
                _freelyRefineNurbsCurve(newTotalnEx, fx);
                break;
            case static_cast<int>(ElemType::Square):
                if (newTotalnEx < -1 || newTotalnEy < -1 || newTotalnEz != -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _freelyRefineNurbs: Square elements can only be refined in x and y directions.");
                _freelyRefineNurbsSurface(newTotalnEx, newTotalnEy, fx, fy);
                break;
            case static_cast<int>(ElemType::Parallelep):
                if (newTotalnEx < -1 || newTotalnEy < -1 || newTotalnEz < -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _freelyRefineNurbs: Square elements can only be refined in x, y and z directions.");
                _freelyRefineNurbsSolid(newTotalnEx, newTotalnEy, newTotalnEz, fx, fy, fz);
                break;
            default:
                throw runtime_error("StructMeshGenerator: _freelyRefineNurbs: Wrong element type.");
        }

        //Save history
        if (saveHistory)
        {
            _history.emplace_back([=](){_freelyRefineNurbs(newTotalnEx, newTotalnEy, newTotalnEz, fx, fy, fz, true);});
            _history_names.push_back(__FUNCTION__);
        }
    }

    void _degreeElevateCurve(vector<double> &Uh, vector<vector<double>> &Qw, int n, int p, vector<double> &U, vector<vector<double>> &Pw, int t)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; pp. 206-209.
        /* Degree elevate a curve t times. */
        /* Input: n, p, U, Pw, t */
        /* Output: nh, Uh, Qw */

        //Modify for HPLFE
        n--;
        int s = Pw[0].size();

        vector<vector<double>> bezalfs(p+t+1, vector<double>(p+1));
        vector<vector<double>> bpts(p+1, vector<double>(4));
        vector<vector<double>> ebpts(p+t+1, vector<double>(4));
        vector<vector<double>> Nextbpts(p-1, vector<double>(4));

        int m = n+p+1;
        int ph = p+t;
        int ph2 = ph/2;

        //Compute Bezier degree elevation coefficients
        bezalfs[0][0] = bezalfs[ph][p] = 1.0;
        for (int i = 1; i <= ph2; i++)
        {
            double inv = 1.0/static_cast<double>(Math::binomialCoeff(ph, i));
            int mpi = std::min(p, i);
            for (int j = std::max(0, i-t); j <= mpi; j++)
                bezalfs[i][j] = inv*static_cast<double>(Math::binomialCoeff(p, j))*static_cast<double>(Math::binomialCoeff(t, i-j));
        }
        for (int i = ph2+1; i <= ph-1; i++)
        {
            int mpi = std::min(p, i);
            for (int j = std::max(0, i-t); j <= mpi; j++)
                bezalfs[i][j] = bezalfs[ph-i][p-j];
        }

//        int mh = ph;
        int kind = ph+1;
        int r = -1;
        int a = p;
        int b = p+1;
        int cind = 1;
        double ua = U[0];
        for (int d = 0; d < s; d++)
            Qw[0][d] = Pw[0][d];
        for (int i = 0; i <= ph; i++)
            Uh[i] = ua;

        //Initialize first Bezier segment
        for (int i = 0; i <= p; i++)
            for (int d = 0; d < s; d++)
                bpts[i][d] = Pw[i][d];

        //Big loop thru knot vector
        while (b < m)
        {
            int i = b;
            while (b < m && U[b] == U[b+1])
                b = b+1;
            int mul = b-i+1;
            int mh = mh+mul+t;
            double ub = U[b];
            int oldr = r;
            r = p-mul;
            //Insert knot u(b) r times
            int lbz, rbz;
            if (oldr > 0)
                lbz = (oldr+2)/2;
            else
                lbz = 1;
            if (r > 0)
                rbz = ph-(r+1)/2;
            else
                rbz = ph;
            //Insert knot to get Bezier segment
            if (r > 0)
            {
                double numer = ub-ua;
                vector<double> alfs(p-1);
                for (int k = p; k > mul; k--)
                    alfs[k-mul-1] = numer/(U[a+k]-ua);
                for (int j = 1; j <= r; j++)
                {
                    int save = r-j;
                    int s = mul+j;
                    for (int k = p; k >= s; k--)
                    {
                        for (int d = 0; d < s; d++)
                            bpts[k][d] = alfs[k-s]*bpts[k][d] + (1.0-alfs[k-s])*bpts[k-1][d] ;
                    }
                    for (int d = 0; d < s; d++)
                        Nextbpts[save][d] = bpts[p][d];
                }
            }

            //Degree elevate Bezier
            for (int i = lbz; i <= ph; i++)
            {
                for (int d = 0; d < s; d++)
                    ebpts[i][d] = 0.0;
                int mpi = std::min(p,i);
                for (int j = std::max(0, i-t); j <= mpi; j++)
                    for (int d = 0; d < s; d++)
                        ebpts[i][d] += bezalfs[i][j]*bpts[j][d];
            }

            //Remove knot u=U[a] oldr times
            if (oldr > 1)
            {
                int first = kind-2;
                int last = kind;
                double den = ub-ua;
                double bet = (ub-Uh[kind-1])/den;
                //Knot removal loop
                for (int tr = 1; tr < oldr; tr++)
                {
                    int i = first;
                    int j = last;
                    int kj = j-kind+1;
                    //Loop and compute the new
                    while (j-i > tr)
                    {
                        if (i < cind)
                        {
                            double alf = (ub-Uh[i])/(ua-Uh[i]);
                            for (int d = 0; d < s; d++)
                                Qw[i][d] = alf*Qw[i][d] + (1.0-alf)*Qw[i-1][d];
                        }
                        if(j >= lbz)
                        {
                            if(j-tr <= kind-ph+oldr )
                            {
                                double gam = (ub-Uh[j-tr])/den;
                                for (int d = 0; d < s; d++)
                                    ebpts[kj][d] = gam*ebpts[kj][d]+(1.0-gam)*ebpts[kj+1][d];
                            }
                            else
                            {
                                for (int d = 0; d < s; d++)
                                    ebpts[kj][d] = bet*ebpts[kj][d]+(1.0-bet)*ebpts[kj+1][d];
                            }
                        }
                        i = i+1;
                        j = j-1;
                        kj = kj-1;
                    }
                    first = first-1;
                    last = last+1;
                }
            }
            //Load knot ua
            if (a != p)
            {
                for (int i = 0; i < ph-oldr; i++)
                {
                    Uh[kind] = ua;
                    kind = kind+1;
                }
            }
            //Load control points into Qw
            for (int j = lbz; j <= rbz; j++)
            {
                for (int d = 0; d < s; d++)
                    Qw[cind][d] = ebpts[j][d];
                cind = cind+1;
            }
            //Set up for next pass thru loop
            if (b < m)
            {
                for (int j = 0; j < r; j++)
                    for (int d = 0; d < s; d++)
                        bpts[j][d] = Nextbpts[j][d];
                for (int j = r; j <= p; j++)
                    for (int d = 0; d < s; d++)
                        bpts[j][d] = Pw[b-p+j][d];
                a = b;
                b = b+1;
                ua = ub;
            }
            else
            {
                for (int i = 0; i <= ph; i++)
                    Uh[kind+i] = ub;
            }
        }
        // nh = mh-ph-1;
    }

    void _degreeElevateSurface(vector<double> &Uh, vector<double> &Vh, vector<vector<vector<double>>> &Qw, int nnx, int order_x, vector<double> &U, int nny, int order_y, vector<double> &V, vector<vector<vector<double>>> &CP, int t, int r, int dir)
    {
        /* Adapted from Austin Cottrell's fortran code */

        int s = CP[0][0].size();

        if (dir == 0)
        {
            //Initialize
            vector<vector<double>> xCP(nnx, vector<double>(s));
            vector<vector<double>> xCPbar(nnx+r, vector<double>(s));

            for (int j = 0; j < nny; j++)
            {
                //Rearrange control points
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        xCP[i][d] = CP[i][j][d];
                    }
                }

                //Degree elevate
                _degreeElevateCurve(Uh, xCPbar, nnx, order_x, U, xCP, t);

                //Update control points
                for (int i = 0; i < nnx+r; i++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        Qw[i][j][d] = xCPbar[i][d];
                    }
                }
            }

        }

        else if (dir == 1)
        {
            //Initialize
            vector<vector<double>> yCP(nny, vector<double>(s));
            vector<vector<double>> yCPbar(nny+r, vector<double>(s));

            for (int i = 0; i < nnx; i++)
            {
                //Rearrange control points
                for (int j = 0; j < nny; j++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        yCP[j][d] = CP[i][j][d];
                    }
                }

                //Degree elevate
                _degreeElevateCurve(Vh, yCPbar, nny, order_y, V, yCP, t);

                //Update control points
                for (int j = 0; j < nny+r; j++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        Qw[i][j][d] = yCPbar[j][d];
                    }
                }
            }

        }

    }

    void _degreeElevateSolid(vector<double> &Uh, vector<double> &Vh, vector<double> &Wh, vector<vector<vector<vector<double>>>> &Qw, int nnx, int order_x, vector<double> &U, int nny, int order_y, vector<double> &V, int nnz, int order_z, vector<double> &W, vector<vector<vector<vector<double>>>> &CP, int t, int r, int dir)
    {
        /* Adapted from Austin Cottrell's fortran code */

        int s = CP[0][0][0].size();

        if (dir == 0)
        {
            //Initialize
            vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny,vector<double>(s)));
            vector<vector<vector<double>>> xyCPbar(nnx+r, vector<vector<double>>(nny, vector<double>(s)));

            for (int k = 0; k < nnz; k++)
            {
                //Rearrange control points
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            xyCP[i][j][d] = CP[i][j][k][d];
                        }
                    }
                }

                //Degree elevate
                _degreeElevateSurface(Uh, Vh, xyCPbar, nnx, order_x, U, nny, order_y, V, xyCP, t, r, 0);

                //Update control points
                for (int i = 0; i < nnx+r; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            Qw[i][j][k][d] = xyCPbar[i][j][d];
                        }
                    }
                }
            }

        }
        else if (dir == 1)
        {
            //Initialize
            vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny,vector<double>(s)));
            vector<vector<vector<double>>> xyCPbar(nnx, vector<vector<double>>(nny+r, vector<double>(s)));

            for (int k = 0; k < nnz; k++)
            {
                //Rearrange control points
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            xyCP[i][j][d] = CP[i][j][k][d];
                        }
                    }
                }

                //Degree elevate
                _degreeElevateSurface(Uh, Vh, xyCPbar, nnx, order_x, U, nny, order_y, V, xyCP, t, r, 1);

                //Update control points
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny+r; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            Qw[i][j][k][d] = xyCPbar[i][j][d];
                        }
                    }
                }
            }
        }
        else if (dir == 2)
        {
            //Initialize
            vector<vector<vector<double>>> zxCP(nnz, vector<vector<double>>(nnx,vector<double>(s)));
            vector<vector<vector<double>>> zxCPbar(nnz+r, vector<vector<double>>(nnx, vector<double>(s)));

            for (int j = 0; j < nny; j++)
            {
                //Rearrange control points
                for (int k = 0; k < nnz; k++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            zxCP[k][i][d] = CP[i][j][k][d];
                        }
                    }
                }

                //Degree elevate
                _degreeElevateSurface(Wh, Uh, zxCPbar, nnz, order_z, W, nnx, order_x, U, zxCP, t, r, 0);

                //Update control points
                for (int k = 0; k < nnz+r; k++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            Qw[i][j][k][d] = zxCPbar[k][i][d];
                        }
                    }
                }

            }

        }

    }

    void StructMeshGenerator::_degreeElevateNurbsCurve(int orderIncX)
    {
        //Checks
        if (orderIncX < 0)
            throw runtime_error("StructMeshGenerator: _degreeElevateNurbsCurve: The order can only be increased.");

        if (orderIncX == 0)
            throw runtime_error("StructMeshGenerator: _degreeElevateNurbsCurve: The order increment is zero.");

        //Initialize
        int order_x = _bfOrderX;
        int nnx = _nEx + order_x;
        int nKu = _nEx + 1 + 2*order_x;

        //Rearrange and form projective control point vector
        vector<vector<double>> xCP(nnx, vector<double>(4));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        xCP[i][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        xCP[i][d] *= xCP[i][3];
                    }
                }
            }
        }

        //Calculate number of distinct knots
        int distKu{1};
        for (int i = 0; i < nKu-1; i++)
            if (_uKnot[i] != _uKnot[i+1])
                distKu++;
        int rx = (distKu-1)*orderIncX;

        //New knot and control point vectors
        vector<double> Ubar(nKu+distKu*orderIncX);
        vector<vector<double>> xCPbar(nnx+rx, vector<double>(4));

        //Degree elevate in x
        _degreeElevateCurve(Ubar, xCPbar, nnx, order_x, _uKnot, xCP, orderIncX);

        //Convert projective coordinates into physical coordinates
        vector<vector<vector<vector<double>>>> CP(nnx+rx, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        for (int i = 0; i < nnx+rx; i++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int k = 0; k < 1; k++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = xCPbar[i][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Set new order globally
        _bfOrderX = order_x + orderIncX;

        //Generate mesh
        _genNurbsCurve(_bfOrderX, Ubar, CP);

    }

    void StructMeshGenerator::_degreeElevateNurbsSurface(int orderIncX, int orderIncY)
    {
        //Checks
        if ((orderIncX < 0) || (orderIncY < 0))
            throw runtime_error("StructMeshGenerator: _degreeElevateNurbsSurface: The orders can only be increased.");

        if ((orderIncX == 0) && (orderIncY == 0))
            throw runtime_error("StructMeshGenerator: _degreeElevateNurbsSurface: The order increments are zero.");

        //Initialize
        int order_x = _bfOrderX;
        int nnx = _nEx + order_x;
        int nKu = _nEx + 1 + 2*order_x;
        int order_y = _bfOrderY;
        int nKv = _nEy + 1 + 2*order_y;
        int nny = _nEy + order_y;

        //Rearrange and form projective control point vector
        vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny, vector<double>(4)));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        xyCP[i][j][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        xyCP[i][j][d] *= xyCP[i][j][3];
                    }
                }
            }
        }

        //Calculate number of distinct knots
        int distKu{1};
        for (int i = 0; i < nKu-1; i++)
            if (_uKnot[i] != _uKnot[i+1])
                distKu++;
        int rx = (distKu-1)*orderIncX;
        int distKv{1};
        for (int i = 0; i < nKv-1; i++)
            if (_vKnot[i] != _vKnot[i+1])
                distKv++;
        int ry = (distKv-1)*orderIncY;

        //New knot and control point vectors
        vector<double> Ubar(nKu+distKu*orderIncX);
        vector<double> Vbar(nKv+distKv*orderIncY);
        vector<vector<vector<double>>> xyCPbarx(nnx+rx, vector<vector<double>>(nny, vector<double>(4)));
        vector<vector<vector<double>>> xyCPbar(nnx+rx, vector<vector<double>>(nny+ry, vector<double>(4)));

        //Degree elevate in x
        if (orderIncX > 0)
        {
            _degreeElevateSurface(Ubar, _vKnot, xyCPbarx, nnx, order_x, _uKnot, nny, order_y, _vKnot, xyCP, orderIncX, rx, 0);
        }
        else
        {
            xyCPbarx = xyCP;
            Ubar = _uKnot;
        }

        //Degree elevate in y
        if (orderIncY > 0)
        {
            _degreeElevateSurface(Ubar, Vbar, xyCPbar, nnx+rx, order_x, Ubar, nny, order_y, _vKnot, xyCPbarx, orderIncY, ry, 1);
        }
        else
        {
            xyCPbar = xyCPbarx;
            Vbar = _vKnot;
        }

        //Convert projective coordinates into physical coordinates
        vector<vector<vector<vector<double>>>> CP(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(1, vector<double>(4))));
        for (int i = 0; i < nnx+rx; i++)
        {
            for (int j = 0; j < nny+ry; j++)
            {
                for (int k = 0; k < 1; k++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = xyCPbar[i][j][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Set new orders globally
        _bfOrderX = order_x + orderIncX;
        _bfOrderY = order_y + orderIncY;

        //Generate mesh
        _genNurbsSurface(_bfOrderX, _bfOrderY, Ubar, Vbar, CP);

    }

    void StructMeshGenerator::_degreeElevateNurbsSolid(int orderIncX, int orderIncY, int orderIncZ)
    {
        //Checks
        if ((orderIncX < 0) || (orderIncY < 0) || (orderIncZ < 0))
            throw runtime_error("StructMeshGenerator: _degreeElevateNurbsSolid: The orders can only be increased.");

        if ((orderIncX == 0) && (orderIncY == 0) && (orderIncZ == 0))
            throw runtime_error("StructMeshGenerator: _degreeElevateNurbsSolid: The order increments is zero.");

        //Initialize
        int order_x = _bfOrderX;
        int nnx = _nEx + order_x;
        int nKu = _nEx + 1 + 2*order_x;
        int order_y = _bfOrderY;
        int nKv = _nEy + 1 + 2*order_y;
        int nny = _nEy + order_y;
        int order_z = _bfOrderZ;
        int nKw = _nEz + 1 + 2*order_z;
        int nnz = _nEz + order_z;

        //Rearrange and form projective control point vector
        vector<vector<vector<vector<double>>>> CP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] *= CP[i][j][k][3];
                    }
                }
            }
        }

        //Calculate number of distinct knots
        int distKu{1};
        for (int i = 0; i < nKu-1; i++)
            if (_uKnot[i] != _uKnot[i+1])
                distKu++;
        int rx = (distKu-1)*orderIncX;
        int distKv{1};
        for (int i = 0; i < nKv-1; i++)
            if (_vKnot[i] != _vKnot[i+1])
                distKv++;
        int ry = (distKv-1)*orderIncY;
        int distKw{1};
        for (int i = 0; i < nKw-1; i++)
            if (_wKnot[i] != _wKnot[i+1])
                distKw++;
        int rz = (distKw-1)*orderIncZ;

        //New knot and control point vectors
        vector<double> Ubar(nKu+distKu*orderIncX);
        vector<double> Vbar(nKv+distKv*orderIncY);
        vector<double> Wbar(nKw+distKw*orderIncZ);
        vector<vector<vector<vector<double>>>> CPbarx(nnx+rx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        vector<vector<vector<vector<double>>>> CPbarxy(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(nnz, vector<double>(4))));
        vector<vector<vector<vector<double>>>> CPbar(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(nnz+rz, vector<double>(4))));

        //Degree elevate in x
        if (orderIncX > 0)
        {
            _degreeElevateSolid(Ubar, _vKnot, _wKnot, CPbarx, nnx, order_x, _uKnot, nny, order_y, _vKnot, nnz, order_z, _wKnot, CP, orderIncX, rx, 0);
        }
        else
        {
            CPbarx = CP;
            Ubar = _uKnot;
        }

        //Degree elevate in y
        if (orderIncY > 0)
        {
            _degreeElevateSolid(Ubar, Vbar, _wKnot, CPbarxy, nnx+rx, order_x, Ubar, nny, order_y, _vKnot, nnz, order_z, _wKnot, CPbarx, orderIncY, ry, 1);
        }
        else
        {
            CPbarxy = CPbarx;
            Vbar = _vKnot;
        }

        //Degree elevate in z
        if (orderIncZ > 0)
        {
            _degreeElevateSolid(Ubar, Vbar, Wbar, CPbar, nnx+rx, order_x, Ubar, nny+ry, order_y, Vbar, nnz, order_z, _wKnot, CPbarxy, orderIncZ, rz, 2);
        }
        else
        {
            CPbar = CPbarxy;
            Wbar = _wKnot;
        }

        //Convert projective coordinates into physical coordinates
        CP.clear();
        CP.resize(nnx+rx, vector<vector<vector<double>>>(nny+ry, vector<vector<double>>(nnz+rz, vector<double>(4))));
        for (int k = 0; k < nnz+rz; k++)
        {
            for (int j = 0; j < nny+ry; j++)
            {
                for (int i = 0; i < nnx+rx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = CPbar[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CPbar[i][j][k][3];
                    }
                }
            }
        }

        //Set new orders globally
        _bfOrderX = order_x + orderIncX;
        _bfOrderY = order_y + orderIncY;
        _bfOrderZ = order_z + orderIncZ;

        //Generate mesh
        _genNurbsSolid(_bfOrderX, _bfOrderY, _bfOrderZ, Ubar, Vbar, Wbar, CP);
    }

    void StructMeshGenerator::_degreeElevateNurbs(int orderIncX, int orderIncY, int orderIncZ)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator: Cannot perform transformation before generating the mesh.");

        //Degree elevate
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (orderIncX == -1 || orderIncY != -1 || orderIncZ != -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _degreeElevateNurbs: Order elevation for Line elements can only performed in x direction.");
                _degreeElevateNurbsCurve(orderIncX);
                break;
            case static_cast<int>(ElemType::Square):
                if (orderIncX == -1 || orderIncY == -1 || orderIncZ != -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _degreeElevateNurbs: Order elevation for Square elements can only performed in x and/or y direction.");
                _degreeElevateNurbsSurface(orderIncX, orderIncY);
                break;
            case static_cast<int>(ElemType::Parallelep):
                if (orderIncX == -1 || orderIncY == -1 || orderIncZ == -1)
                    throw runtime_error("StructMeshGenerator_Transformations: _degreeElevateNurbs: Order elevation for Parallelep elements can only performed in x and/or y and/or z direction.");
                _degreeElevateNurbsSolid(orderIncX, orderIncY, orderIncZ);
                break;
            default:
                throw runtime_error("StructMeshGenerator: _degreeElevateNurbs: Wrong element type.");
        }

        //Save history
        _history.emplace_back([=](){_degreeElevateNurbs(orderIncX, orderIncY, orderIncZ);});
        _history_names.push_back(__FUNCTION__);

    }


    // Unclamp
    void _ucCurve(int n, int p, vector<double> &U, vector<vector<double>> &Pw)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; pp. 577-578.
        /* Unclamp a clamped curve */
        /* Input: n,p,U,Pw */
        /* Output: U,Pw */

        //Modify for HPLFE
        n--;
        int s = Pw[0].size();

        // Unclamp at left end
        for (int i = 0; i <= p-2; i++)
        {
            U[p-i-1] = U[p-i] - (U[n-i+1]-U[n-i]);
            int k = p-1;
            for (int j = i; j >= 0; j--)
            {
                double alfa = (U[p]-U[k])/(U[p+j+1]-U[k]);
                for (int d = 0; d < s; d++)
                    Pw[j][d] = (Pw[j][d]-alfa*Pw[j+1][d])/(1.0-alfa);
                k = k-1;
            }
        }
        // Set first knot
        U[0] = U[1] - (U[n-p+2]-U[n-p+1]);

        // Unclamp at right end
        for (int i = 0; i <= p-2; i++)
        {
            U[n+i+2] = U[n+i+1] + (U[p+i+1]-U[p+i]);
            for (int j = i; j >= 0; j--)
            {
                double alfa = (U[n+1]-U[n-j])/(U[n-j+i+2]-U[n-j]);
                for (int d = 0; d < s; d++)
                    Pw[n-j][d] = (Pw[n-j][d]-(1.0-alfa)*Pw[n-j-1][d])/alfa;
            }
        }
        // Set last knot
        U[n+p+1] = U[n+p] + (U[2*p]-U[2*p-1]);
    }

    void _ucSurface(vector<double> &Uh, vector<double> &Vh, int nnx, int order_x, vector<double> &U, int nny, int order_y, vector<double> &V, vector<vector<vector<double>>> &CP, int dir)
    {
        int s = CP[0][0].size();

        if (dir == 0)
        {
            // Initialize
            vector<vector<double>> xCP(nnx, vector<double>(s));

            // Loop through lines in Y
            for (int j = 0; j < nny; j++)
            {
                // Extract control points of line j
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        xCP[i][d] = CP[i][j][d];
                    }
                }

                // Save uknot
                Uh = U;

                // Unclamp
                _ucCurve(nnx, order_x, Uh, xCP);

                // Update control points
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        CP[i][j][d] = xCP[i][d];
                    }
                }
            }
        }
        else if (dir == 1)
        {
            // Initialize
            vector<vector<double>> yCP(nny, vector<double>(s));

            // Loop through lines in X
            for (int i = 0; i < nnx; i++)
            {
                // Extract control points of line i
                for (int j = 0; j < nny; j++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        yCP[j][d] = CP[i][j][d];
                    }
                }

                // Save uknot
                Vh = V;

                // Unclamp
                _ucCurve(nny, order_y, Vh, yCP);

                // Update control points
                for (int j = 0; j < nny; j++)
                {
                    for (int d = 0; d < s; d++)
                    {
                        CP[i][j][d] = yCP[j][d];
                    }
                }
            }
        }
    }

    void _ucSolid(vector<double> &Uh, vector<double> &Vh, vector<double> &Wh, int nnx, int order_x, vector<double> &U, int nny, int order_y, vector<double> &V, int nnz, int order_z, vector<double> &W, vector<vector<vector<vector<double>>>> &CP, int dir)
    {
        int s = CP[0][0][0].size();

        if (dir == 0)
        {
            // Initialize
            vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny,vector<double>(s)));

            // Loop through surfaces in Z
            for (int k = 0; k < nnz; k++)
            {
                // Extract control points of surface k
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            xyCP[i][j][d] = CP[i][j][k][d];
                        }
                    }
                }

                // Unclamp
                _ucSurface(Uh, Vh, nnx, order_x, U, nny, order_y, V, xyCP, 0);

                // Update control points
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            CP[i][j][k][d] = xyCP[i][j][d];
                        }
                    }
                }
            }

        }
        else if (dir == 1)
        {
            //Initialize
            vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny,vector<double>(s)));

            // Loop through surfaces in Z
            for (int k = 0; k < nnz; k++)
            {
                // Extract control points of surface k
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            xyCP[i][j][d] = CP[i][j][k][d];
                        }
                    }
                }

                // Unclamp
                _ucSurface(Uh, Vh, nnx, order_x, U, nny, order_y, V, xyCP, 1);

                // Update control points
                for (int i = 0; i < nnx; i++)
                {
                    for (int j = 0; j < nny; j++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            CP[i][j][k][d] = xyCP[i][j][d];
                        }
                    }
                }
            }
        }
        else if (dir == 2)
        {
            // Initialize
            vector<vector<vector<double>>> zxCP(nnz, vector<vector<double>>(nnx,vector<double>(s)));

            // Loop through surfaces in Y
            for (int j = 0; j < nny; j++)
            {
                // Extract control points of surface j
                for (int k = 0; k < nnz; k++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            zxCP[k][i][d] = CP[i][j][k][d];
                        }
                    }
                }

                // Unclamp
                _ucSurface(Wh, Uh, nnz, order_z, W, nnx, order_x, U, zxCP, 0);

                // Update control points
                for (int k = 0; k < nnz; k++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        for (int d = 0; d < s; d++)
                        {
                            CP[i][j][k][d] = zxCP[k][i][d];
                        }
                    }
                }

            }
        }
    }

    void StructMeshGenerator::_unclampNurbsCurve()
    {
        // Initialize
        int nnx = _nEx + _bfOrderX;

        //Rearrange and form projective control point vector
        vector<vector<double>> xCP(nnx, vector<double>(4));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        xCP[i][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        xCP[i][d] *= xCP[i][3];
                    }
                }
            }
        }

        // Unclamp curve
        _ucCurve(nnx, _bfOrderX, _uKnot, xCP);

        //Convert projective coordinates into physical coordinates
        vector<vector<vector<vector<double>>>> CP(nnx, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        for (int i = 0; i < nnx; i++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int k = 0; k < 1; k++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = xCP[i][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Generate mesh
        _genNurbsCurve(_bfOrderX, _uKnot, CP);
    }

    void StructMeshGenerator::_unclampNurbsSurface(int unclampX, int unclampY)
    {
        // Initialize
        int nnx = _nEx + _bfOrderX;
        int nny = _nEy + _bfOrderY;

        // Rearrange and form projective control point vector
        vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny, vector<double>(4)));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        xyCP[i][j][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        xyCP[i][j][d] *= xyCP[i][j][3];
                    }
                }
            }
        }

        // New knots
        vector<double> Ubar = _uKnot;
        vector<double> Vbar = _vKnot;

        // Unclamp in x
        if (unclampX)
            _ucSurface(Ubar, Vbar, nnx, _bfOrderX, _uKnot, nny, _bfOrderY, _vKnot, xyCP, 0);

        // Unclamp in y
        if (unclampY)
            _ucSurface(Ubar, Vbar, nnx, _bfOrderX,   Ubar, nny, _bfOrderY, _vKnot, xyCP, 1);

        // Convert projective coordinates into physical coordinates
        vector<vector<vector<vector<double>>>> CP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(1, vector<double>(4))));
        for (int i = 0; i < nnx; i++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int k = 0; k < 1; k++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = xyCP[i][j][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Generate mesh
        _genNurbsSurface(_bfOrderX, _bfOrderY, Ubar, Vbar, CP);
    }

    void StructMeshGenerator::_unclampNurbsSolid(int unclampX, int unclampY, int unclampZ)
    {
        // Initialize
        int nnx = _nEx + _bfOrderX;
        int nny = _nEy + _bfOrderY;
        int nnz = _nEz + _bfOrderZ;

        // Rearrange and form projective control point vector
        vector<vector<vector<vector<double>>>> xyzCP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        xyzCP[i][j][k][d] = _CP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        xyzCP[i][j][k][d] *= xyzCP[i][j][k][3];
                    }
                }
            }
        }

        // New knots
        vector<double> Ubar = _uKnot;
        vector<double> Vbar = _vKnot;
        vector<double> Wbar = _wKnot;

        // Unclamp in x
        if (unclampX)
            _ucSolid(Ubar, Vbar, Wbar, nnx, _bfOrderX, _uKnot, nny, _bfOrderY, _vKnot, nnz, _bfOrderZ, _wKnot, xyzCP, 0);

        // Unclamp in y
        if (unclampY)
            _ucSolid(Ubar, Vbar, Wbar, nnx, _bfOrderX,   Ubar, nny, _bfOrderY, _vKnot, nnz, _bfOrderZ, _wKnot, xyzCP, 1);

        // Unclamp in z
        if (unclampZ)
            _ucSolid(Ubar, Vbar, Wbar, nnx, _bfOrderX,   Ubar, nny, _bfOrderY,   Vbar, nnz, _bfOrderZ, _wKnot, xyzCP, 2);

        // Convert projective coordinates into physical coordinates
        vector<vector<vector<vector<double>>>> CP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 4; d++)
                    {
                        CP[i][j][k][d] = xyzCP[i][j][k][d];
                    }
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] /= CP[i][j][k][3];
                    }
                }
            }
        }

        //Generate mesh
        _genNurbsSolid(_bfOrderX, _bfOrderY, _bfOrderZ, Ubar, Vbar, Wbar, CP);
    }

    void StructMeshGenerator::_unclampNurbs(vector<Axis> axes)
    {
        // Get unclamp directions
        bool unclampX{false};
        bool unclampY{false};
        bool unclampZ{false};
        for (size_t it = 0; it < axes.size(); ++it)
        {
            switch (axes[it])
            {
                case Axis::Xaxis:
                    if (!_unclampedX)
                    {
                        _unclampedX = true;
                        unclampX = true;
                    }
                    break;
                case Axis::Yaxis:
                    if (!_unclampedY)
                    {
                        _unclampedY = true;
                        unclampY = true;
                    }
                    break;
                case Axis::Zaxis:
                    if (!_unclampedZ)
                    {
                        _unclampedZ = true;
                        unclampZ = true;
                    }
                    break;
                default:
                    throw std::runtime_error("StructMeshGenerator::_unclampNurbs: Axis not set.");
                    break;
            }
        }

        // Unclamp
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (unclampY or unclampZ)
                    throw  runtime_error("StructMeshGenerator::unclampNurbs: Axis can only be Xaxis for curves.");
                _unclampNurbsCurve();
                break;
            case static_cast<int>(ElemType::Square):
                if (unclampZ)
                    throw  runtime_error("StructMeshGenerator::unclampNurbs: Axis can only be Xaxis or Yaxis for surfaces.");
                _unclampNurbsSurface(unclampX, unclampY);
                break;
            case static_cast<int>(ElemType::Parallelep):
                _unclampNurbsSolid(unclampX, unclampY, unclampZ);
                break;
            default:
                throw runtime_error("StructMeshGenerator: Wrong element type.");
        }
    }


    //Revolution
    void _makeRevolvedSurface(vector<double> S, vector<double> T, double theta, int m, vector<vector<double>> Pj, vector<double> wj, int &n, vector<double> &U, vector<vector<vector<double>>> &Pij, vector<vector<double>> &wij)
    {
        // Algorithm adapted from Piegl, Les. "The NURBS Book".
        //  Springer-Verlag: Berlin 1995; pp. 346-348.
        /* Create NURBS surface of revolution */
        /* Input: S,T,theta,m,Pj,wj */
        /* Output: n,U,Pij,wij */

        //Modify for HPLFE
        m--;

        //Get number of arcs and knot vectors
        int narcs{};
        if (theta <= M_PI/2.0)
            narcs = 1;
        else if (theta <= M_PI)
            narcs = 2;
        else if (theta <= 3.0*M_PI/2.0)
            narcs = 3;
        else
            narcs = 4;

        /* dtheta/2 is base angle */
        double dtheta = theta/narcs;
        double wm = cos(dtheta/2.0);

        //Create control points for narcs segments
        n = 2*narcs;
        Pij.resize(n+1, vector<vector<double>>(m+1, vector<double>(3, 0.0)));
        wij.resize(n+1, vector<double>(m+1));

        /* Compute sines and cosines only once */
        double angle = 0.0;
        vector<double> cosines(narcs+1), sines(narcs+1);
        for (int i = 1; i <= narcs; i++)
        {
            angle = angle + dtheta;
            cosines[i] = cos(angle);
            sines[i] = sin(angle);
        }

        /* Loop and compute each u row of ctrl pts and weights*/
        vector<double> X(3, 0.0), Y(3, 0.0), O(3, 0.0);
        vector<double> r(3, 0.0);
        for (int j = 0; j <= m; j++)
        {
            SGeometry::pointToLine(S, T, Pj[j], O);
            for (int d = 0; d < 3; d++)
                X[d] = Pj[j][d] - O[d];
            double r = Math::Norm3D(X.data());
            if (r != 0)
            {
                for (int d = 0; d < 3; d++)
                {
                    X[d] = X[d]/r;
                }
            }
            Math::Cross(Y.data(), T.data(), X.data());

            /* Initialize first */
            vector<double> PO(3);
            Pij[0][j] = PO = Pj[j];

            /* ctrl pt and weight */
            wij[0][j] = wj[j];
            vector<double> TO(3);
            TO = Y;
            int index = 0;
            angle = 0.0;

            /* compute u row */
            for (int i = 1; i <= narcs; i++)
            {
                vector<double> P2(3), T2(3);
                for (int d = 0; d < 3; d++)
                    P2[d] = O[d] + r*cosines[i]*X[d] + r*sines[i]*Y[d];
                Pij[index+2][j] = P2;
                wij[index+2][j] = wj[j];
                for (int d = 0; d < 3; d++)
                    T2[d] = -sines[i]*X[d] + cosines[i]*Y[d];
                int ierr = SGeometry::intersect3DLines(PO, TO, P2, T2, Pij[index+1][j]);
                (void) ierr;
                wij[index+1][j] = wm*wj[j];
                index = index + 2;
                if (i < narcs)
                {
                    PO = P2;
                    TO = T2;
                }
            }
        }

        //Create knot vector
        U.resize(6+2*(narcs-1));
        int j = 2*narcs+1;
        for (int i = 0; i < 3; i++)
        {
            U[i] = 0.0;
            U[i+j] = 1.0;
        }
        switch (narcs)
        {
            case 1:
                break;
            case 2:
                U[3] = U[4] = 0.5;
                break;
            case 3:
                U[3] = U[4] = 1.0/3.0;
                U[5] = U[6] = 2.0/3.0;
                break;
            case 4:
                U[3] = U[4] = 0.25;
                U[5] = U[6] = 0.5;
                U[7] = U[8] = 0.75;
                break;
        }

    }

    void _makeRevolvedSolid(vector<double> S, vector<double> T, double theta, int m, int n, vector<vector<vector<double>>> Pij, vector<vector<double>> wij, int &o, vector<double> &U, vector<vector<vector<vector<double>>>> &Pijk, vector<vector<vector<double>>> &wijk)
    {

        //Modify for HPLFE
        m--;
        n--;

        //Get number of arcs and knot vectors
        int narcs{};
        if (theta <= M_PI/2.0)
            narcs = 1;
        else if (theta <= M_PI)
            narcs = 2;
        else if (theta <= 3.0*M_PI/2.0)
            narcs = 3;
        else
            narcs = 4;

        /* dtheta/2 is base angle */
        double dtheta = theta/narcs;
        double wm = cos(dtheta/2.0);

        //Create control points for narcs segments
        o = 2*narcs;
        Pijk.resize(m+1, vector<vector<vector<double>>>(n+1, vector<vector<double>>(o+1, vector<double>(3, 0.0))));
        wijk.resize(m+1, vector<vector<double>>(n+1, vector<double>(o+1)));

        /* Compute sines and cosines only once */
        double angle = 0.0;
        vector<double> cosines(narcs+1), sines(narcs+1);
        for (int k = 1; k <= narcs; k++)
        {
            angle = angle + dtheta;
            cosines[k] = cos(angle);
            sines[k] = sin(angle);
        }

        /* Loop and compute each u row of ctrl pts and weights*/
        vector<double> X(3, 0.0), Y(3, 0.0), O(3, 0.0);
        vector<double> r(3, 0.0);
        for (int i = 0; i <= m; i++)
        {
            for (int j = 0; j <= n; j++)
            {
                SGeometry::pointToLine(S, T, Pij[i][j], O);
                for (int d = 0; d < 3; d++)
                    X[d] = Pij[i][j][d] - O[d];
                double r = Math::Norm3D(X.data());
                if (r != 0)
                {
                    for (int d = 0; d < 3; d++)
                    {
                        X[d] = X[d]/r;
                    }
                }
                Math::Cross(Y.data(), T.data(), X.data());

                /* Initialize first */
                vector<double> PO(3);
                Pijk[i][j][0] = PO = Pij[i][j];

                /* ctrl pt and weight */
                wijk[i][j][0] = wij[i][j];
                vector<double> TO(3);
                TO = Y;
                int index = 0;
                angle = 0.0;

                /* compute u row */
                for (int k = 1; k <= narcs; k++)
                {
                    vector<double> P2(3), T2(3);
                    for (int d = 0; d < 3; d++)
                        P2[d] = O[d] + r*cosines[k]*X[d] + r*sines[k]*Y[d];
                    Pijk[i][j][index+2] = P2;
                    wijk[i][j][index+2] = wij[i][j];
                    for (int d = 0; d < 3; d++)
                        T2[d] = -sines[k]*X[d] + cosines[k]*Y[d];
                    int ierr = SGeometry::intersect3DLines(PO, TO, P2, T2, Pijk[i][j][index+1]);
                    (void) ierr;
                    wijk[i][j][index+1] = wm*wij[i][j];
                    index = index + 2;
                    if (k < narcs)
                    {
                        PO = P2;
                        TO = T2;
                    }
                }
            }
        }

        //Create knot vector
        U.resize(6+2*(narcs-1));
        int j = 2*narcs+1;
        for (int i = 0; i < 3; i++)
        {
            U[i] = 0.0;
            U[i+j] = 1.0;
        }
        switch (narcs)
        {
            case 1:
                break;
            case 2:
                U[3] = U[4] = 0.5;
                break;
            case 3:
                U[3] = U[4] = 1.0/3.0;
                U[5] = U[6] = 2.0/3.0;
                break;
            case 4:
                U[3] = U[4] = 0.25;
                U[5] = U[6] = 0.5;
                U[7] = U[8] = 0.75;
                break;
        }

    }

    void StructMeshGenerator::_revolveNurbsCurve(int nEy, int order_y, double theta, vector<double> point, vector<double> dir)
    {
        //FIXME: TODO Checks


        //Arrange control points and weights
        int nnx = _nEx + _bfOrderX;
        vector<vector<double>> xCP(nnx, vector<double>(3));
        vector<double> xWei(nnx);
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 3; d++)
                    {
                        xCP[i][d] = _CP[i][j][k][d];
                    }
                    xWei[i] = _CP[i][j][k][3];
                }
            }
        }

        //Make revolved surface
        vector<vector<vector<double>>> yxCP;
        vector<vector<double>> yxWei;
        int nny;
        _makeRevolvedSurface(point, dir, theta, nnx, xCP, xWei, nny, _vKnot, yxCP, yxWei);

        //Rearrange control points and weight
        nny++;
        vector<vector<vector<vector<double>>>> CP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(1, vector<double>(4))));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] = yxCP[j][i][d];
                    }
                    CP[i][j][k][3] = yxWei[j][i];
                }
            }
        }

        //Change element type
        _eType = ElemType::Square;

        //Set order in Y direction
        _bfOrderY = 2;

        //Generate mesh
        _genNurbsSurface(_bfOrderX, _bfOrderY, _uKnot, _vKnot, CP);

        //Elevate order
        int orderIncY = order_y - _bfOrderY;
        if (orderIncY > 0)
            degreeElevateNurbs(0, orderIncY);

        //Refine
        uniformlyRefineNurbs(0, nEy);

    }

    void StructMeshGenerator::_revolveNurbsSurface(int nEz, int order_z, double theta, vector<double> point, vector<double> dir)
    {
        //FIXME: TODO Checks
        // throw runtime_error("StructMeshGenerator_Transformations: revolveNurbs: Work in progress.");


        //Arrange control points and weights
        int nnx = _nEx + _bfOrderX;
        int nny = _nEy + _bfOrderY;
        vector<vector<vector<double>>> xyCP(nnx, vector<vector<double>>(nny, vector<double>(3)));
        vector<vector<double>> xyWei(nnx, vector<double>(nny));
        for (int k = 0; k < 1; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 3; d++)
                    {
                        xyCP[i][j][d] = _CP[i][j][k][d];
                    }
                    xyWei[i][j] = _CP[i][j][k][3];
                }
            }
        }

        //Make revolved surface
        vector<vector<vector<vector<double>>>> xyzCP;
        vector<vector<vector<double>>> xyzWei;
        int nnz;
        _makeRevolvedSolid(point, dir, theta, nnx, nny, xyCP, xyWei, nnz, _wKnot, xyzCP, xyzWei);

        //Rearrange control points and weight
        nnz++;
        vector<vector<vector<vector<double>>>> CP(nnx, vector<vector<vector<double>>>(nny, vector<vector<double>>(nnz, vector<double>(4))));
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    for (int d = 0; d < 3; d++)
                    {
                        CP[i][j][k][d] = xyzCP[i][j][k][d];
                    }
                    CP[i][j][k][3] = xyzWei[i][j][k];
                }
            }
        }

        //Change element type
        _eType = ElemType::Parallelep;

        //Set order in Y direction
        _bfOrderZ = 2;

        //Generate mesh
        _genNurbsSolid(_bfOrderX, _bfOrderY, _bfOrderZ, _uKnot, _vKnot, _wKnot, CP);

        //Elevate order
        int orderIncZ = order_z - _bfOrderZ;
        if (orderIncZ > 0)
            degreeElevateNurbs(0, 0, orderIncZ);

        //Refine
        uniformlyRefineNurbs(0, 0, nEz);

    }


    void StructMeshGenerator::_revolveNurbs(int nEr, int order_r, double theta, vector<double> point, vector<double> dir)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator::revolveNurbs: Cannot perform transformation before generating the mesh.");

        //Correct direction
        for (int d = 0; d < 3; d++)
            dir[d] += point[d];

        //Transform
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                _revolveNurbsCurve(nEr, order_r, theta, point, dir);
                break;
            case static_cast<int>(ElemType::Square):
                _revolveNurbsSurface(nEr, order_r, theta, point, dir);
                break;
            case static_cast<int>(ElemType::Parallelep):
                throw runtime_error("StructMeshGenerator: Cannot revolve a 3D mesh.");
                break;
            default:
                throw runtime_error("StructMeshGenerator: Wrong element type.");
        }

        //Save minimal mesh
        _bfOrderX_min = _bfOrderX;
        _bfOrderY_min = _bfOrderY;
        _bfOrderZ_min = _bfOrderZ;
        _uKnot_min = _uKnot;
        _vKnot_min = _vKnot;
        _wKnot_min = _wKnot;
        _CP_min = _CP;
        _eType_min = _eType;

        //Clear history
        _history.clear();
        _history_names.clear();
    }


    // Periodicity
    void StructMeshGenerator::_periodicCurveNurbs()
    {
        // Check
        if (_bfOrderX > 2)
            throw runtime_error("StructMeshGenerator::_periodicCurveNurbs: Not implemented for order higher than 2.");

        // Initialize
        vector<linearConstraint> lc;

        // Number of basis functions/control points
        int nnx = _nEx + _bfOrderX;

        // Get control point ids
        int fid = 0;
        int sid = 1;
        int pid = nnx - 2;
        int lid = nnx - 1;

        // Continuity constraint
        lc.push_back({lid, {fid}, {1.0}, 0.0});

        // Second order continuity constraint
        if (_bfOrderX == 2)
        {
            lc.push_back({pid, {fid, sid}, {2.0, -1.0}, 0.0});
        }

        // Save only linear constraints in which the slave is in my partition
        _linearConstraints.resize(0);
        for (size_t l = 0; l < lc.size(); l++)
        {
            int slave = lc[l].slave;
            if (_disPts.isItemInPart(slave))
                _linearConstraints.push_back(lc[l]);
        }
    }

    void StructMeshGenerator::_periodicSurfaceNurbs()
    {
        // Check
        if (_bfOrderX > 2 or _bfOrderY > 2)
            throw runtime_error("StructMeshGenerator::_periodicCurveNurbs: Not implemented for order higher than 2.");

        // Initialize
        vector<linearConstraint> lc;

        // Number of basis functions/control points
        int nnx = _nEx + _bfOrderX;
        int nny = _nEy + _bfOrderY;

        // Compute linear constraints
        if (_periodicInX and _periodicInY)
        {
            if (_bfOrderX != _bfOrderY)
                throw runtime_error("StructMeshGenerator::_periodicCurveNurbs: Not implemented for different orders.");

            // Left bottom square
            int ff = 0;
            int sf = 1;
            int fs = nnx;
            int ss = fs + 1;

            // Right bottom square
            int lf = nnx - 1;
            int pf = lf - 1;
            int ps = pf + nnx;
            int ls = ps + 1;

            // Right top square
            int ll = nnx * nny - 1;
            int lp = ll - nnx;
            int pp = lp - 1;
            int pl = ll - 1;

            // Left top square
            int fl = lp + 1;
            int sl = fl + 1;
            int fp = fl - nnx;
            int sp = fp + 1;

            // Constrain all corners
            lc.push_back({ff, {ll}, {1.0}, 0.0});
            lc.push_back({fl, {ll}, {1.0}, 0.0});
            lc.push_back({lf, {ll}, {1.0}, 0.0});

            // Higher-order continuity in the corner
            if (_bfOrderX == 2 and _bfOrderY == 2) // FIXME:: Only implemented for equal order
            {
                // Neighbors continuity
                lc.push_back({fs, {ll, lp}, {2.0, -1.0}, 0.0});
                lc.push_back({fp, {lp}, {1.0}, 0.0});
                lc.push_back({sf, {ll, pl}, {2.0, -1.0}, 0.0});
                lc.push_back({pf, {pl}, {1.0}, 0.0});

                // Neighbors second order-continuity
                lc.push_back({ss, {pl, ll, lp, pp}, {-2.0, 4.0, -2.0, 1.0}, 0.0});
                lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                lc.push_back({ps, {pl, pp}, {2.0, -1.0}, 0.0});

                // Second-order continuity in the corner
                lc.push_back({sl, {ll, pl}, {2.0, -1.0}, 0.0});
                lc.push_back({ls, {ll, lp}, {2.0, -1.0}, 0.0});
            }

            // X-axis periodic linear constraints not in corner
            for (int j = _bfOrderY; j < nny-_bfOrderY; j++)
            {
                // Identify first and last nodes
                int fid = nnx * j;
                int lid = fid + nnx - 1;

                // First-order linear constraint
                lc.push_back({fid, {lid}, {1.0}, 0.0});

                // Second-order linear constraint
                if (_bfOrderX == 2)
                {
                    // Identify second and second-last nodes
                    int sid = fid + 1;
                    int pid = lid - 1;

                    // Constraint
                    lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                }
            }

            // Y-axis periodic linear constraints not in corner
            for (int i = _bfOrderX; i < nnx-_bfOrderX; i++)
            {
                // Identify first and last nodes
                int fid = i;
                int lid = fid + nnx * (nny - 1);

                // First-order linear constraint
                lc.push_back({fid, {lid}, {1.0}, 0.0});

                // Second-order linear constraint
                if (_bfOrderY == 2)
                {
                    // Identify second and second-last nodes
                    int sid = i + nnx;
                    int pid = lid - nnx;

                    // Constraint
                    lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                }
            }
        }
        else if (_periodicInX)
        {
            for (int j = 0; j < nny; j++)
            {
                // Identify first and last nodes
                int fid = nnx * j;
                int lid = fid + nnx-1;

                // First-order linear constraint
                lc.push_back({fid, {lid}, {1.0}, 0.0});

                // Second-order linear constraints
                if (_bfOrderX == 2)
                {
                    // Identify second and second-last nodes
                    int sid = fid + 1;
                    int pid = lid - 1;

                    // Constraint
                    lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                }
            }
        }
        else if (_periodicInY)
        {
            for (int i = 0; i < nnx; i++)
            {
                // Identify first and last nodes
                int fid = i;
                int lid = fid + nnx * (nny - 1);

                // First-order linear constraint
                lc.push_back({fid, {lid}, {1.0}, 0.0});

                // Second-order linear constraints
                if (_bfOrderY == 2)
                {
                    // Identify second and second-last nodes
                    int sid = i + nnx;
                    int pid = lid - nnx;

                    // Constraint
                    lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                }
            }
        }

        // Save only linear constraints in which the slave is in my partition
        _linearConstraints.resize(0);
        for (size_t l = 0; l < lc.size(); l++)
        {
            int slave = lc[l].slave;
            if (_disPts.isItemInPart(slave))
                _linearConstraints.push_back(lc[l]);
        }
    }

    void StructMeshGenerator::_periodicSolidNurbs()
    {
        // Check
        if (_bfOrderX > 2 or _bfOrderY > 2 or _bfOrderZ > 2)
            throw runtime_error("StructMeshGenerator::_periodicCurveNurbs: Not implemented for order higher than 2.");

        // Initialize
        vector<linearConstraint> lc;

        // Number of basis functions/control points
        int nnx = _nEx + _bfOrderX;
        int nny = _nEy + _bfOrderY;
        int nnz = _nEz + _bfOrderZ;

        // Compute linear constraints
        if (_periodicInX and _periodicInY and _periodicInZ)
        {
            if (_bfOrderX != _bfOrderZ and _bfOrderY != _bfOrderZ)
                throw runtime_error("StructMeshGenerator::_periodicSolidNurbs: Not implemented for different orders.");

            // 64 points in the corner
            //block 1
            int fff = 0;
            int sff = fff + 1;
            int fsf = fff + nnx;
            int ssf = fsf + 1;
            int ffs = fff + nnx*nny;
            int sfs = sff + nnx*nny;
            int fss = fsf + nnx*nny;
            int sss = ssf + nnx*nny;

            //block 2
            int lff = fff + nnx - 1;
            int pff = lff - 1;
            int lsf = lff + nnx;
            int psf = lsf - 1;
            int lfs = lff + nnx*nny;
            int pfs = pff + nnx*nny;
            int lss = lsf + nnx*nny;
            int pss = psf + nnx*nny;

            //block 3
            int flf = fff + nnx*(nny - 1);
            int slf = flf + 1;
            int fpf = flf - nnx;
            int spf = fpf + 1;
            int fls = flf + nnx*nny;
            int sls = slf + nnx*nny;
            int fps = fpf + nnx*nny;
            int sps = spf + nnx*nny;

            //block 4
            int llf = fff + nnx*nny -1;
            int plf = llf - 1;
            int lpf = llf - nnx;
            int ppf = lpf - 1;
            int lls = llf + nnx*nny;
            int pls = plf + nnx*nny;
            int lps = lpf + nnx*nny;
            int pps = ppf + nnx*nny;

            //block 5
            int ffl = fff + nnx*nny*(nnz - 1);
            int sfl = ffl + 1;
            int fsl = ffl + nnx;
            int ssl = fsl + 1;
            int ffp = ffl - nnx*nny;
            int sfp = sfl - nnx*nny;
            int fsp = fsl - nnx*nny;
            int ssp = ssl - nnx*nny;

            //block 6
            int lfl = ffl + nnx - 1;
            int pfl = lfl - 1;
            int lsl = lfl + nnx;
            int psl = lsl - 1;
            int lfp = lfl - nnx*nny;
            int pfp = pfl - nnx*nny;
            int lsp = lsl - nnx*nny;
            int psp = psl - nnx*nny;

            //block 7
            int fll = flf + nnx*nny*(nnz - 1);
            int sll = fll + 1;
            int fpl = fll - nnx;
            int spl = fpl + 1;
            int flp = fll - nnx*nny;
            int slp = sll - nnx*nny;
            int fpp = fpl - nnx*nny;
            int spp = spl - nnx*nny;

            //block 8
            int lll = nnx*nny*nnz -1;
            int pll = lll - 1;
            int lpl = lll - nnx;
            int ppl = lpl - 1;
            int llp = lll - nnx*nny;
            int plp = pll - nnx*nny;
            int lpp = lpl - nnx*nny;
            int ppp = ppl - nnx*nny;

            // corners periodicity constraint
            lc.push_back({fff, {lll}, {1.0}, 0.0});
            lc.push_back({lff, {lll}, {1.0}, 0.0});
            lc.push_back({flf, {lll}, {1.0}, 0.0});
            lc.push_back({llf, {lll}, {1.0}, 0.0});
            lc.push_back({ffl, {lll}, {1.0}, 0.0});
            lc.push_back({lfl, {lll}, {1.0}, 0.0});
            lc.push_back({fll, {lll}, {1.0}, 0.0});


            if (_bfOrder == 2)  // FIXME:: Only implemented for equal order
            {
                //first order equalities
                lc.push_back({pff, {pll}, {1.0}, 0.0});
                lc.push_back({pfl, {pll}, {1.0}, 0.0});
                lc.push_back({plf, {pll}, {1.0}, 0.0});
                lc.push_back({ffp, {llp}, {1.0}, 0.0});
                lc.push_back({lfp, {llp}, {1.0}, 0.0});
                lc.push_back({flp, {llp}, {1.0}, 0.0});
                lc.push_back({fpf, {lpl}, {1.0}, 0.0});
                lc.push_back({fpl, {lpl}, {1.0}, 0.0});
                lc.push_back({lpf, {lpl}, {1.0}, 0.0});
                lc.push_back({pfp, {plp}, {1.0}, 0.0});
                lc.push_back({fpp, {lpp}, {1.0}, 0.0});
                lc.push_back({ppf, {ppl}, {1.0}, 0.0});

                //second order equalities

                //x-periodicity
                lc.push_back({sff, {lll, pll}, {2.0, -1.0}, 0.0});
                lc.push_back({ssf, {lll, lpl, pll, ppl}, {4.0, -2.0, -2.0, 1.0}, 0.0});
                lc.push_back({spf, {lpl, ppl}, {2.0, -1.0}, 0.0});
                lc.push_back({slf, {lll, pll}, {2.0, -1.0}, 0.0});

                lc.push_back({sfs, {lll, llp, pll, plp}, {4.0, -2.0, -2.0, 1.0}, 0.0});
                lc.push_back({sss, {lll, lpl, llp, pll, lpp, ppl, plp, ppp}, {8.0, -4.0, -4.0, -4.0, 2.0, 2.0, 2.0, -1.0}, 0.0});
                lc.push_back({sps, {lpl, lpp, ppl, ppp}, {4.0, -2.0, -2.0, 1.0}, 0.0});
                lc.push_back({sls, {lll, llp, pll, plp}, {4.0, -2.0, -2.0, 1.0}, 0.0});

                lc.push_back({sfp, {llp, plp}, {2.0, -1.0}, 0.0});
                lc.push_back({ssp, {llp, lpp, plp, ppp}, {4.0, -2.0, -2.0, 1.0}, 0.0});
                lc.push_back({spp, {lpp, ppp}, {2.0, -1.0}, 0.0});
                lc.push_back({slp, {llp, plp}, {2.0, -1.0}, 0.0});

                lc.push_back({sfl, {lll, pll}, {2.0, -1.0}, 0.0});
                lc.push_back({ssl, {lll, lpl, pll, ppl}, {4.0, -2.0, -2.0, 1.0}, 0.0});
                lc.push_back({spl, {lpl, ppl}, {2.0, -1.0}, 0.0});
                lc.push_back({sll, {lll, pll}, {2.0, -1.0}, 0.0});

                //y-periodicity
                lc.push_back({fsf, {lll, lpl}, {2.0, -1.0}, 0.0});
                lc.push_back({psf, {pll, ppl}, {2.0, -1.0}, 0.0});
                lc.push_back({lsf, {lll, lpl}, {2.0, -1.0}, 0.0});

                lc.push_back({fss, {lll, llp, lpl, lpp}, {4.0, -2.0, -2.0, 1.0}, 0.0});
                lc.push_back({pss, {pll, plp, ppl, ppp}, {4.0, -2.0, -2.0, 1.0}, 0.0});
                lc.push_back({lss, {lll, llp, lpl, lpp}, {4.0, -2.0, -2.0, 1.0}, 0.0});

                lc.push_back({fsp, {llp, lpp}, {2.0, -1.0}, 0.0});
                lc.push_back({psp, {plp, ppp}, {2.0, -1.0}, 0.0});
                lc.push_back({lsp, {llp, lpp}, {2.0, -1.0}, 0.0});

                lc.push_back({fsl, {lll, lpl}, {2.0, -1.0}, 0.0});
                lc.push_back({psl, {pll, ppl}, {2.0, -1.0}, 0.0});
                lc.push_back({lsl, {lll, lpl}, {2.0, -1.0}, 0.0});


                //z-periodicity
                lc.push_back({ffs, {lll, llp}, {2.0, -1.0}, 0.0});
                lc.push_back({fps, {lpl, lpp}, {2.0, -1.0}, 0.0});
                lc.push_back({fls, {lll, llp}, {2.0, -1.0}, 0.0});

                lc.push_back({pfs, {pll, plp}, {2.0, -1.0}, 0.0});
                lc.push_back({pps, {ppl, ppp}, {2.0, -1.0}, 0.0});
                lc.push_back({pls, {pll, plp}, {2.0, -1.0}, 0.0});

                lc.push_back({lfs, {lll, llp}, {2.0, -1.0}, 0.0});
                lc.push_back({lps, {lpl, lpp}, {2.0, -1.0}, 0.0});
                lc.push_back({lls, {lll, llp}, {2.0, -1.0}, 0.0});
            }

            //edge x-axis direction
            for (int i = _bfOrderX; i < nnx-_bfOrderX; i++)
            {
                // left bottom square
                int ff = i;
                int sf = ff + nnx;
                int fs = ff + nnx * nny;
                int ss = fs + nnx;

                // right bottom square
                int lf = ff + nnx * (nny - 1);
                int pf = lf - nnx;
                int ps = pf + nnx * nny;
                int ls = ps + nnx;

                // left top square
                int fl = ff + nnx * nny * (nnz - 1);
                int sl = fl + nnx;
                int fp = fl - nnx * nny;
                int sp = fp + nnx;

                // right top square
                int ll = fl + nnx * (nny - 1);
                int lp = ll - nnx * nny;
                int pp = lp - nnx;
                int pl = ll - nnx;

                // corners periodicity constraint
                lc.push_back({ff, {ll}, {1.0}, 0.0});
                lc.push_back({fl, {ll}, {1.0}, 0.0});
                lc.push_back({lf, {ll}, {1.0}, 0.0});

                if (_bfOrder == 2)  // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ll, lp}, {2.0, -1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});

                    // neighbors second order continuity
                    lc.push_back({ss, {pl, ll, lp, pp}, {-2.0, 4.0, -2.0, 1.0}, 0.0});
                    lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                    lc.push_back({ps, {pl, pp}, {2.0, -1.0}, 0.0});

                    //continuidad orden 2 esquina
                    lc.push_back({sl, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({ls, {ll, lp}, {2.0, -1.0}, 0.0});
                }
            }

            //edge y-axis direction
            for (int i = _bfOrderY; i < nny-_bfOrderY; i++)
            {
                // left bottom square
                int ff = i * nnx;
                int sf = ff + 1;
                int fs = ff + nnx * nny;
                int ss = fs + 1;

                // right bottom square
                int lf = ff + nnx - 1;
                int pf = lf - 1;
                int ps = pf + nnx * nny;
                int ls = ps + 1;

                // left top square
                int fl = ff + nnx * nny * (nnz - 1);
                int sl = fl + 1;
                int fp = fl - nnx * nny;
                int sp = fp + 1;

                // right top square
                int ll = fl + nnx - 1;
                int lp = ll - nnx * nny;
                int pp = lp - 1;
                int pl = ll - 1;

                // corners periodicity constraint
                lc.push_back({ff, {ll}, {1.0}, 0.0});
                lc.push_back({fl, {ll}, {1.0}, 0.0});
                lc.push_back({lf, {ll}, {1.0}, 0.0});

                if (_bfOrder == 2)  // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ll, lp}, {2.0, -1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});

                    // neighbors second order continuity
                    lc.push_back({ss, {pl, ll, lp, pp}, {-2.0, 4.0, -2.0, 1.0}, 0.0});
                    lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                    lc.push_back({ps, {pl, pp}, {2.0, -1.0}, 0.0});

                    //continuidad orden 2 esquina
                    lc.push_back({sl, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({ls, {ll, lp}, {2.0, -1.0}, 0.0});
                }
            }

            //edge z-axis direction
            for (int i = _bfOrderZ; i < nnz-_bfOrderZ; i++)
            {
                // left bottom square
                int ff = i * nnx * nny;
                int sf = ff + 1;
                int fs = ff + nnx;
                int ss = fs + 1;

                // right bottom square
                int lf = ff + nnx - 1;
                int pf = lf - 1;
                int ps = pf + nnx;
                int ls = ps + 1;

                // left top square
                int fl = ff + nnx * (nny - 1);
                int sl = fl + 1;
                int fp = fl - nnx;
                int sp = fp + 1;

                // right top square
                int ll = fl + nnx - 1;
                int lp = ll - nnx;
                int pp = lp - 1;
                int pl = ll - 1;

                // corners periodicity constraint
                lc.push_back({ff, {ll}, {1.0}, 0.0});
                lc.push_back({fl, {ll}, {1.0}, 0.0});
                lc.push_back({lf, {ll}, {1.0}, 0.0});

                if (_bfOrder == 2)  // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ll, lp}, {2.0, -1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});

                    // neighbors second order continuity
                    lc.push_back({ss, {pl, ll, lp, pp}, {-2.0, 4.0, -2.0, 1.0}, 0.0});
                    lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                    lc.push_back({ps, {pl, pp}, {2.0, -1.0}, 0.0});

                    //continuidad orden 2 esquina
                    lc.push_back({sl, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({ls, {ll, lp}, {2.0, -1.0}, 0.0});
                }
            }

            //Xperiodic
            for (int i = _bfOrderY; i < nny-_bfOrderY; i++)
            {
                for (int j = _bfOrderZ; j < nnz - _bfOrderZ; j++)
                {
                    // Identify first and last nodes
                    int fid = i*nnx + j*nnx*nny ;
                    int lid = fid + nnx - 1;

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderX == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + 1;
                        int pid = lid - 1;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }

            //Yperiodic
            for (int i = _bfOrderX; i < nnx-_bfOrderX; i++)
            {
                for (int j = _bfOrderZ; j < nnz-_bfOrderZ; j++)
                {
                    // Identify first and last nodes
                    int fid = i + j*nnx*nny ;
                    int lid = fid + nnx*(nny - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderY == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + nnx;
                        int pid = lid - nnx;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }

            //Zperiodic
            for (int i = _bfOrderX; i < nnx-_bfOrderX; i++)
            {
                for (int j = _bfOrderY; j < nny-_bfOrderY; j++)
                {
                    // Identify first and last nodes
                    int fid = i + j*nnx ;
                    int lid = fid + nnx*nny*(nnz - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderZ == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + nnx*nny;
                        int pid = lid - nnx*nny;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }
        }
        else if (_periodicInX and _periodicInY)
        {
            if (_bfOrderX != _bfOrderY)
                throw runtime_error("StructMeshGenerator::_periodicSolidNurbs: Not implemented for different orders.");
            for (int i = 0; i < nnz; i++)
            {
                // left bottom square
                int ff = i * nnx * nny;
                int sf = ff + 1;
                int fs = ff + nnx;
                int ss = fs + 1;

                // right bottom square
                int lf = ff + nnx - 1;
                int pf = lf - 1;
                int ps = pf + nnx;
                int ls = ps + 1;

                // right top square
                int ll = ff + nnx * nny - 1;
                int lp = ll - nnx;
                int pp = lp - 1;
                int pl = ll - 1;

                // left top square
                int fl = lp + 1;
                int sl = fl + 1;
                int fp = fl - nnx;
                int sp = fp + 1;

                // Constrain all corners
                lc.push_back({ff, {ll}, {1.0}, 0.0});
                lc.push_back({fl, {ll}, {1.0}, 0.0});
                lc.push_back({lf, {ll}, {1.0}, 0.0});

                if (_bfOrder == 1)  // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ls}, {1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {sl}, {1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});
                }
                else if (_bfOrder == 2) // FIXME:: Only implemented for equal order
                {
                    // Neighbors continuity
                    lc.push_back({fs, {ll, lp}, {2.0, -1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});

                    // Neighbors second order continuity
                    lc.push_back({ss, {pl, ll, lp, pp}, {-2.0, 4.0, -2.0, 1.0}, 0.0});
                    lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                    lc.push_back({ps, {pl, pp}, {2.0, -1.0}, 0.0});

                    // Second-order continuity in the corner
                    lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                    lc.push_back({sl, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({ls, {ll, lp}, {2.0, -1.0}, 0.0});
                }

                // X-axis periodic linear constraints linear constraints not in corner
                for (int j = _bfOrderY; j < nny-_bfOrderY; j++)
                {
                    // Identify first and last nodes
                    int fid = ff + nnx * j;
                    int lid = fid + nnx - 1;

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderX == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + 1;
                        int pid = lid - 1;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }

                // Y-axis periodic linear constraints not in corner
                for (int j = _bfOrderX; j < nnx-_bfOrderX; j++)
                {
                    // Identify first and last nodes
                    int fid = j + ff;
                    int lid = fid + nnx * (nny - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderY == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + nnx;
                        int pid = lid - nnx;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }
        }
        else if (_periodicInX and _periodicInZ)
        {
            if (_bfOrderX != _bfOrderZ)
                throw runtime_error("StructMeshGenerator::_periodicSolidNurbs: Not implemented for different orders.");
            for (int i = 0; i < nny; i++)
            {
                // left bottom square
                int ff = i * nnx;
                int sf = ff + 1;
                int fs = ff + nnx * nny;
                int ss = fs + 1;

                // right bottom square
                int lf = ff + nnx - 1;
                int pf = lf - 1;
                int ps = pf + nnx * nny;
                int ls = ps + 1;

                // right top square
                int ll = ff + nnx * nny * (nnz - 1) + nnx - 1;
                int lp = ll - nnx * nny;
                int pp = lp - 1;
                int pl = ll - 1;

                // left top square
                int fl = ff + nnx * nny * (nnz - 1);
                int sl = fl + 1;
                int fp = fl - nnx * nny;
                int sp = fp + 1;

                // corners periodicity constraint
                lc.push_back({ff, {ll}, {1.0}, 0.0});
                lc.push_back({fl, {ll}, {1.0}, 0.0});
                lc.push_back({lf, {ll}, {1.0}, 0.0});

                if (_bfOrder == 1)  // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ls}, {1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {sl}, {1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});
                }
                else if (_bfOrder == 2)  // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ll, lp}, {2.0, -1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});

                    // neighbors second order continuity
                    lc.push_back({ss, {pl, ll, lp, pp}, {-2.0, 4.0, -2.0, 1.0}, 0.0});
                    lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                    lc.push_back({ps, {pl, pp}, {2.0, -1.0}, 0.0});

                    //continuidad orden 2 esquina
                    lc.push_back({sl, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({ls, {ll, lp}, {2.0, -1.0}, 0.0});
                }

                // X-axis periodic linear constraints linear constraints not in corner
                for (int j = _bfOrderZ; j < nnz-_bfOrderZ; j++)
                {
                    // Identify first and last nodes
                    int fid = ff + nnx * nny * j;
                    int lid = fid + nnx - 1;

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraints
                    if (_bfOrderX == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + 1;
                        int pid = lid - 1;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }


                // Z-axis periodic linear constraints not in corner
                for (int j = _bfOrderX; j < nnx-_bfOrderX; j++)
                {
                    // Identify first and last nodes
                    int fid = j + ff;
                    int lid = fid + nnx * nny * (nnz - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraints
                    if (_bfOrderZ == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + nnx * nny;
                        int pid = lid - nnx * nny;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }
        }
        else if (_periodicInY and _periodicInZ)
        {
            if (_bfOrderY != _bfOrderZ)
                throw runtime_error("StructMeshGenerator::_periodicSolidNurbs: Not implemented for different orders.");

            for (int i = 0; i < nnx; i++)
            {
                // left bottom square
                int ff = i;
                int sf = ff + nnx;
                int fs = ff + nnx * nny;
                int ss = fs + nnx;

                // right bottom square
                int lf = ff + nnx * (nny - 1);
                int pf = lf - nnx;
                int ps = pf + nnx * nny;
                int ls = ps + nnx;

                // left top square
                int fl = ff + nnx * nny * (nnz - 1);
                int sl = fl + nnx;
                int fp = fl - nnx * nny;
                int sp = fp + nnx;

                // right top square
                int ll = fl + nnx * (nny - 1);
                int lp = ll - nnx * nny;
                int pp = lp - nnx;
                int pl = ll - nnx;

                // Linear constrain all corners
                lc.push_back({ff, {ll}, {1.0}, 0.0});
                lc.push_back({fl, {ll}, {1.0}, 0.0});
                lc.push_back({lf, {ll}, {1.0}, 0.0});

                if (_bfOrder == 1) // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ls}, {1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {sl}, {1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});
                }
                else if (_bfOrder == 2) // FIXME:: Only implemented for equal order
                {
                    // neighbors continuity
                    lc.push_back({fs, {ll, lp}, {2.0, -1.0}, 0.0});
                    lc.push_back({fp, {lp}, {1.0}, 0.0});
                    lc.push_back({sf, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({pf, {pl}, {1.0}, 0.0});

                    // neighbors second order continuity
                    lc.push_back({ss, {pl, ll, lp, pp}, {-2.0, 4.0, -2.0, 1.0}, 0.0});
                    lc.push_back({sp, {lp, pp}, {2.0, -1.0}, 0.0});
                    lc.push_back({ps, {pl, pp}, {2.0, -1.0}, 0.0});

                    // Second-order continuity in the corner
                    lc.push_back({sl, {ll, pl}, {2.0, -1.0}, 0.0});
                    lc.push_back({ls, {ll, lp}, {2.0, -1.0}, 0.0});
                }

                // Y-axis periodic linear constraints not in corner
                for (int j = _bfOrderZ; j < nnz-_bfOrderZ; j++)
                {
                    // Identify first and last nodes
                    int fid = j * nnx * nny + ff;
                    int lid = fid + nnx * (nny - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderY == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + nnx;
                        int pid = lid - nnx;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }

                // Z-axis periodic linear constraints linear constraints not in corner
                for (int j = _bfOrderY; j < nny-_bfOrderY; j++)
                {
                    // Identify first and last nodes
                    int fid = ff + nnx * j;
                    int lid = fid + nnx * nny * (nnz - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderZ == 2)
                    {
                        // Identify second and second-last nodes
                        int pid = lid - nnx * nny;
                        int sid = fid + nnx * nny;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }
        }
        else if (_periodicInX)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnz; i++)
                {
                    // Identify first and last nodes
                    int fid = nnx * j + (nnx * nny) * i;
                    int lid = fid + nnx - 1;

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderX == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + 1;
                        int pid = lid - 1;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }
        }
        else if (_periodicInY)
        {
            for (int j = 0; j < nnx; j++)
            {
                for (int i = 0; i < nnz; i++)
                {
                    // Identify first and last nodes
                    int fid = j + i * (nnx * nny);
                    int lid = fid + nnx * (nny - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderY == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + nnx;
                        int pid = lid - nnx;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }
        }
        else if (_periodicInZ)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    // Identify first and last nodes
                    int fid = i + j * (nnx);
                    int lid = fid + nnx * nny * (nnz - 1);

                    // First-order linear constraint
                    lc.push_back({fid, {lid}, {1.0}, 0.0});

                    // Second-order linear constraint
                    if (_bfOrderZ == 2)
                    {
                        // Identify second and second-last nodes
                        int sid = fid + nnx * nny;
                        int pid = lid - nnx * nny;

                        // Constraint
                        lc.push_back({sid, {lid, pid}, {2.0, -1.0}, 0.0});
                    }
                }
            }
        }

        // Save only linear constraints in which the slave is in my partition
        _linearConstraints.resize(0);
        for (size_t l = 0; l < lc.size(); l++)
        {
            int slave = lc[l].slave;
            if (_disPts.isItemInPart(slave))
                _linearConstraints.push_back(lc[l]);
        }
    }

    // Extrude
    void StructMeshGenerator::_extrudeSurfaceLinearNurbs(int nEz, double height)
    {
        (void) nEz;
        (void) height;
        throw runtime_error("StructMeshGenerator::_extrudeSurfaceLinearNurbs: Linear extrusion not implemented for BSplines/Nurbs.");
    }

}
