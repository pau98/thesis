/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francesco Greco and Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_StructMeshGenerator.h"

using std::cout;
using std::endl;
using std::vector;
using std::runtime_error;

namespace hiperlife
{

    //Save and reload mesh
    void StructMeshGenerator::_saveMesh()
    {
        _nDim_tmp = _nDim;
        _bfOrder_tmp = _bfOrder;
        _bfOrderX_tmp = _bfOrderX;
        _bfOrderY_tmp = _bfOrderY;
        _bfOrderZ_tmp = _bfOrderZ;
        _bfOrderX_min_tmp = _bfOrderX_min;
        _bfOrderY_min_tmp = _bfOrderY_min;
        _bfOrderZ_min_tmp = _bfOrderZ_min;
        _isBfOrderSubSet_tmp = _isBfOrderSubSet;
        _eType_tmp = _eType;
        _bfType_tmp = _bfType;

        _x_nodes_tmp = _x_nodes;
        _weights_tmp = _weights;
        _uKnot_tmp   = _uKnot;
        _vKnot_tmp   = _vKnot;
        _wKnot_tmp   = _wKnot;
        _uKnot_min_tmp = _uKnot_min;
        _vKnot_min_tmp = _vKnot_min;
        _wKnot_min_tmp = _wKnot_min;
        _connec_tmp = _connec;
        _creases_tmp = _creases;
        _eflags_tmp = _eflags;
        _elMap_newToOld_tmp = _elMap_newToOld;

        _nPts_tmp = _nPts;
        _nElem_tmp = _nElem;
        _loc_nPts_tmp = _loc_nPts;
        _loc_nElem_tmp = _loc_nElem;
        _nVert_tmp = _nVert;
        _pDim_tmp = _pDim;
        _nCreases_tmp = _nCreases;
        _nEFlags_tmp = _nEFlags;

        _nEx_tmp = _nEx;
        _nEy_tmp = _nEy;
        _nEz_tmp = _nEz;

        _hRefinedMesh_tmp = _hRefinedMesh;
        _pRefinedMesh_tmp = _pRefinedMesh;

        _unclampedX_tmp = _unclampedX;
        _unclampedY_tmp = _unclampedY;
        _unclampedZ_tmp = _unclampedZ;

        _CP_tmp = _CP;
        _CP_min_tmp = _CP_min;

        _history_tmp = _history;
        _history_names_tmp = _history_names;

        _periodicInX_tmp = _periodicInX;
        _periodicInY_tmp = _periodicInY;
        _periodicInZ_tmp = _periodicInZ;
        _linearConstraints_tmp = _linearConstraints;
    }

    void StructMeshGenerator::_reloadMesh()
    {
        _nDim = _nDim_tmp;
        _bfOrder = _bfOrder_tmp;
        _bfOrderX = _bfOrderX_tmp;
        _bfOrderY = _bfOrderY_tmp;
        _bfOrderZ = _bfOrderZ_tmp;
        _bfOrderX_min = _bfOrderX_min_tmp;
        _bfOrderY_min = _bfOrderY_min_tmp;
        _bfOrderZ_min = _bfOrderZ_min_tmp;
        _eType = _eType_tmp;
        _bfType = _bfType_tmp;

        _x_nodes = _x_nodes_tmp;
        _weights = _weights_tmp;
        _uKnot   = _uKnot_tmp;
        _vKnot   = _vKnot_tmp;
        _wKnot   = _wKnot_tmp;
        _uKnot_min = _uKnot_min_tmp;
        _vKnot_min = _vKnot_min_tmp;
        _wKnot_min = _wKnot_min_tmp;
        _connec = _connec_tmp;
        _creases = _creases_tmp;
        _eflags = _eflags_tmp;
        _elMap_newToOld = _elMap_newToOld_tmp;

        _nPts = _nPts_tmp;
        _nElem = _nElem_tmp;
        _loc_nPts = _loc_nPts_tmp;
        _loc_nElem = _loc_nElem_tmp;
        _nVert = _nVert_tmp;
        _pDim = _pDim_tmp;
        _nCreases = _nCreases_tmp;
        _nEFlags = _nEFlags_tmp;

        _nEx = _nEx_tmp;
        _nEy = _nEy_tmp;
        _nEz = _nEz_tmp;

        _CP = _CP_tmp;
        _CP_min = _CP_min_tmp;

        _history = _history_tmp;
        _history_names = _history_names_tmp;

        _periodicInX = _periodicInX_tmp;
        _periodicInY = _periodicInY_tmp;
        _periodicInZ = _periodicInZ_tmp;
        _linearConstraints = _linearConstraints_tmp;

        _hRefinedMesh = false;
        _pRefinedMesh = false;
    }


    //p-Refined mesh
    void StructMeshGenerator::_getPRefinedMesh(int orderInc)
    {
        //Check
        if (_bfType == BasisFuncType::SubdivSurfs)
            throw runtime_error("StructMeshGenerator::_getPRefinedMesh: Subdivision surfaces cannot be p-refined");

        //Save
        _pRefinedMesh = true;

        //Generate
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            _genPRefinedMesh(orderInc);
        else
            _genPRefinedMeshNurbs(orderInc, orderInc, orderInc);
    }

    void StructMeshGenerator::_getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ)
    {
        //Check
        if (_bfType == BasisFuncType::SubdivSurfs)
            throw runtime_error("StructMeshGenerator::_getPRefinedMesh: Subdivision surfaces cannot be p-refined");

        //Save
        _pRefinedMesh = true;

        //Generate
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            throw runtime_error("StructMeshGenerator: getPRefinedMesh: p-Refined mesh with different order per direction only works for BSplines and NURBS.");
        else
            _genPRefinedMeshNurbs(orderIncX, orderIncY, orderIncZ);
    }


    //h-Refined mesh
    void StructMeshGenerator::_getHRefinedMesh(int refLevel)
    {
        _hRefinedMesh = true;

        //Checks
        if (refLevel == 0)
            throw runtime_error("StructMeshGenerator: h-refinement level zero or not set.");
        if (refLevel != 1)
            throw runtime_error("StructMeshGenerator: h-refinement only implemented for one order of refinement (yet).");

        //Refine
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            _genHRefinedMesh(refLevel);
        else
            _genHRefinedMeshNurbs(refLevel);
    }


    //Boundary mesh
    void StructMeshGenerator::_getBoundaryMesh(vector<MAxis> vMAx)
    {
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            throw runtime_error("StructMeshGenerator: getBoundaryMesh: Not yet implemented for Bsplines/NURBS.");

        //Common values
        _nDim = _nDim_tmp;
        _bfOrder = _bfOrder_tmp;
        _bfType = _bfType_tmp;
        _nCreases = _nCreases_tmp;
        _pDim = _pDim_tmp - 1;

        //Checks
        for (auto& ax : vMAx)
        {
            int myAxis = getAxis(ax);
            if ((myAxis == 1) && (_pDim < 1))
                throw runtime_error("StructMeshGenerator: You cannot obtain a boundary mesh in Y direction from a 1D mesh.");
            else if ((myAxis == 2) && (_pDim < 2))
                throw runtime_error("StructMeshGenerator: You cannot obtain a boundary mesh in Z direction from a 2D or 1D mesh.");
        }

        //Generate boundary mesh
        _genBoundaryMesh(vMAx);
    }


    //Checks
    void StructMeshGenerator::_performChecks(int nEx, int nEy, int nEz)
    {
        _performSettingChecks();
        _performElementChecks(nEx, nEy, nEz);
        _performOrderChecks();
    }

    void StructMeshGenerator::_performSettingChecks()
    {

        if (_nDim == 0)
            throw runtime_error("StructMeshGenerator: nDim has not been set.");

        if (_eType == ElemType::Undefined)
            throw runtime_error("StructMeshGenerator: Element type has not been set");

        if (_bfType == BasisFuncType::Undefined)
            throw runtime_error("StructMeshGenerator: Basis functions type has not been set");

        if (_bfOrder < 0 && _bfOrderX < 0 && _bfOrderY < 0 && _bfOrderZ < 0 && _bfType != BasisFuncType::Linear && _bfType != BasisFuncType::SubdivSurfs)
            throw runtime_error("StructMeshGenerator: The order of the basis functions has not been set or it is negative.");
    }

    void StructMeshGenerator::_performElementChecks(int nEx, int nEy, int nEz)
    {
        if (nEx < -1 && nEy < -1 && nEz < -1)
            throw runtime_error("StructMeshGenerator: Number of elements should be positive.");
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (nEx == -1 || nEy != -1 || nEz != -1)
                    throw runtime_error("StructMeshGenerator: Line elements should (only) have elements in x direction.");
                break;
            case static_cast<int>(ElemType::Triang):
                if ((nEx == -1 || nEy == -1) || (nEz != -1))
                    throw runtime_error("StructMeshGenerator: Triang elements should (only) have elements in x and y directions.");
                break;
            case static_cast<int>(ElemType::Square):
                if ((nEx == -1 || nEy == -1) || (nEz != -1))
                    throw runtime_error("StructMeshGenerator: Square elements should (only) have elements in x and y directions.");
                break;
            case static_cast<int>(ElemType::Tetrah):
                if (nEx == -1 || nEy == -1 || nEz == -1)
                    throw runtime_error("StructMeshGenerator: Tetrah elements should have elements in x, y and z directions.");
                break;
            case static_cast<int>(ElemType::Parallelep):
                if (nEx == -1 || nEy == -1 || nEz == -1)
                    throw runtime_error("StructMeshGenerator: Parallelep elements should have elements in x, y and z directions.");
                break;
            default:
                throw runtime_error("StructMeshGenerator: Wrong element type.");
        }
    }


    //Utils
    void StructMeshGenerator::_printMesh(const std::string& mssg)
    {
        if (_myRank == 0)
            cout << endl << mssg << endl;

        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                cout << "Processor: " << p << endl;
                cout << " bf: " << str(_bfType) << endl;
                cout << " eType: " << str(_eType) << endl;

                cout << " nPts: " << _nPts << " " << _loc_nPts << endl;
                cout << " nEle: " << _nElem << " " << _loc_nElem << " ("<< _nEx << ", " <<  _nEy << ", " <<  _nEz << ")" << endl;
                cout << " Ord:  "<< _bfOrder << " ("<< _bfOrderX << ", " << _bfOrderY << ", " << _bfOrderZ << ")" << endl;

                cout << " xnodes:" << endl;
                int n = 0;
                for (int i = 0; i < _nPts; i++)
                {
                    if(_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        cout << "   " << i << " - ";
                        for (int j = 0; j < _nDim; j++)
                            cout << _x_nodes[_loc_nPts * j + locN] << " ";
                        cout << endl;
                    }
                    n++;
                }

                cout << " connec:" << endl;
                n = 0;
                for (int i = 0; i < _nElem; i++)
                {
                    if(_disElem.isItemInPart(n))
                    {
                        int locN = _disElem.locIdx(n);
                        cout << "   "  << i << " - ";
                        for (int j = 0; j < _nVert; j++)
                            cout << _connec[locN * _nVert + j] << " ";
                        cout << endl;
                    }
                    n++;
                }

                cout << " creases:" << endl;
                n = 0;
                for (int i = 0; i < _nPts; i++)
                {
                    if(_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        cout << "   " << i << " - ";
                        for (int j = 0; j < _nCreases; j++)
                            cout << _creases[_loc_nPts * j + locN] << " ";
                        cout << endl;
                    }
                    n++;
                }

                cout << " eflags:" << endl;
                n = 0;
                for (int i = 0; i < _nElem; i++)
                {
                    if(_disElem.isItemInPart(n))
                    {
                        int locN = _disElem.locIdx(n);
                        cout << "   "  << i << " - ";
                        for (int j = 0; j < _nEFlags; j++)
                            cout << _eflags[locN * _nEFlags + j] << " ";
                        cout << endl;
                    }
                    n++;
                }

                if ((_bfType == BasisFuncType::Nurbs) || (_bfType == BasisFuncType::BSplines))
                {
                    cout << " U : " << endl << "   ";
                    for (auto u: _uKnot)
                        cout << u << " ";
                    cout << endl;
                    cout << " V : " << endl << "   ";
                    for (auto u: _vKnot)
                        cout << u << " ";
                    cout << endl;
                    cout << " W : " << endl << "   ";
                    for (auto u: _wKnot)
                        cout << u << " ";
                    cout << endl;
                    cout << " CP :" << endl;
                    for (auto i = 0u; i < _CP.size(); i++)
                    {
                        for (auto j = 0u; j < _CP[i].size(); j++)
                        {
                            for (auto k = 0u; k < _CP[i][j].size(); k++)
                            {
                                cout << "  ";
                                for (int d = 0; d < 4; d++)
                                {
                                    cout << " " << _CP[i][j][k][d];
                                }
                                cout << endl;
                            }
                        }
                    }
                }

            }
            Barrier();
        }
    }

    void StructMeshGenerator::_distConnec(int nn, int value)
    {
        int el = nn / _nVert;
        if (_disElem.isItemInPart(el) == false)
            return;

        int locEl  = _disElem.locIdx(el);
        int numNbor = nn % _nVert;

        _connec[locEl * _nVert + numNbor] = value;
    }

}
