/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francesco Greco
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <fstream>

#include <gmsh.h>
#include <mpi.h>

#include "hl_legIOAux.h"
#include "hl_Math.h"
#include "hl_TypeDefs.h"
#include "hl_UnstructGmshMeshGenerator.h"
#ifdef HL_VTK
#include <vtkDoubleArray.h>
#include <vtkPointData.h>
#include <vtkPolyData.h>
#include "hl_UnstructVtkMeshGenerator.h"
#endif

using std::cout;
using std::endl;
using std::vector;
using std::string;
using std::runtime_error;


namespace factory = gmsh::model::geo;

namespace hiperlife
{

    // Save and reload mesh
    void UnstructGmshMeshGenerator::_saveMesh()
    {
        return;
    }

    void UnstructGmshMeshGenerator::_reloadMesh()
    {
        return;
    }


    // Derived meshes
    void UnstructGmshMeshGenerator::_getPRefinedMesh(int orderInc)
    {
        (void) orderInc;
        throw runtime_error("UnstructGmshMeshGenerator::getPRefinedMesh:  Not implemented.");
    }

    void UnstructGmshMeshGenerator::_getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ)
    {
        (void) orderIncX;
        (void) orderIncY;
        (void) orderIncZ;
        throw runtime_error("UnstructGmshMeshGenerator:: getPRefinedMesh: Not implemented.");
    }

    void UnstructGmshMeshGenerator::_getHRefinedMesh(int refLevel)
    {
#ifdef HL_VTK
        // Checks
        if (_meshType == MeshType::Parallel)
            throw runtime_error("UnstructGmshMeshGenerator::_getHRefinedMesh: h-refine a mesh loaded in parallel not implemented.");

        // Initialize
        vtkSmartPointer<vtkPolyData> polyData =  vtkSmartPointer<vtkPolyData>::New();

        // Create points
        vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
        points->SetNumberOfPoints(_nPts);
        for (int i = 0; i < _nPts; i++)
        {
            points->SetPoint(i,_glob_x_nodes[_nDim*i+0],_glob_x_nodes[_nDim*i+1],_glob_x_nodes[_nDim*i+2]);
        }
        polyData->SetPoints(points);

        // Create elements
        vtkSmartPointer<vtkCellArray> elems = vtkSmartPointer<vtkCellArray>::New();
        for (int e = 0; e < _nElem; e++)
        {
            vtkSmartPointer<vtkIdList> elem = vtkSmartPointer<vtkIdList>::New();

            for (int n=0; n <_nVert; n++)
                elem->InsertNextId(_glob_connec[e*_nVert+n]);

            elems->InsertNextCell(elem);
        }
        polyData->SetPolys(elems);

        // Insert nodeFields (creases)
        vtkSmartPointer<vtkDoubleArray> vtknodeFields = vtkSmartPointer<vtkDoubleArray>::New();
        vtknodeFields->SetNumberOfComponents(1);
        vtknodeFields->SetNumberOfTuples(_nPts);
        vtknodeFields->SetName("Creases");
        vtkIdType n{};
        for (int i = 0; i < _nPts; i++)
        {
            vtknodeFields->SetValue(n, _glob_creases[_nCreases*i]);
            n++;
        }
        polyData->GetPointData()->AddArray(vtknodeFields);

        // Compute h-refined mesh
        UnstructVtkMeshGenerator::_computeHRefinedMesh(refLevel, _nPts, _nElem, _nDim, _nVert, _nCreases, _nEFlags,
                                                       _glob_x_nodes, _glob_connec, _glob_creases, _glob_eflags,
                                                       polyData, _comm, myRank());
#else
        (void) refLevel;
        throw runtime_error("UnstructGmshMeshGenerator::_getHRefinedMesh: VTK is required to h-refine a mesh.");
#endif
    }

    void UnstructGmshMeshGenerator::_getBoundaryMesh(vector<MAxis> vMAx)
    {
        (void) vMAx;
        throw runtime_error("UnstructGmshMeshGenerator:: getBoundaryMesh: Not implemented.");
    }


    //Checks
    void UnstructGmshMeshGenerator::_performSettingChecks()
    {
        if (_eType != ElemType::Triang)
            throw runtime_error("UnstructGmshMeshGenerator:: Only triangular elements are implemented.");
        if (_bfType != BasisFuncType::Linear and _bfType != BasisFuncType::Lagrangian and _bfType != BasisFuncType::SubdivSurfs)
            throw runtime_error("UnstructGmshMeshGenerator:: Only working with linear, Lagrangian or subdivision surfaces.");
        if (_bfOrder > 1 and _bfType != BasisFuncType::SubdivSurfs)
            throw runtime_error("UnstructGmshMeshGenerator:: Only working with order 1, except for subdivision surfaces (which is always 2).");
    }

    void UnstructGmshMeshGenerator::_performChecks()
    {
        //Settings checks
        _performSettingChecks();

        //Order checks
        _performOrderChecks();

        //Check if other mesh was already generated
        if (_isMeshGenerated() == true)
            throw runtime_error("UnstructGmshMeshGenerator:: Only one mesh can be generated.");

    }


    // 2D Generations
    void UnstructGmshMeshGenerator::_genPoly(vector<double> x, vector<double> y, double lc)
    {
        //Checks
        _performChecks();

        //Initialize
        _pDim = computePDim(_eType);
        _nVert = computeNVert(_bfType, _eType, _bfOrder);

        //Generate
        if (myRank() == 0)
        {
            // Initialize Gmsh
            gmsh::initialize();
            gmsh::option::setNumber("General.Terminal", 1);
            gmsh::model::add("t1");
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Number of vertices
            int nv = int(x.size());

            // // Compute normal direction
            // double norm{};
            // for (int i = 0; i < nv; i++)
            // {
            //     vector<double> c(3);
            //     int j0{i-1}, j1{i}, j2{i+1};
            //     if (i == 0)
            //         j0 = nv-1;
            //     if (i == nv-1)
            //         j2 = 0;
            //     vector<double> u ={x[j1]-x[j0], y[j1]-y[j0], 0.0};
            //     vector<double> v ={x[j2]-x[j1], y[j2]-y[j1], 0.0};
            //     Math::Cross(c.data(), u.data(), v.data());
            //     norm += c[2]/abs(c[2]);
            // }

            // // Reverse if normal direction = -z
            // if (norm < 0.0)
            // {
            //     std::reverse(x.begin(), x.end());
            //     std::reverse(y.begin(), y.end());
            // }
            

            // Compute normal direction
            double zval = 0;
            for (int i = 0; i <(nv-1); i++)
                zval += (x[i+1]-x[i])*(y[i+1]+y[i]);

            // Reverse if normal direction = -z
            if (zval > 0.0)
            {
                std::reverse(x.begin(), x.end());
                std::reverse(y.begin(), y.end());
            }

            // Set points
            for (int i = 0; i < nv; i++)
                factory::addPoint(x[i], y[i], 0, lc, i + 1);

            // Set lines
            vector<double> v_lines={};
            for (int i = 0; i < nv - 1; i++)
            {
                factory::addLine(i + 1, i + 2, i + 1);
                v_lines.push_back(i+1);
            }
            factory::addLine(nv, 1, nv);

            // Set curves
            std::vector<int> poli(nv);
            for (int i = 0; i < nv; i++)
                poli[i] = i + 1;
            factory::addCurveLoop(poli, 1);

            // Set surface
            factory::addPlaneSurface({1}, 1);

            // Synchronize
            factory::synchronize();

            // Set mesh element size
            gmsh::model::mesh::field::add("Distance", 1);
            gmsh::model::mesh::field::setNumbers(1, "CurvesList", v_lines);
            gmsh::model::mesh::field::setNumber(1, "Sampling", 100);

            gmsh::model::mesh::field::add("Threshold", 2);
            gmsh::model::mesh::field::setNumber(2, "InField", 1);
            gmsh::model::mesh::field::setNumber(2, "SizeMin", 0.5*lc);
            gmsh::model::mesh::field::setNumber(2, "SizeMax", 5*lc);
            gmsh::model::mesh::field::setNumber(2, "DistMin", 0.05);
            gmsh::model::mesh::field::setNumber(2, "DistMax", 0.2);
            gmsh::model::mesh::field::setAsBackgroundMesh(2);
                        
            gmsh::option::setNumber("Mesh.MeshSizeExtendFromBoundary", 0);
            gmsh::option::setNumber("Mesh.MeshSizeFromPoints", 0);
            gmsh::option::setNumber("Mesh.MeshSizeFromCurvature", 300);

            // Generate mesh
            gmsh::model::mesh::generate(2);

            // Elevate order
            if (_bfOrder > 1)
                gmsh::model::mesh::setOrder(_bfOrder);

            // Extract mesh info to hiperlife
            _gmsh2hl();

            // Finalize
            gmsh::finalize();
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nDim, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        // Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }
    
    void UnstructGmshMeshGenerator::genPolyHole(vector<double> xOut, vector<double> yOut, vector<double> xIn, vector<double> yIn, double lcOut, double lcIn)
    {
        //Checks
        _performChecks();

        //Initialize
        _pDim = computePDim(_eType);
        _nVert = computeNVert(_bfType, _eType, _bfOrder);
            cout << "Start mesh" << endl;

        // Generate
        if (myRank() == 0)
        {
            // Initialize Gmsh
            gmsh::initialize();
            gmsh::option::setNumber("General.Terminal", 1);
            gmsh::model::add("t1");
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Number of vertices
            int nvOut = int(xOut.size());
            int nvIn = int(xIn.size());

            // Compute normal direction Out
            double zvalOut = 0;
            for (int i = 0; i <(nvOut-1); i++)
                zvalOut += (xOut[i+1]-xOut[i])*(yOut[i+1]+yOut[i]);

            // Reverse if normal direction = -z
            if (zvalOut > 0.0)
            {
                std::reverse(xOut.begin(), xOut.end());
                std::reverse(yOut.begin(), yOut.end());
            }

            // Set points
            for (int i = 0; i < nvOut; i++)
                factory::addPoint(xOut[i], yOut[i], 0, lcOut, i + 1);

            // Set lines
            vector<double> vLinesOut={};
            for (int i = 0; i < nvOut - 1; i++)
            {
                factory::addLine(i + 1, i + 2, i + 1);
                vLinesOut.push_back(i+1);
            }
            factory::addLine(nvOut, 1, nvOut);

            // Set curves
            std::vector<int> poliOut(nvOut);
            for (int i = 0; i < nvOut; i++)
                poliOut[i] = i + 1;
            factory::addCurveLoop(poliOut, 1);
            cout << "Out Done" << endl;
            //***** */
            // In
            //***** */
            // Compute normal direction In
            double zval = 0;
            for (int i = 0; i <(nvIn-1); i++)
                zval += (xIn[i+1]-xIn[i])*(yIn[i+1]+yIn[i]);

            // Reverse if normal direction = z
            if (zval < 0.0)
            {
                std::reverse(xIn.begin(), xIn.end());
                std::reverse(yIn.begin(), yIn.end());
            }

            // Set points
            for (int i = 0; i < nvIn; i++)
                factory::addPoint(xIn[i], yIn[i], 0, lcIn, i+1+nvOut);

            // Set lines
            vector<double> vLinesIn={};
            for (int i = 0; i < nvIn - 1; i++)
            {
                factory::addLine(i+1+nvOut, i+2+nvOut, i+1+nvOut);
                vLinesIn.push_back(i+1+nvOut);
            }
            factory::addLine(nvOut+nvIn, 1+nvOut, nvOut+nvIn);

            // Set curves
            std::vector<int> poliIn(nvIn);
            for (int i = 0; i < nvIn; i++)
                poliIn[i] = i+1+nvOut;
            factory::addCurveLoop(poliIn, 2);
            std::reverse(poliIn.begin(), poliIn.end());
            factory::addCurveLoop(poliIn, 3);
            cout << "In Done" << endl;

            // Set surface
            // factory::addPlaneSurface({3}, 1);
            factory::addPlaneSurface({1,2}, 2);
            // factory::addPhysicalGroup(2,{3,4});
            gmsh::model::mesh::removeDuplicateNodes();            
            // Synchronize
            factory::synchronize();
            // gmsh::model::mesh::setCompound(2,{1,2});

            // Set mesh element size
            gmsh::model::mesh::field::add("Distance", 1);
            gmsh::model::mesh::field::setNumbers(1, "CurvesList", vLinesIn);
            gmsh::model::mesh::field::setNumber(1, "Sampling", 100);

            gmsh::model::mesh::field::add("Threshold", 2);
            gmsh::model::mesh::field::setNumber(2, "InField", 1);
            gmsh::model::mesh::field::setNumber(2, "SizeMin", 0.5*lcIn);
            gmsh::model::mesh::field::setNumber(2, "SizeMax", 3*lcIn);
            gmsh::model::mesh::field::setNumber(2, "DistMin", 0.0005);
            gmsh::model::mesh::field::setNumber(2, "DistMax", 0.001);
            
            gmsh::model::mesh::field::add("Distance", 3);
            gmsh::model::mesh::field::setNumbers(3, "CurvesList", vLinesOut);
            gmsh::model::mesh::field::setNumber(3, "Sampling", 100);

            gmsh::model::mesh::field::add("Threshold", 4);
            gmsh::model::mesh::field::setNumber(4, "InField", 3);
            gmsh::model::mesh::field::setNumber(4, "SizeMin", lcOut);
            gmsh::model::mesh::field::setNumber(4, "SizeMax", 3*lcOut);
            gmsh::model::mesh::field::setNumber(4, "DistMin", 0.0005);
            gmsh::model::mesh::field::setNumber(4, "DistMax", 0.001);
            
            gmsh::model::mesh::field::add("Min", 5);
            gmsh::model::mesh::field::setNumbers(5, "FieldsList", {2, 4});
            gmsh::model::mesh::field::setAsBackgroundMesh(5);
                        
            gmsh::option::setNumber("Mesh.MeshSizeExtendFromBoundary", 0);
            gmsh::option::setNumber("Mesh.MeshSizeFromPoints", 0);
            gmsh::option::setNumber("Mesh.MeshSizeFromCurvature", 0);

            // Generate mesh
            gmsh::model::mesh::removeDuplicateNodes();            
            gmsh::model::mesh::generate(2);
            gmsh::model::mesh::removeDuplicateNodes();
            gmsh::write("t1.msh");

            // Elevate order
            if (_bfOrder > 1)
                gmsh::model::mesh::setOrder(_bfOrder);

            // Extract mesh info to hiperlife
            _gmsh2hl();

            // Finalize
            gmsh::finalize();
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nDim, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        // Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }

    void UnstructGmshMeshGenerator::_read2DPointsFromCSV(string fname, vector<double> &x, vector<double> &y)
    {
        // Checks
        _checkFileExists(fname);

        // Check that file is a CSV
        if (_getFileExtension(fname) != "csv")
            throw runtime_error("UnstructGmshMeshGenerator::_read2DPointsFromCSV: Only CSV files are allowed.");

        // Read number of points
        int nPts{};
        if (myRank() == 0)
        {
            string line;
            std::ifstream file(fname);
            while (getline(file, line))
                nPts++;
            file.close();
        }

        // Create vectors of coordinates
        if (myRank() == 0)
        {
            // Read file into vector
            vector<double> buff;
            std::ifstream file(fname);
            fillVectorData<double>(buff, file, nPts, 2);
            file.close();

            // Rearrange into vectors
            x.resize(nPts, 0);
            y.resize(nPts, 0);
            for (int n = 0; n < nPts; n++)
            {
                x[n] = buff[n*2+0];
                y[n] = buff[n*2+1];
            }
        }
    }

    void UnstructGmshMeshGenerator::genPoly(string fname, double lc)
    {
        // Read points
        vector<double> x, y;
        _read2DPointsFromCSV(fname, x, y);

        // Generate
        _genPoly(x, y, lc);
    }


    void UnstructGmshMeshGenerator::genRegularPoly(int nv, double r, double lc)
    {
        // Create vectors of coordinates
        vector<double> x(nv), y(nv);
        if (myRank() == 0)
        {
            double an;
            for (int i = 0; i < nv; i++)
            {
                an = 2 * M_PI * i / nv;
                x[i] = r * cos(an);
                y[i] = r * sin(an);
            }
        }

        // Generate
        _genPoly(x, y, lc);
    }


    void UnstructGmshMeshGenerator::genRectangle(double a, double b, double lc)
    {
        // Create vectors of coordinates
        vector<double> x(4), y(4);
        if (myRank() == 0)
        {
            x = {0, a, a, 0};
            y = {0, 0, b, b};
        }

        // Generate
        _genPoly(x, y, lc);

        // Add second creases (MAxis)
        if (myRank() == 0)
        {
            // Set tolerance value
            double tol = 1e-8;

            // Initialize to one
            for (int i = 0; i < _nPts; i++)
                _glob_creases[2*i + 1] = 1;

            // Set creases
            for (int i = 0; i < _nPts; i++)
            {
                // Get coordinates
                vector<double> coords(2);
                for (int d = 0; d < 2; d++)
                    coords[d] = _glob_x_nodes[i*_nDim + d];

                // Left (2)
                if (coords[0] < tol)
                    _glob_creases[2*i + 1] *= 2;
                // Right (3)
                if (coords[0] > a-tol)
                    _glob_creases[2*i + 1] *= 3;
                // Bottom (5)
                if (coords[1] < tol)
                    _glob_creases[2*i + 1] *= 5;
                // Bottom (7)
                if (coords[1] > b-tol)
                    _glob_creases[2*i + 1] *= 7;
            }

            // Not boundary (-1)
            for (int i = 0; i < _nPts; i++)
            {
                if (_glob_creases[2*i + 1] == 1)
                    _glob_creases[2*i + 1] = -1;
            }
        }
    }


    void UnstructGmshMeshGenerator::genCircle(double r, double lc)
    {
        //Checks
        _performChecks();

        //Initialize
        _pDim = computePDim(_eType);
        _nVert = computeNVert(_bfType, _eType, _bfOrder);

        if (myRank() == 0)
        {
            // Initialize gmsh
            gmsh::initialize();
            gmsh::option::setNumber("General.Terminal", 1);
            gmsh::model::add("t1");
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Add points
            factory::addPoint(-r, 0, 0, lc, 1);
            factory::addPoint(0, -r, 0, lc, 2);
            factory::addPoint(r, 0, 0, lc, 3);
            factory::addPoint(0, r, 0, lc, 4);
            factory::addPoint(0, 0, 0, lc, 5);

            // Add arcs
            factory::addCircleArc(1, 5, 2, 1);
            factory::addCircleArc(2, 5, 3, 2);
            factory::addCircleArc(3, 5, 4, 3);
            factory::addCircleArc(4, 5, 1, 4);

            // Add curve
            int nv = 4;
            std::vector<int> poli(nv);
            for (int i = 0; i < nv; i++)
                poli[i] = i + 1;
            factory::addCurveLoop(poli, 1);

            // Add surface
            factory::addPlaneSurface({1}, 1);

            // Generate the mesh
            factory::synchronize();
            gmsh::model::mesh::generate(2);

            // Set order
            if (_bfOrder > 1)
                gmsh::model::mesh::setOrder(_bfOrder);

            // Extract mesh info to hplfe
            _gmsh2hl();

            // Fix the corner creases to 1 in the case of the circle
            for (int i = 0; i < _nPts; i++)
                if (_glob_creases[2*i] == 2)
            _glob_creases[2*i]= 1;

            // Finalize
            gmsh::finalize();
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nDim, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }


    void UnstructGmshMeshGenerator::genBSpline(vector<double> x, vector<double> y, double lc)
    {
        // Checks
        _performChecks();

        // Initialize
        _pDim = computePDim(_eType);
        _nVert = computeNVert(_bfType, _eType, _bfOrder);

        if (myRank() == 0)
        {
            // Initialize gmsh
            gmsh::initialize();
            gmsh::option::setNumber("General.Terminal", 1);
            gmsh::model::add("t1");
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Number of points
            int nv = int(x.size());

            // Compute normal direction
            double norm{};
            for (int i = 0; i < nv; i++)
            {
                vector<double> c(3);
                int j0{i-1}, j1{i}, j2{i+1};
                if (i == 0)
                    j0 = nv-1;
                if (i == nv-1)
                    j2 = 0;
                vector<double> u ={x[j1]-x[j0], y[j1]-y[j0], 0.0};
                vector<double> v ={x[j2]-x[j1], y[j2]-y[j1], 0.0};
                Math::Cross(c.data(), u.data(), v.data());
                norm += c[2]/abs(c[2]);
            }

            // Reverse if normal direction = -z
            if (norm < 0.0)
            {
                std::reverse(x.begin(), x.end());
                std::reverse(y.begin(), y.end());
            }

            // Set points
            for (int i = 0; i < nv; i++)
                factory::addPoint(x[i], y[i], 0, lc, i + 1);

            // Generate vector with points
            std::vector<int> poli(nv + 1);
            for (int i = 0; i < nv; i++)
                poli[i] = i + 1;
            poli[nv] = 1;

            // Bspline line + curve + surface
            factory::addBSpline(poli, 1);
            factory::addCurveLoop({1}, 1);
            factory::addPlaneSurface({1}, 1);
            factory::synchronize();

            // Generate mesh
            gmsh::model::mesh::generate(2);

            // Set order
            if (_bfOrder > 1)
                gmsh::model::mesh::setOrder(_bfOrder);

            // Extract mesh info to hplfe
            _gmsh2hl();

            // The creases of the first control point is 2 and is fixed to 1
            for (int i = 0; i < _nPts; i++)
                if (_glob_creases[2*i] == 2)
                    _glob_creases[2*i] = 1;

            // Finalize
            gmsh::finalize();
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nDim, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        // Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }


    void UnstructGmshMeshGenerator::genBSpline(string fname, double lc)
    {
        // Read points
        vector<double> x, y;
        _read2DPointsFromCSV(fname, x, y);

        // Generate
        genBSpline(x, y, lc);
    }


    void UnstructGmshMeshGenerator::genSphereTri(double r, double lc)
    {
        //Checks
        _performChecks();

        //Initialize
        _pDim = computePDim(_eType);
        _nVert = computeNVert(_bfType, _eType, _bfOrder);

        if (myRank() == 0)
        {
            // Initialize
            gmsh::initialize();
            gmsh::option::setNumber("General.Terminal", 1);
            gmsh::model::add("t1");
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Set points
            factory::addPoint(0, 0, 0, lc, 1);
            factory::addPoint(r, 0, 0, lc, 2);
            factory::addPoint(-r, 0, 0, lc, 3);
            factory::addPoint(0, r, 0, lc, 4);
            factory::addPoint(0, -r, 0, lc, 5);
            factory::addPoint(0, 0, r, lc, 6);
            factory::addPoint(0, 0, -r, lc, 7);

            // Set circular arcs
            factory::addCircleArc(6, 1, 3, 1);
            factory::addCircleArc(3, 1, 7, 2);
            factory::addCircleArc(7, 1, 2, 3);
            factory::addCircleArc(2, 1, 6, 4);
            factory::addCircleArc(6, 1, 5, 5);
            factory::addCircleArc(5, 1, 3, 6);
            factory::addCircleArc(5, 1, 7, 7);
            factory::addCircleArc(5, 1, 2, 8);
            factory::addCircleArc(6, 1, 4, 9);
            factory::addCircleArc(3, 1, 4, 10);
            factory::addCircleArc(2, 1, 4, 11);
            factory::addCircleArc(4, 1, 7, 12);

            // Set curves
            factory::addCurveLoop({12, 3, 11}, 13);
            factory::addCurveLoop({9, -11, 4}, 15);
            factory::addCurveLoop({4, 5, 8}, 17);
            factory::addCurveLoop({8, -3, -7}, 19);
            factory::addCurveLoop({7, -2, -6}, 21);
            factory::addCurveLoop({2, -12, -10}, 23);
            factory::addCurveLoop({1, 10, -9}, 25);
            factory::addCurveLoop({6, -1, 5}, 27);

            // Set surfaces
            for (int i = 13; i < 28; i = i + 2)
                factory::addSurfaceFilling({i}, i + 1);

            // Sync and mesh
            factory::synchronize();
            gmsh::model::mesh::generate(2);

            // Set order
            if (_bfOrder > 1)
                gmsh::model::mesh::setOrder(_bfOrder);

            // Get info
            std::vector<int> elementTypes;
            std::vector<std::vector<size_t> > elementTags;
            std::vector<std::vector<size_t> > nodeTags;

            gmsh::model::mesh::getElements(elementTypes, elementTags, nodeTags, -1, -1);


            std::vector<size_t> nodeTags1;
            std::vector<double> coord;
            std::vector<double> parametricCoord;

            gmsh::model::mesh::getNodes(nodeTags1, coord, parametricCoord, -1, -1, false);



            //we ignore the first node at the center
            _nPts = int(coord.size()) / 3 - 1;
            _glob_x_nodes.resize(3 * _nPts);


            for (int i = 0; i < 3 * _nPts; i++)
                _glob_x_nodes[i] = coord[i + 3];


            int nne = ((_bfOrder + 1) * (_bfOrder + 2)) / 2;


            std::vector<int> vmap;
            vmap = _create_mapping(_bfOrder);


            _nElem = int(nodeTags[1].size()) / nne;


            std::vector<int> ecorr;
            ecorr.resize(_nElem * nne);


            for (int i = 0; i < _nElem; i++)
                for (int j = 0; j < nne; j++)
                    ecorr[i * nne + j] = nodeTags[1][i * nne + vmap[j]];


            for (int i = 0; i < _nElem * nne; i++)
                nodeTags[1][i] = ecorr[i];





            //this second correction is necessary because of the ordering of gmsh
            std::vector<int> corr(_nPts + 1);

            for (int i = 0; i < _nPts + 1; i++)
                corr[nodeTags1[i] - 1] = i;


            _glob_connec.resize(nodeTags[1].size());



            //there is -1 at the end here since we remove the first node at the center
            for (size_t i = 0; i < nodeTags[1].size(); i++)
                _glob_connec[i] = corr[nodeTags[1][i] - 1] - 1;


            _glob_creases.resize(_nPts * 2, 0);


            for (int i = 0; i < _nPts; i++)
                _glob_creases[2 * i + 1] = -1;


            _glob_eflags.resize(_nElem * _nEFlags, 0);



            // Finalize
            gmsh::finalize();
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nDim, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        // Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }


    void UnstructGmshMeshGenerator::genSphereQua(double r, double lc)
    {
        // Checks
        _performChecks();

        // Initialize
        _pDim = computePDim(_eType);
        _nVert = computeNVert(_bfType, _eType, _bfOrder);

        if (myRank() == 0)
        {
            // Initialize gmsh
            gmsh::initialize();
            gmsh::option::setNumber("General.Terminal", 1);
            gmsh::model::add("t1");
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Set points
            double r3=sqrt(3)/3*r;
            factory::addPoint(0, 0,0, lc, 1);
            factory::addPoint(r3, -r3, -r3, lc, 2);
            factory::addPoint(r3, -r3, r3, lc, 3);
            factory::addPoint(r3, r3, r3, lc, 4);
            factory::addPoint(r3, r3, -r3, lc, 5);
            factory::addPoint(-r3, -r3, -r3, lc, 6);
            factory::addPoint(-r3, -r3, r3, lc, 7);
            factory::addPoint(-r3, r3, r3, lc, 8);
            factory::addPoint(-r3, r3, -r3, lc, 9);

            // Set circular arcs
            factory::addCircleArc(2, 1, 3, 1);
            factory::addCircleArc(3, 1, 4, 2);
            factory::addCircleArc(4, 1, 5, 3);
            factory::addCircleArc(5, 1, 2, 4);
            factory::addCircleArc(6, 1, 7, 5);
            factory::addCircleArc(7, 1, 8, 6);
            factory::addCircleArc(8, 1, 9, 7);
            factory::addCircleArc(9, 1, 6, 8);
            factory::addCircleArc(2, 1, 6, 9);
            factory::addCircleArc(3, 1, 7, 10);
            factory::addCircleArc(4, 1, 8, 11);
            factory::addCircleArc(5, 1, 9, 12);

            // Set curves
            factory::addCurveLoop({1, 2, 3, 4}, 10);
            factory::addCurveLoop({5, 6, 7, 8}, 11);
            factory::addCurveLoop({6, -11, -2, 10}, 12);
            factory::addCurveLoop({5, -10, -1 ,9}, 13);
            factory::addCurveLoop({-8, -12, 4, 9}, 14);
            factory::addCurveLoop({-7, -11, 3, 12}, 15);

            // Set surfaces
            for (int i = 10; i <=15; i++)
                factory::addSurfaceFilling({i}, i +6);

            // Sync and mesh
            factory::synchronize();
            gmsh::model::mesh::generate(2);

            // Change order
            if (_bfOrder > 1)
                gmsh::model::mesh::setOrder(_bfOrder);

            // Get info
            std::vector<int> elementTypes;
            std::vector<std::vector<size_t> > elementTags;
            std::vector<std::vector<size_t> > nodeTags;

            gmsh::model::mesh::getElements(elementTypes, elementTags, nodeTags, -1, -1);

            // Coordinates
            std::vector<size_t> nodeTags1;
            std::vector<double> coord;
            std::vector<double> parametricCoord;
            gmsh::model::mesh::getNodes(nodeTags1, coord, parametricCoord, -1, -1, false);
            _nPts = int(coord.size()) / 3 - 1; // Ignore 1st node at center
            _glob_x_nodes.resize(3 * _nPts);
            for (int i = 0; i < 3 * _nPts; i++)
                _glob_x_nodes[i] = coord[i + 3];


            int nne = ((_bfOrder + 1) * (_bfOrder + 2)) / 2;


            std::vector<int> vmap;
            vmap = _create_mapping(_bfOrder);


            _nElem = int(nodeTags[1].size()) / nne;


            std::vector<int> ecorr;
            ecorr.resize(_nElem * nne);


            for (int i = 0; i < _nElem; i++)
                for (int j = 0; j < nne; j++)
                    ecorr[i * nne + j] = nodeTags[1][i * nne + vmap[j]];


            for (int i = 0; i < _nElem * nne; i++)
                nodeTags[1][i] = ecorr[i];



            //this second correction is necessary because of the ordering of gmsh
            std::vector<int> corr(_nPts + 1);

            for (int i = 0; i < _nPts + 1; i++)
                corr[nodeTags1[i] - 1] = i;


            _glob_connec.resize(nodeTags[1].size());


            //there is -1 at the end here since we remove the first node at the center
            for (size_t i = 0; i < nodeTags[1].size(); i++)
                _glob_connec[i] = corr[nodeTags[1][i] - 1] - 1;


            // Creases
            _glob_creases.resize(_nPts * 2, 0);
            for (int i = 0; i < _nPts; i++)
                _glob_creases[2 * i + 1] = -1;

            // Element flags
            _glob_eflags.resize(_nElem * _nEFlags, 0);

            //Finalize
            gmsh::finalize();
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nDim, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        // Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }

    void UnstructGmshMeshGenerator::genFreeMesh(std::function<void(void)> myMesh)
    {
        // Checks
        _performChecks();

        // Initialize
        _pDim = computePDim(_eType);
        _nVert = computeNVert(_bfType, _eType, _bfOrder);

        if (myRank() == 0)
        {
            // Initialize
            gmsh::initialize();
            gmsh::option::setNumber("General.Terminal", 1);
            gmsh::model::add("t1");
            gmsh::option::setNumber("General.Verbosity", 2); // Only warnings

            // Generate geometry (defined by the user externally)
            myMesh();

            // Generate mesh
            factory::synchronize();
            gmsh::model::mesh::generate(_pDim);

            // Elevate order
            if (_bfOrder > 1)
                gmsh::model::mesh::setOrder(_bfOrder);

            // Extract mesh info to hplfe
            _gmsh2hl();

            // Finalize
            gmsh::finalize();

        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nDim, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        // Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts, 1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }


    // Auxiliary functions
    vector<int> UnstructGmshMeshGenerator::_create_mapping(int _bfOrder)
    {

        int nne = ((_bfOrder + 1) * (_bfOrder + 2)) / 2;



        std::vector<int> mapping(nne);



        int i = 0;
        int la = _bfOrder - 1;


        int v1 = 0;
        int v2 = nne - _bfOrder - 1;
        int v3 = nne - 1;

        int st = 4;

        int ra0 = 1;
        int ra1 = _bfOrder + 1;


        while (i < nne)
        {
            mapping[v1] = i++;

            if (v2!=v1)
            mapping[v2] = i++;

            if (v3!=v1)
                mapping[v3] = i++;

            if (la > 0)
            {

                int ra = ra0;
                for (int j = v1 + ra0; j < v2; j = j + ra)
                {
                    mapping[j] = i++;
                    ra = ra + 1;
                }


                for (int j = v2 + 1; j < v3; j++)
                    mapping[j] = i++;



                ra = ra1;
                for (int j = v3 - ra1; j > v1; j = j - ra)
                {
                    mapping[j] = i++;
                    ra = ra - 1;
                }

            }



            v1 = v1 + st;
            v2 = v2 - la;
            v3 = v3 - la - 3;


            st = st + 4;

            la = la - 1;

            ra0 = ra0 + 2;

            ra1 = ra1 - 1;


        }


        std::vector<int> mcorr;


        mcorr.resize(nne);



        int jin = nne - _bfOrder - 1;
        int jfin = nne - 1;
        int imc = 0;


        for (int k = 0; k < _bfOrder + 1; k++)
        {

            for (int j = jin; j <= jfin; j++)
                mcorr[imc++] = mapping[j];

            jfin = jin - 1;
            jin = jin - (_bfOrder - k);

        }


        for (int k = 0; k < nne; k++)
            mapping[k] = mcorr[k];


        return mapping;

    }

    void UnstructGmshMeshGenerator::_gmsh2hl()
    {
        // Get elements and connectivity in gmsh node tags (tags may not go from 1 to nPts)
        std::vector<int> elementTypes;
        std::vector<std::vector<size_t>> elementTags;
        std::vector<std::vector<size_t>> connec;
        gmsh::model::mesh::getElements(elementTypes, elementTags, connec, _pDim, -1);

        // Get node tags (tags may not go from 1 to nPts)
        std::vector<size_t> nodeTags;
        std::vector<double> coord;
        std::vector<double> parametricCoord;
        gmsh::model::mesh::getNodes(nodeTags, coord, parametricCoord, _pDim, -1, true);

        // Get quantities
        _nElem = elementTags[0].size();
        _nPts  = nodeTags.size();

        // Create map from note tags to nodes
        std::map<int,int> tagToNode;
        for (int i = 0; i < _nPts; i++)
            tagToNode.emplace(nodeTags[i],i);

        // Coordinates
        _glob_x_nodes.resize(_nPts*_nDim);
        for (int i = 0; i < _nPts; i++)
        {
            for (int d = 0; d < _nDim; d++)
                _glob_x_nodes[i*_nDim + d] = coord[3*i + d];
        }

        // Connec
        _glob_connec.resize(_nElem*_nVert);
        for (int i = 0; i < _nElem*_nVert; i++)
            _glob_connec[i] = tagToNode[connec[0][i]];


        // Get node tags of the edges
        vector<int> edgeNodeTags;
        {
            std::vector<size_t> nodeTags;
            std::vector<double> coord;
            std::vector<double> parametricCoord;
            gmsh::model::mesh::getNodes(nodeTags, coord, parametricCoord, _pDim-1, -1, true);

            // Create edge node tags
            edgeNodeTags.resize(nodeTags.size(), -1);
            for (size_t i = 0; i < nodeTags.size(); i++)
                if (tagToNode.find(nodeTags[i]) != tagToNode.end())
                    edgeNodeTags[i] = tagToNode.at(nodeTags[i]);
        }

        // Get node tags of the corners
        vector<int> cornerNodeTags;
        {
            std::vector<size_t> nodeTags;
            std::vector<double> coord;
            std::vector<double> parametricCoord;
            gmsh::model::mesh::getNodes(nodeTags, coord, parametricCoord, _pDim-2, -1, true);

            // Create corner node tags
            cornerNodeTags.resize(nodeTags.size(), -1);
            for (size_t i = 0; i < nodeTags.size(); i++)
                if (tagToNode.find(nodeTags[i]) != tagToNode.end())
                    cornerNodeTags[i] = tagToNode.at(nodeTags[i]);
        }

        // Creases: Edges = 1; Corners = 2; Faces = 3
        _glob_creases.resize(_nPts*_nCreases, 0);
        for (int i = 0; i < _nPts; i++)
        {
            if (std::find(edgeNodeTags.cbegin(), edgeNodeTags.cend(), i) != edgeNodeTags.cend())
                _glob_creases[_nCreases*i+0] = 1;
            if (std::find(cornerNodeTags.cbegin(), cornerNodeTags.cend(), i) != cornerNodeTags.cend())
                _glob_creases[_nCreases*i+0] = 2;
            _glob_creases[_nCreases*i+1] = -1;
        }

        // Element flags
        _glob_eflags.resize(_nElem*2, 0);
    }

    void UnstructGmshMeshGenerator::_printMesh(const std::string& mssg)
    {
        if (_myRank == 0)
        {
            cout << endl << mssg << endl;
            cout << " bf: " << str(_bfType) << endl;
            cout << " eType: " << str(_eType) << endl;

            cout << " nPts: " << _nPts << " " << _loc_nPts << endl;
            cout << " nEle: " << _nElem << " " << _loc_nElem << " ("<< _nEx << ", " <<  _nEy << ", " <<  _nEz << ")" << endl;
            cout << " Ord:  "<< _bfOrder << " ("<< _bfOrderX << ", " << _bfOrderY << ", " << _bfOrderZ << ")" << endl;

            cout << " xnodes:" << endl;
            for (int i = 0; i < _nPts; i++)
            {
                cout << "   " << i << " - ";
                for (int j = 0; j < _nDim; j++)
                    cout << _glob_x_nodes[_nDim * i + j] << " ";
                cout << endl;
            }

            cout << " connec:" << endl;
            for (int i = 0; i < _nElem; i++)
            {
                cout << "   "  << i << " - ";
                for (int j = 0; j < _nVert; j++)
                    cout << _glob_connec[_nVert * i + j] << " ";
                cout << endl;
            }

            cout << " creases:" << endl;
            for (int i = 0; i < _nPts; i++)
            {
                cout << "   " << i << " - ";
                for (int j = 0; j < _nCreases; j++)
                    cout << _glob_creases[_nCreases * i + j] << " ";
                cout << endl;
            }

        }
    }
}
