/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MESHCREATOR_H
#define MESHCREATOR_H


#include <vector>
#include <functional>
#include <deque>

#include "hl_DistributedClass.h"
#include "hl_DistributedData.h"
#include "hl_TypeDefs.h"


namespace hiperlife
{
    struct linearConstraint
    {
        int slave;
        std::vector<int> masters;
        std::vector<double> weights;
        double value;
    };

    class MeshCreator : public DistributedClass
    {

        public:
            MeshCreator(std::string tag = "MeshCreator", MPI_Comm comm = MPI_COMM_WORLD) : DistributedClass(tag, comm){};
            MeshCreator() = default;
            MeshCreator(MeshCreator &&other) = default;
            virtual ~MeshCreator() = default;
            MeshCreator& operator=(MeshCreator&& other) = default;

            MeshCreator& operator=(const MeshCreator& other) = delete;
            MeshCreator(const MeshCreator& other) = delete;


            /** @name Object creation management
             *   Main functions to set the dimensions, the element and basis function type, and the order.
             *  @{*/
            /*! \brief Sets the number of physical dimensions. Currently it should be 3.*/
            void setNDim(int nDim){_nDim = nDim;};
            /*! \brief Sets the element type.*/
            void setElemType(ElemType eType){_eType = eType;}
            /*! \brief Sets the basis function type.*/
            void setBasisFuncType(BasisFuncType bfType){_bfType = bfType;}
            /*! \brief Sets the basis function order.*/
            void setBasisFuncOrder(int bfOrder){_bfOrder = bfOrder;}
            /*! \brief Sets the basis function order for x direction.*/
            void setBasisFuncOrderDir(int bfOrderX){_bfOrderX = bfOrderX;}
            /*! \brief Sets the basis function order for x and y directions.*/
            void setBasisFuncOrderDir(int bfOrderX, int bfOrderY){_bfOrderX = bfOrderX; _bfOrderY = bfOrderY;}
            /*! \brief Sets the basis function order for x, y, and z directions.*/
            void setBasisFuncOrderDir(int bfOrderX, int bfOrderY, int bfOrderZ){_bfOrderX = bfOrderX; _bfOrderY = bfOrderY; _bfOrderZ = bfOrderZ;}
            /*! \brief Sets the basis function order per directions.*/
            void setBasisFuncOrderDir(std::vector<int> bfOrder)
            {
                if (bfOrder.size() == 1)
                {
                    _bfOrder = bfOrder[0];
                }
                else if (bfOrder.size() == 2)
                {
                    if (bfOrder[0] == bfOrder[1])
                    {
                        _bfOrder = bfOrder[0];
                    }
                    else
                    {
                        _bfOrderX = bfOrder[0];
                        _bfOrderY = bfOrder[1];
                    }
                }
                else if (bfOrder.size() == 3)
                {
                    if ((bfOrder[0] == bfOrder[1]) && (bfOrder[1] == bfOrder[2]))
                    {
                        _bfOrder = bfOrder[0];
                    }
                    else
                    {
                        _bfOrderX = bfOrder[0];
                        _bfOrderY = bfOrder[1];
                        _bfOrderZ = bfOrder[2];
                    }
                }
                else
                {
                    throw std::runtime_error("MeshCreator::setBasisFuncOrderDir: Incorrect number of components in the vector of basis function order.");
                }
            }
            /*! \brief Sets element type, basis function type and order.*/
            void setMesh(ElemType eType, BasisFuncType bfType, int bfOrder){_eType = eType; _bfType = bfType; _bfOrder = bfOrder;}
            /*! \brief Sets element type, basis function type and order per direction in x and y.*/
            void setMesh(ElemType eType, BasisFuncType bfType, int bfOrderX, int bfOrderY){_eType = eType; _bfType = bfType; _bfOrderX = bfOrderX; _bfOrderY = bfOrderY;}
            /*! \brief Sets element type, basis function type and order per direction in x, y and z.*/
            void setMesh(ElemType eType, BasisFuncType bfType, int bfOrderX, int bfOrderY, int bfOrderZ){_eType = eType; _bfType = bfType; _bfOrderX = bfOrderX; _bfOrderY = bfOrderY; _bfOrderZ = bfOrderZ;}
            /*! \brief Sets element type, basis function type and order per direction in x, y and z.*/
            void setMesh(ElemType eType, BasisFuncType bfType, std::vector<int> bfOrder){_eType = eType; _bfType = bfType; setBasisFuncOrderDir(bfOrder);}
            /** @} */ // end of object creation management

            /** @name Affine transformations
             *    Translate, rotate, scale and shear a mesh for any type of basis function.
             *  @{ */
            //Translate
            /*! \brief Translate mesh in x direction by an increment (incrX).*/
            inline void translateX(double incrX){translate(incrX, 0.0, 0.0);};
            /*! \brief Translate mesh in y direction by an increment (incrY).*/
            inline void translateY(double incrY){translate(0.0, incrY, 0.0);};
            /*! \brief Translate mesh in z direction by an increment (incrZ).*/
            inline void translateZ(double incrZ){translate(0.0, 0.0, incrZ);};
            /*! \brief Translate mesh in x and y directions by an increment per direction (incrX and incrY, respectively).*/
            inline void translateXY(double incrX, double incrY){translate(incrX, incrY, 0.0);};
            /*! \brief Translate mesh in every direction by an increment (incr).*/
            inline void translate(double incr)
            {
                if (_pDim == 1)
                    translate(incr, 0.0, 0.0);
                else if (_pDim == 2)
                    translate(incr, incr, 0.0);
                else
                    translate(incr, incr, incr);
            };
            /*! \brief Translate mesh in x, y and z directions by an increment per direction (incrX, incrY and incrZ, respectively).*/
            inline void translate(double incrX, double incrY, double incrZ){_translate(incrX, incrY, incrZ);};

            //Scale
            /*! \brief Scale mesh in x direction by a factor (factorX).*/
            inline void scaleX(double factorX){_scale(factorX, 1.0, 1.0);};
            /*! \brief Scale mesh in y direction by a factor (factorY).*/
            inline void scaleY(double factorY){_scale(1.0, factorY, 1.0);};
            /*! \brief Scale mesh in z direction by a factor (factorZ).*/
            inline void scaleZ(double factorZ){_scale(1.0, 1.0, factorZ);};
            /*! \brief Scale mesh in x and y directions by a factor per direction (factorX and factorY, respectively).*/
            inline void scaleXY(double factorX, double factorY){_scale(factorX, factorY, 1.0);};
            /*! \brief Scale mesh in every direction by a factor (factor).*/
            inline void scale(double factor){scale(factor, factor, factor);};
            /*! \brief Scale mesh in x, y and z directions by a factor per direction (factorX, factorY and factorZ, respectively).*/
            inline void scale(double factorX, double factorY, double factorZ){_scale(factorX, factorY, factorZ);};

            //Rotate
            /*! \brief Rotate a two-dimensional mesh by a given angle (phi) and w.r.t. a given center of rotation (center).*/
            inline void rotate2D(double phi, std::vector<double> center = {0, 0, 0}){rotateZ(phi, center);};
            /*! \brief Rotate mesh around x-axis by a given angle (phiX) and w.r.t. a given center of rotation (center).*/
            void rotateX(double phiX, std::vector<double> center = {0, 0, 0});
            /*! \brief Rotate mesh around y-axis by a given angle (phiY) and w.r.t. a given center of rotation (center).*/
            void rotateY(double phiY, std::vector<double> center = {0, 0, 0});
            /*! \brief Rotate mesh around z-axis by a given angle (phiZ) and w.r.t. a given center of rotation (center).*/
            void rotateZ(double phiZ, std::vector<double> center = {0, 0, 0});
            /*! \brief Rotate mesh a given angle (phi) around an axis given by vector \a u.*/
            void rotateAngleVector(double phi, std::vector<double> u);

            //Shear
            /*! \brief Shear mesh in x direction by a factor (factorX).*/
            inline void shearX(double factorX){shearXY(factorX, 0.0);};
            /*! \brief Shear mesh in y direction by a factor (factorY).*/
            inline void shearY(double factorY){shearXY(0.0, factorY);};
            /*! \brief Shear mesh in x and y directions by a factor per direction (factorX and factorY, respectively).*/
            void shearXY(double factorX, double factorY);
            /** @} */ // end of affine transformations


            /** @name Free transformations
             *    Functions to freely transform a mesh
             *  @{ */
            /*! \brief Transform mesh in x direction following a function (fx).*/
            void transformFree(std::function<double(double)> fx);
            /*! \brief Transform mesh in x and y directions following a function (fxy).*/
            void transformFree(std::function<std::tuple<double, double>(double, double)> fxy);
            /*! \brief Transform mesh in x, y and z directions following a function (fxyz).*/
            void transformFree(std::function<std::tuple<double, double, double>(double, double, double)> fxyz);
            /** @} */ // end of free transformations


            //Main variables
            DistributedData _disPts{"DistributedData", _comm};
            DistributedData _disElem{"DistributedData", _comm};
            int _nVert{};
            int _pDim{};
            int _nCreases = 2;
            int _nEFlags = 1;

            int _nDim{3};
            int _bfOrder{-1};
            int _bfOrderX{-1}, _bfOrderY{-1}, _bfOrderZ{-1};
            int _bfOrderX_min{-1}, _bfOrderY_min{-1}, _bfOrderZ_min{-1};
            bool _isBfOrderSubSet{false};
            bool _isBfOrderSubSet_tmp{false};

            ElemType _eType{ElemType::Undefined};
            BasisFuncType _bfType{BasisFuncType::Undefined};
            MeshType _meshType{MeshType::Undefined};

            std::vector<double> _x_nodes;
            std::vector<double> _weights;
            std::vector<std::vector<std::vector<std::vector<double>>>> _CP;
            std::vector<double> _uKnot;
            std::vector<double> _vKnot;
            std::vector<double> _wKnot;
            std::vector<int> _connec;
            std::vector<int> _creases;
            std::vector<int> _eflags;
            std::vector<int> _elMap_newToOld;

            std::vector<double> _glob_x_nodes;
            std::vector<int> _glob_connec;
            std::vector<int> _glob_creases;
            std::vector<int> _glob_eflags;


            int _nPts{};
            int _nElem{};
            int _loc_nPts{};
            int _loc_nElem{};

            int _nEx = -1;
            int _nEy = -1;
            int _nEz = -1;

            bool _hRefinedMesh = false;
            bool _pRefinedMesh = false;

            bool _unclampedX{false};
            bool _unclampedY{false};
            bool _unclampedZ{false};

            std::deque<std::function<void()>> _history;
            std::vector<std::string> _history_names;

            bool _periodicInX{false};
            bool _periodicInY{false};
            bool _periodicInZ{false};
            std::vector<linearConstraint> _linearConstraints;

        protected:

            //Interface functions //FIXME: Add comments
            void _checkMesh();
            virtual void _saveMesh() = 0;
            virtual void _reloadMesh() = 0;

            virtual void _getPRefinedMesh(int orderInc) = 0;
            virtual void _getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ) = 0;
            virtual void _getHRefinedMesh(int refLevel) = 0;
            virtual void _getBoundaryMesh(std::vector<MAxis> vMAx) = 0;

            /** @name Expert users and developers only
             *  @{ */
            //Auxiliary functions
            void _performOrderChecks();
            bool _isMeshGenerated();
            void _checkFileExists(const std::string& fname);
            std::string _getFileExtension(const std::string& fname);
            // map(slave, master) in Indextype::Global
            void _removeRepeatedNodes(std::map<int,int> removeMap);
            // Create node ghosts
            std::vector<int> _createNodeGhosts();
            /** @} */ // end of expert


            //Friends
            friend class DistributedMesh;
            friend class MultiPatchMeshGenerator;


        private:

            //Transformations
            void _translate(double incrX, double incrY, double incrZ);
            void _scale(double factorX, double factorY, double factorZ);
            void _transformFree(std::function<std::tuple<double, double, double>(double, double, double)> fxyz);

    };

}

#endif // MESHCREATOR_H
