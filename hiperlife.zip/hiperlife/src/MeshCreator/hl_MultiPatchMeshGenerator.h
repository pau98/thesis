/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MULTIPATCH_H
#define MULTIPATCH_H

#include "hl_DistributedData.h"
#include "hl_MeshCreator.h"
#include "hl_TypeDefs.h"


namespace hiperlife
{
    //FIXME: Document the class
    /*!
     * \class MultiPatchMeshGenerator
     * \brief Class to create multipatch meshes
     *
     *
     */

    class MultiPatchMeshGenerator : public MeshCreator
    {
        public:

            /** @name Constructor / Destructor / Operator
             *   Copy constructors are deleted for memory safety but objects can be created from
             *   temporal objects throught move constructors
             *  @{ */
            MultiPatchMeshGenerator(std::string tag = "MultiPatchMeshGenerator", MPI_Comm comm = MPI_COMM_WORLD) : MeshCreator(tag, comm){};
            MultiPatchMeshGenerator(MultiPatchMeshGenerator&& other) = default;
            MultiPatchMeshGenerator(const MultiPatchMeshGenerator& other) = delete;
            ~MultiPatchMeshGenerator() = default;
            MultiPatchMeshGenerator& operator=(const MultiPatchMeshGenerator& other) = delete;
            MultiPatchMeshGenerator& operator=(MultiPatchMeshGenerator&& other) = default;
            /** @} */ // end of constructors


            // Setters
            /*! \brief Sets the multipatch mesh from a vector of mesh creators.
              * \param meshCreators Vector of mesh creators
              */
            void setMeshes(std::vector<Teuchos::RCP<MeshCreator>> meshCreators, MultiPatchConnectivity mpConn, std::vector<std::vector<int>> map);
            void setMeshes(std::vector<Teuchos::RCP<MeshCreator>> meshCreators, MultiPatchConnectivity mpConn, double tolerance = -1.0);


            // Update
            void Update();


            // Auxiliary functions
            void printMesh(const std::string& mssg){_printMesh(mssg);};

            // Expert users

        private:

            // Main variables
            std::vector<Teuchos::RCP<MeshCreator>> _mCreators;
            double _tolerance{-1.0};
            std::vector<std::vector<int>> _mul_map;  //master, slave (in part)
            bool _createMapping{false};
            MultiPatchConnectivity _mpConn{MultiPatchConnectivity::Undefined};

            // Main functions
            void _shareBoundaryNodes(std::vector<int>& glob_bNodes, std::vector<double>& glob_bCoords, std::vector<int>& glob_slaves);
            void _appendSequentialMeshes();
            void _appendParallelMeshes();
            void _appendMeshes();
            void _createLinearConstraints();
            void _unclampSequentialMeshes();
            void _unclampParallelMeshes();
            void _unclampMeshes();

            // Interface functions
            void _saveMesh() override;
            void _reloadMesh() override;

            void _getPRefinedMesh(int orderInc) override;
            void _getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ) override;
            void _getHRefinedMesh(int refLevel) override;
            void _getBoundaryMesh(std::vector<MAxis> vMAx) override;

            // Checks
            void _performChecks(int nEx, int nEy, int nEz);
            void _performSettingChecks();
            void _performElementChecks(int nEx, int nEy, int nEz);

            // Auxiliary functions
            void _printMesh(const std::string& mssg);

    };

}
#endif
