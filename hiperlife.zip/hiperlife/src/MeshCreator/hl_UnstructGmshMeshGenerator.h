/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francesco Greco
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef UNSTRUCTGMSHMESHGENERATOR_H
#define UNSTRUCTGMSHMESHGENERATOR_H




#include <vector>
#include <functional>
#include <deque>


#include "hl_DistributedData.h"
#include "hl_TypeDefs.h"

#include "hl_MeshCreator.h"


namespace hiperlife
{

    /*!
     * \class UnstructGmshMeshGenerator
     * \brief Class to generate unstructured meshes using Gmsh¹
     *
     * UnstructGmshMeshGenerator is a class that generates different types of unstructured meshes compatible with hiperlife.
     * It generates triangular meshes for finite elements and subdivision surfaces. This class is composed
     * by generators and transformations and should be used in that order: First generate a mesh, which can be a
     * predefined mesh (eg. square, circle spherical surface) or user-defined, and then apply the desired transformations.
     * [1] Geuzaine, Christophe, and Jean‐François Remacle. "Gmsh: A 3‐D finite element mesh generator with built‐in
     * pre‐and post‐processing facilities. "International journal for numerical methods in engineering 79.11 (2009): 1309-1331.
     */

    class UnstructGmshMeshGenerator : public MeshCreator
    {
        public:

            /** @name Constructor / Destructor / Operator
             *   Copy constructors are deleted for memory safety but objects can be created from
             *   temporal objects through move constructors
             *  @{ */
            UnstructGmshMeshGenerator(std::string tag = "UnstructGmshMeshGenerator", MPI_Comm comm = MPI_COMM_WORLD) : MeshCreator(tag, comm){_meshType= MeshType::Sequential;};
            UnstructGmshMeshGenerator(UnstructGmshMeshGenerator&& other) = default;
            UnstructGmshMeshGenerator(const UnstructGmshMeshGenerator& other) = delete;
            ~UnstructGmshMeshGenerator() = default;
            UnstructGmshMeshGenerator& operator=(const UnstructGmshMeshGenerator& other) = delete;
            UnstructGmshMeshGenerator& operator=(UnstructGmshMeshGenerator&& other) = default;
            /** @} */ // end of constructors


            /** @name Two-dimensional surface generators
             *   Functions to generate meshes embedded in a plane.
             *  @{*/
            /*! \brief Generate mesh enclosed by a polygon.
             * \param vx Vector of X coordinates of the vertices of the polygon.
             * \param vy Vector of Y coordinates of the vertices of the polygon.
             * \param h Element size.
             */
            inline void genPoly(std::vector<double> vx, std::vector<double> vy, double h){_genPoly(vx, vy, h);};
            /*! \brief Generate mesh enclosed by a polygon.
             * \param fname File name where the coordinates of the vertices of the polygon are defined (in comma separeted value format).
             * \param h Element size.
             */
            void genPoly(std::string fname, double h);
            /*! \brief Generate mesh enclosed by a regular polygon inscribed in a circle.
             * \param nv Number of vertices of the polygon
             * \param radius Radius of the circle
             * \param h Element size.
             */
            void genRegularPoly(int nv, double radius, double h);
            /*! \brief Generate mesh enclosed by a polygon with a polygonal hole.
             * \param vxOut Vector of X coordinates of the vertices of the outer polygon.
             * \param vyOut Vector of Y coordinates of the vertices of the outer polygon.
             * \param vxIn Vector of X coordinates of the vertices of the inner polygon.
             * \param vyIn Vector of Y coordinates of the vertices of the inner polygon.
             * \param h Element size.
             */
            void genPolyHole(std::vector<double> xOut, std::vector<double> yOut, std::vector<double> xIn, std::vector<double> yIn, double lcOut, double lcIn);
            /*! \brief Generate a square.
             * \param side Side of the square.
             * \param h Element size.
             */
            inline void genSquare(double side, double h){genRectangle(side, side, h);};
            /*! \brief Generate a rectangle.
             * \param sideX Side length in x-direction.
             * \param sideY Side length in y-direction.
             * \param h Element size.
             */
            void genRectangle(double sideX, double sidY, double h);
            /*! \brief Generate a circle.
             * \param radius Radius of the circle
             * \param h Element size.
             */
            void genCircle(double radius, double h);
            /*! \brief Generate mesh enclosed by a cubic BSpline.
             * \param Cx Vector of X coordinates of the control points of the BSpline.
             * \param Cy Vector of Y coordinates of the control points of the BSpline.
             * \param h Element size.
             */
            void genBSpline(std::vector<double> Cx, std::vector<double> Cy, double h);
            /*! \brief Generate mesh enclosed by a cubic BSpline.
             * \param fname File name where the coordinates of the control points of the BSpline are defined (in comma separeted value format).
             * \param h Element size.
             */
            void genBSpline(std::string fname, double h);
            /** @} */ // end of 2D surf generators


            /** @name Three-dimensional surface generators
             *   Functions to generate three-dimensional surface meshes.
             *  @{*/
            /*! \brief Generate a sphere using triangular patches
             * \param radius Radius of the sphere
             * \param h Element size.
             */
            void genSphereTri(double radius, double h);
            /*! \brief Generate a sphere using rectangular patches
             * \param radius Radius of the sphere
             * \param h Element size.
             */
            void genSphereQua(double radius, double h);
            /** @} */ // end of 3D surf generators


            /** @name User defined generator
             *  @{*/
            /*! \brief Method that the user can customize and call externally using the gmsh paradigm.
             *
             *  \param myMesh Function or lmabda function used to define the geometry
             */
            void genFreeMesh(std::function<void(void)> myMesh);
            /** @} */ // end of user defined generator


            // Auxiliary functions
            void _printMesh(const std::string& mssg);

            // Transformation
            void hRefine(int refLevel){_getHRefinedMesh(refLevel);};
            void uniformlyRefine(int refLevel){_getHRefinedMesh(refLevel);};

        private:

            // Interface functions
            void _saveMesh() override;
            void _reloadMesh() override;
            void _getPRefinedMesh(int orderInc) override;
            void _getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ) override;
            void _getHRefinedMesh(int refLevel) override;
            void _getBoundaryMesh(std::vector<MAxis> vMAx) override;

            // Check functions
            void _performSettingChecks();
            void _performChecks();

            // Generators
            void _genPoly(std::vector<double> vx, std::vector<double> vy, double h);

            // Auxiliary functions
            // Read points in file
            void _read2DPointsFromCSV(std::string fname, std::vector<double> &x, std::vector<double> &y);

            // Function needed to change the connectivity from Gmsh to hplfe
            std::vector<int> _create_mapping(int _bfOrder);

            // Function to extrat the mesh information from Gmsh to hiperlife
            void _gmsh2hl();

    };
}
#endif
