/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <vector>
#include <functional>
#include <deque>

#include "hl_Math.h"
#include "hl_TypeDefs.h"
#include "hl_MeshCreator.h"
using std::cout;
using std::endl;
using std::vector;
using std::runtime_error;

namespace hiperlife
{
    //Free transform
    void MeshCreator::_transformFree(std::function<std::tuple<double, double, double>(double, double, double)> fxyz)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("MeshCreator: Cannot perform transformation before generating the mesh.");

        //Transform nodes
        if (nameTag() == "StructMeshGenerator")
        {
            for (int n = 0; n < _loc_nPts; n++)
            {
                double x = _x_nodes[_loc_nPts * 0 + n];
                double y = _x_nodes[_loc_nPts * 1 + n];
                double z = _x_nodes[_loc_nPts * 2 + n];
                auto myfunc = fxyz(x, y, z);
                _x_nodes[_loc_nPts * 0 + n] = std::get<0>(myfunc);
                _x_nodes[_loc_nPts * 1 + n] = std::get<1>(myfunc);
                _x_nodes[_loc_nPts * 2 + n] = std::get<2>(myfunc);
            }
        }
        else
        {
            if (myRank() == 0)
            {
                for (int n = 0; n < _nPts; n++)
                {
                    double x = _glob_x_nodes[_nDim * n + 0];
                    double y = _glob_x_nodes[_nDim * n + 1];
                    double z = _glob_x_nodes[_nDim * n + 2];
                    auto myfunc = fxyz(x, y, z);
                    _glob_x_nodes[_nDim * n + 0] = std::get<0>(myfunc);
                    _glob_x_nodes[_nDim * n + 1] = std::get<1>(myfunc);
                    _glob_x_nodes[_nDim * n + 2] = std::get<2>(myfunc);
                }
            }
        }

        //Transform control points
        if ((_bfType == BasisFuncType::BSplines) or (_bfType == BasisFuncType::Nurbs))
        {
            //Number of basis functions/control points
            int nnx{1}, nny{1}, nnz{1};
            if (_nEx > 0)
                nnx = _nEx + _bfOrderX;
            if (_nEy > 0)
                nny = _nEy + _bfOrderY;
            if (_nEz > 0)
                nnz = _nEz + _bfOrderZ;

            //Transform control points
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        double x = _CP[i][j][k][0];
                        double y = _CP[i][j][k][1];
                        double z = _CP[i][j][k][2];
                        auto myfunc = fxyz(x, y, z);
                        _CP[i][j][k][0] = std::get<0>(myfunc);
                        _CP[i][j][k][1] = std::get<1>(myfunc);
                        _CP[i][j][k][2] = std::get<2>(myfunc);
                    }
                }
            }

        }

        //Save history
        _history.emplace_back([=](){_transformFree(fxyz);});
        _history_names.push_back(__FUNCTION__);
    }

    void MeshCreator::transformFree(std::function<double(double)> fx)
    {
        //Check
        if (_nEx == -1)
            throw runtime_error("MeshCreator: transformFree: The number of elements per direction was not set.");

        //Create transform function
        auto fxyz = ([fx](double x, double y, double z){
                return std::make_tuple(fx(x), y, z);
                });

        //Transform
        _transformFree(fxyz);
    }

    void MeshCreator::transformFree(std::function<std::tuple<double, double>(double, double)> fxy)
    {
        //Check
        // if (_nEx == -1 || _nEy == -1)
        //     throw runtime_error("MeshCreator: _genStructMeshFree: The number of elements per direction was not set.");

        //Create transform function
        auto fxyz = ([fxy](double x, double y, double z){
                auto myfunc = fxy(x, y);
                return std::make_tuple(std::get<0>(myfunc), std::get<1>(myfunc), z);
                });

        //Transform
        _transformFree(fxyz);
    }

    void MeshCreator::transformFree(std::function<std::tuple<double, double, double>(double, double, double)> fxyz)
    {
        //Check
        // if (_nEx == -1 || _nEy == -1 || _nEz == -1)
        //     throw runtime_error("MeshCreator: _genStructMeshFree: The number of elements per direction was not set.");

        //Transform
        _transformFree(fxyz);
    }


    //Affine transformations
    void MeshCreator::_translate(double incrX, double incrY, double incrZ)
    {
        //Create transform function
        auto fxyz = ([incrX, incrY, incrZ](double x, double y, double z){
                return std::make_tuple(x+incrX, y+incrY, z+incrZ);
                });

        //Transform
        _transformFree(fxyz);
    }

    void MeshCreator::_scale(double factorX, double factorY, double factorZ)
    {
        //Create transform function
        auto fxyz = ([factorX, factorY, factorZ](double x, double y, double z){
                return std::make_tuple(x*factorX, y*factorY, z*factorZ);
                });

        //Transform
        _transformFree(fxyz);
    }

    void MeshCreator::rotateX(double phiX, vector<double> c)
    {
        //Translate to center of rotation
        if (c[0] != 0.0 && c[1] != 0.0 && c[2] != 0.0)
            _translate(-c[0], -c[1], -c[2]);

        //Create transform function
        auto fxyz = ([phiX](double x, double y, double z){
                double x1 = x;
                double y1 = y*cos(phiX) - z*sin(phiX);
                double z1 = y*sin(phiX) + z*cos(phiX);
                return std::make_tuple(x1, y1, z1);
                ;});

        //Transform
        _transformFree(fxyz);

        //Translate back
        if (c[0] != 0.0 && c[1] != 0.0 && c[2] != 0.0)
            _translate(c[0], c[1], c[2]);
    }

    void MeshCreator::rotateY(double phiY, vector<double> c)
    {
        //Translate to center of rotation
        if (c[0] != 0.0 && c[1] != 0.0 && c[2] != 0.0)
            _translate(-c[0], -c[1], -c[2]);

        //Create transform function
        auto fxyz = ([phiY](double x, double y, double z){
                double x1 = x*cos(phiY) + z*sin(phiY);
                double y1 = y;
                double z1 = - x*sin(phiY) + z*cos(phiY);
                return std::make_tuple(x1, y1, z1);
                ;});

        //Transform
        _transformFree(fxyz);

        //Translate back
        if (c[0] != 0.0 && c[1] != 0.0 && c[2] != 0.0)
            _translate(c[0], c[1], c[2]);

    }

    void MeshCreator::rotateZ(double phiZ, vector<double> c)
    {
        //Translate to center of rotation
        if (c[0] != 0.0 && c[1] != 0.0 && c[2] != 0.0)
            _translate(-c[0], -c[1], -c[2]);

        //Create transform function
        auto fxyz = ([phiZ](double x, double y, double z){
                double x1 = x*cos(phiZ) - y*sin(phiZ);
                double y1 = x*sin(phiZ) + y*cos(phiZ);
                double z1 = z;
                return std::make_tuple(x1, y1, z1);
                ;});

        //Transform
        _transformFree(fxyz);

        //Translate back
        if (c[0] != 0.0 && c[1] != 0.0 && c[2] != 0.0)
            _translate(c[0], c[1], c[2]);
    }

    void MeshCreator::rotateAngleVector(double phi, std::vector<double> u)
    {
        //Check
        if (u.size() < 2)
            throw runtime_error("MeshCreator: rotateAngleVector: The vector has to be either two- or three-dimensional.");

        //Make unitary vector
        double ux{}, uy{}, uz{};
        ux = u[0]/Math::Norm3D(u.data());
        uy = u[1]/Math::Norm3D(u.data());
        if (u.size() == 3)
            uz = u[2]/Math::Norm3D(u.data());
        else
            uz = 0.0;

        //Create transform function
        auto fxyz = ([ux, uy, uz, phi](double x, double y, double z){
                double x1 =
                x*(cos(phi) + ux*ux*(1.0-cos(phi))) +
                y*(ux*uy*(1.0-cos(phi)) - uz*sin(phi)) +
                z*(ux*uz*(1.0-cos(phi)) + uy*sin(phi));
                double y1 =
                x*(uy*ux*(1.0-cos(phi)) + uz*sin(phi)) +
                y*(cos(phi) + uy*uy*(1.0-cos(phi))) +
                z*(uy*uz*(1.0-cos(phi)) - ux*sin(phi));
                double z1 =
                x*(uz*ux*(1.0-cos(phi)) - uy*sin(phi)) +
                y*(uz*uy*(1.0-cos(phi)) + ux*sin(phi)) +
                z*(cos(phi) + uz*uz*(1.0-cos(phi)));

                return std::make_tuple(x1, y1, z1);
                ;});

        //Transform
        _transformFree(fxyz);
    }

    void MeshCreator::shearXY(double factorX, double factorY)
    {
        //Create transform function
        auto fxyz = ([factorX, factorY](double x, double y, double z){
                return std::make_tuple(x + y*factorX, y + x*factorY, z);
                });

        //Transform
        _transformFree(fxyz);
    }

}
