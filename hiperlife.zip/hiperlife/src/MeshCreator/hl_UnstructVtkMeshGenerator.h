/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef UNSTRUCTVTKMESHGENERATOR_H
#define UNSTRUCTVTKMESHGENERATOR_H

#include <vector>
#include <functional>
#include <deque>

#include "hl_DistributedData.h"
#include "hl_TypeDefs.h"

#include "hl_MeshCreator.h"
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>

namespace hiperlife
{

    /*!
     * \class UnstructVtkMeshGenerator
     * \brief Class to generate different types of structured meshes
     *
     * UnstructVtkMeshGenerator is a class that generates different types of structured meshes that are fully compatible with hiperlife.
     * It can generate meshes for finite elements, subdivision surfaces, BSplines and Nurbs. This class is composed
     * by generators and transformations and should be used in that order: First generate a mesh, which can be a
     * predefined mesh (eg. square, circle or torus) or user-defined, and then apply the desired transformations.
     *
     */

    class UnstructVtkMeshGenerator : public MeshCreator
    {
        public:

            /** @name Constructor / Destructor / Operator
             *   Copy constructors are deleted for memory safety but objects can be created from
             *   temporal objects through move constructors
             *  @{ */
            UnstructVtkMeshGenerator(std::string tag = "UnstructVtkMeshGenerator", MPI_Comm comm = MPI_COMM_WORLD) : MeshCreator(tag, comm){_meshType= MeshType::Sequential;};
            UnstructVtkMeshGenerator(UnstructVtkMeshGenerator&& other) = default;
            UnstructVtkMeshGenerator(const UnstructVtkMeshGenerator& other) = delete;
            ~UnstructVtkMeshGenerator() = default;
            UnstructVtkMeshGenerator& operator=(const UnstructVtkMeshGenerator& other) = delete;
            UnstructVtkMeshGenerator& operator=(UnstructVtkMeshGenerator&& other) = default;
            /** @} */ // end of constructors


            /** @name Generators for every basis function
             *   Functions to generate meshes valid for every basis function.
             *  @{*/
            /*! \brief Generate a structured unitary line, rectangle or cube with nEdir elements per direction.*/
            void genPlane(std::function<double(double[3])> h);

            void genSphere(std::function<double(double[3])> h, std::function<std::array<double,3>(double[3])> def = nullptr);
            void genTorus(std::function<double(double[3])> h);
            void genCylinder(double radius, double height, bool cap, std::function<double(double[3])> h, std::function<std::array<double,3>(double[3])> def = nullptr);
            void genPolygon(std::function<double(double[3])> h,std::function<std::array<double,3>(double[3])> def = nullptr);
            /** @} */ // end of generators

            static void _computeHRefinedMesh(int refLevel, int& nPts, int& nElem, int& nDim, int& nVert, int& nCreases,
                                                            int& nEFlags, std::vector<double>& glob_x_nodes, std::vector<int>& glob_connec,
                                                            std::vector<int>& glob_creases, std::vector<int>& glob_eflags,
                                                            vtkSmartPointer<vtkPolyData>& vtkoutput, MPI_Comm comm, int rank);

            /** @name Transformations
             *  @{ */
            /** @} */ // end of transformations

      protected:

            std::vector<double> _tmp_glob_x_nodes;
            std::vector<int> _tmp_glob_connec;
            std::vector<int> _tmp_glob_creases;
            std::vector<int> _tmp_glob_eflags;

            int _tmp_nPts;
            int _tmp_nElem;
            vtkSmartPointer<vtkPolyData> _tmp_vtkoutput;

            vtkSmartPointer<vtkPolyData> _vtkoutput;


        // Interface functions
            void _saveMesh() override;
            void _reloadMesh() override;
            void _getPRefinedMesh(int orderInc) override;
            void _getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ) override;
            void _getHRefinedMesh(int refLevel) override;
            void _getBoundaryMesh(std::vector<MAxis> vMAx) override;
    };

}
#endif
