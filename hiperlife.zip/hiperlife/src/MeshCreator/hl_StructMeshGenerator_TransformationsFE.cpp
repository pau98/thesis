/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <fstream>
#include <functional>
#include <deque>

#include <Teuchos_RCP.hpp>
#include <Epetra_LocalMap.h>

#include "hl_MpiHelpers.h"
#include "hl_Math.h"
#include "hl_Geometry.h"
#include "hl_TypeDefs.h"
#include "hl_Linear.h"
#include "hl_Lagrangian.h"
#include "hl_FieldStruct.h"

#include "hl_StructMeshGenerator.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{
    //Stretch
    void StructMeshGenerator::_stretchElems(std::function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz)
    {
        //Checks
        if ((_hRefinedMesh == true) and (_bfType != BasisFuncType::BSplines) and (_bfType != BasisFuncType::Nurbs))// FIXME
            throw runtime_error("StructMeshGenerator::stretchElems: h-refined meshes do not work with stretch transformations (yet) for linear, lagrangian and subdivision surfaces basis functions.");

        if ((_pRefinedMesh == true) and (_bfType != BasisFuncType::BSplines) and (_bfType != BasisFuncType::Nurbs))// FIXME
            cout << "Warning: StructMeshGenerator::stretchElems: p-refined meshes do not work with stretch transformations (yet) for linear, lagrangian and subdivision surfaces basis functions if they geometries are curved." << endl;

        int nx, ny, nz;
        int nnx, nny, nnz;
        double hx, hy, hz;
        double x0, x1, y0, y1, z0, z1;
        int n = 0;

        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                //Number of corner nodes
                nx = _nEx + 1;

                //Spacing of nodes
                hx = 1.0 / _nEx;

                //Number of nodes
                nnx = (_bfOrder*nx-(_bfOrder-1));

                //Modify nodes
                for (int ii = 0; ii < nnx; ii++)
                {
                    int i = (int)(ii/_bfOrder);
                    x0 = hx*i;
                    x1 = hx*(i+1);
                    if (fx != nullptr)
                    {
                        x0 = fx(x0);
                        x1 = fx(x1);
                    }
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);

                        if (ii % _bfOrder == 0)
                        {
                            //Corner nodes
                            double x = _x_nodes[_loc_nPts * 0 + locN];
                            if (fx != nullptr)
                                _x_nodes[_loc_nPts * 0 + locN] = fx(x);
                        }
                        else
                        {
                            //Intra-element nodes
                            if (fx != nullptr)
                            {
                                double hhx = (x1-x0)/_bfOrder;
                                _x_nodes[_loc_nPts * 0 + locN] = x0 + hhx*(ii % _bfOrder);
                            }
                        }

                    }
                    n++;
                }

                break;
            case static_cast<int>(ElemType::Triang):
            case static_cast<int>(ElemType::Square):
                //Number of corner nodes
                nx = _nEx + 1;
                ny = _nEy + 1;

                //Spacing of nodes
                hx = 1.0 / _nEx;
                hy = 1.0 / _nEy;

                //Number of nodes
                nnx = (_bfOrder*nx-(_bfOrder-1));
                nny = (_bfOrder*ny-(_bfOrder-1));

                //Modify nodes
                for (int jj = 0; jj < nny; jj++)
                {
                    int j = (int)(jj/_bfOrder);
                    y0 = hy*j;
                    y1 = hy*(j+1);
                    if (fy != nullptr)
                    {
                        y0 = fy(y0);
                        y1 = fy(y1);
                    }
                    for (int ii = 0; ii < nnx; ii++)
                    {
                        int i = (int)(ii/_bfOrder);
                        x0 = hx*i;
                        x1 = hx*(i+1);
                        if (fx != nullptr)
                        {
                            x0 = fx(x0);
                            x1 = fx(x1);
                        }
                        if (_disPts.isItemInPart(n))
                        {
                            int locN = _disPts.locIdx(n);

                            if ((ii % _bfOrder == 0) && (jj % _bfOrder == 0))
                            {
                                //Corner nodes
                                double x = _x_nodes[_loc_nPts * 0 + locN];
                                double y = _x_nodes[_loc_nPts * 1 + locN];
                                if (fx != nullptr)
                                    _x_nodes[_loc_nPts * 0 + locN] = fx(x);
                                if (fy != nullptr)
                                    _x_nodes[_loc_nPts * 1 + locN] = fy(y);
                            }
                            else
                            {
                                //Intra-element nodes
                                if ((fx != nullptr)  && (ii != nnx-1))
                                {
                                    double hhx = (x1-x0)/_bfOrder;
                                    _x_nodes[_loc_nPts * 0 + locN] = x0 + hhx*(ii % _bfOrder);
                                }
                                if ((fy != nullptr) && (jj != nny-1))
                                {
                                    double hhy = (y1-y0)/_bfOrder;
                                    _x_nodes[_loc_nPts * 1 + locN] = y0 + hhy*(jj % _bfOrder);
                                }
                            }

                        }
                        n++;
                    }
                }

                break;
            case static_cast<int>(ElemType::Tetrah):
            case static_cast<int>(ElemType::Parallelep):
                //Number of corner nodes
                nx = _nEx + 1;
                ny = _nEy + 1;
                nz = _nEz + 1;

                //Spacing of nodes
                hx = 1.0 / _nEx;
                hy = 1.0 / _nEy;
                hz = 1.0 / _nEz;

                //Number of nodes
                nnx = (_bfOrder*nx-(_bfOrder-1));
                nny = (_bfOrder*ny-(_bfOrder-1));
                nnz = (_bfOrder*nz-(_bfOrder-1));

                //Modify nodes
                for (int kk = 0; kk < nnz; kk++)
                {
                    int k = (int)(kk/_bfOrder);
                    z0 = hz*k;
                    z1 = hz*(k+1);
                    if (fz != nullptr)
                    {
                        z0 = fz(z0);
                        z1 = fz(z1);
                    }
                    for (int jj = 0; jj < nny; jj++)
                    {
                        int j = (int)(jj/_bfOrder);
                        y0 = hy*j;
                        y1 = hy*(j+1);
                        if (fy != nullptr)
                        {
                            y0 = fy(y0);
                            y1 = fy(y1);
                        }
                        for (int ii = 0; ii < nnx; ii++)
                        {
                            int i = (int)(ii/_bfOrder);
                            x0 = hx*i;
                            x1 = hx*(i+1);
                            if (fx != nullptr)
                            {
                                x0 = fx(x0);
                                x1 = fx(x1);
                            }
                            if (_disPts.isItemInPart(n))
                            {
                                int locN = _disPts.locIdx(n);

                                if ((ii % _bfOrder == 0) && (jj % _bfOrder == 0) && (kk % _bfOrder == 0))
                                {
                                    //Corner nodes
                                    double x = _x_nodes[_loc_nPts * 0 + locN];
                                    double y = _x_nodes[_loc_nPts * 1 + locN];
                                    double z = _x_nodes[_loc_nPts * 2 + locN];
                                    if (fx != nullptr)
                                        _x_nodes[_loc_nPts * 0 + locN] = fx(x);
                                    if (fy != nullptr)
                                        _x_nodes[_loc_nPts * 1 + locN] = fy(y);
                                    if (fz != nullptr)
                                        _x_nodes[_loc_nPts * 2 + locN] = fz(z);
                                }
                                else
                                {
                                    //Intra-element nodes
                                    if ((fx != nullptr)  && (ii != nnx-1))
                                    {
                                        double hhx = (x1-x0)/_bfOrder;
                                        _x_nodes[_loc_nPts * 0 + locN] = x0 + hhx*(ii % _bfOrder);
                                    }
                                    if ((fy != nullptr) && (jj != nny-1))
                                    {
                                        double hhy = (y1-y0)/_bfOrder;
                                        _x_nodes[_loc_nPts * 1 + locN] = y0 + hhy*(jj % _bfOrder);
                                    }
                                    if ((fz != nullptr) && (kk != nnz-1))
                                    {
                                        double hhz = (z1-z0)/_bfOrder;
                                        _x_nodes[_loc_nPts * 2 + locN] = z0 + hhz*(kk % _bfOrder);
                                    }
                                }

                            }
                            n++;
                        }
                    }
                }
                break;
            default:
                throw runtime_error("StructMeshGenerator: Wrong element type.");
        }



    }


    //Unclamp
    void StructMeshGenerator::_unclampCurve()
    {
        //Number of corner nodes
        int nx = _nEx + 1;
        int nnx = (_bfOrder*nx-(_bfOrder-1));

        //Mark nodes for deletion
        vector<int> del_x;
        if (_disPts.isItemInPart(nnx-1))
        {
            int locN = _disPts.locIdx(nnx-1);
            del_x.push_back(_loc_nPts * 0 + locN);
            del_x.push_back(_loc_nPts * 1 + locN);
            del_x.push_back(_loc_nPts * 2 + locN);
        }

        //Order deletion vector in descending order
        std::sort(del_x.begin(), del_x.end(), [](int a, int b){ return a > b;});

        //Delete nodes and creases
        for (auto i = 0u; i < del_x.size(); i++)
            _x_nodes.erase(_x_nodes.begin() + del_x[i]);

        //Update number of points
        _loc_nPts -= del_x.size()/3;
        _disPts.setLocNItem(_loc_nPts);
        _disPts.setNItem(0);
        _disPts.Update();
        _nPts = _disPts.nItem();

        //Rearrange Connectivity
        int nn = 0;
        for (int i=0; i<nx-1; i++)
        {
            for (int ii=0; ii<_bfOrder+1 ; ii++)
            {
                if (i == nx-2 and ii == _bfOrder)
                {
                    _distConnec(nn, 0);
                }
                nn++;
            }
        }

        //Relabel Creases
        _creases.resize(_loc_nPts*_nCreases, 0);
        nn = 0;
        for (int i = 0; i < nnx; i++)
        {
            if(_disPts.isItemInPart(nn))
            {
                int locN = _disPts.locIdx(nn);
                // Creases: Edges = 1
                _creases[_loc_nPts * 0 + locN] = 0;
                // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                _creases[_loc_nPts * 1 + locN] = -1;
            }
            nn++;
        }
    }

    void StructMeshGenerator::_unclampSurface(Axis axis)
    {
        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;

        //Number of nodes
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        int nny = (_bfOrder*ny-(_bfOrder-1));

        //Mark nodes for deletion
        vector<int> del_x;
        int n = 0;
        for (int j = 0; j < nny; j++)
        {
            for (int i = 0; i < nnx; i++)
            {
                if (_disPts.isItemInPart(n))
                {
                    int locN = _disPts.locIdx(n);
                    if ((axis == Axis::Xaxis and _creases[_loc_nPts * 1 + locN] % getMAxis(MAxis::Xmax) == 0) or
                        (axis == Axis::Yaxis and _creases[_loc_nPts * 1 + locN] % getMAxis(MAxis::Ymax) == 0))
                    {
                        del_x.push_back(_loc_nPts * 0 + locN);
                        del_x.push_back(_loc_nPts * 1 + locN);
                        del_x.push_back(_loc_nPts * 2 + locN);
                    }
                }
                n++;
            }
        }

        //Order deletion vector in descending order
        std::sort(del_x.begin(), del_x.end(), [](int a, int b){return a > b;});

        //Delete nodes
        for (auto i = 0u; i < del_x.size(); i++)
            _x_nodes.erase(_x_nodes.begin() + del_x[i]);

        //Update number of points
        _loc_nPts -= del_x.size()/3;
        _disPts.setLocNItem(_loc_nPts);
        _disPts.setNItem(0);
        _disPts.Update();
        _nPts = _disPts.nItem();

        //Rearrange connectivity
        int nn = 0;
        if (_eType == ElemType::Square)
        {
            for (int j = 0; j < ny-1; j++)
            {
                for (int i = 0; i < nx-1; i++)
                {
                    for (int jj = 0; jj < _bfOrder+1; jj++)
                    {
                        for (int ii = 0; ii < _bfOrder+1; ii++)
                        {
                            if (axis == Axis::Xaxis)
                            {
                                int id = j*(nnx-1)*_bfOrder + jj*(nnx-1) + i*_bfOrder + ii;
                                if ((i == nx-2) and (ii == _bfOrder))
                                    id = j*(nnx-1)*_bfOrder + jj*(nnx-1) + 0;
                                if ((_unclampedY == true) and (j == ny-2) and (jj == _bfOrder))
                                {
                                    id = 0 + i*_bfOrder + ii;
                                    if ((i == nx-2) and (ii == _bfOrder))
                                        id = 0;
                                }
                                _distConnec(nn, id);
                            }

                            if ((axis == Axis::Yaxis) and (j == ny-2) and (jj == _bfOrder))
                            {
                                int id = 0 + i*_bfOrder + ii;
                                if (_unclampedX == true and (i == nx-2) and (ii == _bfOrder))
                                    id = 0;
                                _distConnec(nn, id);
                            }
                            nn++;
                        }
                    }
                }
            }
        }
        else if (_eType == ElemType::Triang)
        {
            for (int j = 0; j < ny-1; j++)
            {
                for (int i = 0; i < nx-1; i++)
                {
                    //Lower triangle
                    for (int jj = 0; jj < _bfOrder+1; jj++)
                    {
                        for (int ii = 0; ii < _bfOrder+1-jj; ii++)
                        {
                            if (axis == Axis::Xaxis)
                            {
                                int id = j*(nnx-1)*_bfOrder + jj*(nnx-1) + i*_bfOrder + ii;
                                if ((i == nx-2) and (ii == _bfOrder))
                                    id = j*(nnx-1)*_bfOrder + jj*(nnx-1) + 0;
                                if ((_unclampedY == true) and (j == ny-2) and (jj == _bfOrder))
                                {
                                    id = 0 + i*_bfOrder + ii;
                                    if ((i == nx-2) and (ii == _bfOrder))
                                        id = 0;
                                }
                                _distConnec(nn, id);
                            }

                            if ((axis == Axis::Yaxis) and (j == ny-2) and (jj == _bfOrder))
                            {
                                int id = 0 + i*_bfOrder + ii;
                                if (_unclampedX == true and (i == nx-2) and (ii == _bfOrder))
                                    id = 0;
                                _distConnec(nn, id);
                            }
                            nn++;
                        }
                    }

                    //Upper triangle
                    for (int jj = _bfOrder; jj >= 0; jj--)
                    {
                        for (int ii = _bfOrder; ii >= _bfOrder-jj; ii--)
                        {
                            if (axis == Axis::Xaxis)
                            {
                                int id = j*(nnx-1)*_bfOrder + jj*(nnx-1) + i*_bfOrder + ii;
                                if ((i == nx-2) and (ii == _bfOrder))
                                    id = j*(nnx-1)*_bfOrder + jj*(nnx-1) + 0;
                                if ((_unclampedY == true) and (j == ny-2) and (jj == _bfOrder))
                                {
                                    id = 0 + i*_bfOrder + ii;
                                    if ((i == nx-2) and (ii == _bfOrder))
                                        id = 0;
                                }
                                _distConnec(nn, id);
                            }

                            if ((axis == Axis::Yaxis) and (j == ny-2) and (jj == _bfOrder))
                            {
                                int id = 0 + i*_bfOrder + ii;
                                if (_unclampedX == true and (i == nx-2) and (ii == _bfOrder))
                                    id = 0;
                                _distConnec(nn, id);
                            }
                            nn++;
                        }
                    }
                }
            }
        }

        //Relabel creases
        _creases.resize(_loc_nPts*_nCreases, 0);
        if (axis == Axis::Xaxis)
            nnx--;
        if (axis == Axis::Yaxis)
            nny--;
        int ex = nnx - 1;
        int ey = nny - 1;

        if (_unclampedX == true and _unclampedY == false)
        {
            nn = 0;
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if(_disPts.isItemInPart(nn))
                    {
                        int locN = _disPts.locIdx(nn);
                        // Creases: Edges = 1; Corners = 2
                        if(j==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(j==ey)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else
                            _creases[_loc_nPts * 0 + locN] = 0;
                        // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                        //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                        if(j==0)
                            _creases[_loc_nPts * 1 + locN] = 5;
                        else if(j==ey)
                            _creases[_loc_nPts * 1 + locN] = 7;
                        else
                            _creases[_loc_nPts * 1 + locN] = -1;
                    }
                    nn++;
                }
            }
        }
        else if (_unclampedX == false and _unclampedY == true)
        {
            nn = 0;
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if(_disPts.isItemInPart(nn))
                    {
                        int locN = _disPts.locIdx(nn);
                        // Creases: Edges = 1; Corners = 2
                        if(i==0)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else if(i==ex)
                            _creases[_loc_nPts * 0 + locN] = 1;
                        else
                            _creases[_loc_nPts * 0 + locN] = 0;
                        // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                        //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                        if(i==0)
                            _creases[_loc_nPts * 1 + locN] = 2;
                        else if(i==ex)
                            _creases[_loc_nPts * 1 + locN] = 3;
                        else
                            _creases[_loc_nPts * 1 + locN] = -1;
                    }
                    nn++;
                }
            }
        }
        else
        {
            nn = 0;
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if(_disPts.isItemInPart(nn))
                    {
                        int locN = _disPts.locIdx(nn);
                        // Creases: Edges = 1; Corners = 2
                        _creases[_loc_nPts * 0 + locN] = 0;
                        // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                        //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                        _creases[_loc_nPts * 1 + locN] = -1;
                    }
                    nn++;
                }
            }
        }

    }

    void StructMeshGenerator::_unclampSolid(Axis axis)
    {
        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;
        int nz = _nEz + 1;

        //Number of nodes
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        int nny = (_bfOrder*ny-(_bfOrder-1));
        int nnz = (_bfOrder*nz-(_bfOrder-1));

        //Mark nodes for deletion
        vector<int> del_x;
        int n = 0;
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        if ((axis == Axis::Xaxis and _creases[_loc_nPts * 1 + locN] % getMAxis(MAxis::Xmax) == 0) or
                            (axis == Axis::Yaxis and _creases[_loc_nPts * 1 + locN] % getMAxis(MAxis::Ymax) == 0) or
                            (axis == Axis::Zaxis and _creases[_loc_nPts * 1 + locN] % getMAxis(MAxis::Zmax) == 0))
                        {
                            del_x.push_back(_loc_nPts * 0 + locN);
                            del_x.push_back(_loc_nPts * 1 + locN);
                            del_x.push_back(_loc_nPts * 2 + locN);
                        }
                    }
                    n++;
                }
            }
        }

        //Order deletion vector in descending order
        std::sort(del_x.begin(), del_x.end(), [](int a, int b){ return a > b;});

        //Delete nodes
        for (auto i = 0u; i < del_x.size(); i++)
            _x_nodes.erase(_x_nodes.begin() + del_x[i]);

        //Update number of points
        _loc_nPts -= del_x.size()/3;
        _disPts.setLocNItem(_loc_nPts);
        _disPts.setNItem(0);
        _disPts.Update();
        _nPts = _disPts.nItem();

        //Rearrange connectivity
        int nn = 0;
        for (int k=0; k<nz-1; k++)
        {
            for (int j=0; j<ny-1; j++)
            {
                for (int i=0; i<nx-1; i++)
                {
                    for (int kk=0; kk<_bfOrder+1 ; kk++)
                    {
                        for (int jj=0; jj<_bfOrder+1 ; jj++)
                        {
                            for (int ii=0; ii<_bfOrder+1 ; ii++)
                            {
                                int NNx = nnx;
                                int NNy = nny;
                                if (_unclampedX == true)
                                    NNx--;
                                if (_unclampedY == true)
                                    NNy--;
                                if (axis == Axis::Xaxis)
                                {
                                    int id = k*NNx*NNy*_bfOrder + kk*NNx*NNy + j*NNx*_bfOrder + jj*NNx + i*_bfOrder + ii;
                                    if ((i == nx-2) and (ii == _bfOrder))
                                        id = k*NNx*NNy*_bfOrder + kk*NNx*NNy + j*NNx*_bfOrder + jj*NNx + 0;
                                    if ((_unclampedY == true) and (j == ny-2) and (jj == _bfOrder))
                                    {
                                        id = k*NNx*NNy*_bfOrder + kk*NNx*NNy + 0 + i*_bfOrder + ii;
                                        if ((i == nx-2) and (ii == _bfOrder))
                                            id = k*NNx*NNy*_bfOrder + kk*NNx*NNy + 0 + 0;
                                    }
                                    if ((_unclampedZ == true) and (k == nz-2) and (kk == _bfOrder))
                                    {
                                        id = j*NNx*_bfOrder + jj*NNx + i*_bfOrder + ii;
                                        if ((i == nx-2) and (ii == _bfOrder))
                                        {
                                            id = 0 + 0 + i*_bfOrder + ii;
                                            if ((_unclampedY == true) and (j == ny-2) and (jj == _bfOrder))
                                            {
                                                id = 0 + 0 + 0;
                                            }
                                        }
                                    }
                                    _distConnec(nn, id);
                                }
                                if (axis == Axis::Yaxis)
                                {
                                    int id = k*NNx*NNy*_bfOrder + kk*NNx*NNy + j*NNx*_bfOrder + jj*NNx + i*_bfOrder + ii;
                                    if ((j == ny-2) and (jj == _bfOrder))
                                    {
                                        id = k*NNx*NNy*_bfOrder + kk*NNx*NNy + 0 + i*_bfOrder + ii;
                                        if ((_unclampedX == true) and (i == nx-2) and (ii == _bfOrder))
                                            id = k*NNx*NNy*_bfOrder + kk*NNx*NNy + 0 + 0;
                                    }
                                    if ((_unclampedZ == true) and (k == nz-2) and (kk == _bfOrder))
                                    {
                                        id = j*NNx*_bfOrder + jj*NNx + i*_bfOrder + ii;
                                        if ((i == nx-2) and (ii == _bfOrder))
                                        {
                                            id = 0 + 0 + i*_bfOrder + ii;
                                            if ((_unclampedY == true) and (j == ny-2) and (jj == _bfOrder))
                                            {
                                                id = 0 + 0 + 0;
                                            }
                                        }
                                    }
                                    _distConnec(nn, id);
                                }
                                if ((axis == Axis::Zaxis) and (k == nz-2) and (kk == _bfOrder))
                                {
                                    int id = 0 + j*NNx*_bfOrder + jj*NNx + i*_bfOrder + ii;
                                    if ((_unclampedX == true) and (i == nx-2) and (ii == _bfOrder))
                                        id = 0 + j*NNx*_bfOrder + jj*NNx + 0;
                                    if ((_unclampedY == true) and (j == ny-2) and (jj == _bfOrder))
                                    {
                                        id = 0 + 0 + i*_bfOrder + ii;
                                        if ((_unclampedX == true) and (i == nx-2) and (ii == _bfOrder))
                                        {
                                            id = 0 + 0 + 0;
                                        }
                                    }
                                    _distConnec(nn, id);
                                }
                                nn++;
                            }
                        }
                    }
                }
            }
        }

        //Relabel creases
        _creases.resize(_loc_nPts*_nCreases, 0);
        if (axis == Axis::Xaxis)
            nnx--;
        if (axis == Axis::Yaxis)
            nny--;
        if (axis == Axis::Zaxis)
            nnz--;
        int ex = nnx - 1;
        int ey = nny - 1;
        int ez = nnz - 1;
        if (_unclampedX == true and _unclampedY == false and _unclampedZ == false)
        {
            nn = 0;
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        if(_disPts.isItemInPart(nn))
                        {
                            int locN = _disPts.locIdx(nn);
                            //Creases: Edges = 1; Corners = 2; Faces = 3
                            if(j==0 && k==0)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(j==0 && k == ez)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(j==ey && k == 0)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(j==ey && k == ez)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(j==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(k==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(j==ey)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(k==ez)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else
                                _creases[_loc_nPts * 0 + locN] = 0;
                            // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                            //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                            //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                            if(j==0 && k==0)
                                _creases[_loc_nPts * 1 + locN] = 5*11;
                            else if(j==0 && k == ez)
                                _creases[_loc_nPts * 1 + locN] = 5*13;
                            else if(j==ey && k == 0)
                                _creases[_loc_nPts * 1 + locN] = 7*11;
                            else if(j==ey && k == ez)
                                _creases[_loc_nPts * 1 + locN] = 7*13;
                            else if(j==0)
                                _creases[_loc_nPts * 1 + locN] = 5;
                            else if(j==ey)
                                _creases[_loc_nPts * 1 + locN] = 7;
                            else if(k==0)
                                _creases[_loc_nPts * 1 + locN] = 11;
                            else if(k==ez)
                                _creases[_loc_nPts * 1 + locN] = 13;
                            else
                                _creases[_loc_nPts * 1 + locN] = -1;
                        }
                        nn++;
                    }
                }
            }
        }
        else if (_unclampedX == false and _unclampedY == true and _unclampedZ == false)
        {
            nn = 0;
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        if(_disPts.isItemInPart(nn))
                        {
                            int locN = _disPts.locIdx(nn);
                            //Creases: Edges = 1; Corners = 2; Faces = 3
                            if(i==0 && k==0)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==0 && k == ez)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==ex && k == 0)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==ex && k == ez)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(k==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(i==ex)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(k==ez)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else
                                _creases[_loc_nPts * 0 + locN] = 0;
                            // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                            //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                            //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                            if(i==0 && k==0)
                                _creases[_loc_nPts * 1 + locN] = 2*11;
                            else if(i==0 && k == ez)
                                _creases[_loc_nPts * 1 + locN] = 2*13;
                            else if(i==ex && k == 0)
                                _creases[_loc_nPts * 1 + locN] = 3*11;
                            else if(i==ex && k == ez)
                                _creases[_loc_nPts * 1 + locN] = 3*13;
                            else if(i==0)
                                _creases[_loc_nPts * 1 + locN] = 2;
                            else if(i==ex)
                                _creases[_loc_nPts * 1 + locN] = 3;
                            else if(k==0)
                                _creases[_loc_nPts * 1 + locN] = 11;
                            else if(k==ez)
                                _creases[_loc_nPts * 1 + locN] = 13;
                            else
                                _creases[_loc_nPts * 1 + locN] = -1;
                        }
                        nn++;
                    }
                }
            }
        }
        else if (_unclampedX == false and  _unclampedY == false and _unclampedZ == true)
        {
            nn = 0;
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        if(_disPts.isItemInPart(nn))
                        {
                            int locN = _disPts.locIdx(nn);
                            //Creases: Edges = 1; Corners = 2; Faces = 3
                            if(i==0 && j==0)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==0 && j == ey)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==ex && j == 0)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==ex && j == ey)
                                _creases[_loc_nPts * 0 + locN] = 1;
                            else if(i==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(j==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(i==ex)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(j==ey)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else
                                _creases[_loc_nPts * 0 + locN] = 0;
                            // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                            //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                            //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                            if(i==0 && j==0)
                                _creases[_loc_nPts * 1 + locN] = 2*5;
                            else if(i==0 && j == ey)
                                _creases[_loc_nPts * 1 + locN] = 2*7;
                            else if(i==ex && j == 0)
                                _creases[_loc_nPts * 1 + locN] = 3*5;
                            else if(i==ex && j == ey)
                                _creases[_loc_nPts * 1 + locN] = 3*7;
                            else if(i==0)
                                _creases[_loc_nPts * 1 + locN] = 2;
                            else if(i==ex)
                                _creases[_loc_nPts * 1 + locN] = 3;
                            else if(j==0)
                                _creases[_loc_nPts * 1 + locN] = 5;
                            else if(j==ey)
                                _creases[_loc_nPts * 1 + locN] = 7;
                            else
                                _creases[_loc_nPts * 1 + locN] = -1;
                        }
                        nn++;
                    }
                }
            }
        }
        else if (_unclampedX == true and _unclampedY == true and _unclampedZ == false)
        {
            nn = 0;
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        if(_disPts.isItemInPart(nn))
                        {
                            int locN = _disPts.locIdx(nn);
                            //Creases: Edges = 1; Corners = 2; Faces = 3
                            if(k==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(k==ez)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else
                                _creases[_loc_nPts * 0 + locN] = 0;
                            // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                            //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                            //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                            if(k==0)
                                _creases[_loc_nPts * 1 + locN] = 11;
                            else if(k==ez)
                                _creases[_loc_nPts * 1 + locN] = 13;
                            else
                                _creases[_loc_nPts * 1 + locN] = -1;
                        }
                        nn++;
                    }
                }

            }

        }
        else if (_unclampedX == true and _unclampedY == false and _unclampedZ == true)
        {
            nn = 0;
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        if(_disPts.isItemInPart(nn))
                        {
                            int locN = _disPts.locIdx(nn);
                            //Creases: Edges = 1; Corners = 2; Faces = 3
                            if(j==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(j==ey)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else
                                _creases[_loc_nPts * 0 + locN] = 0;
                            // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                            //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                            //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                            if(j==0)
                                _creases[_loc_nPts * 1 + locN] = 5;
                            else if(j==ey)
                                _creases[_loc_nPts * 1 + locN] = 7;
                            else
                                _creases[_loc_nPts * 1 + locN] = -1;
                        }
                        nn++;
                    }
                }

            }

        }
        else if (_unclampedX == false and _unclampedY == true and _unclampedZ == true)
        {
            nn = 0;
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        if(_disPts.isItemInPart(nn))
                        {
                            int locN = _disPts.locIdx(nn);
                            //Creases: Edges = 1; Corners = 2; Faces = 3
                            if(i==0)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else if(i==ex)
                                _creases[_loc_nPts * 0 + locN] = 3;
                            else
                                _creases[_loc_nPts * 0 + locN] = 0;
                            // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                            //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                            //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                            if(i==0)
                                _creases[_loc_nPts * 1 + locN] = 2;
                            else if(i==ex)
                                _creases[_loc_nPts * 1 + locN] = 3;
                            else
                                _creases[_loc_nPts * 1 + locN] = -1;
                        }
                        nn++;
                    }
                }
            }
        }
        else
        {
            nn = 0;
            for (int k = 0; k < nnz; k++)
            {
                for (int j = 0; j < nny; j++)
                {
                    for (int i = 0; i < nnx; i++)
                    {
                        if(_disPts.isItemInPart(nn))
                        {
                            int locN = _disPts.locIdx(nn);
                            //Creases: Edges = 1; Corners = 2; Faces = 3
                            _creases[_loc_nPts * 0 + locN] = 0;
                            // Axis: MAxis::Xmin = module(2); MAxis::Xmax = module(3);
                            //       MAxis::Ymin = module(5); MAxis::Ymax = module(7);
                            //       MAxis::Zmin = module(11); MAxis::Zmax = module(13);
                            _creases[_loc_nPts * 1 + locN] = -1;
                        }
                        nn++;
                    }
                }

            }
        }
    }

    void StructMeshGenerator::_unclamp(vector<Axis> axes)
    {
        // Get unclamp directions
        bool unclampX{false};
        bool unclampY{false};
        bool unclampZ{false};
        for (size_t it = 0; it < axes.size(); ++it)
        {
            switch (axes[it])
            {
                case Axis::Xaxis:
                    if (!_unclampedX)
                    {
                        _unclampedX = true;
                        unclampX = true;
                    }
                    break;
                case Axis::Yaxis:
                    if (!_unclampedY)
                    {
                        _unclampedY = true;
                        unclampY = true;
                    }
                    break;
                case Axis::Zaxis:
                    if (!_unclampedZ)
                    {
                        _unclampedZ = true;
                        unclampZ = true;
                    }
                    break;
                default:
                    throw std::runtime_error("StructMeshGenerator::_unclampNurbs: Axis not set.");
                    break;
            }
        }

        // Unclamp
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                if (unclampY or unclampZ)
                    throw  runtime_error("StructMeshGenerator::unclamp: Axis can only be Xaxis for curves.");
                if (unclampX)
                    _unclampCurve();
                break;
            case static_cast<int>(ElemType::Triang):
            case static_cast<int>(ElemType::Square):
                if (unclampZ)
                    throw  runtime_error("StructMeshGenerator::unclamp: Axis can only be Xaxis or Yaxis for surfaces.");
                if (unclampX)
                    _unclampSurface(Axis::Xaxis);
                if (unclampY)
                    _unclampSurface(Axis::Yaxis);
                break;
            case static_cast<int>(ElemType::Tetrah):
            case static_cast<int>(ElemType::Parallelep):
                if (unclampX)
                    _unclampSolid(Axis::Xaxis);
                if (unclampY)
                    _unclampSolid(Axis::Yaxis);
                if (unclampZ)
                    _unclampSolid(Axis::Zaxis);
                break;
            default:
                throw runtime_error("StructMeshGenerator: Wrong element type.");
        }
    }


    //Revolve
    void StructMeshGenerator::_revolveCurve(int nEy, int order_y, ElemType eType, double theta, vector<double> point, vector<double> dir)
    {
        //Order is constant for every direction
        (void) order_y;

        //Save coordinates
        _saveMesh();

        //Get global x_nodes
        vector<double> xnodes_Glob(_nPts_tmp*_nDim, 0.0);
        for (int p = 0; p < numProcs(); p++)
        {
            //Send xnodes
            int nloc = _disPts.proc_nItem(p);
            vector<double> xnodes(nloc*_nDim);
            if (myRank() == p)
                xnodes = _x_nodes;
            MPI_Bcast(xnodes.data(), nloc*_nDim, MPI_DOUBLE, p, comm());

            //Put them in the correct location
            int offSet = _disPts.offs_nItem(p);
            for (int i = 0; i < nloc; i++)
            {
                for (int d = 0; d < 3; d++)
                {
                    xnodes_Glob[_nPts_tmp*d + offSet + i] = xnodes[nloc*d+i];
                }
            }
        }

        //Generate 2D mesh
        _eType = eType;
        genStructMesh(_nEx, nEy);

        //Transform
        int nold{};
        double phi{}, dphi{theta/_nEy/_bfOrder};
        vector<double> X_old(3), X(3), O(3), Y(3);
        int nnx = _bfOrder*_nEx + 1;
        int nny = _bfOrder*_nEy + 1;
        int n = 0;
        for (int j = 0; j < nny; j++)
        {
            for (int i = 0; i < nnx; i++)
            {
                nold = n%_nPts_tmp;
                if ((n%_nPts_tmp == 0) and (n != 0))
                    phi += dphi;
                if (_disPts.isItemInPart(n))
                {
                    int locN = _disPts.locIdx(n);

                    for (int d = 0; d < 3; d++)
                        X_old[d] = xnodes_Glob[_nPts_tmp*d+nold];
                    SGeometry::pointToLine(point, dir, X_old, O);
                    for (int d = 0; d < 3; d++)
                        X[d] = X_old[d] - O[d];
                    double r = Math::Norm3D(X.data());
                    if (r != 0)
                    {
                        for (int d = 0; d < 3; d++)
                        {
                            X[d] = X[d]/r;
                        }
                    }
                    Math::Cross(Y.data(), dir.data(), X.data());

                    for (int d = 0; d < 3; d++)
                        _x_nodes[_loc_nPts * d + locN] = O[d] + r*cos(phi)*X[d] + r*sin(phi)*Y[d];
                }
                n++;
            }
        }

    }

    void StructMeshGenerator::_revolveSurface(int nEz, int order_z, ElemType eType, double theta, vector<double> point, vector<double> dir)
    {
        //Order is constant for every direction
        (void) order_z;

        //Save coordinates
        _saveMesh();

        //Get global x_nodes
        vector<double> xnodes_Glob(_nPts_tmp*_nDim, 0.0);
        for (int p = 0; p < numProcs(); p++)
        {
            //Send xnodes
            int nloc = _disPts.proc_nItem(p);
            vector<double> xnodes(nloc*_nDim);
            if (myRank() == p)
                xnodes = _x_nodes;
            MPI_Bcast(xnodes.data(), nloc*_nDim, MPI_DOUBLE, p, comm());

            //Put them in the correct location
            int offSet = _disPts.offs_nItem(p);
            for (int i = 0; i < nloc; i++)
            {
                for (int d = 0; d < 3; d++)
                {
                    xnodes_Glob[_nPts_tmp*d + offSet + i] = xnodes[nloc*d+i];
                }
            }
        }

        //Generate 2D mesh
        _eType = eType;
        genStructMesh(_nEx, _nEy, nEz);

        //Transform
        int nold{};
        double phi{}, dphi{theta/_nEz/_bfOrder};
        vector<double> X_old(3), X(3), O(3), Y(3);
        int nnx = _bfOrder*_nEx + 1;
        int nny = _bfOrder*_nEy + 1;
        int nnz = _bfOrder*_nEz + 1;
        int n = 0;
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    nold = n%_nPts_tmp;
                    if ((n%_nPts_tmp == 0) and (n != 0))
                        phi += dphi;
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);

                        for (int d = 0; d < 3; d++)
                            X_old[d] = xnodes_Glob[_nPts_tmp*d+nold];
                        SGeometry::pointToLine(point, dir, X_old, O);
                        for (int d = 0; d < 3; d++)
                            X[d] = X_old[d] - O[d];
                        double r = Math::Norm3D(X.data());
                        if (r != 0)
                        {
                            for (int d = 0; d < 3; d++)
                            {
                                X[d] = X[d]/r;
                            }
                        }
                        Math::Cross(Y.data(), dir.data(), X.data());

                        for (int d = 0; d < 3; d++)
                            _x_nodes[_loc_nPts * d + locN] = O[d] + r*cos(phi)*X[d] + r*sin(phi)*Y[d];
                    }
                    n++;
                }
            }
        }
    }

    void StructMeshGenerator::_revolve(int nEr, int order_r, ElemType eType, double theta, vector<double> point, vector<double> dir)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator::revolve: Cannot perform transformation before generating the mesh.");
        if (_eType != eType--)
            throw runtime_error("StructMeshGenerator::revolve: Cannot revolve a " + str(_eType) + " element mesh into a " + str(eType) + " one.");

        //Correct direction
        for (int d = 0; d < 3; d++)
            dir[d] += point[d];

        //Transform
        switch (int(eType))
        {
            case static_cast<int>(ElemType::Line):
                throw runtime_error("StructMeshGenerator: Cannot revolve a 0D mesh.");
                break;
            case static_cast<int>(ElemType::Square):
            case static_cast<int>(ElemType::Triang):
                _revolveCurve(nEr, order_r, eType, theta, point, dir);
                break;
            case static_cast<int>(ElemType::Parallelep):
            case static_cast<int>(ElemType::Tetrah):
                _revolveSurface(nEr, order_r, eType, theta, point, dir);
                break;
            default:
                throw runtime_error("StructMeshGenerator: Wrong element type.");
        }

        // //Save history
        // _history.emplace_back([=](){_revolve(nEr, order_r, theta, point, dir);});
        // _history_names.push_back(__FUNCTION__);
    }


    //Periodicity
    void StructMeshGenerator::_periodicCurve()
    {
        //Number of corner nodes
        int nx = _nEx + 1;

        //Number of nodes
        int nnx = (_bfOrder*nx-(_bfOrder-1));

        // Check if node nnx -1 is in the core
        _linearConstraints.resize(0);
        if (_disPts.isItemInPart(nnx -1))
            _linearConstraints.push_back({nnx-1, {0}, {1.0}, 0.0});
    }

    void StructMeshGenerator::_periodicSurface()
    {
        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;

        //Number of nodes
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        int nny = (_bfOrder*ny-(_bfOrder-1));

        // Number of axis along which periodicity is defined
        int naxis = 0;

        bool checkNodeflag = true; /* flag to check the repeated node */
        bool diagnosticFlag = false;  /* flag introduced for debugging */

        _linearConstraints.resize(0);
        if (_periodicInY and _periodicInX)
        {
            _linearConstraints.push_back({nnx*nny-1, {0}, {1.0}, 0.0}); /* Left upper corner node */
            naxis = 1;
        }


        if (_periodicInX)
        {

            for (int nodeIdx=0; nodeIdx<_nPts; nodeIdx=nodeIdx + nnx)
            {
                if (_disPts.isItemInPart(nodeIdx+nnx-1))
                {
                    for (int j = 0; j < naxis; j++)
                    {
                        if (_linearConstraints[j].slave == nodeIdx+nnx-1)
                        {
                            checkNodeflag = false;
                            break;
                        }
                    }
                    if (checkNodeflag)
                        _linearConstraints.push_back({nodeIdx+nnx-1, {nodeIdx}, {1.0}, 0.0});
                    else
                        checkNodeflag=true;
                }
            }
        }


        if (_periodicInY)
        {

           for (int nodeIdx=0; nodeIdx<nnx; nodeIdx++)
           {
                if(_disPts.isItemInPart(nodeIdx + (_bfOrder*nx-(_bfOrder-1))*(_bfOrder*ny-(_bfOrder-1))-nnx))
                {
                     for (int j=0;j<naxis;j++)
                     {
                          if (_linearConstraints[j].slave  == nodeIdx +
                              (_bfOrder*nx-(_bfOrder-1))*(_bfOrder*ny-(_bfOrder-1))-nnx)
                          {
                              checkNodeflag =false ;
                              break;
                          }
                     }
                     if (checkNodeflag)
                         _linearConstraints.push_back({nodeIdx + (_bfOrder*nx-(_bfOrder-1))*(_bfOrder*ny-(_bfOrder-1))-nnx, {nodeIdx}, {1.0}, 0.0});
                     else
                         checkNodeflag=true;
                }

            }
        }

        // If the node nnx*nny-1 does not belong to the partition
        // erase first entry of the _linearConstraints vector
        if(!_disPts.isItemInPart(nnx*nny-1))
        {
            if (_periodicInX and _periodicInY)
                _linearConstraints.erase(_linearConstraints.begin(),_linearConstraints.begin()+1);
        }

        if (diagnosticFlag and (_periodicInX or _periodicInY or _periodicInZ) )
        {
            int size;
            MPI_Comm_size(MPI_COMM_WORLD, &size);
            for (int processorId=0; processorId<size;processorId++)
            {
                int world_rank;
                MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
                MPI_Barrier(MPI_COMM_WORLD);
                if (world_rank == processorId)
                {
                    for (size_t i = 0; i < _linearConstraints.size(); i++)
                    {
                        printf("The master and slave nodes for  processor id %d are respectively %d and %d \n ", processorId, _linearConstraints[i].masters[0], _linearConstraints[i].slave);
                    }
                }
                MPI_Barrier(MPI_COMM_WORLD);
            }
        }
    }

    void StructMeshGenerator::_periodicSolid()
    {
        //Number of corner nodes
        int nx = _nEx + 1;
        int ny = _nEy + 1;
        int nz = _nEz + 1;

        //Number of nodes
        int nnx = (_bfOrder*nx-(_bfOrder-1));
        int nny = (_bfOrder*ny-(_bfOrder-1));
        int nnz = (_bfOrder*nz-(_bfOrder-1));

        bool checkNodeflag = true; /* flag to check the repeated node */
        bool diagnosticFlag = false;  /* flag introduced for debugging */
        _linearConstraints.resize(0);
        int naxis=0;

        if (((_periodicInX and _periodicInY and _periodicInZ)==false) and _periodicInX and _periodicInY)
        {
            for (int j=0;j<nnz;j++)
            {
                _linearConstraints.push_back({nnx*nny*(nnz-1-j)+nnx*nny-1, {nnx*nny*(nnz-1-j)}, {1.0}, 0.0});
                naxis++;
            }
        }
        if (((_periodicInX and _periodicInY and _periodicInZ)==false) and _periodicInY and _periodicInZ)
        {
            for (int j=0;j<nnx;j++)
            {
                _linearConstraints.push_back({j + nnx*nny*nnz -nnx, {j}, {1.0}, 0.0});
                naxis++;
            }
        }
        if (((_periodicInX and _periodicInY and _periodicInZ)==false)  and  _periodicInZ and _periodicInX)
        {
            for (int j=0;j<nny;j++)
            {
                _linearConstraints.push_back({j*nnx +  nnx*nny*(nnz-1) + nnx-1, {j*nnx}, {1.0}, 0.0});
                naxis++;
            }
        }

        if (_periodicInX and _periodicInY and _periodicInZ)
        {

            _linearConstraints.push_back({nnx*nny*nnz-1, {0}, {1.0}, 0.0}); /* node 7*/
            _linearConstraints.push_back({nnx*nny*nnz-nnx, {0}, {1.0}, 0.0}); /* node 6 */
            _linearConstraints.push_back({nnx*nny*(nnz-1)+nnx-1, {0}, {1.0}, 0.0}); /* node 5 */
            _linearConstraints.push_back({nnx*nny*(nnz-1), {0}, {1.0}, 0.0}); /* node 4 */
            _linearConstraints.push_back({nnx*nny-1, {0}, {1.0}, 0.0}); /* node 3 */
            _linearConstraints.push_back({nnx*nny-nnx, {0}, {1.0}, 0.0}); /* node 2 */
            _linearConstraints.push_back({nnx-1, {0}, {1.0}, 0.0}); /* node 1 */
            naxis=7;

            for (int j=1;j<nnz-1;j++)
            {
                _linearConstraints.push_back({nnx*nny*(nnz-1-j)+nnx*nny-1, {nnx*nny*(nnz-1-j)}, {1.0}, 0.0});
                naxis++;
            }

            for (int j=1;j<nnx-1;j++)
            {
                _linearConstraints.push_back({j + nnx*nny*nnz - nnx, {j}, {1.0}, 0.0});
                naxis++;
            }

            for (int j=1;j<nny-1;j++)
            {
                _linearConstraints.push_back({j*nnx + nnx*nny*(nnz-1) + nnx-1, {j*nnx}, {1.0}, 0.0});
                naxis++;
            }


        }

        if (_periodicInZ)  // Periodicity is xy plane
        {
           for (int nodeIdx=0; nodeIdx<nnx*nny; nodeIdx++)
           {
                if(_disPts.isItemInPart((nnz-1)*nnx*nny + nodeIdx) )
                {
                    for (int j=0;j<naxis;j++)
                    {
                        if (_linearConstraints[j].slave  == (nnz-1)*nnx*nny + nodeIdx)
                        {
                            checkNodeflag = false;
                            break;
                        }
                    }
                    if (checkNodeflag)
                        _linearConstraints.push_back({(nnz-1)*nnx*nny + nodeIdx, {nodeIdx}, {1.0}, 0.0});
                    else
                       checkNodeflag=true;
                }
            }
        }
        if (_periodicInX) // Periodicity in yz plane
        {
           for (int nodeIdx=0; nodeIdx<_nPts; nodeIdx=nodeIdx+nnx)
           {
                if(_disPts.isItemInPart(nnx  + nodeIdx - 1))
                {
                    for (int j=0;j<naxis;j++)
                    {
                        if (_linearConstraints[j].slave  == nnx + nodeIdx - 1)
                        {
                            checkNodeflag = false;
                            break;
                        }
                    }
                    if (checkNodeflag)
                        _linearConstraints.push_back({nnx + nodeIdx - 1, {nodeIdx}, {1.0}, 0.0});
                    else
                        checkNodeflag=true;
                }
           }
        }
        if (_periodicInY) // Periodicity in zx plane
        {

           for (int nodeIdx=0; nodeIdx<_nPts; nodeIdx++)
           {
                if(_disPts.isItemInPart(nnx*(nny-1)  + nodeIdx)  and nodeIdx%(nnx*nny)<nny)
                {
                    for (int j=0;j<naxis;j++)
                    {
                        if (_linearConstraints[j].slave  == nnx*(nny-1)  + nodeIdx)
                        {
                            checkNodeflag = false;
                            break;
                        }
                    }
                    if (checkNodeflag)
                        _linearConstraints.push_back({nnx*(nny-1) + nodeIdx, {nodeIdx}, {1.0}, 0.0});
                    else
                        checkNodeflag=true;
                }
           }

        }

        // If the slave node does not belong to the core erase first entry of the _linearConstraints vector
        for (int i = naxis-1; i >= 0; i--)
        {
            if(!_disPts.isItemInPart(_linearConstraints[i].slave))
            {
                if ((_periodicInX and _periodicInY) or
                    (_periodicInY and _periodicInZ) or
                    (_periodicInZ and _periodicInX) or
                    (_periodicInX and _periodicInY and _periodicInZ))
                {
                    _linearConstraints.erase(_linearConstraints.begin()+i,_linearConstraints.begin()+i+1);
                }
            }
        }

        if (diagnosticFlag and (_periodicInY or _periodicInX or _periodicInZ))
        {
            int size;
            MPI_Comm_size(MPI_COMM_WORLD, &size);
            for (int processorId=0; processorId<size;processorId++)
            {
                int world_rank;
                MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
                if ( world_rank== processorId )
                {
                    for (size_t i = 0; i<_linearConstraints.size(); i++)
                    {
                        printf("The master and slave nodes for  processor id %d are respectively %d and %d \n ",processorId,_linearConstraints[i].masters[0],_linearConstraints[i].slave);
                    }
                }
            }
        }
    }


    //Extrude
    void StructMeshGenerator::_extrudeSurfaceLinear(int nEz, double height)
    {
        ElemType eType;
        if (_eType == ElemType::Square)
            eType = ElemType::Parallelep;
        else
            throw runtime_error("StructMeshGenerator: Wrong element type for extrusion.");

        //Save coordinates
        _saveMesh();

        //Get global x_nodes
        vector<double> xnodes_Glob(_nPts_tmp*_nDim, 0.0);
        for (int p = 0; p < numProcs(); p++)
        {
            //Send xnodes
            int nloc = _disPts.proc_nItem(p);
            vector<double> xnodes(nloc*_nDim);
            if (myRank() == p)
                xnodes = _x_nodes;
            MPI_Bcast(xnodes.data(), nloc*_nDim, MPI_DOUBLE, p, comm());

            //Put them in the correct location
            int offSet = _disPts.offs_nItem(p);
            for (int i = 0; i < nloc; i++)
            {
                for (int d = 0; d < 3; d++)
                {
                    xnodes_Glob[_nPts_tmp*d + offSet + i] = xnodes[nloc*d+i];
                }
            }
        }

        //Generate 3D mesh
        _eType = eType;
        genStructMesh(_nEx, _nEy, nEz);

        //Transform 3D mesh
        int nnx = _bfOrder*_nEx + 1;
        int nny = _bfOrder*_nEy + 1;
        int nnz = _bfOrder*_nEz + 1;
        int n{0};
        for (int k = 0; k < nnz; k++)
        {
            for (int j = 0; j < nny; j++)
            {
                for (int i = 0; i < nnx; i++)
                {
                    int nold = n%_nPts_tmp;
                    if (_disPts.isItemInPart(n))
                    {
                        int locN = _disPts.locIdx(n);
                        for (int d = 0; d < 2; d++)
                        {
                            double coord = xnodes_Glob[_nPts_tmp*d+nold];
                            _x_nodes[_loc_nPts * d + locN] = coord;
                        }
                    }
                    n++;
                }
            }
        }

        // Scale
        scaleZ(height);
    }


    //Refinement
    void templateThreeRefinement_2D_preallocate(int &t_nPts, int &t_nElem, vector<int> S)
    {
        // Reorder nodal subdivision levels and creases counter-clock-wise
        swap(S[2], S[3]); //FIXME higher-order

        // Initialize
        int templ{};
        for (auto s: S)
            if (s > 0)
                templ++;

        // Select template
        if (templ == 0)
        {
            t_nPts  = 4-4;
            t_nElem = 1;
        }
        else if (templ == 1)
        {
            t_nPts  = 7-4;
            t_nElem = 3;
        }
        else if (templ == 2)
        {
            t_nPts  = 12-4;
            t_nElem = 7;
        }
        else if (templ == 3)
        {
            t_nPts  = 14-4;
            t_nElem = 8;
        }
        else if (templ == 4)
        {
            t_nPts  = 16-4;
            t_nElem = 9;
        }
    }

    //Refinement
    void templateHRefinement_2D_preallocate(int &t_nPts, int &t_nElem, vector<int> S)
    {
        // Initialize
        int templ{};
        int nPts = S.size();

        for (auto s: S)
            if (s > 0)
                templ++;

        // Select template
        if (nPts == 4)
        {
            if (templ == 0)
            {
                t_nPts  = 4-4;
                t_nElem = 1;
            }
            else
            {
                t_nPts  = 9-4;
                t_nElem = 4;
            }
        }
        else if (nPts == 9)
        {
            if (templ == 0)
            {
                t_nPts  = 9-9;
                t_nElem = 1;
            }
            else
            {
                t_nPts  = 25-9;
                t_nElem = 4;
            }
        }
    }

    void templateThreeRefinement_2D(int &t_nPts, int &t_nElem, vector<int> &t_rCoordsID, vector<int> &t_connec, vector<vector<int>> &t_C, vector<int> &t_S, vector<int> &t_repeated, vector<int> &t_map, vector<int> S, vector<vector<int>> C)
    {
        // Check
        if (C.size() != 2)
            throw runtime_error("StructMeshGenerator_TransformationsFE::templateThreeRefinement_2D: Only implemented for 2 creases.");

        // Reorder nodal subdivision levels and creases counter-clock-wise
        swap(S[2], S[3]); //FIXME higher-order
        for (size_t d = 0; d < C.size(); d++)
            swap(C[d][2], C[d][3]); //FIXME higher-order

        // Initialize
        int templ{}, rot{};
        for (auto s: S)
            if (s > 0)
                templ++;
        t_C.resize(C.size());
        for (size_t c = 0; c < C.size(); c++)
            t_C[c].resize(16,-2);

        // Select template
        if (templ == 0)
        {
            // Main variables
            t_nPts  = 4-4;
            t_nElem = 1;
            t_connec = {-1,-2,-3,-4};
            t_map = {-1,-10,-10,-2,
                     -10,-10,-10,-10,
                     -10,-10,-10,-10,
                     -3,-10,-10,-4};

            // Creases
            for (size_t c = 0; c < C.size(); c++)
            {
                t_C[c][0]  = C[c][0];
                t_C[c][3]  = C[c][1];
                t_C[c][15] = C[c][2];
                t_C[c][12] = C[c][3];
            }
        }
        else if (templ == 1)
        {
            // Main variables
            t_nPts  = 7-4;
            t_nElem = 3;
            t_rCoordsID = {1,
                           4,5};
            t_repeated = {0,1};
            t_connec = {-1,0,1,2,
                        0,-2,2,-4,
                        1,2,-3,-4};
            t_map = {-1,0,-10,-2,
                     1,2,-10,-10,
                     -10,-10,-10,-10,
                     -3,-10,-10,-4};

            // Rotation
            if (S[1] > 0)
                rot = 1;
            else if (S[2] > 0)
                rot = 2;
            else if (S[3] > 0)
                rot = 3;
            if (rot > 0)
            {
                std::rotate(S.begin(),S.begin()+rot,S.end());
                for (size_t i = 0; i < C.size(); i++)
                    std::rotate(C[i].begin(),C[i].begin()+rot,C[i].end());
            }

            // Subdivision levels
            t_S.resize(1, 0);
            t_S[0] = max(S[0]-1,0);

            // Creases
            for (size_t c = 0; c < C.size(); c++)
            {
                // Corners
                t_C[c][0]  = C[c][0];
                t_C[c][3]  = C[c][1];
                t_C[c][15] = C[c][2];
                t_C[c][12] = C[c][3];

                // Other
                for (int i = 0; i < t_nPts; i++)
                    t_C[c][t_rCoordsID[i]] = -c;
                t_C[c][1]  = min(t_C[c][0], t_C[c][3]);
                t_C[c][4]  = min(t_C[c][12], t_C[c][0]);
            }
        }
        else if (templ == 2)
        {
            // Main variables
            t_nPts  = 12-4;
            t_nElem = 7;

            if (S[0]*S[2] > 0 or S[1]*S[3] > 0) // Template 2b
            {
                // Coordinates and connectivity
                t_rCoordsID = {1,
                               4,5,6,
                               9,10,11,
                               14};
                t_connec = {-1,0,1,2,
                            0,-2,2,3,
                            1,2,-3,4,
                            2,3,4,5,
                            3,-2,5,6,
                            4,5,-3,7,
                            5,6,7,-4};
                t_repeated = {0,6,7,1};
                t_map = {-1,0,-10,-2,
                         1,2,3,-10,
                         -10,4,5,6,
                         -3,-10,7,-4};

                // Rotation
                if (S[0] == 0)
                    rot = 1;
                if (rot > 0)
                {
                    std::rotate(S.begin(),S.begin()+rot,S.end());
                    for (size_t i = 0; i < C.size(); i++)
                        std::rotate(C[i].begin(),C[i].begin()+rot,C[i].end());
                }

                // Subdivision levels
                t_S.resize(16, 0);
                t_S[0]  = max(S[0]-1,0);
                t_S[15] = max(S[2]-1,0);

                // Creases
                for (size_t c = 0; c < C.size(); c++)
                {
                    // Corners
                    t_C[c][0]  = C[c][0];
                    t_C[c][3]  = C[c][1];
                    t_C[c][15] = C[c][2];
                    t_C[c][12] = C[c][3];

                    // Other
                    for (int i = 0; i < t_nPts; i++)
                        t_C[c][t_rCoordsID[i]] = -c;
                    t_C[c][1]  = min(t_C[c][0], t_C[c][3]);
                    t_C[c][11] = min(t_C[c][3], t_C[c][15]);
                    t_C[c][14] = min(t_C[c][15], t_C[c][12]);
                    t_C[c][4]  = min(t_C[c][12], t_C[c][0]);
                }
            }
            else // Template 2a
            {
                // Coordinates and connectivity
                t_rCoordsID = {1,2,
                               4,5,6,7,
                               9,10};
                t_connec = {-1,0,2,3,
                            0,1,3,4,
                            1,-2,4,5,
                            2,3,-3,6,
                            3,4,6,7,
                            4,5,7,-4,
                            6,7,-3,-4};
                t_repeated = {0,1,5,2};
                t_map = {-1,0,1,-2,
                         2,3,4,5,
                         -10,6,7,-10,
                         -3,-10,-10,-4};

                // Rotation
                if (S[1] > 0 and S[2] > 0)
                    rot = 1;
                else if (S[2] > 0 and S[3] > 0)
                    rot = 2;
                else if (S[3] > 0 and S[0] > 0)
                    rot = 3;
                if (rot > 0)
                {
                    std::rotate(S.begin(),S.begin()+rot,S.end());
                    for (size_t i = 0; i < C.size(); i++)
                        std::rotate(C[i].begin(),C[i].begin()+rot,C[i].end());
                }

                // Subdivision levels
                t_S.resize(4, 0);
                t_S[0]  = max(S[0]-1,0);
                t_S[3]  = max(S[1]-1,0);
                t_S[1]  = min(t_S[0], t_S[3]);
                t_S[2]  = min(t_S[0], t_S[3]);

                // Creases
                for (size_t c = 0; c < C.size(); c++)
                {
                    // Corners
                    t_C[c][0]  = C[c][0];
                    t_C[c][3]  = C[c][1];
                    t_C[c][15] = C[c][2];
                    t_C[c][12] = C[c][3];

                    // Other
                    for (int i = 0; i < t_nPts; i++)
                        t_C[c][t_rCoordsID[i]] = -c;
                    t_C[c][1] = min(t_C[c][0],  t_C[c][3]);
                    t_C[c][2] = min(t_C[c][0],  t_C[c][3]);
                    t_C[c][7] = min(t_C[c][3],  t_C[c][15]);
                    t_C[c][4] = min(t_C[c][12], t_C[c][0]);
                }
            }
        }
        else if (templ == 3)
        {
            // Main variables
            t_nPts  = 14-4;
            t_nElem = 8;

            // Coordinates and connectivity
            t_rCoordsID = {1,2,
                           4,5,6,7,
                           9,10,11,
                           14};
            t_connec = {-1,0,2,3,
                        0,1,3,4,
                        1,-2,4,5,
                        2,3,-3,6,
                        3,4,6,7,
                        4,5,7,8,
                        6,7,-3,9,
                        7,8,9,-4};
            t_repeated = {0,1,5,8,9,2};
            t_map = {-1,0,1,-2,
                     2,3,4,5,
                     -10,6,7,8,
                     -3,-10,9,-4};

            // Rotation
            if (S[0] == 0)
                rot = 1;
            else if (S[1] == 0)
                rot = 2;
            else if (S[2] == 0)
                rot = 3;
            if (rot > 0)
            {
                std::rotate(S.begin(),S.begin()+rot,S.end());
                for (size_t i = 0; i < C.size(); i++)
                    std::rotate(C[i].begin(),C[i].begin()+rot,C[i].end());
            }

            // Subdivision levels
            t_S.resize(16, 0);
            t_S[0]  = max(S[0]-1,0);
            t_S[3]  = max(S[1]-1,0);
            t_S[15] = max(S[2]-1,0);
            t_S[1]  = min(t_S[0], t_S[3]);
            t_S[2]  = min(t_S[0], t_S[3]);
            t_S[7]  = min(t_S[3], t_S[15]);
            t_S[11] = min(t_S[3], t_S[15]);

            // Creases
            for (size_t c = 0; c < C.size(); c++)
            {
                // Corners
                t_C[c][0]  = C[c][0];
                t_C[c][3]  = C[c][1];
                t_C[c][15] = C[c][2];
                t_C[c][12] = C[c][3];

                // Other
                for (int i = 0; i < t_nPts; i++)
                    t_C[c][t_rCoordsID[i]] = -c;
                t_C[c][1]  = min(t_C[c][0], t_C[c][3]);
                t_C[c][2]  = min(t_C[c][0], t_C[c][3]);
                t_C[c][7]  = min(t_C[c][3], t_C[c][15]);
                t_C[c][11] = min(t_C[c][3], t_C[c][15]);
                t_C[c][14] = min(t_C[c][15], t_C[c][12]);
                t_C[c][4]  = min(t_C[c][12], t_C[c][0]);
            }
        }
        else if (templ == 4)
        {
            // Main variables
            // t_nPts  = 16;
            t_nPts  = 16-4;
            t_nElem = 9;
            t_rCoordsID = {1,2,
                           4,5,6,7,
                           8,9,10,11,
                           13,14};
            t_repeated = {0,1,5,9,10,11,6,2};
            t_connec = {-1,0,2,3,
                        0,1,3,4,
                        1,-2,4,5,
                        2,3,6,7,
                        3,4,7,8,
                        4,5,8,9,
                        6,7,-3,10,
                        7,8,10,11,
                        8,9,11,-4};
            t_map = {-1,0,1,-2,
                     2,3,4,5,
                     6,7,8,9,
                     -3,10,11,-4};

            // Subdivision levels
            t_S.resize(t_nPts+4, 0);
            t_S[0]  = max(S[0]-1,0);
            t_S[3]  = max(S[1]-1,0);
            t_S[15] = max(S[2]-1,0);
            t_S[12] = max(S[3]-1,0);
            t_S[1]  = min(t_S[0], t_S[3]);
            t_S[2]  = min(t_S[0], t_S[3]);
            t_S[7]  = min(t_S[3], t_S[15]);
            t_S[11] = min(t_S[3], t_S[15]);
            t_S[14] = min(t_S[15], t_S[12]);
            t_S[13] = min(t_S[15], t_S[12]);
            t_S[8]  = min(t_S[12], t_S[0]);
            t_S[4]  = min(t_S[12], t_S[0]);
            t_S[5]  = min({t_S[0], t_S[3], t_S[15], t_S[12]});
            t_S[6]  = min({t_S[0], t_S[3], t_S[15], t_S[12]});
            t_S[9]  = min({t_S[0], t_S[3], t_S[15], t_S[12]});
            t_S[10] = min({t_S[0], t_S[3], t_S[15], t_S[12]});

            // Creases
            for (size_t c = 0; c < C.size(); c++)
            {
                // Corners
                t_C[c][0]  = C[c][0];
                t_C[c][3]  = C[c][1];
                t_C[c][15] = C[c][2];
                t_C[c][12] = C[c][3];

                // Other
                for (int i = 0; i < t_nPts; i++)
                    t_C[c][t_rCoordsID[i]] = -c;
                t_C[c][1]  = min(t_C[c][0], t_C[c][3]);
                t_C[c][2]  = min(t_C[c][0], t_C[c][3]);
                t_C[c][7]  = min(t_C[c][3], t_C[c][15]);
                t_C[c][11] = min(t_C[c][3], t_C[c][15]);
                t_C[c][14] = min(t_C[c][15], t_C[c][12]);
                t_C[c][13] = min(t_C[c][15], t_C[c][12]);
                t_C[c][8]  = min(t_C[c][12], t_C[c][0]);
                t_C[c][4]  = min(t_C[c][12], t_C[c][0]);
            }
        }

        // Rotate
        if (rot != 0)
        {
            // Compute rotated order
            vector<int> rOrder;
            if (rot == 1)
                rOrder = {3,7,11,15,
                          2,6,10,14,
                          1,5,9,13,
                          0,4,8,12};
            else if (rot == 2)
                rOrder = {15,14,13,12,
                          11,10,9,8,
                          7,6,5,4,
                          3,2,1,0};
            else if (rot == 3)
                rOrder = {12,8,4,0,
                          13,9,5,1,
                          14,10,6,2,
                          15,11,7,3};

            // Rotate rCoords
            for (int i = 0; i < t_nPts; i++)
                t_rCoordsID[i] = rOrder[t_rCoordsID[i]];

            // Compute rotated corners
            vector<int> rotCorners;
            if (rot == 1)
                rotCorners = {-2,-4,-1,-3};
            else if (rot == 2)
                rotCorners = {-4,-3,-2,-1};
            else if (rot == 3)
                rotCorners = {-3,-1,-4,-2};

            // Rotate corners in connectivity
            for (size_t i = 0; i < t_connec.size(); i++)
                if (t_connec[i] < 0)
                    t_connec[i] = rotCorners[-t_connec[i]-1];

            // Rotate corners in map
            for (size_t i = 0; i < t_map.size(); i++)
                if (t_map[i] < 0)
                    t_map[i] = rotCorners[-t_map[i]-1];
        }

        // // Correct first creases (only values of 1 are allowed) //FIXME: Error in creases if one element only
        // for (size_t i = 0; i < t_C[0].size(); i++)
        // {
        //     if (t_C[0][i] > 1)
        //         t_C[0][i] = 1;
        // }

        // Remove repeated nodes that are creases
        for (size_t i = 0; i < t_C[0].size(); i++)
        {
            if (t_C[0][i] > 0)
            {
                std::vector<int>::iterator it = find(t_repeated.begin(), t_repeated.end(), t_map[i]);
                if (it != t_repeated.end())
                    t_repeated.erase(it);
            }
        }
    }
    
    void templateHRefinement_2D(int &t_nPts, int &t_nElem, vector<int> &t_rCoordsID, vector<int> &t_connec, vector<vector<int>> &t_C, vector<int> &t_S, vector<int> &t_repeated, vector<int> &t_map, vector<int> S, vector<vector<int>> C)
    {
        // Check
        if (C.size() != 2)
            throw runtime_error("StructMeshGenerator_TransformationsFE::templateHRefinement_2D: Only implemented for 2 creases.");

        int nPts = S.size();
        // Linear basis functions
        if (nPts == 4)
        {
            // Reorder nodal subdivision levels and creases counter-clock-wise
            swap(S[2], S[3]); 
            for (size_t d = 0; d < C.size(); d++)
                swap(C[d][2], C[d][3]); 

            // Initialize
            int templ{}, rot{};
            for (auto s: S)
                if (s > 0)
                    templ++;
            t_C.resize(C.size());
            for (size_t c = 0; c < C.size(); c++)
                t_C[c].resize(9,-2);

            // Select template
            if (templ == 0)
            {
                // Main variables
                t_nPts  = 4-4;
                t_nElem = 1;
                t_connec = {-1,-2,-3,-4};
                t_map = {-1,-10,-2,
                        -10,-10,-10,
                        -3,-10,-4};

                // Creases
                for (size_t c = 0; c < C.size(); c++)
                {
                    t_C[c][0] = C[c][0];
                    t_C[c][2] = C[c][1];
                    t_C[c][8] = C[c][2];
                    t_C[c][6] = C[c][3];
                }
            }
            else
            {
                // Main variables
                t_nPts  = 9-4;
                t_nElem = 4;
                t_rCoordsID = {1,
                            3,4,5,
                            7};
                t_repeated = {0,3,4,1};
                t_connec = {-1,0,1,2,
                            0,-2,2,3,
                            1,2,-3,4,
                            2,3,4,-4};
                t_map = {-1,0,-2,
                        1,2,3,
                        -3,4,-4};

                // Subdivision levels
                t_S.resize(t_nPts+4, 0);
                t_S[0] = max(S[0]-1,0);
                t_S[2] = max(S[1]-1,0);
                t_S[8] = max(S[2]-1,0);
                t_S[6] = max(S[3]-1,0);
                t_S[1] = min(t_S[0], t_S[2]);
                t_S[5] = min(t_S[2], t_S[8]);
                t_S[7] = min(t_S[8], t_S[6]);
                t_S[3] = min(t_S[6], t_S[0]);
                t_S[4] = min({t_S[0], t_S[2], t_S[8], t_S[6]});

                // Creases
                for (size_t c = 0; c < C.size(); c++)
                {
                    // Corners
                    t_C[c][0] = C[c][0];
                    t_C[c][2] = C[c][1];
                    t_C[c][8] = C[c][2];
                    t_C[c][6] = C[c][3];

                    // Other
                    for (int i = 0; i < t_nPts; i++)
                        t_C[c][t_rCoordsID[i]] = -c;
                    t_C[c][1] = min(t_C[c][0], t_C[c][2]);
                    t_C[c][5] = min(t_C[c][2], t_C[c][8]);
                    t_C[c][7] = min(t_C[c][8], t_C[c][6]);
                    t_C[c][3] = min(t_C[c][6], t_C[c][0]);
                }
            }
        }
        else if (nPts == 9)
        {
            // Initialize
            int templ{};
            for (auto s: S)
            {
                if (s > 0)
                {
                    templ++;
                    break;
                }
            }
            t_C.resize(C.size());
            for (size_t c = 0; c < C.size(); c++)
                t_C[c].resize(25,-2);

            // Select template
            if (templ == 0)
            {
                // Main variables
                t_nPts  = 9-9;
                t_nElem = 1;
                t_connec = {-1,-2,-3,-4,-5,-6,-7,-8,-9};
                t_map = {-1,-10,-2,-10,-3,
                        -10,-10,-10,-10,-10,
                        -4,-10,-5,-10,-6,
                        -10,-10,-10,-10,-10,
                        -7,-10,-8,-10,-9};

                // Creases
                for (size_t c = 0; c < C.size(); c++)
                {
                    t_C[c][0] = C[c][0];
                    t_C[c][2] = C[c][1];
                    t_C[c][4] = C[c][2];
                    t_C[c][10] = C[c][3];
                    t_C[c][12] = C[c][4];
                    t_C[c][14] = C[c][5];
                    t_C[c][20] = C[c][6];
                    t_C[c][22] = C[c][7];
                    t_C[c][24] = C[c][8];
                }
            }
            else
            {
                // Main variables
                t_nPts  = 25-9;
                t_nElem = 4;
                t_rCoordsID = {1,3,
                               5,6,7,8,9,
                               11,13,
                               15,16,17,18,19,
                               21,23};
                t_repeated = {0,1,6,13,15,14,9,2};
                t_connec = {-1,0,-2,2,3,4,-4,7,-5,
                            -2,1,-3,4,5,6,-5,8,-6,
                            -4,7,-5,9,10,11,-7,14,-8,
                            -5,8,-6,11,12,13,-8,15,-9};
                t_map = {-1,0,-2,1,-3,
                         2,3,4,5,6,
                         -4,7,-5,8,-6,
                         9,10,11,12,13,
                         -7,14,-8,15,-9};

                // Subdivision levels
                t_S.resize(t_nPts+9, 0);
                t_S[0] = max(S[0]-1,0);
                t_S[2] = max(S[1]-1,0);
                t_S[4] = max(S[2]-1,0);
                t_S[10] = max(S[3]-1,0);
                t_S[12] = max(S[4]-1,0);
                t_S[14] = max(S[5]-1,0);
                t_S[20] = max(S[6]-1,0);
                t_S[22] = max(S[7]-1,0);
                t_S[24] = max(S[8]-1,0);
                t_S[1] = min(t_S[0], t_S[2]);
                t_S[3] = min(t_S[2], t_S[4]);
                t_S[5] = min(t_S[0], t_S[10]);
                t_S[7] = min(t_S[2], t_S[12]);
                t_S[9] = min(t_S[4], t_S[14]);
                t_S[11] = min(t_S[10], t_S[12]);
                t_S[13] = min(t_S[12], t_S[14]);
                t_S[15] = min(t_S[10], t_S[20]);
                t_S[17] = min(t_S[12], t_S[22]);
                t_S[19] = min(t_S[14], t_S[24]);
                t_S[21] = min(t_S[20], t_S[22]);
                t_S[23] = min(t_S[22], t_S[24]);
                t_S[6] = min({t_S[0], t_S[2], t_S[10], t_S[12]});
                t_S[8] = min({t_S[2], t_S[4], t_S[12], t_S[14]});
                t_S[16] = min({t_S[10], t_S[12], t_S[20], t_S[22]});
                t_S[18] = min({t_S[12], t_S[14], t_S[22], t_S[24]});

                // Creases
                for (size_t c = 0; c < C.size(); c++)
                {
                    // Corners
                    t_C[c][0] = C[c][0];
                    t_C[c][2] = C[c][1];
                    t_C[c][4] = C[c][2];
                    t_C[c][10] = C[c][3];
                    t_C[c][12] = C[c][4];
                    t_C[c][14] = C[c][5];
                    t_C[c][20] = C[c][6];
                    t_C[c][22] = C[c][7];
                    t_C[c][24] = C[c][8];

                    // Other
                    for (int i = 0; i < t_nPts; i++)
                        t_C[c][t_rCoordsID[i]] = -c;
                    t_C[c][1] = min(t_C[c][0], t_C[c][2]);
                    t_C[c][3] = min(t_C[c][2], t_C[c][4]);
                    t_C[c][5] = min(t_C[c][0], t_C[c][10]);
                    t_C[c][7] = min(t_C[c][2], t_C[c][12]);
                    t_C[c][9] = min(t_C[c][4], t_C[c][14]);
                    t_C[c][11] = min(t_C[c][10], t_C[c][12]);
                    t_C[c][13] = min(t_C[c][12], t_C[c][14]);
                    t_C[c][15] = min(t_C[c][10], t_C[c][20]);
                    t_C[c][17] = min(t_C[c][12], t_C[c][22]);
                    t_C[c][19] = min(t_C[c][14], t_C[c][24]);
                    t_C[c][21] = min(t_C[c][20], t_C[c][22]);
                    t_C[c][23] = min(t_C[c][22], t_C[c][24]);
                }
            }
        }
        // Remove repeated nodes that are creases
        for (size_t i = 0; i < t_C[0].size(); i++)
        {
            if (t_C[0][i] > 0)
            {
                std::vector<int>::iterator it = find(t_repeated.begin(), t_repeated.end(), t_map[i]);
                if (it != t_repeated.end())
                    t_repeated.erase(it);
            }
        }
    }

    void StructMeshGenerator::_threeRefine(map<int, int> nodeSubdivLevels)
    {
        using namespace MpiHelpers;

        // Checks
        if (_bfType != BasisFuncType::Lagrangian and _bfType != BasisFuncType::Linear)
            throw runtime_error("StructMeshGenerator::threeRefine: Only implemented for Linear and Lagrangian basis function types");
        if (_eType != ElemType::Square)
            throw runtime_error("StructMeshGenerator::threeRefine: Only implemented for square elements.");
        if (_bfOrder != 1 and _bfOrder != 2)
            throw runtime_error("StructMeshGenerator::threeRefine: Only implemented for order 1 or 2.");
        if (_periodicInX or _periodicInY or _periodicInZ)
            throw runtime_error("StructMeshGenerator::threeRefine: Not implemented for periodic BCs");

        bool hR = 1;
        bool threeR = 0;
        // Create BasisFunctions for one element
        RCP<BasisFunctions> basisFunctions;
        if (_bfType == BasisFuncType::Linear)
            basisFunctions = rcp(new Linear);
        else if (_bfType == BasisFuncType::Lagrangian)
            basisFunctions = rcp(new Lagrangian);
        RCP<Epetra_LocalMap> OneMap = rcp(new Epetra_LocalMap(1, 0, *_epComm));
        Teuchos::RCP<Epetra_IntVector> _BFTags = rcp(new Epetra_IntVector(*OneMap));
        basisFunctions->setBasisFunctionTags(_BFTags);
        basisFunctions->setElementType(_eType);
        basisFunctions->setBasisFunctionOrder(_bfOrder);
        basisFunctions->Update();

        // Pre-compute basis functions for a fully refined element //FIXME: 3D & order > 2
        int n{};
        vector<vector<double>> bfs;
        if (threeR)
        {
            bfs.resize(16, vector<double>(_nVert));
            for (int j = 0; j < 4; j++)
            {
                double y = (-3.0 + 2.0*j)/3.0;
                for (int i = 0; i < 4; i++)
                {
                    double x = (-3.0 + 2.0*i)/3.0;
                    vector<double> rCoords = {x, y};
                    bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                    n++;
                }
            }
        }
        else if(hR)
        {
            if(_bfOrder == 1)
            {
                bfs.resize(9, vector<double>(_nVert));
                for (int j = 0; j < 3; j++)
                {
                    double y = (-1. + j);
                    for (int i = 0; i < 3; i++)
                    {
                        double x = (-1.0 + i);
                        vector<double> rCoords = {x, y};
                        bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                        n++; 
                    }
                }
            }
            else if(_bfOrder == 2)
            {
                bfs.resize(25, vector<double>(_nVert));
                for (int j = 0; j < 5; j++)
                {
                    double y = (-4.0 + 2.0*j)/4.0;
                    for (int i = 0; i < 5; i++)
                    {
                        double x = (-4.0 + 2.0*i)/4.0;
                        vector<double> rCoords = {x, y};
                        bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                        n++;
                    }
                }
            }
            
        }
        // Loop until all refinement is done
        bool subdivide{true};
        while (subdivide)
        {
            //*******************************************************************
            // [0] Initialize
            //*******************************************************************

            // Create nodeData
            RCP<FieldStruct> _nodeData = rcp(new FieldStruct("nodeData", _comm));
            _nodeData->setBlockMap(_disPts.map());
            // _nodeData->setBlockMap(_graph->map());
            _nodeData->setNFlds(_nDim);
            double *_tmp_distXnodes = _x_nodes.data();
            _nodeData->setDistFields(_tmp_distXnodes);
            // _nodeData->setDistFields(&*_x_nodes.data());
            _nodeData->Update();

            // Create creases
            RCP<IntFieldStruct> _nodeFlags = rcp(new IntFieldStruct("nodeFlags", _comm));
            _nodeFlags->setBlockMap(_disPts.map());
            // _nodeData->setBlockMap(_graph->map());
            _nodeFlags->setNFlds(_nCreases_tmp);
            int *_tmp_distCreases = _creases.data();
            _nodeFlags->setDistFields(_tmp_distCreases);
            // _nodeData->setDistFields(&*_x_nodes.data());
            _nodeFlags->Update();

            // Create and update ghosts on node data and flags
            vector<int> ghosts = _createNodeGhosts();
            _nodeData->UpdateGhosts(ghosts);
            _nodeFlags->UpdateGhosts(ghosts);

            // Save old data
            _saveMesh();
            DistributedData _disPts_tmp;
            _disPts_tmp.setLocNItem(_loc_nPts_tmp);
            _disPts_tmp.setNItem(0);
            _disPts_tmp.Update();
            map<int, int> nodeSubdivLevels_tmp = nodeSubdivLevels;
            nodeSubdivLevels.clear();

            // Get new number of nodes and elements
            int t_loc_nPts{}, t_loc_nElem{};
            for (int e = 0; e < _loc_nElem_tmp; e++)
            {
                // Get nodal subdivision level
                vector<int> S(_nVert);
                for (int i = 0; i < _nVert; i++)
                {
                    int n = _connec_tmp[e*_nVert+i];
                    std::map<int,int>::iterator it = nodeSubdivLevels_tmp.find(n);
                    if (it != nodeSubdivLevels_tmp.end())
                        S[i] = it->second;
                    else
                        S[i] = 0;
                }

                // Get info
                int t_nPts_e, t_nElem_e;
                if(threeR)
                    templateThreeRefinement_2D_preallocate(t_nPts_e, t_nElem_e, S);
                else if(hR)
                    templateHRefinement_2D_preallocate(t_nPts_e, t_nElem_e, S);
                // Update
                t_loc_nPts += t_nPts_e;
                t_loc_nElem += t_nElem_e;
            }
            _loc_nPts += t_loc_nPts;
            _loc_nElem = t_loc_nElem;

            // Update distribution
            _disPts.setLocNItem(_loc_nPts);
            _disPts.setNItem(0);
            _disPts.Update();
            _nPts = _disPts.nItem();
            _disElem.setLocNItem(_loc_nElem);
            _disElem.setNItem(0);
            _disElem.Update();
            _nElem = _disElem.nItem();

            // Preallocate _x_nodes
            _x_nodes.clear();
            _x_nodes.resize(_loc_nPts*_nDim);
            for (int i = 0; i < _loc_nPts_tmp; i++)
                for (int d = 0; d < _nDim; d++)
                    _x_nodes[_loc_nPts*d + i] = _x_nodes_tmp[_loc_nPts_tmp*d + i];

            // Preallocate connectivity, creases and element flags
            _connec.clear();
            _connec.resize(_loc_nElem*_nVert);
            _creases.resize(0);
            _creases.resize(_loc_nPts*_nCreases);
            _eflags.resize(0);
            _eflags.resize(_loc_nElem*_nEFlags, 0);

            // Declare ghost impostors for creases
            vector<int> gImp_creases;

            // Declare vectors and map for repeated nodes
            vector<int> i_repeated;
            vector<vector<double>> x_repeated;
            map<int,int> map_repeatedNodes;


            //*******************************************************************
            // [1] Refine elements and save repeated nodes
            //*******************************************************************

            // Loop through elements and refine once
            int loc_nPts{_loc_nPts_tmp};
            int loc_nElem{0};
            for (int e = 0; e < _loc_nElem_tmp; e++)
            {
                //*******************************************************************
                // [1.0] Get template
                //*******************************************************************

                // Get nodal subdivision level and creases
                vector<int> S(_nVert);
                vector<vector<int>> C(_nCreases_tmp, vector<int>(_nVert));
                for (int i = 0; i < _nVert; i++)
                {
                    // Initialize
                    int n = _connec_tmp[e*_nVert+i];

                    // Nodal subdivision levels
                    std::map<int,int>::iterator it = nodeSubdivLevels_tmp.find(n);
                    if (it != nodeSubdivLevels_tmp.end())
                        S[i] = it->second;
                    else
                        S[i] = 0;

                    // Creases
                    for (int d = 0; d < _nCreases; d++)
                        C[d][i] = _nodeFlags->getValue(d, n, IndexType::Global);
                }

                // Select template
                int t_nElem, t_nPts;
                vector<int> t_rCoordsID, t_connec, t_S, t_repeated, t_map;
                vector<vector<int>> t_C;
                if(threeR)
                    templateThreeRefinement_2D(t_nPts, t_nElem, t_rCoordsID, t_connec,
                                               t_C, t_S, t_repeated, t_map, S, C);
                else if(hR)
                    templateHRefinement_2D(t_nPts, t_nElem, t_rCoordsID, t_connec,
                                               t_C, t_S, t_repeated, t_map, S, C);
                //*******************************************************************
                // [1.1] Refine element
                //*******************************************************************

                // Get nbors
                vector<int> nbors(_nVert);
                for (int i = 0; i < _nVert; i++)
                    nbors[i] = _connec_tmp[e*_nVert+i];

                // Get corner nodes
                vector<int> corners(4);
                corners[0] = _connec_tmp[e*_nVert+0];
                corners[1] = _connec_tmp[e*_nVert+_bfOrder_tmp];
                corners[2] = _connec_tmp[e*_nVert+(_bfOrder_tmp+1)*(_bfOrder_tmp+1)-1-_bfOrder_tmp];
                corners[3] = _connec_tmp[e*_nVert+(_bfOrder_tmp+1)*(_bfOrder_tmp+1)-1];

                // Relabel repeated nodes to global
                for (size_t i = 0; i < t_repeated.size(); i++)
                    t_repeated[i] += loc_nPts + _disPts.offs_nItem();

                // Add new x_nodes and save those that are repeated
                for (int i = 0; i < t_nPts; i++)
                {
                    // Get global node id
                    int loc_nodeIdx = i + loc_nPts;
                    int nodeIdx = loc_nodeIdx + _disPts.offs_nItem();

                    // Get basis function value
                    vector<double> bf = bfs[t_rCoordsID[i]];

                    // Compute coordinates
                    vector<double> xCoords(_nDim, 0.0);
                    for (int n = 0; n < _nVert; n++)
                    {
                        int nbor = nbors[n];
                        for (int d = 0; d < _nDim; d++)
                        {
                            double nborCoord = _nodeData->getValue(d, nbor, IndexType::Global);
                            xCoords[d] += nborCoord*bf[n];
                        }
                    }

                    // Check repeated nodes
                    bool rep = false;
                    vector<int>::iterator it = find(t_repeated.begin(), t_repeated.end(), nodeIdx);
                    if (it != t_repeated.end())
                    {
                        for (size_t j = 0; j < i_repeated.size(); j++)
                        {
                            vector<double> bCoords = x_repeated[j];
                            if (Math::Dist3D(bCoords.data(), xCoords.data()) < 1e-6)
                            {
                                // Save repeated node in map
                                map_repeatedNodes[*it] = i_repeated[j]; // slave, master

                                // Remove node and coordinates from vector
                                i_repeated.erase(i_repeated.begin()+j);
                                x_repeated.erase(x_repeated.begin()+j);

                                // Save and break loop
                                rep = true;
                                break;
                            }
                        }
                        if (rep == false)
                        {
                            i_repeated.push_back(*it);
                            x_repeated.push_back(xCoords);
                        }
                    }

                    // Add to x_nodes
                    for (int d = 0; d < _nDim; d++)
                        _x_nodes[_loc_nPts*d + loc_nodeIdx] = xCoords[d];
                }

                // Add new connectivity
                for (int t_e = 0; t_e < t_nElem; t_e++)
                {
                    for (int n = 0; n < _nVert; n++)
                    {
                        int node = t_connec[t_e*_nVert+n];
                        if (node < 0)
                        {
                            node = nbors[-node-1];
                            int part = _disPts_tmp.getItemPartition(node);
                            node = node - _disPts_tmp.offs_nItem(part) + _disPts.offs_nItem(part);
                        }
                        else
                        {
                            node += loc_nPts + _disPts.offs_nItem();
                        }
                        _connec[(loc_nElem+t_e)*_nVert+n] = node;
                    }
                }

                // Update creases
                for (size_t i = 0; i < t_C[0].size(); i++)
                {
                    if (t_C[0][i] != -2 or t_C[1][i] != -2)
                    {
                        // Get node id
                        int node = t_map[i];
                        if (node < 0)
                        {
                            node = nbors[-node-1];
                            int part = _disPts_tmp.getItemPartition(node);
                            node = node - _disPts_tmp.offs_nItem(part) + _disPts.offs_nItem(part);
                        }
                        else
                        {
                            node += loc_nPts + _disPts.offs_nItem();
                        }

                        // Correct value
                        if (t_C[0][i] == -2)
                            t_C[0][i] = 0;
                        if (t_C[1][i] == -2)
                            t_C[1][i] = -1;

                        // Save the value
                        if (_disPts.isItemInPart(node))
                        {
                            int loc_node = node - _disPts.offs_nItem();
                            for (int d = 0; d < _nCreases_tmp; d++)
                                _creases[_loc_nPts*d + loc_node] = t_C[d][i];
                        }
                        else
                        {
                            // Check if the impostor was already there
                            bool found{false};
                            for (size_t i = 0; i < gImp_creases.size()/(_nCreases_tmp+1); i++)
                            {
                                if (gImp_creases[(_nCreases+1)*i] == node)
                                    found = true;
                            }

                            // Add impostor
                            if (!found)
                            {
                                vector<int> vInsert(1+_nCreases_tmp);
                                vInsert[0] = node;
                                for (int d = 0; d < _nCreases_tmp; d++)
                                    vInsert[1+d] = t_C[d][i];
                                gImp_creases.insert(gImp_creases.end(), vInsert.begin(), vInsert.end());
                            }
                        }
                    }
                }

                // Update nodal subdivision levels
                for (size_t i = 0; i < t_S.size(); i++)
                {
                    if (t_S[i] > 0)
                    {
                        int node = t_map[i];
                        if (node < 0)
                        {
                            node = nbors[-node-1];
                            int part = _disPts_tmp.getItemPartition(node);
                            node = node - _disPts_tmp.offs_nItem(part) + _disPts.offs_nItem(part);
                        }
                        else
                        {
                            node += loc_nPts + _disPts.offs_nItem();
                        }
                        nodeSubdivLevels[node] = t_S[i];
                    }
                }

                // Update element flags
                for (int i = 0; i < t_nElem; i++)
                {
                    for (int d = 0; d < _nEFlags; d++)
                        _eflags[_loc_nElem*d + i+loc_nElem] = _eflags_tmp[_loc_nElem_tmp*d + e];
                }

                // Update number of nodes and elements
                loc_nPts  += t_nPts;
                loc_nElem += t_nElem;
            }


            //*******************************************************************
            // [2] Share ghost impostors for creases
            //*******************************************************************

            // Share local impostors
            vector<int> glob_gImp_creases = allgatherv(gImp_creases, _numProcs, _myRank);

            // Impose impostor creases
            for (size_t i = 0; i < glob_gImp_creases.size()/(_nCreases_tmp+1); i++)
            {
                int node = glob_gImp_creases[(_nCreases+1)*i];
                if (_disPts.isItemInPart(node))
                {
                    int loc_node = node - _disPts.offs_nItem();
                    for (int d = 0; d < _nCreases_tmp; d++)
                        _creases[_loc_nPts*d + loc_node] = glob_gImp_creases[(_nCreases+1)*i+1+d];
                }
            }


            //*******************************************************************
            // [3] Share repeated nodes
            //*******************************************************************

            // Rearrange map of repeated nodes into a vector
            vector<int> vec_repeatedNodes(map_repeatedNodes.size()*2);
            int n{};
            for (auto const& m : map_repeatedNodes)
            {
                vec_repeatedNodes[2*n] = m.first;
                vec_repeatedNodes[2*n+1] = m.second;
                n++;
            }

            // Share vector of repeated nodes
            vector<int> glob_vec_repeatedNodes = allgatherv(vec_repeatedNodes, _numProcs, _myRank);

            // Rearrange vector of repeated nodes into a map
            map_repeatedNodes.clear();
            for (size_t i = 0; i < glob_vec_repeatedNodes.size()/2; i++)
                map_repeatedNodes.emplace(glob_vec_repeatedNodes[2*i], glob_vec_repeatedNodes[2*i+1]);


            //*******************************************************************
            // [4] Remove repeated nodes across partitions
            //*******************************************************************

            // Share repeated node ids
            vector<int> glob_i_repeated = allgatherv(i_repeated, _numProcs, _myRank);

            // Rearrange repeated nodes coordinates
            vector<double> coord_repeated(x_repeated.size()*_nDim);
            n = 0;
            for (size_t i = 0; i < x_repeated.size(); i++)
            {
                for (int j = 0; j < _nDim; j++)
                {
                    coord_repeated[n] = x_repeated[i][j];
                    n++;
                }
            }

            // Share repeated node coordinates
            vector<double> glob_x_repeated = allgatherv(coord_repeated, _numProcs, _myRank);

            // Initialize original index locations
            int n_rep = static_cast<int> (glob_i_repeated.size());
            vector<size_t> idx(n_rep);
            iota(idx.begin(), idx.end(), 0);

            // Sort indexes based on coords order
            stable_sort(idx.begin(), idx.end(),
                        [&glob_x_repeated](size_t i1, size_t i2) {
                            if (glob_x_repeated[i1*3+0] != glob_x_repeated[i2*3+0])
                                return glob_x_repeated[i1*3+0] < glob_x_repeated[i2*3+0];
                            if (glob_x_repeated[i1*3+1] != glob_x_repeated[i2*3+1])
                                return glob_x_repeated[i1*3+1] < glob_x_repeated[i2*3+1];
                            return glob_x_repeated[i1*3+2] < glob_x_repeated[i2*3+2];
                        });

            // Save repeated nodes, knowing that they are ordered according to idx
            for (int i = 0; i < n_rep-1; i++)
            {
                // First coord
                int i1 = idx[i];
                vector<double> coords1(glob_x_repeated.begin()+3*i1, glob_x_repeated.begin()+3*i1+3);

                // Second coords
                int j{1};
                bool found{true};
                while (found and i+j != n_rep)
                {
                    int i2 = idx[i+j];
                    vector<double> coords2(glob_x_repeated.begin()+3*i2, glob_x_repeated.begin()+3*i2+3);
                    if (Math::Dist3D(coords1.data(), coords2.data()) < 1e-6)
                        map_repeatedNodes[glob_i_repeated[i1]] = glob_i_repeated[i2];
                    else
                        found = false;
                    j++;
                }
            }

            // Remove repeated nodes within processor
            _removeRepeatedNodes(map_repeatedNodes);


            //*******************************************************************
            // [5] Update nodal subdivision levels
            //*******************************************************************

            // Shift subdivision levels
            nodeSubdivLevels_tmp = nodeSubdivLevels;
            nodeSubdivLevels.clear();
            map<int,int>::reverse_iterator rit;
            for (map<int,int>::iterator it = nodeSubdivLevels_tmp.begin(); it != nodeSubdivLevels_tmp.end(); ++it)
            {
                int node = it->first;

                // Check if node is repeated
                map<int,int>::iterator mit = map_repeatedNodes.find(node);
                if (mit != map_repeatedNodes.end())
                    node = mit->second;

                // Get shifts of this processor
                int j{};
                for (rit = map_repeatedNodes.rbegin(); rit != map_repeatedNodes.rend(); ++rit)
                {
                    if (node > rit->first)
                        break;
                    j++;
                }
                j = map_repeatedNodes.size()-j;

                nodeSubdivLevels[node-j] = it->second;
            }

            // Check if subdivide again
            int nSub = nodeSubdivLevels.size();
            MPI_Allreduce(&nSub, &nSub, 1, MPI_INT, MPI_MAX, _comm);
            subdivide = nSub;
        }

        if (false)
        {
            if (_myRank == 0)
                cout << "checking" << endl;
            vector<double> x_nodes(_loc_nPts*3);
            for (int i = 0; i < _loc_nPts; i++)
            {
                x_nodes[i*3+0] = _x_nodes[_loc_nPts*0+i];
                x_nodes[i*3+1] = _x_nodes[_loc_nPts*1+i];
                x_nodes[i*3+2] = _x_nodes[_loc_nPts*2+i];
            }

            // Share x_nodes
            vector<double> glob_x_nodes = allgatherv(x_nodes, _numProcs, _myRank);

            // Save repeated nodes
            int n = glob_x_nodes.size()/3;
            for (int i = 0; i < n; i++)
            {
                vector<double> coords1(3, 0.0);
                coords1[0] = glob_x_nodes[3*i+0];
                coords1[1] = glob_x_nodes[3*i+1];
                coords1[2] = glob_x_nodes[3*i+2];
                for (int j = i+1; j < n; j++)
                {
                    vector<double> coords2(3, 0.0);
                    coords2[0] = glob_x_nodes[3*j+0];
                    coords2[1] = glob_x_nodes[3*j+1];
                    if (Math::Dist3D(coords1.data(), coords2.data()) < 1e-6)
                    {
                        if (_myRank == 0)
                            cout << "        " << i << " <--> " << j << endl;
                    }
                }
            }
            if (_myRank == 0)
                cout << "checking done" << endl;
        }

        if (false)
        {

            // Share connectivity
            vector<int> glob_connec = allgatherv(_connec, _numProcs, _myRank);

            // Iterate over the vector and store the frequency of each element in map
            std::map<int, int> countMap;
            for (auto &c: glob_connec)
            {
                auto result = countMap.insert(std::pair<int, int>(c, 1));
                if (result.second == false)
                    result.first->second++;
            }

            // Iterate over the map
            for (auto &c: countMap)
            {
                if (_disPts.isItemInPart(c.first))
                {
                    int loc_node = c.first - _disPts.offs_nItem();
                    if (_creases[_loc_nPts*0 + loc_node] == 0 and c.second < 3)
                    {
                        std::cout << "  " << c.first << " :: " << c.second << std::endl;
                    }
                }
            }
        }

        return;
    }
 

    void StructMeshGenerator::threeRefine(map<int, int> nodeSubdivLevels, IndexType idxType)
    {
        if (idxType == IndexType::Global)
        {
            _threeRefine(nodeSubdivLevels);
        }
        else
        {
            // Save subdivision levels (in global coordinates) that are in this partition
            map<int, int> nodeSubdivLevels_new;
            for (auto it = nodeSubdivLevels.begin(); it != nodeSubdivLevels.end(); it++)
            {
                int glob_idx = it->first + _disPts.offs_nItem();
                if (_disPts.isItemInPart(glob_idx))
                    nodeSubdivLevels_new.emplace(glob_idx, it->second);
            }

            // Create and share ghosts
            vector<int> ghosts = _createNodeGhosts();
            vector<int> shared_ghosts = MpiHelpers::allgatherv(ghosts, _numProcs, _myRank);

            // Save node subdivision levels that are ghosts to other partitions
            vector<int> nSL_ghosts;
            for (auto it = nodeSubdivLevels_new.begin(); it != nodeSubdivLevels_new.end(); it++)
            {
                if (find(shared_ghosts.begin(), shared_ghosts.end(), it->first) != shared_ghosts.end())
                    nSL_ghosts.insert(nSL_ghosts.end(), {it->first, it->second});
            }

            // Share node subdivision levels ghosts and rearrange in map
            vector<int> shared_nSL_ghosts = MpiHelpers::allgatherv(nSL_ghosts, _numProcs, _myRank);
            map<int, int> nodeSubdivLevels_ghosts;
            for (size_t i = 0; i < shared_nSL_ghosts.size()/2; i++)
                nodeSubdivLevels_ghosts.emplace(shared_nSL_ghosts[2*i], shared_nSL_ghosts[2*i+1]);

            // Save nodal subdivision levels of the ghosts
            for (auto g: ghosts)
            {
                auto it = nodeSubdivLevels_ghosts.find(g);
                if (it != nodeSubdivLevels_ghosts.end())
                    nodeSubdivLevels_new.emplace(it->first, it->second);
            }

            // Refine
            _threeRefine(nodeSubdivLevels_new);
        }
    }
    
    void StructMeshGenerator::_hangingNodesConstraints()
    {
        // Create a vector of vectors of connectivity-> _nConnec[node] = elems connected to node
        vector<vector<int>> _nConnec(_nPts);
        for (int e = 0; e < _loc_nElem; e++)
        {
            for (int i = 0; i < _nVert; i++)
            {
                int nbor = _connec[e*_nVert+i];
                _nConnec[nbor].push_back(e);
            }
        }

        // Gather from all threads
        for (int n = 0; n < _nPts; n++)
        {
            vector<int> loc_nodeConnec = _nConnec[n];
            vector<int> nodeConnec = MpiHelpers::allgatherv(loc_nodeConnec, _numProcs, _myRank);
            _nConnec[n] = nodeConnec;
        }
        
        int nHanging = 0;
        int nConnec1 = 0;
        int nElems1 = 0;
        // Loop for every node to see if hanging, then apply constraints
        for (int n = 0; n < _nPts; n++)
        {
            int locN = _disPts.locIdx(n);
            // Check the current nodes is hanging
            switch(_bfOrder)
            {
            case 1:
                if (_nConnec[n].size() == 2 && _creases[locN] == 0)
                {
                    // Find the two master nodes
                    int el0 = _nConnec[n][0];
                    int el1 = _nConnec[n][1];
                    vector<int> nbors0(_nVert);
                    vector<int> nbors1(_nVert);
                    int locEl0 = _disElem.locIdx(el0);
                    int locEl1 = _disElem.locIdx(el1);
                    for (int i = 0; i < _nVert; i++)
                    {
                        nbors0[i] = (_connec[el0*_nVert+i]);
                        nbors1[i] = (_connec[el1*_nVert+i]);
                    } 
                    vector<int> nH(2); // Hanging node internal position for element
                    vector<int> nM(2); // Master nodes
                    vector<int> nSh(2); // Shared nodes position
                    // Obtain position of hangin nodes
                    for (int i = 0; i < _nVert; i++)
                    {
                        if (nbors0[i] == n)
                            nH[0] = i;
                        else
                        {
                            for (int j = 0; j < _nVert; j++)
                            {
                                if (nbors0[i] == nbors1[j])
                                {
                                    nSh[0] = i;
                                    nSh[1] = j;
                                }
                            }
                        }
                        if (nbors1[i] == n)
                            nH[1] = i;
                    }
                    for (int j = 0; j < 2; j++)
                    {
                        if(nH[j] == 0 || nH[j] == 3)
                        {
                            if (nSh[j] == 2)
                                nM[j] = 1;
                            else
                                nM[j] = 2;
                        }
                        else if(nH[j] == 1 || nH[j] == 2)
                        {
                            if (nSh[j] == 0)
                                nM[j] = 3;
                            else
                                nM[j] = 0; 
                        }
                    }

                    int node0 = _connec[locEl0*_nVert+nM[0]];
                    int node1 = _connec[locEl1*_nVert+nM[1]]; 
                    // Apply the linear constraint
                    _linearConstraints.push_back({n, {node0,node1}, {0.5,0.5}, 0.0});
                }
                break;
            case 2:
                if (_nConnec[n].size() == 1 && _creases[locN] == 0)
                {
                    nConnec1++;
                    // Find the three master nodes
                    int el = _nConnec[n][0];
                    vector<int> nbors(_nVert);
                    int locEl = _disElem.locIdx(el);
                    for (int i = 0; i < _nVert; i++)
                        nbors[i] = (_connec[el*_nVert+i]);

                    int nH = -1; // Hanging node internal position for element
                    vector<int> nM(3); // Master nodes

                    // Obtain position of hanging nodes
                    for (int i = 0; i < _nVert; i++)
                    {
                        if (nbors[i] == n)
                        {
                            nH = i;
                            break;
                        }
                    }
                    if (nH != 4)
                    {
                        switch (nH)
                        {
                        case 1:
                            nM[0] = 0;
                            nM[1] = 2;
                            break;
                        case 5:
                            nM[0] = 2;
                            nM[1] = 8;
                            break;
                        case 7:
                            nM[0] = 6;
                            nM[1] = 8;
                            break;
                        case 3:
                            nM[0] = 0;
                            nM[1] = 6;
                            break;                      
                        default:
                            cout << "WARING: This node should not be a hanging node" << endl;
                            break;
                        }

                        
                        int node0 = _connec[locEl*_nVert+nM[0]];
                        int node1 = _connec[locEl*_nVert+nM[1]]; 

                        if (_nConnec[node1].size() == 3 && _creases[node1] == 0)
                            swap(node1,node0);
                        
                        vector<int> nConn0 = _nConnec[node0];
                        vector<int> nConn1 = _nConnec[node1];
                        nConn0.erase(find(nConn0.begin(), nConn0.end(), el));
                        nConn1.erase(find(nConn1.begin(), nConn1.end(), el));

                        int el1 = nConn0[1];
                        auto it1 = find(nConn1.begin(), nConn1.end(), nConn0[0]);
                        if (it1!=nConn1.end())
                            el1 = nConn0[0];
                        
                        vector<int> nbors1(_nVert);
                        int locEl1 = _disElem.locIdx(el1);
                        for (int i = 0; i < _nVert; i++)
                            nbors1[i] = (_connec[el1*_nVert+i]);
                        auto it = find(nbors1.begin(), nbors1.end(), node0);
                        int nPos0 = it - nbors1.begin();
                        int n2 = -1;
                        switch (nPos0)
                        {
                        case 1:
                            n2 = 0;
                            if (node1 == nbors1[0])
                                n2 = 2;
                            break;
                        case 3:
                            n2 = 0;
                            if (node1 == nbors1[0])
                                n2 = 6;
                            break;
                        case 5:
                            n2 = 2;
                            if (node1 == nbors1[2])
                                n2 = 8;
                            break;
                        case 7:
                            n2 = 6;
                            if (node1 == nbors1[6])
                                n2 = 8;
                            break;                      
                        default:
                            cout << "WARING: This node should not be a MASTER node" << endl;
                            break;
                        }

                        int node2 = _connec[locEl1*_nVert+n2]; 
                        // Apply the linear constraint
                        _linearConstraints.push_back({n, {node0,node1,node2}, {0.75,0.375,-0.125}, 0.0});
                        nHanging ++;
                    }
                    else
                        nElems1++;
                }
                break;
            }        
        }
    }

    void StructMeshGenerator::threeRefine(std::function<double(double, double, double)> fxyz, int maxSubdivisionLevel, vector<int> nSamplesDirLevel)
    {
        // Check
        if (nSamplesDirLevel.size() > 0 and static_cast<int>(nSamplesDirLevel.size()) < maxSubdivisionLevel-1)
            throw runtime_error("StructMeshGenerator::threeRefine: The size of nSamplesDirLevel should be equal to maxSubdivisionLevel-1.");

        // Create BasisFunctions for one element
        RCP<BasisFunctions> basisFunctions;
        if (_bfType == BasisFuncType::Linear)
            basisFunctions = rcp(new Linear);
        else if (_bfType == BasisFuncType::Lagrangian)
            basisFunctions = rcp(new Lagrangian);
        RCP<Epetra_LocalMap> OneMap = rcp(new Epetra_LocalMap(1, 0, *_epComm));
        Teuchos::RCP<Epetra_IntVector> _BFTags = rcp(new Epetra_IntVector(*OneMap));
        basisFunctions->setBasisFunctionTags(_BFTags);
        basisFunctions->setElementType(_eType);
        basisFunctions->setBasisFunctionOrder(_bfOrder);
        basisFunctions->Update();

        bool subdivide{true};
        for (int l = 1; subdivide; l++)
        {
            // Create nodeData
            RCP<FieldStruct> _nodeData = rcp(new FieldStruct("nodeData", _comm));
            _nodeData->setBlockMap(_disPts.map());
            // _nodeData->setBlockMap(_graph->map());
            _nodeData->setNFlds(_nDim);
            double *_tmp_distXnodes = _x_nodes.data();
            _nodeData->setDistFields(_tmp_distXnodes);
            // _nodeData->setDistFields(&*_x_nodes.data());
            _nodeData->Update();

            // Create and update ghosts on node data and flags
            vector<int> ghosts = _createNodeGhosts();
            _nodeData->UpdateGhosts(ghosts);

            // Pre-compute basis functions for a fully refined element //FIXME: 3D
            int n{};
            int nSamplesDir{};
            if (nSamplesDirLevel.size() > 0)
                nSamplesDir = nSamplesDirLevel.at(l-1);
            vector<vector<double>> bfs(nSamplesDir*nSamplesDir, vector<double>(_nVert));
            for (int j = 0; j < nSamplesDir; j++)
            {
                double y = (-(nSamplesDir-1) + 2.0*j)/nSamplesDir;
                for (int i = 0; i < nSamplesDir; i++)
                {
                    double x = (-(nSamplesDir-1) + 2.0*i)/nSamplesDir;
                    vector<double> rCoords = {x, y};
                    bfs[n] = basisFunctions->computeBasisFunctionsReference(rCoords, 0)[0];
                    n++;
                }
            }

            // Save vector of local node subdivision levels
            vector<int> vec_nSL;
            for (int e = 0; e < _loc_nElem; e++)
            {
                // Initialize
                bool refineElem{false};

                // Check corner points
                for (int i = 0; i < _nVert; i++)
                {
                    // Initialize
                    int nbor = _connec[e*_nVert+i];

                    double x = _nodeData->getValue(0, nbor, IndexType::Global);
                    double y = _nodeData->getValue(1, nbor, IndexType::Global);
                    double z = _nodeData->getValue(2, nbor, IndexType::Global);
                    double level = fxyz(x,y,z);
                    if (level >= l)
                    {
                        refineElem = true;
                        break;
                    }
                }

                // Check points inside the element
                if (!refineElem and nSamplesDir != 0)
                {
                    // Get neighbors
                    vector<int> nbors(_nVert);
                    for (int i = 0; i < _nVert; i++)
                        nbors[i] = _connec[e*_nVert+i];

                    // Loop over points
                    for (size_t j = 0; j < bfs.size(); j++)
                    {
                        // Compute coordinates
                        vector<double> xCoords(_nDim, 0.0);
                        for (int i = 0; i < _nVert; i++)
                        {
                            int nbor = nbors[i];
                            for (int d = 0; d < _nDim; d++)
                            {
                                double nborCoord = _nodeData->getValue(d, nbor, IndexType::Global);
                                xCoords[d] += nborCoord*bfs[j][i];
                            }
                        }

                        // Evaluate levels
                        double level = fxyz(xCoords[0],xCoords[1],xCoords[2]);
                        if (level >= l)
                        {
                            refineElem = true;
                            break;
                        }
                    }
                }

                // Refine all element to prevent inter-level overlap
                vector<int> S(_nVert, 0);
                if (refineElem)
                {
                    for (int i = 0; i < _nVert; i++)
                    {
                        int nbor = _connec[e*_nVert+i];
                        vec_nSL.push_back(nbor);
                    }
                }
            }

            // Remove repeated and share
            std::sort(vec_nSL.begin(), vec_nSL.end());
            vec_nSL.erase(std::unique(vec_nSL.begin(), vec_nSL.end()), vec_nSL.end());
            vector<int> glob_vec_nSL = MpiHelpers::allgatherv(vec_nSL, _numProcs, _myRank);

            // Stop if no more subdivisions are required
            if (glob_vec_nSL.size() == 0)
            {
                subdivide = false;
                break;
            }

            // Save global subdivision levels
            map<int,int> nodeSubdivLevels;
            for (auto c: glob_vec_nSL)
                nodeSubdivLevels[c] = 1;

            // Call refinement;
            // _threeRefine(nodeSubdivLevels);
            _threeRefine(nodeSubdivLevels);

            // Stop if reached the maximum subdivision level
            if (maxSubdivisionLevel > 0 and l == maxSubdivisionLevel)
                subdivide = false;
        }
        _hangingNodesConstraints();
    }
}
