/*
    *******************************************************************************
    Copyright (c) 2017-2024 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <stdexcept>
#include <iterator>
#include <fstream>

#include "hl_MeshLoader.h"
#include "hl_legIOAux.h"
#ifdef HL_VTK
#include "vtkUnstructuredGrid.h"
#include "vtkUnstructuredGridReader.h"
#include "vtkXMLPUnstructuredGridReader.h"
#include "vtkXMLUnstructuredGridReader.h"
#include "vtkXMLPolyDataReader.h"
#include "vtkXMLPPolyDataReader.h"
#include "vtkPolyData.h"
#include "vtkPointData.h"
#include "vtkCellData.h"


//Vtk
void hiperlife::MeshLoader::_serialVtkLoader()
{
    vtkSmartPointer<vtkUnstructuredGrid> unstructuredGrid = vtkSmartPointer<vtkUnstructuredGrid>::New();

    if (_name.find(".vtk") != std::string::npos)
    {
        vtkSmartPointer<vtkUnstructuredGridReader> reader = vtkSmartPointer<vtkUnstructuredGridReader>::New();
        reader->SetFileName(_name.c_str());
        reader->Update();
        unstructuredGrid = reader->GetOutput();
    }
    else if (_name.find(".vtu") != std::string::npos)
    {
        vtkSmartPointer<vtkXMLUnstructuredGridReader > reader = vtkSmartPointer<vtkXMLUnstructuredGridReader >::New();
        reader->SetFileName(_name.c_str());
        reader->Update();
        unstructuredGrid = reader->GetOutput();
    }
    else if (_name.find(".pvtu") != std::string::npos)
    {
        vtkSmartPointer<vtkXMLPUnstructuredGridReader > reader = vtkSmartPointer<vtkXMLPUnstructuredGridReader >::New();
        reader->SetFileName(_name.c_str());
        reader->Update();
        unstructuredGrid = reader->GetOutput();
    }
    else if (_name.find(".vtp") != std::string::npos)
    {
        vtkSmartPointer<vtkXMLPolyDataReader> reader = vtkSmartPointer<vtkXMLPolyDataReader>::New();
        reader->SetFileName(_name.c_str());
        reader->Update();

        vtkSmartPointer<vtkPolyData> polyData = vtkSmartPointer<vtkPolyData>::New();
        polyData = reader->GetOutput();

        unstructuredGrid->SetPoints(polyData->GetPoints());
        unstructuredGrid->GetPointData()->ShallowCopy(polyData->GetPointData());
        vtkSmartPointer<vtkCellArray> cells = polyData->GetPolys();
        cells->InitTraversal();
        vtkSmartPointer<vtkIdList> idList = vtkSmartPointer<vtkIdList>::New();
        while(cells->GetNextCell(idList))
            unstructuredGrid->InsertNextCell(VTK_TRIANGLE, idList);
    }
    else if (_name.find(".pvtp") != std::string::npos)
    {
        vtkSmartPointer<vtkXMLPPolyDataReader> reader = vtkSmartPointer<vtkXMLPPolyDataReader>::New();
        reader->SetFileName(_name.c_str());
        reader->Update();

        vtkSmartPointer<vtkPolyData> polyData = vtkSmartPointer<vtkPolyData>::New();
        polyData = reader->GetOutput();

        unstructuredGrid->SetPoints(polyData->GetPoints());
        unstructuredGrid->GetPointData()->ShallowCopy(polyData->GetPointData());
        vtkSmartPointer<vtkCellArray> cells = polyData->GetPolys();
        cells->InitTraversal();
        vtkSmartPointer<vtkIdList> idList = vtkSmartPointer<vtkIdList>::New();
        while(cells->GetNextCell(idList))
            unstructuredGrid->InsertNextCell(VTK_TRIANGLE, idList);
    }
    else
    {
        throw std::runtime_error("MeshLoader::_serialVtkLoader: The file extension is not supported.");
    }

    vtkPointData* pointData = unstructuredGrid->GetPointData();
    vtkDataArray* creasedArray{nullptr};

    if (pointData)
    {
        creasedArray = pointData->GetScalars("CreasesId");
        if (creasedArray)
        {
            int sizeCreases = creasedArray->GetNumberOfTuples();
            assert(sizeCreases == unstructuredGrid->GetNumberOfPoints());
        }
    }

    _nPts  = static_cast<int>(unstructuredGrid->GetNumberOfPoints());
    _nElem = static_cast<int>(unstructuredGrid->GetNumberOfCells());

    _glob_x_nodes.resize(_nPts*_nDim,0.0);
    _glob_creases.resize(_nPts*_nCreases,0);
    for (int i = 0; i < _nPts; i++)
    {
        double x[3];
        unstructuredGrid->GetPoint(i, x);
        _glob_x_nodes[_nDim*i+0] = x[0];
        _glob_x_nodes[_nDim*i+1] = x[1];
        _glob_x_nodes[_nDim*i+2] = x[2];

        if (creasedArray)
        {
            _glob_creases[_nCreases*i] = static_cast<int>(creasedArray->GetTuple1(i)+0.1);
        }
    }

    _glob_connec.resize(_nElem*_nVert,0);
    std::vector<int> reorder = vtkReordering(_eType, _bfType, _bfOrder);
    for (int i = 0; i < _nElem; i++)
    {
        vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
        unstructuredGrid->GetCellPoints(i, ptsIds);
        for (int k = 0; k < _nVert; k++)
        {
            _glob_connec[_nVert*i+k] = ptsIds->GetId(reorder[k]);
        }
    }

    _glob_eflags.resize(_nElem*_nEFlags,0);
}

#include "vtkDoubleArray.h"
#include "vtkLinearSubdivisionFilter.h"
void hiperlife::MeshLoader::_getHRefinedMesh_serial_triangles(int refLevel)
{
    if (myRank() == 0)
    {
        vtkSmartPointer<vtkPolyData> polyData =  vtkSmartPointer<vtkPolyData>::New();
        vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
        points->SetNumberOfPoints(_nPts);
        for (int i = 0; i < _nPts; i++)
        {
            points->SetPoint(i,_glob_x_nodes[_nDim*i+0],_glob_x_nodes[_nDim*i+1],_glob_x_nodes[_nDim*i+2]);
        }
        polyData->SetPoints(points);

        vtkSmartPointer<vtkCellArray> elems = vtkSmartPointer<vtkCellArray>::New();
        for (int e = 0; e < _nElem; e++)
        {
            vtkSmartPointer<vtkIdList> elem = vtkSmartPointer<vtkIdList>::New();

            for (int n = 0; n <_nVert; n++)
                elem->InsertNextId(_glob_connec[e*_nVert+n]);

            elems->InsertNextCell(elem);
        }
        polyData->SetPolys(elems);

        //Insert nodeFields
        vtkSmartPointer<vtkDoubleArray> vtknodeFields = vtkSmartPointer<vtkDoubleArray>::New();
        vtknodeFields->SetNumberOfComponents(1);
        vtknodeFields->SetNumberOfTuples(_nPts);
        vtknodeFields->SetName("Creases");
        vtkIdType n{};
        for (int i = 0; i < _nPts; i++)
        {
            vtknodeFields->SetValue(n,_glob_creases[_nCreases*i]);
            n++;
        }
        polyData->GetPointData()->AddArray(vtknodeFields);


        vtkSmartPointer<vtkLinearSubdivisionFilter> subdivisionFilter = vtkSmartPointer<vtkLinearSubdivisionFilter>::New();
        subdivisionFilter->SetInputData(polyData);
        subdivisionFilter->SetNumberOfSubdivisions(refLevel);
        subdivisionFilter->Update();

        polyData = subdivisionFilter->GetOutput();

        _nPts  = polyData->GetNumberOfPoints();
        _nElem = polyData->GetNumberOfCells();

        _glob_x_nodes.resize(_nPts*_nDim,0.0);
        for (int i = 0; i < _nPts; i++)
        {
            double x[3];
            polyData->GetPoint(i, x);

            _glob_x_nodes[_nDim*i+0] = x[0];
            _glob_x_nodes[_nDim*i+1] = x[1];
            _glob_x_nodes[_nDim*i+2] = x[2];
        }

        _glob_connec.resize(_nElem*_nVert,0);
        for (int i = 0; i < _nElem; i++)
        {
            vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
            polyData->GetCellPoints(i, ptsIds);
            _glob_connec[_nVert*i+0] = ptsIds->GetId(0);
            _glob_connec[_nVert*i+1] = ptsIds->GetId(1);
            _glob_connec[_nVert*i+2] = ptsIds->GetId(2);
        }

        _glob_creases.resize(_nPts*_nCreases,0);

        n=0;
        for (int i = 0; i < _nPts; i++)
        {
            if(polyData->GetPointData()->GetArray("Creases")->GetTuple1(n)>1.4)
                _glob_creases[_nCreases*i] = 2;
            else if(polyData->GetPointData()->GetArray("Creases")->GetTuple1(n)>0.8)
                _glob_creases[_nCreases*i] = 1;
            n++;
        }

        _glob_eflags.resize(_nElem*_nEFlags,0);
    }
    else
    {
        _glob_x_nodes.resize(_nDim, 0);
        _glob_connec.resize(_nVert, 0);
        _glob_creases.resize(_nCreases, 0);
        _glob_eflags.resize(_nEFlags, 0);
    }

    //Communicate number of points and elements
    MPI_Barrier(comm());
    MPI_Bcast(&_nPts,  1, MPI_INT, 0, comm());
    MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
}

#else

void hiperlife::MeshLoader::_serialVtkLoader()
{
    throw std::runtime_error("MeshLoader::Error. Serial vtk loader needs VTK library. Please, recompile hiperlife with VTK support.");
}

void hiperlife::MeshLoader::_getHRefinedMesh_serial_triangles(int refLevel)
{
    throw std::runtime_error("MeshLoader::Error. H refinement for serial triangular meshes needs VTK library. Please, recompile hiperlife with VTK support.");
}

#endif

void hiperlife::MeshLoader::_parallelLegacyVtkLoader()
{
    using namespace std;

    // Check extension
    string ext = _getFileExtension(_name);
    if (ext != "vtk")
        throw runtime_error("MeshLoader::_parallelLegacyVtkLoader: The parallel loader only works with legacy vtk files");

    //Read file
    ifstream file(_name);
    string line;
    bool loadNodes{false}, loadConnec{false}, loadCreases{false}, loadEFlags{false};
    vector<int> _tmp_connec;
    while (getline(file, line))
    {
        //Skip lines that are empty or only white spaces
        if (line.empty())
            continue;
        if (line.find_first_not_of(' ') == string::npos)
            continue;

        //Get line and store info in a vector
        std::istringstream iss(line);
        vector<string> tokens{istream_iterator<string>{iss}, istream_iterator<string>{}};

        //Read node coordinates
        if (tokens[0] == "POINTS")
        {
            //Read number of points
            _nPts = stoi(tokens[1]);

            //Create trivial point distribution
            _disPts.setLocNItem(0);
            _disPts.setNItem(_nPts);
            _disPts.Update();
            _loc_nPts = _disPts.loc_nItem();

            //Read coordinates
            vector<double> _tmp_x_nodes;
            fillVectorData<double>(_tmp_x_nodes, file, _loc_nPts, _nDim, 0, _disPts.offs_nItem());
            loadNodes = true;

            //Reorder x_nodes
            _x_nodes.resize(_loc_nPts*_nDim, 0.0);
            int i{0};
            for (int n = 0; n < _loc_nPts; n++)
            {
                for (int d = 0; d < _nDim; d++)
                {
                    _x_nodes[_loc_nPts*d+n] = _tmp_x_nodes[i];
                    i++;
                }
            }

            continue;
        }

        //Read connectivity
        if (tokens[0] == "POLYGONS" || tokens[0] == "CELLS")
        {
            //Read number of elements
            _nElem = stoi(tokens[1]);

            //Create trivial element distribution
            _disElem.setLocNItem(0);
            _disElem.setNItem(_nElem);
            _disElem.Update();
            _loc_nElem = _disElem.loc_nItem();

            //Read connectivity
            fillVectorData<int>(_tmp_connec, file, _loc_nElem, _nVert+1, 1, _disElem.offs_nItem());
            loadConnec = true;

            continue;
        }

        //Read cell type
        if (tokens[0] == "CELL_TYPES")
        {
            //Read number of elements
            _nElem = stoi(tokens[1]);

            //Create trivial element distribution
            _disElem.setLocNItem(0);
            _disElem.setNItem(_nElem);
            _disElem.Update();
            _loc_nElem = _disElem.loc_nItem();

            //Read cell type
            vector<int> cellType;
            fillVectorData<int>(cellType, file, _loc_nElem, 1, 0, _disElem.offs_nItem());

            //Check cell type
            for (auto c: cellType)
            {
                if (hlToVtkElemType(_eType, _bfType, _bfOrder) != c)
                    throw runtime_error("MeshLoader::loadLegacyVtk: The element type of the vtk does not match with the specified element type.");
            }

            continue;
        }

        //Read creases
        if (tokens[0] == "CreasesId")
        {
            //Read number of points
            _nPts = stoi(tokens[2]);

            //Create trivial point distribution
            _disPts.setLocNItem(0);
            _disPts.setNItem(_nPts);
            _disPts.Update();
            _loc_nPts = _disPts.loc_nItem();

            //FIXME: Right now we are assuming _nCreases=1

            //Read creases
            fillVectorData<int>(_creases, file, _loc_nPts, 1, 0, _disPts.offs_nItem());
            _creases.resize(_loc_nPts*_nCreases);
            loadCreases = true;

            continue;
        }

        //Read element flags
        if (tokens[0] == "ElemFlags")
        {
            throw runtime_error("MeshLoader::_parallelLegacyVtkLoader: Not implemented yet.");
        }


    }

    //Close file
    file.close();

    //Check whether nodes and connectivities were read
    if (!loadNodes || !loadConnec)
        throw runtime_error("MeshLoader::loadLegacyVtk: There was a problem loading the mesh information.");

    //If there are no creases, we create them
    if (loadCreases == false)
        _creases.resize(_loc_nPts * _nCreases, 0);
    // for (int i = 0; i < _nPts; i++)
    //     _glob_creases[_nCreases*i + 1] = -1; FIXME:: Add this when the previous fixme has been corrected

    //If there are no element flags, we create them
    if (loadEFlags == false)
        _eflags.resize(_loc_nElem * _nEFlags, 0);

    //Reorder connectivity
    if (_bfType != BasisFuncType::SubdivSurfs)
    {
        vector<int> reorder = vtkReordering(_eType, _bfType, _bfOrder, true);
        int pos{};
        _connec.resize(_loc_nElem*_nVert);
        for (int e = 0; e < _loc_nElem; e++)
        {
            for (int v = 0; v < _nVert; v++)
                _connec[pos+v] = _tmp_connec[pos+reorder[v]];
            pos += _nVert;
        }
    }
    else
    {
        _connec = _tmp_connec;
    }
}
