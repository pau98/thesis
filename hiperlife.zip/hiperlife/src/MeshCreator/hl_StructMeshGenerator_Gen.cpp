/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Francesco Greco and Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <vector>
#include <functional>
#include <deque>
#include <fstream>      // std::ifstream
#include <iterator>

#include "hl_TypeDefs.h"
#include "hl_legIOAux.h"
#include "hl_StructMeshGenerator.h"
#include "hl_Math.h"

#define MAXN 100001

using std::cout;
using std::endl;
using std::vector;
using std::runtime_error;

namespace hiperlife
{

    //Basic generator
    void StructMeshGenerator::genStructMesh(int nEx, int nEy, int nEz)
    {
        //Checks
        _performChecks(nEx, nEy, nEz);

        //Save requested order
        int orderIncX = _bfOrderX-1;
        int orderIncY = _bfOrderY-1;
        int orderIncZ = _bfOrderZ-1;

        //Generate mesh
        switch (int(_bfType))
        {
            case static_cast<int>(BasisFuncType::Linear):
                switch (int(_eType))
                {
                    case static_cast<int>(ElemType::Line):
                        _genLineStructMesh(nEx);
                        break;
                    case static_cast<int>(ElemType::Triang):
                        _genTriangStructMesh(nEx, nEy);
                        break;
                    case static_cast<int>(ElemType::Tetrah):
                        _genTetrahStructMesh(nEx, nEy, nEz);
                        break;
                    default:
                        throw runtime_error("StructMeshGenerator: Linear elements only work with Line, Triang or Tetrah element types.");
                }
                break;
            case static_cast<int>(BasisFuncType::Lagrangian):
                switch (int(_eType))
                {
                    case static_cast<int>(ElemType::Line):
                        _genLineStructMesh(nEx);
                        break;
                    case static_cast<int>(ElemType::Triang):
                        _genTriangStructMesh(nEx, nEy);
                        break;
                    case static_cast<int>(ElemType::Square):
                        _genSquareStructMesh(nEx, nEy);
                        break;
                    case static_cast<int>(ElemType::Tetrah):
                        _genTetrahStructMesh(nEx, nEy, nEz);
                        break;
                    case static_cast<int>(ElemType::Parallelep):
                        _genParallelepStructMesh(nEx, nEy, nEz);
                        break;
                    default:
                        throw runtime_error("StructMeshGenerator: Wrong element type.");
                }
                break;
            case static_cast<int>(BasisFuncType::SubdivSurfs):
                switch (int(_eType))
                {
                    case static_cast<int>(ElemType::Triang):
                        _genTriangStructMesh(nEx, nEy);
                        break;
                    default:
                        throw runtime_error("StructMeshGenerator: Subdivision surfaces only work with triangular element types.");
                }
                break;
            case static_cast<int>(BasisFuncType::BSplines):
            case static_cast<int>(BasisFuncType::Nurbs):
                switch (int(_eType))
                {
                    case static_cast<int>(ElemType::Line):
                        _genBezierCurve();
                        if (orderIncX > 0)
                            degreeElevateNurbs(orderIncX);
                        if (nEx > 1)
                            uniformlyRefineNurbs(nEx);
                        break;
                    case static_cast<int>(ElemType::Square):
                        _genBezierSurface();
                        if (orderIncX > 0 || orderIncY > 0)
                            degreeElevateNurbs(orderIncX, orderIncY);
                        if ((nEx > 1) || (nEy > 1))
                            uniformlyRefineNurbs(nEx, nEy);
                        break;
                    case static_cast<int>(ElemType::Parallelep):
                        _genBezierSolid();
                        if (orderIncX > 0 || orderIncY > 0 || orderIncZ > 0)
                            degreeElevateNurbs(orderIncX, orderIncY, orderIncZ);
                        if ((nEx > 1) || (nEy > 1) || (nEz > 1))
                            uniformlyRefineNurbs(nEx, nEy, nEz);
                        break;
                    default:
                        throw runtime_error("StructMeshGenerator: Bspline/Nurbs only work with Line, Square or Parallelep element types.");
                }
                break;
            default:
                throw runtime_error("StructMeshGenerator: Basis function type not set.");
        }

    }

    void StructMeshGenerator::genLine(int nEx, double Lx)
    {
        //Check
        if (nEx < 1)
            throw runtime_error("StructMeshGenerator: Line: Number of elements should be positive.");
        if (Lx <= 0.0)
            throw runtime_error("StructMeshGenerator: Line: The length Lx of the line should be a positive number.");
        if (_eType != ElemType::Line)
            throw runtime_error("StructMeshGenerator: Line: Element type should be Line.");

        //Generate
        genStructMesh(nEx, -1, -1);
        if (Lx != 1.0)
            scale(Lx);
    }

    void StructMeshGenerator::genLine(int nEx, vector<double> p0, vector<double> p1)
    {
        //Check
        if (nEx < 1)
            throw runtime_error("StructMeshGenerator: Line: Number of elements should be positive.");
        if (p0 == p1)
            throw runtime_error("StructMeshGenerator: Line: Points p0 and p1 cannot be equal.");
        if (_eType != ElemType::Line)
            throw runtime_error("StructMeshGenerator: Line: Element type should be a line.");
        if (p0.size() < 2 || p1.size() < 2)
            throw runtime_error("StructMeshGenerator: Line: The initial and final points have to be 2D or 3D.");
        if (p0.size() != p1.size())
            throw runtime_error("StructMeshGenerator: Line: The dimension of the initial and final points does not match.");

        //Generate
        genStructMesh(nEx, -1, -1);

        //Get dimension
        int d = p0.size();

        //Scale
        double Lx = Math::Dist(d, p0.data(), p1.data());
        if (Lx != 1.0)
            scale(Lx);

        //Rotate
        double phi;
        vector<double> a(3), b(3);
        if (d == 2)
        {
            a = {1, 0};
            b = {p1[0]-p0[0], p1[1]-p0[1]};
            phi = acos(Math::Dot2D(a.data(), b.data())/Math::Norm2D(a.data())/Math::Norm2D(b.data()));
            rotate2D(phi);
        }
        else
        {
            vector<double> v(3);
            a = {1, 0, 0};
            b = {p1[0]-p0[0], p1[1]-p0[1], p1[2]-p0[2]};
            Math::Cross(v.data(), a.data(), b.data());
            if (v[0] == 0 and  v[1] == 0 and v[2] == 0)
                v = {0, 0, 1};
            phi = acos(Math::Dot3D(a.data(), b.data())/Math::Norm3D(a.data())/Math::Norm3D(b.data()));
            rotateAngleVector(phi, v);
        }

        //Translate
        translate(p0[0], p0[1], p0[2]);
    }

    void StructMeshGenerator::genSquareLine(int nEl, double side)
    {
        //Check
        if (_eType != ElemType::Line)
            throw runtime_error("StructMeshGenerator::genSquareLine Only line elements can be used.");

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genSquareLineNurbs(nEl, side);
        else
            _genSquareLine(nEl, side);
    }

    void StructMeshGenerator::genPolygonalCurve(std::string fname, bool closeCurve)
    {
        //Check
        if (_eType != ElemType::Line)
            throw runtime_error("StructMeshGenerator::genPolygonalCurve: Only line elements can be used.");
        _checkFileExists(fname);
        // if (refLevel != 0) //FIXME:: Add refinement
        //     throw runtime_error("StructMeshGenerator::genPolygonalCurve: Refinement not implemented yet.");

        //Count number of points
        std::ifstream file;
        file.open(fname, std::ofstream::in);
        std::string line;
        int nLines{0};
        while (std::getline(file, line))
            ++nLines;
        file.close();
        if (closeCurve)
            nLines++;

        //Generate
        genStructMesh(nLines-1, -1, -1);

        //Get point coordinates
        file.open(fname, std::ofstream::in);
        vector<double> coords(2*_loc_nPts, -1);
        for (int i = 0; i < nLines; i++)
        {
            if (_disPts.isItemInPart(i))
            {
                fillVectorData<double>(coords, file, _loc_nPts, 2);
                break;
            }
            std::getline(file, line);
        }
        file.close();

        //Transform //FIXME:: Do it for every order and BSplines
        if (((_bfType == BasisFuncType::BSplines or _bfType == BasisFuncType::Nurbs) and _bfOrder > 1) or (_bfType == BasisFuncType::Lagrangian and _bfOrder > 1))
            throw runtime_error("StructMeshGenerator::genPolygonalCurve: Not implemented for this combination of basis function and order.");

        for (int n = 0; n < _loc_nPts; n++)
        {
            _x_nodes[_loc_nPts * 0 + n] = coords[2*n];
            _x_nodes[_loc_nPts * 1 + n] = coords[2*n+1];
        }

        //Unclamp it
        if (closeCurve)
            unclamp(Axis::Xaxis);
    }

    void StructMeshGenerator::genPolygonalCurve(std::vector<double> xCoords,std::vector<double> yCoords, bool closeCurve)
    {
        //Check
        if (_eType != ElemType::Line)
            throw runtime_error("StructMeshGenerator::genPolygonalCurve: Only line elements can be used.");
    
        if (xCoords.size() != yCoords.size())
            throw runtime_error("StructMeshGenerator::genPolygonalCurve: Coord vectors have to be the same size.");

        //Count number of points
        int nLines = xCoords.size();
        if (closeCurve)
            nLines++;

        //Generate
        genStructMesh(nLines-1, -1, -1);      

        //Transform //FIXME:: Do it for every order and BSplines
        if (((_bfType == BasisFuncType::BSplines or _bfType == BasisFuncType::Nurbs) and _bfOrder > 1) or (_bfType == BasisFuncType::Lagrangian and _bfOrder > 1))
            throw runtime_error("StructMeshGenerator::genPolygonalCurve: Not implemented for this combination of basis function and order.");

        for (int n = 0; n < _loc_nPts; n++)
        {
            _x_nodes[_loc_nPts * 0 + n] = xCoords[n];
            _x_nodes[_loc_nPts * 1 + n] = yCoords[n];
        }

        //Unclamp it
        if (closeCurve)
            unclamp(Axis::Xaxis);
    }

    void StructMeshGenerator::genSquare(int nEx, int nEy, double side)
    {
        //Check
        if ((nEx < 1) || (nEy < 1))
            throw runtime_error("StructMeshGenerator: Square: Number of elements per direction should be positive.");
        if (side <= 0.0)
            throw runtime_error("StructMeshGenerator: Square: The side of the square should be a positive number.");
        if (_eType != ElemType::Square && _eType != ElemType::Triang)
            throw runtime_error("StructMeshGenerator: Square: Element type should be Square or Triang.");

        //Generate
        genStructMesh(nEx, nEy, -1);
        if (side != 1.0)
            scale(side);
    }

    void StructMeshGenerator::genRectangle(int nEx, int nEy, double sidex, double sidey)
    {
        //Check
        if (nEx < 1 || nEy < 1)
            throw runtime_error("StructMeshGenerator: Rectangle: Number of elements should be positive.");
        if (sidex <= 0.0 || sidey <= 0.0)
            throw runtime_error("StructMeshGenerator: Rectangle: The sides of the rectangle should be a positive number.");
        if (_eType != ElemType::Square && _eType != ElemType::Triang)
            throw runtime_error("StructMeshGenerator: Rectangle: Element type should be Square or Triang.");

        //Generate
        genStructMesh(nEx, nEy, -1);
        scale(sidex, sidey, 1.0);
    }

    void StructMeshGenerator::genRuledSurface(int nEx, int nEy, vector<double> p1, vector<double> p2, vector<double> p3, vector<double> p4)
    {

        /* Generates a ruled surface starting from 4 points, as illustrated below
         p4 -------- p3
         |           |
         |           |
         |           |
         p1 -------- p2
        */

        //Check
        if (nEx < 1 || nEy < 1)
            throw runtime_error("StructMeshGenerator: Rectangle: Number of elements should be positive.");
        if (_eType != ElemType::Square && _eType != ElemType::Triang)
            throw runtime_error("StructMeshGenerator: Rectangle: Element type should be Square or Triang.");

        if (p1[0]==p2[0] && p1[1]==p2[1] && p1[2]==p2[2] )
            throw runtime_error("Ruled surface generator doesn't work for coincident points.");

        if (p1[0]==p3[0]  && p1[1]==p3[1] && p1[2]==p3[2] )
            throw runtime_error("Ruled surface generator doesn't work for coincident points.");

        if (p1[0]==p4[0]  && p1[1]==p4[1] && p1[2]==p4[2] )
            throw runtime_error("Ruled surface generator doesn't work for coincident points.");

        if (p2[0]==p3[0]  && p2[1]==p3[1] && p2[2]==p3[2] )
            throw runtime_error("Ruled surface generator doesn't work for coincident points.");

        if (p2[0]==p4[0]  && p2[1]==p4[1] && p2[2]==p4[2] )
            throw runtime_error("Ruled surface generator doesn't work for coincident points.");

        if (p3[0]==p4[0]  && p3[1]==p4[1] && p3[2]==p4[2] )
            throw runtime_error("Ruled surface generator doesn't work for coincident points.");



        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genRuledSurfaceNurbs(nEx, nEy, p1,p2,p3,p4);
        else
            _genRuledSurface(nEx, nEy, p1,p2,p3,p4);

    }

    void StructMeshGenerator::genCube(int nEdir, double side)
    {
        //Check
        if (nEdir < 1)
            throw runtime_error("StructMeshGenerator: Cube: Number of elements per direction should be positive.");
        if (side <= 0.0)
            throw runtime_error("StructMeshGenerator: Cube: The side of the square should be a positive number.");
        if (_eType != ElemType::Parallelep && _eType != ElemType::Tetrah)
            throw runtime_error("StructMeshGenerator: Cube: Element type should be Parallelep or Tetrah.");

        //Generate
        genStructMesh(nEdir, nEdir, nEdir);
        if (side != 1.0)
            scale(side);
    }

    void StructMeshGenerator::genRectangularParallelepiped(int nEx, int nEy, int nEz, double sidex, double sidey, double sidez)
    {
        //Check
        if (nEx < 1 || nEy < 1 || nEz < 1)
            throw runtime_error("StructMeshGenerator: RectangularParallelepiped: Number of elements should be positive.");
        if (sidex <= 0.0 || sidey <= 0.0 || sidez <= 0)
            throw runtime_error("StructMeshGenerator: RectangularParallelepiped: The sides of the rectangle should be a positive number.");
        if (_eType != ElemType::Parallelep && _eType != ElemType::Tetrah)
            throw runtime_error("StructMeshGenerator: RectangularParallelepiped: Element type should be Parallelep or Tetrah.");

        //Generate
        genStructMesh(nEx, nEy, nEz);
        scale(sidex, sidey, sidez);
    }

    void StructMeshGenerator::genCircularArc(int nEx, double radius, double phiIni, double phiEnd)
    {
        //Check
        if (nEx < 1)
            throw runtime_error("StructMeshGenerator: CircularArc: Number of elements should be positive.");
        if (_eType != ElemType::Line)
            throw runtime_error("StructMeshGenerator: CircularArc: Element type should be a line.");
        if (phiEnd - phiIni > 2.0*M_PI)
            throw runtime_error("StructMeshGenerator: CircularArc: Total angle phi should be less than 2*PI.");

        //Correct initial angle
        if (phiIni > 2.0*M_PI)
            phiIni -= 2.0*M_PI;

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genCircularArcNurbs(nEx, radius, phiEnd-phiIni);
        else
            _genCircularArc(nEx, radius, phiEnd-phiIni);

        //Rotate
        if (phiIni != 0.0)
            rotate2D(phiIni);
    }

    void StructMeshGenerator::genAnnularSector(int nEx, int nEy, double rInt, double rExt, double phiIni, double phiEnd)
    {
        //Check
        if (nEx < 1 || nEy < 1)
            throw runtime_error("StructMeshGenerator: AnnularSector: Number of elements should be positive.");
        if (_eType != ElemType::Square && _eType != ElemType::Triang)
            throw runtime_error("StructMeshGenerator: AnnularSector: Element type should be square or triangle.");
        if (phiEnd-phiIni > 2.0*M_PI)
            throw runtime_error("StructMeshGenerator: AnnularSector: Total angle should be less than 2*PI.");

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genAnnularSectorNurbs(nEx, nEy, rInt, rExt, phiEnd-phiIni);
        else
            _genAnnularSector(nEx, nEy, rInt, rExt, phiEnd-phiIni);

        //Rotate
        if (phiIni != 0.0)
            rotate2D(phiIni);

        //Unclamp it
        if (phiEnd-phiIni == 2.0*M_PI)
            unclamp(Axis::Yaxis);
    }


    void StructMeshGenerator::genDisk_Polar(int nEx, int nEy, double r)
    {
        //Check
        if (nEx < 1 || nEy < 1)
            throw runtime_error("StructMeshGenerator: Disk_Polar: Number of elements should be positive.");
        if (_eType != ElemType::Square)
            throw runtime_error("StructMeshGenerator: Disk_Polar: Element type should be square.");

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genDiskNurbs_Polar(nEx, nEy, r);
        else
            _genDisk_Polar(nEx, nEy, r);

        //Unclamp it
        unclamp(Axis::Yaxis);
    }

    void StructMeshGenerator::genDisk_Squared(int nEx, int nEy, double r)
    {
        //Check
        if (nEx < 1 || nEy < 1)
            throw runtime_error("StructMeshGenerator: Disk_Squared: Number of elements should be positive.");
        if (_eType != ElemType::Square && _eType != ElemType::Triang)
            throw runtime_error("StructMeshGenerator: Disk_Squared: Element type should be square or triangle.");

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genDiskNurbs_Squared(nEx, nEy, r);
        else
            _genDisk_Squared(nEx, nEy, r);

    }

    void StructMeshGenerator::genQuarterPlateWithCircularHole(int nEx, int nEy, double sx, double sy, double r)
    {
        //Check
        if (nEx < 1 || nEy < 1)
            throw runtime_error("StructMeshGenerator: QuarterPlateWithCircularHole: Number of elements should be positive.");
        if (_eType != ElemType::Square && _eType != ElemType::Triang)
            throw runtime_error("StructMeshGenerator: QuarterPlateWithCircularHole: Element type should be square or triangle.");
        if (r >= sx || r >= sy)
            throw runtime_error("StructMeshGenerator: QuarterPlateWithCircularHole: The radius cannot be greater or equal than the side of the plate.");

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genQuarterPlateWithCircularHoleNurbs(nEx, nEy, sx, sy, r);
        else
            _genQuarterPlateWithCircularHole(nEx, nEy, sx, sy, r);

    }

    void StructMeshGenerator::genTorusSurfacePatchSector(int nEx, int nEy, double rGen, double phiIni, double phiEnd, double rDir, double thetaIni, double thetaEnd)
    {
        //Check
        if (nEx < 1 || nEy < 1)
            throw runtime_error("StructMeshGenerator: TorusSurfacePatchSector: Number of elements should be positive.");
        if (rGen <= 0 || rDir <= 0)
            throw runtime_error("StructMeshGenerator: TorusSurfacePatchSector: Radius should be positive.");
        if (phiEnd-phiIni > 2.0*M_PI)
            throw runtime_error("StructMeshGenerator: TorusSurfacePatchSector: Total angle should be less than 2*PI.");
        if (thetaEnd-thetaIni > 2.0*M_PI)
            throw runtime_error("StructMeshGenerator: TorusSurfacePatchSector: Total angle should be less than 2*PI.");

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genTorusSurfacePatchSectorNurbs(nEx, nEy, rGen, phiIni, phiEnd, rDir, thetaEnd-thetaIni);
        else
            _genTorusSurfacePatchSector(nEx, nEy, rGen, phiIni, phiEnd, rDir, thetaEnd-thetaIni);

        //Rotate
        if (thetaIni != 0.0)
            rotateZ(thetaIni);
    }

    void StructMeshGenerator::genTorusSolidSector(int nEx, int nEy, int nEz, double rGen, double rDir, double thetaIni, double thetaEnd)
    {
        //Check
        if (nEx < 1 || nEy < 1 || nEz < 1)
            throw runtime_error("StructMeshGenerator: TorusSolidSector: Number of elements should be positive.");
        if (rGen <= 0 || rDir <= 0)
            throw runtime_error("StructMeshGenerator: TorusSolidSector: Radius should be positive.");
        if (thetaEnd-thetaIni > 2.0*M_PI)
            throw runtime_error("StructMeshGenerator: TorusSolidSector: Total angle should be less than 2*PI.");
        if (_eType != ElemType::Parallelep && _eType != ElemType::Tetrah)
            throw runtime_error("StructMeshGenerator: TorusSolidSector: Element type should be either Parallelep or Tetrah.");

        //Generate
        if ((_bfType == BasisFuncType::BSplines) || (_bfType == BasisFuncType::Nurbs))
            _genTorusSolidSectorNurbs(nEx, nEy, nEz, rGen, rDir, thetaEnd-thetaIni);
        else
            _genTorusSolidSector(nEx, nEy, nEz, rGen, rDir, thetaEnd-thetaIni);

        //Rotate
        if (thetaIni != 0.0)
            rotateZ(thetaIni);
    }

    void StructMeshGenerator::genSolidQuarterPlateWithCylindricalHole(int nEx, int nEy, int nEz, double side, double height, double radius)
    {
        //Check
        if (nEx < 1 or nEy < 1 or nEz < 1)
            throw runtime_error("StructMeshGenerator::genSolidQuarterPlateWithCylindricalHole: Number of elements should be positive.");
        if (_eType != ElemType::Parallelep and _eType != ElemType::Tetrah)
            throw runtime_error("StructMeshGenerator::genSolidQuarterPlateWithCylindricalHole: Element type should be Parallelep or Tetrah.");
        if (radius >= side)
            throw runtime_error("StructMeshGenerator::genSolidQuarterPlateWithCylindricalHole: The radius cannot be greater or equal than the side of the plate.");
        if (height < 0.0)
            throw runtime_error("StructMeshGenerator::genSolidQuarterPlateWithCylindricalHole: The height has to be positive.");

        //Save mesh info
        ElemType eType = _eType;

        //Generate 2D mesh
        if (eType == ElemType::Parallelep)
            _eType = ElemType::Square;
        else
            _eType = ElemType::Triang;
        genQuarterPlateWithCircularHole(nEx, nEy, side, side, radius);

        //Extrude 2D mesh
        extrudeSurfaceLinear(nEz, height);
    }


    //Extra generators
    void StructMeshGenerator::genVermouth()
    {

        setNDim(3);
        setElemType(ElemType::Line);
        setBasisFuncType(BasisFuncType::BSplines);
        setBasisFuncOrder(2);

        //Define knots
        vector<double> U = {0.0, 0.0, 0.0, 1/3, 1/3, 2/3, 2/3, 1.0, 1.0, 1.0};

        //Define control points
        vector<vector<vector<vector<double>>>> CP(7, vector<vector<vector<double>>>(1, vector<vector<double>>(1, vector<double>(4))));
        CP[0][0][0] = {0.75, 0.0, 0.0, 1.0};
        CP[1][0][0] = {0.75/2, 0.025, 0.0, 1.0};
        CP[2][0][0] = {0.1, 0.05, 0.0, 1.0};
        CP[3][0][0] = {0.1, (2-0.05)/2+0.05, 0.0, 1.0};
        CP[4][0][0] = {0.1, 2.0, 0.0, 1.0};
        CP[5][0][0] = {(1.2-0.1)/2+0.1, 2.5, 0.0, 1.0};
        CP[6][0][0] = {1.2, 3.0, 0.0, 1.0};

        //Generate
        genNurbsFree(U, CP);
        revolve(0, 2, ElemType::Square, 2*M_PI, Axis::Yaxis);
        uniformlyRefineNurbs(40, 120);

    }


    //Test distribution
    // Calculating SPF (Smallest Prime Factor) for every
    // number till MAXN.
    // Time Complexity : O(nloglogn)
    void sieve(int *spf)
    {
        spf[1] = 1;
        // marking smallest prime factor for every
        // number to be itself.
        for (int i=2; i<MAXN; i++)
            spf[i] = i;
        // separately marking spf for every even
        // number as 2
        for (int i=4; i<MAXN; i+=2)
            spf[i] = 2;
        for (int i=3; i*i<MAXN; i++)
        {
            // checking if i is prime
            if (spf[i] == i)
            {
                // marking SPF for all numbers divisible by i
                for (int j=i*i; j<MAXN; j+=i)
                    // marking spf[j] if it is not
                    // previously marked
                    if (spf[j]==j)
                        spf[j] = i;
            }
        }
    }

    // A O(log n) function returning primefactorization
    // by dividing by smallest prime factor at every step
    vector<int> getFactorization(int x, int *spf)
    {
        vector<int> ret;
        while (x != 1)
        {
            ret.push_back(spf[x]);
            x = x / spf[x];
        }
        return ret;
    }

    int StructMeshGenerator::_getElem(int e)
    {
        if (_mapEl.count(e) > 0)
            return _mapEl.find(e)->second;
        else
            return -1;
    }

    void StructMeshGenerator::_genElementMap()
    {

        //Resize?
        //Get factorization
        int spf[MAXN];
        sieve(spf);
        vector<int> fac = getFactorization(numProcs(), spf);

        int px = fac[0];
        int py = fac[1];
        int ip = myRank()/px;
        int jp = myRank()%px;
        int nx = _nEx/px;
        int ny = _nEy/py;


        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                cout << "Proc: " << _myRank << endl;
                cout << ip << " " << jp  << " "<< nx << " " << ny << endl;
                cout << ny*jp << " " << ny*(jp+1) << " " << nx*ip << " " << nx*(ip+1) << endl;

                cout << endl;
            }
            Barrier();
        }

        //Distribute
        int elNew = myRank()*nx*ny;
        for (int j = ny*jp; j < ny*(jp+1); j++)
        {
            for (int i = j*_nEx + nx*ip; i < j*_nEx + nx*(ip+1); i++)
            {
                _mapEl[i] = elNew;
                elNew++;
            }
        }


        // if (myRank() == 0)
        // {
        //     for (int j = 0; j < _nEy/2; j++)
        //     {
        //         for (int i = j*_nEx; i < j*_nEx+2; i++)
        //         {
        //             _mapEl[i] = elNew;
        //             elNew++;
        //         }
        //     }
        // }
        // else if (myRank() == 1)
        // {
        //     for (int j = 0; j < _nEy/2; j++)
        //     {
        //         for (int i = j*_nEx+2; i < j*_nEx+4; i++)
        //         {
        //             _mapEl[i] = elNew;
        //             elNew++;
        //         }
        //     }
        // }
        // if (myRank() == 2)
        // {
        //     for (int j = _nEy/2; j < _nEy; j++)
        //     {
        //         for (int i = j*_nEx; i < j*_nEx+2; i++)
        //         {
        //             _mapEl[i] = elNew;
        //             elNew++;
        //         }
        //     }
        // }
        // else if (myRank() == 3)
        // {
        //     for (int j = _nEy/2; j < _nEy; j++)
        //     {
        //         for (int i = j*_nEx+2; i < j*_nEx+4; i++)
        //         {
        //             _mapEl[i] = elNew;
        //             elNew++;
        //         }
        //     }
        // }

        for (int p = 0; p < _numProcs; p++)
        {
            if (_myRank == p)
            {
                cout << "Proc: " << _myRank << endl;
                for (std::map<int,int>::iterator it = _mapEl.begin(); it != _mapEl.end(); ++it)
                    std::cout << it->first << " => " << it->second << endl;
                cout << endl;
            }
            Barrier();
        }

    }

}
