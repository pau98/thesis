/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Waleed Mirza
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <vector>
#include <functional>
#include <deque>

#include "hl_Math.h"
#include "hl_TypeDefs.h"
#include "hl_StructMeshGenerator.h"

using std::cout;
using std::endl;
using std::vector;
using std::runtime_error;

namespace hiperlife
{
    // Unclamp
    void StructMeshGenerator::unclamp(vector<Axis> axes)
    {
        // Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator::unclamp: Cannot perform transformation before generating the mesh.");

        // Unclamp it
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            _unclamp(axes);
        else
            _unclampNurbs(axes);
    }


    // Revolve
    void StructMeshGenerator::revolve(int nEr, int order_r, ElemType eType, double theta, vector<double> point, vector<double> dir)
    {
        //Check
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator::revolve: Cannot perform transformation before generating the mesh.");

        //Unclamp it
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
            _revolve(nEr, order_r, eType, theta, point, dir);
        else
            _revolveNurbs(nEr, order_r, theta, point, dir);
    }


    // Stretch
    void StructMeshGenerator::stretchElemsSymmetric(double ratioX, double ratioY, double ratioZ)
    {
        //Create functions
        auto fx = [ratioX](double chi){
            double r = ratioX;
            if (r == 0)
                return chi;
            else if (r > 0)
                return 0.5*(1.0+tanh(r*(2.0*chi-1.0))/tanh(r));
            else
                return 0.5*(1.0-atanh(tanh(r)*(1.0-2.0*chi))/r);
        };
        auto fy = [ratioY](double chi){
            double r = ratioY;
            if (r == 0)
                return chi;
            else if (r > 0)
                return 0.5*(1.0+tanh(r*(2.0*chi-1.0))/tanh(r));
            else
                return 0.5*(1.0-atanh(tanh(r)*(1.0-2.0*chi))/r);
        };
        auto fz = [ratioZ](double chi){
            double r = ratioZ;
            if (r == 0)
                return chi;
            else if (r > 0)
                return 0.5*(1.0+tanh(r*(2.0*chi-1.0))/tanh(r));
            else
                return 0.5*(1.0-atanh(tanh(r)*(1.0-2.0*chi))/r);
        };

        //Transform
        stretchElems(fx, fy, fz);

    }

    void StructMeshGenerator::stretchElemsAsymmetric(double ratioX, double ratioY, double ratioZ)
    {
        //Create functions
        auto fx = [ratioX](double chi){
            double r = ratioX;
            if (r == 0.0)
                return chi;
            else if (r > 0)
                return tanh(r*(chi))/tanh(r);
            else
                return 1.0 - tanh(r*(1.0-chi))/tanh(r);
        };
        auto fy = [ratioY](double chi){
            double r = ratioY;
            if (r == 0.0)
                return chi;
            else if (r > 0)
                return tanh(r*(chi))/tanh(r);
            else
                return 1.0 - tanh(r*(1.0-chi))/tanh(r);
        };
        auto fz = [ratioZ](double chi){
            double r = ratioZ;
            if (r == 0.0)
                return chi;
            if (r > 0)
                return tanh(r*(chi))/tanh(r);
            else
                return 1.0 - tanh(r*(1.0-chi))/tanh(r);
        };

        //Transform
        stretchElems(fx, fy, fz);

    }

    void StructMeshGenerator::stretchElems(std::function<double(double)> fx, std::function<double(double)> fy, std::function<double(double)> fz)
    {
        //Checks
        if (_isMeshGenerated() == false)
            throw runtime_error("StructMeshGenerator: Cannot perform transformation before generating the mesh.");

        //Transform
        if ((_bfType != BasisFuncType::BSplines) && (_bfType != BasisFuncType::Nurbs))
        {
            //If this is the first transformation
            if (_history.size() == 0)
            {
                //Transform
                _stretchElems(fx, fy, fz);
            }
            else
            {
                //Restart mesh
                genStructMesh(_nEx, _nEy, _nEz);

                //Transform
                _stretchElems(fx, fy, fz);

                //Save history, transform, and reload history
                _history_tmp = _history;
                _history_names_tmp = _history_names;
                for (auto& fu : _history_tmp)
                    fu();
                _history = _history_tmp;
                _history_names = _history_names_tmp;
            }

            //Save history
            _history.emplace_front([=](){_stretchElems(fx, fy, fz);});
        }
        else
        {
            //Save number of elements
            double newTotalnEx = _nEx;
            double newTotalnEy = _nEy;
            double newTotalnEz = _nEz;

            //Save order
            int orderX = _bfOrderX;
            int orderY = _bfOrderY;
            int orderZ = _bfOrderZ;

            //Save history
            _history_tmp = _history;
            _history_names_tmp = _history_names;

            //Generate elemental mesh
            _genNurbsFree(_bfOrderX_min, _bfOrderY_min, _bfOrderZ_min, _uKnot_min, _vKnot_min, _wKnot_min, _CP_min);

            //Degree elevate
            auto h = 0u;
            if (orderX != _bfOrderX_min or orderY != _bfOrderY_min or orderZ != _bfOrderZ_min)
            {
                _history_tmp[0]();
                h++;
            }

            //Transform
            _freelyRefineNurbs(newTotalnEx, newTotalnEy, newTotalnEz, fx, fy, fz, false);

            // Apply remaining history
            for (auto i = h; i < _history_tmp.size(); i++)
                _history_tmp[i]();

            //Reload history
            _history = _history_tmp;
            _history_names = _history_names_tmp;

            //Save stretch into history
            _history.emplace(_history.begin()+h, [=](){_stretchElems(fx, fy, fz);});
            _history_names.push_back(__FUNCTION__);

        }
    }


    // Reorder connectivity
    void StructMeshGenerator::_reorderConnec()
    {
        switch (int(_eType))
        {
            case static_cast<int>(ElemType::Line):
                //No need to reorder
                break;
            case static_cast<int>(ElemType::Triang):
                _reorderConnecTriang();
                break;
            case static_cast<int>(ElemType::Square):
                _reorderConnecSquare();
                break;
            case static_cast<int>(ElemType::Tetrah):
                _reorderConnecTetrah();
                break;
            case static_cast<int>(ElemType::Parallelep):
                _reorderConnecParallelep();
                break;
            default:
                throw runtime_error("StructMeshGenerator: Wrong element type.");
        }
    }

    void StructMeshGenerator::_reorderConnecTriang()
    {
        //Change second diagonal triangle so that the node in the corner is not isolated
        _flipTriangles(1, 0);
        _flipTriangles(0, 1);
        _flipTriangles(1, 1);

        //Change last triangle so that the node in the corner is not isolated
        _flipTriangles(_nEx-2, _nEy-2);
        _flipTriangles(_nEx-1, _nEy-2);
        _flipTriangles(_nEx-2, _nEy-1);

        //Generate node map for regular triangles
        vector<vector<int>> nmap_r(8, vector<int>(_nVert, 0));
        for (int i = 0; i < 8; i++)
            for (int j = 0; j < _nVert; j++)
                nmap_r[i][j] = j;
        if (_bfOrder == 1)
        {
            nmap_r[1] = {2, 0, 1};
            nmap_r[6] = {2, 0, 1};
            nmap_r[3] = {1, 2, 0};
            nmap_r[4] = {1, 2, 0};
        }
        else
        {
            cout << "StructMeshGenerator::_reorderConnec: Warning: Reorder of nodes for order different than 1 has not been implemented." << endl;
        }

        //Generate node map for flipped triangles
        vector<vector<int>> nmap_f(8, vector<int>(_nVert, 0));
        for (int i = 0; i < 8; i++)
            for (int j = 0; j < _nVert; j++)
                nmap_f[i][j] = j;
        if (_bfOrder == 1)
        {
             nmap_f[3] = {2, 0, 1};
             nmap_f[4] = {2, 0, 1};
             nmap_f[0] = {1, 2, 0};
             nmap_f[7] = {1, 2, 0};
        }

        //Loop through macro-elements
        int nElold{}, nElnew{};
        vector<int> _connec_new;
        vector<vector<int>> emap(8, vector<int>(2, 0));
        vector<vector<int>> nmap(8, vector<int>(_nVert, 0));
        _connec_new.resize(_loc_nElem*_nVert, 0);
        for (int mj = 0; mj < _nEy/2; mj++)
        {
            for (int mi = 0; mi < _nEx/2; mi++)
            {
                //Get initial old element number for this macro-element
                nElold = 4*_nEx*mj + 4*mi;

                //Generate element map and assign node map
                if ((mi == 0 && mj == 0) || (mi == _nEx/2-1 && mj == _nEy/2-1 ))
                {
                    //Element map of the flipped triangles
                    emap[0] = {nElold  , nElnew+2};
                    emap[1] = {nElold+1, nElnew+5};
                    emap[2] = {nElold+2, nElnew+0};
                    emap[3] = {nElold+3, nElnew+3};
                    nElold += 2*_nEx;
                    emap[4] = {nElold  , nElnew+7};
                    emap[5] = {nElold+1, nElnew+4};
                    emap[6] = {nElold+2, nElnew+1};
                    emap[7] = {nElold+3, nElnew+6};

                    //Node map
                    nmap = nmap_f;
                }
                else
                {
                    //General element map
                    emap[0] = {nElold  , nElnew+0};
                    emap[1] = {nElold+1, nElnew+3};
                    emap[2] = {nElold+2, nElnew+1};
                    emap[3] = {nElold+3, nElnew+6};
                    nElold += 2*_nEx;
                    emap[4] = {nElold  , nElnew+2};
                    emap[5] = {nElold+1, nElnew+5};
                    emap[6] = {nElold+2, nElnew+7};
                    emap[7] = {nElold+3, nElnew+4};

                    //Node map
                    nmap = nmap_r;
                }

                //Loop over elements in the macro-element
                for (int e = 0; e < 8; e++)
                {
                    if (_disElem.isItemInPart(emap[e][0]))
                    {
                        int locNold = _disElem.locIdx(emap[e][0]);
                        int locNnew = _disElem.locIdx(emap[e][1]);
                        for (int v = 0; v < _nVert; v++)
                            _connec_new[locNnew * _nVert + v] = _connec[locNold * _nVert + nmap[e][v]];
                    }
                }

                //Increase new element
                nElnew += 8;
            }
        }
        _connec = _connec_new;

    }

    void StructMeshGenerator::_reorderConnecSquare()
    {

        //Loop through macro-elements
        int nElold{}, nElnew{};
        vector<int> _connec_new;
        vector<vector<int>> emap(4, vector<int>(2,0));
        _connec_new.resize(_loc_nElem*_nVert, 0);
        for (int mj = 0; mj < _nEy/2; mj++)
        {
            for (int mi = 0; mi < _nEx/2; mi++)
            {
                //Get initial old element number for this macro-element
                nElold = 2*_nEx*mj + 2*mi;

                //Create element map
                emap[0] = {nElold,   nElnew+0};
                emap[1] = {nElold+1, nElnew+1};
                nElold += _nEx;
                emap[3] = {nElold,   nElnew+3};
                emap[2] = {nElold+1, nElnew+2};

                //Fill new connectivity
                for (int e = 0; e < 4; e++)
                {
                    if (_disElem.isItemInPart(emap[e][0]))
                    {
                        int locNold = _disElem.locIdx(emap[e][0]);
                        int locNnew = _disElem.locIdx(emap[e][1]);
                        for (int v = 0; v < _nVert; v++)
                            _connec_new[locNnew * _nVert + v] = _connec[locNold * _nVert + v];
                    }
                }

                //Increase new element
                nElnew += 4;
            }
        }
        _connec = _connec_new;

    }

    void StructMeshGenerator::_reorderConnecTetrah()
    {
        throw runtime_error("StructMeshGenerator::_reorderConnectTetrah: Not implemented yet.");
    }

    void StructMeshGenerator::_reorderConnecParallelep()
    {

        //Loop through macro-elements
        int nElold{}, nElnew{};
        vector<int> _connec_new;
        vector<vector<int>> emap(8, vector<int>(2,0));
        _connec_new.resize(_loc_nElem*_nVert, 0);
        for (int mk = 0; mk < _nEz/2; mk++)
        {
            for (int mj = 0; mj < _nEy/2; mj++)
            {
                for (int mi = 0; mi < _nEx/2; mi++)
                {
                    //Get initial old element number for this macro-element
                    nElold = 2*_nEx*_nEy*mk + 2*_nEx*mj + 2*mi;

                    //Create element map
                    emap[0] = {nElold,   nElnew+0};
                    emap[1] = {nElold+1, nElnew+1};
                    nElold += _nEx;
                    emap[3] = {nElold,   nElnew+3};
                    emap[2] = {nElold+1, nElnew+2};
                    nElold += _nEx*_nEy -_nEx;
                    emap[4] = {nElold,   nElnew+4};
                    emap[5] = {nElold+1, nElnew+5};
                    nElold += _nEx;
                    emap[7] = {nElold,   nElnew+7};
                    emap[6] = {nElold+1, nElnew+6};

                    //Fill new connectivity
                    for (int e = 0; e < 8; e++)
                    {
                        if (_disElem.isItemInPart(emap[e][0]))
                        {
                            int locNold = _disElem.locIdx(emap[e][0]);
                            int locNnew = _disElem.locIdx(emap[e][1]);
                            for (int v = 0; v < _nVert; v++)
                                _connec_new[locNnew * _nVert + v] = _connec[locNold * _nVert + v];
                        }
                    }

                    //Increase new element
                    nElnew += 8;
                }
            }
        }
        _connec = _connec_new;

    }


    // Periodicity
    void StructMeshGenerator::_periodic()
    {
        //Checks
        if (_periodicInX == false and _periodicInY == false and _periodicInZ == false)
            return;

        //Transform
        if ((_bfType == BasisFuncType::Linear) or (_bfType == BasisFuncType::Lagrangian))
        {
            if (_pDim == 1)
                _periodicCurve();
            else if (_pDim == 2)
                _periodicSurface();
            else if (_pDim == 3)
                _periodicSolid();
        }
        else if ((_bfType == BasisFuncType::BSplines) or (_bfType == BasisFuncType::Nurbs))
        {
            if (_pDim == 1)
                _periodicCurveNurbs();
            else if (_pDim == 2)
                _periodicSurfaceNurbs();
            else if (_pDim == 3)
                _periodicSolidNurbs();
        }
        else
        {
            throw std::runtime_error("StructMeshGenerator::setPeriodicBoundaryCondition: Not implemented yet for " + str(_bfType)+ " basis functions.");
        }
    }

    // Extrusion
    void StructMeshGenerator::extrudeSurfaceLinear(int nEz, double height)
    {
        //Check
        if (nEz < 1)
            throw runtime_error("StructMeshGenerator::extrudeSurfaceLinear: Number of elements should be positive.");
        if (height < 0.0)
            throw runtime_error("StructMeshGenerator::extrudeSurfaceLinear: The height has to be positive.");

        // Transform
        if (_bfType != BasisFuncType::BSplines and _bfType != BasisFuncType::Nurbs)
            _extrudeSurfaceLinear(nEz, height);
        else
            _extrudeSurfaceLinearNurbs(nEz, height);
    }

}
