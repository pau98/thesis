/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef MESH_LOADER_H
#define MESH_LOADER_H

#include "hl_DistributedData.h"
#include "hl_TypeDefs.h"

#include "hl_MeshCreator.h"


namespace hiperlife
{
    //FIXME: Document the class
    /*!
     * \class MeshLoader
     * \brief Class to load meshes from files
     *
     */

    class MeshLoader : public MeshCreator
    {
        public:

            /** @name Constructor / Destructor / Operator
             *   Copy constructors are deleted for memory safety but objects can be created from
             *   temporal objects through move constructors
             *  @{ */
            MeshLoader(std::string tag = "MeshLoader", MPI_Comm comm = MPI_COMM_WORLD) : MeshCreator(tag, comm){};
            MeshLoader(MeshLoader&& other) = default;
            MeshLoader(const MeshLoader& other) = delete;
            ~MeshLoader() = default;
            MeshLoader& operator=(const MeshLoader& other) = delete;
            MeshLoader& operator=(MeshLoader&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             *   Main function to set the name of the file
             *  @{*/
            /*! \brief Sets the name of the file to be loaded.*/ //FIXME: Is this function useful?
            void setFileName(std::string name){_name = name;};
            // /*! \brief Sets the processor that will load the mesh for sequential loaders.*/
            // void setMasterProcessor(int p){_mProc = p;};
            /** @} */ // end of object creation management


            /** @name Mesh loader functions
             *   Functions to load meshes
             *  @{*/
            /*! \brief Loads a mesh. The type of mesh is deduced by the extension of the file.
              \param name String with the path and name of the mesh
              \param meshType How the mesh will be readed, either in sequential or in parallel
             */
            void loadMesh(std::string name, MeshType meshType);
            /*! \brief Loads a mesh. The type of mesh is deduced by the extension of the file.
              \param name String with the path and name of the mesh
             */
            void loadVtk(std::string name, MeshType meshType){loadMesh(name, meshType);};
            /*! \brief Loads a Gmsh mesh
              \param name String with the path and name of the mesh
              \param meshType How the mesh will be readed, either in sequential or in parallel
             */
            void loadGmsh(std::string name, MeshType meshType){loadMesh(name, meshType);};

            /** @} */ // end of object creation management

            //Auxiliary functions
            void printMesh(const std::string& mssg){_printMesh(mssg);};

        protected:
            //Main variables
            std::string _name{};
            DistributedData _disPts;
            DistributedData _disElem;
            int _mProc{};

            // Interface functions
            void _saveMesh() override;
            void _reloadMesh() override;

            void _getPRefinedMesh(int orderInc) override;
            void _getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ) override;
            void _getHRefinedMesh(int refLevel) override;
            void _getHRefinedMesh_serial_triangles(int refLevel);
            void _getBoundaryMesh(std::vector<MAxis> vMAx) override;

            //Loaders
            void _serialVtkLoader();
            void _parallelLegacyVtkLoader();
            void _loadVtk();
            void _serialGmshLoader();
            void _parallelGmshLoader();
            void _loadGmsh();

            //Checks
            void _performSettingChecks();

            //Auxiliary functions
            void _printMesh(const std::string& mssg);
    };

}
#endif
