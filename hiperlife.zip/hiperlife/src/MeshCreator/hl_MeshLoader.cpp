/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Font-Reverter
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <cstddef>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <iterator>
#include <numeric>

#include "hl_legIOAux.h"
#include "hl_TypeDefs.h"
#include "hl_MeshLoader.h"

using namespace std;

namespace hiperlife
{

    //Save and reload mesh
    void MeshLoader::_saveMesh()
    {
        return;
    }

    void MeshLoader::_reloadMesh()
    {
        return;
    }


    //Derived meshes
    void MeshLoader::_getPRefinedMesh(int orderInc)
    {
        using namespace std;

        (void) orderInc;

        //Checks
        //FIXME: make it work for meshes loaded in parallel (issue here is nodes added at the boundary between partitions)
        if (_meshType == MeshType::Parallel)
            throw runtime_error("MeshLoader::_getPRefinedMesh: p-refine a mesh loaded in parallel not implemented.");

        //FIXME: make it work for squares and higher-order elements
        if(_eType!=ElemType::Triang or _bfType != BasisFuncType::Linear)
                throw runtime_error("MeshLoader::getPRefinedMesh: Not implemented for elem type different than triangles or basis functions different from linear.");

        _bfType = BasisFuncType::Lagrangian;
        setBasisFuncOrder(2);
        _performOrderChecks();

        _nVert = 6;
        _pRefinedMesh = true;

        _loc_nPts=0;
        _loc_nElem=0;

        if (_myRank == 0)
        {
            vector<int> glob_connec(_nElem*_nVert);

            vector<pair<int,int>> edges;
            for(int e = 0; e < _nElem;  e++)
            {
                /*
                   2
                   | \
                   |   \
                   |     \
                   0------1 //local labels
                */

                //global labels
                int e0 = _glob_connec[e*3+0];  //_glob_connec is matrix of size _nElem * 3
                int e1 = _glob_connec[e*3+1];
                int e2 = _glob_connec[e*3+2];

                edges.push_back({min(e0,e1),max(e0,e1)});
                edges.push_back({min(e1,e2),max(e1,e2)});
                edges.push_back({min(e0,e2),max(e0,e2)});
            }

            sort(edges.begin(),edges.end());

            edges.erase(unique(edges.begin(), edges.end()), edges.end());

            int nPts = _nPts + edges.size();

            vector<int> newlabel_new(edges.size(),-1);
            vector<int> newlabel_old(_nPts,-1);

            vector<double> glob_x_nodes;

            int lastLabel{};
            for(int e = 0; e < _nElem;  e++)
            {
                /*
                   2
                   | \
                   |   \
                   |     \
                   0------1 //local labels
                */

                //global labels
                int e0 = _glob_connec[e*3+0];  //_glob_connec is matrix of size _nElem * 3
                int e1 = _glob_connec[e*3+1];
                int e2 = _glob_connec[e*3+2];

                double* x0 = &_glob_x_nodes[e0*_nDim]; //positions of the nodes
                double* x1 = &_glob_x_nodes[e1*_nDim];
                double* x2 = &_glob_x_nodes[e2*_nDim];


                //FIXME: make this more efficient
                int l0 = find(edges.begin(),edges.end(),std::pair<int,int>({min(e0,e1),max(e0,e1)}))-edges.begin();
                int l1 = find(edges.begin(),edges.end(),std::pair<int,int>({min(e1,e2),max(e1,e2)}))-edges.begin();
                int l2 = find(edges.begin(),edges.end(),std::pair<int,int>({min(e0,e2),max(e0,e2)}))-edges.begin();

                /*
                   5
                   | \
                   3   4
                   |     \
                   0---1---2
                */

                if(newlabel_old[e0] == -1)
                {
                    for(int m = 0; m< _nDim; m++)
                        glob_x_nodes.push_back(x0[m]);

                    newlabel_old[e0] = lastLabel;
                    glob_connec[e*6+0] = lastLabel;
                    lastLabel++;
                }
                else
                    glob_connec[e*6+0] = newlabel_old[e0];

                if(newlabel_new[l0] == -1)
                {
                    for(int m = 0; m< _nDim; m++)
                        glob_x_nodes.push_back(0.5*(x0[m]+x1[m]));

                    newlabel_new[l0] = lastLabel;
                    glob_connec[e*6+1] = lastLabel;
                    lastLabel++;
                }
                else
                    glob_connec[e*6+1] = newlabel_new[l0];

                if(newlabel_old[e1] == -1)
                {
                    for(int m = 0; m< _nDim; m++)
                        glob_x_nodes.push_back(x1[m]);

                    newlabel_old[e1] = lastLabel;
                    glob_connec[e*6+2] = lastLabel;
                    lastLabel++;
                }
                else
                    glob_connec[e*6+2] = newlabel_old[e1];

                if(newlabel_new[l2] == -1)
                {
                    for(int m = 0; m< _nDim; m++)
                        glob_x_nodes.push_back(0.5*(x0[m]+x2[m]));

                    newlabel_new[l2] = lastLabel;
                    glob_connec[e*6+3] = lastLabel;
                    lastLabel++;
                }
                else
                    glob_connec[e*6+3] = newlabel_new[l2];

                if(newlabel_new[l1] == -1)
                {
                    for(int m = 0; m< _nDim; m++)
                        glob_x_nodes.push_back(0.5*(x1[m]+x2[m]));

                    newlabel_new[l1] = lastLabel;
                    glob_connec[e*6+4] = lastLabel;
                    lastLabel++;
                }
                else
                    glob_connec[e*6+4] = newlabel_new[l1];


                if(newlabel_old[e2] == -1)
                {
                    for(int m = 0; m< _nDim; m++)
                        glob_x_nodes.push_back(x2[m]);

                    newlabel_old[e2] = lastLabel;
                    glob_connec[e*6+5] = lastLabel;
                    lastLabel++;
                }
                else
                    glob_connec[e*6+5] = newlabel_old[e2];
            }

            _nPts = nPts;
            _glob_x_nodes = glob_x_nodes;
            _glob_connec  = glob_connec;

            _glob_creases.resize(_nPts*_nCreases,0);
            _glob_eflags.resize(_nElem*_nEFlags,0);
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nVert, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts,  1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }

    void MeshLoader::_getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ)
    {
        (void) orderIncX;
        (void) orderIncY;
        (void) orderIncZ;
        throw runtime_error("MeshLoader::getPRefinedMesh: Not implemented.");
    }

    void MeshLoader::_getHRefinedMesh(int refLevel)
    {
        if (_meshType == MeshType::Parallel or _eType != ElemType::Triang)
            throw runtime_error("MeshLoader::_getHRefinedMesh: h-refine for loaded meshes only worked in serial and for triangle elements.");

        _getHRefinedMesh_serial_triangles(refLevel);
    }

    void MeshLoader::_getBoundaryMesh(vector<MAxis> vMAx)
    {
        (void) vMAx;
        throw runtime_error("MeshLoader::getBoundaryMesh: Not implemented.");
    }


    //Loaders
    void MeshLoader::loadMesh(string name, MeshType meshType)
    {
        //Save inputs
        _name = name;
        _meshType = meshType;

        //Checks
        _checkFileExists(_name);
        _performSettingChecks();

        //Get file extension
        string ext = _getFileExtension(name);

        //Load the mesh
        if (ext == "vtk" or ext == "vtu" or ext == "vtp" or ext == "pvtu" or ext == "pvtp")
            _loadVtk();
        else if (ext == "msh")
            _loadGmsh();
        else
            throw runtime_error("MeshLoader::loadMesh: There is no available reader the requested file '" + _name + "'.");
    }

    void MeshLoader::_loadVtk()
    {
        //Checks
        if ((_bfType == BasisFuncType::BSplines) or (_bfType == BasisFuncType::Nurbs))
            throw runtime_error("MeshLoader::loadLegacyVtk: Currently, the legacy vtk loader cannot read Bsplines/Nurbs meshes.");

        //Initialize
        _pDim = computePDim(_eType);
        if (_bfType != BasisFuncType::BSplines and _bfType != BasisFuncType::Nurbs)
            _nVert = computeNVert(_bfType, _eType, _bfOrder);
        else
            _nVert = computeNVert(_bfType, _eType, _bfOrderX, _bfOrderY, _bfOrderZ);

        //Load file
        if (_meshType == MeshType::Sequential)
        {
            //Load file in processor _mProc
            if (myRank() == _mProc)
            {
                _serialVtkLoader();
            }
            else
            {
                _glob_x_nodes.resize(_nDim, 0);
                _glob_connec.resize(_nDim, 0);
                _glob_creases.resize(_nCreases, 0);
                _glob_eflags.resize(_nEFlags, 0);
            }

            //Communicate number of points and elements
            MPI_Barrier(comm());
            MPI_Bcast(&_nPts, 1, MPI_INT, _mProc, comm());
            MPI_Bcast(&_nElem, 1, MPI_INT, _mProc, comm());
        }
        else
        {
            _parallelLegacyVtkLoader();
        }
    }


    //Gmsh
    void MeshLoader::_serialGmshLoader()
    {
        //Read file
        ifstream file(_name);
        string line;
        bool loadNodes{false}, loadConnec{false}, loadCreases{false}, loadEFlags{false};
        vector<int> _tmp_glob_connec;
        while (getline(file, line))
        {
            //Skip lines that are empty or only white spaces
            if (line.empty())
                continue;
            if (line.find_first_not_of(' ') == string::npos)
                continue;

            //Get line and store info in a vector
            std::istringstream iss(line);
            vector<string> tokens{istream_iterator<string>{iss}, istream_iterator<string>{}};

            //Read node coordinates
            if (tokens[0] == "$Nodes")
            {
                //Read number of points
                vector<int> ibuff;
                fillVectorData<int>(ibuff, file, 4);
                int nEntitites = ibuff[0];
                _nPts = ibuff[1];

                //Resize x_nodes
                _glob_x_nodes.resize(_nPts*_nDim);

                //Loop over entities
                int n{0};
                for (int i = 0; i < nEntitites; i++)
                {
                    //Read number of nodes in this entity
                    fillVectorData<int>(ibuff, file, 4);
                    int nEnt = ibuff[3];

                    //Skip lines with node tags
                    fillVectorData<int>(ibuff, file, nEnt);

                    //Read x_nodes
                    fillVectorData<double>(_glob_x_nodes, file, nEnt*_nDim, 1, 0, 0, (ibuff[0]-1)*_nDim, false);

                    n += nEnt*_nDim;
                }
                loadNodes = true;

                continue;
            }

            //Read connectivity
            if (tokens[0] == "$Elements")
            {
                //Read number of entities
                vector<int> ibuff;
                fillVectorData<int>(ibuff, file, 4);
                int nEntitites = ibuff[0];

                //Loop over entities
                _nElem = 0;
                for (int i = 0; i < nEntitites; i++)
                {
                    //Read element description in this entity
                    fillVectorData<int>(ibuff, file, 4);
                    int eT   = ibuff[2];
                    int nEnt = ibuff[3];

                    //Compute nVert for this entity
                    BasisFuncType gBfType;
                    ElemType gEType;
                    int gBfOrder;
                    gmshTohlElemType(eT, gEType, gBfType, gBfOrder);
                    int gNVert = computeNVert(gBfType, gEType, gBfOrder);

                    //Read connectivity
                    fillVectorData<int>(ibuff, file, nEnt, gNVert+1, 1);

                    //Save connectivity of matching elements
                    if (gEType == _eType and gBfType == _bfType and gBfOrder == _bfOrder)
                    {
                        for (size_t j = 0; j < ibuff.size(); j++)
                            ibuff[j] -= 1;

                        _nElem += nEnt;
                        _tmp_glob_connec.reserve(_nElem);
                        _tmp_glob_connec.insert(_tmp_glob_connec.end(), ibuff.begin(), ibuff.end());
                        loadConnec = true;
                    }
                }

                continue;
            }

            //Read creases //FIXME

            //Read element flags //FIXME
        }

        //Close file
        file.close();


        //Check whether nodes and connectivities were read
        if (!loadNodes || !loadConnec)
            throw runtime_error("MeshLoader::loadGmsh: There was a problem loading the mesh information. Please, check the element type, basis function type and order.");

        //If there are no creases, we create them
        if (loadCreases == false)
            _glob_creases.resize(_nPts * _nCreases, 0);
        // for (int i = 0; i < _nPts; i++)
        //     _glob_creases[_nCreases*i + 1] = -1; FIXME:: Add this when the previous fixme has been corrected

        //If there are no element flags, we create them
        if (loadEFlags == false)
            _glob_eflags.resize(_nElem * _nEFlags, 0);

        //Reorder connectivity
        if (_bfType != BasisFuncType::SubdivSurfs)
        {
            vector<int> reorder = vtkReordering(_eType, _bfType, _bfOrder, true);
            int pos{};
            _glob_connec.resize(_nElem*_nVert);
            for (int e = 0; e < _nElem; e++)
            {
                for (int v = 0; v < _nVert; v++)
                    _glob_connec[pos+v] = _tmp_glob_connec[pos+reorder[v]];
                pos += _nVert;
            }
        }
        else
        {
            _glob_connec = _tmp_glob_connec;
        }
    }

    void MeshLoader::_parallelGmshLoader()
    {
        //Read file
        ifstream file(_name);
        string line;
        bool loadNodes{false}, loadConnec{false}, loadCreases{false}, loadEFlags{false};
        vector<int> _tmp_connec;
        vector<double> _tmp_x_nodes;
        vector<int> nodeMap;
        while (getline(file, line))
        {
            //Skip lines that are empty or only white spaces
            if (line.empty())
                continue;
            if (line.find_first_not_of(' ') == string::npos)
                continue;

            //Get line and store info in a vector
            std::istringstream iss(line);
            vector<string> tokens{istream_iterator<string>{iss}, istream_iterator<string>{}};

            //Read node coordinates
            if (tokens[0] == "$Nodes")
            {
                //Read number of points
                vector<int> ibuff;
                fillVectorData<int>(ibuff, file, 4);
                int nEntitites = ibuff[0];
                _loc_nPts = ibuff[1];

                //Create trivial point distribution
                _disPts.setLocNItem(_loc_nPts);
                _disPts.setNItem(0);
                _disPts.Update();
                _nPts = _disPts.nItem();

                //Resize tmp x_nodes
                _tmp_x_nodes.resize(_loc_nPts*_nDim);
                // vector<int> _nodeMap(_loc_nPts);

                //Loop over entities
                int n{0};
                for (int i = 0; i < nEntitites; i++)
                {
                    //Read number of nodes in this entity
                    fillVectorData<int>(ibuff, file, 4);
                    int nEnt = ibuff[3];

                    //Read node tags
                    fillVectorData<int>(ibuff, file, nEnt);
                    for (int j = 0; j < nEnt; j++) //FIXME
                        nodeMap.push_back(ibuff[j]);
                    // fillVectorData<int>(nodeMap, file, nEnt, 1, 0, 0, , false);

                    //Read x_nodes
                    fillVectorData<double>(_tmp_x_nodes, file, nEnt*_nDim, 1, 0, 0, n, false);

                    n += nEnt*_nDim;
                }
                loadNodes = true;

                continue;
            }


            //Read connectivity
            if (tokens[0] == "$Elements")
            {
                //Read number of entities
                vector<int> ibuff;
                fillVectorData<int>(ibuff, file, 4);
                int nEntitites = ibuff[0];

                //Loop over entities
                _loc_nElem = 0;
                for (int i = 0; i < nEntitites; i++)
                {
                    //Read element description in this entity
                    fillVectorData<int>(ibuff, file, 4);
                    int eT   = ibuff[2];
                    int nEnt = ibuff[3];

                    //Compute nVert for this entity
                    BasisFuncType gBfType;
                    ElemType gEType;
                    int gBfOrder;
                    gmshTohlElemType(eT, gEType, gBfType, gBfOrder);
                    int gNVert = computeNVert(gBfType, gEType, gBfOrder);

                    //Read connectivity
                    fillVectorData<int>(ibuff, file, nEnt, gNVert+1, 1);

                    //Save connectivity of matching elements
                    if (gEType == _eType and gBfType == _bfType and gBfOrder == _bfOrder)
                    {
                        _loc_nElem += nEnt;
                        _tmp_connec.reserve(_loc_nElem);
                        _tmp_connec.insert(_tmp_connec.end(), ibuff.begin(), ibuff.end());
                        loadConnec = true;
                    }
                }

                //Create trivial element distribution
                _disElem.setLocNItem(_loc_nElem);
                _disElem.setNItem(0);
                _disElem.Update();
                _nElem = _disElem.nItem();

                continue;
            }

            //Read creases //FIXME

            //Read element flags //FIXME
        }

        //Close file
        file.close();

        //Check whether nodes and connectivities were read
        if (!loadNodes || !loadConnec)
            throw runtime_error("MeshLoader::loadGmsh: There was a problem loading the mesh information. Please, check the element type, basis function type and order.");

        //If there are no creases, we create them
        if (loadCreases == false)
            _creases.resize(_loc_nPts * _nCreases, 0);
        // for (int i = 0; i < _nPts; i++)
        //     _glob_creases[_nCreases*i + 1] = -1; FIXME:: Add this when the previous fixme has been corrected

        //If there are no element flags, we create them
        if (loadEFlags == false)
            _eflags.resize(_loc_nElem * _nEFlags, 0);

        //Share gmsh global node tags
        vector<int> rsizes(_numProcs);
        for (int i = 0; i < _numProcs; ++i)
            rsizes[i] = _disPts.proc_nItem(i);
        vector<int> displs(_numProcs);
        for (int i = 0; i < _numProcs; ++i)
            displs[i] = accumulate(rsizes.begin(), rsizes.begin()+i, 0);
        vector<int> glob_nodeMap(_nPts);
        MPI_Allgatherv(nodeMap.data(), rsizes[_myRank], MPI_INT, glob_nodeMap.data(), rsizes.data(), displs.data(), MPI_INT, MPI_COMM_WORLD);

        // Create a map to store the frequency of each node
        std::map<int, int> countMap;
        for (auto & elem : glob_nodeMap)
        {
            auto result = countMap.insert(std::pair<int, int>(elem, 1));
            if (result.second == false)
                result.first->second++;
        }

        // Iterate over the map and store the nodes to delete
        vector<int> delNodes;
        for (auto & elem : countMap)
        {
            // If frequency count is greater than 1 then its a duplicate element
            if (elem.second > 1)
            {
                int f = elem.second;
                for (size_t i = 0; i < glob_nodeMap.size(); i++)
                {
                    if (glob_nodeMap[i] == elem.first)
                    {
                        delNodes.push_back(i);
                        f--;
                    }
                    if (f < 2)
                        break;
                }
            }
        }
        sort(delNodes.begin(), delNodes.end(), greater<int>());

        //Remove nodes shared by partitions
        for (size_t i = 0; i < delNodes.size(); i++)
        {
            glob_nodeMap.erase(glob_nodeMap.begin()+delNodes[i]);
            if (_disPts.isItemInPart(delNodes[i]))
            {
                int n = _disPts.locIdx(delNodes[i]);
                _tmp_x_nodes.erase(_tmp_x_nodes.begin()+n*_nDim, _tmp_x_nodes.begin()+n*_nDim+_nDim);
                _loc_nPts--;
            }
        }
        _disPts.setLocNItem(_loc_nPts);
        _disPts.setNItem(0);
        _disPts.Update();
        _nPts = _disPts.nItem();

        //Reorder x_nodes
        _x_nodes.resize(_loc_nPts*_nDim, 0.0);
        int i{0};
        for (int n = 0; n < _loc_nPts; n++)
        {
            for (int d = 0; d < _nDim; d++)
            {
                _x_nodes[_loc_nPts*d+n] = _tmp_x_nodes[i];
                i++;
            }
        }

        //Copy vector into map (map is logN in find)
        std::map<int, int> g_nodeMap;
        for (size_t i = 0; i < glob_nodeMap.size(); i++)
            g_nodeMap.insert(std::pair<int, int>(glob_nodeMap[i], i));

        //Relabel connectivity
        for (int i = 0; i < _loc_nElem*_nVert; i++)
            _tmp_connec[i] = (g_nodeMap.find(_tmp_connec[i])->second);

        //Reorder connectivity
        if (_bfType != BasisFuncType::SubdivSurfs)
        {
            vector<int> reorder = vtkReordering(_eType, _bfType, _bfOrder, true);
            int pos{};
            _connec.resize(_loc_nElem*_nVert);
            for (int e = 0; e < _loc_nElem; e++)
            {
                for (int v = 0; v < _nVert; v++)
                    _connec[pos+v] = _tmp_connec[pos+reorder[v]];
                pos += _nVert;
            }
        }
        else
        {
            _connec = _tmp_connec;
        }
    }

    void MeshLoader::_loadGmsh()
    {
        //Checks
        if ((_bfType == BasisFuncType::BSplines) or (_bfType == BasisFuncType::Nurbs))
            throw runtime_error("MeshLoader::loadLegacyVtk: Currently, the legacy vtk loader cannot read Bsplines/Nurbs meshes.");

        //Initialize
        _pDim = computePDim(_eType);
        if (_bfType != BasisFuncType::BSplines and _bfType != BasisFuncType::Nurbs)
            _nVert = computeNVert(_bfType, _eType, _bfOrder);
        else
            _nVert = computeNVert(_bfType, _eType, _bfOrderX, _bfOrderY, _bfOrderZ);

        //Load file
        if (_meshType == MeshType::Sequential)
        {
            //Load file in processor _mProc
            if (myRank() == _mProc)
            {
                _serialGmshLoader();
            }
            else
            {
                _glob_x_nodes.resize(_nDim, 0);
                _glob_connec.resize(_nDim, 0);
                _glob_creases.resize(_nCreases, 0);
                _glob_eflags.resize(_nEFlags, 0);
            }

            //Communicate number of points and elements
            MPI_Barrier(comm());
            MPI_Bcast(&_nPts, 1, MPI_INT, _mProc, comm());
            MPI_Bcast(&_nElem, 1, MPI_INT, _mProc, comm());
        }
        else
        {
            _parallelGmshLoader();
        }

    }


    //Checks
    void MeshLoader::_performSettingChecks()
    {
        if (_nDim == 0)
            throw runtime_error("MeshLoader: nDim has not been set.");

        if (_eType == ElemType::Undefined)
            throw runtime_error("MeshLoader: Element type has not been set");

        if (_bfType == BasisFuncType::Undefined)
            throw runtime_error("MeshLoader: Basis functions type has not been set");

        if (_bfOrder < 0 && _bfOrderX < 0 && _bfOrderY < 0 && _bfOrderZ < 0 && _bfType != BasisFuncType::Linear && _bfType != BasisFuncType::SubdivSurfs)
            throw runtime_error("MeshLoader: The order of the basis functions has not been set or it is negative.");

        //Order zero is not allowed
        if (_bfOrder == 0 || _bfOrderX == 0 || _bfOrderY == 0 || _bfOrderZ == 0)
            throw runtime_error("MeshLoader: In the current implementation, the order of the basis functions cannot be zero.");

        //Linear elements: Check order or set it to one if the user did not
        if (_bfType == BasisFuncType::Linear)
        {
            if ((_bfOrder > 1) or (_bfOrder == 0))
                throw runtime_error("MeshLoader: The order of linear elements must be set to one or not set.");
            else if (_bfOrder == -1)
                _bfOrder = 1;
            if (_bfOrderX != -1 or _bfOrderY != -1 or _bfOrderZ != -1)
                throw runtime_error("MeshLoader: setBasisFuncOrderDir: Order per direction cannot be set for linear elements.");
        }

        //Subdivision surfaces: The order is set it to two if the user did not
        if (_bfType == BasisFuncType::SubdivSurfs)
        {
            if ((_bfOrder != 2) and (_bfOrder != -1))
                throw runtime_error("MeshLoader: The order of subdivision surfaces must be set to two or not set.");
            else if (_bfOrder == -1)
                _bfOrder = 2;

            if (_bfOrderX != -1 or _bfOrderY != -1 or _bfOrderZ != -1)
                throw runtime_error("MeshLoader: setBasisFuncOrderDir: Order per direction cannot be set for subdivision surfaces.");
        }

        //Lagrangian elements
        if (_bfType == BasisFuncType::Lagrangian)
        {
            if (_bfOrderX != -1 or _bfOrderY != -1 or _bfOrderZ != -1)
                throw runtime_error("MeshLoader: setBasisFuncOrderDir: Order per direction cannot be set for Lagrangian elements.");
        }

        //Bsplines and Nurbs
        if ((_bfType == BasisFuncType::BSplines) or (_bfType == BasisFuncType::Nurbs))
        {
            if (_bfOrder != -1)
            {
                switch (int(_eType))
                {
                    case static_cast<int>(ElemType::Line):
                        _bfOrderX = _bfOrder;
                        break;
                    case static_cast<int>(ElemType::Square):
                    case static_cast<int>(ElemType::Triang):
                        _bfOrderX = _bfOrder;
                        _bfOrderY = _bfOrder;
                        break;
                    case static_cast<int>(ElemType::Parallelep):
                    case static_cast<int>(ElemType::Tetrah):
                        _bfOrderX = _bfOrder;
                        _bfOrderY = _bfOrder;
                        _bfOrderZ = _bfOrder;
                        break;
                    default:
                        throw runtime_error("MeshLoader: Element type is wrong or has not been set.");
                }
            }
            else
            {
                _bfOrder = std::max({_bfOrderX, _bfOrderY, _bfOrderZ}); //FIXME: Assume constant order for output to vtk purposes. Remove this and create specific vtk for bsplines/Nurbs
            }

            switch (int(_eType))
            {
                case static_cast<int>(ElemType::Line):
                    if ((_bfOrderX == -1) || (_bfOrderY != -1  || _bfOrderZ != -1))
                        throw runtime_error("MeshLoader: The order of Line elements should (only) be set in x direction.");
                    break;
                case static_cast<int>(ElemType::Triang):
                    if ((_bfOrderX == -1 || _bfOrderY == -1)  || _bfOrderZ != -1)
                        throw runtime_error("MeshLoader: The order of Triang elements should (only) be set  in x and y direction.");
                    break;
                case static_cast<int>(ElemType::Square):
                    if ((_bfOrderX == -1 || _bfOrderY == -1)  || _bfOrderZ != -1)
                        throw runtime_error("MeshLoader: The order of Square elements should (only) be set in x and y direction.");
                    break;
                case static_cast<int>(ElemType::Tetrah):
                    if (_bfOrderX == -1 || _bfOrderY == -1  || _bfOrderZ == -1)
                        throw runtime_error("MeshLoader: The order of Tetrah elements should be set in x, y and z direction.");
                    break;
                case static_cast<int>(ElemType::Parallelep):
                    if (_bfOrderX == -1 || _bfOrderY == -1  || _bfOrderZ == -1)
                        throw runtime_error("MeshLoader: The order of Parallelep elements should be set in x, y and z direction.");
                    break;
                default:
                    throw runtime_error("MeshLoader: Wrong element type.");
            }
        }

        //Check file
        _checkFileExists(_name);
    }

    void MeshLoader::_printMesh(const std::string& mssg)
    {
        if (_meshType == MeshType::Sequential)
        {
            if (_myRank == 0)
            {
                cout << endl << mssg << endl;
                cout << " bf: " << str(_bfType) << endl;
                cout << " eType: " << str(_eType) << endl;

                cout << " nPts: " << _nPts << " " << _loc_nPts << endl;
                cout << " nEle: " << _nElem << " " << _loc_nElem << " ("<< _nEx << ", " <<  _nEy << ", " <<  _nEz << ")" << endl;
                cout << " Ord:  "<< _bfOrder << " ("<< _bfOrderX << ", " << _bfOrderY << ", " << _bfOrderZ << ")" << endl;

                cout << " xnodes:" << endl;
                for (int i = 0; i < _nPts; i++)
                {
                    cout << "   " << i << " - ";
                    for (int j = 0; j < _nDim; j++)
                        cout << _glob_x_nodes[_nDim * i + j] << " ";
                    cout << endl;
                }

                cout << " connec:" << endl;
                for (int i = 0; i < _nElem; i++)
                {
                    cout << "   "  << i << " - ";
                    for (int j = 0; j < _nVert; j++)
                        cout << _glob_connec[_nVert * i + j] << " ";
                    cout << endl;
                }

                cout << " creases:" << endl;
                for (int i = 0; i < _nPts; i++)
                {
                    cout << "   " << i << " - ";
                    for (int j = 0; j < _nCreases; j++)
                        cout << _glob_creases[_nCreases * i + j] << " ";
                    cout << endl;
                }

            }
        }
        else
        {
            if (_myRank == 0)
                cout << endl << mssg << endl;

            for (int p = 0; p < _numProcs; p++)
            {
                if (_myRank == p)
                {
                    cout << "Processor: " << p << endl;
                    cout << " bf: " << str(_bfType) << endl;
                    cout << " eType: " << str(_eType) << endl;

                    cout << " nPts: " << _nPts << " " << _loc_nPts << endl;
                    cout << " nEle: " << _nElem << " " << _loc_nElem << " ("<< _nEx << ", " <<  _nEy << ", " <<  _nEz << ")" << endl;
                    cout << " Ord:  "<< _bfOrder << " ("<< _bfOrderX << ", " << _bfOrderY << ", " << _bfOrderZ << ")" << endl;

                    cout << " xnodes:" << endl;
                    int n = 0;
                    for (int i = 0; i < _nPts; i++)
                    {
                        if(_disPts.isItemInPart(n))
                        {
                            int locN = _disPts.locIdx(n);
                            cout << "   " << i << " - ";
                            for (int j = 0; j < _nDim; j++)
                                cout << _x_nodes[_loc_nPts * j + locN] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    cout << " connec:" << endl;
                    n = 0;
                    for (int i = 0; i < _nElem; i++)
                    {
                        if(_disElem.isItemInPart(n))
                        {
                            int locN = _disElem.locIdx(n);
                            cout << "   "  << i << " - ";
                            for (int j = 0; j < _nVert; j++)
                                cout << _connec[locN * _nVert + j] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    cout << " creases:" << endl;
                    n = 0;
                    for (int i = 0; i < _nPts; i++)
                    {
                        if(_disPts.isItemInPart(n))
                        {
                            int locN = _disPts.locIdx(n);
                            cout << "   " << i << " - ";
                            for (int j = 0; j < _nCreases; j++)
                                cout << _creases[_loc_nPts * j + locN] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    cout << " eflags:" << endl;
                    n = 0;
                    for (int i = 0; i < _nElem; i++)
                    {
                        if(_disElem.isItemInPart(n))
                        {
                            int locN = _disElem.locIdx(n);
                            cout << "   "  << i << " - ";
                            for (int j = 0; j < _nEFlags; j++)
                                cout << _eflags[locN * _nEFlags + j] << " ";
                            cout << endl;
                        }
                        n++;
                    }

                    if ((_bfType == BasisFuncType::Nurbs) || (_bfType == BasisFuncType::BSplines))
                    {
                        cout << " U : " << endl << "   ";
                        for (auto u: _uKnot)
                            cout << u << " ";
                        cout << endl;
                        cout << " V : " << endl << "   ";
                        for (auto u: _vKnot)
                            cout << u << " ";
                        cout << endl;
                        cout << " W : " << endl << "   ";
                        for (auto u: _wKnot)
                            cout << u << " ";
                        cout << endl;
                        cout << " CP :" << endl;
                        for (auto i = 0u; i < _CP.size(); i++)
                        {
                            for (auto j = 0u; j < _CP[i].size(); j++)
                            {
                                for (auto k = 0u; k < _CP[i][j].size(); k++)
                                {
                                    cout << "  ";
                                    for (int d = 0; d < 4; d++)
                                    {
                                        cout << " " << _CP[i][j][k][d];
                                    }
                                    cout << endl;
                                }
                            }
                        }
                    }

                }
                Barrier();
            }

        }
    }

}
