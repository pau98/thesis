/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <vector>
#include <functional>
#include <deque>

#include "hl_TypeDefs.h"
#include "hl_BasicMeshGenerator.h"

using std::cout;
using std::endl;
using std::vector;
using std::runtime_error;

namespace hiperlife
{
    //Save and reload mesh
    void BasicMeshGenerator::_saveMesh()
    {
        return;
    }

    void BasicMeshGenerator::_reloadMesh()
    {
        return;
    }


    //Derived meshes
    void BasicMeshGenerator::_getPRefinedMesh(int orderInc)
    {
        (void) orderInc;
        throw runtime_error("BasicMeshGenerator::getPRefinedMesh: Not implemented.");
    }

    void BasicMeshGenerator::_getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ)
    {
        (void) orderIncX;
        (void) orderIncY;
        (void) orderIncZ;
        throw runtime_error("BasicMeshGenerator::getPRefinedMesh: Not implemented.");
    }

    void BasicMeshGenerator::_getHRefinedMesh(int refLevel)
    {
        (void) refLevel;
        throw runtime_error("BasicMeshGenerator::getHRefinedMesh: Not implemented.");
    }

    void BasicMeshGenerator::_getBoundaryMesh(vector<MAxis> vMAx)
    {
        (void) vMAx;
        throw runtime_error("BasicMeshGenerator::getBoundaryMesh: Not implemented.");
    }


    //Utils
    void BasicMeshGenerator::_printMesh(const std::string& mssg)
    {
        if (_myRank == 0)
            cout << endl << mssg << endl;

        for (int p = 0; p < _numProcs; p++)
        {
            Barrier();
            if (_myRank == p)
            {
                cout << "Processor: " << p << endl;
                cout << " bf: " << str(_bfType) << endl;
                cout << " eType: " << str(_eType) << endl;

                cout << " nPts: " << _nPts << " " << _loc_nPts << endl;
                cout << " nEle: " << _nElem << " " << _loc_nElem << " ("<< _nEx << ", " <<  _nEy << ", " <<  _nEz << ")" << endl;
                cout << " Ord:  "<< _bfOrder << " ("<< _bfOrderX << ", " << _bfOrderY << ", " << _bfOrderZ << ")" << endl;

                cout << " xnodes:" << endl;
                int n = 0;
                for (int i = 0; i < _loc_nPts; i++)
                {
                    cout << "   " << i << " - ";
                    for (int j = 0; j < _nDim; j++)
                        cout << _x_nodes[_loc_nPts * j + i] << " ";
                    cout << endl;
                    n++;
                }

                cout << " connec:" << endl;
                n = 0;
                for (int i = 0; i < _loc_nElem; i++)
                {
                    cout << "   "  << i << " - ";
                    for (int j = 0; j < _nVert; j++)
                        cout << _connec[i * _nVert + j] << " ";
                    cout << endl;
                    n++;
                }

                cout << " creases:" << endl;
                n = 0;
                for (int i = 0; i < _loc_nPts; i++)
                {
                    cout << "   " << i << " - ";
                    for (int j = 0; j < _nCreases; j++)
                        cout << _creases[_loc_nPts * j + i] << " ";
                    cout << endl;
                    n++;
                }

                cout << " eflags:" << endl;
                n = 0;
                for (int i = 0; i < _loc_nElem; i++)
                {
                    cout << "   "  << i << " - ";
                    for (int j = 0; j < _nEFlags; j++)
                        cout << _eflags[i * _nEFlags + j] << " ";
                    cout << endl;
                }

                if ((_bfType == BasisFuncType::Nurbs) || (_bfType == BasisFuncType::BSplines))
                {
                    cout << " U : " << endl << "   ";
                    for (auto u: _uKnot)
                        cout << u << " ";
                    cout << endl;
                    cout << " V : " << endl << "   ";
                    for (auto u: _vKnot)
                        cout << u << " ";
                    cout << endl;
                    cout << " W : " << endl << "   ";
                    for (auto u: _wKnot)
                        cout << u << " ";
                    cout << endl;
                    cout << " CP :" << endl;
                    for (auto i = 0u; i < _CP.size(); i++)
                    {
                        for (auto j = 0u; j < _CP[i].size(); j++)
                        {
                            for (auto k = 0u; k < _CP[i][j].size(); k++)
                            {
                                cout << "  ";
                                for (int d = 0; d < 4; d++)
                                {
                                    cout << " " << _CP[i][j][k][d];
                                }
                                cout << endl;
                            }
                        }
                    }
                }

            }
            Barrier();
        }


    }

}
