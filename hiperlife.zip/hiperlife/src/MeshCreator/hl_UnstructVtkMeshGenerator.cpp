/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <array>


#include "hl_TypeDefs.h"
#include "hl_UnstructVtkMeshGenerator.h"
#include "hl_Math.h"

#include <vtkDoubleArray.h>
#include <vtkPlaneSource.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>
#include <vtkDiskSource.h>
#include <vtkParametricTorus.h>
#include <vtkParametricFunctionSource.h>
#include <vtkCleanPolyData.h>
#include <vtkPointData.h>
#include <vtkPolyDataWriter.h>
#include <vtkPolyDataReader.h>
#include <vtkTriangleFilter.h>
#include <vtkCellLocator.h>
#include <vtkFeatureEdges.h>
#include <vtkDataSetSurfaceFilter.h>
#include <vtkLinearSubdivisionFilter.h>
#include <vtkPointLocator.h>
#include <vtkSmoothPolyDataFilter.h>
#include <vtkCylinderSource.h>

#include "vtkSurfaceRemeshing.h"


using std::cout;
using std::endl;
using std::vector;
using std::array;
using std::runtime_error;

namespace hiperlife
{

    void UnstructVtkMeshGenerator::genPlane(std::function<double(double[3])> h)
    {
        _performOrderChecks();

        _nDim = 3;
        _pDim = 2;

        _nVert = 3;
        _nCreases = 2;

        double center[3] = {0.0,0.0,0.0};
        double a = 1.0;
        double b = 1.0;

        if ( myRank() == 0 )
        {

            // Create a plane
            vtkSmartPointer<vtkPlaneSource> planeSource = vtkSmartPointer<vtkPlaneSource>::New();
            planeSource->SetCenter(0.0, 0.0, 0.0);
            planeSource->SetNormal(0.0, 0.0, 1.0);
//            planeSource->SetPoint1(0.0, 0.0, 0.0);
//            planeSource->SetPoint2(1.0, 1.0, 0.0);
            planeSource->SetResolution(int(1.0/0.01), int(1.0/0.01));
            planeSource->Update();

            vtkSmartPointer<vtkTriangleFilter> triangFilter = vtkSmartPointer<vtkTriangleFilter>::New();
            triangFilter->SetInputData(planeSource->GetOutput());
            triangFilter->Update();

            vtkSmartPointer<vtkPolyData> vtkoutput = triangFilter->GetOutput();
            int nPts = vtkoutput->GetNumberOfPoints();

            vtkSmartPointer<vtkDoubleArray> h_VTK = vtkDoubleArray::New();
            h_VTK->SetNumberOfComponents(1);
            for( int i = 0; i < nPts; i++ )
            {
                double x[3];
                vtkoutput->GetPoint(i, x);
                double l = h(x);
                h_VTK->InsertNextValue(l*l);
            }
            h_VTK->SetName("AreaArray");
            vtkoutput->GetPointData()->SetScalars(h_VTK);

            vtkSmartPointer<vtkSurfaceRemeshing> vtkRemeshing = vtkSurfaceRemeshing::New();

            vtkRemeshing->SetInputData( vtkoutput );
            vtkRemeshing->SetElementSizeModeToTargetAreaArray();
            vtkRemeshing->SetTargetAreaArrayName("AreaArray");
            vtkRemeshing->SetNumberOfIterations(10);
            vtkRemeshing->SetAspectRatioThreshold(1.1);
//            vtkRemeshing->SetCollapseAngleThreshold(1.0);
            vtkRemeshing->SetTriangleSplitFactor(10.0);
            vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(500);
//            vtkRemeshing->SetPreserveBoundaryEdges(true);
            vtkRemeshing->Update();


            vtkSmartPointer<vtkCleanPolyData> vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData( vtkRemeshing->GetOutput() );
            vtkClean->Update();

            vtkoutput = vtkClean->GetOutput();



            vtkSmartPointer<vtkCellLocator> cellLocator = vtkCellLocator::New();
            cellLocator->SetDataSet(vtkoutput);
            cellLocator->BuildLocator();

            nPts = vtkoutput->GetNumberOfPoints();
            for ( int i = -1; i <=1 ; i+=2 )
            {
                for ( int j = -1; j <= 1; j+=2 )
                {
                    double point[3] = {center[0]+0.5*i*a,center[1]+0.5*j*b,center[2]};

                    vtkoutput->GetPoints()->InsertNextPoint(point);
                    nPts++;

                    double cpoint[3];
                    vtkIdType cellId;
                    int subId;
                    double dist;
                    cellLocator->FindClosestPoint(point, cpoint, cellId, subId, dist);


//                    cout << "Point=(" << point[0] << ", " << point[1] << ", " << point[2] << ")";
//                    cout << " CellId=" << cellId << " SubId=" << subId << endl;
//
                    vtkSmartPointer<vtkCell> cell = vtkoutput->GetCell(cellId);
                    vtkSmartPointer<vtkIdList> points = cell->GetPointIds();

//                    cout << points->GetId(0) << " " << points->GetId(1) << " " <<  points->GetId(2) << endl;


                    int i1 = points->GetId(0);
                    int i2 = points->GetId(1);
                    int i3 = points->GetId(2);

                    double x1[3], x2[3], x3[3];
                    vtkoutput->GetPoint(i1, x1);
                    vtkoutput->GetPoint(i2, x2);
                    vtkoutput->GetPoint(i3, x3);

//                    cout << x1[0] << " " << x1[1] << " " << x1[2] << endl;
//                    cout << x2[0] << " " << x2[1] << " " << x2[2] << endl;
//                    cout << x3[0] << " " << x3[1] << " " << x3[2] << endl;

                    double xmid1[3] = {0.5*(x2[0]+x3[0]),0.5*(x2[1]+x3[1]),0.5*(x2[2]+x3[2])};
                    double xmid2[3] = {0.5*(x1[0]+x3[0]),0.5*(x1[1]+x3[1]),0.5*(x1[2]+x3[2])};
                    double xmid3[3] = {0.5*(x1[0]+x2[0]),0.5*(x1[1]+x2[1]),0.5*(x1[2]+x2[2])};


                    double d1 = Math::Dist3D(x1, point);
                    double d2 = Math::Dist3D(x2, point);
                    double d3 = Math::Dist3D(x3, point);

                    double dmid1 = Math::Dist3D(xmid1, point);
                    double dmid2 = Math::Dist3D(xmid2, point);
                    double dmid3 = Math::Dist3D(xmid3, point);

                    if ( (dmid1 <= dmid2 and dmid1<=dmid3) and (dmid1 >= d2 or dmid1 <= d3) )
                    {
                        vtkoutput->GetPoints()->InsertNextPoint(xmid1);
                        nPts++;

                        vtkSmartPointer<vtkIdList> newpoints = vtkIdList::New();
                        newpoints->InsertId(0, nPts-2);
                        newpoints->InsertId(1, nPts-1);
                        newpoints->InsertId(2, i2);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        newpoints = vtkIdList::New();
                        newpoints->InsertId(0, nPts-2);
                        newpoints->InsertId(1, i3);
                        newpoints->InsertId(2, nPts-1);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        newpoints = vtkIdList::New();
                        newpoints->InsertId(0, i3);
                        newpoints->InsertId(1, i1);
                        newpoints->InsertId(2, nPts-1);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        vtkoutput->ReplaceCellPoint(cellId, i3, nPts-1);


                    }
                    else if ( (dmid2 <= dmid1 and dmid2<=dmid3) and (dmid2 >= d1 or dmid2 <= d3) )
                    {
                        vtkoutput->GetPoints()->InsertNextPoint(xmid2);
                        nPts++;

                        vtkSmartPointer<vtkIdList> newpoints = vtkIdList::New();
                        newpoints->InsertId(0, nPts-2);
                        newpoints->InsertId(1, nPts-1);
                        newpoints->InsertId(2, i3);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        newpoints = vtkIdList::New();
                        newpoints->InsertId(0, nPts-2);
                        newpoints->InsertId(1, i1);
                        newpoints->InsertId(2, nPts-1);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        newpoints = vtkIdList::New();
                        newpoints->InsertId(0, i1);
                        newpoints->InsertId(1, i2);
                        newpoints->InsertId(2, nPts-1);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        vtkoutput->ReplaceCellPoint(cellId, i1, nPts-1);
                    }
                    else if ( (dmid3 <= dmid1 and dmid3<=dmid1) and (dmid3 >= d1 or dmid3 <= d2) )
                    {
                        vtkoutput->GetPoints()->InsertNextPoint(xmid3);
                        nPts++;

                        vtkSmartPointer<vtkIdList> newpoints = vtkIdList::New();
                        newpoints->InsertId(0, nPts-2);
                        newpoints->InsertId(1, nPts-1);
                        newpoints->InsertId(2, i1);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        newpoints = vtkIdList::New();
                        newpoints->InsertId(0, nPts-2);
                        newpoints->InsertId(1, i2);
                        newpoints->InsertId(2, nPts-1);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        newpoints = vtkIdList::New();
                        newpoints->InsertId(0, i2);
                        newpoints->InsertId(1, i3);
                        newpoints->InsertId(2, nPts-1);

                        vtkoutput->InsertNextCell(VTK_TRIANGLE, newpoints);

                        vtkoutput->ReplaceCellPoint(cellId, i2, nPts-1);
                    }
                    else
                        throw runtime_error("UnstructVtkMeshGenerator::genPlane::Error: corner point does not match conditions");

                }
            }

            _nPts  = vtkoutput->GetNumberOfPoints();
            _nElem = vtkoutput->GetNumberOfCells();

            _glob_x_nodes.resize(_nPts*_nDim,0.0);
            _glob_creases.resize(_nPts*_nCreases,0);

            for( int i = 0; i < _nPts; i++ )
            {
                double x[3];
                vtkoutput->GetPoint(i, x);
                _glob_x_nodes[_nDim*i+0] = x[0];
                _glob_x_nodes[_nDim*i+1] = x[1];
                _glob_x_nodes[_nDim*i+2] = 0.0;

                if ( x[0] < center[0] - 0.5*a+1.E-8 )
                {
                    _glob_creases[_nCreases*i+0] = 1;
                    _glob_creases[_nCreases*i+1] = 2;
                }
                else if ( x[0] > center[0] + 0.5*a-1.E-8  )
                {
                    _glob_creases[_nCreases*i+0] = 1;
                    _glob_creases[_nCreases*i+1] = 3;
                }
                if ( x[1] < center[1] - 0.5*b+1.E-8 )
                {
                    _glob_creases[_nCreases*i+0] = 1;
                    _glob_creases[_nCreases*i+1] = 5;
                }
                else if ( x[1] > center[1] + 0.5*b-1.E-8  )
                {
                    _glob_creases[_nCreases*i+0] = 1;
                    _glob_creases[_nCreases*i+1] = 7;
                }
                else
                    _glob_creases[_nCreases*i+1] = -1;

            }
            _glob_creases[_nCreases*(nPts-2)+0] = 2;
            _glob_creases[_nCreases*(nPts-2)+1] = 2*5;
            _glob_creases[_nCreases*(nPts-4)+0] = 2;
            _glob_creases[_nCreases*(nPts-4)+1] = 2*7;
            _glob_creases[_nCreases*(nPts-6)+0] = 2;
            _glob_creases[_nCreases*(nPts-6)+1] = 3*5;
            _glob_creases[_nCreases*(nPts-8)+0] = 2;
            _glob_creases[_nCreases*(nPts-8)+1] = 3*7;

            _glob_connec.resize(_nElem*_nVert,0);
            for( int i = 0; i < _nElem; i++ )
            {
                vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                _glob_connec[_nVert*i+0] = ptsIds->GetId(0);
                _glob_connec[_nVert*i+1] = ptsIds->GetId(1);
                _glob_connec[_nVert*i+2] = ptsIds->GetId(2);

            }

            _glob_eflags.resize(_nElem*_nEFlags,0);

            _vtkoutput = vtkoutput;
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nVert, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts,  1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());
    }

    void UnstructVtkMeshGenerator::genTorus(std::function<double(double[3])> h)
    {

        _performOrderChecks();

        _nDim = 3;
        _pDim = 2;

        _nVert = 3;
        _nCreases = 1;

        if ( myRank() == 0 )
        {
            vtkSmartPointer<vtkParametricTorus> fn = vtkSmartPointer<vtkParametricTorus>::New();
            fn->SetRingRadius(1);
            fn->SetCrossSectionRadius(0.5);

            vtkSmartPointer<vtkParametricFunctionSource> source = vtkParametricFunctionSource::New();
            source->SetParametricFunction(fn);
            source->SetUResolution(50);
            source->SetVResolution(30);
            source->Update();

            vtkSmartPointer<vtkPolyData> vtkoutput = source->GetOutput();


            vtkSmartPointer<vtkCleanPolyData> vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData( vtkoutput );
            vtkClean->SetPointMerging(true);
            vtkClean->SetConvertPolysToLines(false);
            vtkClean->SetConvertLinesToPoints(false);
            vtkClean->SetTolerance(1.E-8);
            vtkClean->Update();

            vtkoutput = vtkClean->GetOutput();

            int nPts = vtkoutput->GetNumberOfPoints();
            vtkSmartPointer<vtkDoubleArray> h_VTK = vtkDoubleArray::New();
            h_VTK->SetNumberOfComponents(1);
            for( int i = 0; i < nPts; i++ )
            {
                double x[3];
                source->GetOutput()->GetPoint(i, x);
                h_VTK->InsertNextValue(h(x));
            }
            h_VTK->SetName("AreaArray");
            vtkoutput->GetPointData()->SetScalars(h_VTK);

            vtkSmartPointer<vtkSurfaceRemeshing> vtkRemeshing = vtkSurfaceRemeshing::New();

            vtkRemeshing->SetInputData( vtkoutput );
            vtkRemeshing->SetElementSizeModeToTargetAreaArray();
            vtkRemeshing->SetTargetAreaArrayName("AreaArray");
            vtkRemeshing->SetNumberOfIterations(5);
            vtkRemeshing->SetAspectRatioThreshold(10.0);
            vtkRemeshing->SetCollapseAngleThreshold(1.0);
            vtkRemeshing->SetTriangleSplitFactor(10.0);
            vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(500);
            vtkRemeshing->SetPreserveBoundaryEdges(true);
            vtkRemeshing->Update();

            vtkClean->SetInputData(  vtkRemeshing->GetOutput() );
            vtkClean->SetPointMerging(true);
            vtkClean->SetConvertPolysToLines(false);
            vtkClean->SetConvertLinesToPoints(false);
            vtkClean->SetTolerance(1.E-8);
            vtkClean->Update();

            vtkoutput = vtkClean->GetOutput();

            _nPts  = vtkoutput->GetNumberOfPoints();
            _nElem = vtkoutput->GetNumberOfCells();

            _glob_x_nodes.resize(_nPts*_nDim,0.0);
            for( int i = 0; i < _nPts; i++ )
            {
                double x[3], targetx[3];
                vtkoutput->GetPoint(i, x);

                double z = x[2];

                double a = 0.5;
                double c = 1.0;

                double theta = atan2(x[1],x[0]);

                double aux = x[0]*cos(theta)+x[1]*sin(theta) - c;
                double phi = atan2(z,aux);
                targetx[0] = (c+a*cos(phi)) * cos(theta);
                targetx[1] = (c+a*cos(phi)) * sin(theta);
                targetx[2] = a*sin(phi);

                _glob_x_nodes[_nDim*i+0] = targetx[0];
                _glob_x_nodes[_nDim*i+1] = targetx[1];
                _glob_x_nodes[_nDim*i+2] = targetx[2];
            }

//            cout << "----------" << endl;
            _glob_connec.resize(_nElem*_nVert,0);
            for( int i = 0; i < _nElem; i++ )
            {
                vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                _glob_connec[_nVert*i+0] = ptsIds->GetId(0);
                _glob_connec[_nVert*i+1] = ptsIds->GetId(1);
                _glob_connec[_nVert*i+2] = ptsIds->GetId(2);

//                cout << _glob_connec[_nVert*i+0] << " ";
//                cout << _glob_connec[_nVert*i+1] << " ";
//                cout << _glob_connec[_nVert*i+2] << endl;
            }

            _glob_creases.resize(_nPts*_nCreases,0);
            _glob_eflags.resize(_nElem*_nEFlags,0);

            _vtkoutput = vtkoutput;

        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nVert, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts,  1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());

    }

    void UnstructVtkMeshGenerator::genCylinder(double radius, double height, bool cap, std::function<double(double[3])> h, std::function<std::array<double,3>(double[3])> def)
    {
        _performOrderChecks();

        _nDim = 3;
        _pDim = 2;

        _nVert = 3;
        _nCreases = 2;

        if ( myRank() == 0 )
        {
            vtkNew<vtkCylinderSource> cylinderSource;
            cylinderSource->SetCenter(0.0, 0.0, 0.0);
            cylinderSource->SetRadius(radius);
            cylinderSource->SetHeight(height);
            cylinderSource->SetResolution(100);
            if(!cap)
                cylinderSource->CappingOff();
            cylinderSource->Update();

            vtkSmartPointer<vtkTriangleFilter> triangleFilter = vtkSmartPointer<vtkTriangleFilter>::New();
            triangleFilter->SetInputConnection(cylinderSource->GetOutputPort());
            triangleFilter->Update();

            vtkSmartPointer<vtkPolyData> vtkoutput = triangleFilter->GetOutput();
            vtkIdType nPts = vtkoutput->GetNumberOfPoints();
            vtkSmartPointer<vtkDoubleArray> h_VTK = vtkDoubleArray::New();
            h_VTK->SetNumberOfComponents(1);
            for(vtkIdType i = 0; i < nPts; i++)
            {
                array<double,3> x{};
                vtkoutput->GetPoint(i, x.data());
                const double curr_rad = sqrt(x[0]*x[0]+x[2]*x[2]);
                x = {radius*x[0]/curr_rad, radius*x[2]/curr_rad, x[1]};
                vtkoutput->GetPoints()->SetPoint(i, x.data());

                h_VTK->InsertNextValue(h(x.data()));
            }
            h_VTK->SetName("AreaArray");
            vtkoutput->GetPointData()->SetScalars(h_VTK);

            vtkSmartPointer<vtkSurfaceRemeshing> vtkRemeshing = vtkSurfaceRemeshing::New();

            vtkRemeshing->SetInputData( vtkoutput );
            vtkRemeshing->SetElementSizeModeToTargetAreaArray();
            vtkRemeshing->SetTargetAreaArrayName("AreaArray");
            vtkRemeshing->SetNumberOfIterations(5);
            vtkRemeshing->SetAspectRatioThreshold(1.1);
            vtkRemeshing->SetCollapseAngleThreshold(0.1);
            vtkRemeshing->SetTriangleSplitFactor(10.0);
            vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(500);
            vtkRemeshing->Update();

            vtkSmartPointer<vtkCleanPolyData> vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData( vtkRemeshing->GetOutput() );
            vtkClean->Update();

            vtkoutput = vtkClean->GetOutput();
            if (def != nullptr)
            {
                nPts = vtkoutput->GetNumberOfPoints();
                h_VTK = vtkDoubleArray::New();
                h_VTK->SetNumberOfComponents(1);
                for( int i = 0; i < nPts; i++ )
                {
                    array<double,3> x{};
                    vtkoutput->GetPoint(i, x.data());
                    x = def(x.data());
                    vtkoutput->GetPoints()->SetPoint(i, x.data());
                    h_VTK->InsertNextValue(h(x.data()));
                }
                h_VTK->SetName("AreaArray");
                vtkoutput->GetPointData()->SetScalars(h_VTK);

                vtkoutput = vtkClean->GetOutput();
                vtkRemeshing->SetInputData( vtkoutput );
                vtkRemeshing->SetElementSizeModeToTargetAreaArray();
                vtkRemeshing->SetTargetAreaArrayName("AreaArray");
                vtkRemeshing->SetNumberOfIterations(5);
                vtkRemeshing->SetAspectRatioThreshold(1.1);
                vtkRemeshing->SetCollapseAngleThreshold(0.1);
                vtkRemeshing->SetTriangleSplitFactor(10.0);
                vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(500);
                vtkRemeshing->Update();

                vtkClean = vtkCleanPolyData::New();
                vtkClean->SetInputData( vtkRemeshing->GetOutput() );
                vtkClean->Update();

                vtkoutput = vtkClean->GetOutput();
            }

            _nPts  = static_cast<int>(vtkoutput->GetNumberOfPoints());
            _nElem = static_cast<int>(vtkoutput->GetNumberOfCells());

            _glob_x_nodes.resize(_nPts*_nDim,0.0);
            _glob_creases.resize(_nPts*_nCreases,0);
            for( int i = 0; i < _nPts; i++ )
            {
                double x[3];
                vtkoutput->GetPoint(i, x);
                _glob_x_nodes[_nDim*i+0] = x[0];
                _glob_x_nodes[_nDim*i+1] = x[1];
                _glob_x_nodes[_nDim*i+2] = x[2];

                const double hx = h(x);
                if(abs(abs(x[2])-0.5*height) < 0.01*hx) {
                    _glob_creases[_nCreases * i + 0] = 1;
                }
            }

            _glob_connec.resize(_nElem*_nVert,0);
            for( int i = 0; i < _nElem; i++ )
            {
                vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                _glob_connec[_nVert*i+0] = ptsIds->GetId(0);
                _glob_connec[_nVert*i+1] = ptsIds->GetId(1);
                _glob_connec[_nVert*i+2] = ptsIds->GetId(2);

            }

            _glob_eflags.resize(_nElem*_nEFlags,0);
            _vtkoutput = vtkoutput;
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nVert, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts,  1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());


    }

    void UnstructVtkMeshGenerator::genSphere(std::function<double(double[3])> h, std::function<std::array<double,3>(double[3])> def)
    {

        _performOrderChecks();

        _nDim = 3;
        _pDim = 2;

        _nVert = 3;
        _nCreases = 2;

        if ( myRank() == 0 )
        {
            vtkSmartPointer<vtkSphereSource> sphereSource = vtkSmartPointer<vtkSphereSource>::New();
            sphereSource->SetCenter(0.0,0.0,0.0);
            sphereSource->SetRadius(1.0);
            sphereSource->SetThetaResolution(100);
            sphereSource->SetPhiResolution(100);
            sphereSource->Update();

            vtkSmartPointer<vtkPolyData> vtkoutput = sphereSource->GetOutput();
            int nPts = vtkoutput->GetNumberOfPoints();
            vtkSmartPointer<vtkDoubleArray> h_VTK = vtkDoubleArray::New();
            h_VTK->SetNumberOfComponents(1);
            for( int i = 0; i < nPts; i++ )
            {
                array<double,3> x{};
                vtkoutput->GetPoint(i, x.data());

                if ( def != nullptr)
                {
                    x = def(x.data());
                    vtkoutput->GetPoints()->SetPoint(i, x.data());
                }

                h_VTK->InsertNextValue(h(x.data()));
            }
            h_VTK->SetName("AreaArray");
            vtkoutput->GetPointData()->SetScalars(h_VTK);

            vtkSmartPointer<vtkSurfaceRemeshing> vtkRemeshing = vtkSurfaceRemeshing::New();

            vtkRemeshing->SetInputData( vtkoutput );
            vtkRemeshing->SetElementSizeModeToTargetAreaArray();
            vtkRemeshing->SetTargetAreaArrayName("AreaArray");
            vtkRemeshing->SetNumberOfIterations(5);
            vtkRemeshing->SetAspectRatioThreshold(1.1);
            vtkRemeshing->SetCollapseAngleThreshold(0.1);
            vtkRemeshing->SetTriangleSplitFactor(10.0);
            vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(500);
            vtkRemeshing->Update();


            vtkSmartPointer<vtkCleanPolyData> vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData( vtkRemeshing->GetOutput() );
            vtkClean->Update();

            vtkoutput = vtkClean->GetOutput();

            _nPts  = vtkoutput->GetNumberOfPoints();
            _nElem = vtkoutput->GetNumberOfCells();

            _glob_x_nodes.resize(_nPts*_nDim,0.0);
            for( int i = 0; i < _nPts; i++ )
            {
                double x[3];
                vtkoutput->GetPoint(i, x);
                _glob_x_nodes[_nDim*i+0] = x[0];
                _glob_x_nodes[_nDim*i+1] = x[1];
                _glob_x_nodes[_nDim*i+2] = x[2];
            }

            _glob_connec.resize(_nElem*_nVert,0);
            for( int i = 0; i < _nElem; i++ )
            {
                vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                _glob_connec[_nVert*i+0] = ptsIds->GetId(0);
                _glob_connec[_nVert*i+1] = ptsIds->GetId(1);
                _glob_connec[_nVert*i+2] = ptsIds->GetId(2);

            }

            _glob_creases.resize(_nPts*_nCreases,0);
            _glob_eflags.resize(_nElem*_nEFlags,0);

            _vtkoutput = vtkoutput;

        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nVert, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts,  1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());

    }

    void UnstructVtkMeshGenerator::genPolygon(std::function<double(double[3])> h,std::function<std::array<double,3>(double[3])> def)
    {

        _performOrderChecks();

        _nDim = 3;
        _pDim = 2;

        _nVert = 3;
        _nCreases = 2;

        if ( myRank() == 0 )
        {
            // Create a circle
            vtkSmartPointer<vtkDiskSource> diskSource = vtkSmartPointer<vtkDiskSource>::New();
            diskSource->SetInnerRadius(0.0);
            diskSource->SetOuterRadius(1);
            diskSource->SetRadialResolution(50);
            diskSource->SetCircumferentialResolution(50);
            diskSource->Update();


            vtkSmartPointer<vtkPolyData> vtkoutput = diskSource->GetOutput();


            vtkSmartPointer<vtkCleanPolyData> vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData( vtkoutput );
            vtkClean->SetPointMerging(true);
            vtkClean->SetConvertPolysToLines(false);
            vtkClean->SetConvertLinesToPoints(false);
            vtkClean->SetTolerance(1.E-8);
            vtkClean->Update();

            vtkSmartPointer<vtkTriangleFilter> triangFilter = vtkSmartPointer<vtkTriangleFilter>::New();
            triangFilter->SetInputData(vtkClean->GetOutput());
            triangFilter->Update();


            vtkoutput = triangFilter->GetOutput();
            int nPts = vtkoutput->GetNumberOfPoints();

            vtkSmartPointer<vtkDoubleArray> h_VTK = vtkDoubleArray::New();
            h_VTK->SetNumberOfComponents(1);
            for( int i = 0; i < nPts; i++ )
            {
                array<double,3> x;
                vtkoutput->GetPoint(i, x.data());

                if ( def != nullptr)
                {
                    x = def(x.data());

                    vtkoutput->GetPoints()->SetPoint(i, x.data());
                }

                h_VTK->InsertNextValue(h(x.data()));
            }
            h_VTK->SetName("AreaArray");
            vtkoutput->GetPointData()->SetScalars(h_VTK);

            vtkSmartPointer<vtkSurfaceRemeshing> vtkRemeshing = vtkSurfaceRemeshing::New();

            vtkRemeshing->SetInputData( vtkoutput );
            vtkRemeshing->SetElementSizeModeToTargetAreaArray();
            vtkRemeshing->SetTargetAreaArrayName("AreaArray");
            vtkRemeshing->SetNumberOfIterations(5);
            vtkRemeshing->SetAspectRatioThreshold(1.1);
            vtkRemeshing->SetCollapseAngleThreshold(1.0);
            vtkRemeshing->SetTriangleSplitFactor(10.0);
            vtkRemeshing->SetNumberOfConnectivityOptimizationIterations(500);
            vtkRemeshing->Update();


            vtkClean = vtkCleanPolyData::New();
            vtkClean->SetInputData( vtkRemeshing->GetOutput() );
            vtkClean->Update();

            vtkoutput = vtkClean->GetOutput();

            _nPts  = vtkoutput->GetNumberOfPoints();
            _nElem = vtkoutput->GetNumberOfCells();

            _glob_x_nodes.resize(_nPts*_nDim,0.0);
            for( int i = 0; i < _nPts; i++ )
            {
                double x[3];
                vtkoutput->GetPoint(i, x);
                _glob_x_nodes[_nDim*i+0] = x[0];
                _glob_x_nodes[_nDim*i+1] = x[1];
                _glob_x_nodes[_nDim*i+2] = x[2];
            }

            _glob_connec.resize(_nElem*_nVert,0);
            for( int i = 0; i < _nElem; i++ )
            {
                vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                _glob_connec[_nVert*i+0] = ptsIds->GetId(0);
                _glob_connec[_nVert*i+1] = ptsIds->GetId(1);
                _glob_connec[_nVert*i+2] = ptsIds->GetId(2);

            }


            _glob_creases.resize(_nCreases*_nPts);

            vtkSmartPointer<vtkDataSetSurfaceFilter> surfaceFilter = vtkDataSetSurfaceFilter::New();
            surfaceFilter->SetInputData(vtkoutput);
            surfaceFilter->Update();

            vtkSmartPointer<vtkFeatureEdges> pEdges = vtkFeatureEdges::New();
            pEdges->SetInputData( surfaceFilter->GetOutput() );
            pEdges->BoundaryEdgesOn();
            pEdges->FeatureEdgesOff();
            pEdges->NonManifoldEdgesOff();
            pEdges->ManifoldEdgesOff();
            pEdges->Update();

            vtkSmartPointer<vtkPolyData> poly = pEdges->GetOutput();
            for ( int k=0; k<poly->GetNumberOfPoints(); k++ )
            {
                double x[3];
                poly->GetPoint( k, x );
                vtkIdType ptId = vtkoutput->FindPoint( x );

                _glob_creases[_nCreases*ptId+0] = 1;
            }


            _glob_eflags.resize(_nElem*_nEFlags,0);

            _vtkoutput = vtkoutput;
        }
        else
        {
            _glob_x_nodes.resize(_nDim, 0);
            _glob_connec.resize(_nVert, 0);
            _glob_creases.resize(_nCreases, 0);
            _glob_eflags.resize(_nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm());
        MPI_Bcast(&_nPts,  1, MPI_INT, 0, comm());
        MPI_Bcast(&_nElem, 1, MPI_INT, 0, comm());

    }

    //Check, save and reload mesh
    void UnstructVtkMeshGenerator::_saveMesh()
    {

        _tmp_glob_connec  = _glob_connec;
        _tmp_glob_x_nodes = _glob_x_nodes;
        _tmp_glob_creases = _glob_creases;
        _tmp_glob_eflags  = _glob_eflags;

        _tmp_nElem = _nElem;
        _tmp_nPts = _nPts;

        _tmp_vtkoutput = _vtkoutput;
    }

    void UnstructVtkMeshGenerator::_reloadMesh()
    {

        _glob_connec = _tmp_glob_connec ;
        _glob_x_nodes = _tmp_glob_x_nodes;
        _glob_creases = _tmp_glob_creases;
        _glob_eflags = _tmp_glob_eflags;

        _nElem = _tmp_nElem;
        _nPts = _tmp_nPts;

        _vtkoutput = _tmp_vtkoutput;
    }


    //p-Refined mesh
    void UnstructVtkMeshGenerator::_getPRefinedMesh(int orderInc)
    {
        (void) orderInc;
    }

    void UnstructVtkMeshGenerator::_getPRefinedMesh(int orderIncX, int orderIncY, int orderIncZ)
    {
        (void) orderIncX;
        (void) orderIncY;
        (void) orderIncZ;
    }

    //h-Refined mesh
    void UnstructVtkMeshGenerator::_computeHRefinedMesh(int refLevel, int& nPts, int& nElem, int& nDim, int& nVert, int& nCreases,
                              int& nEFlags, std::vector<double>& glob_x_nodes, std::vector<int>& glob_connec,
                              std::vector<int>& glob_creases, std::vector<int>& glob_eflags,
                              vtkSmartPointer<vtkPolyData>& vtkoutput, MPI_Comm comm, int rank)
    {
        if (rank == 0)
        {
            vtkSmartPointer<vtkLinearSubdivisionFilter>  subdivisionFilter = vtkSmartPointer<vtkLinearSubdivisionFilter>::New();
            subdivisionFilter->SetInputData(vtkoutput);
            subdivisionFilter->SetNumberOfSubdivisions(refLevel);
            subdivisionFilter->Update();

            vtkoutput = subdivisionFilter->GetOutput();

            nPts  = static_cast<int>(vtkoutput->GetNumberOfPoints());
            nElem = static_cast<int>(vtkoutput->GetNumberOfCells());

            glob_x_nodes.resize(nPts*nDim,0.0);
            for (int i = 0; i < nPts; i++)
            {
                double x[3];
                vtkoutput->GetPoint(i, x);

                glob_x_nodes[nDim*i+0] = x[0];
                glob_x_nodes[nDim*i+1] = x[1];
                glob_x_nodes[nDim*i+2] = x[2];
            }

            glob_connec.resize(nElem*nVert,0);
            for (int i = 0; i < nElem; i++)
            {
                vtkSmartPointer<vtkIdList> ptsIds = vtkIdList::New();
                vtkoutput->GetCellPoints(i, ptsIds);
                glob_connec[nVert*i+0] = static_cast<int>(ptsIds->GetId(0));
                glob_connec[nVert*i+1] = static_cast<int>(ptsIds->GetId(1));
                glob_connec[nVert*i+2] = static_cast<int>(ptsIds->GetId(2));
            }

            glob_creases.resize(nPts*nCreases,0);

            vtkSmartPointer<vtkFeatureEdges> edges = vtkSmartPointer<vtkFeatureEdges>::New();
            edges->SetInputData(vtkoutput);
            edges->BoundaryEdgesOn();
            edges->FeatureEdgesOff();
            edges->NonManifoldEdgesOff();
            edges->ManifoldEdgesOff();
            edges->Update();

            auto polydata_b = edges->GetOutput();

            vtkSmartPointer<vtkPointLocator> loc = vtkSmartPointer<vtkPointLocator>::New();
            loc->SetDataSet(vtkoutput);
            loc->BuildLocator();

            for (int i = 0; i < polydata_b->GetPoints()->GetNumberOfPoints(); i++)
            {
                std::array<double, 3> x{};
                polydata_b->GetPoints()->GetPoint(i, x.data());
                int j = static_cast<int>(loc->FindClosestPoint(x.data()));

                glob_creases[nCreases*j] = 1;
            }

            glob_eflags.resize(nElem*nEFlags,0);
        }
        else
        {
            glob_x_nodes.resize(nDim, 0);
            glob_connec.resize(nVert, 0);
            glob_creases.resize(nCreases, 0);
            glob_eflags.resize(nEFlags, 0);
        }

        //Communicate number of points and elements
        MPI_Barrier(comm);
        MPI_Bcast(&nPts,  1, MPI_INT, 0, comm);
        MPI_Bcast(&nElem, 1, MPI_INT, 0, comm);
    }

    void UnstructVtkMeshGenerator::_getHRefinedMesh(int refLevel)
    {
        _computeHRefinedMesh(refLevel, _nPts, _nElem, _nDim, _nVert, _nCreases, _nEFlags,
                             _glob_x_nodes, _glob_connec, _glob_creases, _glob_eflags, _vtkoutput,
                             _comm, myRank());
    }


    //Boundary mesh
    void UnstructVtkMeshGenerator::_getBoundaryMesh(vector<MAxis> vMAx)
    {
        (void) vMAx;
    }

}
