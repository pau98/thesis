/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HIPERPROBLEM_H
#define HIPERPROBLEM_H


#include <string>

#include <Teuchos_RCP.hpp>
#include <Teuchos_ParameterList.hpp>
#include <Epetra_LinearProblem.h>
#include <hl_Integration.h>

#include "hl_FillType.h"
#include "hl_DOFsHandler.h"
#include "hl_DistributedClass.h"
#include "hl_FieldStruct.h"
#include "hl_CubatureSet.h"
#include "hl_BasisFunctionsSet.h"
#include "hl_FillStructure.h"
#include "hl_ParamStructure.h"
#include "hl_WeightedAdjcyStruct.h"
#include "hl_HiperIndexConverter.h"

namespace hiperlife
{


    /*!
     * \class HiPerProblem
     * \brief Class that contains all the basic material for solving problems
     * using Finite Elements.
     *
     * It contains a DistributedMesh object that deals with the structures
     * needed for generate a mesh in distributed memory. Also, it contains
     * structure for the DoFs, constraints and the Linear Algebra objects to
     * actually solve the problem.
     *
     * The information needed for creating the object needs given via the
     * class setters and then Update function will generate the object.
     * Afterwords, the constraints and the ghost structures and LA
     * object needs to be created before actually using it.
     *
    */

    class HiPerProblem : public DistributedSrcData
    {
        public:
            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            HiPerProblem(std::string tag ="HiPerProblem", MPI_Comm comm = MPI_COMM_WORLD) : DistributedSrcData(tag, comm) {}
            HiPerProblem(HiPerProblem&& other) = default;
            HiPerProblem(const HiPerProblem& other) = delete;
            ~HiPerProblem() = default;



            /** @name Object Creation Management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a HiPerProblem object and,
             * in fact, several can be incompatible between each other.
            *  @{
            */
            /*! \brief Sets all the DOFsHandlers of our HiPerProblem. */
            void setDOFsHandlers(std::vector<Teuchos::RCP<DOFsHandler>> dhands);

            std::vector<std::string> _getDofTags() {return _dofTags;};

            int setIntegration(std::string nameInteg, std::vector<std::string>, std::vector<Teuchos::RCP<MeshMap>> mappings);

            int setIntegration(std::string nameInteg, std::vector<std::string>);

            void setCubatureGauss(std::string nameInteg, int iPts, std::set<size_t> elems={}, IndexType idxType=IndexType::Global);

            void _setCubatureBorderGauss_MAxis(std::string nameInteg, int iPts,  std::set<MAxis> axes);

            void _setCubatureBorderGauss_Elems(std::string nameInteg, int iPts,  std::set<size_t> elems, IndexType idxType=IndexType::Global);

            //FIXME: add support for _setCubatureBorderGauss_Elems (integration in specific elements at the border)
            inline void setCubatureBorderGauss(std::string nameInteg, int iPts, std::set<MAxis> any={})
            {
                _setCubatureBorderGauss_MAxis(nameInteg, iPts, any);
            }

            void setCubatureIrregSubdivSurf(std::string nameInteg, int iPts, int nSubdiv, std::set<size_t> elems = {}, IndexType idxType=IndexType::Global);

            void setCubatureCutCellNonConforming(std::string nameInteg, int iPtsInterior, int iPtsBoundary, int nSubdiv,
                                                 std::set<size_t> interiorElems = {}, std::set<size_t> cutElems = {},
                                                 IndexType idxType=IndexType::Global);
            
            void setCubatureCutCellConforming(std::string nameInteg, int iPtsInterior, int intOrderBoundary, std::string regionTag = {},
                                                 std::set<size_t> interiorElems = {}, std::set<size_t> cutElems = {},
                                                 IndexType idxType=IndexType::Global);

            void setCubatureBorderImmersed(std::string nameInteg, int iPts, std::set<size_t> cutElems={}, IndexType idxType=IndexType::Global);

            void setCubatureUserDefined(std::string nameInteg, std::vector<std::vector<double>> rCoords, std::vector<double> weights, std::set<size_t> elems = {}, IndexType idxType=IndexType::Global);

            void setCubatureBorderIntersection(std::string nameInteg, int iPts, std::set<BorderIntersections>);

            /*! \brief Sets up ghost-penalty patch integration for a named integration object.
             *
             *  Each element of \p elemPairs must be a pair of global element IDs that share an
             *  interior facet.  For each pair (K+, K-) the library integrates over the full
             *  volume of each element and evaluates the neighbour element's basis functions at
             *  those interior points by polynomial extension (Newton inverse map).
             *
             *  The named integration must have been registered with the same DOFsHandler tag
             *  listed twice (e.g. {"dofHand","dofHand"}) so that fillStr[0] is the host element
             *  and fillStr[1] the guest (extended) element at every Gauss point.
             *
             *  \param nameInteg  Tag of the integration object.
             *  \param iPts       Number of Gauss points per direction for the volume rule.
             *  \param elemPairs  Vector of (globalK+, globalK-) pairs sharing an interior facet.
             *  \param idxType    Whether element IDs are global (default) or local.
             */
            void setCubatureGhostPenalty(std::string nameInteg, int iPts,
                                         std::vector<std::pair<int,int>> elemPairs,
                                         IndexType idxType = IndexType::Global);

            /*! \brief Sets up interior-facet integration for a named integration object.
             *
             *  Each element of \p elemPairs must be a pair of global element IDs that share an
             *  interior edge. The library automatically detects which side each element contributes.
             *  The named integration must have been registered with the same DOFsHandler tag listed
             *  twice (e.g. {"dofHand", "dofHand"}) so that fillStr[0] gives elem+ data and
             *  fillStr[1] gives elem- data in the user filling function.
             *
             *  \param nameInteg  Tag of the integration object.
             *  \param iPts       Number of Gauss points along each shared edge.
             *  \param elemPairs  Vector of (globalElem1, globalElem2) pairs sharing an interior edge.
             *  \param idxType    Whether element IDs are global (default) or local.
             */
            void setCubatureInteriorFacet(std::string nameInteg, int iPts,
                                          std::vector<std::pair<int,int>> elemPairs,
                                          IndexType idxType = IndexType::Global);

            void setElementFillings(std::string nameInteg,
                                 void (*elemMatRHS)(FillStructure&) = nullptr,
                                 void (*elemMat)(FillStructure&)    = nullptr,
                                 void (*elemRHS)(FillStructure&)    = nullptr);

            typedef void (*elemMatRHS)(FillStructure&);
            void setElementFillings(std::string nameInteg,  elemMatRHS elemPredefined(Teuchos::RCP<ParamStructure>))
            {
                setElementFillings(nameInteg, elemPredefined(_userStr));
            };

            void setParameterStructure(Teuchos::RCP<ParamStructure> userStr) {_userStr = userStr;}
            void setGlobalIntegrals(std::vector<std::string> globInteg, bool savePerElems = false);

            // Set consistency DOFsHandler and DOFs
            void setConsistencyDOFs(int dhand, std::vector<int> dofs)
            {
                _consDOFsHandlers.push_back(dhand);
                _consDOFs.push_back(dofs);
            }
            void setConsistencyDOFs(std::string dhandTag, std::vector<std::string> dofsTags)
            {
                _consDOFsHandlersTags.push_back(dhandTag);
                _consDOFsTags.push_back(dofsTags);
            }
            void setConsistencyCheckType(ConsistencyCheckType consCheckType, std::string consCheckGlobIntegTag = "") {_consCheckType = consCheckType; _consCheckGlobIntegTag = consCheckGlobIntegTag;}
            void setConsistencyCheckTolerance(double consCheckTol) {_consCheckTol = consCheckTol;}
            void setConsistencyCheckDelta(double consCheckDelta) {_consCheckDelta = consCheckDelta;}

            /*! \brief Method that sets a linear constraint of the form:
             *     x1 = a2/a1*x2 + a3/a1*x3 +  ...  + an/a1*xn + b/a1
             * Note: A master node cannot be an slave of another linear constraint
             * /param slave CompHiPerIndex of slave node x1 in the above equation
             * /param masters vector of CompHiPerIndex of master nodes ({x2, x3, ..., xn} in the above equation)
             * /param weights vector of weights ({a2/a1, a3/a1, ..., an/a1} in the above equation)
             * /param value b/a1 in the above equation
             */
            void setLinearConstraint(CompHiPerIndex slave, CompHiPerIndex master, double weight = 1.0, double value = 0.0);
            void setLinearConstraint(CompHiPerIndex slave, std::vector<CompHiPerIndex> masters, std::vector<double> weights, double value = 0.0);

            bool isDOFLinearlyConstraint(int idx, IndexType idxType = IndexType::Global)
            {
                 return _LCWgraph->getNumNbors(idx,idxType) != 0;
            }

            /*! \brief Method that actually creates the object. Before calling that the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of object creation


            /** @name Assembly Methods
             * In order to assembly the global matrix and RHS of our equations this can be done separately
             * or both at the same time.
             * Notice that the library does not checked which functions are active.
             * If the function for the Linear System by Element is introduced, then the others will be
             * ignored.
             * The individual Filling methods only works if the individual functions are set.
             *
            *  @{
            */

            /*! \brief Method that enforces Boundary Conditions.*/
            template<FillType F> void enforceDirichletBC_and_LinearC(bool fillRhs, bool fillA);
            /*! \brief Method that fills the global Linear System.*/
            void FillLinearSystem();
            /*! \brief Method that fills the global Stiffness Matrix.*/
            void FillStiffMatrix();
            /*! \brief Method that fills the global Right Hand Side.*/
            void FillRHS();
            /** @} */ // end of filling structures
            /*! \brief Update the ghost information of all the nodes.
             * If we introduce a number, we only update that \ref DOFsHandler
             * \param idxDHand \ref DOFsHandler to updateGhosts
             * */
            void UpdateGhosts(bool genImporters=false,int idxDHand = -1);

            /*! \brief Update nodeDOFs with the information
             * of the solution of the Linear System for all DOFsHandlers
             * */
            void UpdateSolution();

            /*! \brief Method that adds the solution of the Linear System to the degrees of freedom
             * */
            void AddSolutionToDOFs(double a=1.0);

            /*! \brief Get an individual value of the solution vector. It includes possible ghost points.
             * */
            double solValue(int hpIdx, IndexType idxtype=IndexType::Global);

            /*! \brief Returns the userStr of the HiPerProblem.
             * */
            Teuchos::RCP<ParamStructure> userStructure() {return _userStr;}
            [[deprecated("This function is deprecated and will be removed in the next release. Please use userStr() instead.")]]
            Teuchos::RCP<ParamStructure> userStr() {return _userStr;}

            /*! \brief Returns the global integral of index idx. */
            inline double globalIntegral(int idx){return _globInteg[idx];}
            [[deprecated("This function is deprecated and will be removed in the next release. Please use globalIntegral(same arguments) instead.")]]
            inline double globIntegral(int idx){return _globInteg[idx];}
            /*! \brief Returns the global integral of tag ident. */
            inline double globalIntegral(std::string ident){ return _globInteg[_globIntegTagIdx[ident]];};
            [[deprecated("This function is deprecated and will be removed in the next release. Please use globalIntegral(same arguments) instead.")]]
            inline double globIntegral(std::string ident){ return _globInteg[_globIntegTagIdx[ident]];};
            /*! \brief Returns a vector with the values of all global integrals.*/
            inline std::vector<double> globalIntegrals(){ return std::vector<double>(_globInteg);}
            [[deprecated("This function is deprecated and will be removed in the next release. Please use globalIntegrals() instead.")]]
            inline std::vector<double> globIntegrals(){ return std::vector<double>(_globInteg);}
            /*! \brief Returns a vector with the names of all global integrals. */
            inline std::vector<string> globalIntegralNames()
            {
                std::vector<string> names;

                for (int i = 0; i < static_cast<int>(_globInteg.size()); i++)
                {
                    for (auto it = _globIntegTagIdx.begin(); it != _globIntegTagIdx.end(); ++it)
                    {
                        if (it->second == i)
                            names.push_back(it->first);

                    }
                }

                return names;
            }
            [[deprecated("This function is deprecated and will be removed in the next release. Please use globIntegralNames() instead.")]]
            inline std::vector<string> globIntegralNames(){return globalIntegralNames();};
            /*! Returns the id of a global integral tag. */
            inline int globalIntegralId (std::string tag){return _globIntegTagIdx.at(tag);};
            /*! \brief Returns the the complex Hiper index from a given hiper index. */
            inline CompHiPerIndex complexHiPerIndex(int hpIdx){return hiperIndexConverter->getCompHiPerIndex(hpIdx);}
            [[deprecated("This function is deprecated and will be removed in the next release. Please use getComplexHiPerIndex() instead.")]]
            inline CompHiPerIndex getCompHiPerIndex(int hpIdx){return hiperIndexConverter->getCompHiPerIndex(hpIdx);}

            /** @name Expert Users and Developers Only
            *  @{ */
            std::vector<Teuchos::RCP<DOFsHandler>> _dhands;
            std::vector<Teuchos::RCP<Integration>> _integ;

            // Linear Algebra data structures
            std::vector<double> _globInteg;
            Teuchos::RCP<Epetra_FECrsMatrix> A  = Teuchos::null;
            Teuchos::RCP<Epetra_FEVector> rhs   = Teuchos::null;
            Teuchos::RCP<Epetra_FEVector> sol   = Teuchos::null;
            Teuchos::RCP<Epetra_LinearProblem> linProbl = Teuchos::null;

            Teuchos::RCP<Epetra_FEVector> _ghostsData   = Teuchos::null;

            std::map<std::string, int> _dhandsTagIdx;
            std::map<std::string, int> _integTagIdx;
            std::map<std::string, int> _globIntegTagIdx;
            std::vector<int> _globIntegToElemAux;


            std::vector<int> _consDOFsHandlers;
            std::vector<std::vector<int>> _consDOFs;
            std::vector<std::string> _consDOFsHandlersTags;
            std::vector<std::vector<std::string>> _consDOFsTags;
            ConsistencyCheckType _consCheckType = ConsistencyCheckType::Undefined;
            std::string _consCheckGlobIntegTag = "";
            int _consCheckGlobInteg{-1};
            double _consCheckTol{1.E-4};
            double _consCheckDelta{1.E-4};
            /** @} */ // Expert Users and Developers Only


        private:
            Teuchos::RCP<ParamStructure> _userStr = Teuchos::null;
            std::vector<std::tuple<int, std::vector<int>, std::vector<double>>> _temp_LC_data;  // First is the local node where to put the LC, the second is the nbors and the third is the weights
            Teuchos::RCP<WeightedAdjcyStruct> _LCWgraph = Teuchos::null;
            std::vector<double> _LCvalues;

            void _computeDOFsMaps();
            std::vector<int> _computeAdjcyLCGhosts();
            void _createGhostStructure();
            int _allocGhosts() override;
            int _updateGhosts();
            void _updateMeshGhosts();
            void _updateConsistencyCheck();

            /* The following function sets linear constraints coming from the mesh*/
            void _setMeshLinearConstraints();


            // Tag that controls if the Global integrals are saved for each element.
            bool _savePerElems{false};
            void _prepareElemenGlobInteg();

            Teuchos::RCP<HiperIndexConverter> hiperIndexConverter;

            void _createLinearConstraints();

            void _setCubatureCutCellElementTags(cubaParams &cparams,
                                                std::set<size_t> interiorElems = {},
                                                std::set<size_t> cutElements = {},
                                                std::string regionTag = {});

            void _removeEmptyCutElements(std::set<size_t>& cutElems, const cubaParams& cparams);

            void _setExtendedBFConstraints();

            void _freezeOutDOFsInIBM();

            // Immersed
            std::vector<std::string> _dofTags{};
    };
}



#include "hl_HiPerProblem-impl.h"



#endif //HIPERPROBLEM_H
