/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


//
// Created by santos on 2/27/18.
//

#ifndef _HIPERPROBLEM_IMPL_H
#define _HIPERPROBLEM_IMPL_H

#include "hl_FillType.h"
#include "hl_FillType-impl.h"
#include "hl_HiPerProblem.h"

namespace hiperlife
{


    template <FillType F> void HiPerProblem::enforceDirichletBC_and_LinearC(bool fillRhs, bool fillA)
    {

        int one = 1;
//        double dOne = 1.0;
        double dZero = 0.0;

        for (const auto& dhand : _dhands)
        {
            for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
            {
                int ii = i + dhand->mesh->offs_nPts();

                for (int dI = 0; dI < dhand->numDOFs(); dI++)
                {
//                    int  iD = i * dhand->numDOFs() + dI;
                    int hiD = dhand->hiperIdx(dI, ii, IndexType::Global);

                    bool constrM = dhand->constrFlag(dI, ii, IndexType::Global);

                    if (constrM)
                    {

                        if (fillRhs)
                        {
                            double valConstr = dhand->constrValue(dI, ii, IndexType::Global);
                            rhs->SumIntoGlobalValues(1, &hiD, &one, &valConstr);
                        }

                        if (fillA)
                        {
                            matrixFill<F>(A, hiD, hiD, 1.0);
                        }
                    }

                    bool lcR = _LCWgraph->getNumNbors(hiD, IndexType::Global) > 0;

//                    if (_LCWgraph->isItemInfoInPart(hiD))
//                    lcR = ;

                    if (lcR)
                    {

                        if (fillRhs)
                        {
                            rhs->SumIntoGlobalValues(1, &hiD, &one, &dZero);
                        }

                        if (fillA)
                        {
                            matrixFill<F>(A, hiD, hiD, 1.0);
                        }
                    }




                }

            }

        }

    }
}


#endif //_HIPERPROBLEM_IMPL_H
