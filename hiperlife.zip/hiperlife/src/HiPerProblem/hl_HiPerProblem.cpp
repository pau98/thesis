/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <iostream>
#include <iomanip>
#include <string>
#include <functional>
#include <unistd.h>

#include "hl_Integration.h"
#include "hl_CubatureInfo.h"
#include "hl_BasisFunctionsSet.h"
#include "hl_Cubature.h"
#include "hl_CubatureGauss.h"
#include "hl_DistributedMesh.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"
#include "hl_MeshMap_Trivial.h"
#include "hl_HiperIndexConverter.h"


#ifdef EXTRAE_PROFILING
#include "extrae_user_events.h"
#endif

using namespace std;
using Teuchos::null;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{

    void HiPerProblem::setDOFsHandlers(std::vector<Teuchos::RCP<DOFsHandler>> dhands)
    {
        _dhands = dhands;

        UpdateGhosts();

        if (_dhands.size() == 0)
            throw runtime_error("HiPerProblem::Update: No DOFsHandler has been introduced.");

        // Generating dictionary tag <-> index for DOFsHandler vector
        for (auto i = 0u; i < _dhands.size(); i++)
            _dhandsTagIdx.emplace(_dhands[i]->nameTag(), i);

        _computeDOFsMaps();

        //The previous step calculates the maps and the local number of local items, so here I resize the vector containing the values of each linear constraint
        _LCvalues.resize(_loc_nItem);

        // Import Immersed region tags for immersed
        for(auto dhand:dhands)
        {
            std::vector<std::string> dofTags = dhand->_getDofTags();
            if (!dofTags.empty())
                _dofTags = dofTags;
        }

    }

    void HiPerProblem::Update()
    {
        // // create a function for freezing out DOFs
        // //  run a test with BFM and check if it works
        // if (_dhands[0]->mesh->_childMesh != nullptr)
        // {
        //     if (_dhands[0]->mesh->_childMesh->_meshRel == MeshRelation::Immersed)
        //     {
        //         _freezeOutDOFsInIBM();
        //     }
        // }

        _setExtendedBFConstraints();
        
        if(_dhands[0]->mesh->_regionTags().size() == 0)
            _setMeshLinearConstraints();

        _createLinearConstraints();

        _createGhostStructure();


        hiperIndexConverter = rcp(new HiperIndexConverter);
        hiperIndexConverter->setNumberOfProcs(_numProcs);
        hiperIndexConverter->setNumberOfDOFsHandlers(_dhands.size());
        for (auto i = 0u; i < _dhands.size(); i++ )
        {
            hiperIndexConverter->setNDOFDOFsHandler(i,_dhands[i]->numDOFs());
            // hiperIndexConverter->setDHandTag(i,_dhands[i]->nameTag());
            for ( int p = 0; p < _numProcs; p++ )
                hiperIndexConverter->setLocNItemDOFsHandler(p,i,_dhands[i]->mesh->_graph->proc_nItem(p));
        }
        hiperIndexConverter->Update();

        _updateMeshGhosts();
        UpdateGhosts(true);

        // FIXME Be careful if you have several integrations
        _prepareElemenGlobInteg();

        // Update consistency check options
        _updateConsistencyCheck();

        // Save integration info
        for (auto &i : _integ)
        {
            i->setParamStruct(_userStr);
            i->_LCWgraph = _LCWgraph;
            i->_LCvalues = _LCvalues;
            i->hiperIndexConverter = hiperIndexConverter;
            i->_dhandsFullList = Teuchos::rcpFromRef(_dhands);
            i->_consDOFsHandlers   = _consDOFsHandlers;
            i->_consDOFs           = _consDOFs;
            i->_consCheckType      = _consCheckType;
            i->_consCheckGlobInteg = _consCheckGlobInteg;
            i->_consCheckTol       = _consCheckTol;
            i->_consCheckDelta     = _consCheckDelta;
            i->Update();
            i->_fillStr->_globIntegTagIdx    = _globIntegTagIdx;
            i->_fillStr->_savePerElems       = _savePerElems;
            i->_fillStr->_globIntegToElemAux = _globIntegToElemAux;
            i->_fillLinearSystem<FillType::TrilCreat>(A, null);
        }
        enforceDirichletBC_and_LinearC<FillType::TrilCreat>(false, true);

        A->GlobalAssemble();
    }

    void HiPerProblem::_updateConsistencyCheck()
    {
        // deprecated
        if (_consCheckType == ConsistencyCheckType::Undefined)
        {
            _consCheckType = ConsistencyCheckType::Hessian;
            // cout << "HiPerProblem::Update: The ConsistencyCheck now allows to choose between doing a check in the jacobian, in the hessian or in both. \n   You can select which one to use with the function setConsistencyCheckType(ConsistencyCheckType::Both). \n   In order to be consistent with previous versions, the default value will be ConsistencyCheckType::Hessian until the next release." << endl;
        }

        // Check which consistency check global integral to use
        if (_consCheckType == ConsistencyCheckType::Jacobian or _consCheckType == ConsistencyCheckType::Both)
        {
            // Check that it was set
            if (_consCheckGlobIntegTag == "")
                throw runtime_error("HiPerProblem::Update: The global integral for the consistency check was not set.");

            // Check whether it exists
            if (_globIntegTagIdx.count(_consCheckGlobIntegTag) == 0)
                throw runtime_error("HiPerProblem::Update: The global integral for the consistency check does not exist in the hiperproblem.");

            // Save the id of the global integral
            _consCheckGlobInteg = _globIntegTagIdx.at(_consCheckGlobIntegTag);
        }

        // Transform DOFsHandlers and DOFs tags to index for the consistency check
        for (auto dhTag: _consDOFsHandlersTags)
        {
            // Save dhand
            int dhIdx = _dhandsTagIdx[dhTag];
            _consDOFsHandlers.push_back(dhIdx);

            // Save DOFs
            if (dhIdx >= static_cast<int>(_consDOFs.size()))
                _consDOFs.resize(_consDOFs.size()+1);
            for (auto dofsTag: _consDOFsTags[dhIdx])
                _consDOFs[dhIdx].push_back(_dhands[dhIdx]->nodeDOFs->index(dofsTag));
        }

        // Default option: Add all DOFsHandlers and DOFs  <-- FIXME:: move to setDefault function
        if (_consCheckType != ConsistencyCheckType::None)
        {
            if (_consDOFsHandlers.size() == 0)
            {
                for (size_t dhIdx = 0; dhIdx < _dhands.size(); dhIdx++)
                {
                    _consDOFsHandlers.push_back(dhIdx);
                    _consDOFs.resize(_consDOFs.size()+1);
                    for (int dofsIdx = 0; dofsIdx < _dhands[dhIdx]->nodeDOFs->numFlds(); dofsIdx++)
                        _consDOFs[dhIdx].push_back(dofsIdx);
                }
            }
        }
    }

    void HiPerProblem::_computeDOFsMaps()
    {

        int loc_rows{};

        for (auto i = 0u; i < _dhands.size(); i++)
        {
            loc_rows += _dhands[i]->numDOFs() * _dhands[i]->mesh->loc_nPts();
        }

        setLocNItem(loc_rows);
        UpdateDistData();

        offs_nItem();

        loc_rows = 0;
        for (auto i = 0u; i < _dhands.size(); i++)
        {
            _dhands[i]->computeOffsHiperProbl(loc_rows + offs_nItem());

            loc_rows += _dhands[i]->numDOFs() * _dhands[i]->mesh->loc_nPts();
        }

        // Linear System:
        Epetra_Map vec_map(-1, _loc_nItem, 0, epComm());

        A = rcp(new Epetra_FECrsMatrix(Copy, vec_map, -1));
        rhs = rcp(new Epetra_FEVector(vec_map));
        sol = rcp(new Epetra_FEVector(vec_map));

        linProbl = rcp(new Epetra_LinearProblem(&(*A), &(*sol), &(*rhs)));
    }

    std::vector<int> HiPerProblem::_computeAdjcyLCGhosts()
    {
        set<int> set_ghosts;

        for (auto& dhand: _dhands)
        {
            auto &ghosts = dhand->mesh->_adjcyNE->listGhosts();

            for (auto& g : ghosts)
            {
                for (int d = 0; d < dhand->numDOFs(); d++)
                {
                    const int hpIdxGh = dhand->hiperIdx(d, g, IndexType::Global);
                    set_ghosts.insert(hpIdxGh);
                }
            }

        }

        vector<int> ghosts(set_ghosts.size());
        std::copy(set_ghosts.begin(), set_ghosts.end(), ghosts.begin());

        return ghosts;
    }

    void HiPerProblem::_createLinearConstraints()
    {

        _LCWgraph  = rcp(new WeightedAdjcyStruct("LCWgraph", _comm));

        _LCWgraph->setLocNItem(loc_nItem());
        _LCWgraph->setNItem(nItem());
        _LCWgraph->setDistData(_temp_LC_data);
        _LCWgraph->Update();

        auto ghosts = _computeAdjcyLCGhosts();

        _LCWgraph->UpdateGhosts(ghosts);

        /// FIXME XXXX LC_GENERAL  Check that an slave is not a IntegType::Master of another LC
    }

    void HiPerProblem::_createGhostStructure()
    {
        int hpIdx = 0;
        vector<int> countPart(numProcs(), 0);
        set<int> set_ghosts;

        for(auto& dhand : _dhands)
        {
            for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
            {
                for (int dof = 0; dof < dhand->numDOFs(); dof++)
                {
                    const int nlc = _LCWgraph->getNumNbors(hpIdx, IndexType::Local);

                    for ( int nb = 0; nb < nlc; nb++ )
                    {
                        const int hiD_mast = _LCWgraph->getNbor(hpIdx, nb, IndexType::Local);
                        if (isItemInPart(hiD_mast) == false)
                            set_ghosts.insert(hiD_mast);
                    }
                    hpIdx++;
                }
            }
        }
        std::copy(set_ghosts.begin(), set_ghosts.end(), std::back_inserter(_ghosts));

        DistributedSrcData::UpdateGhosts(_ghosts);
    }

    int HiPerProblem::_allocGhosts()
    {
        _ghostsData = rcp(new Epetra_FEVector(_ghostsImporter->TargetMap(), 1));
        if (sol != null)
            _updateGhosts();

        return 0;
    }

    int HiPerProblem::_updateGhosts()
    {
        _ghostsData->Import(*sol, *_ghostsImporter, Insert);
        return 0;
    }

    double HiPerProblem::solValue(int hpIdx, IndexType idxtype)
    {
        if (idxtype == IndexType::Local)
            return (*sol)[0][hpIdx];
        else
        {
            if (isItemInPart(hpIdx))
                return (*sol)[0][locIdx(hpIdx)];
            else if (isItemInPartGhosts(hpIdx))
            {
                ptrdiff_t idx_ghosts = find(_ghosts.begin(), _ghosts.end(), hpIdx) - _ghosts.begin();
                return (*_ghostsData)[0][idx_ghosts];
            }
            else
                throw runtime_error("HiPerProblem::getSolValue: hpIdx: " + to_string(hpIdx) + " is not here!!");
        }
    }

    int HiPerProblem::setIntegration(string nameInteg, vector<string> tagsDHands, std::vector<Teuchos::RCP<MeshMap>> mappings)
    {
        //Checks
        if (tagsDHands.size() == 0)
            throw runtime_error("HiPerProblem::setIntegration: You have not set any DOFsHandler for this integration.");
        if (mappings.size() != tagsDHands.size())
            throw runtime_error("HiPerProblem::setIntegration: The number of maps introduced is not correct.");
        if (_integTagIdx.find(nameInteg) != _integTagIdx.end())
            throw runtime_error("HiPerProblem::setIntegration: The integration name is already been used.");


        // Set new integration object
        auto idxInteg = static_cast<int>(_integ.size());

        _integ.push_back(rcp(new Integration(nameInteg)));
        _integTagIdx.emplace(nameInteg, idxInteg);


        for (auto i = 0u; i < tagsDHands.size(); i++)
            _integ[idxInteg]->_dhandsTagIdx.emplace(tagsDHands[i], i);

        for (const auto &nameDHand : tagsDHands)
        {

            int dhandIdx = _dhandsTagIdx[nameDHand];
            _integ[idxInteg]->_dhands.push_back(_dhands[dhandIdx]);
        }

        _integ[idxInteg]->_meshMaps = mappings;

        return 0;
    }

    int HiPerProblem::setIntegration(string nameInteg, vector<string> tagsDHands)
    {
        //Initialize
        int dhand0      = _dhandsTagIdx[tagsDHands[0]];
        auto meshMaster = _dhands[dhand0]->mesh;
        std::vector<Teuchos::RCP<MeshMap>> mappings(tagsDHands.size());

        //Create master mapping
        mappings[0] = createMeshMap_Trivial(meshMaster->loc_nElem());

        //Get map to parent mappings
        for (size_t i = 1; i < tagsDHands.size(); i++)
        {
            //Get mesh
            int dhandIdx = _dhandsTagIdx[tagsDHands[i]];
            auto mesh = _dhands[dhandIdx]->mesh;

            //Copy mappings
            if (mesh->_mapToParent != Teuchos::null)
                mappings[i] = mesh->_mapToParent->generateInverse();
            else if (meshMaster->_mapToParent != Teuchos::null)
                mappings[i] = meshMaster->_mapToParent;
            else
               throw runtime_error("HiPerProblem::setIntegration: cannot find suitable mesh relation (mapping) between the DOFsHandler " + tagsDHands[i] +" and the master DOFsHandler "+ tagsDHands[0]);
        }

        //Set integration
        setIntegration(nameInteg, tagsDHands, mappings);

        return 0;
    }

    void HiPerProblem::setCubatureGauss(std::string nameInteg, int iPts, std::set<size_t> elems, IndexType idxType)
    {
        RCP<Integration> currInteg = null;

        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];

        size_t cubaId = currInteg->numCubas();

        cubaParams cparams;
        cparams.iPts = iPts;
        cparams.elems = elems;

        cparams.type = CubaType::Gauss;
        cparams.idxType = idxType;

        currInteg->setCubatureParameters(cubaId, cparams);
    }

    // void HiPerProblem::setCubatureBorderGauss(std::string nameInteg, int iPts)
    // {
    //     RCP<Integration> currInteg = null;

    //     int pos = _integTagIdx.at(nameInteg);
    //     currInteg = _integ[pos];

    //     size_t cubaId = currInteg->numCubas();

    //     cubaParams cparams;
    //     cparams.iPts = iPts;

    //     cparams.type = CubaType::BorderGauss;

    //     currInteg->setCubatureParameters(cubaId, cparams);
    // }

    void HiPerProblem::_setCubatureBorderGauss_MAxis(std::string nameInteg, int iPts, std::set<MAxis> axes)
    {
        RCP<Integration> currInteg = null;

        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];

        size_t cubaId = currInteg->numCubas();

        cubaParams cparams;
        cparams.iPts = iPts;
        cparams.axes = axes;

        cparams.type = CubaType::BorderGauss;
        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::_setCubatureBorderGauss_Elems(std::string nameInteg, int iPts, std::set<size_t> elems, IndexType idxType)
    {
        RCP<Integration> currInteg = null;

        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];

        size_t cubaId = currInteg->numCubas();

        cubaParams cparams;
        cparams.iPts = iPts;
        cparams.elems = elems;

        cparams.type = CubaType::BorderGauss;
        cparams.idxType = idxType;

        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setCubatureBorderIntersection(string nameInteg, int iPts, std::set<BorderIntersections> BorderIntersections)
    {
        RCP<Integration> currInteg = null;

        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];
        size_t cubaId = currInteg->numCubas();

        cubaParams cparams;
        cparams.iPts = iPts;
        cparams._BorderIntersections = BorderIntersections;
        cparams.type = CubaType::BorderIntersections;

        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setCubatureIrregSubdivSurf(std::string nameInteg, int iPts,  int nSubdiv, std::set<size_t> elems, IndexType idxType)
    {
        RCP<Integration> currInteg = null;

        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];

        size_t cubaId = currInteg->numCubas();

        cubaParams cparams;
        cparams.iPts = iPts;
        cparams.nSubdiv = nSubdiv;

        cparams.elems = elems;

        cparams.type = CubaType::IrregSubdivSurf;
        cparams.idxType = idxType;

        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::_setCubatureCutCellElementTags(cubaParams &cparams, set<size_t> interiorElems, set<size_t> cutElements, string regionTag)
    {
        std::set<size_t> intElems, cutElems;
        if (interiorElems.empty() and cutElements.empty())
        {
            //Get background mesh //FIXME::Get it from the integration
            RCP<DistributedMesh> backMesh = _dhands[0]->mesh;
            // for (auto d: _dhands)
            // {
            //     if (d->mesh->_meshRel == MeshRelation::Immersed)
            //         backMesh = d->mesh->_parentMesh;
            // }
            // Get tag position
            vector<string> userTags = backMesh->_regionTags();
            if (userTags.size() != 0)
            { 
                vector<int> tagsInternal = {3,5,7,11};
                int iTag = -1;
                for (int i{}; i < userTags.size();i++)
                {
                    if (regionTag == userTags[i])
                    {
                        iTag = i;
                    }
                }
                if (iTag == -1) 
                {
                    throw runtime_error("HiPerProblem::setCubatureCutCell: Given region tag not found.");
                }
                cparams.regionTag = tagsInternal[iTag];

                // Get flags
                for (int e = 0; e < backMesh->loc_nElem(); e++)
                {
                    if (backMesh->elemTag(1, e, IndexType::Local)%tagsInternal[iTag] == 0)
                    {
                        if (backMesh->elemTag(1, e, IndexType::Local)%2 == 0)
                            cutElems.insert(e);
                        else
                            intElems.insert(e);
                    }
                }
            }
            else
            {
                // Get flags
                for (int e = 0; e < backMesh->loc_nElem(); e++)
                {
                    if (backMesh->elemTag(1, e, IndexType::Local) == 1)
                        intElems.insert(e);
                    else if (backMesh->elemTag(1, e, IndexType::Local) == 2)
                        cutElems.insert(e);
                }
            }
        }
        else if (!interiorElems.empty() and !cutElements.empty())
        {
            //Get them from the given ones
            intElems = interiorElems;
            cutElems = cutElements;
        }
        else
        {
            throw runtime_error("HiPerProblem::setCubatureCutCell: Either both or none of interiorElems and cutElements sets need to be given.");
        }

        //Save the list of elements, interior elements and boundary elements
        std::merge(intElems.begin(), intElems.end(),
                   cutElems.begin(), cutElems.end(),
                   std::inserter(cparams.elems, cparams.elems.begin()));
        cparams.intElems = intElems;
        cparams.cutElems = cutElems;
    }

    void HiPerProblem::setCubatureCutCellNonConforming(std::string nameInteg, int iPtsInterior, int iPtsBoundary, int nSubdiv, std::set<size_t> interiorElems, std::set<size_t> cutElems, IndexType idxType)
    {
        RCP<Integration> currInteg = null;
        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];
        size_t cubaId = currInteg->numCubas();

        //Save parameters of the cubature
        cubaParams cparams;
        cparams.type = CubaType::CutCellNonConforming;
        cparams.iPts = iPtsInterior;
        cparams.iPts2 = iPtsBoundary;
        cparams.nSubdiv = nSubdiv;
        cparams.idxType = idxType;
        _setCubatureCutCellElementTags(cparams, interiorElems, cutElems);

        //Set parameters of the cubature
        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setCubatureCutCellConforming(std::string nameInteg, int iPtsInterior, int intOrderBoundary, std::string regionTag, std::set<size_t> interiorElems, std::set<size_t> cutElems, IndexType idxType)
    {
        RCP<Integration> currInteg = null;
        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];
        size_t cubaId = currInteg->numCubas();

        //Save parameters of the cubature
        cubaParams cparams;
        cparams.type = CubaType::CutCellConforming;
        cparams.iPts = iPtsInterior;
        cparams.iPts2 = intOrderBoundary;
        cparams.idxType = idxType;
        _setCubatureCutCellElementTags(cparams, interiorElems, cutElems, regionTag);

        //Set parameters of the cubature
        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setCubatureBorderImmersed(std::string nameInteg, int iPts, std::set<size_t> cutElems, IndexType idxType)
    {
        RCP<Integration> currInteg = null;
        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];
        size_t cubaId = currInteg->numCubas();

        //Save parameters of the cubature
        cubaParams cparams;
        cparams.type = CubaType::BorderImmersed;
        cparams.iPts = iPts;
        if (cutElems.empty())
        {
            //Get them from the mesh //FIXME: Get the mesh from the integration
            auto backMesh = _dhands[0]->mesh;

            for(int i{}; i < backMesh->loc_nElem(); ++i)
            {
                vector<int> backToImmMap = backMesh->_mapToChild->directMap(i, IndexType::Local);
                if(!backToImmMap.empty())
                {
                    cparams.cutElems.insert(i);
                }
            }

            //Set IndexType
            cparams.idxType = IndexType::Local;
        }
        else
        {
            //Get them from the given ones
            cparams.cutElems = cutElems;

            //Set IndexType
            cparams.idxType = idxType;
        }

        //Set parameters of the cubature
        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setCubatureUserDefined(string nameInteg, vector<vector<double>> rCoords, vector<double> weights, std::set<size_t> elems, IndexType idxType)
    {
        RCP<Integration> currInteg = null;

        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];

        size_t cubaId = currInteg->numCubas();

        cubaParams cparams; // Add info to this

        cparams.type = CubaType::UserDefined;
        cparams.elems = elems;
        cparams.idxType = idxType;
        for (size_t i = 0; i < rCoords.size(); i++)
            for (size_t j = 0; j < rCoords[i].size(); j++)
                cparams.rCoords.push_back(rCoords[i][j]);
        for (size_t i = 0; i < weights.size(); i++)
            cparams.weights.push_back(weights[i]);
        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setCubatureInteriorFacet(string nameInteg, int iPts,
                                                 vector<pair<int,int>> elemPairs,
                                                 IndexType idxType)
    {
        int pos = _integTagIdx.at(nameInteg);
        RCP<Integration> currInteg = _integ[pos];

        size_t cubaId = currInteg->numCubas();

        cubaParams cparams;
        cparams.type           = CubaType::InteriorFacet;
        cparams.iPts           = iPts;
        cparams.facetElemPairs = elemPairs;
        cparams.idxType        = idxType;

        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setCubatureGhostPenalty(string nameInteg, int iPts,
                                                vector<pair<int,int>> elemPairs,
                                                IndexType idxType)
    {
        int pos = _integTagIdx.at(nameInteg);
        RCP<Integration> currInteg = _integ[pos];

        size_t cubaId = currInteg->numCubas();

        cubaParams cparams;
        cparams.type           = CubaType::GhostPenalty;
        cparams.iPts           = iPts;
        cparams.facetElemPairs = elemPairs;
        cparams.idxType        = idxType;

        currInteg->setCubatureParameters(cubaId, cparams);
    }

    void HiPerProblem::setElementFillings(string nameInteg, void (*elemMatRHS)(FillStructure&), void (*elemMat)(FillStructure&), void (*elemRHS)(FillStructure&))
    {

        if (elemMatRHS == nullptr and elemMat == nullptr and elemRHS == nullptr)
            throw runtime_error("HiPerProblem::setElemFillings: All the introduced element filling "
                                "functions are null. What are you doing, man?");

        RCP<Integration> currInteg = null;

        int pos = _integTagIdx.at(nameInteg);
        currInteg = _integ[pos];

        currInteg->LinSystemByElement = elemMatRHS;
        currInteg->StiffnessMatrixByElement = elemMat;
        currInteg->RightHandSideByElement = elemRHS;
    }

    void HiPerProblem::setGlobalIntegrals(std::vector<std::string> globInteg, bool savePerElems)
    {
        _globInteg.resize(globInteg.size());

        for (auto i = 0u; i < globInteg.size(); i++)
            _globIntegTagIdx.emplace(globInteg[i], i);

        _savePerElems = savePerElems;
    }

    void HiPerProblem::_prepareElemenGlobInteg()
    {
        if (_savePerElems == false)
            return;

        // Only working with one integration // FIXME
        if (_integ.size() > 1)
        {
            std::clog << "HiPerProblem::_prepareElemenGlobInteg: Warning! Saving the elementary contributions of the global integrals are not prepared for the case of more than one integral. It needs to be implemented." << endl;
            _savePerElems = false;
            return;
        }

        // Check that the sizes are compatible
        if (_dhands[0]->numElemAuxF() < static_cast<int>(_globInteg.size()))
        {
            std::clog << "HiPerProblem::_prepareElemenGlobInteg: The elementary contributions of the global integrals cannot be saved in the elemental auxiliary fields of the first DOFsHandler." << std::endl;
            _savePerElems = false;
            return;
        }

        // Create map from global integrals to elems and initialize them
        for (std::map<std::string,int>::iterator it = _globIntegTagIdx.begin(); it != _globIntegTagIdx.end(); ++it)
        {
            // Compute id of element aux
            int elemAuxId = _dhands[0]->elemAuxF->index(it->first);

            // Create map and initialize
            _globIntegToElemAux.push_back(elemAuxId);
            _dhands[0]->elemAuxF->setValue(elemAuxId, 0.0);
        }
    }

    void HiPerProblem::FillLinearSystem()
    {
    #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 10);
    #endif
        rhs->PutScalar(0.0);
        A->PutScalar(0.0);

        fill(_globInteg.begin(), _globInteg.end(), 0.0);
    #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);

        Extrae_eventandcounters(1000, 11);

    #endif

        for (auto &in : _integ)
        {
            in->_fillLinearSystem<FillType::TrilFill>(A, rhs);

            // Fill global integrals from each Integration object
            for (auto i = 0u; i < _globInteg.size(); i++)
                _globInteg[i] += in->_fillStr->_globInteg[i];
        }
    #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);

        Extrae_eventandcounters(1000, 12);
    #endif

        enforceDirichletBC_and_LinearC<FillType::TrilFill>(true, true);

    #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);

        Extrae_eventandcounters(1000, 13);
    #endif

        // FIXME -> introduce fillMatrix and fillRHs
        A->GlobalAssemble();
        rhs->GlobalAssemble();

    #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);

        Extrae_eventandcounters(1000, 14);
    #endif

        for (double &integ : _globInteg) // FIXME:: Share as vector
        {
            double recBuf = 0;
            MPI_Allreduce(&integ, &recBuf, 1, MPI_DOUBLE, MPI_SUM, _comm);
            integ = recBuf;
        }

    #ifdef EXTRAE_PROFILING
        Extrae_eventandcounters(1000, 0);
    #endif
    }

    void HiPerProblem::UpdateGhosts(bool genImporters, int idxMec)
    {
        if (_ghostComputed == true)
            _updateGhosts();

        if (idxMec > 0 and idxMec < int(_dhands.size()))
            _dhands[idxMec]->Update();

        for (auto &dhand : _dhands)
            dhand->UpdateGhosts(genImporters);
    }

    void HiPerProblem::UpdateSolution()
    {
        _updateGhosts();

        int hpIdx = 0;

        for (auto &dhand : _dhands)
        {
            for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
            {
                for (int dof = 0; dof < dhand->numDOFs(); dof++)
                {
                    int nlc = _LCWgraph->getNumNbors(hpIdx, IndexType::Local);

                    if (nlc == 0)
                    {
                        const double value = (*sol)[0][hpIdx];
                        dhand->nodeDOFs->setValue(dof, i, IndexType::Local, value);
                    }
                    else
                    {
                        dhand->nodeDOFs->setValue(dof, i, IndexType::Local, 0.0);

                        for (int nb = 0; nb < nlc; nb++)
                        {
                            const int hiD_mast = _LCWgraph->getNbor(hpIdx, nb, IndexType::Local);
                            const double hiD_weig = _LCWgraph->getWeight(hpIdx, nb, IndexType::Local);

                            const double value = solValue(hiD_mast, IndexType::Global) * hiD_weig;


                            dhand->nodeDOFs->addValue(dof, i, IndexType::Local, value);

                        }

                        dhand->nodeDOFs->addValue(dof, i, IndexType::Local, _LCvalues[hpIdx]);

                    }

                    hpIdx++;
                }
            }
        }
        UpdateGhosts();

    }

    void HiPerProblem::AddSolutionToDOFs(double a)
    {
        _updateGhosts();

        int locHpIdx = 0;
        for(auto &dhand : _dhands)
        {
            for (int i = 0; i < dhand->mesh->loc_nPts(); i++)
            {
                for (int dof = 0; dof < dhand->numDOFs(); dof++)
                {
                    int nlc = _LCWgraph->getNumNbors(locHpIdx, IndexType::Local);

                    if ( nlc == 0 )
                    {
                        const double value = a * (*sol)[0][locHpIdx];
                        dhand->nodeDOFs->addValue(dof, i, IndexType::Local, value);
                    }
                    else
                    {
                        double value{};
                        for ( int nb = 0; nb < nlc; nb++ )
                        {
                            const int     hiD_mast = _LCWgraph->getNbor(locHpIdx, nb, IndexType::Local);
                            const double  hiD_weig = _LCWgraph->getWeight(locHpIdx, nb, IndexType::Local);

                            value += a * solValue(hiD_mast,IndexType::Global) * hiD_weig;
                        }

                        dhand->nodeDOFs->addValue(dof, i, IndexType::Local, value);
                    }

                    locHpIdx++;
                }
            }
        }

        UpdateGhosts();

    }

    void HiPerProblem::setLinearConstraint(CompHiPerIndex slave, CompHiPerIndex master, double weight, double value)
    {
        auto& dhandSl = _dhands[slave.dhand];

        int hpIdx_slave = dhandSl->hiperIdx(slave.idof, slave.index, slave.idxType);


        if (isItemInPart(hpIdx_slave) == false)
            throw runtime_error("HiPerProblem::setLinearConstraint: the hiperIndex " + to_string(hpIdx_slave) +", corresponding to the slave node " + to_string(slave.index) +  " is not in the partition (" + to_string(myRank()) + ").");

        auto& dhandMast = _dhands[master.dhand];
        int hpIdx_master = dhandMast->hiperIdx(master.idof, master.index, master.idxType);


        std::tuple<int, std::vector<int>, std::vector<double>> newTuple (hpIdx_slave, {hpIdx_master}, {weight});
        _temp_LC_data.push_back(newTuple);

        _LCvalues[locIdx(hpIdx_slave)] = value;

    }

    void HiPerProblem::setLinearConstraint(CompHiPerIndex slave, vector<CompHiPerIndex> masters, vector<double> weights, double value)
    {
        auto& dhandSl = _dhands[slave.dhand];

        int hpIdx_slave = dhandSl->hiperIdx(slave.idof, slave.index, slave.idxType);


        if (isItemInPart(hpIdx_slave) == false)
            throw runtime_error("HiPerProblem::setLinearConstraint: the hiperIndex " + to_string(hpIdx_slave) +", corresponding to the slave node " + to_string(slave.index) +  " is not in the partition (" + to_string(myRank()) + ").");


        if (weights.size() != masters.size())
            throw runtime_error("HiPerProblem::setLinearConstraint: the dimension of masters and weights do not coincide");


        _LCvalues[locIdx(hpIdx_slave)] = value;

        for (auto i = 0u; i < weights.size(); i++)
        {
            auto master = masters[i];
            auto& dhandMast = _dhands[master.dhand];
            int hpIdx_master = dhandMast->hiperIdx(master.idof, master.index, master.idxType);

            std::tuple<int, std::vector<int>, std::vector<double>> newTuple (hpIdx_slave, {hpIdx_master}, {weights[i]});
            _temp_LC_data.push_back(newTuple);
        }

    }

    void HiPerProblem::_updateMeshGhosts()
    {

        for (size_t dofHand_idx = 0; dofHand_idx < _dhands.size(); dofHand_idx++)
        {
            auto dhand = _dhands[dofHand_idx];
            auto mesh = dhand->mesh;
            auto adjcyEN = dhand->mesh->_adjcyEN;

            for ( int loc_e = 0; loc_e < mesh->loc_nElem(); loc_e++)
            {
                for ( int i = 0; i < adjcyEN->getNumNbors(loc_e,IndexType::Local); i++ )
                {
                    int nbor = adjcyEN->getNbor(loc_e,i,IndexType::Local);
                    for ( int d = 0; d < dhand->nodeDOFs->numFlds(); d++)
                    {
                        int hpidx = dhand->hiperIdx(d, nbor, IndexType::Global);

                        for( int m = 0; m < _LCWgraph->getNumNbors(hpidx); m++ )
                        {
                            int dof = _LCWgraph->getNbor(hpidx,m);
                            auto chIdx = hiperIndexConverter->getCompHiPerIndex(dof);

                            if ( _dhands[chIdx.dhand]->mesh->_graph->isItemInfoInPart(chIdx.index) == false )
                                _dhands[chIdx.dhand]->mesh->_graph->listGhosts().push_back(chIdx.index);
                        }

                    }
                }
            }
        }

        //this is necessary for right output of PBCs with vtu using hl_PP_OutputToVtk
        for (size_t dofHand_idx = 0; dofHand_idx < _dhands.size(); dofHand_idx++)
        {
            _dhands[dofHand_idx]->mesh->_nodeData->UpdateGhosts(_dhands[dofHand_idx]->mesh->_graph->listGhosts());
        }

    }

    void HiPerProblem::_setMeshLinearConstraints()
    {
        for (size_t dofHand_idx = 0; dofHand_idx < _dhands.size(); dofHand_idx++)
        {
            for (auto lc: _dhands[dofHand_idx]->mesh->_linearConstraints)
            {
                for (int dof_idx = 0; dof_idx < _dhands[dofHand_idx]->nodeDOFs->numFlds(); dof_idx++)
                {
                    CompHiPerIndex slave(int(dofHand_idx), dof_idx, lc.slave, IndexType::Global);
                    vector<CompHiPerIndex> masters;
                    for (size_t m = 0; m < lc.masters.size(); m++)
                        masters.push_back(CompHiPerIndex(int(dofHand_idx), dof_idx, lc.masters[m], IndexType::Global));
                    setLinearConstraint(slave, masters, lc.weights, lc.value);
                }
            }
        }
    }

    void HiPerProblem::_setExtendedBFConstraints()
    {
        for (size_t dofHandIdx{}; dofHandIdx < _dhands.size(); ++dofHandIdx)
        {
            for (auto bf : _dhands[dofHandIdx]->mesh->_cutBFsConstraints)
            {
                for (int dof{}; dof < _dhands[dofHandIdx]->nodeDOFs->numFlds(); ++dof)
                {
                    CompHiPerIndex slaveBF = {static_cast<int>(dofHandIdx), dof, bf.slave, IndexType::Global};
                    vector<CompHiPerIndex> masterBFs;
                    for (size_t i{}; i < bf.masters.size(); ++i)
                    {
                        masterBFs.push_back({static_cast<int>(dofHandIdx), dof, bf.masters.at(i), IndexType::Global});
                    }
                    setLinearConstraint(slaveBF, masterBFs, bf.weights);
                }
            }
            
            int itag = 0;
            std::vector<std::string> dofRegionTags = _getDofTags();
            std::vector<std::string> regionTags = _dhands[dofHandIdx]->mesh->_regionTags();
            for (std::vector<hiperlife::linearConstraint> bfTag : _dhands[dofHandIdx]->mesh->_cutBFConstrRegions)
            {
                for (linearConstraint bf : bfTag)
                {
                    for (int dof{}; dof < _dhands[dofHandIdx]->nodeDOFs->numFlds(); ++dof)
                    {
                        if (regionTags[itag] == dofRegionTags[dof])
                        {
                            CompHiPerIndex slaveBF = {static_cast<int>(dofHandIdx), dof, bf.slave, IndexType::Global};
                            vector<CompHiPerIndex> masterBFs;
                            for (size_t i{}; i < bf.masters.size(); ++i)
                            {
                                masterBFs.push_back({static_cast<int>(dofHandIdx), dof, bf.masters.at(i), IndexType::Global});
                            }
                            setLinearConstraint(slaveBF, masterBFs, bf.weights);
                        }
                    }
                }
                itag += 1;
            }
        }
    }

    void HiPerProblem::_freezeOutDOFsInIBM()
    {
        for (int i{}; i < _dhands[0]->numDOFs(); ++i)
        {
            _dhands[0]->setConstraint(i, 0.0);
        }

        for (int e = 0; e < _dhands[0]->mesh->loc_nElem(); e++)
        {
            if (_dhands[0]->mesh->_elemFlags->getValue(1, e, IndexType::Local) != 0)
            {
                vector<int> nbors = _dhands[0]->mesh->_connec->getNborList(e, IndexType::Local);
                for (auto n : nbors)
                {
                    if (_dhands[0]->mesh->isNodeInPart(n))
                    {
                        for (int i{}; i < _dhands[0]->numDOFs(); ++i)
                        {
                            _dhands[0]->removeConstraint(i, n, IndexType::Global);
                        }
                    }
                }
            }
        }
    }

} // namespace hiperlife
