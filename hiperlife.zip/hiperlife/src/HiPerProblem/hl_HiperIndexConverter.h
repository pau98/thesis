/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HIPERSTRUCT_H
#define HIPERSTRUCT_H

#include "hl_DistributedSrcData.h"
#include "hl_TypeDefs.h"


namespace hiperlife
{
    /*!
     * \class CompHiPerIndex
     * \brief Class that encapsulates the four indices that characterizes a hiperIndex in one class
     *
    */
    class CompHiPerIndex
    {
        public:

            int dhand;   ///< Index of the DOFsHandler
            int idof;    ///< Index of dof inside DOFsHandler
            int index;  ///< Index of the node
            IndexType idxType; ///< Node index type: IndexType::Local or IndexType::Global

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors.
                To initialize a CompHiPerIndex we need the index of the DOFsHandler, the number of dof
                and the node index in global or local labeling. If the index type is not specified
                it assumes that the node index is global.
            *  @{ */
            /*! \brief Constructor with individual parameters. */
            CompHiPerIndex(int m, int d, int i, IndexType iT = IndexType::Global) : dhand(m), idof(d), index(i), idxType(iT) {}
            /*! \brief Constructor with tuple of four parameters. Can be used with an initialization list. */
            CompHiPerIndex(std::tuple<int, int, int, IndexType> init) : dhand(std::get<0>(init)), idof(std::get<1>(init)), index(std::get<2>(init)), idxType(std::get<3>(init)) {}
            /*! \brief Constructor with tuple of three parameters assumes indextype to be global. Can be used with an initialization list. */
            CompHiPerIndex(std::tuple<int, int, int> init) : dhand(std::get<0>(init)), idof(std::get<1>(init)), index(std::get<2>(init)), idxType(IndexType::Global) {}
            /** @} */
    };

    /*!
     * \class HiperIndexConverter
     * \brief Hiperindex converter from hiperindex to complex hiper index and vice versa for usage in
     * <b>hiperlife</b>.
     *
     * It takes information about the number of processors, number of DOFsHandlers, number of local nodes
     * and number of degrees of freedom
    */
    class HiperIndexConverter : DistributedClass
    {
        public:
            /** @name Object Creation Management
            *  @{
            */
            /*! \brief Method that sets the number of partitions. */
            inline void setNumberOfProcs(int nPart)
            {
                _loc_offDHand.resize(nPart);
            };

            /*! \brief Method that sets the number of DOFsHandlers. */
            inline void setNumberOfDOFsHandlers(int nDHands)
            {
                if (_loc_offDHand.size() == 0)
                    throw std::runtime_error("HiperIndexConverter::setNumberOfDOFsHandlers: Number of processor not set!");

                for (auto i = 0u; i <  _loc_offDHand.size(); i++)
                    _loc_offDHand[i].resize(nDHands);
                _dhandDOFs.resize(nDHands);

                _loc_offProcs.resize(nDHands);
                for (auto i = 0u; i <  _loc_offProcs.size(); i++)
                    _loc_offProcs[i].resize(_loc_offDHand.size());
            };

            /*! \brief Method that sets the number of degrees of freedom in a DOFsHandler. */
            inline void setNDOFDOFsHandler(int dhand, int nDOF)
            {
                if (dhand >= int(_dhandDOFs.size()))
                    throw std::runtime_error("HiperIndexConverter::setNDOFDOFsHandler: Number of DOFsHandlers smaller than DOFsHandler tag");
                else
                    _dhandDOFs[dhand] = nDOF;
            };

            /*! \brief Method that sets the number of items of a DOFsHandler in a partition. */
            inline void setLocNItemDOFsHandler(int p, int dhand, int locnItem)
            {
                if (p >= int(_loc_offDHand.size()))
                    throw std::runtime_error("HiperIndexConverter::setLocNItemDOFsHandler: Number of partitions smaller than partition tag");
                else if (dhand >= int(_loc_offDHand[p].size()))
                    throw std::runtime_error("HiperIndexConverter::setLocNItemDOFsHandler: Number of DOFsHandlers smaller than DOFsHandler tag");
                else
                {
                    _loc_offDHand[p][dhand]=locnItem;
                    _loc_offProcs[dhand][p]=locnItem;
                }
            }

            /*! \brief Method check all the parameters and creates the object. */
            inline void Update()
            {
                int cum{};
                for (auto p = 0u; p < _loc_offDHand.size(); p++)
                {
                    for (auto m = 0u; m < _loc_offDHand[p].size(); m++)
                    {
                        int locNPts = _loc_offDHand[p][m];
                        int locTotNPts = locNPts*_dhandDOFs[m];
                        _loc_offDHand[p][m] = cum;
                        cum += locTotNPts;
                    }
                }

                for (auto m = 0u; m < _loc_offProcs.size(); m++)
                {
                    cum = 0;
                    for (auto p = 0u; p < _loc_offProcs[m].size(); p++)
                    {
                        int locNPts = _loc_offProcs[m][p];
                        _loc_offProcs[m][p] = cum;
                        cum += locNPts;
                    }
                }
            }

            /*! \brief Method to get the complex hiper index from a given hiper index. */
            inline CompHiPerIndex getCompHiPerIndex(int hpIdx)
            {

                auto p = 0u;

                while (p < _loc_offDHand.size()-1)
                {
                    if (hpIdx < _loc_offDHand[p+1][0])
                        break;
                    p++;
                }

                if (p == _loc_offDHand.size())
                    throw std::runtime_error("HiperStruct: Partition not found!");

                auto m = 0u;
                while (m < _loc_offDHand[p].size()-1)
                {
                    if (hpIdx < _loc_offDHand[p][m+1])
                        break;
                    m++;
                }

                if (m == _loc_offDHand[p].size())
                    throw std::runtime_error("HiperStruct: DOFsHandler not found!");

                int lh = hpIdx - _loc_offDHand[p][m];

                CompHiPerIndex chIdx(m,lh % _dhandDOFs[m],lh / _dhandDOFs[m] + _loc_offProcs[m][p],IndexType::Local);

                return chIdx;
            }
            //TODO: inverse method and include this in DOFsHandler to substitute inner methods

        private:

            std::vector <std::vector <int>> _loc_offDHand ={}; //offsets per DOFsHandler in each partition (first index is partition, second is DOFsHandler), equal to localhiperindex offset
            std::vector <std::vector <int>> _loc_offProcs ={}; //offsets per partition in each DOFsHandler (first index is DOFsHandler, second is partition), equal to global offset in DOFsHandler
            std::vector <int> _dhandDOFs={};                    //number of degrees of freedom in a DOFsHandler
    };



}


#endif //HIPERSTRUCT_H
