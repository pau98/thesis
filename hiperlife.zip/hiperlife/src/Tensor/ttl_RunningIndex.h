/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ttl_runningindex_h
#define ttl_runningindex_h

namespace ttl
{
    template<bool All=false>
    struct runningIndex;

    template<>
    struct runningIndex<false>
    {
        int first{};
        int last{};

        runningIndex(int _first, int _last)
        {
            first = _first;
            last  = _last;
        }

        int size() const
        {    return last-first+1;}
    };

    template<>
    struct runningIndex<true>
    {};

    typedef runningIndex<false> range;
    static constexpr runningIndex<true> all;
}

#endif //ttl_runningindex_h
