/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_tensorindicesoperations_impl_h
#define ttl_tensorindicesoperations_impl_h

#if __cplusplus >= 201402L

namespace ttl
{    
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
    struct TensorIndicesOperation::product_tidx<Type1, St1, Co1, Ow1, typelist<Indices1...>, Type2, St2, Co2, Ow2, typelist<Indices2...>, false>
    {
        static auto function( const tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> &tens1, const tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> &tens2) -> typename std::conditional<sizeof...(Indices1)+sizeof...(Indices2)-2*remove_duplicates<Indices1...,Indices2...>::shared_first.size()==0, typename std::common_type<Type1,Type2>::type, tensor<typename std::common_type<Type1,Type2>::type, remove_duplicates<Indices1...,Indices2...>::type::size,true,true>>::type
        {
            typedef remove_duplicates<Indices1...,Indices2...> type;
            constexpr int contOrder = remove_duplicates<Indices1...,Indices2...>::shared_first.size();

            constexpr auto idx1_1 = firsthalf<type::free.size(),sizeof...(Indices1)-contOrder>(type::free);
            constexpr auto idx1_2 = type::shared_first;
            constexpr auto idx2_1 = substract<type::shared_second.size(),sizeof...(Indices1)>(type::shared_second);
            constexpr auto idx2_2 = substract<secondhalf<type::free.size(),sizeof...(Indices1)-contOrder>(type::free).size(),sizeof...(Indices1)>(secondhalf<type::free.size(),sizeof...(Indices1)-contOrder>(type::free));

            constexpr auto idx1 = concat(idx1_1,idx1_2);
            auto res1 = tens1._tensor.transpose(idx1);

            constexpr auto idx2 = concat(idx2_1,idx2_2);
            auto res2 = tens2._tensor.transpose(idx2);

            constexpr bool isScalar = sizeof...(Indices1)+sizeof...(Indices2)-2*contOrder==0;
            
            return TensorOperation::template _productLastFirst<Type1,Type2,sizeof...(Indices1),sizeof...(Indices2),contOrder, isScalar>::function( res1, res2 );
        }

    };

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
    struct TensorIndicesOperation::product_tidx<Type1, St1, Co1, Ow1, typelist<Indices1...>, Type2, St2, Co2, Ow2, typelist<Indices2...>, true>
    {
        static auto function(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& tens1, tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> const& tens2) -> tensor<typename std::common_type<Type1,Type2>::type, remove_duplicates<Indices1...,Indices2...>::type::size, true, true>
        {
            return outer(tens1._tensor,tens2._tensor);
        }
    };

    template <class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::fake_contract<Type, Order,St,Co,false,Indices...>
    {
        static auto function(tensor<Type,Order,St,Co> const& tens) -> typename std::conditional<remove_duplicates<Indices...>::free.size()==0, Type, tensor<Type,remove_duplicates<Indices...>::free.size()> >::type
        {
            constexpr auto idx1 = remove_duplicates<Indices...>::shared_first;
            constexpr auto idx2 = remove_duplicates<Indices...>::free;
            constexpr auto idx3 = remove_duplicates<Indices...>::shared_second;

            constexpr auto idx = concat(concat(idx1,idx2),idx3);
                        
            constexpr int contOrder = remove_duplicates<Indices...>::shared_first.size();
            constexpr bool isScalar = remove_duplicates<Indices...>::free.size()==0;
            
            return TensorOperation::template _contractLastFirst<Type,Order,contOrder,isScalar>::function(tens.transpose(idx));
        }
    };

    template <class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::fake_contract<Type, Order,St,Co,true, Indices...>
    {
        static tensor<Type,Order,St,Co> & function(tensor<Type,Order,St,Co> & tens)
        {
            return tens;
        }
        static tensor<Type,Order,St,Co>&& function(tensor<Type,Order,St,Co> && tens) 
        {
            return std::move(tens);
        }
    };

    template<bool ints, bool move, class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::onemorefakecontracttuple<true,ints,move,Type,Order,St,Co,std::tuple<Indices...>>
    {
        static Type function(tensor<Type,Order,St,Co> const& tens)
        {
            return fake_contract<Type,Order,St,Co,remove_duplicates<Indices...>::shared_first.size()==0,Indices...>::function(tens);
        }
    };

    template<bool ints, class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::onemorefakecontracttuple<false,ints,false,Type,Order,St,Co,std::tuple<Indices...>>
    {
        static constexpr bool contraction = remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order;

        static tensor_indices<Type, typename remove_duplicates<Indices...>::type,(St and not ints) or contraction,(Co and not ints) or contraction, contraction> function(tensor<Type,Order,St,Co> & tens)
        {
            return fake_contract<Type,Order,St,Co,remove_duplicates<Indices...>::shared_first.size()==0,Indices...>::function(tens);
        }
    };

    template<bool ints, class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::onemorefakecontracttuple<false,ints,true,Type,Order,St,Co,std::tuple<Indices...>>
    {
        static constexpr bool contraction = remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order;

        static tensor_indices<Type, typename remove_duplicates<Indices...>::type, St or contraction, Co or contraction, true> function(tensor<Type,Order,St,Co> && tens)
        {
            return fake_contract<Type,Order,St,Co,remove_duplicates<Indices...>::shared_first.size()==0,Indices...>::function(std::move(tens));
        }
    };

    template<bool scalar, class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::yetanotherfakecontract<true,scalar,true,Type, Order, St, Co, Indices...>
    {
        static auto function(tensor<Type,Order, St, Co> & tens, const Indices... indices) -> decltype(onemorefakecontracttuple<scalar,true,true,Type,Order-_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value,false, false,remove_t<int,Indices...>>::function( std::move(tensor<Type,Order,St,Co>:: template _getSubspace<false,Indices...>::function(tens,indices...))))
        {
            return onemorefakecontracttuple<scalar,true,true,Type,Order-_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value,false,false,remove_t<int,Indices...>>::function( std::move(tensor<Type,Order,St,Co>:: template _getSubspace<false,Indices...>::function(tens,indices...)));
        }
    };

    template<bool scalar, class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::yetanotherfakecontract<false, scalar, false, Type, Order, St, Co, Indices...>
    {
        static auto function(tensor<Type,Order,St,Co> & tens, const Indices...) -> decltype( onemorefakecontracttuple<scalar,false,false,Type,Order,St,Co,std::tuple<Indices...>>::function(tens))
        {
            return onemorefakecontracttuple<scalar,false,false,Type,Order,St,Co,std::tuple<Indices...>>::function(tens);
        }
    };

    template<bool scalar, class Type, int Order, bool St, bool Co, class... Indices>
    struct TensorIndicesOperation::yetanotherfakecontract<false,scalar, true, Type, Order, St, Co, Indices...>
    {
        static auto function(tensor<Type,Order,St,Co> && tens, const Indices...) -> decltype( onemorefakecontracttuple<scalar,false,true,Type,Order,St,Co,std::tuple<Indices...>>::function(std::move(tens)))
        {
            return onemorefakecontracttuple<scalar,false,true,Type,Order,St,Co,std::tuple<Indices...>>::function(std::move(tens));
        }
    };
}

#endif //__cplusplus >= 201402L
#endif //ttl_tensorindices_h