/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_tensorindices_impl_h
#define ttl_tensorindices_impl_h

#if __cplusplus >= 201402L

namespace ttl
{
    template <class Type, int Order>
    template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type*>
    auto tensor<Type,Order,false,false>::operator() ( const Indices... indices ) -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type, tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type,remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0, remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0, remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order>>::type
    {
        constexpr bool ints = _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value>0;
        constexpr bool scalar = remove_duplicates_tuple<remove_t<int,Indices...>>::type::size == 0;
  
        return TensorIndicesOperation::yetanotherfakecontract<ints,scalar,ints,Type,Order,false,false,Indices...>::function(*this,indices...);
    }

    template <class Type, int Order>
    template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type*>
    auto tensor<Type,Order,false,true>::operator() ( const Indices... indices ) -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type, tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type, remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0, (_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value==0) or (remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0), remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order>>::type
    {
        constexpr bool ints = _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value>0;
        constexpr bool scalar = remove_duplicates_tuple<remove_t<int,Indices...>>::type::size == 0;

        return TensorIndicesOperation::yetanotherfakecontract<ints,scalar,ints,Type,Order,false,true,Indices...>::function(*this,indices...);
    }

    template <class Type, int Order>
    template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type*>
    auto tensor<Type,Order,true,true>::operator() ( const Indices... indices ) & -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type,tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type, (_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value==0) or (remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0), (_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value==0) or (remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0), remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order>>::type
    {
        constexpr bool ints = _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value>0;
        constexpr bool scalar = remove_duplicates_tuple<remove_t<int,Indices...>>::type::size == 0;

        return TensorIndicesOperation::yetanotherfakecontract<ints,scalar,ints,Type,Order,true,true,Indices...>::function(*this,indices...);
    }

    template <class Type, int Order>
    template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type*>
    auto tensor<Type,Order,true,true>::operator() ( const Indices... indices ) && -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type,tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type,true, true, true>>::type
    {
        constexpr bool ints = _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value>0;
        constexpr bool scalar = remove_duplicates_tuple<remove_t<int,Indices...>>::type::size == 0;

        return TensorIndicesOperation::yetanotherfakecontract<ints,scalar,true,Type,Order,true,true,Indices...>::function(std::move(*this),indices...);
    }

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
    auto operator*(const tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1>& ti1, const tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2>& ti2) -> typename std::conditional<sizeof...(Indices1)+sizeof...(Indices2)-2*remove_duplicates<Indices1...,Indices2...>::shared_first.size()==0, typename std::common_type<Type1,Type2>::type,tensor_indices<typename std::common_type<Type1,Type2>::type, typename remove_duplicates<Indices1...,Indices2...>::type,true, true, true>>::type
    {
        constexpr bool cond = remove_duplicates<Indices1..., Indices2...>::type::size == typelist<Indices1..., Indices2...>::size;

        typename std::conditional<sizeof...(Indices1)+sizeof...(Indices2)-2*remove_duplicates<Indices1...,Indices2...>::shared_first.size()==0, typename std::common_type<Type1,Type2>::type,tensor_indices<typename std::common_type<Type1,Type2>::type, typename remove_duplicates<Indices1...,Indices2...>::type,true, true, true>>::type prod = TensorIndicesOperation::product_tidx<Type1, St1, Co1, Ow1, typelist<Indices1...>, Type2, St2, Co2, Ow2, typelist<Indices2...>, cond>::function(ti1, ti2);
        return prod;
    }

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2>
    tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true> operator+(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices1...>, St2, Co2, Ow2> const& ti2)
    {

        return ti1._tensor + ti2._tensor;
    }

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
    tensor_indices<typename std::common_type<Type1,Type2>, typelist<Indices1...>,true,true,true> operator+(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> const& ti2)
    {
        static_assert(remove_duplicates<Indices1...,Indices2...>::free.size()==0, "Indices do not match");
        
        return ti1._tensor + ti2._tensor.transpose(remove_duplicates<Indices2...,Indices1...>::shared_first);
    }

    template <class Type1, class... Indices1, bool St2, bool Co2, bool Ow2, class... Indices2>
    tensor_indices<Type1, typelist<Indices1...>,true,true,true>&& operator+(tensor_indices<Type1, typelist<Indices1...>, true, true, true> && ti1, tensor_indices<Type1, typelist<Indices2...>, St2, Co2, Ow2> const& ti2)
    {
        ti1 += ti2;
        return std::move(ti1);
    }

    template <class Type1, class... Indices1, class... Indices2>
    tensor_indices<Type1, typelist<Indices1...>,true,true,true>&& operator+(tensor_indices<Type1, typelist<Indices1...>, true, true, true> && ti1, tensor_indices<Type1, typelist<Indices2...>, true, true, true> && ti2)
    {
        ti1 += ti2;
        return std::move(ti1);
    }

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2>
    auto operator-(tensor_indices<typename std::common_type<Type1,Type2>, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices1...>, St2, Co2, Ow2> const& ti2) -> tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true>
    {
        return ti1._tensor - ti2._tensor;
    }

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
    auto operator-(tensor_indices<typename std::common_type<Type1,Type2>, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> const& ti2) -> tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true>
    {
        static_assert(remove_duplicates<Indices1...,Indices2...>::free.size()==0, "Indices do not match");

        return ti1._tensor - ti2._tensor.transpose(remove_duplicates<Indices2...,Indices1...>::shared_first);
    }

    template <class Type1, class... Indices1, bool St2, bool Co2, bool Ow2, class... Indices2>
    tensor_indices<Type1, typelist<Indices1...>,true,true,true>&& operator-(tensor_indices<Type1, typelist<Indices1...>, true, true, true> && ti1, tensor_indices<Type1, typelist<Indices2...>, St2, Co2, Ow2> const& ti2)
    {
        ti1 -= ti2;
        return std::move(ti1);
    }

    template <class Type1, class... Indices1, class... Indices2>
    tensor_indices<Type1, typelist<Indices1...>,true,true,true>&& operator-(tensor_indices<Type1, typelist<Indices1...>, true, true, true> && ti1, tensor_indices<Type1, typelist<Indices2...>, true, true, true> && ti2)
    {
        ti1 -= ti2;
        return std::move(ti1);
    }

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
    auto operator+(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>
    {
        return static_cast<tensor<typename std::common_type<Type1,S>::type,sizeof...(Indices1)>>(ti1._tensor) + scalar;
    }
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
    auto operator-(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>
    {
        return static_cast<tensor<typename std::common_type<Type1,S>::type,sizeof...(Indices1)>>(ti1._tensor) - scalar;
    }
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
    auto operator*(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>
    {
        return static_cast<tensor<typename std::common_type<Type1,S>::type,sizeof...(Indices1)>>(ti1._tensor) * scalar;
    }

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
    auto operator/(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>
    {
        return static_cast<tensor<typename std::common_type<Type1,S>::type,sizeof...(Indices1)>>(ti1._tensor) / scalar;
    }
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
    auto operator+(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>
    {
        return scalar+static_cast<tensor<typename std::common_type<Type1,S>::type,sizeof...(Indices1)>>(ti1._tensor);
    }
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
    auto operator-(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>
    {
        return scalar-static_cast<tensor<typename std::common_type<Type1,S>::type,sizeof...(Indices1)>>(ti1._tensor);
    }
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
    auto operator*(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>
    {
        return scalar*static_cast<tensor<typename std::common_type<Type1,S>::type,sizeof...(Indices1)>>(ti1._tensor);
    }

    template <class Type1, class... Indices1>
    auto operator+(tensor_indices<Type1,typelist<Indices1...>,true,true,true> && ti1, Type1 const scalar ) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true> &&
    {
        ti1 += scalar;
        return std::move(ti1);
    }
    template <class Type1, class... Indices1>
    auto operator-(tensor_indices<Type1,typelist<Indices1...>,true,true,true> && ti1, Type1 const scalar ) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true> &&
    {
        ti1 -= scalar;
        return std::move(ti1);
    }
    template <class Type1, class... Indices1>
    auto operator*(tensor_indices<Type1,typelist<Indices1...>,true,true,true> && ti1, Type1 const scalar ) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true> &&
    {
        ti1 *= scalar;
        return std::move(ti1);
    }
    template <class Type1, class... Indices1>
    auto operator/(tensor_indices<Type1,typelist<Indices1...>,true,true,true> && ti1, Type1 const scalar ) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true> &&
    {
        ti1 /= scalar;
        return std::move(ti1);
    }
    template <class Type1, class... Indices1>
    auto operator+(Type1 const scalar , tensor_indices<Type1,typelist<Indices1...>,true,true,true> && ti1) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true> &&
    {
        ti1 += scalar;
        return std::move(ti1);
    }
    template <class Type1, class... Indices1>
    auto operator-(Type1 const scalar , tensor_indices<Type1,typelist<Indices1...>,true,true,true> && ti1) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true> &&
    {
        ti1 -= scalar;
        return std::move(-ti1);
    }
    template <class Type1, class... Indices1>
    auto operator*(Type1 const scalar , tensor_indices<Type1,typelist<Indices1...>,true,true,true> && ti1) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true> &&
    {
        ti1 *= scalar;
        return std::move(ti1);
    }
}

#endif //__cplusplus >= 201402L
#endif //ttl_tensorindices_impl_h
