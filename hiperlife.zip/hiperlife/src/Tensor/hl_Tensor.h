#include "ttl.h"

namespace hiperlife
{
    namespace Tensor = ttl;
}
