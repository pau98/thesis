/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ttl_tensor_h
#define ttl_tensor_h

namespace ttl
{
    template <class Type, int Order>
    class tensor<Type,Order,false,false>
    {
        static_assert(Order>0, "Order must be larger than 0.");

        public:

            tensor(Type* ptr, std::array<int,Order> const& dims, std::array<int,Order> const& jumps) : _dims{dims}, _jumps{jumps}, _data{ptr} 
            {}

            tensor(tensor<Type,Order,false,false> const& other) : _dims{other._dims}, _jumps{other._jumps}, _data{other._data} 
            {}
            tensor& operator=(tensor<Type,Order,false,false> const& other);

            tensor(tensor<Type,Order,false,false> && other) : _dims{other._dims}, _jumps{other._jumps}, _data{other._data}
            {}
            tensor& operator=(tensor<Type,Order,false,false> && other);

            template<class S>
            tensor& operator=(tensor<S,Order,false,false> const& other);
            void operator=(NestedInitializerListsT<Type,Order> init_list );

        protected:
            tensor(){};
            std::array<int,Order> _dims{};
            std::array<int,Order> _jumps{};

            Type* _data{nullptr};

        private:
            template<class S, int n, bool noFinal>
            struct _print;
        
        public: 

            std::array<int, Order> shape() const
            {    return _dims;    }

            std::array<int, Order> jumps() const
            {    return _jumps;    }

            Type* data() const
            {    return _data;   }

            Type det();
            Type norm();
            tensor<Type,Order> inv ( );

            void print( std::ostream& out, const std::string opening, const std::string closing, const std::string separator) const
            {    _print<tensor,0,(0<Order-1)>::function( (*this), out, opening, closing, separator );    }

            friend std::ostream& operator<<(std::ostream& out, tensor const& tens)
            {
                tens.print( out, "[", "]", ",");
                return out;
            }

        //Subspace
        //------------------------------------------------------------
        private:

            template <int isScalar, typename... Indices>
            struct _getSubspace;

            template <typename... Indices>
            struct _getSubspace<false, Indices...>
            {
#if __cplusplus >= 201402L
                static auto function(const tensor<Type,Order,false,false>& thetensor, const Indices&... indices) -> tensor<Type,_nRunningIndices<sizeof...(Indices)==1,Indices...>::value+_nIndices<sizeof...(Indices)==1,Indices...>::value, false, false>;
#else
                static auto function(const tensor<Type,Order,false,false>& thetensor, const Indices&... indices) -> tensor<Type,_nRunningIndices<sizeof...(Indices)==1,Indices...>::value, false, false>;
#endif
            };
            
            template <typename... Indices>
            struct _getSubspace<true, Indices...>
            {
                static Type& function(const tensor<Type,Order,false,false>& thetensor,const Indices&... indices);
            };

            template<class Idx>
            typename std::enable_if< std::is_same<int, Idx>::value, int>::type
            _getVecIndex(const Idx& idx) const;
            template <class Idx, class... Indices>
            typename std::enable_if< std::is_same<int, Idx>::value, int>::type
            _getVecIndex(const Idx& idx, const Indices&... indices) const;
            
            template <int i, size_t childOrder,class Idx>
            typename std::enable_if<std::is_same<int, Idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx) const;
            
            template <int i, size_t childOrder,class Idx, class... Indices>
            typename std::enable_if< std::is_same<int, Idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx, const Indices&... indices) const;

            template <int i, size_t childOrder,class Idx>
            typename std::enable_if< std::is_same<runningIndex<true>, Idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx) const;

            template <int i, size_t childOrder,class Idx>
            typename std::enable_if< std::is_same<runningIndex<false>, Idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx) const;

            template <int i, size_t childOrder,class Idx, class... Indices>
            typename std::enable_if< std::is_same<runningIndex<true>, Idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx, const Indices&... indices) const;
            template <int i, size_t childOrder,class Idx, class... Indices>
            typename std::enable_if< std::is_same<runningIndex<false>, Idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx, const Indices&... indices) const;

#if __cplusplus >= 201402L
            template <int i, size_t childOrder,class Idx>
            typename std::enable_if<is_instance<Idx,idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx) const;
            template <int i, size_t childOrder,class Idx, class... Indices>
            typename std::enable_if<is_instance<Idx,idx>::value, int>::type
            _getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, const Idx& idx, const Indices&... indices) const;
#endif

        public:
            template <class... Indices, typename std::enable_if<areIntsOrRIs<Indices...>::value>::type* = nullptr>
            auto operator() ( const Indices&... indices ) ->  decltype(tensor<Type,Order,false,false>::template _getSubspace<areInts<Indices...>::value,Indices...>::function(*this,indices...))
            {    return tensor<Type,Order,false,false>::template _getSubspace<areInts<Indices...>::value,Indices...>::function(*this,indices...);    }

            template<int n>
            typename std::enable_if<n<Order-1, void>::type
            _initialize( int vidx,  NestedInitializerListsT<Type,Order-n> init_list );

            template<int n>
            typename std::enable_if<n==Order-1, void>::type
            _initialize( int vidx, NestedInitializerListsT<Type,1> init_list );

        public:

            tensor<Type,Order,false,false> transpose ( std::array<int,Order> const& indices) const;
            tensor<Type,Order,false,false> T ( ) const;

            template<class S, int Order2, bool Storage, bool Contiguous>
            friend class tensor;

            template< class S, class U, int Order2 >
            friend auto operator+(tensor<S,Order2,false,false> const& tensor1, tensor<U,Order2,false,false> const& tensor2 ) -> tensor<typename std::common_type<S,U>::typ,Order2>;

            template< class S, class U, int Order2 >
            friend auto operator-(tensor<S,Order2,false,false> const& tensor1, tensor<U,Order2,false,false> const& tensor2 ) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator+(tensor<S,Order2,false,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;
            template <class S, class U, int Order2, typename C>
            friend auto operator+(U const scalar,tensor<S,Order2,false,false> const& tensor1) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator-(tensor<S,Order2,false,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;
            template <class S, class U, int Order2, typename C>
            friend auto operator-(U const scalar,tensor<S,Order2,false,false> const& tensor1) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator*(tensor<S,Order2,false,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;
            template <class S, class U, int Order2, typename C>
            friend auto operator*(U const scalar,tensor<S,Order2,false,false> const& tensor1) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator/(tensor<S,Order2,false,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2>
            friend tensor<typename std::common_type<S,U>::type,Order2> eproduct(tensor<S,Order2,false,false> const& tensor1, tensor<U,Order2,false,false> const& tensor2 );

            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator+=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator-=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator*=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator/=(U const scalar);

            tensor<Type,Order> operator-();

            template <class U>
            void operator+=(tensor<U,Order,false,false> const& tensor2);
            template <class U>
            void operator-=(tensor<U,Order,false,false> const& tensor2);

            friend class TensorOperation;

#if __cplusplus >= 201402L

            template<bool ints, bool scalar, bool move, class Type2, int Order2, bool St2, bool Co2, class... Indices>
            friend struct yetanotherfakecontract;

            template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type* = nullptr>
            auto operator() ( const Indices... indices ) -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type, tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type,remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0, remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0, remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order>>::type;


            template<class S, class U, bool St, bool Co, bool Ow>
            tensor(tensor_indices<S,U,St,Co,Ow> const& other) : tensor{other._tensor} { }
            template<class S, bool St, bool Co, bool Ow, class... U>
            tensor<Type,Order,false,false>& operator =(tensor_indices<S,typelist<U...>,St,Co,Ow>& other){*this = other._tensor; return *this;}

            friend class TensorIndicesOperation;

#endif

    };

    template <class Type, int Order>
    class tensor<Type,Order,false> : public tensor<Type,Order,false,false>
    {
        using __ = tensor<Type,Order,false,false> ;

        public:

            tensor(){};

            template <class... Dims>
            tensor ( Type* pointer, const Dims... dims);

            tensor(tensor<Type,Order,false,true> const& other)
            {
                __::_dims = other._dims;
                __::_jumps = other._jumps;
                 _size = other._size;
                __::_data = other._data;
            }

            tensor<Type,Order,false>& operator=(tensor<Type,Order,false> const& other)
            {
                std::copy( other._data, other._data + _size, __::_data );
                return *this;
            }

            tensor<Type,Order,false>& operator=(tensor<Type,Order,false> && other)
            {
                std::copy( other._data, other._data + _size, __::_data );
                return *this;
            }

            tensor(tensor<Type,Order,false> && other)
            {
                __::_dims = other._dims;
                __::_jumps = other._jumps;
                 _size = other._size;
                  __::_data = other._data;
            }

            template<bool St>
            tensor(tensor<Type,Order,St> const& other)
            {
                __::_dims = other._dims;
                __::_jumps = other._jumps;
                 _size = other._size;
                  __::_data = other._data;
            }


            template<class S, bool St>
            tensor<Type,Order,false>& operator=(tensor<S,Order,St> const& other)
            {
                std::copy( other._data, other._data + _size, __::_data );
                return *this;
            }

            tensor(tensor<Type,Order,false,false> const& other) = delete;  
            tensor(tensor<Type,Order,false,false> && other) = delete;  

            template<class S>
            tensor<Type,Order,false>& operator=(tensor<S,Order,false,false> const& other);

        protected:

            void _calculateJumps();          
            int _size{};

        public:

            template<class S, int Order2, bool Storage, bool Contiguous>
            friend class tensor;

            template< class S, class U, int Order2 >
            friend auto operator+(tensor<S,Order2,false> const& tensor1, tensor<U,Order2,false> const& tensor2 ) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template< class S, class U, int Order2 >
            friend auto operator-(tensor<S,Order2,false> const& tensor1, tensor<U,Order2,false> const& tensor2 ) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator+(tensor<S,Order2,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;
            template <class S, class U, int Order2, typename C>
            friend auto operator+(U const scalar,tensor<S,Order2,false> const& tensor1) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator-(tensor<S,Order2,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;
            template <class S, class U, int Order2, typename C>
            friend auto operator-(U const scalar,tensor<S,Order2,false> const& tensor1) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator*(tensor<S,Order2,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;
            template <class S, class U, int Order2, typename C>
            friend auto operator*(U const scalar,tensor<S,Order2,false> const& tensor1) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class S, class U, int Order2, typename C>
            friend auto operator/(tensor<S,Order2,false> const& tensor1, U const scalar ) -> tensor<typename std::common_type<S,U>::type,Order2>;

            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator+=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator-=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator*=(U const scalar);
            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator/=(U const scalar);

            tensor<Type,Order> operator-();
            
            template <class U>
            void operator+=(tensor<U,Order,false> const& tensor2);
            template <class U>
            void operator-=(tensor<U,Order,false> const& tensor2);
            template <class U>
            void operator+=(tensor<U,Order,false,false> const& tensor2){__::operator+=(tensor2);}
            template <class U>
            void operator-=(tensor<U,Order,false,false> const& tensor2){__::operator-=(tensor2);}

            int size() const
            {    return _size;}
            Type det();
            tensor<Type,Order> inv ();
            Type norm();

            friend class TensorOperation;

            template <class... Indices, typename std::enable_if<areIntsOrRIs<Indices...>::value>::type* = nullptr>
            auto operator() ( const Indices... indices ) ->  decltype(tensor<Type,Order,false,false>::template _getSubspace<areInts<Indices...>::value,Indices...>::function(*this,indices...))
            {
                return tensor<Type,Order,false,false>::template _getSubspace<areInts<Indices...>::value,Indices...>::function(*this,indices...);
            }

#if __cplusplus >= 201402L
            template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type* = nullptr>
            auto operator() ( const Indices... indices ) -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type, tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type, remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0, (_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value==0) or (remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0), remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order>>::type;

            template<class U>
            tensor(tensor_indices<Type,U,false,true,true> && other) : tensor{std::move(other._tensor)} { }
            template<class... U>
            tensor<Type,Order,false,true>& operator =(tensor_indices<Type,typelist<U...>,false,true,true>&& other){*this=std::move(other._tensor); return *this;}

            template<class S, class U, bool St, bool Co, bool Ow>
            tensor(tensor_indices<S,U,St,Co,Ow> const& other) : tensor{other._tensor} { }
            template<class S, bool St, bool Co, bool Ow, class... U>
            tensor<Type,Order,false,true>& operator =(tensor_indices<S,typelist<U...>,St,Co,Ow>& other){*this=other._tensor; return *this;}
#endif
    };

    template <class Type, int Order>
    class tensor<Type,Order,true> : public tensor<Type,Order,false>
    {
        using __= tensor<Type,Order,false,false> ;
        using _= tensor<Type,Order,false> ;

        public:

            tensor(){};

            ~tensor()
            {    clear();    };

            template <class... Dims>
            tensor ( int dim1, const Dims... dims);

            tensor(tensor<Type,Order>& other) : _()
            {
                resize(other); 
                _copy(other);
            }
            tensor& operator=(tensor<Type,Order>& other)
            {
                _copy(other); 
                return *this;
            }

            tensor(tensor<Type,Order> && other) : _()
            {    _copySizesAndSwap(std::move(other));    }
            tensor& operator=(tensor<Type,Order> && other)
            {
                _swap(std::move(other));
                return *this;
            }

            template<class S, bool St>
            tensor(tensor<S,Order,St> const& other)
            {    resize(other);    _copy(other);    }
            template<class S, bool St>
            tensor<Type,Order>& operator=(tensor<S,Order,St> const& other)            
            {
                _copy(other); 
                return *this;
            }

            template<class S>
            tensor(tensor<S,Order,false,false> const& other);

            tensor(NestedInitializerListsT<Type,Order> init_list);

            void clear();

            template<class S>
            void resize(tensor<S,Order,false,false> const& other);
            template<class S>
            void resize(tensor<S,Order,false,true> const& other);

            template <class U, typename C = typename std::enable_if<not is_tensor<U>::value and not is_tensor_indices<U>::value, void>::type>
            void operator=(U const scalar){_::operator=(scalar);}

            template <class... Dims>
            void resize( int dim1, const Dims... dims )
            {
                clear();
                new (this) tensor<Type,Order>(dim1, dims...);
            }

            tensor<Type,Order,false,false> transpose ( std::array<int,Order> const& indices) const &
            {    return __::transpose(indices);    }
            tensor<Type,Order,false,false> T ( ) const &
            {    return __::T();}
            tensor<Type,Order> transpose ( std::array<int,Order> const& indices) const && 
            {    return __::transpose(indices);    }
            tensor<Type,Order> T ( ) const &&
            {    return __::T();}

        protected:

            template<class S, bool St>
            void _copy(tensor<S,Order,St> const& other);
            void _swap(tensor<Type,Order> && other);
            void _copySizesAndSwap(tensor<Type,Order> && other);

            template<int n>
            typename std::enable_if<n<Order-1, void>::type
            _initializeAndDim( std::vector<Type>& data, NestedInitializerListsT<Type,Order-n> init_list );

            template<int n>
            typename std::enable_if<n==Order-1, void>::type
            _initializeAndDim( std::vector<Type>& data, NestedInitializerListsT<Type,1> init_list );

            template<class S, int Order2, bool Storage, bool Contiguous>
            friend class tensor;

        public:

            template <class... Indices, typename std::enable_if<areIntsOrRIs<Indices...>::value>::type* = nullptr>
            auto operator() ( const Indices... indices ) ->  decltype(tensor<Type,Order,false,false>::template _getSubspace<areInts<Indices...>::value,Indices...>::function(*this,indices...))
            {
                return tensor<Type,Order,false,false>::template _getSubspace<areInts<Indices...>::value,Indices...>::function(*this,indices...);
            }

#if __cplusplus >= 201402L

            template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type* = nullptr>
            auto operator() ( const Indices... indices ) & -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type,tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type, (_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value==0) or (remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0), (_nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value==0) or (remove_duplicates_tuple<remove_t<int,Indices...>>::shared_first.size()!=0), remove_duplicates_tuple<remove_t<int,Indices...>>::free.size()!=Order>>::type;

            template <class... Indices, typename std::enable_if<areIntsOrIndices<Indices...>::value and _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value != Order>::type* = nullptr>
            auto operator() ( const Indices... indices ) && -> typename std::conditional< remove_duplicates_tuple<remove_t<int,Indices...>>::type::empty, Type,tensor_indices<Type, typename remove_duplicates_tuple<remove_t<int,Indices...>>::type,true, true, true>>::type;

            template<class U>
            tensor(tensor_indices<Type,U,true,true,true> && other) : tensor{std::move(other._tensor)} { }
            template<class... U>
            tensor<Type,Order>& operator =(tensor_indices<Type,typelist<U...>,true,true,true>&& other){*this=std::move(other._tensor); return *this;}

            template<class S, class U, bool St, bool Co, bool Ow>
            tensor(tensor_indices<S,U,St,Co,Ow> const& other) : tensor{other._tensor} {}
            template<class S, bool St, bool Co, bool Ow, class... U>
            tensor<Type,Order>& operator =(tensor_indices<S,typelist<U...>,St,Co,Ow> const& other){*this=other._tensor; return *this;}
#endif
    };

    template <class type>
    using matrix = tensor<type,2>;

    template <class type>
    using vector = tensor<type,1>;

    template <class type, int order>
    using wrapper = tensor<type,order,false,true>;

    template <class type, int order>
    using unsorted_wrapper = tensor<type,order,false,false>;

}

#endif //ttl_tensor_h
