/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_tensoroperations_h
#define ttl_tensoroperations_h

namespace ttl
{
    class TensorOperation
    {
        private:

            template < class T, class S, class U, int Order1, int Order2, int contOrder, int n, int phase >
            struct _doProduct;

            template < class T, class S, class U, int Order1, int Order2, int contOrder, int n, int phase >
            struct _doProductScalar;

            template<class T, class S, int Order1, int Order2, int contOrder, bool isScalar>
            struct _productLastFirst;

            template< class T, class S, int Order1, int Order2, int contOrder >
            static auto _product(tensor<T,Order1,false,false> const& tensor1, tensor<S,Order2,false,false> const& tensor2, int const (&contIndices)[contOrder][2]) ->  decltype(_productLastFirst<T,S,Order1,Order2,contOrder,Order1+Order2-2*contOrder==0>::function(tensor1, tensor2));

            template < class T, class U, int Order, int contOrder, int n, int phase >
            struct _doContract;

            template < class T, class U, int Order, int contOrder, int n, int phase >
            struct _doContractScalar;

            template<class T, int Order, int contOrder, bool isScalar>
            struct _contractLastFirst;

            template< class T, int Order, int contOrder >
            static auto _contract(tensor<T,Order,false,false> const&  input, int const (&contIndices)[contOrder][2]) ->  decltype(TensorOperation::_contractLastFirst<T,Order,contOrder,Order-2*contOrder==0>::function(input));

            template < class T, class S, class U, int Order, int OpType, int n, int Phase>
            struct _doElementWiseOperationScalar;

            template < class T, class U, int Order, int OpType, int n, int Phase>
            struct _doElementWiseOperationScalar1;

            template < class T, class S, class U, int Order, int OpType, int n, int Phase>
            struct _doElementWiseOperationTensor;

            template < class T, class U, int Order, int OpType, int n, int Phase>
            struct _doElementWiseOperationTensor1;

            template<class T, int Order, bool St, bool Co>
            friend class tensor;

            template<class S, int O, bool St, bool Co, class... Indices>
            friend class tensorindices;

            friend class TensorIndicesOperation;

            template< class T, class S, int Order1, int Order2, int contOrder >
            friend auto product(tensor<T,Order1,false,false> const& tensor1, tensor<S,Order2,false,false> const& tensor2, int const (&contIndices)[contOrder][2]) ->  decltype(TensorOperation::_productLastFirst<T,S,Order1,Order2,contOrder,Order1+Order2-2*contOrder==0>::function(tensor1,tensor2));

            template <class T, class S, int Order>
            friend tensor<typename std::common_type<T,S>::type,Order> eproduct(tensor<T,Order,false,false> const& tensor1, tensor<S,Order,false,false> const& tensor2 );

            template< class T, int Order, int contOrder >
            friend auto contract(tensor<T,Order,false,false> const& input, int const (&contIndices)[contOrder][2]) ->  decltype(TensorOperation::_contractLastFirst<T,Order,contOrder,Order-2*contOrder==0>::function(input));

            template <class T, class S, int Order1, int Order2>
            friend auto operator*(tensor<T,Order1,false,false> const& tensor1, tensor<S,Order2,false,false> const& tensor2 ) -> decltype(_productLastFirst<T,S,Order1,Order2,1,Order1+Order2-2==0>::function(tensor1,tensor2));

            template <class T, int Order>
            friend auto trace(tensor<T,Order> const& input ) -> decltype(TensorOperation::_contractLastFirst<T,Order,1,Order-2==0>::function(input));

            template< class T, class S, int Order1, int Order2 >
            friend auto outer(tensor<T,Order1,false,false> const& tensor1, tensor<S,Order2,false,false> const& tensor2) ->  decltype(TensorOperation::_productLastFirst<T,S,Order1,Order2,0,false>::function(tensor1,tensor2));

            template <class T, class S, int Order>
            friend auto operator+(tensor<T,Order,false,false> const& tensor1, tensor<S,Order,false,false> const& tensor2 ) -> tensor<typename std::common_type<T,S>::type,Order>;

            template <class T, class S, int Order>
            friend auto operator-(tensor<T,Order,false,false> const& tensor1, tensor<S,Order,false,false> const& tensor2 ) -> tensor<typename std::common_type<T,S>::type,Order>;

            template <class T, class S, int Order, typename C>
            friend auto operator+(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;

            template <class T, class S, int Order, typename C>
            friend auto operator-(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;

            template <class T, class S, int Order, typename C>
            friend auto operator*(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;

            template <class T, class S, int Order, typename C>
            friend auto operator/(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;
    };

    template< class T, class S, int Order1, int Order2 >
    auto outer(tensor<T,Order1,false,false> const& tensor1, tensor<S,Order2,false,false> const& tensor2) ->  decltype(TensorOperation::_productLastFirst<T,S,Order1,Order2,0,false>::function(tensor1,tensor2))
    {
        return TensorOperation::_productLastFirst<T,S,Order1,Order2,0,false>::function(tensor1,tensor2);
    }

    template< class T, class S, int Order1, int Order2, int contOrder >
    auto product(tensor<T,Order1,false,false> const& tensor1, tensor<S,Order2,false,false> const& tensor2, int const (&contIndices)[contOrder][2]) ->  decltype(TensorOperation::_productLastFirst<T,S,Order1,Order2,contOrder,Order1+Order2-2*contOrder==0>::function(tensor1,tensor2))
    {
        return TensorOperation::_product(tensor1,tensor2,contIndices);
    }

    template< class T, int Order, int contOrder >
    auto contract(tensor<T,Order,false,false> const& input, int const (&contIndices)[contOrder][2]) ->  decltype(TensorOperation::_contractLastFirst<T,Order,contOrder,Order-2*contOrder==0>::function(input))
    {
        return TensorOperation::_contract(input,contIndices);
    }

    template <class T, class S, int Order1, int Order2>
    auto operator*(tensor<T,Order1,false,false> const& tensor1, tensor<S,Order2,false,false> const& tensor2 ) -> decltype(TensorOperation::_productLastFirst<T,S,Order1,Order2,1, Order1+Order2-2==0>::function(tensor1,tensor2))
    {
        return TensorOperation::_productLastFirst<T,S,Order1,Order2,1, Order1+Order2-2==0>::function(tensor1,tensor2);
    }

    template <class T, int Order>
    auto trace(tensor<T,Order> const& input ) -> decltype(TensorOperation::_contractLastFirst<T,Order,1,Order-2==0>::function(input))
    {
        return TensorOperation::_contractLastFirst<T,Order,1,Order-2==0>::function(input);
    }

    //TODO: this could be improved by generating functions for rvalues and tensor<...,true,true>
    template <class T, class S, int Order>
    tensor<typename std::common_type<T,S>::type,Order> eproduct(tensor<T,Order,false,false> const& tensor1, tensor<S,Order,false,false> const& tensor2 );
}

#endif //ttl_tensoroperations_h
