/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_auxiliary_h
#define ttl_auxiliary_h

namespace ttl
{
    template<typename... Conds>
    struct _and : std::true_type {};

    template<typename Cond, typename... Conds>
    struct _and<Cond, Conds...> : std::conditional<Cond::value, _and<Conds...>,std::false_type>::type {};

    template<typename... Conds>
    struct _or : std::false_type {};

    template<typename Cond, typename... Conds>
    struct _or<Cond, Conds...> : std::conditional<Cond::value, std::true_type, _or<Conds...>>::type {};

    template<typename... Ts>
    using areInts = _and<std::is_same<int,Ts>...>;

    template <class, template <bool> class>
    struct is_instance_ : public std::false_type {};

    template <wchar_t T, template <bool> class U>
    struct is_instance_<U<T>, U> : public std::true_type {};

    template <class, template <bool> class>
    struct is_instance__ : public std::false_type {};

    template <wchar_t T, template <bool> class U>
    struct is_instance__<U<T>&, U> : public std::true_type {};

    template <class, template <wchar_t> class>
    struct is_instance : public std::false_type {};

    template <wchar_t T, template <wchar_t> class U>
    struct is_instance<U<T>, U> : public std::true_type {};

    template<typename... Ts>
    using areRIs = _and<_or<is_instance_<Ts,runningIndex>,is_instance__<Ts,runningIndex>>...>;

    template<typename... Ts>
    using areIntsOrRIs = _and<_or<_or<std::is_same<runningIndex<false>,Ts>,std::is_same<runningIndex<true>,Ts>>,std::is_same<int,Ts>>...>;

    template<bool final, typename S, typename... Ts>
    struct _nRunningIndices;

    template<typename S>
    struct _nRunningIndices<true,S>
    {
        static constexpr int value = _or<std::is_same<runningIndex<false>,S>,std::is_same<runningIndex<true>,S>>::value ? 1 : 0;
    };

    template<typename S, typename... Ts>
    struct _nRunningIndices<false,S,Ts...>
    {
        static constexpr int value = _or<std::is_same<runningIndex<false>,S>,std::is_same<runningIndex<true>,S>>::value ? (_nRunningIndices<sizeof...(Ts)==1,Ts...>::value + 1) : (_nRunningIndices<sizeof...(Ts)==1,Ts...>::value);
    };

    template<class T, std::size_t T_levels>
    struct NestedInitializerLists
    {
        using type = std::initializer_list<typename NestedInitializerLists<T, T_levels - 1>::type>;
    };

    template<class T>
    struct NestedInitializerLists<T, 0>
    {
        using type = T;
    };

    template<class T, std::size_t T_levels>
    using NestedInitializerListsT = typename NestedInitializerLists<T, T_levels>::type;

    template<bool final, typename Ref, typename S, typename... Ts>
    struct _nElementsOfClass;

    template<typename Ref, typename S>
    struct _nElementsOfClass<true,Ref,S>
    {
        static constexpr int value = std::is_same<Ref,S>::value ? 1 : 0;
    };

    template<typename Ref, typename S, typename... Ts>
    struct _nElementsOfClass<false,Ref,S,Ts...>
    {
        static constexpr int value = std::is_same<Ref,S>::value ? (_nElementsOfClass<sizeof...(Ts)==1,Ref,Ts...>::value + 1) : (_nElementsOfClass<sizeof...(Ts)==1,Ref,Ts...>::value);
    };

    template<bool add>
    struct addone;

    template<>
    struct addone<true>
    {
        static void function(int & i){i++;}
    };
    template<>
    struct addone<false>
    {
        static void function(int &){}
    };

    template <size_t N, class T>
    std::array<T,N> make_array(const T &v) {
        std::array<T,N> ret;
        ret.fill(v);
        return ret;
    }

    template<int Order>
    std::array<int,Order> ordIdx()
    {
        std::array<int,Order> arr{0}; 
        std::iota(arr.begin(),arr.end(),0);
        return arr;
    }

    template <class Type, int Order, bool Storage=true, bool Contiguous=true>
    class tensor;
    template <class A>
    struct is_tensor : std::false_type{};
    template <class T,int O, bool S, bool St>
    struct is_tensor<tensor<T,O,S,St>> : std::true_type{};

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator+(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>; 

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator-(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;
    
    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator*(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator/(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator+(S const scalar, tensor<T,Order,false,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator-(S const scalar, tensor<T,Order,false,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class S, class U, int Order, typename C = typename std::enable_if<not is_tensor<U>::value, void>::type>
    auto operator*(U const scalar,tensor<S,Order,false,false> const& input) -> tensor<typename std::common_type<S,U>::type,Order>;

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator+(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>; 

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator-(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;
    
    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator*(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator/(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator+(S const scalar, tensor<T,Order,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class T, class S, int Order, typename C = typename std::enable_if<not is_tensor<S>::value, void>::type>
    auto operator-(S const scalar, tensor<T,Order,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>;

    template <class S, class U, int Order, typename C = typename std::enable_if<not is_tensor<U>::value, void>::type>
    auto operator*(U const scalar,tensor<S,Order,false> const& input) -> tensor<typename std::common_type<S,U>::type,Order>;

#if __cplusplus >= 201402L

    template<wchar_t c>
    struct idx
    {
        static constexpr wchar_t value = c;
    };

    template < typename... Types >
    struct typelist
    {
        static constexpr int size = sizeof...(Types);
        static constexpr int empty = sizeof...(Types)==0;
    };


    template < int... Ints >
    struct intlist
    {
        static constexpr int size = sizeof...(Ints);
        static constexpr int empty = sizeof...(Ints)==0;
    };
        
    template < typename TElement, typename TList >
    struct is_in
    {
        static constexpr bool value = false;
        static constexpr int  position = 0;
    };

    template < typename TElement, typename... TTail >
    struct is_in < TElement, typelist < TElement, TTail... > >
    {
        
        static constexpr bool value = true;
        static constexpr int  position = 0;
    };

    template < typename TElement, typename THead, typename... TTail >
    struct is_in < TElement, typelist < THead, TTail... > >
    {
        static constexpr bool value    = is_in< TElement, typelist < TTail... > >::value;
        static constexpr int  position = is_in <TElement, typelist < TTail... >>::position+1;
    };

    template < int TElement, typename TList >
    struct isint_in
    {
        static constexpr bool value = false;
        static constexpr int  position = 0;
    };

    template < int TElement, int... TTail >
    struct isint_in < TElement, intlist < TElement, TTail... > >
    {
        
        static constexpr bool value = true;
        static constexpr int  position = 0;
    };
        

    template < int TElement, int THead, int... TTail >
    struct isint_in < TElement, intlist < THead, TTail... > >
    {
        static constexpr bool value    = isint_in< TElement, intlist < TTail... > >::value;
        static constexpr int  position = isint_in <TElement, intlist < TTail... >>::position+1;
    };

    template<int N, int i,typename TList1, typename TList2>
    struct array_integers_notinlist;

    template<int N, int i, int... Ints1, int... Ints2>
    struct array_integers_notinlist<N,i, intlist<Ints1...>, intlist<Ints2...>>
    {
        static constexpr auto array = array_integers_notinlist<N,i+1,typename std::conditional<isint_in<i,intlist<Ints2...>>::value,intlist<Ints1...>,intlist<Ints1...,i>>::type,intlist<Ints2...>>::array;

    };

    template<int N, int... Ints1, int... Ints2>
    struct array_integers_notinlist<N,N, intlist<Ints1...>, intlist<Ints2...>>
    {
        static constexpr std::array<int,sizeof...(Ints1)> array = {Ints1...};
    };

    template<typename TList1, typename T, typename TList2, typename intList1, typename intList2, int N, bool isTinList1, bool isTinList1_2, typename... TList1_2>
    struct do_remove_duplicates;

    template<typename U, typename T, typename... List1, int... Ints1, int... Ints2, int N, typename... List2, typename... List1_2>
    struct do_remove_duplicates<typelist<U,List1...>, T, typelist<List2...>, intlist<Ints1...>, intlist<Ints2...>, N, true, false, List1_2...>
    {
        typedef do_remove_duplicates<typelist<List1...>,U,typelist<List2...>,intlist<Ints1...>, intlist<Ints2...>, N, is_in<U,typelist<List1...>>::value,is_in<U,typelist<List1_2...,T>>::value, List1_2..., T> _next_;
        typedef typename _next_::type type;
        static constexpr auto shared_first = _next_::shared_first;
        static constexpr auto shared_second = _next_::shared_second;
        static constexpr auto free = _next_::free;
    };

    template<typename U, typename T, typename... List1, int... Ints1, int... Ints2, int N, typename... List2, typename... List1_2>
    struct do_remove_duplicates<typelist<U,List1...>, T, typelist<List2...>, intlist<Ints1...>, intlist<Ints2...>, N, false, true, List1_2...>
    {
        typedef do_remove_duplicates<typelist<List1...>,U,typelist<List2...>,intlist<Ints1...,is_in<T,typelist<List1_2...>>::position>,intlist<Ints2...,sizeof...(List1_2)>,N,is_in<U,typelist<List1...>>::value, is_in<U,typelist<List1_2...,T>>::value, List1_2..., T> _next_;
        
        typedef typename _next_::type type;
        static constexpr auto shared_first = _next_::shared_first;
        static constexpr auto shared_second = _next_::shared_second;
        static constexpr auto free = _next_::free;
    };

    template<typename U, typename T, typename... List1, int... Ints1,  int... Ints2, int N, typename... List2, typename... List1_2>
    struct do_remove_duplicates<typelist<U,List1...>, T, typelist<List2...>, intlist<Ints1...>, intlist<Ints2...>, N, false, false, List1_2...>
    {
        typedef do_remove_duplicates<typelist<List1...>,U,typelist<List2...,T>,intlist<Ints1...>,intlist<Ints2...>,N,is_in<U,typelist<List1...>>::value, is_in<U,typelist<List1_2...,T>>::value, List1_2..., T> _next_;
        typedef typename _next_::type type;
        static constexpr auto shared_first = _next_::shared_first;
        static constexpr auto shared_second = _next_::shared_second;
        static constexpr auto free = _next_::free;
    };

    template<typename T, typename... List2, int... Ints1, int... Ints2, int N, typename... List1_2>
    struct do_remove_duplicates<typelist<>, T, typelist<List2...>, intlist<Ints1...>, intlist<Ints2...>, N, false, true, List1_2...>
    {
        typedef typelist<List2...> type;
        static constexpr std::array<int,sizeof...(Ints1)+1> shared_first = {Ints1...,is_in<T,typelist<List1_2...>>::position};
        static constexpr std::array<int,sizeof...(Ints2)+1> shared_second = {Ints2...,sizeof...(List1_2)};
        static constexpr auto free = array_integers_notinlist<N,0,intlist<>,intlist<Ints1...,is_in<T,typelist<List1_2...>>::position,Ints2...,sizeof...(List1_2)>>::array;
    };

    template<typename T, typename... List2, int... Ints1, int... Ints2, int N, typename... List1_2>
    struct do_remove_duplicates<typelist<>, T, typelist<List2...>, intlist<Ints1...>, intlist<Ints2...>, N, false, false, List1_2...>
    {
        typedef typelist<List2...,T> type;
        static constexpr std::array<int,sizeof...(Ints1)> shared_first = {Ints1...};
        static constexpr std::array<int,sizeof...(Ints2)> shared_second = {Ints2...};
        static constexpr auto free = array_integers_notinlist<N,0,intlist<>,intlist<Ints1...,Ints2...>>::array;
    };

    template<typename T, typename... TList>
    struct remove_duplicates
    {
        typedef do_remove_duplicates<typelist<TList...>, T, typelist<>, intlist<>, intlist<>, sizeof...(TList)+1, is_in<T,typelist<TList...>>::value, false> _next_;
        typedef typename _next_::type type;
        static constexpr decltype(_next_::shared_first) shared_first = _next_::shared_first;
        static constexpr decltype(_next_::shared_second) shared_second = _next_::shared_second;
        static constexpr decltype(_next_::free) free = _next_::free;
    };

    template<typename T, typename... TList>
    constexpr decltype(remove_duplicates<T,TList...>::_next_::shared_first) remove_duplicates<T,TList...>::shared_first;
    template<typename T, typename... TList>
    constexpr decltype(remove_duplicates<T,TList...>::_next_::shared_second) remove_duplicates<T,TList...>::shared_second;
    template<typename T, typename... TList>
    constexpr decltype(remove_duplicates<T,TList...>::_next_::free) remove_duplicates<T,TList...>::free;

    template<typename...Ts>
    using tuple_cat_t = decltype(std::tuple_cat(std::declval<Ts>()...));

    template<typename T, typename...Ts>
    using remove_t = tuple_cat_t<typename std::conditional<std::is_same<T, Ts>::value,std::tuple<>,
    std::tuple<Ts>>::type... >;

    template<typename T>
    struct remove_duplicates_tuple;

    template<typename T, typename... TList>
    struct remove_duplicates_tuple<std::tuple<T,TList...>>
    {
        typedef do_remove_duplicates<typelist<TList...>, T, typelist<>, intlist<>, intlist<>, sizeof...(TList)+1, is_in<T,typelist<TList...>>::value, false> _next_;
        typedef typename _next_::type type;
        static constexpr decltype(_next_::shared_first) shared_first = _next_::shared_first;
        static constexpr decltype(_next_::shared_second) shared_second = _next_::shared_second;
        static constexpr decltype(_next_::free) free = _next_::free;
    };

    template<typename T, typename... TList>
    constexpr decltype(remove_duplicates_tuple<std::tuple<T,TList...>>::_next_::shared_first) remove_duplicates_tuple<std::tuple<T,TList...>>::shared_first;
    template<typename T, typename... TList>
    constexpr decltype(remove_duplicates_tuple<std::tuple<T,TList...>>::_next_::shared_second) remove_duplicates_tuple<std::tuple<T,TList...>>::shared_second;
    template<typename T, typename... TList>
    constexpr decltype(remove_duplicates_tuple<std::tuple<T,TList...>>::_next_::free) remove_duplicates_tuple<std::tuple<T,TList...>>::free;

    template<unsigned long... Is> struct seq{};
    template<unsigned long N, unsigned long... Is>
    struct gen_seq : gen_seq<N-1, N-1, Is...>{};
    template<unsigned long... Is>
    struct gen_seq<0, Is...> : seq<Is...>{};

    template<unsigned long N1, unsigned long... I1, unsigned long N2, unsigned long... I2>
    // Expansion pack
    constexpr inline std::array<int, N1+N2> concat(const std::array<int, N1>& a1, const std::array<int, N2>& a2, seq<I1...>, seq<I2...>)
    {
    return { a1[I1]..., a2[I2]... };
    }

    template<unsigned long N1, unsigned long N2>
    // Initializer for the recursion
    constexpr inline std::array<int, N1+N2> concat(const std::array<int, N1>& a1, const std::array<int, N2>& a2)
    {
    return concat(a1, a2, gen_seq<N1>{}, gen_seq<N2>{});
    }

    template<unsigned long N, unsigned long M, unsigned long... I>
    constexpr inline std::array<int, M> firsthalf(const std::array<int, N>& a, seq<I...>)
    {
        return {a[I]...};
    }

    template<unsigned long N, unsigned long M>
    // Initializer for the recursion
    constexpr inline std::array<int, M> firsthalf(const std::array<int, N>& a)
    {
        return firsthalf<N,M>(a,gen_seq<M>{});
    }

    template<unsigned long N, int M, unsigned long... I>
    constexpr inline std::array<int, N-M> secondhalf(const std::array<int, N>& a, seq<I...>)
    {
        return {a[I+M]...};
    }

    template<unsigned long N, int M>
    // Initializer for the recursion
    constexpr inline std::array<int, N-M> secondhalf(const std::array<int, N>& a)
    {
        return secondhalf<N,M>(a,gen_seq<N-M>{});
    }

    template<unsigned N, int M, unsigned long... I>
    constexpr inline std::array<int, N> substract(const std::array<int, N>& a, seq<I...>)
    {
        return {-M+a[I]...};
    }

    template<unsigned N, int M>
    // Initializer for the recursion
    constexpr inline std::array<int, N> substract(const std::array<int, N>& a)
    {
        return substract<N,M>(a,gen_seq<N>{});
    }

    template<typename... Ts>
    using areIntsOrIndices = _and<_or<is_instance<Ts,idx>,std::is_same<int,Ts>>...>;

    template<typename... Ts>
    using areIndices = _and<is_instance<Ts,idx>...>;


    template<bool final, typename S, typename... Ts>
    struct _nIndices;

    template<typename S>
    struct _nIndices<true,S>
    {
        static constexpr int value = is_instance<S,idx>::value ? 1 : 0;
    };

    template<typename S, typename... Ts>
    struct _nIndices<false,S,Ts...>
    {
        static constexpr int value = is_instance<S,idx>::value ? (_nIndices<sizeof...(Ts)==1,Ts...>::value + 1) : (_nIndices<sizeof...(Ts)==1,Ts...>::value);
    };

    template<int Order>
    constexpr std::array<int,Order> revIdx()
    {
        std::array<int,Order> arr{0}; 
        std::iota(arr.rbegin(),arr.rend(),0);
        return arr;
    }
    
    template <typename T, std::size_t N>
    constexpr bool is_sorted(std::array<T, N> const& arr, std::size_t from) {
        return N - from == 0 or (arr[from - 1] <= arr[from] and is_sorted(arr, from + 1));
    }

    template <typename T, std::size_t N>
    constexpr bool is_sorted(std::array<T, N> const& arr) {
        return N == 0 or is_sorted(arr, 1);
    }

    template<class T, class U, bool St, bool Co, bool Ow>
    class tensor_indices;
    
    template <class A>
    struct is_tensor_indices : std::false_type{};

    template<class T, class U, bool St, bool Co, bool Ow>
    struct is_tensor_indices<tensor_indices<T,U,St,Co,Ow>> : std::true_type{};

    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C = typename std::enable_if<not is_tensor_indices<S>::value, void>::type>
    auto operator+(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C = typename std::enable_if<not is_tensor_indices<S>::value, void>::type>
    auto operator-(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C = typename std::enable_if<not is_tensor_indices<S>::value, void>::type>
    auto operator*(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C = typename std::enable_if<not is_tensor_indices<S>::value, void>::type>
    auto operator/(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C = typename std::enable_if<not is_tensor_indices<S>::value, void>::type>
    auto operator+(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C = typename std::enable_if<not is_tensor_indices<S>::value, void>::type>
    auto operator-(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
    template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C = typename std::enable_if<not is_tensor_indices<S>::value, void>::type>
    auto operator*(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;

#endif //__cplusplus >= 201402L
}

#endif //ttl_auxiliary_h
