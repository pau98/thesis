/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_tensor_impl_h
#define ttl_tensor_impl_h

#include <list>
#include <type_traits>
#include <cstring>

namespace ttl
{
    template <class Type, int Order>
    void tensor<Type,Order,false,true>::_calculateJumps()
    {
        __::_jumps[Order-1] = 1;
        for ( int i = Order-2; i >=0 ; i-- )
            __::_jumps[i] = __::_jumps[i+1] * __::_dims[i+1];
    }

    template <class Type, int Order>
    template <class... Dims>
    tensor<Type,Order,false,true>::tensor ( Type* pointer, const Dims... dims)
    {
        static_assert(sizeof...(Dims)==Order, "Number of dimensions do not match with tensor order");
        static_assert(areInts<Dims...>::value,"Non-integers passed as dimensions.");

        __::_dims = {dims...};
        _calculateJumps();
        _size = __::_jumps[0] * __::_dims[0];
        __::_data = pointer;
    }

    template <class Type, int Order>
    template <class... Dims>
    tensor<Type,Order,true,true>::tensor ( int dim1, const  Dims... dims )
    {        
        static_assert(sizeof...(Dims)==Order-1, "Number of dimensions do not match with tensor order");
        static_assert(areInts<Dims...>::value,"Non-integers passed as dimensions.");

        __::_dims = {dim1, dims...};
        _::_calculateJumps();
        _::_size = __::_jumps[0] * __::_dims[0];
        __::_data = new Type [__::_jumps[0]*__::_dims[0]];
    }


    template <class Type, int Order>
    void tensor<Type,Order,true>::clear()
    {
        if(__::_data != nullptr)
        {
            delete [] __::_data;
            __::_data = nullptr;
            _::_size = 0;
        }
    }

    template <class Type, int Order>
    tensor<Type,Order,false,false>& tensor<Type,Order,false,false>::operator=(tensor<Type,Order,false,false> const& other)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,Type,Order,4,0,nextPhase>(*this, other, 0, 0);

        return *this;
    }

    template <class Type, int Order>
    tensor<Type,Order,false,false>& tensor<Type,Order,false,false>::operator=(tensor<Type,Order,false,false> && other)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,Type,Order,4,0,nextPhase>(*this, other, 0, 0);

        return *this;
    }

    template <class Type, int Order>
    template<class S>
    tensor<Type,Order,false,false>& tensor<Type,Order,false,false>::operator=(tensor<S,Order,false,false> const& other)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,S,Order,4,0,nextPhase>(*this, other, 0, 0);

        return *this;
    }

    template <class Type, int Order>
    template<class S>
    void tensor<Type,Order>::resize(tensor<S,Order,false,false> const& other)
    {
        __::_dims = other._dims;
        _::_calculateJumps();
        int new_size = __::_dims[0] * __::_jumps[0];
        if(_::_size != new_size)
        {
            clear();
            _::_size = new_size;
            _::_data = new Type [_::_size];
        }
    }

    template <class Type, int Order>
    template<class S>
    void tensor<Type,Order>::resize(tensor<S,Order,false,true> const& other)
    {
        __::_dims = other._dims;
        __::_jumps = other._jumps;
        if(_::_size != other._size)
        {
            clear();
            _::_size = other._size;
            _::_data = new Type [_::_size];
        }
    }

    template <class Type, int Order>
    template<class S, bool St>
    void tensor<Type,Order>::_copy(tensor<S,Order,St> const& other)
    {
        std::copy( other._data , other._data + _::_size, _::_data );
    }

    template <class Type, int Order>
    template<class S>
    tensor<Type,Order>::tensor(tensor<S,Order,false,false> const& other)
    {
        resize(other);
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,S,Order,4,0,nextPhase>(*this, other, 0, 0);
    }

    template <class Type, int Order>
    template<class S>
    tensor<Type,Order,false>& tensor<Type,Order,false>::operator=(tensor<S,Order,false,false> const& other)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,S,Order,4,0,nextPhase>(*this, other, 0, 0);

        return *this;
    }

    template <class Type, int Order>
    void tensor<Type,Order>::_copySizesAndSwap(tensor<Type,Order> && other)
    {
        __::_dims = other._dims;
        __::_jumps = other._jumps;
        _::_size = other._size;
        std::swap(_::_data,other._data);
    }
    template <class Type, int Order>
    void tensor<Type,Order>::_swap(tensor<Type,Order> && other)
    {
        std::swap(_::_data,other._data);
    }

    template <class Type, int Order>
    template<class S, int n>
    struct tensor<Type,Order,false,false>::_print<S,n,true>
    {
        static void function( S const& t, std::ostream& out, std::string opening, std::string closing, std::string separator, int idx=0 )
        {

            out << opening;
            for ( int i = 0; i < t._dims[n]-1; i++ )
            {
                int idxI = idx + i*t._jumps[n];

                _print<S, n+1, (n+1 < Order-1) >::function(t,out,opening,closing,separator,idxI);
                out << separator;
            }

            int idxI = idx + (t._dims[n]-1)*t._jumps[n];

            _print<S,n+1,(n+1< Order-1)>::function(t,out,opening,closing,separator,idxI);

            idx += t._jumps[n];

            out << closing;

        }
    };

    template <class Type, int Order>
    template<class S, int n>
    struct tensor<Type,Order,false,false>::_print<S,n,false>
    {
        static void function( S const& t, std::ostream& out, std::string opening, std::string closing, std::string separator, int idx=0 )
        {

            out << opening;
            for ( int i = 0; i < t._dims[n]-1; i++ )
            {
                int idxI = idx + i*t._jumps[n];

                    out << t._data[idxI];
                out << separator;
            }

            int idxI = idx + (t._dims[n]-1)*t._jumps[n];

            out << t._data[idxI];

            idx += t._jumps[n];

            out << closing;

        }
    };

    template<class Type, int Order>
    template<class Idx>
    typename std::enable_if< std::is_same<int, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndex(Idx const& idx) const
    {
        return idx *_jumps[Order-1];
    }
    
    template<class Type, int Order>
    template <class Idx, class... Indices>
    typename std::enable_if< std::is_same<int, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndex(Idx const& idx, const Indices&... indices) const
    {
        constexpr int remaining = sizeof...(indices);
        return idx*_jumps[Order-remaining-1] + _getVecIndex(indices...);
    }


    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx>
    typename std::enable_if<std::is_same<int, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& , std::array<int,childOrder>& , Idx const& idx) const
    {
        return idx *_jumps[Order-1];
    }

    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx>
    typename std::enable_if< std::is_same<runningIndex<false>, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, Idx const& idx) const
    {
        childDims[i] = idx.size();
        childJumps[i] = _jumps[Order-1];
        return idx.first *_jumps[Order-1];
    }

    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx>
    typename std::enable_if< std::is_same<runningIndex<true>, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, Idx const&) const
    {
        childDims[i] = _dims[Order-1];
        childJumps[i] = _jumps[Order-1];
        return 0;
    }

#if __cplusplus >= 201402L
    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx>
    typename std::enable_if<is_instance<Idx,idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, Idx const&) const
    {
        childDims[i] = _dims[Order-1];
        childJumps[i] = _jumps[Order-1];
        return 0;
    }
#endif
    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx, class... Indices>
    typename std::enable_if< std::is_same<int, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, Idx const& idx, const Indices&... indices) const
    {
        constexpr int remaining = sizeof...(indices);
        return  idx *_jumps[Order-remaining-1] + _getVecIndexAndInitDim<i,childOrder,Indices...>(childDims, childJumps, indices...);
        return 0;
    }

    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx, class... Indices>
    typename std::enable_if< std::is_same<runningIndex<false>, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, Idx const& idx, const Indices&... indices) const
    {
        constexpr int remaining = sizeof...(indices);

        childDims[i] = idx.size();
        childJumps[i] = _jumps[Order-remaining-1];
        return idx.first *_jumps[Order-remaining-1] + _getVecIndexAndInitDim<i+1,childOrder,Indices...>(childDims, childJumps, indices...);
    }

    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx, class... Indices>
    typename std::enable_if< std::is_same<runningIndex<true>, Idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, Idx const&, const Indices&... indices) const
    {
        constexpr int remaining = sizeof...(indices);
        childDims[i] = _dims[Order-remaining-1];
        childJumps[i] = _jumps[Order-remaining-1];
        return _getVecIndexAndInitDim<i+1,childOrder,Indices...>(childDims, childJumps, indices...);
    }
#if __cplusplus >= 201402L
    template<class Type, int Order>
    template <int i, size_t childOrder,class Idx, class... Indices>
    typename std::enable_if<is_instance<Idx,idx>::value, int>::type
    tensor<Type,Order,false,false>::_getVecIndexAndInitDim(std::array<int,childOrder>& childDims, std::array<int,childOrder>& childJumps, Idx const &, const Indices&... indices) const
    {
        constexpr int remaining = sizeof...(indices);

        childDims[i] = _dims[Order-remaining-1];
        childJumps[i] = _jumps[Order-remaining-1];

        return _getVecIndexAndInitDim<i+1,childOrder,Indices...>(childDims, childJumps, indices...);
    }
#endif

    template <class Type, int Order>
    template <typename... Indices>
    Type& tensor<Type,Order,false,false>::_getSubspace<true,Indices...>::function(const tensor<Type,Order,false,false>& thetensor, const Indices&... indices)
    {
        static_assert(sizeof...(Indices)==Order, "Number of dimensions do not match with tensor order");
        static_assert(areInts<Indices...>::value,"Non-integers passed as indices.");
        return thetensor._data[thetensor._getVecIndex(indices...)];
    }

#if __cplusplus >= 201402L
    template <class Type, int Order>
    template <typename... Indices>
    auto tensor<Type,Order,false,false>::_getSubspace<false,Indices...>::function(const tensor<Type,Order,false,false>& thetensor, const Indices&... indices) -> tensor<Type,_nRunningIndices<sizeof...(Indices)==1,Indices...>::value+_nIndices<sizeof...(Indices)==1,Indices...>::value,false,false>
    {
        constexpr int nInts = _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value;
        constexpr int nRunI = _nRunningIndices<sizeof...(Indices)==1,Indices...>::value;
        constexpr int nI = _nIndices<sizeof...(Indices)==1,Indices...>::value;
        static_assert(sizeof...(Indices)==Order, "Number of dimensions do not match with tensor order");
        static_assert(nInts+nRunI+nI==Order, "Unrecognized symbol. Indices should be an integer or runningIndex (e.g. all, range(i,j))");

        tensor<Type,nRunI+nI,false,false> output;

        output._data = &thetensor._data[thetensor._getVecIndexAndInitDim<0,nRunI+nI,Indices...>(output._dims, output._jumps, indices...)];

        return output;
    }
#else
    template <class Type, int Order>
    template <typename... Indices>
    auto tensor<Type,Order,false,false>::_getSubspace<false,Indices...>::function(const tensor<Type,Order,false,false>& thetensor, const Indices&... indices) -> tensor<Type,_nRunningIndices<sizeof...(Indices)==1,Indices...>::value,false,false>
    {
        constexpr int nInts = _nElementsOfClass<sizeof...(Indices)==1,int,Indices...>::value;
        constexpr int nRunI = _nRunningIndices<sizeof...(Indices)==1,Indices...>::value;
        static_assert(sizeof...(Indices)==Order, "Number of dimensions do not match with tensor order");
        static_assert(nInts+nRunI==Order, "Unrecognized symbol. Indices should be an integer or runningIndex (e.g. all, range(i,j))");

        tensor<Type,nRunI,false,false> output;
        output._data = &thetensor._data[thetensor._getVecIndexAndInitDim<0,nRunI,Indices...>(output._dims, output._jumps, indices...)];

        return output;
    }
#endif

    template<class Type, int Order>
    tensor<Type,Order,false,false> tensor<Type,Order,false,false>::transpose(std::array<int,Order> const& indices) const
    {
        tensor<Type,Order,false,false> newTens;

        for ( int i = 0; i < Order ; i++ )
        {
            int j=indices[i];
            newTens._dims[i] = _dims[j];
            newTens._jumps[i] = _jumps[j];
        }

        newTens._data = _data;

        return newTens;
    }

    template<class Type, int Order>
    tensor<Type,Order,false,false> tensor<Type,Order,false,false>::T() const
    {
        tensor<Type,Order,false,false> newTens;
        std::copy(_dims.begin()+1,_dims.end()-1,newTens._dims.begin()+1);
        newTens._dims[0]  = _dims[Order-1];
        newTens._dims[Order-1]  = _dims[0];
        std::copy(_jumps.begin()+1,_jumps.end()-1,newTens._jumps.begin()+1);
        newTens._jumps[0] = _jumps[Order-1];
        newTens._jumps[Order-1] = _jumps[0];
            
        newTens._data = _data;

        return newTens;
    }

    template<class Type, int Order>
    template<int n>
    typename std::enable_if<n==Order-1, void>::type
    tensor<Type,Order,false,false>::_initialize( int vidx,  NestedInitializerListsT<Type,1> init_list )
    {
        auto it = init_list.begin();
        for ( int i = 0; i < _dims[n]; i++)
        {
            int vidxI = vidx + i * _jumps[n];

            _data[vidxI] = *it;
            it++;
        }
    }

    template<class Type, int Order>
    template<int n>
    typename std::enable_if<n<Order-1, void>::type
    tensor<Type,Order,false,false>::_initialize( int vidx, NestedInitializerListsT<Type,Order-n> init_list )
    {
        auto it = init_list.begin();
        for ( int i = 0; i < _dims[n]; i++)
        {
            int vidxI = vidx + i * _jumps[n];
            _initialize<n+1>(vidxI,*it);

            it++;
        }
    }

    template<class Type, int Order>
    void tensor<Type,Order,false,false>::operator=(NestedInitializerListsT<Type,Order> init_list )
    {
        _initialize<0>(0,init_list);
    }

    template<class Type, int Order>
    template<int n>
    typename std::enable_if<n==Order-1, void>::type
    tensor<Type,Order>::_initializeAndDim( std::vector<Type>& data,  NestedInitializerListsT<Type,1> init_list )
    {
        __::_dims[n] = init_list.size();

        for ( auto& it : init_list)
            data.push_back(it);
    }


    template<class Type, int Order>
    template<int n>
    typename std::enable_if<n<Order-1, void>::type
    tensor<Type,Order>::_initializeAndDim( std::vector<Type>& data, NestedInitializerListsT<Type,Order-n> init_list )

    {
        __::_dims[n] = init_list.size();
        for ( auto& it : init_list)
            _initializeAndDim<n+1>(data,it);
    }

    template<class Type, int Order>
    tensor<Type,Order>::tensor(NestedInitializerListsT<Type,Order> init_list)
    {
        std::vector<Type> data{};
        _initializeAndDim<0>(data,init_list);
        _::_calculateJumps();

        _::_size = __::_jumps[0] * __::_dims[0];
        __::_data = new Type [_::_size];

        std::memcpy(__::_data,data.data(), _::_size * sizeof(Type));
    }

    static tensor<double,3> antisym3D={{{ 0, 0, 0},
                                        { 0, 0, 1},
                                        { 0,-1, 0}},
                                       {{ 0, 0,-1},
                                        { 0, 0, 0},
                                        { 1, 0, 0}},
                                       {{ 0, 1, 0},
                                        {-1, 0, 0},
                                        { 0, 0, 0}}};
    static tensor<double,2> Identity2={{ 1, 0},
                                       { 0, 1}};
    static tensor<double,2> Identity3={{ 1, 0, 0},
                                       { 0, 1, 0},
                                       { 0, 0, 1}};

    class Identity : public tensor<double,2>
    {
        using __= tensor<double,2,false,false> ;
        using _= tensor<double,2,false> ;

        public:
            Identity(int dim)
            {
                __::_dims[0]  = dim;
                __::_dims[1]  = dim;
                __::_jumps[0] = dim;
                __::_jumps[1] = 1;
                _::_size     = dim*dim;
                __::_data = new double [dim*dim];

                for(int i = 0; i < dim*dim; i++)
                    __::_data[i] = 0.0;

                for(int i = 0; i < dim; i++)
                    __::_data[i*dim+i] = 1.0;
            }
            ~Identity()
            {
                tensor<double,2>::clear();
            }
    };
}

#endif //ttl_tensor_impl_h
