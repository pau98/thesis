/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ttl_tensoroperations_impl_h
#define ttl_tensoroperations_impl_h

#include <list>

namespace ttl
{
    //First phase, free indices in tensor1
    template < class T, class S, class U, int Order1, int Order2, int contOrder, int n >
    struct TensorOperation::_doProduct<T,S,U,Order1,Order2,contOrder,n,0>
    {

        static constexpr int nextPhase =  (n+1 < Order1-contOrder) ? 0 : ((n+1 < Order1+Order2-2*contOrder) ? 1 : ((n+2 < Order1+Order2-contOrder) ? 2 : (contOrder>0) ? 3: 4));
        _doProduct(tensor<U,Order1+Order2-2*contOrder>& result, tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2, int idx1, int idx2, int& idxr )
        {
            const int jump1 = tensor1._jumps[n];
            for(int max = result._dims[n]; max; max--)
            {
                _doProduct<T,S,U,Order1,Order2,contOrder,n+1,nextPhase>(result,tensor1, tensor2, idx1, idx2, idxr);
                addone<(nextPhase > 1)>::function(idxr);
                idx1 += jump1;
           }
        }
    };

    //Second phase, free indices in tensor2
    template < class T, class S, class U, int Order1, int Order2, int contOrder, int n >
    struct TensorOperation::_doProduct<T,S,U,Order1,Order2,contOrder,n,1>
    {
        static constexpr int nextPhase =  (n+1 < Order1+Order2-2*contOrder) ? 1 : ((n+2 < Order1+Order2-contOrder) ? 2 : (contOrder>0) ? 3: 4);

        _doProduct(tensor<U,Order1+Order2-2*contOrder>& result, tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2, int idx1, int idx2, int& idxr )
        {
            const int jump2 = tensor2._jumps[2*contOrder-Order1+n];
            for(int max = result._dims[n]; max; max--)
            {
                _doProduct<T,S,U,Order1,Order2,contOrder,n+1,nextPhase>(result,tensor1,tensor2, idx1, idx2, idxr);
                addone<(nextPhase > 1)>::function(idxr);
                idx2 += jump2;
            }
        }
    };

    //Third phase, sum paired indices
    template < class T, class S, class U, int Order1, int Order2, int contOrder, int n >
    struct TensorOperation::_doProduct<T,S,U,Order1,Order2,contOrder,n,2>
    {
        static constexpr int nextPhase =  (n+2 < Order1+Order2-contOrder) ? 2 : (contOrder>0) ? 3: 4;

        _doProduct(tensor<U,Order1+Order2-2*contOrder>& result, tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2, int idx1, int idx2, int idxr )
        {
            const int jump1 = tensor1._jumps[n-Order2+contOrder];
            const int jump2 = tensor2._jumps[n-Order1-Order2+2*contOrder];
            for(int max = tensor1._dims[n-Order2+contOrder]; max; max--)
            {

                _doProduct<T,S,U,Order1,Order2,contOrder,n+1,nextPhase>(result,tensor1, tensor2, idx1, idx2, idxr);
                idx1 += jump1;
                idx2 += jump2;
            }
        }
    };


    //Third phase, sum paired indices
    template < class T, class S, class U, int Order1, int Order2, int contOrder, int n >
    struct TensorOperation::_doProduct<T,S,U,Order1,Order2,contOrder,n,3>
    {
        _doProduct(tensor<U,Order1+Order2-2*contOrder>& result, tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false>const&  tensor2, int idx1, int idx2, int idxr )
        {
            U& sum{result._data[idxr]};
            const int jump1 = tensor1._jumps[Order1-1];
            const int jump2 = tensor2._jumps[contOrder-1];
            for(int max = tensor1._dims[Order1-1]; max; max--)
            {
                sum += tensor1._data[idx1] * tensor2._data[idx2];
                idx1 += jump1;
                idx2 += jump2;
            }
        }
    };

    //Third phase, for outer product (no sum!)
    template < class T, class S, class U, int Order1, int Order2, int contOrder, int n >
    struct TensorOperation::_doProduct<T,S,U,Order1,Order2,contOrder,n,4>
    {
        _doProduct(tensor<U,Order1+Order2-2*contOrder>& result, tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false>const&  tensor2, int idx1, int idx2, int idxr )
        {
            result._data[idxr] = tensor1._data[idx1] * tensor2._data[idx2];
        }
    };

    template < class T, class S, class U, int Order1, int Order2, int contOrder, int n >
    struct TensorOperation::_doProductScalar<T,S,U,Order1,Order2,contOrder,n,0>
    {
        static constexpr int nextPhase =  (n+2 < Order1+Order2-contOrder) ? 0 : 1;

        _doProductScalar(U& result, tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2, int idx1, int idx2 )
        {
            const int jump1 = tensor1._jumps[n-Order2+contOrder];
            const int jump2 = tensor2._jumps[n-Order1-Order2+2*contOrder];
            for(int max = tensor1._dims[n-Order2+contOrder]; max; max--)
            {
                _doProductScalar<T,S,U,Order1,Order2,contOrder,n+1,nextPhase>(result,tensor1,tensor2, idx1, idx2);
                idx1 += jump1;
                idx2 += jump2;
            }
        }
    };


    template < class T, class S, class U, int Order1, int Order2, int contOrder, int n >
    struct TensorOperation::_doProductScalar<T,S,U,Order1,Order2,contOrder,n,1>
    {
        _doProductScalar(U& result, tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2, int idx1, int idx2 )
        {
            const int jump1 = tensor1._jumps[Order1-1];
            const int jump2 = tensor2._jumps[contOrder-1];
            for(int max = tensor1._dims[Order1-1]; max; max--)
            {
                result += tensor1._data[idx1] * tensor2._data[idx2];
                idx1 += jump1;
                idx2 += jump2;
            }
        }
    };

    template<class T, class S, int Order1, int Order2, int contOrder>
    struct TensorOperation::_productLastFirst<T,S,Order1,Order2,contOrder,false>
    {
        static auto function(tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2 ) -> tensor<typename std::common_type<T,S>::type,Order1+Order2-2*contOrder>
        {
            tensor<typename std::common_type<T,S>::type,Order1+Order2-2*contOrder> result;

            std::copy(tensor1._dims.begin(), tensor1._dims.begin()+Order1-contOrder, result._dims.begin());
            std::copy(tensor2._dims.begin()+contOrder, tensor2._dims.begin()+Order2, result._dims.begin()+Order1-contOrder);

            result._calculateJumps();
            result._size = result._jumps[0]*result._dims[0];
            result._data = new typename std::common_type<T,S>::type [result._size]();

            constexpr int iniPhase = (0 < Order1-contOrder) ? 0 : ((0 < Order1+Order2-2*contOrder) ? 1 : ((0 < Order1+Order2-contOrder) ? 2 : (contOrder>0) ? 3 : 4));

            int zero=0;
            _doProduct<T,S,typename std::common_type<T,S>::type,Order1,Order2,contOrder,0,iniPhase>(result,tensor1,tensor2,0,0,zero);

            return result;
        }
    };

    template<class T, class S, int Order1, int Order2, int contOrder>
    struct TensorOperation::_productLastFirst<T,S,Order1,Order2,contOrder,true>
    {
        static auto function(tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2 ) -> typename std::common_type<T,S>::type
        {
            typename std::common_type<T,S>::type result{};

            constexpr int iniPhase = (1 < Order1+Order2-contOrder) ? 0 : 1;
            _doProductScalar<T,S,typename std::common_type<T,S>::type,Order1,Order2,contOrder,0,iniPhase>(result,tensor1,tensor2,0,0);

            return result;
        }
    };

    template< class T, class S, int Order1, int Order2, int contOrder >
    auto TensorOperation::_product(tensor<T,Order1,false,false> const&  tensor1, tensor<S,Order2,false,false> const&  tensor2, int const (&contIndices)[contOrder][2]) ->  decltype(TensorOperation::_productLastFirst<T,S,Order1,Order2,contOrder,Order1+Order2-2*contOrder==0>::function(tensor1, tensor2))
    {

        std::array<int,Order1> allIndices1 = ordIdx<Order1>();
        std::array<int,Order2> allIndices2 = ordIdx<Order2>();

        std::list<int> sortedIndices1{allIndices1.begin(),allIndices1.end()};
        std::list<int> sortedIndices2{allIndices2.begin(),allIndices2.end()};
        
        for ( int i = 0; i < contOrder; i++ )
        {
            allIndices1[Order1-contOrder+i] = contIndices[i][0];
            allIndices2[i] = contIndices[i][1];

            sortedIndices1.remove(contIndices[i][0]);
            sortedIndices2.remove(contIndices[i][1]);
        }

        std::copy(sortedIndices1.begin(), sortedIndices1.end(),allIndices1.begin());
        std::copy(sortedIndices2.begin(), sortedIndices2.end(),allIndices2.begin()+contOrder);

        auto tensor1T = tensor1.transpose(allIndices1);
        auto tensor2T = tensor2.transpose(allIndices2);

        constexpr bool isScalar = Order1+Order2-2*contOrder==0;
        return TensorOperation::_productLastFirst<T,S,Order1,Order2,contOrder,isScalar>::function( tensor1T, tensor2T );
    }

    template < class T, class U, int Order, int contOrder, int n >
    struct TensorOperation::_doContract<T,U,Order,contOrder,n,0>
    {
        static constexpr int nextPhase =  (n+1 < Order-2*contOrder) ? 0 : ((n+2 < Order-contOrder) ? 1 : 2 );
        _doContract(tensor<U,Order-2*contOrder,false,false>& result, tensor<T,Order,false,false> const&  input, int idx1, int& idxr )
        {
            const int jump1 = input._jumps[n+contOrder];
            for(int max = result._dims[n]; max; max--)
            {
                _doContract<T,U,Order,contOrder,n+1,nextPhase>(result,input, idx1, idxr);
                idx1 += jump1;
                addone<(nextPhase > 0)>::function(idxr);
            }
        }
    };

    template < class T, class U, int Order, int contOrder, int n >
    struct TensorOperation::_doContract<T,U,Order,contOrder,n,1>
    {
        static constexpr int nextPhase =  (n+2 < Order-contOrder) ? 1 : 2;

        _doContract(tensor<U,Order-2*contOrder,false,false>& result, tensor<T,Order,false,false> const&  input, int idx1, int idxr )
        {
            const int jump1 = input._jumps[n-Order+2*contOrder]+input._jumps[n+contOrder];
            for(int max = input._dims[n+contOrder]; max; max--)
            {
                _doContract<T,U,Order,contOrder,n+1,nextPhase>(result, input, idx1, idxr);
                idx1 += jump1;
            }
        }
    };

    template < class T, class U, int Order, int contOrder, int n >
    struct TensorOperation::_doContract<T,U,Order,contOrder,n,2>
    {
        _doContract(tensor<U,Order-2*contOrder,false,false>& result, tensor<T,Order,false,false> const&  input, int idx1, int idxr )
        {
            U& sum{result._data[idxr]};
            const int jump1 = input._jumps[n-Order+2*contOrder]+input._jumps[n+contOrder];
            for(int max = input._dims[n+contOrder]; max; max--)
            {
                sum += input._data[idx1] ;
                idx1 += jump1;
            }
        }
    };

    template < class T, class U, int Order, int contOrder, int n >
    struct TensorOperation::_doContractScalar<T,U,Order,contOrder,n,0>
    {
        static constexpr int nextPhase =  (n+2 < Order-contOrder) ? 0 : 1;

        _doContractScalar( U& result, tensor<T,Order,false,false> const&  input, int idx1 )
        {
            const int jump1 = input._jumps[n-Order+2*contOrder]+input._jumps[n+contOrder];
            for(int max = input._dims[n]; max; max--)
            {
                _doContractScalar<T,U,Order,contOrder,n+1,nextPhase>(result,input, idx1);
                idx1  += jump1;
            }
        }
    };

    template < class T, class U, int Order, int contOrder, int n >
    struct TensorOperation::_doContractScalar<T,U,Order,contOrder,n,1>
    {
        _doContractScalar(U& result, tensor<T,Order,false,false> const&  input, int idx1 )
        {
            const int jump1 = input._jumps[n-Order+2*contOrder]+input._jumps[n+contOrder];
            for(int max = input._dims[n]; max; max--)
            {
                result += input._data[idx1] ;
                idx1  += jump1;
            }
        }
    };



    template<class T, int Order, int contOrder>
    struct TensorOperation::_contractLastFirst<T,Order,contOrder,false>
    {
        static auto function(tensor<T,Order,false,false> const&  input ) -> tensor<T,Order-2*contOrder>
        {
            tensor<T,Order-2*contOrder> result;

            std::copy(input._dims.begin()+contOrder, input._dims.begin()+Order-contOrder, result._dims.begin());

            result._calculateJumps();

            result._size = result._jumps[0]*result._dims[0];
            result._data = new T [result._size]();

            int zero{};
            _doContract<T,T,Order,contOrder,0,0>(result,input,0,zero);

            return result;
        }
    };

    template<class T, int Order, int contOrder>
    struct TensorOperation::_contractLastFirst<T,Order,contOrder,true>
    {
        static T function(tensor<T,Order,false,false> const&  input )
        {
            T result{};
            constexpr int iniPhase = (0 < Order-contOrder-1) ? 0 : 1;
            _doContractScalar<T,T,Order,contOrder,0,iniPhase>(result,input,0);

            return result;
        }
    };

    template< class T, int Order, int contOrder >
    auto TensorOperation::_contract(tensor<T,Order,false,false> const&  input, int const (&contIndices)[contOrder][2]) ->  decltype(TensorOperation::_contractLastFirst<T,Order,contOrder,Order-2*contOrder==0>::function(input))
    {

        std::array<int,Order> allIndices;
        std::list<int> sortedIndices;

        for ( int i = 0; i < Order; i++ )
            sortedIndices.push_back(i);

        for ( int i = 0; i < contOrder; i++ )
        {
            allIndices[i] = contIndices[i][0];
            allIndices[Order-contOrder+i] = contIndices[i][1];

            sortedIndices.remove(contIndices[i][0]);
            sortedIndices.remove(contIndices[i][1]);
        }

        std::copy(sortedIndices.begin(), sortedIndices.end(),allIndices.begin()+contOrder);

        auto inputT = input.transpose(allIndices);

        constexpr bool isScalar = Order-2*contOrder==0;
        return TensorOperation::_contractLastFirst<T,Order,contOrder,isScalar>::function(inputT);
    }


    //This is just a way to make operations template-dependent to program tensor operations once in terms of OpType
    //OpType = 0 : sum
    //OpType = 1 : subtraction
    //OpType = 2 : product
    //OpType = 3 : quotient
    template <class T, class S, int OpType>
    struct operation;

    template <class T, class S>
    struct operation<T,S,0>
    {
        static constexpr typename std::common_type<T,S>::type function( T first, S second )
        {
            return first+second;
        }
    };

    template <class T, class S>
    struct operation<T,S,1>
    {
        static constexpr typename std::common_type<T,S>::type function( T first, S second )
        {
            return first-second;
        }
    };


    template <class T, class S>
    struct operation<T,S,2>
    {
        static constexpr typename std::common_type<T,S>::type function( T first, S second )
        {
            return first*second;
        }
    };

    template <class T, class S>
    struct operation<T,S,3>
    {
        static constexpr typename std::common_type<T,S>::type function( T first, S second )
        {
            return first/second;
        }
    };

    template < class T, class S, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationScalar<T,S,U,Order,OpType,n,0>
    {
        static constexpr int nextPhase =  (n+2 < Order) ? 0 : 1;

        _doElementWiseOperationScalar(tensor<T,Order,false,false>&  output, tensor<S,Order,false,false> const&  input, U const scalar, int idxO, int idxI )
        {
            const int jumpO=output._jumps[n];
            const int jumpI=input._jumps[n];
            const int max = input._dims[n];
            for ( int i = 0; i < max; i++ )
            {
                _doElementWiseOperationScalar<T,S,U,Order,OpType,n+1,nextPhase>(output,input, scalar, idxO, idxI);
                idxO += jumpO;
                idxI += jumpI;
            }
        }
    };

    template < class T, class S, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationScalar<T,S,U,Order,OpType,n,1>
    {
        _doElementWiseOperationScalar(tensor<T,Order,false,false>&  output, tensor<S,Order,false,false> const&  input, U const scalar, int idxO, int idxI )
        {
            const int jumpO=output._jumps[Order-1];
            const int jumpI=input._jumps[Order-1];
            const int max = input._dims[Order-1];
            for ( int i = 0; i < max; i++ )
            {
                output._data[idxO] = operation<S,U,OpType>::function(input._data[idxI],scalar);
                idxO += jumpO;
                idxI += jumpI;
            }
        }
    };

    template < class T, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationScalar1<T,U,Order,OpType,n,0>
    {
        static constexpr int nextPhase =  (n+2 < Order) ? 0 : 1;

        _doElementWiseOperationScalar1(tensor<T,Order,false,false>&  output, U const scalar, int idxO)
        {
            const int jumpO=output._jumps[n];
            const int max = output._dims[n];
            for ( int i = 0; i < max; i++ )
            {
                _doElementWiseOperationScalar1<T,U,Order,OpType,n+1,nextPhase>(output, scalar, idxO);
                idxO += jumpO;
            }
        }
    };

    template < class T, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationScalar1<T,U,Order,OpType,n,1>
    {
        _doElementWiseOperationScalar1(tensor<T,Order,false,false>&  output, U const scalar, int idxO)
        {
            const int jumpO=output._jumps[Order-1];
            const int max = output._dims[Order-1];
            for ( int i = 0; i < max; i++ )
            {
                output._data[idxO] = operation<T,U,OpType>::function(output._data[idxO],scalar);
                idxO += jumpO;
            }
        }
    };

    template < class T, class U, int Order, int n >
    struct TensorOperation::_doElementWiseOperationScalar1<T,U,Order,4,n,1>
    {
        _doElementWiseOperationScalar1(tensor<T,Order,false,false>&  output, U const scalar, int idxO )
        {
            const int jumpO=output._jumps[Order-1];
            const int max = output._dims[Order-1];
            for ( int i = 0; i < max; i++ )
            {
                output._data[idxO] = scalar;
                idxO += jumpO;
            }
        }
    };


    template < class T, class S, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationTensor<T,S,U,Order,OpType,n,0>
    {
        static constexpr int nextPhase =  (n+2 < Order) ? 0 : 1;

        //First phase, free indices in tensor1
        _doElementWiseOperationTensor(tensor<T,Order,false,false>&  output, tensor<S,Order,false,false> const&  input1, tensor<U,Order,false,false> const&  input2, int idxO, int idxI1, int idxI2 )
        {
            const int jumpO=output._jumps[n];
            const int jumpI1=input1._jumps[n];
            const int jumpI2=input2._jumps[n];
            const int max = input1._dims[n];
            for ( int i = 0; i < max; i++ )
            {
                _doElementWiseOperationTensor<T,S,U,Order,OpType,n+1,nextPhase>(output, input1, input2, idxO, idxI1, idxI2);
                idxO += jumpO;
                idxI1 += jumpI1;
                idxI2 += jumpI2;
            }
        }
    };

    template < class T, class S, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationTensor<T,S,U,Order,OpType,n,1>
    {
        //First phase, free indices in tensor1
        _doElementWiseOperationTensor(tensor<T,Order,false,false>&  output, tensor<S,Order,false,false> const&  input1, tensor<U,Order,false,false> const&  input2, int idxO, int idxI1, int idxI2 )
        {
            const int jumpI1=input1._jumps[Order-1];
            const int jumpI2=input2._jumps[Order-1];
            const int max = input1._dims[Order-1];
            for ( int i = 0; i < max; i++ )
            {
                output._data[idxO] = operation<S,U,OpType>::function(input1._data[idxI1],input2._data[idxI2]);
                idxO++;
                idxI1 += jumpI1;
                idxI2 += jumpI2;
            }
        }
    };

    template < class T, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationTensor1<T,U,Order,OpType,n,0>
    {
        static constexpr int nextPhase =  (n+2 < Order) ? 0 : 1;

        //First phase, free indices in tensor1
        _doElementWiseOperationTensor1(tensor<T,Order,false,false>&  output, tensor<U,Order,false,false> const&  input2, int idxO, int idxI2 )
        {
            const int jumpO=output._jumps[n];
            const int jumpI2=input2._jumps[n];
            const int max = output._dims[n];
            for ( int i = 0; i < max; i++ )
            {
                _doElementWiseOperationTensor1<T,U,Order,OpType,n+1,nextPhase>(output, input2, idxO, idxI2);
                idxO += jumpO;
                idxI2 += jumpI2;
            }
        }
    };

    template < class T, class U, int Order, int OpType, int n >
    struct TensorOperation::_doElementWiseOperationTensor1<T,U,Order,OpType,n,1>
    {
        //First phase, free indices in tensor1
        _doElementWiseOperationTensor1(tensor<T,Order,false,false>&  output, tensor<U,Order,false,false> const&  input2, int idxO, int idxI2 )
        {
            const int jumpO=output._jumps[Order-1];
            const int jumpI2=input2._jumps[Order-1];
            const int max = output._dims[Order-1];
            for ( int i = 0; i < max; i++ )
            {
                output._data[idxO] = operation<T,U,OpType>::function(output._data[idxO],input2._data[idxI2]);
                idxO += jumpO;
                idxI2 += jumpI2;
            }
        }
    };

    template < class T, class U, int Order, int n >
    struct TensorOperation::_doElementWiseOperationTensor1<T,U,Order,4,n,1>
    {
        //First phase, free indices in tensor1
        _doElementWiseOperationTensor1(tensor<T,Order,false,false>&  output, tensor<U,Order,false,false> const&  input2, int idxO, int idxI2 )
        {
            const int jumpO=output._jumps[Order-1];
            const int jumpI2=input2._jumps[Order-1];
            const int max = output._dims[Order-1];
            for ( int i = 0; i < max; i++ )
            {
                output._data[idxO] = input2._data[idxI2];
                idxO += jumpO;
                idxI2 += jumpI2;
            }
        }
    };

    template < class T, class U, int Order, int n >
    struct TensorOperation::_doElementWiseOperationTensor1<T,U,Order,5,n,1>
    {
        //First phase, free indices in tensor1
        _doElementWiseOperationTensor1(tensor<T,Order,false,false>&  output, tensor<U,Order,false,false> const&  input2, int idxO, int idxI2 )
        {
            const int jumpO=output._jumps[Order-1];
            const int jumpI2=input2._jumps[Order-1];
            const int max = output._dims[Order-1];
            for ( int i = 0; i < max; i++ )
            {
                output._data[idxO] = -input2._data[idxI2];
                idxO += jumpO;
                idxI2 += jumpI2;
            }
        }
    };

    template<class Type, int Order>
    template<class U>
    void tensor<Type,Order,false,false>::operator+=(tensor<U,Order,false,false> const& tensor2)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,U,Order,0,0,nextPhase>(*this,tensor2, 0, 0);
    }

    template<class Type, int Order>
    template <class U>
    void tensor<Type,Order,false,false>::operator-=(tensor<U,Order,false,false> const& tensor2)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,U,Order,1,0,nextPhase>(*this,tensor2, 0, 0);
    }

    template< class T, class S, int Order>
    auto operator+(tensor<T,Order,false,false> const& tensor1, tensor<S,Order,false,false> const& tensor2 ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result;
        result.resize(tensor1);

        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor<typename std::common_type<T,S>::type,T,S,Order,0,0,nextPhase>(result,tensor1,tensor2, 0, 0, 0 );

        return result;
    }

    template< class T, class S, int Order>
    auto operator-(tensor<T,Order,false,false> const& tensor1, tensor<S,Order,false,false> const& tensor2 ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result;
        result.resize(tensor1);

        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor<typename std::common_type<T,S>::type,T,S,Order,1,0,nextPhase>(result,tensor1,tensor2, 0, 0, 0 );

        return result;
    }

    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false,false>::operator+=(U const scalar)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar1<Type,U,Order,0,0,nextPhase>(*this,scalar, 0 );
    }
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false,false>::operator-=(U const scalar)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar1<Type,U,Order,1,0,nextPhase>(*this,scalar, 0);
    }
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false,false>::operator*=(U const scalar)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar1<Type,U,Order,2,0,nextPhase>(*this,scalar, 0);
    }
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false,false>::operator/=(U const scalar)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar1<Type,U,Order,3,0,nextPhase>(*this,scalar, 0 );
    }

    template <class T, class S, int Order, typename C>
    auto operator+(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result;
        result.resize(input);

        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar<typename std::common_type<T,S>::type,T,S,Order,0,0,nextPhase>(result, input, scalar, 0, 0 );

        return result;
    }

    template <class T, class S, int Order, typename C>
    auto operator-(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result;
        result.resize(input);

        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar<typename std::common_type<T,S>::type,T,S,Order,1,0,nextPhase>(result, input, scalar, 0, 0 );

        return result;
    }
    
    template <class T, class S, int Order, typename C>
    auto operator*(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result;
        result.resize(input);

        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar<typename std::common_type<T,S>::type,T,S,Order,2,0,nextPhase>(result, input, scalar, 0, 0 );

        return result;
    }

    template <class T, class S, int Order, typename C>
    auto operator/(tensor<T,Order,false,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result;
        result.resize(input);

        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar<typename std::common_type<T,S>::type,T,S,Order,3,0,nextPhase>(result, input, scalar, 0, 0 );

        return result;
    }
    
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false,false>::operator=(U const scalar)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar1<Type,U,Order,4,0,nextPhase>(*this,scalar, 0);
    }

    template <class T, class S, int Order, typename C>
    auto operator+(S const scalar, tensor<T,Order,false,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        return input + scalar;
    }

    template <class T, class S, int Order, typename C>
    auto operator-(S const scalar, tensor<T,Order,false,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        return (-input) + scalar;
    }

    template <class S, class U, int Order, typename C>
    auto operator*(U const scalar,tensor<S,Order,false,false> const& input) -> tensor<typename std::common_type<S,U>::type,Order>
    {
        return input * scalar;
    }

    template<class Type, int Order>
    template<class U>
    void tensor<Type,Order,false>::operator+=(tensor<U,Order,false> const& tensor2)
    {
        for(int i = 0; i < _size; i++)
            __::_data[i] += tensor2._data[i];
    }
    template<class Type, int Order>
    template<class U>
    void tensor<Type,Order,false>::operator-=(tensor<U,Order,false> const& tensor2)
    {
        for(int i = 0; i < _size; i++)
            __::_data[i] -= tensor2._data[i];
    }

    template< class T, class S, int Order>
    auto operator+(tensor<T,Order,false> const& tensor1, tensor<S,Order,false> const& tensor2 ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result(tensor1);
        for(int i = 0; i < result._size; i++)
            result._data[i] += tensor2._data[i];
        return result;
    }
    
    template< class T, int Order>
    tensor<T,Order> operator+(tensor<T,Order>&& tensor1, tensor<T,Order> const& tensor2)
    {
        tensor1+=tensor2;
        return std::move(tensor1);
    }

    template< class T, int Order>
    tensor<T,Order> operator+(tensor<T,Order> const& tensor1, tensor<T,Order> && tensor2)
    {
        tensor2+=tensor1;
        return std::move(tensor2);
    }

    template< class T, int Order>
    tensor<T,Order> operator+(tensor<T,Order>&& tensor1, tensor<T,Order> && tensor2)
    {
        tensor1+=tensor2;
        return std::move(tensor1);
    }

    template< class T, class S, int Order>
    auto operator-(tensor<T,Order,false> const& tensor1, tensor<S,Order,false> const& tensor2 ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result;
        result.resize(tensor1);
        for(int i = 0; i < result._size; i++)
            result._data[i] = tensor1._data[i] - tensor2._data[i];

        return result;
    }

    template< class T, int Order>
    tensor<T,Order> operator-(tensor<T,Order>&& tensor1, tensor<T,Order> const& tensor2)
    {
        tensor1-=tensor2;
        return std::move(tensor1);
    }

    template< class T, int Order>
    tensor<T,Order> operator-(tensor<T,Order> const& tensor1, tensor<T,Order> && tensor2)
    {
        tensor2-=tensor1;
        return std::move(tensor2);
    }

    template< class T, int Order>
    tensor<T,Order> operator-(tensor<T,Order>&& tensor1, tensor<T,Order> && tensor2)
    {
        tensor1-=tensor2;
        return std::move(tensor1);
    }

    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false>::operator+=(U const scalar)
    {
        for(int i = 0; i < _size; i++)
            __::_data[i] += scalar;
    }
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false>::operator-=(U const scalar)
    {
        for(int i = 0; i < _size; i++)
            __::_data[i] -= scalar;
    }
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false>::operator*=(U const scalar)
    {
        for(int i = 0; i < _size; i++)
            __::_data[i] *= scalar;
    }
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false>::operator/=(U const scalar)
    {
        for(int i = 0; i < _size; i++)
            __::_data[i] /= scalar;
    }


    template <class T, class S, int Order, typename C>
    auto operator+(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result(input);
        result += scalar;
        return result;
    }

    template <class T, class S, int Order, typename C>
    auto operator-(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result(input);
        result -= scalar;
        return result;
    }

    template <class T, class S, int Order, typename C>
    auto operator*(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result(input);
        result *= scalar;
        return result;
    }

    template <class T, class S, int Order, typename C>
    auto operator/(tensor<T,Order,false> const& input, S const scalar ) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        tensor<typename std::common_type<T,S>::type,Order> result(input);
        result /= scalar;
        return result;
    }
    
    template<class Type, int Order>
    template<class U, typename C>
    void tensor<Type,Order,false>::operator=(U const scalar)
    {
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationScalar1<Type,U,Order,4,0,nextPhase>(*this,scalar, 0);
    }

    template <class T, class S, int Order, typename C>
    auto operator+(S const scalar, tensor<T,Order,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        return input + scalar;
    }

    template <class T, class S, int Order, typename C>
    auto operator-(S const scalar, tensor<T,Order,false> const& input) -> tensor<typename std::common_type<T,S>::type,Order>
    {
        return (-input) + scalar;
    }

    template <class S, class U, int Order, typename C>
    auto operator*(U const scalar,tensor<S,Order,false> const& input) -> tensor<typename std::common_type<S,U>::type,Order>
    {
        return input * scalar;
    }

    template <class T, int Order>
    tensor<T,Order> operator+(tensor<T,Order> input, T const scalar )
    {
        input += scalar;
        return input;
    }

    template <class T, int Order>
    tensor<T,Order> operator+(T const scalar, tensor<T,Order> input)
    {
        input += scalar;
        return input;
    }

    template <class T, int Order>
    tensor<T,Order> operator-(tensor<T,Order> input, T const scalar )
    {
        input -= scalar;
        return input;
    }

    template <class T, int Order>
    tensor<T,Order> operator-(T const scalar, tensor<T,Order> input)
    {
        input -= scalar;
        return input;
    }

    template <class T, int Order>
    tensor<T,Order> operator*(tensor<T,Order> input, T const scalar )
    {
        input *= scalar;
        return input;
    }

    template <class T, int Order>
    tensor<T,Order> operator*(T const scalar, tensor<T,Order> input)
    {
        input *= scalar;
        return input;
    }

    template <class T, int Order>
    tensor<T,Order> operator/(tensor<T,Order> input, T const scalar )
    {
        input /= scalar;
        return input;
    }

    template <class Type, int Order>
    tensor<Type,Order> tensor<Type,Order,false,false>::operator-()
    {
        tensor<Type,Order> result;
        result.resize(*this);

        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor1<Type,Type,Order,5,0,nextPhase>(result, *this, 0, 0);

        return result;
    }
    template <class Type, int Order>
    tensor<Type,Order> tensor<Type,Order,false,true>::operator-()
    {
        tensor<Type,Order> result;
        result.resize(*this);

        for(int i = 0; i < _size; i++)
            result._data[i] = -__::_data[i];

        return result;
    }
    
    template<class Type, int Order>
    Type tensor<Type,Order,false,false>::det()
    {
        static_assert(Order==2, "Determinant does not make sense for order different than 2.");

        Type det{};

        if ( _dims[0] == 2 and _dims[1] == 2 )
            det = (*this)(0,0) * (*this)(1,1) - (*this)(0,1) * (*this)(1,0);
        else if  ( _dims[0] == 3 and _dims[1] == 3  )
        {
            det  =    (*this)(0,0) * ((*this)(1,1)*(*this)(2,2) - (*this)(1,2) * (*this)(2,1))
                    - (*this)(1,0) * ((*this)(0,1)*(*this)(2,2) - (*this)(0,2) * (*this)(2,1))
                    + (*this)(2,0) * ((*this)(0,1)*(*this)(1,2) - (*this)(0,2) * (*this)(1,1));
        }
        else
        {
            std::cout << _dims[0] << " " << _dims[1] << std::endl;
            throw std::runtime_error("Tensor::det: Only programmed for 2x2 and 3x3 at the moment.");
        }

        return det;
    }

    template<class Type, int Order>
    Type tensor<Type,Order,false,true>::det()
    {
        static_assert(Order==2, "Determinant does not make sense for order different than 2.");

        Type det{};

        if ( __::_dims[0] == 2 and __::_dims[1] == 2 )
        {
            det = __::_data[0]*__::_data[3]-__::_data[1]*__::_data[2];
        }
        else if  ( __::_dims[0] == 3 and __::_dims[1] == 3  )
        {
            det = __::_data[0] * (__::_data[4]*__::_data[8] - __::_data[5] * __::_data[7])
                  - __::_data[3] * (__::_data[1]*__::_data[8] - __::_data[2] * __::_data[7])
                  + __::_data[6] * (__::_data[1]*__::_data[5] - __::_data[2] * __::_data[4]);
        }
        else
        {
            std::cout << __::_dims[0] << " " << __::_dims[1] << std::endl;
            throw std::runtime_error("Tensor::det: Only programmed for 2x2 and 3x3 at the moment.");
        }

        return det;
    }

    template<class Type, int Order>
    tensor<Type,Order> tensor<Type,Order,false,false>::inv ( )
    {
        static_assert(Order==2, "Inverse cannot be computed for order different than 2.");

        tensor<Type,2> inv;

        if (_dims[0] == 2 and _dims[1] == 2)
        {
            inv._dims[0] = 2;
            inv._dims[1] = 2;

            inv._jumps[0] = 2;
            inv._jumps[1] = 1;

            inv._size = 4;
            inv._data = new Type [4];

            Type idet = 1.0/det();
            inv._data[0] =  (*this)(1,1)*idet;
            inv._data[3] =  (*this)(0,0)*idet;
            inv._data[1] = -(*this)(0,1)*idet;
            inv._data[2] = -(*this)(1,0)*idet;
        }
        else if( _dims[0] == 3 and _dims[1] == 3)
        {
            inv._dims[0] = 3;
            inv._dims[1] = 3;

            inv._jumps[0] = 3;
            inv._jumps[1] = 1;

            inv._size = 9;
            inv._data = new Type [9];

            inv._data[0] = -(*this)(1,2)*(*this)(2,1) + (*this)(1,1)*(*this)(2,2);
            inv._data[1] =  (*this)(0,2)*(*this)(2,1) - (*this)(0,1)*(*this)(2,2);
            inv._data[2] = -(*this)(0,2)*(*this)(1,1) + (*this)(0,1)*(*this)(1,2);
            inv._data[3] =  (*this)(1,2)*(*this)(2,0) - (*this)(1,0)*(*this)(2,2);
            inv._data[4] = -(*this)(0,2)*(*this)(2,0) + (*this)(0,0)*(*this)(2,2);
            inv._data[5] =  (*this)(0,2)*(*this)(1,0) - (*this)(0,0)*(*this)(1,2);
            inv._data[6] = -(*this)(1,1)*(*this)(2,0) + (*this)(1,0)*(*this)(2,1);
            inv._data[7] =  (*this)(0,1)*(*this)(2,0) - (*this)(0,0)*(*this)(2,1);
            inv._data[8] = -(*this)(0,1)*(*this)(1,0) + (*this)(0,0)*(*this)(1,1);

            Type idet = 1./det();
            for(int i=0; i<9; i++)
                inv._data[i] = idet*inv._data[i];
        }
        else
            throw std::runtime_error("Tensor::det: Only programmed for 2x2 and 3x3 matrices at the moment.");

        return inv;
    }

    template<class Type, int Order>
    tensor<Type,Order> tensor<Type,Order,false,true>::inv ( )
    {
        static_assert(Order==2, "Inverse cannot be computed for order different than 2.");

        tensor<Type,2> inv;

        if (__::_dims[0] == 2 and __::_dims[1] == 2)
        {
            inv._dims[0] = 2;
            inv._dims[1] = 2;

            inv._jumps[0] = 2;
            inv._jumps[1] = 1;

            inv._size = 4;
            inv._data = new Type [4];

            Type idet = 1.0/det();
            inv._data[0] =  __::_data[3]*idet;
            inv._data[3] =  __::_data[0]*idet;
            inv._data[1] = -__::_data[1]*idet;
            inv._data[2] = -__::_data[2]*idet;
        }
        else if( __::_dims[0] == 3 and __::_dims[1] == 3)
        {
            inv._dims[0] = 3;
            inv._dims[1] = 3;

            inv._jumps[0] = 3;
            inv._jumps[1] = 1;

            inv._size = 9;
            inv._data = new Type [9];

            //FIXME: improve this
            inv._data[0] = -(*this)(1,2)*(*this)(2,1) + (*this)(1,1)*(*this)(2,2);
            inv._data[1] =  (*this)(0,2)*(*this)(2,1) - (*this)(0,1)*(*this)(2,2);
            inv._data[2] = -(*this)(0,2)*(*this)(1,1) + (*this)(0,1)*(*this)(1,2);
            inv._data[3] =  (*this)(1,2)*(*this)(2,0) - (*this)(1,0)*(*this)(2,2);
            inv._data[4] = -(*this)(0,2)*(*this)(2,0) + (*this)(0,0)*(*this)(2,2);
            inv._data[5] =  (*this)(0,2)*(*this)(1,0) - (*this)(0,0)*(*this)(1,2);
            inv._data[6] = -(*this)(1,1)*(*this)(2,0) + (*this)(1,0)*(*this)(2,1);
            inv._data[7] =  (*this)(0,1)*(*this)(2,0) - (*this)(0,0)*(*this)(2,1);
            inv._data[8] = -(*this)(0,1)*(*this)(1,0) + (*this)(0,0)*(*this)(1,1);

            Type idet = 1./det();
            for(int i=0; i<9; i++)
                inv._data[i] = idet*inv._data[i];
        }
        else
            throw std::runtime_error("Tensor::det: Only programmed for 2x2 and 3x3 matrices at the moment.");

        return inv;
    }
    
    template<class Type, int Order>
    Type tensor<Type,Order,false,false>::norm()
    {
#if __cplusplus >= 201402L
        return sqrt(TensorOperation::_productLastFirst<Type,Type,Order,Order,Order,true>::function(*this,(*this).transpose(revIdx<Order>())));
#else
        std::array<int,Order> arr{0}; 
        std::iota(arr.rbegin(),arr.rend(),0);
        return sqrt(TensorOperation::_productLastFirst<Type,Type,Order,Order,Order,true>::function(*this,(*this).transpose(arr)));
#endif
    }

    template<class Type, int Order>
    Type tensor<Type,Order,false,true>::norm()
    {
        Type norm2{};
        for(int i = 0; i < _size; i++)
            norm2 += (__::_data[i]*__::_data[i]);
        return sqrt(norm2);
    }

    template <class T, class S, int Order>
    tensor<typename std::common_type<T,S>::type,Order> eproduct(tensor<T,Order,false,false> const& tensor1, tensor<S,Order,false,false> const& tensor2 )
    {
        tensor<decltype(tensor1._data[0]*tensor2._data[0]),Order> result;
        result.resize(tensor1);
        constexpr int nextPhase =  (1 < Order) ? 0 : 1;
        TensorOperation::_doElementWiseOperationTensor<decltype(tensor1._data[0]*tensor2._data[0]),T,S,Order,2,0,nextPhase>(result,tensor1,tensor2, 0, 0, 0 );

        return result;
    }
}

#endif //ttl_tensoroperations_impl_h