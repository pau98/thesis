/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_h
#define ttl_h

#include <iostream>
#include <vector>
#include <array>
#include <tuple>
#include <numeric>

#include "ttl_RunningIndex.h"
#include "ttl_Auxiliary.h"
#include "ttl_Tensor.h"
#include "ttl_Operations.h"
#include "ttl_Operations-impl.h"
#include "ttl_Tensor-impl.h"
#include "ttl_TensorIndices.h"
#include "ttl_TensorIndicesOperations.h"
#include "ttl_TensorIndicesOperations-impl.h"
#include "ttl_TensorIndices-impl.h"
#include "ttl_IndexPool.h"

#endif //ttl_h
