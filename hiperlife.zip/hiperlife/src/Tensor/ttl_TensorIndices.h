/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_tensorindices_h
#define ttl_tensorindices_h

#if __cplusplus >= 201402L

namespace ttl
{
    template<class T, bool St, bool Co, class U0, class... U>
    class tensor_indices<T,typelist<U0,U...>, St, Co, true>
    {

        private:

            static constexpr int order = typelist<U0,U...>::size;
            tensor<T,order,St,Co> _tensor{};

        public:            
            tensor_indices(tensor_indices<T,typelist<U0,U...>,St,Co,false> const& other) : _tensor{other._tensor}{}
            tensor_indices(tensor_indices<T,typelist<U0,U...>,St,Co,false> && other) : _tensor{std::move(other._tensor)}{}
            tensor_indices& operator=(tensor_indices<T,typelist<U0,U...>,St,Co,false> const& other)
            {
                _tensor = other._tensor;
                return *this;
            }
            tensor_indices& operator=(tensor_indices<T,typelist<U0,U...>,St,Co,false> && other)
            {
                _tensor = std::move(other._tensor);
                return *this;
            }

            tensor_indices(tensor<T,typelist<U0,U...>::size,St,Co> && tensor) : _tensor{std::move(tensor)}{}
            
            template<class S, bool St2, bool Co2>
            tensor_indices(tensor<S,typelist<U0,U...>::size,St2,Co2> const& tensor) : _tensor{tensor}{}

            template<class S, bool St2, bool Co2, bool Ow2>
            tensor_indices(tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2> const& other) : _tensor{other._tensor} {}

            template<class S, bool St2, bool Co2, bool Ow2>
            tensor_indices& operator=(tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2> const& other)
            {
                _tensor = other._tensor;
                return *this;
            }

            tensor_indices(tensor_indices<T,typelist<U0,U...>,St,Co,true> && other) : _tensor{std::move(other._tensor)} {}
            tensor_indices& operator=(tensor_indices<T,typelist<U0,U...>,St,Co,true> && other)
            {
                _tensor = std::move(other._tensor);
                return *this;
            }

            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            tensor_indices(tensor_indices<S,typelist<V...>,St2,Co2,Ow2> const& other) : _tensor{other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first)} {}

            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            tensor_indices& operator=(tensor_indices<S,typelist<V...>,St2,Co2,Ow2> const& other)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                _tensor = other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first);         
                return *this;
            }
            
            tensor_indices<T,typelist<U0,U...>,St,Co,true> operator ()(U0,U... )         
            {
                return std::move(_tensor);
            }

            template<class...V>
            tensor_indices<T,typelist<V...>,false,false,true> operator ()(V... ) & //if the object does not die, just point to its memory
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                return _tensor.transpose(remove_duplicates<U0,U...,V...>::shared_first);
            }
            template<class...V>
            tensor_indices<T,typelist<V...>,St,St,true> operator ()(V... ) && //Otherwise we need to create a copy (Note here that the output is St,St,true -if storage is false, this has to be false,false otherwise this must be true,true-)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                return _tensor.transpose(remove_duplicates<U0,U...,V...>::shared_first);
            }

            friend std::ostream& operator<<(std::ostream& out, tensor_indices const& wrap_idx)
            {
                wrap_idx._tensor.print( out, "[", "]", ",");
                return out;
            }
            
            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            void operator +=(const tensor_indices<S,typelist<V...>,St2,Co2,Ow2> & other)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                _tensor += other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first);
            }
            
            template<class S, bool St2, bool Co2, bool Ow2>
            void operator +=(const tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2>& other)
            {
                _tensor += other._tensor;
            }
            
            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            void operator -=(const tensor_indices<S,typelist<V...>,St2,Co2,Ow2>& other)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                _tensor -= other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first);
            }
            
            template<class S, bool St2, bool Co2, bool Ow2>
            void operator -=(const tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2>& other)
            {    _tensor -= other._tensor;    }
            template<class S>
            void operator +=(const S scalar)
            {    _tensor += scalar;    }
            template<class S>
            void operator -=(const S scalar)
            {    _tensor -= scalar;    }
            template<class S>
            void operator *=(const S scalar)
            {    _tensor *= scalar;    }
            template<class S>
            void operator /=(const S scalar)
            {    _tensor /= scalar;    }

            tensor_indices<T,typelist<U0,U...>,true,true,true> operator-()
            {    return -_tensor;    }
            
            template<class S, int Order2, bool St2, bool Co2>
            friend class tensor;

            template<class S, class U2, bool St2, bool Co2, bool Ow2>
            friend class tensor_indices;

            friend class TensorIndicesOperation;

            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator+(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator-(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator*(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator/(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator+(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator-(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<Type1, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator*(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2>
            friend tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true> operator+(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices1...>, St2, Co2, Ow2> const& ti2);
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
            friend tensor_indices<Type1, typelist<Indices1...>,true,true,true> operator+(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> const& ti2);
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2>
            friend auto operator-(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices1...>, St2, Co2, Ow2> const& ti2) -> tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
            friend auto operator-(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> const& ti2) -> tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true>;
    };

    template<class T, bool St, bool Co, class U0, class... U>
    class tensor_indices<T,typelist<U0,U...>, St, Co, false>
    {
        private:

            static constexpr int order = typelist<U0,U...>::size;
            tensor<T,order,St,Co> &_tensor{};

        public:

            tensor_indices(tensor_indices<T,typelist<U0,U...>,St,Co,true> const& other) : _tensor{other._tensor}{}
            tensor_indices(tensor_indices<T,typelist<U0,U...>,St,Co,true> && other) : _tensor{std::move(other._tensor)}{}
            tensor_indices& operator=(tensor_indices<T,typelist<U0,U...>,St,Co,true> const& other)
            {
                _tensor = other._tensor;
                return *this;
            }
            tensor_indices& operator=(tensor_indices<T,typelist<U0,U...>,St,Co,true> && other)
            {
                _tensor = std::move(other._tensor);
                return *this;
            }

            template<class S, bool St2, bool Co2>
            tensor_indices(tensor<S,typelist<U0,U...>::size,St2,Co2> & tensor) : _tensor{tensor}{}

            template<class S, bool St2, bool Co2, bool Ow2>
            tensor_indices& operator=(tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2> & other)
            {
                _tensor = other._tensor;
                return *this;
            }

            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            tensor_indices& operator=(tensor_indices<S,typelist<V...>,St2,Co2,Ow2> & other)
            {
                _tensor = other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first);         
                return *this;
            }

            template<class S, bool St2, bool Co2, bool Ow2>
            tensor_indices& operator=(tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2> && other)
            {
                _tensor = std::move(other._tensor);
                return *this;
            }

            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            tensor_indices& operator=(tensor_indices<S,typelist<V...>,St2,Co2,Ow2> && other)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                _tensor = other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first);         
                return *this;
            }

            tensor_indices<T,typelist<U0,U...>,St,Co,true> operator ()(U0,U... )         
            {
                return std::move(_tensor);
            }
            template<class...V>
            tensor_indices<T,typelist<V...>,false,false,true> operator ()(V...)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                return _tensor.transpose(remove_duplicates<U0,U...,V...>::shared_first);
            }

            friend std::ostream& operator<<(std::ostream& out, tensor_indices const& wrap_idx)
            {
                wrap_idx._tensor.print( out, "[", "]", ",");
                return out;
            }
            
            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            void operator +=(const tensor_indices<S,typelist<V...>,St2,Co2,Ow2> & other)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                _tensor += other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first);
            }
            
            template<class S, bool St2, bool Co2, bool Ow2>
            void operator +=(const tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2>& other)
            {
                _tensor += other._tensor;
            }
            
            template<class S, bool St2, bool Co2, bool Ow2, class...V>
            void operator -=(const tensor_indices<S,typelist<V...>,St2,Co2,Ow2>& other)
            {
                static_assert(remove_duplicates<V...,U0,U...>::free.size()==0, "Indices do not match");
                _tensor -= other._tensor.transpose(remove_duplicates<V...,U0,U...>::shared_first);
            }
            
            template<class S, bool St2, bool Co2, bool Ow2>
            void operator -=(const tensor_indices<S,typelist<U0,U...>,St2,Co2,Ow2>& other)
            {
                _tensor -= other._tensor;
            }

            tensor_indices<T,typelist<U0,U...>,true,true,true> operator-()
            {    return -_tensor;    }

            template<class S>
            void operator +=(const S scalar)
            {    _tensor += scalar;    }
            template<class S>
            void operator -=(const S scalar)
            {    _tensor -= scalar;    }
            template<class S>
            void operator *=(const S scalar)
            {    _tensor *= scalar;    }
            template<class S>
            void operator /=(const S scalar)
            {    _tensor /= scalar;    }

            template<class S, int Order2, bool St2, bool Co2>
            friend class tensor;

            template<class S, class U2, bool St2, bool Co2, bool Ow2>
            friend class tensor_indices;
            friend class TensorIndicesOperation;

            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator+(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator-(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator*(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator/(tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1, S const scalar ) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator+(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator-(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class S, typename C>
            friend auto operator*(S const scalar , tensor_indices<Type1,typelist<Indices1...>,St1,Co1,Ow1> const& ti1) ->tensor_indices<typename std::common_type<Type1,S>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2>
            friend tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true> operator+(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices1...>, St2, Co2, Ow2> const& ti2);
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
            friend tensor_indices<Type1, typelist<Indices1...>,true,true,true> operator+(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> const& ti2);
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2>
            friend auto operator-(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices1...>, St2, Co2, Ow2> const& ti2) -> tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true>;
            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
            friend auto operator-(tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1> const& ti1, tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2> const& ti2) -> tensor_indices<typename std::common_type<Type1,Type2>::type, typelist<Indices1...>,true,true,true>;
    };
}

#endif //__cplusplus >= 201402L
#endif //ttl_tensorindices_h
