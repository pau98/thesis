/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef ttl_tensorindicesoperations_h
#define ttl_tensorindicesoperations_h

#if __cplusplus >= 201402L

namespace ttl
{       
    class TensorIndicesOperation
    {
        private:

            template <class Type1, bool St1, bool Co1, bool Ow1, class Indices1, class Type2, bool St2, bool Co2, bool Ow2, class Indices2, bool noRepeated>
            struct product_tidx;

            template <class Type, int Order, bool St, bool Co, bool wrap, class... Indices>
            struct fake_contract;

            template<bool scalar, bool ints, bool move,class Type, int Order, bool St, bool Co, class A>
            struct onemorefakecontracttuple;

            template<bool integers, bool scalar, bool move, class Type, int Order, bool St, bool Co, class... Indices>
            struct yetanotherfakecontract;
        
            template<class Type, int Order, bool St, bool Co>
            friend class tensor;

            template <class Type1, bool St1, bool Co1, bool Ow1, class... Indices1, class Type2, bool St2, bool Co2, bool Ow2, class... Indices2>
            friend auto operator*(const tensor_indices<Type1, typelist<Indices1...>, St1, Co1, Ow1>& ti1, const tensor_indices<Type2, typelist<Indices2...>, St2, Co2, Ow2>& ti2) -> typename std::conditional<sizeof...(Indices1)+sizeof...(Indices2)-2*remove_duplicates<Indices1...,Indices2...>::shared_first.size()==0, typename std::common_type<Type1,Type2>::type,tensor_indices<typename std::common_type<Type1,Type2>::type, typename remove_duplicates<Indices1...,Indices2...>::type,true, true, true>>::type;
    };
}

#endif //__cplusplus >= 201402L
#endif //ttl_tensorindices_h