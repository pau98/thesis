/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef ttl_indexpool_h
#define ttl_indexpool_h
#if __cplusplus >= 201402L


namespace ttl
{
    namespace index
    {
        static constexpr idx<'a'> a;
        static constexpr idx<'b'> b;
        static constexpr idx<'c'> c;
        static constexpr idx<'d'> d;
        static constexpr idx<'e'> e;
        static constexpr idx<'f'> f;
        static constexpr idx<'g'> g;
        static constexpr idx<'h'> h;
        static constexpr idx<'i'> i;
        static constexpr idx<'j'> j;
        static constexpr idx<'k'> k;
        static constexpr idx<'l'> l;
        static constexpr idx<'m'> m;
        static constexpr idx<'n'> n;
        static constexpr idx<'o'> o;
        static constexpr idx<'p'> p;
        static constexpr idx<'q'> q;
        static constexpr idx<'r'> r;
        static constexpr idx<'s'> s;
        static constexpr idx<'t'> t;
        static constexpr idx<'u'> u;
        static constexpr idx<'v'> v;
        static constexpr idx<'x'> x;
        static constexpr idx<'w'> w;
        static constexpr idx<'y'> y;
        static constexpr idx<'z'> z;

        static constexpr idx<'A'> A;
        static constexpr idx<'B'> B;
        static constexpr idx<'C'> C;
        static constexpr idx<'D'> D;
        static constexpr idx<'E'> E;
        static constexpr idx<'F'> F;
        static constexpr idx<'G'> G;
        static constexpr idx<'H'> H;
        static constexpr idx<'I'> I;
        static constexpr idx<'J'> J;
        static constexpr idx<'K'> K;
        static constexpr idx<'L'> L;
        static constexpr idx<'M'> M;
        static constexpr idx<'N'> N;
        static constexpr idx<'O'> O;
        static constexpr idx<'P'> P;
        static constexpr idx<'Q'> Q;
        static constexpr idx<'R'> R;
        static constexpr idx<'S'> S;
        static constexpr idx<'T'> T;
        static constexpr idx<'U'> U;
        static constexpr idx<'V'> V;
        static constexpr idx<'X'> X;
        static constexpr idx<'W'> W;
        static constexpr idx<'Y'> Y;
        static constexpr idx<'Z'> Z;

#ifdef HL_GREEK_INDICES
        static constexpr idx<L'α'> α;
        static constexpr idx<L'β'> β;
        static constexpr idx<L'γ'> γ;
        static constexpr idx<L'δ'> δ;
        static constexpr idx<L'ε'> ε;
        static constexpr idx<L'ζ'> ζ;
        static constexpr idx<L'η'> η;
        static constexpr idx<L'θ'> θ;
        static constexpr idx<L'ι'> ι;
        static constexpr idx<L'κ'> κ;
        static constexpr idx<L'λ'> λ;
        static constexpr idx<L'μ'> μ;
        static constexpr idx<L'ξ'> ξ;
        static constexpr idx<L'π'> π;
        static constexpr idx<L'ρ'> ρ;
        static constexpr idx<L'σ'> σ;
        static constexpr idx<L'τ'> τ;
        static constexpr idx<L'χ'> χ;
        static constexpr idx<L'ϕ'> ϕ;
        static constexpr idx<L'φ'> φ;
        static constexpr idx<L'ψ'> ψ;
        static constexpr idx<L'ω'> ω;

        static constexpr idx<L'Γ'> Γ;
        static constexpr idx<L'Δ'> Δ;
        static constexpr idx<L'Θ'> Θ;
        static constexpr idx<L'Λ'> Λ;
        static constexpr idx<L'Ξ'> Ξ;
        static constexpr idx<L'Π'> Π;
        static constexpr idx<L'Σ'> Σ;
        static constexpr idx<L'Φ'> Φ;
        static constexpr idx<L'Ψ'> Ψ;
        static constexpr idx<L'Ω'> Ω;
#endif
    }
}

#endif //__cplusplus >= 201402L
#endif //ttl_indexpool_h