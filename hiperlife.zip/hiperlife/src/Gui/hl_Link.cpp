/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

// C++ headers
#include <iostream>
#include <fstream>

// Qt headers
#include <QPen>
#include <QPainter>
#include <QPainterPathStroker>

#include "hl_Link.h"

using namespace hlGui;

Link::Link(QGraphicsItem *parent): QGraphicsPathItem(parent)
{
    setFlag(ItemIsSelectable);
    setPen(QPen(Qt::lightGray, 2, Qt::DashLine, Qt::RoundCap, Qt::RoundJoin));
    setBrush(Qt::NoBrush);
    setZValue(-1);
}

void Link::setPort0(Port *p0)
{
    _p0 = p0;
    _p0->links.push_back(this);
}

void Link::setPort1(Port *p1)
{
    _p1 = p1;
    _p1->links.push_back(this);
}

void Link::setLink(Port *p0, Port *p1)
{
    setPort0(p0);
    setPort1(p1);
    setCoords0(p0->pos());
    setCoords1(p1->pos());
}

void Link::Update()
{
    QColor mainColor = bColor(_p0->_mnType);
    if (_p0->blocked == true or (_p1 != 0 and _p1->blocked == true))
    {
        mainColor = Qt::lightGray;
        blocked = true;
    }

    if (_p1 == 0)
        setPen(QPen(Qt::lightGray, 3, Qt::DashLine, Qt::RoundCap, Qt::RoundJoin));
    else
        setPen(QPen(mainColor, 3));

    if (_p1 != 0)
    {
        _c0 = _p0->scenePos();
        _c1 = _p1->scenePos();
    }

    QPainterPath p;
    p.moveTo(_c0);

    qreal dx = _c1.x() - _c0.x();
    qreal dy = _c1.y() - _c0.y();

    if (dx > 0)
    {
        QPointF ctr0(_c0.x() + dx * 0.45, _c0.y() + dy * 0.0);
        QPointF ctr1(_c0.x() + dx * 0.65, _c0.y() + dy * 1.0);

        p.cubicTo(ctr0, ctr1, _c1);
    }
    else
    {
        QPointF ctr0(_c0.x() - dx * 0.15, _c0.y());
        QPointF ctr1(_c0.x() - dx * 0.15, _c0.y() + dy * 0.5);
        QPointF ctr2(_c0.x() + dx * 0.50, _c0.y() + dy * 0.5);
        QPointF ctr3(_c1.x() + dx * 0.15, _c0.y() + dy * 0.5);
        QPointF ctr4(_c1.x() + dx * 0.15, _c1.y());

        p.cubicTo(ctr0, ctr1, ctr2);
        p.cubicTo(ctr3, ctr4, _c1);
    }


    setPath(p);

    return;
}

void Link::save(QDataStream &ds)
{

}

void Link::open(QDataStream &ds)
{

}

//Paint
QRectF Link::boundingRect() const
{
    return shape().boundingRect();
}

QPainterPath Link::shape() const
{
    QPainterPathStroker s;
    s.setWidth(5);
    return s.createStroke(path());
}

void Link::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QColor backColor = QColor(50,50,50);
    QColor mainColor = bColor(_p0->_mnType);
    if (blocked == true)
        mainColor = backColor;

    if (_p1 == 0)
        painter->setPen(QPen(mainColor, 3, Qt::DashLine, Qt::RoundCap, Qt::RoundJoin));
    else
        painter->setPen(QPen(mainColor, 3));

    if (_p1 != 0)
    {
        _c0 = _p0->scenePos();
        _c1 = _p1->scenePos();
    }

    QPainterPath p;
    p.moveTo(_c0);

    qreal dx = _c1.x() - _c0.x();
    qreal dy = _c1.y() - _c0.y();

    if (dx > 0)
    {
        QPointF ctr0(_c0.x() + dx * 0.45, _c0.y() + dy * 0.0);
        QPointF ctr1(_c0.x() + dx * 0.65, _c0.y() + dy * 1.0);

        p.cubicTo(ctr0, ctr1, _c1);
    }
    else
    {
        QPointF ctr0(_c0.x() - dx * 0.15, _c0.y());
        QPointF ctr1(_c0.x() - dx * 0.15, _c0.y() + dy * 0.5);
        QPointF ctr2(_c0.x() + dx * 0.50, _c0.y() + dy * 0.5);
        QPointF ctr3(_c1.x() + dx * 0.15, _c0.y() + dy * 0.5);
        QPointF ctr4(_c1.x() + dx * 0.15, _c1.y());

        p.cubicTo(ctr0, ctr1, ctr2);
        p.cubicTo(ctr3, ctr4, _c1);
    }


    painter->drawPath(p);
    if (isSelected())
    {
        painter->setPen(QPen(Qt::lightGray, 2));
        painter->drawPath(shape());
    }

    return;

}
