/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <cmath>

#include "hl_View.h"


using namespace hlGui;

View::View(QWidget *parent) : QGraphicsView(parent)
{
    setDragMode(QGraphicsView::ScrollHandDrag);
    setRenderHint(QPainter::Antialiasing);
    // setBackgroundBrush(Qt::black);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
    setCacheMode(QGraphicsView::CacheBackground); //FIXME: If uncommented, errors in grid
}

View::View(QGraphicsScene *scene, QWidget *parent) : View(parent)
{
    setScene(scene);
}

void View::drawBackground(QPainter* painter, const QRectF& r)
{
    QGraphicsView::drawBackground(painter, r);

    auto drawGrid = [&](double gridStep)
    {
        QRect   windowRect = rect();
        QPointF tl = mapToScene(windowRect.topLeft());
        QPointF br = mapToScene(windowRect.bottomRight());

        double left   = std::floor(tl.x() / gridStep - 0.5);
        double right  = std::floor(br.x() / gridStep + 1.0);
        double bottom = std::floor(tl.y() / gridStep - 0.5);
        double top    = std::floor(br.y() / gridStep + 1.0);

        //Vertical lines
        for (int xi = int(left); xi <= int(right); ++xi)
        {
            QLineF line(xi * gridStep, bottom * gridStep,
                        xi * gridStep, top * gridStep);
            painter->drawLine(line);
        }

        //Horizontal lines
        for (int yi = int(bottom); yi <= int(top); ++yi)
        {
            QLineF line(left * gridStep, yi * gridStep,
                        right * gridStep, yi * gridStep);
            painter->drawLine(line);
        }
    };

    QBrush bBrush = backgroundBrush();

    if (_drawGrid == true)
    {
        QPen pfine(QColor(20,20,20), 1.0);
        painter->setPen(pfine);
        drawGrid(40);

        QPen p(QColor(50,50,50), 1.0);
        painter->setPen(p);
        drawGrid(400);
    }

}

void View::toggleGrid()
{
    //Change status
    if (_drawGrid == true)
        _drawGrid = false;
    else
        _drawGrid = true;

    //Update view
    resetCachedContent();
}

void View::keyPressEvent(QKeyEvent *event)
{
    switch (event->key())
    {
        case Qt::Key_Shift:
            setDragMode(QGraphicsView::RubberBandDrag);
            break;
        case Qt::Key_Control:
            _zoomOn = true;
            break;

        default:
            break;
    }

    QGraphicsView::keyPressEvent(event);
}

void View::keyReleaseEvent(QKeyEvent *event)
{
    switch (event->key())
    {
        case Qt::Key_Shift:
            setDragMode(QGraphicsView::ScrollHandDrag);
            break;

        case Qt::Key_Control:
            _zoomOn = false;
            break;

        default:
            break;
    }
    QGraphicsView::keyReleaseEvent(event);
}


void View::mousePressEvent(QMouseEvent *event)
{
  QGraphicsView::mousePressEvent(event);
  if (event->button() == Qt::LeftButton)
  {
    _clickPos = mapToScene(event->pos());
  }
}


void View::mouseMoveEvent(QMouseEvent *event)
{
  QGraphicsView::mouseMoveEvent(event);
  if (scene()->mouseGrabberItem() == nullptr && event->buttons() == Qt::LeftButton)
  {
    // Make sure shift is not being pressed
    if ((event->modifiers() & Qt::ShiftModifier) == 0)
    {
      QPointF difference = _clickPos - mapToScene(event->pos());
      setSceneRect(sceneRect().translated(difference.x(), difference.y()));
    }
  }
}

void View::wheelEvent(QWheelEvent *event)
{
    if (event->modifiers() & Qt::ControlModifier)
    {
        QPoint delta = event->angleDelta();

        if (delta.y() == 0)
        {
            event->ignore();
            return;
        }

        double const d = delta.y() / std::abs(delta.y());

        if (d > 0.0)
            scaleUp();
        else
            scaleDown();
    }

    QGraphicsView::wheelEvent(event);
}

void View::scaleUp()
{
    double const step   = 1.2;
    double const factor = std::pow(step, 1.0);

    QTransform t = transform();

    if (t.m11() > 2.0)
        return;

    scale(factor, factor);
}

void View::scaleDown()
{
    double const step   = 1.2;
    double const factor = std::pow(step, -1.0);

    scale(factor, factor);
}


// void View::mousePressEvent(QMouseEvent *me)
// {
//     if (me->button() == Qt::MiddleButton)
//     {
//         setDragMode(QGraphicsView::ScrollHandDrag);
//     }

//     QGraphicsView::mousePressEvent(me);
// }

// void View::mouseReleaseEvent(QMouseEvent *me)
// {
//     if (me->button() == Qt::MiddleButton)
//     {
//         setDragMode(QGraphicsView::RubberBandDrag);
//     }

//     QGraphicsView::mousePressEvent(me);
// }
