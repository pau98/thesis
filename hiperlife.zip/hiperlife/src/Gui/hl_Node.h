/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef hl_NODE_H
#define hl_NODE_H

// Trilinos headers
#include <Teuchos_RCP.hpp>

// hiperlife headers
#include "hl_TypeDefs.h"
#include "hl_Geometry.h"
#include "hl_StructMeshGenerator.h"
#include "hl_MeshLoader.h"
#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"

// Qt headers
#include <QGraphicsPathItem>
#include <QGraphicsItem>
#include <QLabel>
#include <QWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QCheckBox>
#include <QPushButton>
//#include <QGridLayout>
#include <QHBoxLayout>

#include "hl_GuiTypes.h"

namespace hlGui
{

    class Port;
    class Link;
    class Node : public QObject, public QGraphicsPathItem
    {

            Q_OBJECT
        public:
            enum {Type = QGraphicsItem::UserType + 15};

            Node(NodeType nType, QGraphicsItem *parent = 0);

            inline void setNameNumber(int n){_nameNumber = n;};

            void Update();

            int type() const override {return Type;};

            virtual QRectF boundingRect() const;
            QPainterPath shape() const;
            void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);


            NodeType _nType;
            MetaNodeType _mnType;

            QLineEdit *_name;
            QWidget *_nameWidget;
            QWidget *_mainWidget;
            QWidget *_bWidget;
            QPushButton *hambButton;
            QPushButton *delButton;
            QPushButton *hideButton;
            QPushButton *blockButton;

            QVector<QString> _data;
            QVector<QString> _headers;
            QVector<QString> _headers2;
            QVector<Port*> inPorts;
            Port* outPort;
            bool blocked{false};

            bool run();
            void save(QDataStream &ds);

            Teuchos::RCP<hiperlife::StructMeshGenerator> structMesh = Teuchos::null;
            Teuchos::RCP<hiperlife::MeshLoader> loadMesh = Teuchos::null;
            Teuchos::RCP<hiperlife::DistributedMesh> disMesh = Teuchos::null;

        signals:
            void dataUpdated();
            void visibilityChanged();
            void warnDiag(QString title, QString text);
            void updateVtk();
            void viewSolution(QString fPrefix);

        public slots:
            void _updateAllInfo();
            void _updateData();
            void block(bool v);

        private slots:
            void _updateConnected();
            void _visibility(bool v);
            void _updateDOFs();
            void _disableDOFs();
            void _updateBC();

        private:
            double _height{100};
            double _width{240};
            int _nameNumber{};

            void _createLabel();
            void _createMainWidget();
            void _createPorts();
            Port* _createPort(PortType pType, NodeType nType, int n);
            void _updateInPortPosition();
            void _browseSave(QLineEdit *lEdit);
            void _browseOpen(QLineEdit *lEdit);
            void _paraview(QString fname);

            QVBoxLayout *mainLayout;
            QComboBox *elemBox;
            QComboBox *bfBox;
            QComboBox *genBox;
            QLineEdit *orderLEdit;
            QLineEdit *fileLEdit;
            QLineEdit *nExLEdit, *nEyLEdit, *nEzLEdit;
            QVector<QLineEdit*> gOptLEdit;
            QCheckBox *balCheckBox;
            QLineEdit *hLEdit, *pLEdit;
            QLineEdit *dofsLEdit;
            QVector<QLineEdit *> dnamLEdits;
            QVector<QHBoxLayout *> dnamLayouts;
            int nDOFs_old{};
            QVector<QLabel*> dLabels;
            QVector<QComboBox*> iTypeBox;
            QVector<QHBoxLayout *> iTypeLayouts;
            QComboBox *dbcBox;
            QComboBox *maxisBox;
            QLineEdit *bcLEdit;
            QLineEdit *nAuxLEdit;
            QLineEdit *eAuxLEdit;
            QLineEdit *iLEdit, *sLEdit;
            QComboBox *solBox;
            QComboBox *precBox;
            QComboBox *subBox;
            QComboBox *outBox;
            QLineEdit *tolLEdit;
            QLineEdit *iterLEdit;
            QComboBox *preBox;
            QLineEdit *weakLEdit;
            QLineEdit *rhsLEdit;
            QLineEdit *lhsLEdit;

        protected:


    };
}
#endif
