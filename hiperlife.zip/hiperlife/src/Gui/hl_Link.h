/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef hl_LINK_H
#define hl_LINK_H

#include <QGraphicsPathItem>
#include <QGraphicsItem>
#include <QLabel>
#include <QWidget>

#include "hl_GuiTypes.h"
#include "hl_Port.h"

namespace hlGui
{
    // class Port;
    class Link : public QGraphicsPathItem
    {

        public:
            enum {Type = UserType + 2};

            Link(QGraphicsItem *Parent = 0);

            void setPort0(Port *p0);
            void setPort1(Port *p1);
            void setCoords0(const QPointF &c0){_c0 = c0;};
            void setCoords1(const QPointF &c1){_c1 = c1;};
            void setLink(Port *p0, Port *p1);

            virtual QRectF boundingRect() const;
            QPainterPath shape() const;
            void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
            void Update();
            inline QPointF Coords0(){return _c0;};
            inline QPointF Coords1(){return _c1;};

            inline void block(bool b){blocked = b;};

            Port *_p0 = 0;
            Port *_p1 = 0;
            QPointF _c0;
            QPointF _c1;
            bool blocked{false};

            void save(QDataStream &ds);
            void open(QDataStream &ds);

            int type() const override {return Type;};

        public slots:

        private:

        protected:

    };
}
#endif
