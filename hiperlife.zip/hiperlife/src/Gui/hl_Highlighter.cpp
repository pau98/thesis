/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

/****************************************************************************
 **
 ** Copyright (C) 2016 The Qt Company Ltd.
 ** Contact: https://www.qt.io/licensing/
 **
 ** This file is part of the examples of the Qt Toolkit.
 **
 ** $QT_BEGIN_LICENSE:BSD$
 ** Commercial License Usage
 ** Licensees holding valid commercial Qt licenses may use this file in
 ** accordance with the commercial license agreement provided with the
 ** Software or, alternatively, in accordance with the terms contained in
 ** a written agreement between you and The Qt Company. For licensing terms
 ** and conditions see https://www.qt.io/terms-conditions. For further
 ** information use the contact form at https://www.qt.io/contact-us.
 **
 ** BSD License Usage
 ** Alternatively, you may use this file under the terms of the BSD license
 ** as follows:
 **
 ** "Redistribution and use in source and binary forms, with or without
 ** modification, are permitted provided that the following conditions are
 ** met:
 **   * Redistributions of source code must retain the above copyright
 **     notice, this list of conditions and the following disclaimer.
 **   * Redistributions in binary form must reproduce the above copyright
 **     notice, this list of conditions and the following disclaimer in
 **     the documentation and/or other materials provided with the
 **     distribution.
 **   * Neither the name of The Qt Company Ltd nor the names of its
 **     contributors may be used to endorse or promote products derived
 **     from this software without specific prior written permission.
 **
 **
 ** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 ** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 ** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 ** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 ** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 ** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 ** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 ** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 ** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 ** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 ** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
 **
 ** $QT_END_LICENSE$
 **
 ****************************************************************************/


#include "hl_Highlighter.h"
// using namespace hiperlife;


Highlighter::Highlighter(QTextDocument *parent)
    : QSyntaxHighlighter(parent)
{
    HighlightingRule rule;

    //c++ declarations and classes
    keywordFormat.setForeground(QColor("#007100"));
    QStringList keywordPatterns;
    keywordPatterns << "\\bchar\\b" << "\\bclass\\b" << "\\bconst\\b"
                    << "\\bdouble\\b" << "\\benum\\b" << "\\bexplicit\\b"
                    << "\\bfriend\\b" << "\\binline\\b" << "\\bint\\b"
                    << "\\blong\\b" << "\\boperator\\b" << "\\bvector\\b"
                    << "\\bprivate\\b" << "\\bprotected\\b" << "\\bpublic\\b"
                    << "\\bshort\\b" << "\\bsignals\\b" << "\\bsigned\\b"
                    << "\\bslots\\b" << "\\bstatic\\b" << "\\bstruct\\b"
                    << "\\btemplate\\b" << "\\btypedef\\b" << "\\btypename\\b"
                    << "\\bunion\\b" << "\\bunsigned\\b" << "\\bvirtual\\b"
                    << "\\bvoid\\b" << "\\bvolatile\\b" << "\\bbool\\b"
                    << "\\bMeshLoader\\b" << "\\bStructMeshGenerator\\b"
                    << "\\bUnstructGmshMeshGenerator\\b" << "\\bUnstructVtkMeshGenerator\\b"
                    << "\\bDistributedMesh\\b" << "\\bDOFsHandler\\b"
                    << "\\bHiPerProblem\\b" << "\\bFillStructure\\b"
                    << "\\bSubFillStructure\\b"
                    << "\\bRCP\\b" << "\\brcp\\b";

    foreach (const QString &pattern, keywordPatterns)
    {
        rule.pattern = QRegularExpression(pattern);
        rule.format = keywordFormat;
        highlightingRules.append(rule);
    }


    //c++ key words
    keyword2Format.setForeground(QColor("#A100FB"));
    QStringList keyword2Patterns;
    keyword2Patterns << "\\bnew\\b" << "\\breturn\\b" << "\\bauto\\b"
                     << "\\bcout\\b" << "\\bendl\\b"
                     << "\\busing\\b" << "\\bnew\\b"
                     << "\\bnamespace\\b" << "\\b\\b"
                     << "\\bfor\\b" << "\\bif\\b";

    foreach (const QString &pattern, keyword2Patterns)
    {
        rule.pattern = QRegularExpression(pattern);
        rule.format = keyword2Format;
        highlightingRules.append(rule);
    }

    //Q+sth
    classFormat.setFontWeight(QFont::Bold);
    classFormat.setForeground(Qt::darkMagenta);
    rule.pattern = QRegularExpression("\\bQ[A-Za-z]+\\b");
    rule.format = classFormat;
    highlightingRules.append(rule);

    //Enums
    enumFormat.setForeground(QColor("#06989A"));
    rule.pattern = QRegularExpression("\\b[A-Za-z]+(?=::)");
    rule.format = enumFormat;
    highlightingRules.append(rule);
    rule.pattern = QRegularExpression("\\b[0-9.]\\b");
    rule.format = enumFormat;
    highlightingRules.append(rule);

    //Between quotes or <>
    quotationFormat.setForeground(QColor("#84005B"));
    // rule.pattern = QRegularExpression("\".*\"");
    rule.pattern = QRegularExpression("\"\\b(\\w*\\w*)\\b\"");
    rule.format = quotationFormat;
    highlightingRules.append(rule);
    rule.pattern = QRegularExpression(" <.*>");
    rule.format = quotationFormat;
    highlightingRules.append(rule);

    //Declarations
    declarationFormat.setForeground(QColor("#C46300"));
    rule.pattern = QRegularExpression("\\b[A-Za-z0-9_]+(?= =)");
    rule.format = declarationFormat;
    highlightingRules.append(rule);
    rule.pattern = QRegularExpression("\\b[A-Za-z0-9_]+(?==)");
    rule.format = declarationFormat;
    highlightingRules.append(rule);
    // rule.pattern = QRegularExpression("\\b[A-Za-z0-9_]+(?=->)");
    // rule.format = declarationFormat;
    // highlightingRules.append(rule);

    // //Functions
    // functionFormat.setFontItalic(true);
    // functionFormat.setForeground(Qt::blue);
    // rule.pattern = QRegularExpression("\\b[A-Za-z0-9_]+(?=\\()");
    // rule.format = functionFormat;
    // highlightingRules.append(rule);



    //Directives
    directiveFormat.setForeground(QColor("#5F5F87"));
    rule.pattern = QRegularExpression("^#\\b(\\w*\\w*)\\b");
    rule.format = directiveFormat;
    highlightingRules.append(rule);


    //Single line comments
    singleLineCommentFormat.setForeground(QColor("#A50000"));
    rule.pattern = QRegularExpression("//[^\n]*");
    rule.format = singleLineCommentFormat;
    highlightingRules.append(rule);

    multiLineCommentFormat.setForeground(QColor("#A50000"));
    commentStartExpression = QRegularExpression("/\\*");
    commentEndExpression = QRegularExpression("\\*/");
}

void Highlighter::highlightBlock(const QString &text)
{
    foreach (const HighlightingRule &rule, highlightingRules)
    {
        QRegularExpressionMatchIterator matchIterator = rule.pattern.globalMatch(text);
        while (matchIterator.hasNext())
        {
            QRegularExpressionMatch match = matchIterator.next();
            setFormat(match.capturedStart(), match.capturedLength(), rule.format);
        }
    }
    setCurrentBlockState(0);

    int startIndex = 0;
    if (previousBlockState() != 1)
        startIndex = text.indexOf(commentStartExpression);

    while (startIndex >= 0)
    {
        QRegularExpressionMatch match = commentEndExpression.match(text, startIndex);
        int endIndex = match.capturedStart();
        int commentLength = 0;
        if (endIndex == -1)
        {
            setCurrentBlockState(1);
            commentLength = text.length() - startIndex;
        }
        else
        {
            commentLength = endIndex - startIndex + match.capturedLength();
        }
        setFormat(startIndex, commentLength, multiLineCommentFormat);
        startIndex = text.indexOf(commentStartExpression, startIndex + commentLength);
    }
}
