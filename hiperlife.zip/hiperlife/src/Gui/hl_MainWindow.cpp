/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

// hiperlife headers
#include "hl_MeshCreator.h"

// Qt headers
#include <QTextStream>

//GUI headers
#include "hl_MainWindow.h"
#include "hl_Highlighter.h"

using namespace hlGui;

MainWindow::MainWindow(appStyle st, QWidget *parent) : QMainWindow(parent)
{
    //Save style
    _st = st;

    //Reload last settings
    _readSettings();

    //Create main objects
    _scene = new Scene();
    _view = new View(_scene);

    //Undo
    undoStack = new QUndoStack(this);

    //Create actions
    _createGeneralActions();
    _createNodeActions2();
    _createModelActions();

    //Create docks
    _createDocks();

    //Create menus
    _createMenuBar2();
    _createNodeBar7();
    _createStatusBar();

    // //Inner window
    // QMainWindow* _viewMain = new QMainWindow(_view);
    // _viewMain->setWindowFlags(Qt::Widget);
    // _viewMain->addToolBar(Qt::TopToolBarArea, _nodeBar);
    // _viewMain->setCentralWidget(_viewMain);
    // setCentralWidget(_viewMain);
    // QWidget *q = new QWidget();
    // q->addT

    QMainWindow* _viewMain = new QMainWindow();
    _viewMain->setWindowFlags(Qt::Widget);
    _viewMain->addToolBar(Qt::LeftToolBarArea, _nodeBar);
    _viewMain->addToolBarBreak(Qt::LeftToolBarArea);
    _viewMain->addToolBar(Qt::LeftToolBarArea, _nodeBar2);
    _viewMain->setCentralWidget(_view);
    setCentralWidget(_viewMain);

    //Connections
    connect(_scene, SIGNAL(allDataUpdated(QVector<QString>)), this, SLOT(_updateEditor(QVector<QString>)));
    connect(_scene, SIGNAL(meshCreatorUpdated(Teuchos::RCP<hiperlife::MeshCreator>)), _vWidget, SLOT(loadFromMeshCreator(Teuchos::RCP<hiperlife::MeshCreator>)));
    connect(_scene, SIGNAL(vSolution(QString)), _vWidget, SLOT(loadFromFile(QString)));

    setUnifiedTitleAndToolBarOnMac(true);
}

void MainWindow::_createGeneralActions()
{
    //New
    _newAct = new QAction("&New", this);
    _newAct->setShortcut(QKeySequence::New);
    _newAct->setEnabled(false);

    //Open
    const QIcon openIcon = QIcon::fromTheme("document-new", QIcon(":/images/new.png"));
    _openAct = new QAction(openIcon, "&Open", this);
    _openAct->setShortcut(QKeySequence::Open);
    connect(_openAct, &QAction::triggered, this, &MainWindow::_open);

    //Open recent
    _openRAct = new QAction("&Open recent", this);
    _openRAct->setEnabled(false);

    //Save
    _saveAct = new QAction("&Save", this);
    _saveAct->setShortcut(QKeySequence::Save);
    connect(_saveAct, &QAction::triggered, this, &MainWindow::_save);

    //Save as
    _saveAsAct = new QAction("&Save as...", this);
    _saveAsAct->setShortcut(QKeySequence::SaveAs);
    _saveAsAct->setEnabled(false);

    //Save a copy
    _saveCpAct = new QAction("&Save a copy...", this);
    _saveCpAct->setShortcut(QKeySequence("Shift+Ctrl+Alt+S"));
    _saveCpAct->setEnabled(false);

    //Import
    _impAct = new QAction("&Import...", this);
    _impAct->setShortcut(QKeySequence("Ctrl+I"));
    _impAct->setEnabled(false);

    //Close
    _cloAct = new QAction("&Close", this);
    _cloAct->setShortcut(QKeySequence::Close);
    _cloAct->setEnabled(false);

    //Quit
    _quitAct = new QAction("&Quit", this);
    _quitAct->setShortcut(QKeySequence::Quit);
    connect(_quitAct, &QAction::triggered, qApp, &QApplication::quit);

    //Undo
    _undoAct = undoStack->createUndoAction(this, tr("&Undo"));
    _undoAct->setShortcuts(QKeySequence::Undo);
    _undoAct->setStatusTip(tr("Undo the last editing action."));
    // connect(_undoAct, &QAction::triggered, this, &MainWindow::undo);

    //Redo
    _redoAct = undoStack->createRedoAction(this, tr("&Redo"));
    _redoAct->setShortcuts(QKeySequence::Redo);
    _redoAct->setStatusTip(tr("Redo the last editing action."));
    // connect(_redoAct, &QAction::triggered, this, &MainWindow::redo);

    //SelectAll
    _selAllAct = new QAction(tr("&Select all"), this);
    _selAllAct->setShortcuts(QKeySequence::SelectAll);
    _selAllAct->setStatusTip(tr("Select all items."));
    connect(_selAllAct, &QAction::triggered, _scene, &Scene::selectAllNodes);

    //Delete
    _delAct = new QAction(tr("&Delete selected item(s)"), this);
    _delAct->setShortcuts(QKeySequence::Delete);
    _delAct->setStatusTip(tr("Delete selected item(s)."));
    connect(_delAct, &QAction::triggered, _scene, &Scene::deleteItems);

    //Block
    _blockAct = new QAction(tr("&Block selected node(s)"), this);
    _blockAct->setShortcut(QKeySequence("Ctrl+B"));
    _blockAct->setStatusTip(tr("Block selected node(s)."));
    connect(_blockAct, &QAction::triggered, _scene, &Scene::blockNodes);

    //Block
    _ublockAct = new QAction(tr("&Unblock selected node(s)"), this);
    _ublockAct->setShortcut(QKeySequence("Ctrl+Shift+B"));
    _ublockAct->setStatusTip(tr("Unblock selected node(s)."));
    connect(_ublockAct, &QAction::triggered, _scene, &Scene::unblockNodes);

    //Preferences
    _prefAct = new QAction("&Preferences...", this);
    _prefAct->setDisabled(true);

    //Collapse
    _collapAllAct = new QAction("&Collapse all", this);
    _collapAllAct->setStatusTip(tr("Collapse all items."));
    connect(_collapAllAct, &QAction::triggered, _scene, [=](){_scene->toggleVisAllItems(true);});

    //Expand
    _expandAllAct = new QAction("&Expand all", this);
    _expandAllAct->setStatusTip(tr("Collapse all items."));
    connect(_expandAllAct, &QAction::triggered, _scene, [=](){_scene->toggleVisAllItems(false);});
    // connect(_expandAllAct, SIGNAL(triggered()), _scene, SLOT(expandAllItems()));

    //Grid
    _vGridAct = new QAction("&Grid", this);
    _vGridAct->setCheckable(true);
    _vGridAct->setChecked(false);
    _vGridAct->setShortcut(QKeySequence("#"));
    _vGridAct->setStatusTip(tr("Toggle view of background grid."));
    connect(_vGridAct, SIGNAL(triggered()), _view, SLOT(toggleGrid()));


    /*--------------------------- Code ----------------------------*/

    //compile
    _compCodeAct = new QAction("&Compile", this);
    _compCodeAct->setShortcut(QKeySequence("F4"));
    connect(_compCodeAct, SIGNAL(triggered()), this, SLOT(_compile()));

    //run1
    _runCodeAct = new QAction("&Run", this);
    _runCodeAct->setShortcut(QKeySequence("Ctrl+r"));
    _runCodeAct->setDisabled(true);
    connect(_runCodeAct, SIGNAL(triggered()), this, SLOT(_run()));

    //run2
    _runExtCodeAct = new QAction("&Run externally", this);
    _runExtCodeAct->setShortcut(QKeySequence("F5"));
    connect(_runExtCodeAct, SIGNAL(triggered()), this, SLOT(_runExt()));
}

void MainWindow::_createNodeActions()
{
    //QActiongroup
    _nodeActs = new QActionGroup(this);

    //Mesh creator
    _structAct = new QAction("&Structured mesh creator", this);
    connect(_structAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::StructMeshGenerator);});
    _nodeActs->addAction(_structAct);
    _loadAct = new QAction("&Mesh loader", this);
    _loadAct->setShortcut(QKeySequence("Ctrl+1"));
    _loadAct->setStatusTip(tr("Add a mesh loader."));
    connect(_loadAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::MeshLoader);});
    _nodeActs->addAction(_loadAct);
    _gmshAct = new QAction("&Unstructured creator (Gmsh)", this);
    _gmshAct->setDisabled(true);
    _vtkAct = new QAction("&Unstructured creator (VTK)", this);
    _vtkAct->setDisabled(true);

    //Distributed mesh
    _disStdAct = new QAction("&Standard", this);
    _disStdAct->setShortcut(QKeySequence("Ctrl+2"));
    _disStdAct->setStatusTip(tr("Add a distributed mesh."));
    connect(_disStdAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::DistributedMesh);});
    _nodeActs->addAction(_disStdAct);
    _disHAct = new QAction("&h-refined", this);
    _disHAct->setStatusTip(tr("Add a h-refined distributed mesh."));
    connect(_disHAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::hDistributedMesh);});
    _nodeActs->addAction(_disHAct);
    _disPAct = new QAction("&p-refined", this);
    _disPAct->setStatusTip(tr("Add a p-refined distributed mesh."));
    connect(_disPAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::pDistributedMesh);});
    _nodeActs->addAction(_disPAct);

    //DOFs handler
    _dHandAct = new QAction("&DOFs Handler", this);
    _dHandAct->setShortcut(QKeySequence("Ctrl+3"));
    _dHandAct->setStatusTip(tr("Add a DOFs handler."));
    connect(_dHandAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::DOFsHandler);});
    _nodeActs->addAction(_dHandAct);
    _icAct = new QAction("&Initial conditions", this);
    connect(_icAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::InitialConditions);});
    _nodeActs->addAction(_icAct);
    _bcAct = new QAction("&Boundary conditions", this);
    connect(_bcAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::BoundaryConditions);});
    _nodeActs->addAction(_bcAct);


    //Integration
    _intAct = new QAction("&Integration", this);
    connect(_intAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::Integration);});
    _nodeActs->addAction(_intAct);


    //Cubature
    _gauAct = new QAction("&Gauss", this);
    connect(_gauAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::GaussCubature);});
    _nodeActs->addAction(_gauAct);
    _bgauAct = new QAction("&Border gauss", this);
    connect(_bgauAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::BorderGaussCubature);});
    _nodeActs->addAction(_bgauAct);
    _subAct = new QAction("&Subdivision", this);
    connect(_subAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::SubdivCubature);});
    _nodeActs->addAction(_subAct);

    //Filling
    _preFillAct = new QAction("&Predefined", this);
    connect(_preFillAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::preEFilling);});
    _nodeActs->addAction(_preFillAct);
    _ralFillAct = new QAction("&RHS && LHS form", this);
    connect(_ralFillAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::ralEFilling);});
    _nodeActs->addAction(_ralFillAct);
    _weaFillAct = new QAction("&Weak form", this);
    connect(_weaFillAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::weaEFilling);});
    _nodeActs->addAction(_weaFillAct);
    _onsFillAct = new QAction("&Onsager", this);
    connect(_onsFillAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::onsEFilling);});
    _nodeActs->addAction(_onsFillAct);
    _usrFillAct = new QAction("&User-defined", this);
    connect(_usrFillAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::usrEFilling);});
    _nodeActs->addAction(_usrFillAct);

    //Fill structure
    _rhsFStrAct = new QAction("&Right hand side", this);
    connect(_rhsFStrAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::RightHandSide);});
    _nodeActs->addAction(_rhsFStrAct);
    _lhsFStrAct = new QAction("&Left hand side", this);
    connect(_lhsFStrAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::LeftHandSide);});
    _nodeActs->addAction(_lhsFStrAct);
    _eFStrAct = new QAction("&Free energy", this);
    connect(_eFStrAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::FreeEnergy);});
    _nodeActs->addAction(_eFStrAct);
    _dFStrAct = new QAction("&Dissipation", this);
    connect(_dFStrAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::Dissipation);});
    _nodeActs->addAction(_dFStrAct);
    _piFStrAct = new QAction("&Power input", this);
    connect(_piFStrAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::PowerInput);});
    _nodeActs->addAction(_piFStrAct);
    _poFStrAct = new QAction("&Process operator", this);
    connect(_poFStrAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::ProcessOperator);});
    _nodeActs->addAction(_poFStrAct);
    _lmFStrAct = new QAction("&Lagrange multiplier", this);
    connect(_lmFStrAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::LangrageMultiplier);});
    _nodeActs->addAction(_lmFStrAct);

    //Linear system
    _lSystemAct = new QAction("&Linear system", this);
    connect(_lSystemAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::HiPerProblem);});
    _nodeActs->addAction(_lSystemAct);
    _azSolverAct = new QAction("&AztecOO solver", this);
    connect(_azSolverAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::AZSolver);});
    _nodeActs->addAction(_azSolverAct);
    _belSolverAct = new QAction("&Belos solver", this);
    _belSolverAct->setDisabled(true);
    _amSolverAct = new QAction("&Amesos solver", this);
    _amSolverAct->setDisabled(true);

    //Non-linear system
    _nlSystemAct = new QAction("&Non-linear system", this);
    _nodeActs->addAction(_nlSystemAct);
    _nlSystemAct->setDisabled(true);
    _NRSolverAct = new QAction("&Newton-Raphson solver", this);
    _NRSolverAct->setDisabled(true);
    _LSSolverAct = new QAction("&Line search solver", this);
    _LSSolverAct->setDisabled(true);

    //Time
    _staAct = new QAction("&Constant time step", this);
    _nodeActs->addAction(_staAct);
    _staAct->setDisabled(true);
    _adapAct = new QAction("&Adaptive time step", this);
    _adapAct->setDisabled(true);
    _alphaAct = new QAction("&Generalized-alpha", this);
    _alphaAct->setDisabled(true);

    //Solve
    _solveAct = new QAction("&Solve", this);
    connect(_solveAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::Solve);});
    _nodeActs->addAction(_solveAct);

    //Output
    _stdOutAct = new QAction("&Standard output", this);
    connect(_stdOutAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::OutputH);});
    _nodeActs->addAction(_stdOutAct);
    _vtkOutAct = new QAction("&Output to legacy VTK", this);
    connect(_vtkOutAct, &QAction::triggered, _scene, [=](){_scene->createNode(NodeType::OutputVtk);});
    _nodeActs->addAction(_vtkOutAct);
    _csvOutAct = new QAction("&Output to CSV", this);
    _nodeActs->addAction(_csvOutAct);
    _csvOutAct->setDisabled(true);

    //Wildcard
    _udAct = new QAction("&User-defined node", this);
    _udAct->setDisabled(true);


    //Category Buttons
    QVector<SupraNodeType> snTypes(12);
    snTypes[0] = SupraNodeType::MeshCreator;
    snTypes[1] = SupraNodeType::DistributedMesh;
    snTypes[2] = SupraNodeType::DOFsHandler;
    snTypes[3] = SupraNodeType::Integration;
    snTypes[4] = SupraNodeType::Cubature;
    snTypes[5] = SupraNodeType::ElemFilling;
    snTypes[6] = SupraNodeType::FillStruct;
    snTypes[7] = SupraNodeType::LinearSystem;
    snTypes[8] = SupraNodeType::NonLinearSystem;
    snTypes[9] = SupraNodeType::TimeIterators;
    snTypes[10] = SupraNodeType::Solve;
    snTypes[11] = SupraNodeType::Output;
    QVector<QToolButton*> bCat;
    int b{};
    for (int i = 0; i < snTypes.size(); i++)
    {
        //Buttons
        QVector<NodeType> nType = nodeType(snTypes[i]);
        for (int j = 0; j < nType.size(); j++)
        {
            //Add icon
            QString iconName = QString::number(b);
            if (b < 10)
                iconName.prepend(":/img/node_0");
            else
                iconName.prepend(":/img/node_");
            iconName.append(".svg");
            _nodeActs->actions()[b]->setIcon(QPixmap(iconName));

            //Increase
            b++;
        }
    }

}

void MainWindow::_createNodeActions2()
{
    //QActiongroup
    _nodeActs = new QActionGroup(this);

    //Category Buttons
    QVector<SupraNodeType> snTypes(12);
    snTypes[0] = SupraNodeType::MeshCreator;
    snTypes[1] = SupraNodeType::DistributedMesh;
    snTypes[2] = SupraNodeType::DOFsHandler;
    snTypes[3] = SupraNodeType::Integration;
    snTypes[4] = SupraNodeType::Cubature;
    snTypes[5] = SupraNodeType::ElemFilling;
    snTypes[6] = SupraNodeType::FillStruct;
    snTypes[7] = SupraNodeType::LinearSystem;
    snTypes[8] = SupraNodeType::NonLinearSystem;
    snTypes[9] = SupraNodeType::TimeIterators;
    snTypes[10] = SupraNodeType::Solve;
    snTypes[11] = SupraNodeType::Output;
    int b{};
    for (int i = 0; i < snTypes.size(); i++)
    {
        //Buttons
        QVector<NodeType> nType = nodeType(snTypes[i]);
        for (int j = 0; j < nType.size(); j++)
        {
            //Icon name
            QString iconName = QString::number(b);
            if (b < 10)
                iconName.prepend(":/img/node_0");
            else
                iconName.prepend(":/img/node_");
            iconName.append(".svg");

            //Create action
            QAction *act = new QAction(qstr(nType[j]), this);
            // act->setShortcut(QKeySequence("Ctrl+2"));
            act->setToolTip(qstr(nType[j]));
            act->setStatusTip(qstr(nType[j]));
            act->setIcon(QPixmap(iconName));
            connect(act, &QAction::triggered, this, [=](){this->_createNode(nType[j]);});
            if ((b >= 2 and b <= 4) or b == 10 or (b >= 29 and b <= 36) or b == 40)
                act->setDisabled(true);

            //Add to action group
            _nodeActs->addAction(act);

            //Increase
            b++;
        }
    }

}

void MainWindow::_createModelActions()
{
    //Standard model
    _stdModAct = new QAction("&Standard", this);
    _stdModAct->setShortcut(QKeySequence("Ctrl+m"));
    connect(_stdModAct, &QAction::triggered, this, [=](){this->_loadModel("std");});
    _neuModAct = new QAction("&Neuman boundary conditions", this);
    connect(_neuModAct, &QAction::triggered, this, [=](){this->_loadModel("neu");});
    _gcModAct = new QAction("&Global constraint", this);
    _gcModAct->setDisabled(true);
    _lmModAct = new QAction("&Lagrange multipliers", this);
    connect(_lmModAct, &QAction::triggered, this, [=](){this->_loadModel("lm");});

    //Save model
    _saveModAct = new QAction("&Save model", this);
    _saveModAct->setShortcut(QKeySequence("Shift+Ctrl+M"));
    connect(_saveModAct, SIGNAL(triggered()), this, SLOT(_saveModel()));

    //Poisson tut
    _pTutAct = new QAction("&Poisson", this);
    connect(_pTutAct, &QAction::triggered, _scene, [=](){
            _scene->createNode(NodeType::StructMeshGenerator);
            _scene->createNode(NodeType::DistributedMesh);
            _scene->createNode(NodeType::DOFsHandler);
            _scene->createNode(NodeType::Integration);
            _scene->createNode(NodeType::GaussCubature);
            _scene->createNode(NodeType::preEFilling);
            _scene->createNode(NodeType::AZSolver);
            _scene->createNode(NodeType::HiPerProblem);
            _scene->createNode(NodeType::Solve);
        });

    //Cahn-Hilliard tut
    _chTutAct = new QAction("&Cahn-Hilliard", this);
    _chTutAct->setDisabled(true);
}

void MainWindow::_createMenuBar()
{
    //File
    QMenu *_fileMenu = menuBar()->addMenu(tr("&File"));
    _fileMenu->addAction(_newAct);
    _fileMenu->addAction(_openAct);
    _fileMenu->addAction(_openRAct);
    _fileMenu->addAction(_saveAct);
    _fileMenu->addAction(_saveAsAct);
    _fileMenu->addAction(_saveCpAct);
    _fileMenu->addSeparator();
    _fileMenu->addAction(_impAct);
    _fileMenu->addSeparator();
    _fileMenu->addAction(_cloAct);
    _fileMenu->addAction(_quitAct);

    //Edit
    QMenu *_editMenu = menuBar()->addMenu(tr("&Edit"));
    _editMenu->addAction(_undoAct);
    _editMenu->addAction(_redoAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_selAllAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_delAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_blockAct);
    _editMenu->addAction(_ublockAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_prefAct);

    //View
    QMenu *_viewMenu = menuBar()->addMenu(tr("&View"));
    _viewMenu->addAction(_collapAllAct);
    _viewMenu->addAction(_expandAllAct);
    _viewMenu->addSeparator();
    _viewMenu->addAction(_cDock->toggleViewAction());
    _viewMenu->addAction(_lDock->toggleViewAction());
    _viewMenu->addAction(_vGridAct);

    //Code
    QMenu * _codeMenu = menuBar()->addMenu(tr("&Code"));
    _codeMenu->addAction(_compCodeAct);
    _codeMenu->addAction(_runCodeAct);
    _codeMenu->addAction(_runExtCodeAct);

    //Node
    QMenu *_nodeMenu = menuBar()->addMenu(tr("&Nodes"));
    QMenu *_meshCreaMenu = _nodeMenu->addMenu("Mesh creator");
    _meshCreaMenu->addAction(_loadAct);
    _meshCreaMenu->addAction(_structAct);
    _meshCreaMenu->addAction(_gmshAct);
    _meshCreaMenu->addAction(_vtkAct);
    QMenu *_disMeshMenu = _nodeMenu->addMenu("Distributed mesh");
    _disMeshMenu->addAction(_disStdAct);
    _disMeshMenu->addAction(_disHAct);
    _disMeshMenu->addAction(_disPAct);
    QMenu *_dHandMenu = _nodeMenu->addMenu("Degrees of freedom");
    _dHandMenu->addAction(_dHandAct);
    _dHandMenu->addSeparator();
    _dHandMenu->addAction(_icAct);
    _dHandMenu->addAction(_bcAct);
    _nodeMenu->addAction(_intAct);
    QMenu *_cubaMenu = _nodeMenu->addMenu("Cubature");
    _cubaMenu->addAction(_gauAct);
    _cubaMenu->addAction(_bgauAct);
    _cubaMenu->addAction(_subAct);
    QMenu *_fillMenu = _nodeMenu->addMenu("Element filling");
    _fillMenu->addAction(_preFillAct);
    _fillMenu->addAction(_ralFillAct);
    _fillMenu->addAction(_weaFillAct);
    _fillMenu->addAction(_onsFillAct);
    _fillMenu->addAction(_usrFillAct);
    QMenu *_fStrMenu = _nodeMenu->addMenu("Fill structure");
    _fStrMenu->addAction(_rhsFStrAct);
    _fStrMenu->addAction(_lhsFStrAct);
    _fStrMenu->addSeparator();
    _fStrMenu->addAction(_eFStrAct);
    _fStrMenu->addAction(_dFStrAct);
    _fStrMenu->addAction(_piFStrAct);
    _fStrMenu->addAction(_poFStrAct);
    _fStrMenu->addAction(_lmFStrAct);
    QMenu *_lSystemMenu = _nodeMenu->addMenu("Linear system");
    _lSystemMenu->addAction(_lSystemAct);
    _lSystemMenu->addSeparator();
    _lSystemMenu->addAction(_azSolverAct);
    _lSystemMenu->addAction(_belSolverAct);
    _lSystemMenu->addAction(_amSolverAct);
    QMenu *_nlSystemMenu = _nodeMenu->addMenu("Non-linear system");
    _nlSystemMenu->addAction(_nlSystemAct);
    _nlSystemMenu->addSeparator();
    _nlSystemMenu->addAction(_NRSolverAct);
    _nlSystemMenu->addAction(_LSSolverAct);
    QMenu *_timeMenu = _nodeMenu->addMenu("Time iterators");
    _timeMenu->addAction(_staAct);
    _timeMenu->addAction(_adapAct);
    _timeMenu->addAction(_alphaAct);
    _nodeMenu->addAction(_solveAct);
    QMenu *_outMenu = _nodeMenu->addMenu("Output");
    _outMenu->addAction(_stdOutAct);
    _outMenu->addAction(_vtkOutAct);
    _outMenu->addAction(_csvOutAct);
    _nodeMenu->addSeparator();
    _nodeMenu->addAction(_udAct);

    //Models
    QMenu * _modMenu = menuBar()->addMenu(tr("&Models"));
    _modMenu->addAction(_stdModAct);
    _modMenu->addAction(_neuModAct);
    _modMenu->addAction(_gcModAct);
    _modMenu->addAction(_lmModAct);
    _modMenu->addSeparator();
    _modMenu->addAction(_saveModAct);

    //Tutorials
    QMenu * _tutMenu = menuBar()->addMenu(tr("&Tutorials"));
    _tutMenu->addAction(_pTutAct);
    _tutMenu->addAction(_chTutAct);
}

void MainWindow::_createMenuBar2()
{
    //File
    QMenu *_fileMenu = menuBar()->addMenu(tr("&File"));
    _fileMenu->addAction(_newAct);
    _fileMenu->addAction(_openAct);
    _fileMenu->addAction(_openRAct);
    _fileMenu->addAction(_saveAct);
    _fileMenu->addAction(_saveAsAct);
    _fileMenu->addAction(_saveCpAct);
    _fileMenu->addSeparator();
    _fileMenu->addAction(_impAct);
    _fileMenu->addSeparator();
    _fileMenu->addAction(_cloAct);
    _fileMenu->addAction(_quitAct);

    //Edit
    QMenu *_editMenu = menuBar()->addMenu(tr("&Edit"));
    _editMenu->addAction(_undoAct);
    _editMenu->addAction(_redoAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_selAllAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_delAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_blockAct);
    _editMenu->addAction(_ublockAct);
    _editMenu->addSeparator();
    _editMenu->addAction(_prefAct);

    //View
    QMenu *_viewMenu = menuBar()->addMenu(tr("&View"));
    _viewMenu->addAction(_collapAllAct);
    _viewMenu->addAction(_expandAllAct);
    _viewMenu->addSeparator();
    _viewMenu->addAction(_cDock->toggleViewAction());
    _viewMenu->addAction(_lDock->toggleViewAction());
    _viewMenu->addAction(_vGridAct);

    //Code
    QMenu * _codeMenu = menuBar()->addMenu(tr("&Code"));
    _codeMenu->addAction(_compCodeAct);
    _codeMenu->addAction(_runCodeAct);
    _codeMenu->addAction(_runExtCodeAct);

    //Node
    QMenu *_nodeMenu = menuBar()->addMenu(tr("&Nodes"));
    QMenu *_meshCreaMenu = _nodeMenu->addMenu("Mesh creator");
    _meshCreaMenu->addAction(_nodeActs->actions()[0]);
    _meshCreaMenu->addAction(_nodeActs->actions()[1]);
    _meshCreaMenu->addAction(_nodeActs->actions()[2]);
    _meshCreaMenu->addAction(_nodeActs->actions()[3]);
    _meshCreaMenu->addAction(_nodeActs->actions()[4]);
    QMenu *_disMeshMenu = _nodeMenu->addMenu("Distributed mesh");
    _disMeshMenu->addAction(_nodeActs->actions()[5]);
    _disMeshMenu->addAction(_nodeActs->actions()[6]);
    _disMeshMenu->addAction(_nodeActs->actions()[7]);
    QMenu *_dHandMenu = _nodeMenu->addMenu("Degrees of freedom");
    _dHandMenu->addAction(_nodeActs->actions()[8]);
    _dHandMenu->addSeparator();
    _dHandMenu->addAction(_nodeActs->actions()[9]);
    _dHandMenu->addAction(_nodeActs->actions()[10]);
    QMenu *_intMenu = _nodeMenu->addMenu("Integration");
    _intMenu->addAction(_nodeActs->actions()[11]);
    QMenu *_cubaMenu = _nodeMenu->addMenu("Cubature");
    _cubaMenu->addAction(_nodeActs->actions()[12]);
    _cubaMenu->addAction(_nodeActs->actions()[13]);
    _cubaMenu->addAction(_nodeActs->actions()[14]);
    QMenu *_fillMenu = _nodeMenu->addMenu("Element filling");
    _fillMenu->addAction(_nodeActs->actions()[15]);
    _fillMenu->addAction(_nodeActs->actions()[16]);
    _fillMenu->addAction(_nodeActs->actions()[17]);
    _fillMenu->addAction(_nodeActs->actions()[18]);
    _fillMenu->addAction(_nodeActs->actions()[19]);
    QMenu *_fStrMenu = _nodeMenu->addMenu("Fill structure");
    _fStrMenu->addAction(_nodeActs->actions()[20]);
    _fStrMenu->addAction(_nodeActs->actions()[21]);
    _fStrMenu->addSeparator();
    _fStrMenu->addAction(_nodeActs->actions()[22]);
    _fStrMenu->addAction(_nodeActs->actions()[23]);
    _fStrMenu->addAction(_nodeActs->actions()[24]);
    _fStrMenu->addAction(_nodeActs->actions()[25]);
    _fStrMenu->addAction(_nodeActs->actions()[26]);
    QMenu *_lSystemMenu = _nodeMenu->addMenu("Linear system");
    _lSystemMenu->addAction(_nodeActs->actions()[27]);
    _lSystemMenu->addSeparator();
    _lSystemMenu->addAction(_nodeActs->actions()[28]);
    _lSystemMenu->addAction(_nodeActs->actions()[29]);
    _lSystemMenu->addAction(_nodeActs->actions()[30]);
    QMenu *_nlSystemMenu = _nodeMenu->addMenu("Non-linear system");
    _nlSystemMenu->addAction(_nodeActs->actions()[31]);
    _nlSystemMenu->addSeparator();
    _nlSystemMenu->addAction(_nodeActs->actions()[32]);
    _nlSystemMenu->addAction(_nodeActs->actions()[33]);
    QMenu *_timeMenu = _nodeMenu->addMenu("Time iterators");
    _timeMenu->addAction(_nodeActs->actions()[34]);
    _timeMenu->addAction(_nodeActs->actions()[35]);
    _timeMenu->addAction(_nodeActs->actions()[36]);
    QMenu *_solveMenu = _nodeMenu->addMenu("Solve");
    _solveMenu->addAction(_nodeActs->actions()[37]);
    QMenu *_outMenu = _nodeMenu->addMenu("Output");
    _outMenu->addAction(_nodeActs->actions()[38]);
    _outMenu->addAction(_nodeActs->actions()[39]);
    _outMenu->addAction(_nodeActs->actions()[40]);
    // _nodeMenu->addSeparator();
    // _nodeMenu->addAction(_nodeActs->actions()[31]);

    //Models
    QMenu * _modMenu = menuBar()->addMenu(tr("&Models"));
    _modMenu->addAction(_stdModAct);
    _modMenu->addAction(_neuModAct);
    _modMenu->addAction(_gcModAct);
    _modMenu->addAction(_lmModAct);
    _modMenu->addSeparator();
    _modMenu->addAction(_saveModAct);

    //Tutorials
    QMenu * _tutMenu = menuBar()->addMenu(tr("&Tutorials"));
    _tutMenu->addAction(_pTutAct);
    _tutMenu->addAction(_chTutAct);
}

void MainWindow::_createNodeBar()
{
    QToolBar *_nodeBar = addToolBar(tr("File"));

    const QIcon newIcon = QIcon::fromTheme("document-new", QIcon(":/images/new.png"));
    QAction *newLetterAct = new QAction(newIcon, tr("&New Letter"), this);
    newLetterAct->setShortcuts(QKeySequence::New);
    newLetterAct->setStatusTip(tr("Create a new form letter."));
    // connect(newLetterAct, &QAction::triggered, qApp, &QApplication::quit);
    // connect(newLetterAct, &QAction::triggered, this, &MainWindow::newLetter);
    _nodeBar->addAction(newLetterAct);

    QFont f;
    f.setPointSize(8);

    QPushButton *button0 = new QPushButton("&Mesh creator", this);
    button0->setFont(f);
    _nodeBar->addWidget(button0);

    QPushButton *button1 = new QPushButton("&Mesh loader", this);
    button1->setFont(f);
    _nodeBar->addWidget(button1);

    QPushButton *button2 = new QPushButton("&Distributed mesh", this);
    button2->setFont(f);
    _nodeBar->addWidget(button2);


    _nodeBar->setMovable(false);
    addToolBar(Qt::LeftToolBarArea, _nodeBar);

    // QIcon icon = style()->standardIcon(QStyle::SP_DialogOkButton);
    // QPixmap pixmap = icon.pixmap(QSize(64, 64));


    // //Toolbar
    // QPixmap newpix(":logo.png");
    // QPixmap openpix(":logo.png");
    // QPixmap quitpix(":logo.png");

    // QToolBar *toolbar = addToolBar("main toolbar");
    // toolbar->addAction(QIcon(newpix), "New File");
    // toolbar->addAction(QIcon(openpix), "Open File");
    // toolbar->addSeparator();
    // toolbar->setIconSize(QSize(75,75));
    // toolbar->setAllowedAreas(Qt::LeftToolBarArea | Qt::RightToolBarArea);
    // // toolbar->setMovable(false);

    // QAction *quit2 = toolbar->addAction(QIcon(quitpix), "Quit Application");
    // connect(quit2, &QAction::triggered, qApp, &QApplication::quit);
}

void MainWindow::_createNodeBar2()
{
    //Tree
    QTreeWidget *treeWidget = new QTreeWidget();
    treeWidget->setRootIsDecorated(false);
    treeWidget->setIndentation(0);
    treeWidget->setColumnCount(1);
    treeWidget->setHeaderHidden(true);
    treeWidget->setFixedWidth(200);

    //Category items
    QVector<QTreeWidgetItem*> tCat(12);
    for (int i = 0; i < tCat.size(); i++)
    {
        tCat[i] = new QTreeWidgetItem();
        treeWidget->addTopLevelItem(tCat[i]);
    }

    //Category Buttons
    QVector<QPushButton*> bCat(12);
    QVector<SupraNodeType> snTypes(12);
    snTypes[0] = SupraNodeType::MeshCreator;
    snTypes[1] = SupraNodeType::DistributedMesh;
    snTypes[2] = SupraNodeType::DOFsHandler;
    snTypes[3] = SupraNodeType::Integration;
    snTypes[4] = SupraNodeType::Cubature;
    snTypes[5] = SupraNodeType::ElemFilling;
    snTypes[6] = SupraNodeType::FillStruct;
    snTypes[7] = SupraNodeType::LinearSystem;
    snTypes[8] = SupraNodeType::NonLinearSystem;
    snTypes[9] = SupraNodeType::TimeIterators;
    snTypes[10] = SupraNodeType::Solve;
    snTypes[11] = SupraNodeType::Output;
    for (int i = 0; i < tCat.size(); i++)
    {
        if (i != 3 and i != 10)
            bCat[i] = new QPushButton("> " + qstr(snTypes[i]));
        else
            bCat[i] = new QPushButton("   " + qstr(snTypes[i]));
        bCat[i]->setCheckable(true);
        treeWidget->setItemWidget(tCat[i], 0, bCat[i]);
        if (i != 3 and i != 10)
            connect(bCat[i], &QAbstractButton::clicked, treeWidget, [=](){tCat[i]->setExpanded(bCat[i]->isChecked());});
        else
            connect(bCat[i], &QAbstractButton::clicked, this, [=](){this->_createNode(nodeType(snTypes[i])[0]);});

    }

    //Subcat buttons
    QVector<QVector<QPushButton*>> bSubCat(snTypes.size(), QVector<QPushButton*>());
    for (int i = 0; i < snTypes.size(); i++)
    {
        if (i != 3 and i != 10)
        {
            //Frame
            QFrame* pFrame = new QFrame(treeWidget);
            QBoxLayout* pLayout = new QVBoxLayout(pFrame);
            pLayout->setMargin(0);
            pLayout->setSpacing(0);

            //Buttons
            QVector<NodeType> nType = nodeType(snTypes[i]);
            bSubCat[i].resize(nType.size());
            for (int j = 0; j < nType.size(); j++)
            {
                bSubCat[i][j] = new QPushButton(qstr(nType[j]));
                if (nType[j] != NodeType::OutputCsv and nType[j] != NodeType::InitialConditions and nType[j] != NodeType::Undefined)
                    connect(bSubCat[i][j], &QAbstractButton::clicked, this, [=](){this->_createNode(nType[j]);});

                bSubCat[i][j]->setStyleSheet("background-color:rgb(70, 70, 70);padding-left:25px;");
                pLayout->addWidget(bSubCat[i][j]);
            }

            //Tree
            QTreeWidgetItem* pContainer = new QTreeWidgetItem();
            pContainer->setDisabled(true);
            tCat[i]->addChild(pContainer);
            treeWidget->setItemWidget(pContainer, 0, pFrame);
        }
    }

    //Node bar
    QToolBar *_nodeBar = addToolBar(tr("Left tool bar"));
    _nodeBar->addWidget(treeWidget);
    _nodeBar->setMovable(false);
    addToolBar(Qt::LeftToolBarArea, _nodeBar);
}

void MainWindow::_createNodeBar3()
{

    //Node bar
    QToolBar *_nodeBar = addToolBar(tr("Left tool bar"));

    QToolButton *saveButton=new QToolButton(this);
    const QIcon newIcon = QIcon::fromTheme("document-new", QIcon(":/images/new.png"));
    saveButton->setIcon(newIcon);
    saveButton->setText("Save");
    saveButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    saveButton->setPopupMode(QToolButton::InstantPopup);
    saveButton->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

    QMenu *saveMenu=new QMenu(saveButton);
    saveMenu->addAction(new QAction("Save &As", this));
    saveMenu->addAction(new QAction("Save All", this));
    saveButton->setMenu(saveMenu);
    _nodeBar->addWidget(saveButton);

    //Category Buttons
    QVector<QToolButton*> bCat(12);
    QVector<SupraNodeType> snTypes(12);
    snTypes[0] = SupraNodeType::MeshCreator;
    snTypes[1] = SupraNodeType::DistributedMesh;
    snTypes[2] = SupraNodeType::DOFsHandler;
    snTypes[3] = SupraNodeType::Integration;
    snTypes[4] = SupraNodeType::Cubature;
    snTypes[5] = SupraNodeType::ElemFilling;
    snTypes[6] = SupraNodeType::FillStruct;
    snTypes[7] = SupraNodeType::LinearSystem;
    snTypes[8] = SupraNodeType::NonLinearSystem;
    snTypes[9] = SupraNodeType::TimeIterators;
    snTypes[10] = SupraNodeType::Solve;
    snTypes[11] = SupraNodeType::Output;
    for (int i = 0; i < bCat.size(); i++)
    {
        bCat[i] = new QToolButton(this);
        QString iconName = QString::number(i);
        if (i < 10)
            iconName.prepend(":/img/node_0");
        else
            iconName.prepend(":/img/node_");
        iconName.append(".svg");
        qInfo() << iconName;
        QIcon ic = QIcon(iconName);
        // if (i == 0)
        bCat[i]->setIcon(QIcon(":/img/node_00.svg"));
        bCat[i]->setIconSize(QSize(100, 100));
        // else
        // bCat[i]->setIcon(newIcon);
        bCat[i]->setText(qstr(snTypes[i]));
        bCat[i]->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        bCat[i]->setPopupMode(QToolButton::InstantPopup);
        bCat[i]->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
        // bCat[i]->setFixedWidth(100);
        _nodeBar->addWidget(bCat[i]);

        if (i == 3 or i == 10)
            connect(bCat[i], &QAbstractButton::clicked, this, [=](){this->_createNode(nodeType(snTypes[i])[0]);});

    }

    //Subcat buttons
    QVector<QVector<QPushButton*>> bSubCat(snTypes.size(), QVector<QPushButton*>());
    for (int i = 0; i < snTypes.size(); i++)
    {
        if (i != 3 and i != 10)
        {
            QMenu *subMenu = new QMenu(bCat[i]);

            //Buttons
            QVector<NodeType> nType = nodeType(snTypes[i]);
            bSubCat[i].resize(nType.size());
            for (int j = 0; j < nType.size(); j++)
            {
                subMenu->addAction(new QAction("Save All", this));
                // bSubCat[i][j] = new QPushButton(qstr(nType[j]));
                // if (nType[j] != NodeType::OutputCsv and nType[j] != NodeType::InitialConditions and nType[j] != NodeType::Undefined)
                //     connect(bSubCat[i][j], &QAbstractButton::clicked, this, [=](){this->_createNode(nType[j]);});

                // bSubCat[i][j]->setStyleSheet("background-color:rgb(70, 70, 70);padding-left:25px;");
                // pLayout->addWidget(bSubCat[i][j]);
            }

            bCat[i]->setMenu(subMenu);


            // //Tree
            // QTreeWidgetItem* pContainer = new QTreeWidgetItem();
            // pContainer->setDisabled(true);
            // tCat[i]->addChild(pContainer);
            // treeWidget->setItemWidget(pContainer, 0, pFrame);
        }
    }

    //Set node bar
    // _nodeBar->addWidget(treeWidget);
    _nodeBar->setMovable(false);
    // _nodeBar->setMaximumWidth(100);
    addToolBar(Qt::LeftToolBarArea, _nodeBar);
}

void MainWindow::_createNodeBar4()
{

    //Node bar
    _nodeBar = addToolBar(tr("Node tool bar"));

    //Category Buttons
    QVector<SupraNodeType> snTypes(12);
    snTypes[0] = SupraNodeType::MeshCreator;
    snTypes[1] = SupraNodeType::DistributedMesh;
    snTypes[2] = SupraNodeType::DOFsHandler;
    snTypes[3] = SupraNodeType::Integration;
    snTypes[4] = SupraNodeType::Cubature;
    snTypes[5] = SupraNodeType::ElemFilling;
    snTypes[6] = SupraNodeType::FillStruct;
    snTypes[7] = SupraNodeType::LinearSystem;
    snTypes[8] = SupraNodeType::NonLinearSystem;
    snTypes[9] = SupraNodeType::TimeIterators;
    snTypes[10] = SupraNodeType::Solve;
    snTypes[11] = SupraNodeType::Output;
    QVector<QToolButton*> bCat;
    int b{};
    for (int i = 0; i < snTypes.size(); i++)
    {
        //Buttons
        QVector<NodeType> nType = nodeType(snTypes[i]);
        for (int j = 0; j < nType.size(); j++)
        {
            //Create button
            bCat.push_back(new QToolButton(this));

            //Add icon
            QString iconName = QString::number(b);
            if (b < 10)
                iconName.prepend(":/img/node_0");
            else
                iconName.prepend(":/img/node_");
            iconName.append(".svg");
            bCat[b]->setIcon(QPixmap(iconName));

            //Set properties
            bCat[b]->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
            connect(bCat[b], &QAbstractButton::clicked, this, [=](){this->_createNode(nType[j]);});
            bCat[b]->setToolTip(qstr(nType[j]));

            //Set button
            _nodeBar->addWidget(bCat[b]);

            //Increase
            b++;
        }
    }

    //Set node bar
    _nodeBar->setIconSize(QSize(25, 25));
    _nodeBar->setMovable(false);
}

void MainWindow::_createNodeBar5()
{

    //Node bar
    _nodeBar = addToolBar(tr("Left tool bar"));

    //Create vector of snTypes
    QVector<SupraNodeType> snTypes(12);
    snTypes[0] = SupraNodeType::MeshCreator;
    snTypes[1] = SupraNodeType::DistributedMesh;
    snTypes[2] = SupraNodeType::DOFsHandler;
    snTypes[3] = SupraNodeType::Integration;
    snTypes[4] = SupraNodeType::Cubature;
    snTypes[5] = SupraNodeType::ElemFilling;
    snTypes[6] = SupraNodeType::FillStruct;
    snTypes[7] = SupraNodeType::LinearSystem;
    snTypes[8] = SupraNodeType::NonLinearSystem;
    snTypes[9] = SupraNodeType::TimeIterators;
    snTypes[10] = SupraNodeType::Solve;
    snTypes[11] = SupraNodeType::Output;

    //Create combo boxes
    QVector<QComboBox*> snBox;
    int b{};
    for (int i = 0; i < snTypes.size(); i++)
    // for (int i = 0; i < 8; i++)
    {
        cout << str(snTypes[i]) << endl;
        //Main button for supra node type
        snBox.push_back(new QComboBox);

        //Get icon name
        QString iconName = QString::number(b);
        if (b < 10)
            iconName.prepend(":/img/node_0");
        else
            iconName.prepend(":/img/node_");
        iconName.append(".svg");

        //Add item
        snBox[i]->addItem(QPixmap(iconName), "");

        //Increase counter
        b++;

        if (i != 3 and i != 10)
        {
            //Fill the combo box with nodetypes
            QVector<NodeType> nType = nodeType(snTypes[i]);
            for (int j = 0; j < nType.size(); j++)
            {
                cout << "  " << str(nType[j]) << endl;
                //Get icon name
                QString iconName = QString::number(b);
                if (b < 10)
                    iconName.prepend(":/img/node_0");
                else
                    iconName.prepend(":/img/node_");
                iconName.append(".svg");

                //Add item
                snBox[i]->addItem(QPixmap(iconName), "", QVariant(qstr(nType[j])));

                //Increase counter
                b++;
            }
        }

        // //Prevent selection of first element
        // QStandardItemModel* snModel = qobject_cast<QStandardItemModel*>(snBox[i]->model());
        // QModelIndex snFirstIndex = snModel->index(0, snBox[i]->modelColumn(), snBox[i]->rootModelIndex());
        // QStandardItem* snFirstItem = snModel->itemFromIndex(snFirstIndex);
        // snFirstItem->setSelectable(false);

        //Properties
        snBox[i]->setIconSize(QSize(25, 25));
        // connect(snBox[i], QOverload<int>::of(&QComboBox::activated), _scene, [=](int index){_scene->createNode(NodeType::StructMeshGenerator);});
        connect(snBox[i], QOverload<int>::of(&QComboBox::currentIndexChanged), _scene, [=](int index){
                qInfo() << snBox[i]->itemData(index, 0).toString();
                _scene->createNode(NodeType::StructMeshGenerator);
            });

        //Add to node bar
        _nodeBar->addWidget(snBox[i]);
    }

    //Set node bar
    _nodeBar->setMovable(false);
}

void MainWindow::_createNodeBar6()
{
    //Node bar
    _nodeBar = new QToolBar;
    for (int i = 0; i < 20; i++)
        _nodeBar->addAction(_nodeActs->actions()[i]);

    //Node bar properties
    _nodeBar->setIconSize(QSize(25, 25));
    _nodeBar->setMovable(false);


    //Node bar2
    _nodeBar2 = new QToolBar;
    for (int i = 20; i < 41; i++)
        _nodeBar2->addAction(_nodeActs->actions()[i]);

    //Node bar properties
    _nodeBar2->setIconSize(QSize(25, 25));
    _nodeBar2->setMovable(false);

    // QButtonGroup * buttonGroup = new QButtonGroup(this);
    // buttonGroup->setExclusive(false);
    // QGridLayout *layout = new QGridLayout;
    // // layout->addWidget(createCellWidget(tr("Conditional"), DiagramItem::Conditional), 0, 0);
    // // layout->addWidget(createCellWidget(tr("Process"), DiagramItem::Step),0, 1);
    // // layout->addWidget(createCellWidget(tr("Input/Output"), DiagramItem::Io), 1, 0);

    // QToolButton *textButton = new QToolButton;
    // textButton->setCheckable(true);
    // // textButton->addAction(_nodeActs->actions()[0]);
    // buttonGroup->addButton(textButton, 0);
    // textButton->setIcon(QIcon(QPixmap(":/img/node_00.svg")));
    // textButton->setIconSize(QSize(50, 50));
    // QGridLayout *textLayout = new QGridLayout;
    // textLayout->addWidget(textButton, 0, 0, Qt::AlignHCenter);
    // textLayout->addWidget(new QLabel(tr("Text")), 1, 0, Qt::AlignCenter);
    // QWidget *textWidget = new QWidget;
    // textWidget->setLayout(textLayout);
    // layout->addWidget(textWidget, 0, 0);
    // layout->addWidget(textWidget, 1, 0);
    // layout->addWidget(textWidget, 0, 1);
    // layout->addWidget(textWidget, 1, 1);

    // layout->setRowStretch(3, 10);
    // layout->setColumnStretch(2, 10);

    // QWidget *itemWidget = new QWidget;
    // itemWidget->setLayout(layout);

    // QDockWidget * _bDock = new QDockWidget(tr("ba"), this);
    // // // _bDock->addActions(_nodeActs->actions());
    // // QButtonGroup *buttonGroup = new QButtonGroup(this);
    // // QToolButton *tb = new QToolButton(this);
    // // tb->addAction(_nodeActs->actions()[0]);
    // _bDock->setWidget(itemWidget);
    // addDockWidget(Qt::LeftDockWidgetArea, _bDock);

}

void MainWindow::_createNodeBar7()
{
    // //Create empty actions
    // QActionGroup *_eActs = new QActionGroup(this);
    // for (int i = 0; i < 10; i++)
    // {
    //     QAction *e1 = new QAction("Empty", this);
    //     e1->setIcon(QPixmap(":/img/empty.svg"));
    //     e1->setEnabled(false);

    //     //Add to action group
    //     _eActs->addAction(e1);
    // }

    //Node bar
    _nodeBar = new QToolBar;
    for (int i = 0; i < 41; i+=2)
        _nodeBar->addAction(_nodeActs->actions()[i]);

    //Node bar properties
    _nodeBar->setIconSize(QSize(25, 25));
    _nodeBar->setMovable(false);

    //Node bar2
    _nodeBar2 = new QToolBar;
    for (int i = 1; i < 41; i+=2)
        _nodeBar2->addAction(_nodeActs->actions()[i]);

    //Node bar properties
    _nodeBar2->setIconSize(QSize(25, 25));
    _nodeBar2->setMovable(false);
}

void MainWindow::_createStatusBar()
{
    statusBar()->showMessage(tr("Ready."));
}

void MainWindow::_createDocks()
{
    ///////////////////////////////////////////////////
    //////////////////// VTK dock /////////////////////
    ///////////////////////////////////////////////////
    _vDock = new QDockWidget(tr("Mesh"), this);

    //Inner window
    QMainWindow* _vMain = new QMainWindow(_vDock);
    _vMain->setWindowFlags(Qt::Widget);

    //vtkWidget
    _vWidget = new VtkWidget(_st);
    _vWidget->setMinimumWidth(300);
    _vWidget->setMinimumHeight(300);

    //Toolbar
    QToolBar* _vToolBar = new QToolBar(_vMain);
    _vToolBar->setMovable(false);
    const QIcon topViewIcon = QIcon::fromTheme("zoom-best-fit", QIcon(":/images/new.png"));
    QAction* topViewAct = new QAction(topViewIcon, tr("&Top View"), this);
    _vToolBar->addAction(topViewAct);
    connect(topViewAct, &QAction::triggered, _vWidget, &VtkWidget::setViewTop);
    QComboBox *colorBox = new QComboBox;
    for (int i = 0; i < 64; i++)
        colorBox->addItem(QString::number(i));
    connect(colorBox, SIGNAL(currentIndexChanged(int)), _vWidget,SLOT(setColorScheme(int)));
    _vToolBar->addWidget(colorBox);

    //Set vtk dock
    _vMain->addToolBar(Qt::TopToolBarArea, _vToolBar);
    _vMain->setCentralWidget(_vWidget);
    _vDock->setWidget(_vMain);
    // _vDock->setTitleBarWidget(new QWidget());
    addDockWidget(Qt::RightDockWidgetArea, _vDock);


    ///////////////////////////////////////////////////
    //////////////////// Code dock ////////////////////
    ///////////////////////////////////////////////////
    _cDock = new QDockWidget(tr("Code"), this);

    //Inner window
    QMainWindow* _cMain = new QMainWindow(_cDock);
    _cMain->setWindowFlags(Qt::Widget);

    //Toolbar
    QToolBar* _cToolBar = new QToolBar(_cMain);
    _cToolBar->setMovable(false);
    const QIcon topViewIconCode = QIcon::fromTheme("zoom-best-fit", QIcon(":/images/new.png"));
    QAction* topViewActCode = new QAction(topViewIconCode, tr("&Top View"), this);
    _cToolBar->addAction(topViewActCode);

    //Code
    _code = new QTextEdit();
    _code->setText("");
    Highlighter *highlighter = new Highlighter(_code->document());
    _code->setReadOnly(true);
    QFont font;
    font.setFamily("Hack");
    font.setFixedPitch(true);
    font.setPointSize(12);
    _code->setFont(font);

    //Set code dock
    _cMain->addToolBar(Qt::TopToolBarArea, _cToolBar);
    _cMain->setCentralWidget(_code);
    _cDock->setWidget(_cMain);
    // _cDock->setTitleBarWidget(new QWidget());
    addDockWidget(Qt::RightDockWidgetArea, _cDock);


    ///////////////////////////////////////////////////
    ///////////////////// Log dock ////////////////////
    ///////////////////////////////////////////////////
    _lDock = new QDockWidget(tr("Log"), this);

    //Inner window
    QMainWindow* _lMain = new QMainWindow(_lDock);
    _lMain->setWindowFlags(Qt::Widget);

    //Toolbar
    QToolBar* _lToolBar = new QToolBar(_lMain);
    _lToolBar->setMovable(false);
    _lToolBar->addAction(topViewActCode);

    //Log
    _log = new QTextEdit();
    _log->setText("");
    _log->setReadOnly(true);

    //Set code dock
    _lMain->addToolBar(Qt::TopToolBarArea, _lToolBar);
    _lMain->setCentralWidget(_log);
    _lDock->setWidget(_lMain);
    // _lDock->setTitleBarWidget(new QWidget());
    addDockWidget(Qt::RightDockWidgetArea, _lDock);

    //Start with them tabified
    this->tabifyDockWidget(_cDock, _lDock);
    // setTabPosition(Qt::RightDockWidgetArea, QTabWidget::North);
    _cDock->raise();
}

void MainWindow::_updateEditor(QVector<QString> data)
{
    const int old_scrollbar_value = _code->verticalScrollBar()->value();
    _code->clear();
    for (int i = 0; i < data.size(); i++)
        _code->append(data[i]);
    if (old_scrollbar_value < _code->verticalScrollBar()->maximum())
    {
        _code->verticalScrollBar()->setValue(old_scrollbar_value);
    }
}

void MainWindow::_createNode(NodeType nType)
{
    // undoStack->push(new _createNode(nType));
    _scene->createNode(nType);
}

void MainWindow::_open()
{
    QString fname = QFileDialog::getOpenFileName();
    if (fname.isEmpty())
        return;

    QFile file(fname);
    file.open(QFile::ReadOnly);
    QDataStream ds(&file);
    _scene->open(ds);

    file.close();
}

void MainWindow::_save()
{
    _saveGui();
    _saveCode();
}

void MainWindow::_saveGui()
{
    QFile file("/home/guille/Programs/GuiApps/Test/Test.hlg");
    file.open(QFile::WriteOnly);
    QDataStream ds(&file);
    _scene->save(ds);

    file.close();
}

void MainWindow::_saveCode()
{
    QFile file("/home/guille/Programs/GuiApps/Test/Test.cpp");

    if (file.open(QIODevice::WriteOnly))
    {
        QTextStream stream(&file);

        stream << _code->toPlainText();

        file.flush();
        file.close();
        qInfo() << "Saved";
    }
    else
    {
        qInfo() << "Not saved";
        QMessageBox::critical(this, tr("Errore"), tr("Non posso salvare il file"));
        return;
    }
}

void MainWindow::_run()
{

    qInfo() << "Running the code";

    _scene->run();

    return;
}

void MainWindow::_pOutput(QProcess *p)
{
    QByteArray data = p->readAllStandardOutput();

    _log->append(QString(data));
}

void MainWindow::_compile()
{
    //Show and clear dock
    _lDock->show();
    _lDock->raise();
    _log->clear();

    //Save
    _save();

    //Create process
    QProcess *pCompile;
    pCompile = new QProcess();
    QCoreApplication::processEvents();
    pCompile->setProcessChannelMode(QProcess::MergedChannels);
    connect(pCompile, &QProcess::readyReadStandardOutput, this, [=](){this->_pOutput(pCompile);});

    //(De)activate run
    connect(pCompile, (void(QProcess::*)(int))&QProcess::finished, [=]{_runExtCodeAct->setEnabled(true);});
    _runExtCodeAct->setEnabled(false);

    //Compile
    pCompile->start("hpApps -cm --apps GuiApps");
}

void MainWindow::_runExt()
{
    //Show dock
    _lDock->show();
    _lDock->raise();

    //Create run process
    QProcess *pRun;
    pRun = new QProcess();
    QCoreApplication::processEvents();
    pRun->setProcessChannelMode(QProcess::MergedChannels);
    connect(pRun, &QProcess::readyReadStandardOutput, this, [=](){this->_pOutput(pRun);});

    //(De)activate compile
    connect(pRun, (void(QProcess::*)(int))&QProcess::finished, [=]{_compCodeAct->setEnabled(true);});
    _compCodeAct->setEnabled(false);

    //Run
    pRun->start("/home/guille/.local/GuiApps/bin/Test");
}

void MainWindow::_loadModel(QString model)
{
    QString fname = ":/models/" + model + "Model.hlg";
    QFile* file = new QFile(fname);

    file->open(QFile::ReadOnly);
    QDataStream ds(file);
    _scene->open(ds);

    file->close();
}

void MainWindow::_saveModel()
{
    QString dir = "/home/guille/Programs/guihiperlifelib/src/Gui/models/";
    QString filter = "hiperlife GUI (*.hlg);;All file (*)";
    QString fname = QFileDialog::getSaveFileName(this, tr("Save Model"), dir, filter, &filter);
    // if (!fname.endsWith(".hlg"))
    //     fname += ".hlg";

    if (fname.isEmpty())
        return;

    QFile file(fname);
    file.open(QFile::WriteOnly);
    QDataStream ds(&file);
    _scene->save(ds);

    file.close();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    QSettings settings("hiperlife", "GUI");
    settings.setValue("geometry", saveGeometry());
    settings.setValue("windowState", saveState());
    QMainWindow::closeEvent(event);
}


void MainWindow::_readSettings()
{
    QSettings settings("hiperlife", "GUI");
    restoreGeometry(settings.value("MainWindow/geometry").toByteArray());
    restoreState(settings.value("MainWindow/windowState").toByteArray());
}
