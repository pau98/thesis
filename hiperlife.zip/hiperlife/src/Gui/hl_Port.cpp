/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

// C++ headers
#include <iostream>
#include <fstream>

// Qt headers
#include <QPen>
#include <QPainter>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsProxyWidget>
#include <QtWidgets>

#include "hl_Port.h"
#include "hl_Link.h"

using namespace hlGui;
Port::Port(PortType pType, NodeType nType, Node *n, QGraphicsItem *parent): QGraphicsPathItem(parent)
{
    //Set types
    _pType = pType;
    _nType = nType;
    _mnType = metaType(_nType);

    //Set parent node
    parentNode = n;

    // //Set colors
    // if (_pType == PortType::InPort)
    // {
    //     setBrush(bColor(_nType));
    //     setPen(QPen(QColor(30,30,30), 3));
    // }
    // else
    // {
    //     setBrush(QColor(30,30,30));
    //     setPen(QPen(bColor(_nType), 2));
    // }

    // //Draw
    // QPainterPath p;
    // p.addEllipse(-_r, -_r, 2*_r, 2*_r);
    // setPath(p);

    //Set flags
    setFlag(ItemIsMovable, false);
    setFlag(ItemIsSelectable, false);
    setFlag(QGraphicsItem::ItemSendsScenePositionChanges);
    setZValue(2);

    //Add labels
    if (_pType == PortType::InPort)
    {
        //Label
        _name = new QLabel(qstr(_mnType));
        _name->setStyleSheet("color:rgba(150,150,150); background:rgba(0,0,0,0);");

        //Add to node
        QGraphicsProxyWidget* pMyProxy = new QGraphicsProxyWidget(this);
        pMyProxy->setWidget(_name);
        pMyProxy->setPos(20, -_name->height()/2);
    }

    // update();
}

QVariant Port::itemChange(GraphicsItemChange change, const QVariant &value)
{
    if (change == ItemScenePositionHasChanged)
    {
        foreach (Link *link, links)
            link->Update();
    }

    return value;
}

void Port::block(bool b)
{
    //(Un)block this port
    blocked = b;

    //(Un)block out links
    foreach (Link *link, links)
        link->block(b);
}


QRectF Port::boundingRect() const
{
    return QRectF(-2*_r, -2*_r, 4*_r, 4*_r);
}

QPainterPath Port::shape() const
{
    QPainterPath p;
    p.addEllipse(-2*_r, -2*_r, 4*_r, 4*_r);
    return p;
}

void Port::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option);
    Q_UNUSED(widget);

    //Set colors
    QColor backColor = QColor(50,50,50);
    QColor mainColor = bColor(_nType);
    if (_pType == PortType::InPort)
    {

        painter->setBrush(mainColor);
        if (blocked == true)
            painter->setPen(QPen(backColor, 5));
        else
            painter->setPen(QPen(backColor, 2));
    }
    else
    {
        if (blocked == true)
            mainColor = backColor;
        painter->setBrush(QColor(30,30,30));
        painter->setPen(QPen(mainColor, 2));
    }

    //Draw
    // QPainterPath p;
    // p.addEllipse(-_r, -_r, 2*_r, 2*_r);
    // setPath(p);
    painter->drawEllipse(-_r, -_r, 2*_r, 2*_r);
}
