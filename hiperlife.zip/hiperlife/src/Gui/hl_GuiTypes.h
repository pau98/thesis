/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef hl_GUITYPES_H
#define hl_GUITYPES_H

#include <string>
#include <exception>
#include <stdexcept>

#include <QString>
#include <QColor>

#include <hl_TypeDefs.h>

namespace hlGui
{
    //Node and meta node
    enum class NodeType
    {
        Undefined,
        StructMeshGenerator,
        MeshLoader,
        UnstructGmshMeshGenerator,
        UnstructVtkMeshGenerator,
        MeshTransformation,
        DistributedMesh,
        hDistributedMesh,
        pDistributedMesh,
        DOFsHandler,
        BoundaryConditions,
        InitialConditions,
        Integration,
        GaussCubature,
        BorderGaussCubature,
        SubdivCubature,
        preEFilling,
        ralEFilling,
        weaEFilling,
        onsEFilling,
        usrEFilling,
        RightHandSide,
        LeftHandSide,
        FreeEnergy,
        Dissipation,
        PowerInput,
        ProcessOperator,
        LangrageMultiplier,
        HiPerProblem,
        AZSolver,
        BelSolver,
        AmSolver,
        NonLinearSystem,
        NRSolver,
        LSSolver,
        ConstTimeStep,
        AdapTimeStep,
        AlphaTimeStep,
        Solve,
        OutputH,
        OutputVtk,
        OutputCsv,
    };

    enum class MetaNodeType
    {
        Undefined,
        MeshCreator,
        DistributedMesh,
        DOFsHandler,
        BoundaryConditions,
        InitialConditions,
        Integration,
        Cubature,
        ElemFilling,
        RightHandSide,
        LeftHandSide,
        FreeEnergy,
        Dissipation,
        PowerInput,
        ProcessOperator,
        LangrageMultiplier,
        LinearSolver,
        HiPerProblem,
        NonLinearSystem,
        NonLinearSolver,
        TimeIterator,
        Solve,
        Output
    };

    enum class SupraNodeType
    {
        Undefined,
        MeshCreator,
        DistributedMesh,
        DOFsHandler,
        Integration,
        Cubature,
        ElemFilling,
        FillStruct,
        LinearSystem,
        NonLinearSystem,
        TimeIterators,
        Solve,
        Output
    };

    //Converters
    inline MetaNodeType metaType(NodeType nType)
    {
        switch (int(nType))
        {
            case static_cast<int>(NodeType::StructMeshGenerator):
            case static_cast<int>(NodeType::MeshLoader):
            case static_cast<int>(NodeType::UnstructGmshMeshGenerator):
            case static_cast<int>(NodeType::UnstructVtkMeshGenerator):
            case static_cast<int>(NodeType::MeshTransformation):
                return MetaNodeType::MeshCreator;
            case static_cast<int>(NodeType::DistributedMesh):
            case static_cast<int>(NodeType::hDistributedMesh):
            case static_cast<int>(NodeType::pDistributedMesh):
                return MetaNodeType::DistributedMesh;
            case static_cast<int>(NodeType::DOFsHandler):
                return MetaNodeType::DOFsHandler;
            case static_cast<int>(NodeType::BoundaryConditions):
                return MetaNodeType::BoundaryConditions;
            case static_cast<int>(NodeType::InitialConditions):
                return MetaNodeType::InitialConditions;
            case static_cast<int>(NodeType::Integration):
                return MetaNodeType::Integration;
            case static_cast<int>(NodeType::GaussCubature):
            case static_cast<int>(NodeType::BorderGaussCubature):
            case static_cast<int>(NodeType::SubdivCubature):
                return MetaNodeType::Cubature;
            case static_cast<int>(NodeType::preEFilling):
            case static_cast<int>(NodeType::ralEFilling):
            case static_cast<int>(NodeType::weaEFilling):
            case static_cast<int>(NodeType::onsEFilling):
            case static_cast<int>(NodeType::usrEFilling):
                return MetaNodeType::ElemFilling;
            case static_cast<int>(NodeType::RightHandSide):
                return MetaNodeType::RightHandSide;
            case static_cast<int>(NodeType::LeftHandSide):
                return MetaNodeType::LeftHandSide;
            case static_cast<int>(NodeType::FreeEnergy):
                return MetaNodeType::FreeEnergy;
            case static_cast<int>(NodeType::Dissipation):
                return MetaNodeType::Dissipation;
            case static_cast<int>(NodeType::PowerInput):
                return MetaNodeType::PowerInput;
            case static_cast<int>(NodeType::ProcessOperator):
                return MetaNodeType::ProcessOperator;
            case static_cast<int>(NodeType::LangrageMultiplier):
                return MetaNodeType::LangrageMultiplier;
            case static_cast<int>(NodeType::HiPerProblem):
                return MetaNodeType::HiPerProblem;
            case static_cast<int>(NodeType::AZSolver):
            case static_cast<int>(NodeType::BelSolver):
            case static_cast<int>(NodeType::AmSolver):
                return MetaNodeType::LinearSolver;
            case static_cast<int>(NodeType::NonLinearSystem):
                return MetaNodeType::NonLinearSystem;
            case static_cast<int>(NodeType::NRSolver):
            case static_cast<int>(NodeType::LSSolver):
                return MetaNodeType::NonLinearSolver;
            case static_cast<int>(NodeType::Solve):
                return MetaNodeType::Solve;
            case static_cast<int>(NodeType::OutputH):
                return MetaNodeType::Output;
            case static_cast<int>(NodeType::OutputVtk):
                return MetaNodeType::Output;
            case static_cast<int>(NodeType::OutputCsv):
                return MetaNodeType::Output;
            default:
                throw std::runtime_error("MetaType: NodeType undefined.");
        }
    }

    inline QVector<NodeType> nodeType(SupraNodeType snt)
    {
        if (snt == SupraNodeType::Undefined)
            return {NodeType::Undefined};
        else if (snt == SupraNodeType::MeshCreator)
            return {NodeType::StructMeshGenerator,
                    NodeType::MeshLoader,
                    NodeType::UnstructGmshMeshGenerator,
                    NodeType::UnstructVtkMeshGenerator,
                    NodeType::MeshTransformation};
        else if (snt == SupraNodeType::DistributedMesh)
            return {NodeType::DistributedMesh,
                    NodeType::hDistributedMesh,
                    NodeType::pDistributedMesh};
        else if (snt == SupraNodeType::DOFsHandler)
            return {NodeType::DOFsHandler,
                    NodeType::BoundaryConditions,
                    NodeType::InitialConditions};
        else if (snt == SupraNodeType::Integration)
            return {NodeType::Integration};
        else if (snt == SupraNodeType::Cubature)
            return {NodeType::GaussCubature,
                    NodeType::BorderGaussCubature,
                    NodeType::SubdivCubature};
        else if (snt == SupraNodeType::ElemFilling)
            return {NodeType::preEFilling,
                    NodeType::ralEFilling,
                    NodeType::weaEFilling,
                    NodeType::onsEFilling,
                    NodeType::usrEFilling};
        else if (snt == SupraNodeType::FillStruct)
            return {NodeType::RightHandSide,
                    NodeType::LeftHandSide,
                    NodeType::FreeEnergy,
                    NodeType::Dissipation,
                    NodeType::PowerInput,
                    NodeType::ProcessOperator,
                    NodeType::LangrageMultiplier};
        else if (snt == SupraNodeType::LinearSystem)
            return {NodeType::HiPerProblem,
                    NodeType::AZSolver,
                    NodeType::BelSolver,
                    NodeType::AmSolver
                    };
        else if (snt == SupraNodeType::NonLinearSystem)
            return {NodeType::NonLinearSystem,
                    NodeType::NRSolver,
                    NodeType::LSSolver
                    };
        else if (snt == SupraNodeType::TimeIterators)
            return {NodeType::ConstTimeStep,
                    NodeType::AdapTimeStep,
                    NodeType::AlphaTimeStep
                    };
        else if (snt == SupraNodeType::Solve)
            return {NodeType::Solve};
        else if (snt == SupraNodeType::Output)
            return {NodeType::OutputH,
                    NodeType::OutputVtk,
                    NodeType::OutputCsv};
        else
            throw std::runtime_error("nodeType: Supra node type not recognized.");
    }

    //string
    inline std::string str(NodeType nt)
    {
        if (nt == NodeType::Undefined)
            return "Undefined";
        else if (nt == NodeType::StructMeshGenerator)
            return "Structured mesh generator";
        else if (nt == NodeType::MeshLoader)
            return "Mesh loader";
        else if (nt == NodeType::UnstructGmshMeshGenerator)
            return "Unstructured (Gmsh) mesh generator";
        else if (nt == NodeType::UnstructVtkMeshGenerator)
            return "Unstructured (VTK) mesh generator";
        else if (nt == NodeType::MeshTransformation)
            return "Mesh transformation";
        else if (nt == NodeType::DistributedMesh)
            return "Standard distributed mesh";
        else if (nt == NodeType::hDistributedMesh)
            return "h-refined distributed mesh";
        else if (nt == NodeType::pDistributedMesh)
            return "p-refined distributed mesh";
        else if (nt == NodeType::DOFsHandler)
            return "DOFs handler";
        else if (nt == NodeType::BoundaryConditions)
            return "Boundary conditions";
        else if (nt == NodeType::InitialConditions)
            return "Initial conditions";
        else if (nt == NodeType::Integration)
            return "Integration";
        else if (nt == NodeType::GaussCubature)
            return "CubatureGauss";
        else if (nt == NodeType::BorderGaussCubature)
            return "CubatureBorderGauss";
        else if (nt == NodeType::SubdivCubature)
            return "CubatureIrregSubdivSurf";
        else if (nt == NodeType::preEFilling)
            return "Predefined elemental filling";
        else if (nt == NodeType::ralEFilling)
            return "RHS && LHS form elemental filling";
        else if (nt == NodeType::weaEFilling)
            return "Weak form elemental filling";
        else if (nt == NodeType::onsEFilling)
            return "Onsager elemental filling";
        else if (nt == NodeType::usrEFilling)
            return "User-defined elemental filling";
        else if (nt == NodeType::RightHandSide)
            return "Right-hand side";
        else if (nt == NodeType::LeftHandSide)
            return "Left-hand side";
        else if (nt == NodeType::FreeEnergy)
            return "Free energy";
        else if (nt == NodeType::Dissipation)
            return "Dissipation";
        else if (nt == NodeType::PowerInput)
            return "Power input";
        else if (nt == NodeType::ProcessOperator)
            return "Process operator";
        else if (nt == NodeType::LangrageMultiplier)
            return "Lagrange multiplier";
        else if (nt == NodeType::AZSolver)
            return "AztecOO linear solver";
        else if (nt == NodeType::BelSolver)
            return "Belos linear solver";
        else if (nt == NodeType::AmSolver)
            return "Amesos linear solver";
        else if (nt == NodeType::HiPerProblem)
            return "Linear system";
        else if (nt == NodeType::NRSolver)
            return "Newton-Raphson non-linear solver";
        else if (nt == NodeType::LSSolver)
            return "Linea search non-linear solver";
        else if (nt == NodeType::NonLinearSystem)
            return "Non-linear system";
        else if (nt == NodeType::ConstTimeStep)
            return "Constant time-step iterator";
        else if (nt == NodeType::AdapTimeStep)
            return "Adaptive time-step iterator";
        else if (nt == NodeType::AlphaTimeStep)
            return "Generalized-alpha time-step iterator";
        else if (nt == NodeType::Solve)
            return "Solve";
        else if (nt == NodeType::OutputH)
            return "hiperlife output";
        else if (nt == NodeType::OutputVtk)
            return "VTK output";
        else if (nt == NodeType::OutputCsv)
            return "CSV output";
        else
            throw std::runtime_error("str: Node type not recognized.");
    }

    inline std::string str(MetaNodeType mnt)
    {
        if (mnt == MetaNodeType::Undefined)
            return "Undefined";
        else if (mnt == MetaNodeType::DistributedMesh)
            return "Distributed mesh";
        else if (mnt == MetaNodeType::MeshCreator)
            return "Mesh creator";
        else if (mnt == MetaNodeType::DOFsHandler)
            return "DOFs handler";
        else if (mnt == MetaNodeType::BoundaryConditions)
            return "Boundary conditions";
        else if (mnt == MetaNodeType::InitialConditions)
            return "Initial conditions";
        else if (mnt == MetaNodeType::Integration)
            return "Integration";
        else if (mnt == MetaNodeType::Cubature)
            return "Cubature";
        else if (mnt == MetaNodeType::ElemFilling)
            return "Elemental filling";
        else if (mnt == MetaNodeType::RightHandSide)
            return "Right hand side";
        else if (mnt == MetaNodeType::LeftHandSide)
            return "Left hand side";
        else if (mnt == MetaNodeType::FreeEnergy)
            return "Free energy";
        else if (mnt == MetaNodeType::Dissipation)
            return "Dissipation";
        else if (mnt == MetaNodeType::PowerInput)
            return "Power input";
        else if (mnt == MetaNodeType::ProcessOperator)
            return "Process operator";
        else if (mnt == MetaNodeType::LangrageMultiplier)
            return "Lagrange multiplier";
        else if (mnt == MetaNodeType::LinearSolver)
            return "Linear solver";
        else if (mnt == MetaNodeType::HiPerProblem)
            return "Linear system";
        else if (mnt == MetaNodeType::Solve)
            return "Solve";
        else if (mnt == MetaNodeType::Output)
            return "Output";
        else
            throw std::runtime_error("str: Meta node type not recognized.");
    }

    inline std::string str(SupraNodeType snt)
    {
        if (snt == SupraNodeType::Undefined)
            return "Undefined";
        else if (snt == SupraNodeType::MeshCreator)
            return "Mesh creator";
        else if (snt == SupraNodeType::DistributedMesh)
            return "Distributed mesh";
        else if (snt == SupraNodeType::DOFsHandler)
            return "Degrees of freedom";
        else if (snt == SupraNodeType::Integration)
            return "Integration";
        else if (snt == SupraNodeType::Cubature)
            return "Cubature";
        else if (snt == SupraNodeType::ElemFilling)
            return "Element filling";
        else if (snt == SupraNodeType::FillStruct)
            return "Fill structure";
        else if (snt == SupraNodeType::LinearSystem)
            return "Linear system";
        else if (snt == SupraNodeType::NonLinearSystem)
            return "Non-linear system";
        else if (snt == SupraNodeType::TimeIterators)
            return "Time iterators";
        else if (snt == SupraNodeType::Solve)
            return "Solve";
        else if (snt == SupraNodeType::Output)
            return "Output";
        else
            throw std::runtime_error("str: Supra node type not recognized.");
    }

    inline std::string abrev(NodeType nt)
    {
        if (nt == NodeType::Undefined)
            return "Undefined";
        else if (nt == NodeType::StructMeshGenerator)
            return "strMesh";
        else if (nt == NodeType::MeshLoader)
            return "lMesh";
        else if (nt == NodeType::UnstructGmshMeshGenerator)
            return "gMesh";
        else if (nt == NodeType::UnstructVtkMeshGenerator)
            return "vMesh";
        else if (nt == NodeType::MeshTransformation)
            return "Transf";
        else if (nt == NodeType::DistributedMesh)
            return "disMesh";
        else if (nt == NodeType::hDistributedMesh)
            return "hdMesh";
        else if (nt == NodeType::pDistributedMesh)
            return "pdMesh";
        else if (nt == NodeType::DOFsHandler)
            return "dHand";
        else if (nt == NodeType::BoundaryConditions)
            return "bCond";
        else if (nt == NodeType::InitialConditions)
            return "iCond";
        else if (nt == NodeType::Integration)
            return "integr";
        else if (nt == NodeType::GaussCubature)
            return "gCuba";
        else if (nt == NodeType::BorderGaussCubature)
            return "bgCuba";
        else if (nt == NodeType::SubdivCubature)
            return "sCuba";
        else if (nt == NodeType::preEFilling)
            return "pFill";
        else if (nt == NodeType::ralEFilling)
            return "ralFill";
        else if (nt == NodeType::weaEFilling)
            return "wFill";
        else if (nt == NodeType::onsEFilling)
            return "oFill";
        else if (nt == NodeType::usrEFilling)
            return "uFill";
        else if (nt == NodeType::RightHandSide)
            return "rhs";
        else if (nt == NodeType::LeftHandSide)
            return "lhs";
        else if (nt == NodeType::FreeEnergy)
            return "F";
        else if (nt == NodeType::Dissipation)
            return "D";
        else if (nt == NodeType::PowerInput)
            return "PI";
        else if (nt == NodeType::ProcessOperator)
            return "PO";
        else if (nt == NodeType::LangrageMultiplier)
            return "lagMult";
        else if (nt == NodeType::AZSolver)
            return "azSolver";
        else if (nt == NodeType::BelSolver)
            return "bSolver";
        else if (nt == NodeType::AmSolver)
            return "amSolver";
        else if (nt == NodeType::HiPerProblem)
            return "lSystem";
        else if (nt == NodeType::NRSolver)
            return "nrSolver";
        else if (nt == NodeType::LSSolver)
            return "lsSolver";
        else if (nt == NodeType::NonLinearSystem)
            return "nlSystem";
        else if (nt == NodeType::ConstTimeStep)
            return "constTS";
        else if (nt == NodeType::AdapTimeStep)
            return "AdapTS";
        else if (nt == NodeType::AlphaTimeStep)
            return "GaTS";
        else if (nt == NodeType::Solve)
            return "Solve";
        else if (nt == NodeType::OutputH)
            return "hOut";
        else if (nt == NodeType::OutputVtk)
            return "vtkOut";
        else if (nt == NodeType::OutputCsv)
            return "cSvOut";
        else
            throw std::runtime_error("str: Node type not recognized.");
    }

    //QString
    inline QString qstr(NodeType nt)
    {
        return QString::fromStdString(str(nt));
    }

    inline QString qstr(MetaNodeType mnt)
    {
        return QString::fromStdString(str(mnt));
    }

    inline QString qstr(SupraNodeType snt)
    {
        return QString::fromStdString(str(snt));
    }

    inline QString qabrev(NodeType nt)
    {
        return QString::fromStdString(abrev(nt));
    }

    //Color
    inline QColor bColor(MetaNodeType mnType)
    {
        switch (int(mnType))
        {
            case static_cast<int>(MetaNodeType::MeshCreator):
                return Qt::darkRed;
            case static_cast<int>(MetaNodeType::DistributedMesh):
                return Qt::darkCyan;
            case static_cast<int>(MetaNodeType::DOFsHandler):
                return Qt::darkMagenta;
            case static_cast<int>(MetaNodeType::BoundaryConditions):
                return QColor(49,112,141);
            case static_cast<int>(MetaNodeType::InitialConditions):
                return Qt::blue;
            case static_cast<int>(MetaNodeType::Integration):
                return QColor(228,189,0);
            case static_cast<int>(MetaNodeType::Cubature):
                return QColor(199,66,9);
            case static_cast<int>(MetaNodeType::ElemFilling):
            case static_cast<int>(MetaNodeType::RightHandSide):
            case static_cast<int>(MetaNodeType::LeftHandSide):
            case static_cast<int>(MetaNodeType::FreeEnergy):
            case static_cast<int>(MetaNodeType::Dissipation):
            case static_cast<int>(MetaNodeType::PowerInput):
            case static_cast<int>(MetaNodeType::ProcessOperator):
            case static_cast<int>(MetaNodeType::LangrageMultiplier):
                return QColor(241,144,33);
            case static_cast<int>(MetaNodeType::LinearSolver):
                return QColor(63,150,88);
            case static_cast<int>(MetaNodeType::HiPerProblem):
                return QColor(0,167,226);
            case static_cast<int>(MetaNodeType::NonLinearSystem):
                return QColor(0,167,226);
            case static_cast<int>(MetaNodeType::TimeIterator):
                return QColor(0,167,226);
            case static_cast<int>(MetaNodeType::Solve):
                return QColor(0,167,226);
            case static_cast<int>(MetaNodeType::Output):
                return QColor(0,167,226);
            default:
                throw std::runtime_error("bColor: MetaNodeType undefined.");
        }
    }

    inline QColor bColor(NodeType nType)
    {
        return bColor(metaType(nType));
    }

    enum class appStyle
    {
        Undefined,
        DarkStyle,
        LightStyle
    };

    //Port
    enum class PortType
    {
        Undefined,
        InPort,
        OutPort
    };

    inline QString qstr(PortType pt)
    {
        if (pt == PortType::Undefined)
            return QString::fromStdString("Undefined");
        else if (pt == PortType::InPort)
            return QString::fromStdString("In port");
        else if (pt == PortType::OutPort)
            return QString::fromStdString("Out port");
        else
            throw std::runtime_error("str: Port type not recognized.");
    }

    //Converters
    inline hiperlife::BasisFuncType BasisFunction(QString qstr)
    {
        return hiperlife::BasisFunction(qstr.toUtf8().constData());
    }

    inline hiperlife::ElemType Element(QString qstr)
    {
        return hiperlife::Element(qstr.toUtf8().constData());
    }

}

#endif
