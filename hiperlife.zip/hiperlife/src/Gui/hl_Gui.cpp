/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <QApplication>
#include <QFile>
#include <QTextStream>

// C++ headers
#include <mpi.h>

//GUI headers
#include "hl_MainWindow.h"
#include "hl_GuiTypes.h"

//QtVTK
#include <QSurfaceFormat>
#include <QVTKOpenGLNativeWidget.h>

using namespace hlGui;

int main(int argc, char *argv[])
{
    MPI_Init(nullptr, nullptr);

    //Before initializing QApplication, set the default surface format.
    QSurfaceFormat::setDefaultFormat(QVTKOpenGLNativeWidget::defaultFormat());

    //Initialize app
    QApplication app(argc, argv);
    QApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    // Load light application style
    QFile lightStyleFile( ":/qss/newstylesheet.qss" );
    lightStyleFile.open(QFile::ReadOnly);

    //Modify the style
    QString lightStyle(lightStyleFile.readAll());
    lightStyle.replace("mainColor1", "white");
    lightStyle.replace("mainColor2", "rgb(245, 245, 245)");
    lightStyle.replace("mainColor3", "rgb(200, 200, 200)");
    lightStyle.replace("mainColor4", "rgb(160, 160, 160)");
    lightStyle.replace("textColor0", "black");
    lightStyle.replace("textColor1", "rgb(20, 20, 20)");
    lightStyle.replace("textColor2", "rgb(180, 180, 180)");

    // Load dark application style
    QFile darkStyleFile( ":/qss/newstylesheet.qss" );
    darkStyleFile.open(QFile::ReadOnly);

    //Modify the style
    QString darkStyle(darkStyleFile.readAll());
    darkStyle.replace("mainColor1", "rgb(0,0,0)");
    darkStyle.replace("mainColor2", "rgb(20,20,20)");
    darkStyle.replace("mainColor3", "rgb(50,50,50)");
    darkStyle.replace("mainColor4", "rgb(90,90,90)");
    darkStyle.replace("textColor0", "white");
    darkStyle.replace("textColor1", "#eff0f1");
    darkStyle.replace("textColor2", "rgb(120, 120, 120)");

    // Load dark application style
    QFile darkStyleFile2( ":/qss/newstylesheet2.qss" );
    darkStyleFile2.open(QFile::ReadOnly);

    //Modify the style
    QString darkStyle2(darkStyleFile2.readAll());
    darkStyle2.replace("mainColor1", "rgb(30,30,30)");
    darkStyle2.replace("mainColor2", "rgb(70,70,70)");
    darkStyle2.replace("mainColor3", "rgb(90,90,90)");
    darkStyle2.replace("mainColor4", "rgb(110,110,110)");
    darkStyle2.replace("mainColor5", "rgb(50,50,50)");
    darkStyle2.replace("textColor0", "white");
    darkStyle2.replace("textColor1", "#eff0f1");
    darkStyle2.replace("textColor2", "rgb(150, 150, 150)");

    //Apply stylesheet
    appStyle style = appStyle::DarkStyle;
    if (style == appStyle::DarkStyle)
        app.setStyleSheet(darkStyle2);
    else
        app.setStyleSheet(lightStyle);

    //Create window
    MainWindow window(style);
    window.setWindowTitle("hiperlife");
    window.setWindowIcon(QIcon(":/img/logo.png"));
    window.setGeometry(0, 0, 1500, 700);
    int desktopArea = QApplication::desktop()->width() * QApplication::desktop()->height();
    int widgetArea = window.width() * window.height();
    if (((float)widgetArea / (float)desktopArea) < 0.75f)
        window.show();
    else
        window.showMaximized();

    //Run app
    return app.exec();

    MPI_Finalize();
}
