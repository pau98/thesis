/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <filesystem>

//hiperlife
#include "hl_VtkWidget.h"

//Qt
#include <QFile>

//Vtk
#include <vtkGenericOpenGLRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderWindow.h>
#include <vtkDataSetMapper.h>
#include <vtkProperty.h>
#include <vtkDataSetReader.h>

// #include <vtkCamera.h>
// #include <vtkActor.h>
// #include <vtkGenericOpenGLRenderWindow.h>
// #include <vtkNamedColors.h>
// #include <vtkNew.h>
// #include <vtkPolyDataMapper.h>
// #include <vtkProperty.h>
// #include <vtkRenderWindow.h>
// #include <vtkRenderer.h>
// #include <vtkSphereSource.h>
// #include <vtkVersion.h>

#include <vtkSmartPointer.h>
#include <vtkTetra.h>
#include <vtkCellArray.h>
#include <vtkXMLUnstructuredGridReader.h>
#include <vtkDataSetMapper.h>
#include <vtkActor.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkXMLUnstructuredGridWriter.h>
#include <vtkUnstructuredGrid.h>
#include <vtkPointData.h>
#include <vtkVertexGlyphFilter.h>
#include <vtkScalarBarActor.h>
#include <vtkLookupTable.h>
#include <vtkColorSeries.h>
#include <vtkColorTransferFunction.h>

#include <Teuchos_RCP.hpp>

#include "hl_PostProc.h"
#include "hl_VtkGrid.h"


using namespace hlGui;
using namespace hiperlife;
using namespace std;

VtkWidget::VtkWidget(appStyle st, QWidget *parent): QVTKOpenGLNativeWidget(parent)
{
    // Camera
    camera = vtkSmartPointer<vtkCamera>::New();
    camera->SetViewUp(0,1,0);
    camera->SetPosition(0,0,1);
    camera->SetFocalPoint(0,0,0);

    // vtkNew<vtkNamedColors> colors;

    //Renderer
    renderer = vtkSmartPointer<vtkRenderer>::New();
    if (st == appStyle::DarkStyle)
        renderer->SetBackground(0, 0, 0);
    else if (st == appStyle::LightStyle)
        renderer->SetBackground(1, 1, 1);
    renderer->SetBackground(0.1176, 0.1176, 0.1176);

    //Window
    vtkNew<vtkGenericOpenGLRenderWindow> renderWindow;
    setRenderWindow(renderWindow);
    renderWindow->AddRenderer(renderer);

    //Show
    show();
}

void VtkWidget::addDataSet(vtkSmartPointer<vtkDataSet> dataSet)
{
    //Save data set
    _dataSet = dataSet;
}

void VtkWidget::_draw()
{

    // Mapper
    vtkSmartPointer<vtkDataSetMapper> mapper = vtkSmartPointer<vtkDataSetMapper>::New();
    mapper->SetInputData(_dataSet);
    // mapper->ScalarVisibilityOn();
    // mapper->SetColorModeToMapScalars();
    mapper->SetScalarModeToUsePointFieldData();
    mapper->SelectColorArray(0);

    vtkIdType numberOfPointArrays = _dataSet->GetPointData()->GetNumberOfArrays();
    std::cout << "Number of PointData arrays: " << numberOfPointArrays << std::endl;
    for (vtkIdType i = 0; i < numberOfPointArrays; i++)
    {
        // The following two lines are equivalent
        //arrayNames.push_back(polydata->GetPointData()->GetArray(i)->GetName());
        //arrayNames.push_back(polydata->GetPointData()->GetArrayName(i));
        int dataTypeID = _dataSet->GetPointData()->GetArray(i)->GetDataType();
        std::cout << "Array " << i << ": " << _dataSet->GetPointData()->GetArrayName(i)
                  << " (type: " << dataTypeID << ")" << std::endl;
    }

    double *range;
    if (numberOfPointArrays > 0)
    {
        range = _dataSet->GetPointData()->GetArray(0)->GetRange();
        cout << range[0] << endl;
        cout << range[1] << endl;
        mapper->SetScalarRange(range[0], range[1]);
    }

    // Actor
    vtkSmartPointer<vtkActor> actor = vtkSmartPointer<vtkActor>::New();
    actor->SetMapper(mapper);
    actor->GetProperty()->SetEdgeVisibility(true);


    // Create a lookup table to share between the mapper and the scalarbar
    vtkSmartPointer<vtkColorTransferFunction> lut = vtkSmartPointer<vtkColorTransferFunction>::New();
    lut->SetColorSpaceToHSV();

    // Use a color series to create a transfer function
    vtkSmartPointer<vtkColorSeries> colorSeries = vtkSmartPointer<vtkColorSeries>::New();
    colorSeries->SetColorScheme(_colorScheme);
    int numColors = colorSeries->GetNumberOfColors();
    for (int i = 0; i < numColors; i++)
    {
        vtkColor3ub color = colorSeries->GetColor(i);
        double dColor[3];
        dColor[0] = static_cast<double> (color[0]) / 255.0;
        dColor[1] = static_cast<double> (color[1]) / 255.0;
        dColor[2] = static_cast<double> (color[2]) / 255.0;
        double t{};
        if (numberOfPointArrays > 0)
            t = range[0] + (range[1] - range[0]) / (numColors - 1) * i;
        lut->AddRGBPoint(t, dColor[0], dColor[1], dColor[2]);
    }
    mapper->SetLookupTable(lut);


    //Scalar bar
    vtkSmartPointer<vtkScalarBarActor> scalarBar = vtkSmartPointer<vtkScalarBarActor>::New();
    scalarBar->SetLookupTable(mapper->GetLookupTable());
    scalarBar->SetTitle("Title");
    scalarBar->SetNumberOfLabels(4);
    // scalarBar->SetLookupTable(lut);

    // // Actor wireframe/points
    // vtkSmartPointer<vtkActor> actor2 = vtkSmartPointer<vtkActor>::New();
    // actor2->SetMapper(mapper);
    // // actor2->GetProperty()->SetRepresentationToWireframe();
    // actor2->GetProperty()->SetRepresentationToPoints();
    // actor2->GetProperty()->SetRenderPointsAsSpheres(true);
    // actor2->GetProperty()->SetColor(0.5, 0, 0);
    // actor2->GetProperty()->SetLineWidth(10);
    // actor2->GetProperty()->SetPointSize(7.0);

    //Add to renderer
    renderer->AddActor(actor);
    // renderer->AddActor(actor2);
    // renderer->AddActor2D(scalarBar);
    renderer->ResetCamera(_dataSet->GetBounds());

    //Render
    renderer->Render();
}

void VtkWidget::removeDataSet()
{
    int n = renderer->GetActors()->GetNumberOfItems();
    for (int i = 0; i < n; i ++)
    {
        vtkActor *actor = renderer->GetActors()->GetLastActor();
        if (actor != nullptr)
            renderer->RemoveActor(actor);
    }

    //Render
    renderer->Render();
}

void VtkWidget::loadFromFile(QString fileName)
{
    //Remove
    removeDataSet();

    // fileName = "/home/guille/Programs/guihiperlifelib/tests/Poisson";
    string fName = fileName.toStdString();

    //Get file names and sort them
    vector<string> fNames;
    filesystem::path dir(fName);
    cout << dir << endl;
    cout << dir.filename() << endl;

    for (const filesystem::directory_entry& f : filesystem::directory_iterator(dir.parent_path()))
    {
        if (starts_with(filesystem::path(f).filename().string(), dir.filename().string()) and
            ends_with(filesystem::path(f).filename().string(), ".hl"))
            fNames.push_back(f.path().string());
            // cout << " " << f.path() << '\n';
    }

    //Add new data
    try
    {
        //Create grid
        Teuchos::RCP<PostProc::VtkGrid> grid = Teuchos::rcp(new PostProc::VtkGrid());
        grid->setFileName(fNames[0]);
        grid->Update();
        cout << "vtkGrid done" << endl;

        //Plot
        addDataSet(grid->unstructGrid());
        _draw();
        cout << "Plot" << endl;
    }
    catch (std::runtime_error&)
    {
        cout << "Cannot create grid" << endl;
    }

    // //Check if file exists
    // QFile file(fileName);
    // file.open(QIODevice::ReadOnly);
    // if (!file.exists())
    //     return;

    // // Create reader
    // vtkSmartPointer<vtkDataSetReader> reader = vtkSmartPointer<vtkDataSetReader>::New();
    // reader->SetFileName(fileName.toStdString().c_str());

    // // Read the file
    // reader->Update();

    // // Add data set to 3D view
    // vtkSmartPointer<vtkDataSet> dataSet = reader->GetOutput();
    // if (dataSet != nullptr)
    //     addDataSet(reader->GetOutput());
}

void VtkWidget::loadFromMeshCreator(Teuchos::RCP<hiperlife::MeshCreator> mesh)
{
    //Remove
    removeDataSet();

    //Add new data
    try
    {
        //Create grid
        Teuchos::RCP<PostProc::VtkGrid> grid = Teuchos::rcp(new PostProc::VtkGrid());
        grid->setMesh(mesh);
        grid->Update();
        cout << "vtkGrid done" << endl;

        //Plot
        addDataSet(grid->unstructGrid());
        _draw();
        cout << "Plot" << endl;
    }
    catch (std::runtime_error& err)
    {
        cout << "Cannot create grid" << endl;
    }

}

void VtkWidget::loadFromDOFsHandler(Teuchos::RCP<hiperlife::DOFsHandler> dHand)
{

}

void VtkWidget::setViewTop()
{
    //Set camera
    camera->SetFocalPoint(0,0,0);
    camera->SetPosition(0,0,1);
    camera->SetViewUp(0,1,0);

    // // renderer->SetActiveCamera(camera);
    // // renderer->ResetCamera(dataSet->GetBounds());
    renderer->ResetCamera();

    // renderer->GetActiveCamera()->SetPosition(0, 0, 1);
    // renderer->GetActiveCamera()->SetViewUp(0, 1, 0);
    // renderer->ResetCamera();

    //Show
    //Render
    renderer->Render();
}

void VtkWidget::setColorScheme(int colorScheme)
{
    _colorScheme = colorScheme;
    _draw();
}

namespace hlGui
{
    bool starts_with(std::string const &str, std::string const &suffix) {
        if (str.length() < suffix.length()) {
            return false;
        }
        return str.compare(0, suffix.length(), suffix) == 0;
    }

    bool ends_with(std::string const &str, std::string const &suffix) {
        if (str.length() < suffix.length()) {
            return false;
        }
        return str.compare(str.length() - suffix.length(), suffix.length(), suffix) == 0;
    }
}
