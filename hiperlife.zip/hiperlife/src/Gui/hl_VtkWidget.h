/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef VTKWIDGET_H
#define VTKWIDGET_H

// Qt headers
#include <QVTKOpenGLNativeWidget.h>
#include <vtkSmartPointer.h>
#include <vtkRenderer.h>
#include <vtkCamera.h>
#include <vtkDataSet.h>

//Gui headers
#include "hl_GuiTypes.h"

// hiperlife headers
#include "hl_MeshCreator.h"
#include "hl_DOFsHandler.h"
#include "hl_PostProc.h"
#include "hl_VtkGrid.h"

namespace hlGui
{

    class VtkWidget : public QVTKOpenGLNativeWidget
    {
            Q_OBJECT

        public:
            VtkWidget(appStyle st, QWidget *parent = 0);

            void addDataSet(vtkSmartPointer<vtkDataSet> dataSet);
            void removeDataSet();

        public slots:
            void loadFromFile(QString fileName);
            void loadFromMeshCreator(Teuchos::RCP<hiperlife::MeshCreator> mesh);
            void loadFromDOFsHandler(Teuchos::RCP<hiperlife::DOFsHandler> dHand);
            void setViewTop();
            void setColorScheme(int cS);

        private:
            vtkSmartPointer<vtkRenderer> renderer;
            vtkSmartPointer<vtkCamera> camera;
            vtkSmartPointer<vtkDataSet> _dataSet;
            appStyle _st{appStyle::Undefined};
            int _colorScheme{1};

            void _draw();

    };

    bool starts_with(std::string const &str, std::string const &suffix);

    bool ends_with(std::string const &str, std::string const &suffix);

}
#endif // VTKWIDGET_H
