#------------------------------------------------------------
# Source files for HiPerLIFE GUI
#------------------------------------------------------------

# Display message
message(STATUS "Configuring GUI")

# Load vtk
if(NOT VTK_FOUND)
  message(STATUS "  Warning!! Vtk is not in the system. Gui module is disabled.")
  return()
else(NOT VTK_FOUND)
  if(VTK_VERSION VERSION_LESS "8.0")
    message(STATUS "  Warning!! Gui module needs (at least) vtk version 8. Gui module is disabled.")
    return()
  endif()
endif(NOT VTK_FOUND)

#=========================== Qt5 ============================
if(ENABLE_QT)
  find_package(Qt5 HINTS ${Qt5_BASE_PATH} COMPONENTS Core Widgets)
  if(Qt5_FOUND)
    message(STATUS "  Qt5:\t Found version ${Qt5_VERSION} at ${Qt5_DIR}")
  else()
    message(STATUS "  Warning!! Qt is not in the system. Gui module is disabled.")
    return()
  endif()
else(ENABLE_QT)
  message(STATUS "  Warning!! Qt is not enabled. Gui module is disabled.")
  return()
endif(ENABLE_QT)

# Find includes in corresponding build directories
set(CMAKE_INCLUDE_CURRENT_DIR ON)
# Instruct CMake to run moc automatically when needed
set(CMAKE_AUTOMOC ON)
# Create code from a list of Qt designer ui files
set(CMAKE_AUTOUIC ON)
# Resource files
set(CMAKE_AUTORCC ON)

# Set name
set(EXECNAME hlGUI)
message(STATUS "  ${EXECNAME}")

# Add executable
file(GLOB SOURCES_CPP hl*.cpp)
file(GLOB SOURCES_H hl*.h)
add_executable(${EXECNAME} ${SOURCES_CPP} ${SOURCES_H} resources.qrc)

# Link libraries
target_link_libraries(${EXECNAME} ${MPI_LIB})
target_link_libraries(${EXECNAME} ${Trilinos_LIBRARIES})
target_link_libraries(${EXECNAME} ${HPLFE_LIBRARIES})
target_link_libraries(${EXECNAME} Qt5::Widgets)

#Install
install(TARGETS ${EXECNAME} DESTINATION bin)
