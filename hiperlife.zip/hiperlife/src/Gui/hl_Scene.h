/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef hl_SCENE_H
#define hl_SCENE_H

#include <iostream>
#include <vector>
using namespace std;


#include <QGraphicsScene>

#include "hl_GuiTypes.h"
#include "hl_Node.h"
#include "hl_Link.h"

namespace hlGui
{

    class Scene : public QGraphicsScene
    {
            Q_OBJECT
        public:
            Scene(QObject *parent = 0);
            Scene(const Scene&) = delete;
            Scene operator=(const Scene&) = delete;
            ~Scene();

            void run();
            void save(QDataStream &ds);
            void open(QDataStream &ds);

        signals:
            void allDataUpdated(QVector<QString> _allData);
            void plotTest();
            void meshCreatorUpdated(Teuchos::RCP<hiperlife::MeshCreator> mesh);
            void vSolution(QString fPrefix);

        public slots:
            Node* createNode(NodeType nType, QPointF pos = {0,0});
            void updateAllData();
            void selectAllNodes();
            void deleteNode(Node *n);
            void deleteLink(Link *l);
            void deleteItems();
            inline void blockNode(Node *n){n->block(true);};
            inline void unblockNode(Node *n){n->block(false);};
            void blockNodes();
            void unblockNodes();
            void toggleVisAllItems(bool v);
            void updateAllVtk();
            void viewSolution(QString fPrefix){emit(vSolution(fPrefix));}

        private:
            Link *link = 0;
            QVector<QString> _allData;
            hiperlife::StructMeshGenerator structMesh;

            void _createLink(Port* p0, Port *p1);

            void _nodeData(Node* n, MetaNodeType mnType);
            void _nodeData(Node* n, NodeType nType);

            QGraphicsItem *itemAt(const QPointF&);

        protected:

            void mousePressEvent(QGraphicsSceneMouseEvent *me) override;
            void mouseMoveEvent(QGraphicsSceneMouseEvent *me) override;
            void mouseReleaseEvent(QGraphicsSceneMouseEvent *me) override;
            void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *me) override;

    };
}
#endif
