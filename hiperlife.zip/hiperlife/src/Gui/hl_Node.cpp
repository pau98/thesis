/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

// C++ headers
#include <iostream>
#include <fstream>

// Qt headers
#include <QPen>
#include <QPainter>
#include <QStyleOptionGraphicsItem>
#include <QGraphicsProxyWidget>
#include <QtWidgets> //Remove
#include <QSizePolicy>
#include <QLayout>
#include <QFrame>

#include "hl_Node.h"
#include "hl_Port.h"

using namespace hlGui;

Node::Node(NodeType nType, QGraphicsItem *parent) : QGraphicsPathItem(parent)
{
    //General properties
    _nType = nType;
    _mnType = metaType(_nType);
    setFlag(ItemIsMovable);
    setFlag(ItemIsSelectable);
}

void Node::Update()
{
    //Main widget
    _createMainWidget();

    //Get dimensions
    _height = _mainWidget->height()+20;
    _width = std::max(200, _mainWidget->width())+40;

    //Name
    _createLabel();

    //Ports
    _createPorts();

    //Data
    _updateAllInfo();
}

//Create
void Node::_createLabel()
{
    //Name (editable)
    _name = new QLineEdit();
    QString name = qabrev(_nType);
    if (_nameNumber > 0)
        name += QString::number(_nameNumber);
    _name->setText(name);
    _name->setAlignment(Qt::AlignCenter);
    _name->setFixedSize(90, 25);
    _name->setStyleSheet("color: white; background:rgba(0,0,0,0);padding:0px;");
    connect(_name, SIGNAL(textChanged(QString)), SLOT(_updateAllInfo()));

    //Layout
    QHBoxLayout *nLayout = new QHBoxLayout();
    nLayout->addWidget(_name);
    nLayout->setContentsMargins(0, 0, 0, 0);
    nLayout->setAlignment(Qt::AlignCenter);

    //Widget
    _nameWidget = new QWidget();
    _nameWidget->setLayout(nLayout);
    _nameWidget->setStyleSheet("color: white; background:rgba(0,0,0,0);");
    _nameWidget->setFixedWidth(_width);
    _nameWidget->setFixedHeight(35);

    //Add to node
    QGraphicsProxyWidget* pMyProxy = new QGraphicsProxyWidget(this);
    pMyProxy->setWidget(_nameWidget);

    //Hamb
    hambButton = new QPushButton();
    hambButton->setCheckable(true);
    hambButton->setIcon(QIcon(":/img/hamb.svg"));
    hambButton->setFixedSize(25, 25);
    hambButton->setIconSize(QSize(25, 25));
    hambButton->setStyleSheet("background:rgba(0,0,0,0); border: none; padding:0px;");

    //Layout
    QHBoxLayout *hLayout = new QHBoxLayout();
    hLayout->addWidget(hambButton);
    hLayout->setContentsMargins(0, 0, 0, 0);
    hLayout->setAlignment(Qt::AlignLeft);

    //Widget
    QWidget *_hWidget = new QWidget();
    _hWidget->setLayout(hLayout);
    _hWidget->setStyleSheet("color: white; background:rgba(0,0,0,0);");
    _hWidget->setContentsMargins(5, 5, 0, 0);

    //Add to node
    QGraphicsProxyWidget* hMyProxy = new QGraphicsProxyWidget(this);
    hMyProxy->setWidget(_hWidget);

    //Separator
    QFrame* line = new QFrame();
    line->setFrameShape(QFrame::VLine);
    // line->setFrameShadow(QFrame::Sunken);

    //Delete
    delButton = new QPushButton();
    delButton->setIcon(QIcon(":/img/delete.svg"));
    delButton->setFixedSize(35, 35);
    delButton->setIconSize(QSize(35, 35));
    delButton->setStyleSheet("background:rgba(0,0,0,0); border: none; padding:0px;");

    //Hide
    hideButton = new QPushButton();
    hideButton->setCheckable(true);
    hideButton->setIcon(QIcon(":/img/collapse.svg"));
    hideButton->setFixedSize(35, 35);
    hideButton->setIconSize(QSize(35, 35));
    hideButton->setStyleSheet("background:rgba(0,0,0,0); border: none; padding:0px;");
    connect(hideButton, SIGNAL(toggled(bool)), SLOT(_visibility(bool)));

    //Block
    blockButton = new QPushButton();
    blockButton->setCheckable(true);
    blockButton->setChecked(false);
    blockButton->setIcon(QIcon(":/img/lock.svg"));
    blockButton->setFixedSize(35, 35);
    blockButton->setIconSize(QSize(35, 35));
    blockButton->setStyleSheet("background:rgba(0,0,0,0); border: none; padding:0px;");
    connect(blockButton, SIGNAL(toggled(bool)), SLOT(block(bool)));

    //Layout
    QHBoxLayout *bLayout = new QHBoxLayout();
    bLayout->addWidget(line);
    bLayout->addWidget(delButton);
    bLayout->addWidget(hideButton);
    bLayout->addWidget(blockButton);
    bLayout->setContentsMargins(0, 0, 0, 0);
    bLayout->setAlignment(Qt::AlignLeft);

    //Widget
    _bWidget = new QWidget();
    _bWidget->setLayout(bLayout);
    _bWidget->setStyleSheet("QWidget {background-color:"+bColor(_mnType).name()+";}");
    _bWidget->setFixedWidth(_width-35*2);
    _bWidget->setFixedHeight(34);
    _bWidget->setVisible(false);

    //Add to node
    QGraphicsProxyWidget* bMyProxy = new QGraphicsProxyWidget(this);
    bMyProxy->setWidget(_bWidget);
    bMyProxy->setPos(35, 1);

    //Connect
    connect(hambButton, SIGNAL(toggled(bool)), _bWidget, SLOT(setVisible(bool)));
}

void Node::_createMainWidget()
{
    //Create specific layouts
    mainLayout = new QVBoxLayout();
    if (_nType == NodeType::StructMeshGenerator)
    {
        //Geometry label
        QLabel *geomLabel = new QLabel();
        geomLabel->setText("Geometry:");
        QFrame *geomLine = new QFrame;
        geomLine->setFrameShape(QFrame::HLine);
        // geomLine->setFrameShadow(QFrame::Sunken);

        //Generator
        genBox = new QComboBox;
        genBox->addItem("Geometry");
        genBox->addItem(QPixmap(":/img/gen_00.svg"), "", "genStructMesh");
        genBox->addItem(QPixmap(":/img/gen_01.svg"), "", "genLine");
        genBox->addItem(QPixmap(":/img/gen_02.svg"), "", "genSquare");
        genBox->addItem(QPixmap(":/img/gen_03.svg"), "", "genCube");
        genBox->addItem(QPixmap(":/img/gen_04.svg"), "", "genCircularArc");
        genBox->addItem(QPixmap(":/img/gen_05.svg"), "", "genCircle");
        genBox->addItem(QPixmap(":/img/gen_06.svg"), "", "genTorusSolidSector");
        genBox->setIconSize(QSize(50, 75));
        // genBox->setMinimumSize(QSize(50, 100));
        QStandardItemModel* genModel = qobject_cast<QStandardItemModel*>(genBox->model());
        QModelIndex genFirstIndex = genModel->index(0, genBox->modelColumn(), genBox->rootModelIndex());
        QStandardItem* genFirstItem = genModel->itemFromIndex(genFirstIndex);
        genFirstItem->setSelectable(false);
        genBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");

        //Number of elements
        QLabel *nElemLabel = new QLabel();
        nElemLabel->setText("Elements:");
        nExLEdit = new QLineEdit();
        nExLEdit->setPlaceholderText(QString("nElem X"));
        nExLEdit->setAlignment(Qt::AlignRight);
        nEyLEdit = new QLineEdit();
        nEyLEdit->setPlaceholderText(QString("nElem Y"));
        nEyLEdit->setAlignment(Qt::AlignRight);
        nEzLEdit = new QLineEdit();
        nEzLEdit->setPlaceholderText(QString("nElem Z"));
        nEzLEdit->setAlignment(Qt::AlignRight);
        QIntValidator *v = new QIntValidator();
        v->setBottom(1);
        nExLEdit->setValidator(v);
        nEyLEdit->setValidator(v);
        nEzLEdit->setValidator(v);
        QVBoxLayout *nElemLayout = new QVBoxLayout();
        nElemLayout->addWidget(nExLEdit);
        nElemLayout->addWidget(nEyLEdit);
        nElemLayout->addWidget(nEzLEdit);

        //Geometry layout
        QHBoxLayout *geomLayout = new QHBoxLayout();
        geomLayout->addWidget(genBox);
        geomLayout->addLayout(nElemLayout);

        //Other fields
        QLabel *fieldsLabel = new QLabel();
        fieldsLabel->setText("Fields:");
        QHBoxLayout *gLayout = new QHBoxLayout();
        for (int i = 0; i < 4; i++)
        {
            gOptLEdit.push_back(new QLineEdit);
            gOptLEdit[i]->setPlaceholderText(QString("#"));
            gOptLEdit[i]->setAlignment(Qt::AlignRight);
            gLayout->addWidget(gOptLEdit[i]);
        }
        QVBoxLayout *gOptLayout = new QVBoxLayout();
        gOptLayout->addWidget(fieldsLabel);
        gOptLayout->addLayout(gLayout);


        //Discretization label
        QLabel *disLabel = new QLabel();
        disLabel->setText("Discretization:");
        QFrame *disLine = new QFrame;
        disLine->setFrameShape(QFrame::HLine);
        // geomLine->setFrameShadow(QFrame::Sunken);

        //Elements
        elemBox = new QComboBox;
        elemBox->addItem("Element");
        elemBox->addItem(QPixmap(":/img/el_0.svg"), "", "Line");
        elemBox->addItem(QPixmap(":/img/el_1.svg"), "", "Triang");
        elemBox->addItem(QPixmap(":/img/el_2.svg"), "", "Square");
        elemBox->addItem(QPixmap(":/img/el_3.svg"), "", "Tetrah");
        elemBox->addItem(QPixmap(":/img/el_4.svg"), "", "Parallelep");
        elemBox->setIconSize(QSize(50, 50));
        QStandardItemModel* elemModel = qobject_cast<QStandardItemModel*>(elemBox->model());
        QModelIndex elemFirstIndex = elemModel->index(0, elemBox->modelColumn(), elemBox->rootModelIndex());
        QStandardItem* elemFirstItem = elemModel->itemFromIndex(elemFirstIndex);
        elemFirstItem->setSelectable(false);
        elemBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");

        //Basis function
        bfBox = new QComboBox;
        bfBox->addItem("Basis");
        // bfBox->addItem(QPixmap(":/img/el_linear.svg"), "", "Linear");
        bfBox->addItem(QPixmap(":/img/bf_0.svg"), "", "Lagrangian");
        bfBox->addItem(QPixmap(":/img/bf_1.svg"), "", "SubdivSurfs");
        bfBox->addItem(QPixmap(":/img/bf_2.svg"), "", "BSplines");
        bfBox->addItem(QPixmap(":/img/bf_3.svg"), "", "Nurbs");
        bfBox->setIconSize(QSize(50, 50));
        QStandardItemModel* bfModel = qobject_cast<QStandardItemModel*>(bfBox->model());
        QModelIndex bfFirstIndex = bfModel->index(0, bfBox->modelColumn(), bfBox->rootModelIndex());
        QStandardItem* bfFirstItem = bfModel->itemFromIndex(bfFirstIndex);
        bfFirstItem->setSelectable(false);
        bfBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");

        //Element and basis layout
        QHBoxLayout *bfLayout = new QHBoxLayout();
        bfLayout->addWidget(elemBox);
        bfLayout->addWidget(bfBox);

        //Basis function order
        QLabel *orderLabel = new QLabel();
        orderLabel->setText("Basis function order:");
        orderLEdit = new QLineEdit();
        orderLEdit->setPlaceholderText(QString("#"));
        orderLEdit->setMaximumWidth(30);
        orderLEdit->setAlignment(Qt::AlignRight);
        orderLEdit->setValidator(new QIntValidator(0, 100, this));
        QHBoxLayout *orderLayout = new QHBoxLayout();
        orderLayout->addWidget(orderLabel);
        orderLayout->addWidget(orderLEdit);


        //Main layout
        mainLayout->addWidget(geomLabel);
        mainLayout->addWidget(geomLine);
        mainLayout->addLayout(geomLayout);
        mainLayout->addLayout(gOptLayout);
        mainLayout->addWidget(disLabel);
        mainLayout->addWidget(disLine);
        mainLayout->addLayout(bfLayout);
        mainLayout->addLayout(orderLayout);
    }
    else if (_nType == NodeType::MeshLoader)
    {
        //File label
        QLabel *fileLabel = new QLabel();
        fileLabel->setText("Load file:");
        QFrame *fileLine = new QFrame;
        fileLine->setFrameShape(QFrame::HLine);

        //File
        fileLEdit = new QLineEdit();
        fileLEdit->setPlaceholderText(QString("<path-to-file>"));
        QPushButton *fileButton = new QPushButton("Browse");
        connect(fileButton, &QAbstractButton::clicked, this, [=](){this->_browseOpen(fileLEdit);});
        QHBoxLayout *fileLayout = new QHBoxLayout();
        fileLayout->addWidget(fileLEdit);
        fileLayout->addWidget(fileButton);


        //Discretization label
        QLabel *disLabel = new QLabel();
        disLabel->setText("Discretization:");
        QFrame *disLine = new QFrame;
        disLine->setFrameShape(QFrame::HLine);

        //Elements
        elemBox = new QComboBox;
        elemBox->addItem("Element");
        elemBox->addItem(QPixmap(":/img/el_0.svg"), "", "Line");
        elemBox->addItem(QPixmap(":/img/el_1.svg"), "", "Triang");
        elemBox->addItem(QPixmap(":/img/el_2.svg"), "", "Square");
        elemBox->addItem(QPixmap(":/img/el_2.svg"), "", "Tetrah");
        elemBox->addItem(QPixmap(":/img/el_4.svg"), "", "Parallelep");
        elemBox->setIconSize(QSize(50, 50));
        QStandardItemModel* elemModel = qobject_cast<QStandardItemModel*>(elemBox->model());
        QModelIndex elemFirstIndex = elemModel->index(0, elemBox->modelColumn(), elemBox->rootModelIndex());
        QStandardItem* elemFirstItem = elemModel->itemFromIndex(elemFirstIndex);
        elemFirstItem->setSelectable(false);
        elemBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");

        //Basis function
        bfBox = new QComboBox;
        bfBox->addItem("Basis");
        bfBox->addItem(QPixmap(":/img/bf_0.svg"), "", "Lagrangian");
        bfBox->addItem(QPixmap(":/img/bf_1.svg"), "", "SubdivSurfs");
        bfBox->addItem(QPixmap(":/img/bf_2.svg"), "", "BSplines");
        bfBox->addItem(QPixmap(":/img/bf_3.svg"), "", "Nurbs");
        bfBox->setIconSize(QSize(50, 50));
        QStandardItemModel* bfModel = qobject_cast<QStandardItemModel*>(bfBox->model());
        QModelIndex bfFirstIndex = bfModel->index(0, bfBox->modelColumn(), bfBox->rootModelIndex());
        QStandardItem* bfFirstItem = bfModel->itemFromIndex(bfFirstIndex);
        bfFirstItem->setSelectable(false);
        bfBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");

        //Element and basis layout
        QHBoxLayout *bfLayout = new QHBoxLayout();
        bfLayout->addWidget(elemBox);
        bfLayout->addWidget(bfBox);

        //Basis function order
        QLabel *orderLabel = new QLabel();
        orderLabel->setText("Basis function order:");
        orderLEdit = new QLineEdit();
        orderLEdit->setPlaceholderText(QString("#"));
        orderLEdit->setMaximumWidth(30);
        orderLEdit->setAlignment(Qt::AlignRight);
        orderLEdit->setValidator(new QIntValidator(0, 100, this));
        QHBoxLayout *orderLayout = new QHBoxLayout();
        orderLayout->addWidget(orderLabel);
        orderLayout->addWidget(orderLEdit);

        //Main layout
        mainLayout->addWidget(fileLabel);
        mainLayout->addWidget(fileLine);
        mainLayout->addLayout(fileLayout);
        mainLayout->addWidget(disLabel);
        mainLayout->addWidget(disLine);
        mainLayout->addLayout(bfLayout);
        mainLayout->addLayout(orderLayout);
    }
    else if (_nType == NodeType::DistributedMesh)
    {
        //Elements
        balCheckBox = new QCheckBox("Balance mesh");
        balCheckBox->setStyleSheet("QCheckBox Indicator {border:3px solid white;}");
        balCheckBox->setChecked(true);
        QHBoxLayout *balLayout = new QHBoxLayout();
        balLayout->addWidget(balCheckBox);
        balLayout->setAlignment(Qt::AlignCenter);

        //Main layout
        mainLayout->addLayout(balLayout);
    }
    else if (_nType == NodeType::hDistributedMesh)
    {
        //Refinement level
        QLabel *hLabel = new QLabel();
        hLabel->setText("h-refinement level:");

        hLEdit = new QLineEdit();
        hLEdit->setPlaceholderText(QString("#"));
        hLEdit->setMaximumWidth(30);
        hLEdit->setAlignment(Qt::AlignRight);

        QHBoxLayout *hLayout = new QHBoxLayout();
        hLayout->addWidget(hLabel);
        hLayout->addWidget(hLEdit);

        //Main layout
        mainLayout->addLayout(hLayout);
    }
    else if (_nType == NodeType::pDistributedMesh)
    {
        //Refinement level
        QLabel *pLabel = new QLabel();
        pLabel->setText("p-refinement level:");

        pLEdit = new QLineEdit();
        pLEdit->setPlaceholderText(QString("#"));
        pLEdit->setMaximumWidth(30);
        pLEdit->setAlignment(Qt::AlignRight);

        QHBoxLayout *pLayout = new QHBoxLayout();
        pLayout->addWidget(pLabel);
        pLayout->addWidget(pLEdit);

        //Main layout
        mainLayout->addLayout(pLayout);
    }
    else if (_nType == NodeType::DOFsHandler)
    {
        //DOFs number
        QLabel *dofsLabel = new QLabel();
        dofsLabel->setText("DOFs:");
        dofsLEdit = new QLineEdit();
        dofsLEdit->setText("1");
        dofsLEdit->setMaximumWidth(40);
        dofsLEdit->setAlignment(Qt::AlignRight);
        dofsLEdit->setValidator(new QIntValidator(1, 6, this));
        QHBoxLayout *dofsLayout = new QHBoxLayout();
        dofsLayout->addWidget(dofsLabel);
        dofsLayout->addWidget(dofsLEdit);

        //DOFs name
        int nDOFs = dofsLEdit->text().toInt();
        nDOFs_old = nDOFs;
        dnamLEdits.resize(nDOFs);
        dnamLayouts.resize(1);
        dnamLayouts[0] = new QHBoxLayout();
        for (int i = 0; i < nDOFs; i++)
        {
            dnamLEdits[i] = new QLineEdit();
            dnamLEdits[i]->setAlignment(Qt::AlignRight);
            dnamLEdits[i]->setText("d"+QString::number(i));
            dnamLayouts[0]->addWidget(dnamLEdits[i]);
        }
        connect(dofsLEdit, SIGNAL(textChanged(QString)), SLOT(_disableDOFs()));
        connect(dofsLEdit, SIGNAL(editingFinished()), SLOT(_updateDOFs()));

        //Number of nAUX
        QLabel *nAuxLabel = new QLabel();
        nAuxLabel->setText("Node aux fields:");
        nAuxLEdit = new QLineEdit();
        nAuxLEdit->setText("0");
        nAuxLEdit->setMaximumWidth(40);
        nAuxLEdit->setAlignment(Qt::AlignRight);
        nAuxLEdit->setValidator(new QIntValidator(0, 100, this));
        QHBoxLayout *nAuxLayout = new QHBoxLayout();
        nAuxLayout->addWidget(nAuxLabel);
        nAuxLayout->addWidget(nAuxLEdit);

        //Number of eAUX
        QLabel *eAuxLabel = new QLabel();
        eAuxLabel->setText("Element aux fields:");
        eAuxLEdit = new QLineEdit();
        eAuxLEdit->setText("0");
        eAuxLEdit->setMaximumWidth(40);
        eAuxLEdit->setAlignment(Qt::AlignRight);
        eAuxLEdit->setValidator(new QIntValidator(0, 100, this));
        QHBoxLayout *eAuxLayout = new QHBoxLayout();
        eAuxLayout->addWidget(eAuxLabel);
        eAuxLayout->addWidget(eAuxLEdit);

        //Main layout
        mainLayout->addLayout(dofsLayout);
        for (auto l: dnamLayouts)
            mainLayout->addLayout(l);
        mainLayout->addLayout(nAuxLayout);
        mainLayout->addLayout(eAuxLayout);
    }
    else if (_nType == NodeType::BoundaryConditions)
    {
        //DOFs
        dbcBox = new QComboBox;
        dbcBox->addItem("-- dof --");
        QStandardItemModel* dbcModel = qobject_cast<QStandardItemModel*>(dbcBox->model());
        QModelIndex dbcFirstIndex = dbcModel->index(0, dbcBox->modelColumn(), dbcBox->rootModelIndex());
        QStandardItem* dbcFirstItem = dbcModel->itemFromIndex(dbcFirstIndex);
        dbcFirstItem->setSelectable(false);
        dbcBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");

        //Maxis
        maxisBox = new QComboBox;
        maxisBox->addItem("-- Maxis --");
        maxisBox->addItem("Xmin");
        maxisBox->addItem("Xmax");
        maxisBox->addItem("Ymin");
        maxisBox->addItem("Ymax");
        maxisBox->addItem("Zmin");
        maxisBox->addItem("Zmax");
        QStandardItemModel* maxisModel = qobject_cast<QStandardItemModel*>(maxisBox->model());
        QModelIndex maxisFirstIndex = maxisModel->index(0, maxisBox->modelColumn(), maxisBox->rootModelIndex());
        QStandardItem* maxisFirstItem = maxisModel->itemFromIndex(maxisFirstIndex);
        maxisFirstItem->setSelectable(false);
        maxisBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");

        //DOFs number
        bcLEdit = new QLineEdit();
        bcLEdit->setPlaceholderText("#");
        bcLEdit->setMaximumWidth(40);
        bcLEdit->setAlignment(Qt::AlignRight);
        bcLEdit->setValidator(new QDoubleValidator(0.0, 100.0, 2, this));

        QHBoxLayout *bcLayout = new QHBoxLayout();
        bcLayout->addWidget(dbcBox);
        bcLayout->addWidget(maxisBox);
        bcLayout->addWidget(bcLEdit);

        //Main layout
        mainLayout->addLayout(bcLayout);
    }
    else if (_nType == NodeType::Integration)
    {

    }
    else if (_nType == NodeType::GaussCubature)
    {
        //Number of integration points
        QLabel *iLabel = new QLabel();
        iLabel->setText("Gauss points:");
        iLEdit = new QLineEdit();
        iLEdit->setPlaceholderText(QString("#"));
        iLEdit->setMaximumWidth(30);
        iLEdit->setValidator(new QIntValidator(1, 100, this));
        iLEdit->setAlignment(Qt::AlignRight);

        QHBoxLayout *iLayout = new QHBoxLayout();
        iLayout->addWidget(iLabel);
        iLayout->addWidget(iLEdit);

        //Main layout
        mainLayout->addLayout(iLayout);
    }
    else if (_nType == NodeType::BorderGaussCubature)
    {
        //Number of integration points
        QLabel *iLabel = new QLabel();
        iLabel->setText("Gauss points:");
        iLEdit = new QLineEdit();
        iLEdit->setPlaceholderText(QString("#"));
        iLEdit->setMaximumWidth(30);
        iLEdit->setValidator(new QIntValidator(1, 100, this));
        iLEdit->setAlignment(Qt::AlignRight);
        QHBoxLayout *iLayout = new QHBoxLayout();
        iLayout->addWidget(iLabel);
        iLayout->addWidget(iLEdit);

        //Main layout
        mainLayout->addLayout(iLayout);
    }
    else if (_nType == NodeType::SubdivCubature)
    {
        //Number of integration points
        QLabel *iLabel = new QLabel();
        iLabel->setText("Gauss points:");
        iLEdit = new QLineEdit();
        iLEdit->setPlaceholderText(QString("#"));
        iLEdit->setMaximumWidth(30);
        iLEdit->setValidator(new QIntValidator(1, 100, this));
        iLEdit->setAlignment(Qt::AlignRight);

        QHBoxLayout *iLayout = new QHBoxLayout();
        iLayout->addWidget(iLabel);
        iLayout->addWidget(iLEdit);

        //Number of subdivision levels
        QLabel *sLabel = new QLabel();
        sLabel->setText("Subdivision levels:");
        sLEdit = new QLineEdit();
        sLEdit->setPlaceholderText(QString("#"));
        sLEdit->setMaximumWidth(30);
        sLEdit->setValidator(new QIntValidator(1, 100, this));
        sLEdit->setAlignment(Qt::AlignRight);

        QHBoxLayout *sLayout = new QHBoxLayout();
        sLayout->addWidget(sLabel);
        sLayout->addWidget(sLEdit);

        //Main layout
        mainLayout->addLayout(iLayout);
        mainLayout->addLayout(sLayout);
    }
    else if (_nType == NodeType::HiPerProblem)
    {

    }
    else if (_nType == NodeType::AZSolver)
    {
        //Solver
        solBox = new QComboBox;
        solBox->addItem("-- Solver type --");
        solBox->addItem("ConjGrad");
        solBox->addItem("Gmres");
        solBox->addItem("ConjGradS");
        QStandardItemModel* solModel = qobject_cast<QStandardItemModel*>(solBox->model());
        QModelIndex solFirstIndex = solModel->index(0, solBox->modelColumn(), solBox->rootModelIndex());
        QStandardItem* solFirstItem = solModel->itemFromIndex(solFirstIndex);
        solFirstItem->setSelectable(false);
        solBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");
        QHBoxLayout *solLayout = new QHBoxLayout();
        solLayout->addWidget(solBox);

        //Precondition
        precBox = new QComboBox;
        precBox->addItem("-- Preconditioner --");
        precBox->addItem("Undefined");
        precBox->addItem("Jacobi");
        precBox->addItem("SymGaussSeidel");
        precBox->addItem("Neumann");
        precBox->addItem("LeastSquares");
        precBox->addItem("DomainDecomp");
        QStandardItemModel* precModel = qobject_cast<QStandardItemModel*>(precBox->model());
        QModelIndex precFirstIndex = precModel->index(0, precBox->modelColumn(), precBox->rootModelIndex());
        QStandardItem* precFirstItem = precModel->itemFromIndex(precFirstIndex);
        precFirstItem->setSelectable(false);
        precBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");
        QHBoxLayout *precLayout = new QHBoxLayout();
        precLayout->addWidget(precBox);

        //SubdomainSolve
        subBox = new QComboBox;
        subBox->addItem("-- SubdomainSolve --");
        subBox->addItem("Undefined");
        subBox->addItem("ilu");
        subBox->addItem("ilut");
        QStandardItemModel* subModel = qobject_cast<QStandardItemModel*>(subBox->model());
        QModelIndex subFirstIndex = subModel->index(0, subBox->modelColumn(), subBox->rootModelIndex());
        QStandardItem* subFirstItem = subModel->itemFromIndex(subFirstIndex);
        subFirstItem->setSelectable(false);
        subBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");
        QHBoxLayout *subLayout = new QHBoxLayout();
        subLayout->addWidget(subBox);

        //Output
        outBox = new QComboBox;
        outBox->addItem("-- Output --");
        outBox->addItem("true");
        outBox->addItem("false");
        QStandardItemModel* outModel = qobject_cast<QStandardItemModel*>(outBox->model());
        QModelIndex outFirstIndex = outModel->index(0, outBox->modelColumn(), outBox->rootModelIndex());
        QStandardItem* outFirstItem = outModel->itemFromIndex(outFirstIndex);
        outFirstItem->setSelectable(false);
        outBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");
        QHBoxLayout *outLayout = new QHBoxLayout();
        outLayout->addWidget(outBox);

        //Tolerance
        QLabel *tolLabel = new QLabel();
        tolLabel->setText("Tolerance:");
        tolLEdit = new QLineEdit();
        tolLEdit->setPlaceholderText(QString("#"));
        tolLEdit->setMaximumWidth(80);
        tolLEdit->setAlignment(Qt::AlignRight);
        QHBoxLayout *tolLayout = new QHBoxLayout();
        tolLayout->addWidget(tolLabel);
        tolLayout->addWidget(tolLEdit);

        //Iterations
        QLabel *iterLabel = new QLabel();
        iterLabel->setText("Max. iterations:");
        iterLEdit = new QLineEdit();
        iterLEdit->setPlaceholderText(QString("#"));
        iterLEdit->setMaximumWidth(50);
        iterLEdit->setAlignment(Qt::AlignRight);
        QHBoxLayout *iterLayout = new QHBoxLayout();
        iterLayout->addWidget(iterLabel);
        iterLayout->addWidget(iterLEdit);

        //Main layout
        mainLayout->addLayout(solLayout);
        mainLayout->addLayout(precLayout);
        mainLayout->addLayout(subLayout);
        mainLayout->addLayout(outLayout);
        mainLayout->addLayout(tolLayout);
        mainLayout->addLayout(iterLayout);
    }
    else if (_nType == NodeType::preEFilling)
    {
        //Elements
        preBox = new QComboBox;
        preBox->addItem("-- Model --");
        preBox->addItem("Poisson");
        preBox->addItem("Cahn-Hilliard");
        QStandardItemModel* preModel = qobject_cast<QStandardItemModel*>(preBox->model());
        QModelIndex preFirstIndex = preModel->index(0, preBox->modelColumn(), preBox->rootModelIndex());
        QStandardItem* preFirstItem = preModel->itemFromIndex(preFirstIndex);
        preFirstItem->setSelectable(false);
        preBox->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");
        QHBoxLayout *preLayout = new QHBoxLayout();
        preLayout->addWidget(preBox);

        //Main layout
        mainLayout->addLayout(preLayout);
    }
    else if (_nType == NodeType::ralEFilling)
    {

    }
    else if (_nType == NodeType::weaEFilling)
    {
        //Weak form
        weakLEdit = new QLineEdit();
        weakLEdit->setStyleSheet("color:white;background-color:rgb(53,53,53,100);");
        QHBoxLayout *weakLayout = new QHBoxLayout();
        weakLayout->addWidget(weakLEdit);

        //Main layout
        mainLayout->addLayout(weakLayout);
    }
    else if (_nType == NodeType::onsEFilling)
    {

    }
    else if (_nType == NodeType::usrEFilling)
    {
        //File
        fileLEdit = new QLineEdit();
        fileLEdit->setPlaceholderText(QString("<path-to-file>"));
        // orderLEdit->setMaximumWidth(30);
        QPushButton *fileButton = new QPushButton("Browse");
        connect(fileButton, &QAbstractButton::clicked, this, [=](){this->_browseOpen(fileLEdit);});
        QHBoxLayout *fileLayout = new QHBoxLayout();
        fileLayout->addWidget(fileLEdit);
        fileLayout->addWidget(fileButton);

        //Open
        QPushButton *openButton = new QPushButton("Open externally");
        connect(openButton, SIGNAL(clicked()), this, SLOT(_updateAllInfo()));
        QHBoxLayout *openLayout = new QHBoxLayout();
        openLayout->addWidget(openButton);

        //Main layout
        mainLayout->addLayout(fileLayout);
        mainLayout->addLayout(openLayout);
    }
    else if (_nType == NodeType::RightHandSide)
    {
        //RHS
        rhsLEdit = new QLineEdit();
        rhsLEdit->setStyleSheet("color:white;background-color:rgb(53,53,53,100);");
        QHBoxLayout *rhsLayout = new QHBoxLayout();
        rhsLayout->addWidget(rhsLEdit);

        //Main layout
        mainLayout->addLayout(rhsLayout);
    }
    else if (_nType == NodeType::LeftHandSide)
    {
        //LHS
        lhsLEdit = new QLineEdit();
        lhsLEdit->setStyleSheet("color:white;background-color:rgb(53,53,53,100);");
        QHBoxLayout *lhsLayout = new QHBoxLayout();
        lhsLayout->addWidget(lhsLEdit);

        //Main layout
        mainLayout->addLayout(lhsLayout);

    }
    else if (_nType == NodeType::FreeEnergy)
    {

    }
    else if (_nType == NodeType::Dissipation)
    {

    }
    else if (_nType == NodeType::PowerInput)
    {

    }
    else if (_nType == NodeType::ProcessOperator)
    {

    }
    else if (_nType == NodeType::LangrageMultiplier)
    {

    }
    else if (_nType == NodeType::Solve)
    {
        //Solve
        QPushButton *solButton = new QPushButton("Solve");
        solButton->setFixedWidth(140);
        QHBoxLayout *solLayout = new QHBoxLayout();
        solLayout->setAlignment(Qt::AlignCenter);
        solLayout->addWidget(solButton);

        //Main layout
        mainLayout->addLayout(solLayout);
    }
    else if (_nType == NodeType::OutputH)
    {
        //File
        fileLEdit = new QLineEdit();
        fileLEdit->setPlaceholderText(QString("<path-to-file>"));
        // orderLEdit->setMaximumWidth(30);
        QPushButton *fileButton = new QPushButton("Browse");
        connect(fileButton, &QAbstractButton::clicked, this, [=](){this->_browseSave(fileLEdit);});
        QHBoxLayout *fileLayout = new QHBoxLayout();
        fileLayout->addWidget(fileLEdit);
        fileLayout->addWidget(fileButton);

        //Postprocess
        QPushButton *pButton = new QPushButton("Post-process");
        // connect(pButton, &QAbstractButton::clicked, this, [=](){this->_paraview(fileLEdit->text());});
        QHBoxLayout *pLayout = new QHBoxLayout();
        pLayout->addWidget(pButton);

        //Visualize
        QLabel *vLabel = new QLabel();
        vLabel->setText("Visualize:");
        QPushButton *hButton = new QPushButton("Here");
        connect(hButton, &QAbstractButton::clicked, this, [=](){emit(viewSolution(fileLEdit->text()));});
        QPushButton *parButton = new QPushButton("Paraview");
        // connect(parButton, &QAbstractButton::clicked, this, [=](){this->_paraview(fileLEdit->text());});
        QHBoxLayout *outLayout = new QHBoxLayout();
        outLayout->addWidget(hButton);
        outLayout->addWidget(parButton);
        QVBoxLayout *vLayout = new QVBoxLayout();
        vLayout->addWidget(vLabel);
        vLayout->addLayout(outLayout);

        //Main layout
        mainLayout->addLayout(fileLayout);
        mainLayout->addLayout(pLayout);
        mainLayout->addLayout(vLayout);
    }
    else if (_nType == NodeType::OutputVtk)
    {
        //File
        fileLEdit = new QLineEdit();
        fileLEdit->setPlaceholderText(QString("<path-to-file>"));
        // orderLEdit->setMaximumWidth(30);
        QPushButton *fileButton = new QPushButton("Browse");
        connect(fileButton, &QAbstractButton::clicked, this, [=](){this->_browseSave(fileLEdit);});
        QHBoxLayout *fileLayout = new QHBoxLayout();
        fileLayout->addWidget(fileLEdit);
        fileLayout->addWidget(fileButton);

        //Visualize
        QPushButton *outButton = new QPushButton("Plot");
        connect(outButton, &QAbstractButton::clicked, this, [=](){this->_paraview(fileLEdit->text());});

        QHBoxLayout *outLayout = new QHBoxLayout();
        outLayout->addWidget(outButton);

        //Main layout
        mainLayout->addLayout(fileLayout);
        mainLayout->addLayout(outLayout);
    }
    else
    {
        throw std::runtime_error("Node::mWidget: NodeType undefined.");
    }

    //Create main widget
    mainLayout->setAlignment(Qt::AlignCenter);
    _mainWidget = new QWidget();
    _mainWidget->setLayout(mainLayout);
    _mainWidget->setFixedWidth(200);

    //Connect changes in widgets with update data
    foreach(QLineEdit* w, _mainWidget->findChildren<QLineEdit*>())
        if (w != dofsLEdit)
            connect(w, SIGNAL(textChanged(QString)), SLOT(_updateAllInfo()));
    foreach(QPushButton* w, _mainWidget->findChildren<QPushButton*>())
        connect(w, SIGNAL(clicked()), SLOT(_updateAllInfo()));
    foreach(QComboBox* w, _mainWidget->findChildren<QComboBox*>())
        connect(w, SIGNAL(currentIndexChanged(int)), SLOT(_updateAllInfo()));
    foreach(QCheckBox* w, _mainWidget->findChildren<QCheckBox*>())
        connect(w, SIGNAL(stateChanged(int)), SLOT(_updateAllInfo()));

    //Set the widget
    QGraphicsProxyWidget* pMyProxy = new QGraphicsProxyWidget(this);
    pMyProxy->setWidget(_mainWidget);
    pMyProxy->setPos(20, 40);
}

void Node::_createPorts()
{
    //Get inPorts //FIXME:Change for MetaNodeTypes
    QVector<NodeType> nIn{};
    if (_nType == NodeType::DistributedMesh)
    {
        nIn.push_back(NodeType::MeshLoader);
    }
    else if (_nType == NodeType::pDistributedMesh)
    {
        nIn.push_back(NodeType::DistributedMesh);
    }
    else if (_nType == NodeType::hDistributedMesh)
    {
        nIn.push_back(NodeType::DistributedMesh);
    }
    else if (_nType == NodeType::DOFsHandler)
    {
        nIn.push_back(NodeType::DistributedMesh);
        nIn.push_back(NodeType::BoundaryConditions);
        nIn.push_back(NodeType::InitialConditions);
    }
    else if (_nType == NodeType::Integration)
    {
        nIn.push_back(NodeType::DOFsHandler);
        nIn.push_back(NodeType::GaussCubature);
        nIn.push_back(NodeType::preEFilling);
    }
    else if (_nType == NodeType::ralEFilling)
    {
        nIn.push_back(NodeType::LeftHandSide);
        nIn.push_back(NodeType::RightHandSide);
    }
    else if (_nType == NodeType::onsEFilling)
    {
        nIn.push_back(NodeType::FreeEnergy);
        nIn.push_back(NodeType::Dissipation);
        nIn.push_back(NodeType::PowerInput);
        nIn.push_back(NodeType::ProcessOperator);
        nIn.push_back(NodeType::LangrageMultiplier);
    }
    else if (_nType == NodeType::HiPerProblem)
    {
        nIn.push_back(NodeType::Integration);
    }
    else if (_nType == NodeType::AZSolver)
    {
        nIn.push_back(NodeType::HiPerProblem);
    }
    else if (_nType == NodeType::Solve)
    {
        nIn.push_back(NodeType::AZSolver);
    }
    else if (_nType == NodeType::OutputH)
    {
        nIn.push_back(NodeType::Solve);
    }
    else if (_nType == NodeType::OutputVtk)
    {
        nIn.push_back(NodeType::Solve);
    }

    //Modify height
    if (nIn.size() > 0)
        _height += 25;

    //Add inPorts
    for (int i = 0; i < nIn.size(); i++)
        inPorts.push_back(_createPort(PortType::InPort, nIn[i], i));

    _height += (nIn.size()+1)*20 + 10;

    //Out ports
    outPort = (_createPort(PortType::OutPort, _nType, 0));
}

Port* Node::_createPort(PortType pType, NodeType nType, int n)
{
    Port *port = new Port(pType, nType, this, this);

    if (pType == PortType::InPort)
        port->setPos(0, _height + (n)*25 + 20);
    else
        port->setPos(_width, 18);

    return port;
}

void Node::_updateInPortPosition()
{
    for (int i = inPorts.size()-1; i >= 0; i--)
        inPorts[inPorts.size()-1-i]->setPos(0, _height - i*25 - 20);
}

//Others
void Node::_updateAllInfo()
{
    _updateData();

    if (_nType == NodeType::StructMeshGenerator or
        _nType == NodeType::MeshLoader)
        emit(updateVtk());
}

void Node::_updateConnected()
{
    //Update from inports
    for (int i = 0; i < inPorts.size(); i++)
    {
        foreach (Node *n, inPorts[i]->connectedNodes)
            n->_updateAllInfo();
    }

    //Update from outport
    foreach (Node *n, outPort->connectedNodes)
        n->_updateAllInfo();
}

void Node::_updateData()
{
    QString myName = _name->text();
    if (_nType == NodeType::StructMeshGenerator)
    {
        //Create data
        _data.resize(3);
        _data[0] = "RCP<StructMeshGenerator> " + myName
            + " = rcp(new StructMeshGenerator);";
        _data[1] = myName
            + "->setMesh(ElemType::" + elemBox->itemData(elemBox->currentIndex()).toString()
            + ", BasisFuncType::" + bfBox->itemData(bfBox->currentIndex()).toString()
            + ", " + orderLEdit->text()
            + ");";
        QString gen = genBox->itemData(genBox->currentIndex()).toString();
        if (gen == "genStructMesh")
            _data[2] = myName + "->genStructMesh("
                + nExLEdit->text() + ");";// + ", " +
                // nExLEdit->text() + ", " +
                // nExLEdit->text() + ");";
        else if (gen == "genTorusSolidSector")
            _data[2] = myName + "->genTorusSolidSector("
                + nExLEdit->text() + ", "
                + nExLEdit->text() + ", "
                + nExLEdit->text() + ", "
                + gOptLEdit[0]->text() + ", "
                + gOptLEdit[1]->text() + ", "
                + gOptLEdit[2]->text() + ", "
                + gOptLEdit[3]->text() + ");";

        // _data[2] = myName + ".genStructMesh(" + nExLEdit->text() + ");";

        //Header
        _headers.resize(1);
        _headers[0] = "#include \"hl_StructMeshGenerator.h\"";

    }
    else if (_nType == NodeType::MeshLoader)
    {
        //Create data
        _data.resize(3);
        _data[0] = "RCP<MeshLoader> " + myName
            + " = rcp(new MeshLoader);";
        _data[1] = myName
            + "->setMesh(ElemType::" + elemBox->itemData(elemBox->currentIndex()).toString()
            + ", BasisFuncType::" + bfBox->itemData(bfBox->currentIndex()).toString()
            + ", " + orderLEdit->text()
            + ");";
        _data[2] = myName + "->loadMesh(\"" + fileLEdit->text() + "\");";

        //Header
        _headers.resize(1);
        _headers[0] = "#include \"hl_MeshLoader.h\"";
    }
    else if (_nType == NodeType::DistributedMesh)
    {
        //Get info
        QString meshCreator;
        for (int i = 0; i < inPorts[0]->connectedNodes.size(); i++)
        {
            if (inPorts[0]->connectedNodes[i]->blocked == false)
                meshCreator = inPorts[0]->connectedNodes[i]->_name->text();
        }

        QString checked = "false";
        if (balCheckBox->isChecked())
            checked = "true";

        //Create data
        _data.resize(4);
        _data[0] = "RCP<DistributedMesh> " + myName
            + " = rcp(new DistributedMesh);";
        _data[1] = myName + "->setMesh(" + meshCreator + ");";
        _data[2] = myName + "->setBalanceMesh(" + checked + ");";
        _data[3] = myName + "->Update();";

        //Header
        _headers.resize(1);
        _headers[0] = "#include \"hl_DistributedMesh.h\"";

        //Update data of connected nodes
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
            outPort->connectedNodes[i]->_updateAllInfo();
    }
    else if (_nType == NodeType::hDistributedMesh)
    {
        //Get info
        QString disMeshName;
        QString checked = "false";
        for (int i = 0; i < inPorts[0]->connectedNodes.size(); i++)
        {
            if (inPorts[0]->connectedNodes[i]->blocked == false)
            {
                Node *n = inPorts[0]->connectedNodes[i];
                if (n->_nType == NodeType::DistributedMesh)
                {
                    disMeshName = n->_name->text();
                    if (n->balCheckBox->isChecked())
                        checked = "true";
                }
            }
        }

        //Create data
        _data.resize(5);
        _data[0] = "RCP<DistributedMesh> " + myName
            + " = rcp(new DistributedMesh);";
        _data[1] = myName + "->setMeshRelation(MeshRelation::hRefin, " + disMeshName + ");";
        _data[2] = myName + "->setHRefinement(" + hLEdit->text() + ");";
        _data[3] = myName + "->setBalanceMesh(" + checked + ");";
        _data[4] = myName + "->Update();";

        //Header
        _headers.resize(1);
        _headers[0] = "#include \"hl_DistributedMesh.h\"";
    }
    else if (_nType == NodeType::pDistributedMesh)
    {
        //Get info
        QString disMeshName;
        QString checked = "false";
        for (int i = 0; i < inPorts[0]->connectedNodes.size(); i++)
        {
            Node *n = inPorts[0]->connectedNodes[i];
            if (n->_nType == NodeType::DistributedMesh and n->blocked == false)
            {
                disMeshName = n->_name->text();
                if (n->balCheckBox->isChecked())
                    checked = "true";
            }
        }

        //Create data
        _data.resize(5);
        _data[0] = "RCP<DistributedMesh> " + myName
            + " = rcp(new DistributedMesh);";
        _data[1] = myName + "->setMeshRelation(MeshRelation::pRefin, " + disMeshName + ");";
        _data[2] = myName + "->setPRefinement(" + pLEdit->text() + ");";
        _data[3] = myName + "->setBalanceMesh(" + checked + ");";
        _data[4] = myName + "->Update();";

        //Header
        _headers.resize(1);
        _headers[0] = "#include \"hl_DistributedMesh.h\"";
    }
    else if (_nType == NodeType::DOFsHandler)
    {
        //Get info
        QString disMesh;
        QVector<Node*> bc;
        for (int d = 0; d < inPorts.size(); d++)
        {
            for (int i = 0; i < inPorts[d]->connectedNodes.size(); i++)
            {
                Node *n = inPorts[d]->connectedNodes[i];
                if (n->blocked == true)
                    continue;
                if (n->_mnType == MetaNodeType::DistributedMesh)
                    disMesh = n->_name->text();
                if (n->_nType == NodeType::BoundaryConditions)
                {
                    n->_updateBC();
                    bc.push_back(n);
                }
            }
        }
        int DOFs = dofsLEdit->text().toInt();
        QVector<QString> dofNames;
        for (int i = 0; i < DOFs; i++)
            dofNames.push_back(dnamLEdits[i]->text());
        QString nAUX = nAuxLEdit->text();
        QString eAUX = eAuxLEdit->text();

        //Create data
        _data.resize(7 + bc.size());
        _data[0] = "RCP<DOFsHandler> " + myName
            + " = rcp(new DOFsHandler(" + disMesh + "));";
        _data[1] = myName + "->setNameTag(\"" + myName + "\");";
        _data[2] = myName + "->setDOFs({";
        if (DOFs > 0)
        {
            _data[2].append("\"" + dofNames[0] + "\"");
            for (int i = 1; i < DOFs; i++)
                _data[2].append(", \"" + dofNames[i] + "\"");
        }
        _data[2].append("});");
        _data[3] = myName + "->setNumNodeAuxF(" + nAUX + ");";
        _data[4] = myName + "->setNumElemAuxF(" + eAUX + ");";
        _data[5] = myName + "->Update();";
        _data[6] = "";
        for (int i = 0; i < bc.size(); i++)
        {
            _data[7+i] = myName + "->setBoundaryCondition("
                + QString::number(bc[i]->dbcBox->currentIndex()-1)
                + ", MAxis::" + bc[i]->maxisBox->currentText()
                + ", " + bc[i]->bcLEdit->text() + ");";
        }
        _data.push_back(myName + "->UpdateGhosts();");

        //Header
        _headers.resize(1);
        _headers[0] = "#include \"hl_DOFsHandler.h\"";

        //Update element fillings
        if (outPort->connectedNodes.size() > 0)
        {
            Node* in = outPort->connectedNodes[0];

            for (int d = 0; d < in->inPorts.size(); d++)
            {
                for (int c = 0; c < in->inPorts[d]->connectedNodes.size(); c++)
                {
                    Node *n = in->inPorts[d]->connectedNodes[c];
                    if (n->_mnType == MetaNodeType::ElemFilling)
                        n->_updateAllInfo();
                }
            }
        }

        //Update integration
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
        {
            Node *n = outPort->connectedNodes[i];
            if (n->_nType == NodeType::Integration)
                n->_updateData();
        }
    }
    else if (_nType == NodeType::Integration)
    {
        //Get dHands
        QVector<Node *> dhands;
        for (int i = 0; i < inPorts[0]->connectedNodes.size(); i++)
            if (inPorts[0]->connectedNodes[i]->blocked == false)
                dhands.push_back(inPorts[0]->connectedNodes[i]);

        // //Add or remove integration types
        // if (dhands.size() > iTypeLayouts.size())
        // {
        //     for (int i = iTypeLayouts.size(); i < dhands.size(); i++)
        //     {
        //         Node * d = dhands[i];
        //         QString dName = d->_name->text();
        //         //dhands
        //         dLabels.push_back(new QLabel());
        //         dLabels[i]->setText(dName);

        //         //Maxis
        //         iTypeBox.push_back(new QComboBox);
        //         iTypeBox[i]->addItem("-- IntegType --");
        //         iTypeBox[i]->addItem("Master");
        //         iTypeBox[i]->addItem("LagrMultip");
        //         iTypeBox[i]->addItem("GlobConstr");
        //         iTypeBox[i]->addItem("NeumannBC");
        //         QStandardItemModel* iTypeModel = qobject_cast<QStandardItemModel*>(iTypeBox[i]->model());
        //         QModelIndex iTypeFirstIndex = iTypeModel->index(0, iTypeBox[i]->modelColumn(), iTypeBox[i]->rootModelIndex());
        //         QStandardItem* iTypeFirstItem = iTypeModel->itemFromIndex(iTypeFirstIndex);
        //         iTypeFirstItem->setSelectable(false);
        //         iTypeBox[i]->setStyleSheet("QComboBox QAbstractItemView {background-color:rgb(53,53,53);}");
        //         connect(iTypeBox[i], SIGNAL(currentIndexChanged(int)), SLOT(_updateAllInfo()));


        //         iTypeLayouts.push_back(new QHBoxLayout());
        //         iTypeLayouts[i]->addWidget(dLabels[i]);
        //         iTypeLayouts[i]->addWidget(iTypeBox[i]);
        //         iTypeLayouts[i]->setSizeConstraint(QLayout::SetFixedSize);

        //         //Main layout
        //         mainLayout->addLayout(iTypeLayouts[i]);
        //     }

        //     // _height += _mainWidget->height() - 12*dhands.size();

        //     //Move ports
        //     _updateInPortPosition();
        // }
        // else if (dhands.size() < iTypeLayouts.size())
        // {
        //     for (int i = iTypeLayouts.size()-1; i >= dhands.size(); i--)
        //     {
        //         _height -= dLabels[i]->height();
        //         // qInfo() << i;
        //         //Remove
        //         iTypeLayouts[i]->removeWidget(dLabels[i]);
        //         iTypeLayouts[i]->removeWidget(iTypeBox[i]);
        //         dLabels[i]->hide();
        //         delete dLabels[i];
        //         dLabels.pop_back();
        //         iTypeBox[i]->hide();
        //         delete iTypeBox[i];
        //         iTypeBox.pop_back();
        //         delete iTypeLayouts[i];
        //         iTypeLayouts.pop_back();
        //     }
        //     mainLayout->setSizeConstraint(QLayout::SetFixedSize);

        //     //Move ports
        //     _updateInPortPosition();
        // }

        // //Update existing dhand names
        // for (int i = 0; i < dhands.size(); i++)
        // {
        //     //Get info
        //     Node * d = dhands[i];
        //     QString dName = d->_name->text();
        //     dLabels[i]->setText(dName+" :");
        // }

        //Update scene
        emit(visibilityChanged());

        //Update linear problem
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
        {
            Node *n = outPort->connectedNodes[i];
            if (n->_nType == NodeType::HiPerProblem)
                n->_updateData();
        }
    }
    else if (_nType == NodeType::HiPerProblem)
    {
        //Get integration nodes
        QVector<Node*> iNodes;
        for (int d = 0; d < inPorts.size(); d++)
        {
            for (int i = 0; i < inPorts[d]->connectedNodes.size(); i++)
            {
                Node *n = inPorts[d]->connectedNodes[i];
                if (n->_nType == NodeType::Integration and n->blocked == false)
                    iNodes.push_back(n);
            }
        }

        //Loop over integrations
        int n_iNodes = iNodes.size();
        QVector<QString> iNames(n_iNodes);
        QVector<QVector<QString>> idHands(n_iNodes, QVector<QString>());
        QVector<Node*> cNodes(n_iNodes);
        QVector<QString> fillNames(n_iNodes);
        for (int i = 0; i < n_iNodes; i++)
        {
            Node* in = iNodes[i];
            iNames[i] = in->_name->text();
            for (int d = 0; d < in->inPorts.size(); d++)
            {
                for (int c = 0; c < in->inPorts[d]->connectedNodes.size(); c++)
                {
                    Node *n = in->inPorts[d]->connectedNodes[c];
                    if (n->blocked == true)
                        continue;
                    if (n->_nType == NodeType::DOFsHandler)
                    {
                        idHands[i].push_back(n->_name->text());
                    }
                    else if (n->_mnType == MetaNodeType::Cubature)
                    {
                        cNodes[i] = n;
                    }
                    else if (n->_mnType == MetaNodeType::ElemFilling)
                    {
                        fillNames[i] = n->_name->text();
                    }
                }
            }
        }

        //Get vector of dHands and remove duplicates
        vector<QString> dHands;
        for (auto && v : idHands)
            dHands.insert(dHands.end(), v.begin(), v.end());
        sort(dHands.begin(), dHands.end());
        dHands.erase(unique(dHands.begin(), dHands.end()), dHands.end());

        //Create HiPerProblem data
        _data.resize(4+iNodes.size()*3+1);
        _data[0] = "RCP<HiPerProblem> " + myName
            + " = rcp(new HiPerProblem);";
        QString userStr = "userStr";
        _data[1] = "//" + myName + "->setUserStruct(" + userStr + ");";
        _data[2] = myName + "->setDOFsHandlers({";
        if (dHands.size() > 0)
        {
            _data[2] += dHands[0];
            for (size_t d = 1; d < dHands.size(); d++)
                _data[2] += ", " + dHands[d];
            _data[2] += "});";
        }

        //Create integration data
        for (int i = 0; i < n_iNodes; i++)
        {
            //Set integration
            _data[3+i*3] = myName + "->setIntegration(\"" + iNames[i] + "\", ";
            if (idHands[i].size() > 0)
            {
                //dhands
                _data[3+i*3] += "{\"" + idHands[i][0];
                for (int d = 1; d < idHands[i].size(); d++)
                    _data[3+i*3] += "\", \"" + idHands[i][d];
                _data[3+i*3] += "\"});";
            }

            //Set cubature
            if (cNodes[i])
            {
                if (cNodes[i]->_nType == NodeType::GaussCubature)
                    _data[3+i*3+1] = myName
                        + "->setCubatureGauss(\"" + iNames[i]
                        + "\", " + cNodes[i]->iLEdit->text() + ");";
                else if (cNodes[i]->_nType == NodeType::BorderGaussCubature)
                    _data[3+i*3+1] = myName
                        + "->setCubatureBorderGauss(\"" + iNames[i]
                        + "\", " + cNodes[i]->iLEdit->text() + ");";
                else if (cNodes[i]->_nType == NodeType::SubdivCubature)
                    _data[3+i*3+1] = myName
                        + "->setCubatureIrregSubdivSurf(\"" + iNames[i]
                        + "\", " + cNodes[i]->iLEdit->text()
                        + ", " + cNodes[i]->sLEdit->text() + ");";
            }
            //Set fillings
            _data[3+i*3+2] = myName
                + "->setElemFillings(\"" + iNames[i] + "\", "
                + fillNames[i] + ");";
        }

        //Update
        _data[3+n_iNodes*3+1] = myName+"->Update();";

        //Header
        _headers.resize(2);
        _headers[0] = "#include \"hl_FillStructure.h\"";
        _headers[1] = "#include \"hl_HiPerProblem.h\"";

        //Header2
        _headers2.resize(n_iNodes);
        for (int i = 0; i < n_iNodes; i++)
            _headers2[i] = "void " + fillNames[i]
                + "(RCP<FillStructure> fillStr);";
    }
    else if (_nType == NodeType::AZSolver)
    {
        //Get info
        QString hiperProblem;
        for (int i = 0; i < inPorts.size(); i++)
        {
            foreach (Node *n, inPorts[i]->connectedNodes)
                if (n->blocked == false)
                    hiperProblem = n->_name->text();
        }

        //Update
        _data.resize(9);
        _data[0] = "RCP<AztecOOIterativeLinearSolver> " + myName
            + " = rcp(new AztecOOIterativeLinearSolver());";
        _data[1] = myName + "->setHiPerProblem(" + hiperProblem + ");";
        _data[2] = myName + "->setSolver(AztecOOIterativeLinearSolver::Solver::" + solBox->currentText() + ");";
        _data[3] = myName + "->setPrecond(AztecOOIterativeLinearSolver::Precond::" + precBox->currentText() + ");";
        _data[4] = myName + "->setSubdomainSolve(AztecOOIterativeLinearSolver::SubdomainSolve::" + subBox->currentText() + ");";
        _data[5] = myName + "->setTolerance(" + tolLEdit->text() + ");";
        _data[6] = myName + "->setMaxNumIterations(" + iterLEdit->text() + ");";
        _data[7] = myName + "->setVerbose(" + outBox->currentText() + ");";
        _data[8] = myName + "->Update();";

        //Header
        _headers.resize(1);
        _headers[0] = "#include \"hl_LinearSolver_Iterative_AztecOO.h\"";
    }
    else if (_nType == NodeType::preEFilling)
    {
        //Get dofHandlers name
        QVector<QString> dHands;
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
        {
            Node* in = outPort->connectedNodes[i];
            if (in->blocked == true)
                continue;
            for (int d = 0; d < in->inPorts.size(); d++)
            {
                for (int c = 0; c < in->inPorts[d]->connectedNodes.size(); c++)
                {
                    Node *n = in->inPorts[d]->connectedNodes[c];
                    if (n->_nType == NodeType::DOFsHandler and n->blocked == false)
                    {
                        dHands.push_back(n->_name->text());
                    }
                }
            }
        }

        if (preBox->currentText() == "Poisson")
        {
            //Check
            if (dHands.size() > 1)
            {
                QMessageBox msgBox;
                msgBox.setText("preEFilling: Several DOFsHandlers not implemented.");
                msgBox.exec();
            }

            //Data
            _data.clear();
            _data.push_back("void " + myName + "(RCP<FillStructure> fillStr)");
            _data.push_back("{");
            _data.push_back("//double force = fillStr->userStr->dparam[0];");
            _data.push_back("double force = 10;");
            if (dHands.size() > 0)
                _data.push_back("SubFillStructure& subFill = (*fillStr)[\""
                                + dHands[0] + "\"];");
            _data.push_back("int DOF  = subFill.numDOFs;");
            _data.push_back("int eNN  = subFill.eNN;");
            _data.push_back("int nDim = subFill.nDim;");
            _data.push_back("int pDim = subFill.pDim;");
            _data.push_back("vector<double>& xe_nodes  = subFill.nborCoords;");
            _data.push_back("double* Na  = subFill.getDer(0);");
            _data.push_back("double* glNa = subFill.getDer(1);");
            _data.push_back("double gNa[eNN*pDim], jac;");
            _data.push_back("GlobalBasisFunctions::gradients(gNa, jac, subFill);");

            _data.push_back("vector<double> x(pDim);");
            _data.push_back("Array::Fill(x.data(), pDim, 0.0);");
            _data.push_back("for (int i = 0; i < eNN; i++)");
            _data.push_back("{");
            _data.push_back("    for (int d = 0; d < pDim; d++)");
            _data.push_back("        x[d] += xe_nodes[nDim*i+d]  * Na[i];");
            _data.push_back("}");
            _data.push_back("");
            _data.push_back("for (int i = 0; i < eNN; i++)");
            _data.push_back("{");
            _data.push_back("    for (int j = 0; j < eNN; j++)");
            _data.push_back("    {");
            _data.push_back("        double gNagNb{};");
            _data.push_back("        for (int d = 0; d < pDim; d++)");
            _data.push_back("            gNagNb += gNa[pDim*i+d]*gNa[pDim*j+d];");
            _data.push_back("");
            _data.push_back("        fillStr->Ak(0, 0)[i*DOF*eNN+j*DOF] += jac * gNagNb;");
            _data.push_back("    }");
            _data.push_back("");
            _data.push_back("    fillStr->Bk(0)[i*DOF] += jac * Na[i] * force;");
            _data.push_back("}");
            _data.push_back("");
            _data.push_back("return;");
            _data.push_back("}");

            //Header
            _headers.resize(1);
            _headers[0] = "#include \"hl_GlobalBasisFunctions.h\"";
        }
        else if (preBox->currentText() == "Cahn-Hilliard")
        {
            QMessageBox msgBox;
            msgBox.setText("Predefined element filling not implemented.");
            msgBox.exec();
        }

        //Update data of connected nodes
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
            outPort->connectedNodes[i]->_updateAllInfo();
    }
    else if (_nType == NodeType::ralEFilling)
    {
        //Get dofHandlers names
        QVector<QString> dHands;
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
        {
            Node* in = outPort->connectedNodes[i];
            if (in->blocked == true)
                continue;

            for (int d = 0; d < in->inPorts.size(); d++)
            {
                for (int c = 0; c < in->inPorts[d]->connectedNodes.size(); c++)
                {
                    Node *n = in->inPorts[d]->connectedNodes[c];
                    if (n->_nType == NodeType::DOFsHandler)
                    {
                        dHands.push_back(n->_name->text());
                    }
                }
            }
        }

        //Get lhs and rhs
        QString rhs, lhs;
        for (int d = 0; d < inPorts.size(); d++)
        {
            for (int i = 0; i < inPorts[d]->connectedNodes.size(); i++)
            {
                Node *n = inPorts[d]->connectedNodes[i];
                if (n->blocked == true)
                    continue;
                if (n->_nType == NodeType::LeftHandSide)
                    lhs = n->lhsLEdit->text();
                if (n->_nType == NodeType::RightHandSide)
                    rhs = n->rhsLEdit->text();
            }

        }

        //Check
        if (dHands.size() > 1)
        {
            QMessageBox msgBox;
            msgBox.setText("preEFilling: Several DOFsHandlers not implemented.");
            msgBox.exec();

        }

        //Data
        _data.clear();
        _data.push_back("void " + myName + "(RCP<FillStructure> fillStr)");
        _data.push_back("{");
        _data.push_back("using namespace Tensor;");
        _data.push_back("");
        _data.push_back("//double force = fillStr->userStr->dparam[0];");
        _data.push_back("double force = 10;");
        if (dHands.size() > 0)
            _data.push_back("SubFillStructure& subFill = (*fillStr)[\""
                            + dHands[0] + "\"];");
        _data.push_back("int DOF  = subFill.numDOFs;");
        _data.push_back("int eNN  = subFill.eNN;");
        _data.push_back("int nDim = subFill.nDim;");
        _data.push_back("int pDim = subFill.pDim;");
        _data.push_back("tensor<double,2> xe_nodes(subFill.nborCoords.data(), eNN, nDim);");
        _data.push_back("tensor<double,1>  bf(subFill.getDer(0), eNN);");
        _data.push_back("tensor<double,2> dbf_l(subFill.getDer(1), eNN, pDim);");
        _data.push_back("");
        _data.push_back("tensor<double,2> A_k(fillStr->Ak(0,0).data(), eNN, eNN);");
        _data.push_back("tensor<double,1> B_k(fillStr->Bk(0).data(), eNN);");
        _data.push_back("tensor<double,1>  x =  bf * xe_nodes;");
        _data.push_back("tensor<double,2> Dx = dbf_l.T() * xe_nodes;");
        _data.push_back("tensor<double,2>  g = Dx * Dx.T();");
        _data.push_back("");
        _data.push_back("double jac = sqrt(g.det());");
        _data.push_back("");
        if (lhs != 0)
            _data.push_back("A_k = " + lhs + ";");
        if (rhs != 0)
            _data.push_back("B_k = " + rhs + ";");
        _data.push_back("");
        _data.push_back("return;");
        _data.push_back("}");

        //Header
        _headers.resize(2);
        _headers[0] = "#include \"hl_Geometry.h\"";
        _headers[1] = "#include \"hl_Tensor.h\"";

        //Update data of connected nodes
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
            outPort->connectedNodes[i]->_updateAllInfo();
    }
    else if (_nType == NodeType::Solve)
    {
        //Get solver
        QString sName;
        for (int d = 0; d < inPorts.size(); d++)
        {
            for (int i = 0; i < inPorts[d]->connectedNodes.size(); i++)
            {
                Node *n = inPorts[d]->connectedNodes[i];
                if (n->_mnType == MetaNodeType::LinearSolver and n->blocked == false)
                    sName = n->_name->text();
            }
        }

        //Data
        _data.resize(2);
        _data[0] = sName + "->solve();";
        _data[1] = sName + "->UpdateSolution();";
    }
    else if (_nType == NodeType::OutputH)
    {
        //Get solve
        Node *s = nullptr;
        for (int d = 0; d < inPorts.size(); d++)
        {
            for (int i = 0; i < inPorts[d]->connectedNodes.size(); i++)
            {
                Node *n = inPorts[d]->connectedNodes[i];
                if (n->_nType == NodeType::Solve and n->blocked == false)
                    s = n;
            }
        }

        //Get linearSolver
        Node *l = nullptr;
        if (s != 0)
        {
            for (int d = 0; d < s->inPorts.size(); d++)
            {
                for (int i = 0; i < s->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = s->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::AZSolver and n->blocked == false)
                        l = n;
                }
            }
        }

        //Get HiPerProblem
        Node *h = nullptr;
        if (l != 0)
        {
            for (int d = 0; d < l->inPorts.size(); d++)
            {
                for (int i = 0; i < l->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = l->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::HiPerProblem and n->blocked == false)
                        h = n;
                }
            }
        }

        //Get integrations
        QVector<Node*> in;
        if (h != 0)
        {
            for (int d = 0; d < h->inPorts.size(); d++)
            {
                for (int i = 0; i < h->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = h->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::Integration and n->blocked == false)
                        in.push_back(n);
                }
            }
        }

        //Get DOFsHandler names
        QVector<QString> dname;
        for (int k = 0; k < in.size(); k++)
        {
            for (int d = 0; d < in[k]->inPorts.size(); d++)
            {
                for (int i = 0; i < in[k]->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = in[k]->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::DOFsHandler and n->blocked == false)
                        dname.push_back(n->_name->text());
                }
            }
        }

        //Data
        _data.resize(dname.size());
        for (int d = 0; d < dname.size(); d++)
            _data[d] = dname[d] + "->printFile(\"" + fileLEdit->text() + "\");"; //FIXME:Auxiliaries
    }
    else if (_nType == NodeType::OutputVtk)
    {
        //Get solve
        Node *s = nullptr;
        for (int d = 0; d < inPorts.size(); d++)
        {
            for (int i = 0; i < inPorts[d]->connectedNodes.size(); i++)
            {
                Node *n = inPorts[d]->connectedNodes[i];
                if (n->_nType == NodeType::Solve and n->blocked == false)
                    s = n;
            }
        }

        //Get linearSolver
        Node *l = nullptr;
        if (s != 0)
        {
            for (int d = 0; d < s->inPorts.size(); d++)
            {
                for (int i = 0; i < s->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = s->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::AZSolver and n->blocked == false)
                        l = n;
                }
            }
        }

        //Get HiPerProblem
        Node *h = nullptr;
        if (l != 0)
        {
            for (int d = 0; d < l->inPorts.size(); d++)
            {
                for (int i = 0; i < l->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = l->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::HiPerProblem and n->blocked == false)
                        h = n;
                }
            }
        }

        //Get integrations
        QVector<Node*> in;
        if (h != 0)
        {
            for (int d = 0; d < h->inPorts.size(); d++)
            {
                for (int i = 0; i < h->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = h->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::Integration and n->blocked == false)
                        in.push_back(n);
                }
            }
        }

        //Get DOFsHandler names
        QVector<QString> dname;
        for (int k = 0; k < in.size(); k++)
        {
            for (int d = 0; d < in[k]->inPorts.size(); d++)
            {
                for (int i = 0; i < in[k]->inPorts[d]->connectedNodes.size(); i++)
                {
                    Node *n = in[k]->inPorts[d]->connectedNodes[i];
                    if (n->_nType == NodeType::DOFsHandler and n->blocked == false)
                        dname.push_back(n->_name->text());
                }
            }
        }

        //Data
        _data.resize(dname.size());
        for (int d = 0; d < dname.size(); d++)
            _data[d] = dname[d] + "->printFileLegacyVtk(\"" + fileLEdit->text() + "\", true);"; //FIXME:Auxiliaries
    }
    else
    {
        //Update data of connected nodes
        for (int i = 0; i < outPort->connectedNodes.size(); i++)
            outPort->connectedNodes[i]->_updateAllInfo();
    }

    emit(dataUpdated());
}

void Node::_visibility(bool v)
{
    if (v == true)
    {
        //Hide
        _mainWidget->hide();

        //Node
        _height -= _mainWidget->height();
        _width = 180;

        //Header
        _nameWidget->setFixedWidth(_width);
        hideButton->setIcon(QIcon(":/img/expand.svg"));
        _bWidget->setFixedWidth(_width-35*2);

        //Ports
        for (int i = 0; i < inPorts.size(); i++)
        {
            Port *p = inPorts[i];
            p->setY(p->pos().y()-_mainWidget->height());
        }
        Port *p = outPort;
        p->setX(_width);
    }
    else
    {
        //Show
        _mainWidget->show();

        //Node
        _height += _mainWidget->height();
        _width = std::max(140, _mainWidget->width())+40;

        //Header
        _nameWidget->setFixedWidth(_width);
        hideButton->setIcon(QIcon(":/img/collapse.svg"));
        _bWidget->setFixedWidth(_width-35*2);

        //Ports
        for (int i = 0; i < inPorts.size(); i++)
        {
            Port *p = inPorts[i];
            p->setY(p->pos().y()+_mainWidget->height());
        }
        Port *p = outPort;
        p->setX(_width);
    }

    //Hide option menu
    _bWidget->hide();
    hambButton->setChecked(false);

    emit(visibilityChanged());
}


void Node::block(bool b)
{
    //(Un)block node
    blocked = b;

    //(Un)block inports
    for (int i = 0; i < inPorts.size(); i++)
        inPorts[i]->block(b);

    //(Un)block outports and links
    outPort->block(b);

    //Change icon
    if (b == true)
        blockButton->setIcon(QIcon(":/img/unlock.svg"));
    else
        blockButton->setIcon(QIcon(":/img/lock.svg"));

    //Hide option menu
    _bWidget->hide();
    hambButton->setChecked(false);

    //Change label color
    if (b == false)
        _name->setStyleSheet("color: white; background:rgba(0,0,0,0);padding:0px;");
    else
        _name->setStyleSheet("color: " + bColor(_nType).name() + ";background:rgba(0,0,0,0);padding:0px;");

    //Update info and repaint
    _updateAllInfo();
    _updateConnected();
    emit(visibilityChanged());
}

void Node::_disableDOFs()
{
    for (int i = 0; i < nDOFs_old; i++)
        dnamLEdits[i]->setDisabled(true);
}

void Node::_updateDOFs()
{
    //Get nDOFs
    int nDOFs = dofsLEdit->text().toInt();

    //Get connected boundary & initial conditions
    QVector<Node*> bc, ic;
    for (int d = 0; d < inPorts.size(); d++)
    {
        for (int i = 0; i < inPorts[d]->connectedNodes.size(); i++)
        {
            Node *n = inPorts[d]->connectedNodes[i];
            if (n->_nType == NodeType::BoundaryConditions)
                bc.push_back(n);
            if (n->_nType == NodeType::InitialConditions)
                ic.push_back(n);
        }
    }

    //Create or delete
    if (nDOFs > nDOFs_old)
    {
        for (int i = nDOFs_old; i < nDOFs; i++)
        {
            //Create new DOFs
            dnamLEdits.push_back(new QLineEdit());
            dnamLEdits[i]->setAlignment(Qt::AlignRight);
            dnamLEdits[i]->setText("d"+QString::number(i));
            dnamLayouts[0]->addWidget(dnamLEdits[i]);
            connect(dnamLEdits[i], SIGNAL(textChanged(QString)), SLOT(_updateAllInfo()));
        }
    }
    else
    {
        for (int i = nDOFs_old-1; i >= nDOFs; i--)
        {
            //Remove DOFs
            dnamLayouts[0]->removeWidget(dnamLEdits[i]);
            delete dnamLEdits[i];
            dnamLEdits.pop_back();
        }
    }

    //Re-enable
    for (int i = 0; i < nDOFs; i++)
        dnamLEdits[i]->setDisabled(false);

    //Save nDOFs
    nDOFs_old = nDOFs;

    //Update
    for (int j = 0; j < bc.size(); j++)
        bc[j]->_updateBC();
    _updateAllInfo();
}

void Node::_updateBC()
{
    QVector<Node *> dhands;
    for (int i = 0; i < outPort->connectedNodes.size(); i++)
        dhands.push_back(outPort->connectedNodes[i]);

    for (int i = 0; i < dhands.size(); i++)
    {
        //Get info
        Node * d = dhands[i];
        int nDOFs = d->dofsLEdit->text().toInt();
        int nItems = dbcBox->count()-1;

        //Add or remove
        if (nItems < nDOFs)
        {
            //Add new items
            for (int j = nItems; j < nDOFs; j++)
                dbcBox->addItem(dhands[i]->dnamLEdits[j]->text());
        }
        else if (nItems > nDOFs)
        {
            //Put back to zero
            if (dbcBox->currentIndex() > nDOFs)
                dbcBox->setCurrentIndex(0);

            //Remove new items
            for (int j = nItems-1; j >= nDOFs; j--)
                dbcBox->removeItem(j);
        }

        //Update names
        for (int j = 1; j < dbcBox->count(); j++)
            if (dbcBox->itemText(j) != dhands[i]->dnamLEdits[j-1]->text())
                dbcBox->setItemText(j, dhands[i]->dnamLEdits[j-1]->text());
    }
}

void Node::_browseSave(QLineEdit *lEdit)
{
    QString fname = QFileDialog::getSaveFileName();

    lEdit->setText(fname);
    _updateAllInfo();
}

void Node::_browseOpen(QLineEdit *lEdit)
{
    QString fname = QFileDialog::getOpenFileName();

    lEdit->setText(fname);
    _updateAllInfo();
}

void Node::_paraview(QString fname)
{
    QProcess *pParaview;
    pParaview = new QProcess();
    QCoreApplication::processEvents();

    pParaview->start("/home/guille/Programs/ParaView-5.6.0-MPI-Linux-64bit/bin/paraview", {fname});
}

void Node::save(QDataStream &ds)
{
    (void) ds;
    // ds << qstr(_nType);
    // ds << pos();
}

bool Node::run()
{
    if (blocked == true)
        return false;

    qInfo() << "Running " << (_name->text());
    using namespace hiperlife;

    using Teuchos::rcp;
    using Teuchos::RCP;

    if (_nType == NodeType::StructMeshGenerator)
    {
        try
        {
            //Get info
            ElemType eType = Element(elemBox->itemData(elemBox->currentIndex()).toString());
            BasisFuncType bfType = BasisFunction(bfBox->itemData(bfBox->currentIndex()).toString());
            int bfOrder = orderLEdit->text().toInt();
            QString gen = genBox->itemData(genBox->currentIndex()).toString();

            //Generate mesh
            structMesh = rcp(new StructMeshGenerator);
            structMesh->setElemType(eType);
            structMesh->setBasisFuncType(bfType);
            structMesh->setBasisFuncOrder(bfOrder);

            if (gen == "genStructMesh")
                structMesh->genStructMesh(nExLEdit->text().toInt());//, nEyLEdit->text().toInt(), nEzLEdit->text().toInt());
            else if (gen == "genTorusSolidSector")
                structMesh->genTorusSolidSector(
                    nExLEdit->text().toInt(),
                    nEyLEdit->text().toInt(),
                    nEzLEdit->text().toInt(),
                    gOptLEdit[0]->text().toDouble(),
                    gOptLEdit[1]->text().toDouble(),
                    gOptLEdit[2]->text().toDouble(),
                    gOptLEdit[3]->text().toDouble());
            else
            {
                structMesh->setBasisFuncType(BasisFuncType::Undefined);
                structMesh->genStructMesh(-1);
            }
            cout << "Struct done" << endl;
        }
        catch (runtime_error& err)
        {
            qInfo() << "Not able to run" << err.what();
            return false;
        }
    }
    else if (_nType == NodeType::MeshLoader)
    {
        try
        {
            //Get info
            ElemType eType = Element(elemBox->itemData(elemBox->currentIndex()).toString());
            BasisFuncType bfType = BasisFunction(bfBox->itemData(bfBox->currentIndex()).toString());
            int bfOrder = orderLEdit->text().toInt();

            //Generate mesh
            loadMesh = rcp (new MeshLoader);
            loadMesh->setElemType(eType);
            loadMesh->setBasisFuncType(bfType);
            loadMesh->setBasisFuncOrder(bfOrder);
            loadMesh->loadMesh(fileLEdit->text().toStdString(), MeshType::Sequential);

            cout << "Loader done" << endl;
        }
        catch (runtime_error& err)
        {
            qInfo() << "Not able to run" << err.what();
            return false;
        }
    }

    return true;
}

//Paint
QRectF Node::boundingRect() const
{
    return QRectF(0-10, 0-10, _width+20, _height+20);
}

QPainterPath Node::shape() const
{
    QPainterPath p;
    p.addRect(0-10, 0-10, _width+20, _height+20);
    return p;
}

void Node::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option);
    Q_UNUSED(widget);

    QPainterPath p;
    p.addRoundedRect(0, 0, _width, _height, 5, 5);
    setPath(p);

    // QColor back = QColor(30,30,30);
    // back.setAlpha(0);
    QColor backColor = QColor(50, 50, 50);
    // QColor backColor = bColor(_nType);
    // backColor = backColor.darker(1500);
    QColor mainColor = bColor(_nType);
    QColor foreColor = QColor(255,255,255);
    if (blocked == true)
    {
        mainColor = backColor;
        foreColor = QColor(100,110,110);
    }

    _mainWidget->setStyleSheet("QWidget {color:"+foreColor.name()+";}");

    QLinearGradient linearGrad(QPointF(0, 0), QPointF(0, _height));
    linearGrad.setColorAt(0, mainColor);
    linearGrad.setColorAt(35/_height, mainColor);
    linearGrad.setColorAt((35+0.1)/_height, backColor);
    linearGrad.setColorAt(1, backColor);
    painter->setBrush(linearGrad);

    if (isSelected())
    {
        painter->setPen(QPen(Qt::lightGray, 1));
        setZValue(1);
    }
    else
    {
        painter->setPen(Qt::NoPen);
        // painter->setPen(QPen(Qt::darkGray, 0.5));
        setZValue(0);
    }

    painter->drawPath(path());
}
