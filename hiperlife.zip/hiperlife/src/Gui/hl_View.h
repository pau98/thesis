/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef hl_VIEW_H
#define hl_VIEW_H

#include <QGraphicsView>
#include <QMouseEvent>
namespace hlGui
{
    class View : public QGraphicsView
    {
            Q_OBJECT
        public:
            View(QWidget *parent = 0);
            View(QGraphicsScene *scene, QWidget *parent = 0);
            View(const View&) = delete;
            View operator=(const View&) = delete;

        public slots:
            void toggleGrid();
            void scaleUp();
            void scaleDown();

        private:
            QGraphicsScene * _scene;
            int m_click;
            bool _drawGrid{false};
            QPointF _clickPos;
            bool _zoomOn{false};

        protected:
            void drawBackground(QPainter* painter, const QRectF& r) override;
            void wheelEvent(QWheelEvent *event) override;
            void keyPressEvent(QKeyEvent *event) override;
            void keyReleaseEvent(QKeyEvent *event) override;
            void mousePressEvent(QMouseEvent *me) override;
            void mouseMoveEvent(QMouseEvent *event) override;
            // void mouseReleaseEvent(QMouseEvent *me) override;

    };
}
#endif
