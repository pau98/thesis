/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <QVector>
#include <QEvent>
#include <QGraphicsSceneMouseEvent>
#include <QtDebug>

#include "hl_Scene.h"

#include "hl_GuiTypes.h"
#include "hl_Node.h"
#include "hl_Port.h"
#include "hl_Link.h"
#include "hl_VtkWidget.h"

using namespace hlGui;

Scene::Scene(QObject *parent) : QGraphicsScene(parent)
{
    setItemIndexMethod(QGraphicsScene::NoIndex);
    installEventFilter(this);
}

Scene::~Scene()
{
    // clearScene();
}

Node* Scene::createNode(NodeType nType, QPointF pos)
{
    //Create node
    Node *n = new Node(nType);

    //Setters
    n->setPos(pos);
    int k{};
    foreach(QGraphicsItem *item, items())
    {
        Node *node = qgraphicsitem_cast<Node *>(item);
        if (node)
        {
            if (node->_nType == nType)
                k++;
        }
    }
    n->setNameNumber(k);

    //Update
    n->Update();

    //Add node
    addItem(n);

    //Connections
    connect(n, SIGNAL(dataUpdated()), this, SLOT(updateAllData()));
    connect(n, SIGNAL(updateVtk()), this, SLOT(updateAllVtk()));
    connect(n, SIGNAL(visibilityChanged()), this, SLOT(update()));
    connect(n->delButton, &QAbstractButton::pressed, this, [=](){deleteNode(n);});
    connect(n, SIGNAL(viewSolution(QString)), this, SLOT(viewSolution(QString)));

    //Update data
    updateAllData();

    return n;
}

void Scene::_createLink(Port* p0, Port* p1)
{
    //Check if the nodes were already connected
    for (int i = 0; i < p0->connectedNodes.size(); i++)
    {
        if (p1->parentNode == p0->connectedNodes[i])
            return;
    }

    //Create link
    Link* l = new Link();
    l->setLink(p0, p1);
    l->Update();
    addItem(l);

    //Save connected nodes in ports
    p0->connectedNodes.push_back(p1->parentNode);
    p1->connectedNodes.push_back(p0->parentNode);
    connect(p0->parentNode->_name, SIGNAL(textChanged(QString)), p1->parentNode, SLOT(_updateAllInfo()));
    connect(p1->parentNode->_name, SIGNAL(textChanged(QString)), p0->parentNode, SLOT(_updateAllInfo()));

    //Update node data
    p0->parentNode->_updateAllInfo();
    p1->parentNode->_updateAllInfo();
}

QGraphicsItem* Scene::itemAt(const QPointF &pos)
{
    QList<QGraphicsItem*> items = this->items(QRectF(pos - QPointF(1,1), QSize(3,3)));

    foreach(QGraphicsItem *item, items)
        if (item->type() > QGraphicsItem::UserType)
            return item;

    return 0;
}

void Scene::mousePressEvent(QGraphicsSceneMouseEvent *me)
{
    if (me->button() != Qt::LeftButton)
        return;

    QGraphicsItem *item = itemAt(me->scenePos());
    if (item and item->type() == Port::Type)
    {
        if (((Port*)item)->_pType == PortType::OutPort)
        {
            link = new Link();
            this->addItem(link);
            link->setPort0((Port*)item);
            link->setCoords0(item->scenePos());
            link->setCoords1(me->scenePos());
            link->Update();
        }
    }

    QGraphicsScene::mousePressEvent(me);
}

void Scene::mouseMoveEvent(QGraphicsSceneMouseEvent *me)
{
    if (link != 0)
    {
        link->setCoords1(me->scenePos());
        link->Update();
        return;
    }

    QGraphicsScene::mouseMoveEvent(me);
}

void Scene::mouseReleaseEvent(QGraphicsSceneMouseEvent *me)
{
    if (link != 0)
    {
        QGraphicsItem *item = itemAt(me->scenePos());
        if (item && item->type() == Port::Type)
        {
            Port *p0 = link->_p0;
            Port *p1 = (Port*) item;

            if (p1->_pType == PortType::InPort and p0->_mnType == p1->_mnType)
            {
                p0->links.pop_back();
                _createLink(p0, p1);

                //Set to zero
                this->removeItem(link); //FIXME: Is this necessary?
                link = 0;
                delete link;

                return;
            }
        }
        link->_p0->links.erase(link->_p0->links.end() - 1);
        this->removeItem(link); //FIXME: Is this necessary?
        delete link;
        link = 0;
        return;
    }

    QGraphicsScene::mouseReleaseEvent(me);
}

void Scene::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *me)
{
    if (me->button() != Qt::LeftButton)
        return;

    QGraphicsItem *item = itemAt(me->scenePos());

    if (item and item->type() == Port::Type)
    {
        Port *p = qgraphicsitem_cast<Port *>(item);
        if (p->_pType == PortType::OutPort)
        {
            //Get all in ports of the same type
            QVector<Port*> ports;
            foreach(QGraphicsItem *item, items())
            {
                Port *op = qgraphicsitem_cast<Port *>(item);
                if (op and op->_pType == PortType::InPort
                    and op->_nType == p->_nType)
                {
                    //Check if the nodes were already connected
                    bool isConnected{false};
                    for (int j = 0; j < op->connectedNodes.size(); j++)
                    {
                        if (p->parentNode == op->connectedNodes[j])
                            isConnected = true;
                    }
                    if (isConnected == true)
                        continue;

                    //Add port
                    ports.push_back(op);
                }
            }

            //Add link to closest port
            if (ports.size() > 0)
            {
                Port* cp = ports[0];
                for (int i = 1; i < ports.size(); i++)
                {
                    //Compare positions
                    QPointF p0 = me->pos() - cp->parentNode->pos();
                    QPointF p1 = me->pos() - ports[i]->parentNode->pos();
                    if (p0.manhattanLength() > p1.manhattanLength())
                        cp = ports[i];
                }
                _createLink(p, cp);
            }
        }
    }

    if (item and item->type() == Node::Type)
    {
        Node *n = qgraphicsitem_cast<Node *>(item);
        QPointF rPos = me->scenePos() - n->pos();
        QRectF pR = QRectF(rPos - QPointF(1,1), QSize(3,3));
        QRectF l = n->_name->geometry();
        QRectF h = n->hambButton->geometry();
        if (l.contains(pR) == false and h.contains(pR) == false)
        {
            QRectF m = n->_mainWidget->geometry();
            bool v = n->hideButton->isChecked();
            if (v == false and m.contains(pR) == false)
            {
                n->hideButton->setChecked(!v);
                return;
            }
            else if (v==true)
            {
                n->hideButton->setChecked(!v);
                return;
            }
        }
    }

    QGraphicsScene::mouseDoubleClickEvent(me);
}

void Scene::_nodeData(Node *n, MetaNodeType mnType)
{
    if (n->_mnType == mnType and n->blocked == false)
    {
        for (int d = 0; d < n->_data.size(); d++)
            _allData.push_back("    " + n->_data[d]);
        _allData.push_back("");
    }
}

void Scene::_nodeData(Node *n, NodeType nType)
{
    if (n->_nType == nType and n->blocked == false)
    {
        for (int d = 0; d < n->_data.size(); d++)
            _allData.push_back("    " + n->_data[d]);
        _allData.push_back("");
    }
}

void Scene::updateAllData()
{
    //Get vector of nodes and unique node types
    QVector<Node*> nodes;
    QVector<Node*> unodes;
    vector<NodeType> types;
    foreach(QGraphicsItem *item, items())
    {
        Node *n = qgraphicsitem_cast<Node *>(item);
        if (n)
        {
            nodes.push_back(n);
            vector<NodeType>::iterator it = std::find(types.begin(), types.end(), n->_nType);
            if (it == types.end())
            {
                types.push_back(n->_nType);
                unodes.push_back(n);
            }
        }
    }

    //Initialize data
    _allData.clear();

    //Common headers [0]
    _allData.push_back("// C++ headers");
    _allData.push_back("#include <iostream>");
    _allData.push_back("#include <mpi.h>");
    _allData.push_back("#include <fstream>");
    _allData.push_back("");
    _allData.push_back("// Trilinos headers");
    _allData.push_back("#include <Teuchos_RCP.hpp>");
    _allData.push_back("");
    _allData.push_back("// hiperlife headers");
    _allData.push_back("#include \"hl_TypeDefs.h\"");

    //Specific headers (with unique node types)
    for (int i = 0; i < unodes.size(); i++)
        for (auto h: unodes[i]->_headers)
            _allData.push_back(h);

    //Common headers [1]
    _allData.push_back("");
    _allData.push_back("using namespace hiperlife;");
    _allData.push_back("");
    _allData.push_back("using Teuchos::rcp;");
    _allData.push_back("using Teuchos::RCP;");
    _allData.push_back("");

    //Element filling functions (declaration)
    for (int i = 0; i < nodes.size(); i++)
        for (auto h: nodes[i]->_headers2)
            _allData.push_back(h);
    _allData.push_back("");

    //Main
    _allData.push_back("int main()");
    _allData.push_back("{");
    _allData.push_back("");
    _allData.push_back("    MPI_Init(nullptr, nullptr);");
    _allData.push_back("");

    //Mesh creator
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], MetaNodeType::MeshCreator);

    //Distributed meshes
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], NodeType::DistributedMesh);
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], NodeType::hDistributedMesh);
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], NodeType::pDistributedMesh);

    //DOFsHandler
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], MetaNodeType::DOFsHandler);

    //HiPerProblem
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], MetaNodeType::HiPerProblem);

    //Linear solver
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], MetaNodeType::LinearSolver);

    //Solve
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], MetaNodeType::Solve);

    //Output
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], MetaNodeType::Output);

    _allData.push_back("    MPI_Finalize();");
    _allData.push_back("    return 0;");
    _allData.push_back("}");
    _allData.push_back("");

    //Element filling functions (implementation)
    for (int i = 0; i < nodes.size(); i++)
        _nodeData(nodes[i], MetaNodeType::ElemFilling);

    emit(allDataUpdated(_allData));
}

void Scene::updateAllVtk()
{
    using namespace hiperlife;

    using Teuchos::rcp;
    using Teuchos::RCP;

    //Get vector of nodes
    QVector<Node*> nodes;
    foreach(QGraphicsItem *item, items())
    {
        Node *n = qgraphicsitem_cast<Node *>(item);
        if (n)
            nodes.push_back(n);
    }

    //Mesh creator
    for (int i = 0; i < nodes.size(); i++)
    {
        if (nodes[i]->_nType == NodeType::StructMeshGenerator)
        {
            if (nodes[i]->run())
                emit(meshCreatorUpdated(nodes[i]->structMesh));
        }
        else if (nodes[i]->_nType == NodeType::MeshLoader)
        {
            if (nodes[i]->run())
                emit(meshCreatorUpdated(nodes[i]->loadMesh));
        }
    }

    //Update vtk
    // emit(allDataUpdated(_allData));
}


void Scene::selectAllNodes()
{
    foreach(QGraphicsItem *item, items())
    {
        Node *n = qgraphicsitem_cast<Node *>(item);
        if (n)
        {
            item->setSelected(true);
        }
    }
}

void Scene::deleteNode(Node *n)
{

    qInfo() << "Inports";
    //InPorts
    for (int i = 0; i < n->inPorts.size(); i++)
    {
        Port* p = n->inPorts[i];
        for (int j = 0; j < p->links.size(); j++)
        {
            //Select connected port
            Port* pc = p->links[j]->_p0;

            //Remove link from connected port vector
            if (pc)
            {
                for (int lp = 0; lp < pc->links.size(); lp++)
                    if (pc->links[lp] == p->links[j])
                        pc->links.erase(pc->links.begin()+lp);
            }

            //Remove links
            removeItem(p->links[j]);
            delete p->links[j];

            //Remove connected nodes
            for (int k = 0; k < pc->connectedNodes.size(); k++)
            {
                if (pc->connectedNodes[k] == n)
                {
                    pc->connectedNodes.erase(pc->connectedNodes.begin()+k);

                    //Update data
                    pc->parentNode->_updateAllInfo();
                }
            }
        }

    }

    qInfo() << "OutPorts";
    //OutPort
    Port* p = n->outPort;
    for (int j = 0; j < p->links.size(); j++)
    {
        //Select connected port
        Port* pc = p->links[j]->_p1;

        //Remove link from connected port
        if (pc)
        {
            for (int lp = 0; lp < pc->links.size(); lp++)
                if (pc->links[lp] == p->links[j])
                    pc->links.erase(pc->links.begin()+lp);
        }

        //Remove links
        removeItem(p->links[j]);
        delete p->links[j];

        //Remove connected nodes
        for (int k = 0; k < pc->connectedNodes.size(); k++)
        {
            if (pc->connectedNodes[k] == n)
            {
                pc->connectedNodes.erase(pc->connectedNodes.begin()+k);
                //Update data
                pc->parentNode->_updateAllInfo();
            }
        }
    }

    //Remove node
    qInfo() << "remove";
    removeItem(n);
    qInfo() << "delete";
    delete n;

    qInfo() << "UPdate";
    //Update data
    updateAllData();

    qInfo() << "End";
}

void Scene::deleteLink(Link *l)
{
    //Remove link from outport
    Node *n0;
    for (int i = 0; i < l->_p0->links.size(); i++)
    {
        if (l == l->_p0->links[i])
        {
            n0 = l->_p0->connectedNodes[i];
            l->_p0->links.erase(l->_p0->links.begin() + i);
            l->_p0->connectedNodes.erase(l->_p0->connectedNodes.begin() + i);
            n0->_updateAllInfo();
        }
    }

    //Remove link from inport
    Node *n1;
    for (int i = 0; i < l->_p1->links.size(); i++)
    {
        if (l == l->_p1->links[i])
        {
            n1 = l->_p0->connectedNodes[i];
            l->_p1->links.erase(l->_p1->links.begin() + i);
            l->_p1->connectedNodes.erase(l->_p1->connectedNodes.begin() + i);
            n1->_updateAllInfo();
        }
    }

    //Remove links
    removeItem(l);
    delete l;

    //Update data
    updateAllData();

    return;
}

void Scene::deleteItems()
{
    //Delete links (first to avoid problems)
    foreach (QGraphicsItem *item, selectedItems())
    {
        if (item->type() == Link::Type)
        {
            Link *l = qgraphicsitem_cast<Link *>(item);
            deleteLink(l);
        }
    }

    //Delete nodes
    foreach (QGraphicsItem *item, selectedItems())
    {
        if (item->type() == Node::Type)
        {
            Node *n = qgraphicsitem_cast<Node *>(item);
            deleteNode(n);
        }
    }
}

void Scene::blockNodes()
{
    foreach (QGraphicsItem *item, selectedItems())
    {
        if (item->type() == Node::Type)
        {
            Node *n = qgraphicsitem_cast<Node *>(item);
            blockNode(n);
        }
    }
}

void Scene::unblockNodes()
{
    foreach (QGraphicsItem *item, selectedItems())
    {
        if (item->type() == Node::Type)
        {
            Node *n = qgraphicsitem_cast<Node *>(item);
            unblockNode(n);
        }
    }
}


void Scene::toggleVisAllItems(bool v)
{
    foreach(QGraphicsItem *item, items())
    {
        Node *n = qgraphicsitem_cast<Node *>(item);
        if (n)
            n->hideButton->setChecked(v);
    }
}

void Scene::run()
{
    foreach(QGraphicsItem *item, items())
    {
        Node *n = qgraphicsitem_cast<Node *>(item);
        if (n)
            n->run();
    }
}

void Scene::save(QDataStream &ds)
{
    foreach(QGraphicsItem *item, items())
    {
        Node *n = qgraphicsitem_cast<Node *>(item);
        if (n)
        {
            ds << QString::fromStdString("Node");
            ds << static_cast<int>(n->_nType);
            ds << n->pos();
            ds << n->inPorts.size();
            for (int p = 0; p < n->inPorts.size(); p++)
                ds << quint64(n->inPorts[p]);
            ds << quint64(n->outPort);

            n->save(ds);
        }
    }

    foreach(QGraphicsItem *item, items())
    {
        Link *l = qgraphicsitem_cast<Link *>(item);
        if (l)
        {
            ds << QString::fromStdString("Link");
            ds << l->Coords0();
            ds << l->Coords1();
            ds << quint64(l->_p0);
            ds << quint64(l->_p1);
            l->save(ds);
        }
    }
}

void Scene::open(QDataStream &ds)
{
    QMap<quint64, Port*> portMap;
    while (!ds.atEnd())
    {
        QString type;
        ds >> type;
        if (type == "Node")
        {
            int i_nType{};
            QPointF pos;
            int n_inPorts{};

            ds >> i_nType;
            ds >> pos;
            Node *n = createNode(static_cast<NodeType>(i_nType), pos);

            ds >> n_inPorts;
            quint64 ptr;
            for (int p = 0; p < n_inPorts; p++)
            {
                ds >> ptr;
                portMap[ptr] = n->inPorts[p];
            }
            ds >> ptr;
            portMap[ptr] = n->outPort;
        }
        else if (type == "Link")
        {
            QPointF c0, c1;
            quint64 ptr0, ptr1;
            ds >> c0;
            ds >> c1;
            ds >> ptr0;
            ds >> ptr1;

            Port* p0 = portMap[ptr0];
            Port* p1 = portMap[ptr1];

            _createLink(p0, p1);
        }

    }

}
