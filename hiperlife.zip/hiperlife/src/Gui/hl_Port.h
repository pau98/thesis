/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef hl_PORT_H
#define hl_PORT_H

#include <QGraphicsEllipseItem>
#include <QGraphicsPathItem>
#include <QGraphicsItem>
#include <QLabel>
#include <QWidget>

#include "hl_GuiTypes.h"

namespace hlGui
{
    class Link;
    class Node;
    class Port : public QGraphicsPathItem
    {

        public:
            enum {Type = UserType + 1};

            Port(PortType pType, NodeType nType, Node *n, QGraphicsItem *Parent = 0);

            void block(bool b);

            virtual QRectF boundingRect() const;
            QPainterPath shape() const;
            void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
            PortType _pType;
            NodeType _nType;
            MetaNodeType _mnType;
            bool blocked{false};

            QLabel *_name;
            QVector<Link*> links;
            Node* parentNode = 0;
            QVector<Node *> connectedNodes;

            int type() const override {return Type;};

        public slots:


        private:
            double _r{6.0};
            double _height{10};
            double _width{10};
            void _setLabel();
            double _px{};
            double _py{};
            double _ph{};
            double _pw{};

        protected:
            QVariant itemChange(GraphicsItemChange change, const QVariant &value) override;

    };
}
#endif
