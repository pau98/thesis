/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef hl_MAINWINDOW_H
#define hl_MAINWINDOW_H

#include <QMainWindow>
#include <QtWidgets>

#include "hl_Scene.h"
#include "hl_View.h"
#include "hl_VtkWidget.h"

namespace hlGui
{

    class MainWindow : public QMainWindow
    {

            Q_OBJECT

        public:
            MainWindow(appStyle st, QWidget *parent = 0);

        private slots:
            void _updateEditor(QVector<QString> data);
            void _open();
            void _save();
            void _saveModel();
            void _compile();
            void _run();
            void _runExt();
            void _loadModel(QString);

            void _pOutput(QProcess *p);

        private:

            //Main objects
            Scene *_scene;
            View *_view;
            QToolBar* _nodeBar;
            QToolBar* _nodeBar2;
            appStyle _st{appStyle::Undefined};

            //Docks
            QDockWidget *_cDock, *_lDock, *_vDock;
            VtkWidget *_vWidget;
            QTextEdit *_code, *_log;

            //General actions
            QAction *_newAct, *_openAct, *_openRAct;
            QAction *_saveAct, *_saveAsAct, *_saveCpAct;
            QAction *_impAct, *_cloAct, *_quitAct;
            QAction *_undoAct, *_redoAct, *_selAllAct, *_delAct, *_blockAct, *_ublockAct, *_prefAct;
            QAction *_collapAllAct, *_expandAllAct, *_vGridAct;
            QAction *_compCodeAct,*_runCodeAct, *_runExtCodeAct;
            QUndoStack *undoStack;

            //Node actions
            QActionGroup *_nodeActs;
            QAction *_structAct, *_gmshAct, *_vtkAct;
            QAction *_loadAct;
            QAction *_disStdAct, *_disHAct, *_disPAct;
            QAction *_dHandAct, *_icAct, *_bcAct;
            QAction *_intAct;
            QAction *_gauAct, *_bgauAct, *_subAct;
            QAction *_preFillAct, *_ralFillAct, *_weaFillAct, *_onsFillAct, *_usrFillAct;
            QAction *_rhsFStrAct, *_lhsFStrAct;
            QAction *_eFStrAct, *_dFStrAct, *_piFStrAct, *_poFStrAct, *_lmFStrAct;
            QAction *_lSystemAct, *_nlSystemAct;
            QAction *_azSolverAct, *_belSolverAct, *_amSolverAct;
            QAction *_NRSolverAct, *_LSSolverAct;
            QAction *_staAct, *_adapAct, *_alphaAct;
            QAction *_solveAct;
            QAction *_stdOutAct, *_vtkOutAct, *_csvOutAct;
            QAction *_udAct;

            //Model and tutorial actions
            QAction *_stdModAct, *_neuModAct, *_gcModAct, *_lmModAct;
            QAction *_saveModAct;
            QAction *_pTutAct, *_chTutAct;

            //Window functions
            void _readSettings();
            void _createGeneralActions();
            void _createNodeActions();
            void _createNodeActions2();
            void _createModelActions();
            void _createMenuBar();
            void _createMenuBar2();
            void _createNodeBar();
            void _createNodeBar2();
            void _createNodeBar3();
            void _createNodeBar4();
            void _createNodeBar5();
            void _createNodeBar6();
            void _createNodeBar7();
            void _createStatusBar();
            void _createDocks();

            //Action functions
            void _createNode(NodeType nType);
            void _saveGui();
            void _saveCode();


        protected:
            void closeEvent(QCloseEvent *event) override;

    };
}
#endif
