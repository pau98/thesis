/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <Teuchos_RCP.hpp>
#include <Epetra_FEVector.h>
#include <Epetra_Import.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_TypeDefs.h"
#include "hl_Checks.h"
#include "hl_FieldStruct.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;

namespace hiperlife
{

    // Set value
    void FieldStruct::setValue(int dof, int idx, IndexType idxtype, double value)
    {
        if (idxtype == IndexType::Local)
            (*_data)[dof][idx] = value;
        else
            (*_data)[dof][locIdx(idx)] = value;
    }

    void FieldStruct::setValue(int dof, double value)
    {
        for (int i = 0; i < _loc_nItem; i++)
            setValue(dof, i, IndexType::Local, value);
    }

    void FieldStruct::setValue(int outdof, int indof, Teuchos::RCP<FieldStruct> fStruc)
    {
        // Check
        if ((outdof > numFlds() - 1) or (indof > fStruc->numFlds() - 1))
            throw runtime_error("FieldStruct::setValue: FieldStruct not compatible.");

        // Set value
        for (int i = 0; i < _loc_nItem; i++)
        {
            (*_data)[outdof][i] = fStruc->getValue(indof, i, IndexType::Local);
        }
    }

    void FieldStruct::setValue(Teuchos::RCP<FieldStruct> fStruc)
    {
        // Check
        if (numFlds() != fStruc->numFlds() or _loc_nItem != fStruc->loc_nItem())
            throw runtime_error("FieldStruct::setValue: The FieldStruct introduced is not compatible.");

        // Set value
        for (int d = 0; d < numFlds(); d++)
            setValue(d, d, fStruc);
    }

    void FieldStruct::setValue(Epetra_MultiVector* vec)
    {
        // Check
        if (vec->MyLength() != numFlds() * _loc_nItem)
            throw runtime_error("FieldStruct::setValue: The Multivector is not compatible with the FieldStruct.");

        // Set value
        int idx = 0;
        for (int i = 0; i < _loc_nItem; i++)
        {
            for (int d = 0; d < numFlds(); d++)
            {
                (*_data)[d][i] = (*vec)[0][idx];
                idx++;
            }
        }

    }


    // Add value
    void FieldStruct::addValue(int dof, int idx, IndexType idxtype, double value)
    {
        if (idxtype == IndexType::Local)
        {
            (*_data)[dof][idx] += value;
        }
        else
        {
            bool inPart = isItemInPart(idx);
            bool inGhost = isItemInPartGhosts(idx);
            if (inPart)
                (*_data)[dof][locIdx(idx)] += value;
            else if (inGhost)
                (*_ghostsData)[dof][locGhostIdx(idx)] += value;

        }
    }

    void FieldStruct::addValue(int dof, double value)
    {
        for (int i = 0; i < _loc_nItem; i++)
            addValue(dof, i, IndexType::Local, value);
    }

    void FieldStruct::addValue(int outdof, int indof, Teuchos::RCP<FieldStruct> fStruc)
    {
        // Check
        if ((outdof > numFlds() - 1) || (indof > fStruc->numFlds() - 1))
            throw runtime_error("FieldStruct::addValue: FieldStruct not compatible.");

        // Add value
        for (int i = 0; i < _loc_nItem; i++)
            (*_data)[outdof][i] += fStruc->getValue(indof, i, IndexType::Local);
    }

    void FieldStruct::addValue(int outdof, int indof, double value, Teuchos::RCP<FieldStruct> fStruc)
    {
        // Check
        if ((outdof > numFlds() - 1) or (indof > fStruc->numFlds() - 1))
            throw runtime_error("FieldStruct::addValue: FieldStruct not compatible.");

        // Add value
        for (int i = 0; i < _loc_nItem; i++)
            (*_data)[outdof][i] += value * fStruc->getValue(indof, i, IndexType::Local);
    }

    void FieldStruct::addValue(Teuchos::RCP<FieldStruct> fStruc)
    {
        // Check
        if (numFlds() != fStruc->numFlds())
            throw runtime_error("FieldStruct::addValue: FieldStruct not compatible.");

        // Add value
        for (int d = 0; d < numFlds(); d++)
            addValue(d, d, fStruc);
    }

    void FieldStruct::addValue(int dofOffset, double value, Epetra_MultiVector *vec)
    {
        // Check
        if ((numFlds() - dofOffset) * _loc_nItem < vec->MyLength())
            throw runtime_error("FieldStruct::addValue: The Multivector is not compatible with the FieldStruct.");

        // Add value
        int idx = 0;
        int d = dofOffset;
        for (int i = 0; i < vec->MyLength(); i++)
        {
            (*_data)[d][idx] += value * (*vec)[0][i];
            idx++;
            if (idx == _loc_nItem)
            {
                idx = 0;
                d++;
            }
        }

    }

    void FieldStruct::addValue(double value, Epetra_MultiVector *vec)
    {
        // Check
        if (vec->MyLength() != numFlds() * _loc_nItem)
            throw runtime_error("FieldStruct::addValue: The Multivector is not compatible with the FieldStruct.");

        //Add value
        int idx = 0;
        for (int i = 0; i < _loc_nItem; i++)
        {
            for (int d = 0; d < numFlds(); d++)
            {
                (*_data)[d][i] += value * (*vec)[0][idx];
                idx++;
            }
        }

    }

    void FieldStruct::addValue(Epetra_MultiVector *vec)
    {
        // Check
        if (vec->MyLength() != numFlds() * _loc_nItem)
            throw runtime_error("FieldStruct::addValue: The Multivector is not compatible with the FieldStruct.");

        // Add value
        int idx = 0;
        for (int i = 0; i < _loc_nItem; i++)
        {
            for (int d = 0; d < numFlds(); d++)
            {
                (*_data)[d][i] += (*vec)[0][idx];
                idx++;
            }
        }
    }


    // Scale value
    void FieldStruct::scaleValue(int dof, int idx, IndexType idxtype, double value)
    {
        if (idxtype == IndexType::Local)
            (*_data)[dof][idx] *= value;
        else
            (*_data)[dof][locIdx(idx)] *= value;
    }

    void FieldStruct::scaleValue(int dof, double value)
    {
        for (int i = 0; i < _loc_nItem; i++)
            scaleValue(dof, i, IndexType::Local, value);
    }

    void FieldStruct::scaleValue(int outdof, int indof, Teuchos::RCP<FieldStruct> fStruc)
    {
        // Check
        if ((outdof > numFlds() - 1) || (indof > fStruc->numFlds() - 1))
            throw runtime_error("FieldStruct::scaleValue: FieldStruct not compatible.");

        // Scale value
        for (int i = 0; i < _loc_nItem; i++)
            (*_data)[outdof][i] *= fStruc->getValue(indof, i, IndexType::Local);
    }

    // Pointer between fields
    void FieldStruct::mirrorFieldStructure(Teuchos::RCP<FieldStruct> fStruc)
    {
        // Check
        if (numFlds() != fStruc->numFlds())
            throw runtime_error("FieldStruct::pointToFieldStructure: The number of fields (" + to_string(numFlds()) + ") in " + nameTag() + " and the number of fields ("+ to_string(fStruc->numFlds()) + ") in " + fStruc->nameTag() + " are not compatible.");
        if (_data == fStruc->_data)
            throw runtime_error("FieldStruct::pointToFieldStructure: The fieldStructures are the same");

        // Set pointers
        _data = fStruc->_data;

        // Save mirrored fieldStructs for ghost update
        if (std::find(fStruc->_mirroredFieldStruct.begin(), fStruc->_mirroredFieldStruct.end(), this) == fStruc->_mirroredFieldStruct.end())
            fStruc->_mirroredFieldStruct.push_back(this);
    }

    void FieldStruct::mirrorField(int dof, int fStruc_dof, Teuchos::RCP<FieldStruct> fStruc)
    {
        // Checks
        if (dof > numFlds() - 1 or dof < 0)
            throw runtime_error("FieldStruct::pointToField: There is no such field " + to_string(dof) + " in " + nameTag());
        if (fStruc_dof > fStruc->numFlds() - 1 or fStruc_dof < 0)
            throw runtime_error("FieldStruct::pointToField: There is no such field " + to_string(fStruc_dof) + " in " + fStruc->nameTag());
        if (_loc_nItem != fStruc->_loc_nItem)
            throw runtime_error("FieldStruct::pointToField: Fields not compatible. The number of local element is different.(" + to_string(_loc_nItem) + " in " + nameTag() + " and " + to_string(fStruc->_loc_nItem) + " in " + fStruc->nameTag() + ")");
        if (_data == fStruc->_data)
            throw runtime_error("FieldStruct::pointToField: The fieldStructures are the same");

        // Mirror data
        (*_data)[dof] = (*fStruc->_data)[fStruc_dof];

        // Save mirrored fieldStructs for ghost update
        if (std::find(fStruc->_mirroredFieldStruct.begin(), fStruc->_mirroredFieldStruct.end(), this) == fStruc->_mirroredFieldStruct.end())
            fStruc->_mirroredFieldStruct.push_back(this);
    }
}
