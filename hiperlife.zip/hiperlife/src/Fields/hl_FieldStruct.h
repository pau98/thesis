/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef FIELDSTRUCT_H
#define FIELDSTRUCT_H

#include <string>

#include <Teuchos_RCP.hpp>
#include <Epetra_FEVector.h>
#include <Epetra_IntSerialDenseVector.h>

#include "hl_TypeDefs.h"
#include "hl_DistributedSrcData.h"
#include "hl_TagClass.h"

namespace hiperlife
{

    /*!
     * \class FieldStruct
     * \brief Data structure prepared for storing real fields
     *
     * FieldStruct is a data structure prepared for storing real fields. It assumes a unique distribution among
     * different ranks shared for a finite number of fields.
     *
    */
    class FieldStruct : public DistributedSrcData, public TagClass
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            FieldStruct(std::string tag = "FieldStruct", MPI_Comm comm = MPI_COMM_WORLD) : DistributedSrcData(tag, comm) {}
            FieldStruct(FieldStruct &&other) = default;
            virtual ~FieldStruct() = default;
            FieldStruct& operator=(FieldStruct&& other) = default;

            FieldStruct& operator=(const FieldStruct& other) = delete;
            FieldStruct(const FieldStruct& other) = delete;
            /** @} */ // end of constructors

            /** @name Object Creation Management
            *  @{
            */
            /*! \brief Method check all the parameters and creates the object. */
            void Update() override;

            /*! \brief Set the number of fields. Tags will be created automatically as 'Field_i' with i from 0 to nflds-1. */
            void setNFlds(int nflds);
            /*! \brief Set the tags for the fields. The number of fields will set as the number of tags,
             * ignoring anything setted before. */
            void setNFlds(std::vector<std::string> tags);
            /*! \brief Set the BlockMap that defines the distribution of the nodes in different ranks. This is common
             * for all the fields stores here. */
            void setBlockMap(Epetra_BlockMap map){_map = Teuchos::rcp(new Epetra_BlockMap(map));}
            /*! \brief Create the FieldStruct with data stored in POD array. The data is supposed to
             * be in only in rank 0 and it will be distributed according to the map introduced when the Update is called.
             * Warning! This method is only here for small simulations and its use is not adviced. */
            void setGlobFields(double*& fields) {_tmp_globFields = fields;}
            /*! \brief Create the FieldStruct with data stored in POD array. The data is supposed to
             * be distributed according to the map introduced. */
            void setDistFields(double*& fields) {_tmp_distFields = fields;}
            /*! \brief Create the FieldStruct with data stored in a Epetra_FEVector. . */
            void setFields(Teuchos::RCP<Epetra_FEVector> fields) {_tmp_fields = fields;}
            /*! \brief Create the FieldStruct with data stored in a file with hplfe data format. */
            void setIStream(std::istream &in, OutputMode mode) {_tmp_istream = &in; _tmp_outputmode = mode;}
            /** @} */ // end of object creation management

            /** @name Modifiers
            *  @{
            */

            // Set value
            /*! \brief Set the dof field with a given value in only one node. */
            void setValue(int dof, int idx, IndexType idxtype, double value);
            /*! \brief Set the tag field with a given value in only one node. */
            inline void setValue(std::string tag, int idx, IndexType idxtype, double value) {setValue(index(tag), idx, idxtype, value);};
            /*! \brief Set the dof field with a given value. */
            void setValue(int dof, double value);
            /*! \brief Set the tag field with a given value. */
            inline void setValue(std::string tag, double value) {setValue(index(tag), value);};
            /*! \brief Set all the fields with a given value. */
            inline void setValue(double value){_data->PutScalar(value);};
            /*! \brief Set the outdof of the current FieldStruct with the data of the indof of fStruct */
            void setValue(int outdof, int indof, Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief Set the outtag of the current FieldStruct with the data of the intag of fStruct */
            inline void setValue(std::string outtag, std::string intag, Teuchos::RCP<FieldStruct> fStruc) {setValue(index(outtag), fStruc->index(intag), fStruc);};
            /*! \brief Set the dof of the current FieldStruct with the data of the dof of fStruct */
            inline void setValue(int dof, Teuchos::RCP<FieldStruct> fStruc) {setValue(dof, dof, fStruc);}
            /*! \brief Set the dof of the current FieldStruct with the data of the dof of fStruct */
            inline void setValue(std::string tag, Teuchos::RCP<FieldStruct> fStruc) {setValue(index(tag), fStruc->index(tag), fStruc);};
            /*! \brief Set all the fields with the data of another FieldStruct. It checks that both
             * FieldStruct have the same same data distribution and number of fields. */
            void setValue(Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief Set all the fields with the data stored in a Epetra_MultiVector. It checks that local length
             * of the Multivector is compatible with the number of fields and local nodes of the FieldStruct. */
            void setValue(Epetra_MultiVector *vec);
            /*! \brief Set all the fields with the data stored in a Epetra_MultiVector. It checks that local length
             * of the Multivector is compatible with the number of fields and local nodes of the FieldStruct. */
            inline void setValue(Teuchos::RCP<Epetra_MultiVector> vec){setValue(vec.getRawPtr());};


            // Add value
            /*! \brief Add to dof field a given value in only one node. */
            void addValue(int dof, int idx, IndexType idxtype, double value);
            /*! \brief Add to tag field a given value in only one node. */
            inline void addValue(std::string tag, int idx, IndexType idxtype, double value) {addValue(index(tag), idx, idxtype, value);};
            /*! \brief Add to dof field a given value. */
            void addValue(int dof, double value);
            /*! \brief Add to tag field a given value. */
            inline void addValue(std::string tag, double value) {addValue(index(tag), value);};
            /*! \brief Add to the outdof of the current FieldStruct the data of the indof of fStruct */
            void addValue(int outdof, int indof, Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief Add to the outtag of the current FieldStruct the data of the intag of fStruct */
            inline void addValue(std::string outtag, std::string intag, Teuchos::RCP<FieldStruct> fStruc) {addValue(index(outtag), fStruc->index(intag), fStruc);};
            /*! \brief Add to the outdof of the current FieldStruct the data of the indof of fStruct scale with
             * a constant value a */
            void addValue(int outdof, int indof, double a, Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief Add to the outtag of the current FieldStruct the data of the intag of fStruct scale with
             * a constant value a */
            inline void addValue(std::string outtag, std::string intag, double a, Teuchos::RCP<FieldStruct> fStruc) {addValue(index(outtag), fStruc->index(intag), a, fStruc);};
            /*! \brief Add to the dof of the current FieldStruct the data of the dof of fStruct */
            inline void addValue(int dof, Teuchos::RCP<FieldStruct> fStruc) {addValue(dof, dof, fStruc);};
            /*! \brief Add to the dof of the current FieldStruct the data of the dof of fStruct */
            inline void addValue(std::string tag, Teuchos::RCP<FieldStruct> fStruc) {addValue(index(tag), fStruc->index(tag), fStruc);};
            /*! \brief Add to the dof of the current FieldStruct the data of the dof of fStruct scale with
             * a constant value a */
            inline void addValue(int dof, double a, Teuchos::RCP<FieldStruct> fStruc) {addValue(dof, dof, a, fStruc);};
            /*! \brief Add to the tag field of the current FieldStruct the data of the dof of fStruct scale with
             * a constant value a */
            inline void addValue(std::string tag, double a, Teuchos::RCP<FieldStruct> fStruc) {addValue(index(tag), fStruc->index(tag), a, fStruc);};
            /*! \brief Add all the fields with the data of another FieldStruct. It checks that both
             * FieldStruct have the same same data distribution and number of fields. */
            void addValue(Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief All the data stored in a Epetra_MultiVector to dofs of FieldStruct starting at dofOffset.
             * It checks that local length of the Multivector is compatible with the number of fields plus the offset
             * and local nodes of the FieldStruct. */
            void addValue(int dofOffset, double a, Epetra_MultiVector *vec);
            /*! \brief All the data stored in a Epetra_MultiVector to dofs of FieldStruct starting at dofOffset.
             * It checks that local length of the Multivector is compatible with the number of fields plus the offset
             * and local nodes of the FieldStruct. */
            inline void addValue(std::string tagOffset, double a, Epetra_MultiVector *vec) {addValue(index(tagOffset), a, vec);};
            /*! \brief Add the content of Epetra_Multivector (with a multiplied constant) to the current data
             * of the FieldStruct. It checks that the local length of the Multivector is compatible with the number
             * of fields and local nodes of the FieldStruct. */
            void addValue(double a, Epetra_MultiVector *vec);
            /*! \brief Add the content of Epetra_Multivector to the current data of the FieldStruct. It checks that the
             * local length of the Multivector is compatible with the number of fields and local nodes of the FieldStruct. */
            void addValue(Epetra_MultiVector *vec);
            /*! \brief Add the content of Epetra_Multivector (with a multiplied constant) to the current data
             * of the FieldStruct. It checks that the local length of the Multivector is compatible with the number
             * of fields and local nodes of the FieldStruct. */
            inline void addValue(double a, Teuchos::RCP<Epetra_MultiVector> vec){addValue(a, vec.getRawPtr());};
            /*! \brief Add the content of Epetra_Multivector to the current data of the FieldStruct. It checks that the
             * local length of the Multivector is compatible with the number of fields and local nodes of the FieldStruct. */
            inline void addValue(Teuchos::RCP<Epetra_MultiVector> vec){addValue(vec.getRawPtr());};


            // Scale value
            /*! \brief Scale a dof field with a given value in only one node. */
            void scaleValue(int dof, int idx, IndexType idxtype, double value);
            /*! \brief Scale a tag field with a given value in only one node. */
            inline void scaleValue(std::string tag, int idx, IndexType idxtype, double value) {scaleValue(index(tag), idx, idxtype, value);};
            /*! \brief Scale a dof field with a given value. */
            void scaleValue(int dof, double value);
            /*! \brief Scale a tag field with a given value. */
            inline void scaleValue(std::string tag, double value) {scaleValue(index(tag), value);};
            /*! \brief Scale the outdof of the current FieldStruct with the data of the indof of fStruct */
            void scaleValue(int outdof, int indof, Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief Scale the outtag of the current FieldStruct with the data of the intag of fStruct */
            inline void scaleValue(std::string outtag, std::string intag, Teuchos::RCP<FieldStruct> fStruc) {scaleValue(index(outtag), fStruc->index(intag), fStruc);};
            /*! \brief Scale the dof of the current FieldStruct with the data of the dof of fStruct */
            inline void scaleValue(int dof, Teuchos::RCP<FieldStruct> fStruc) {scaleValue(dof, dof, fStruc);};
            /*! \brief Scale the dof of the current FieldStruct with the data of the dof of fStruct */
            inline void scaleValue(std::string tag, Teuchos::RCP<FieldStruct> fStruc) {scaleValue(index(tag), fStruc->index(tag), fStruc);};

            // Field mirror
            /*! \brief Mirror all data of the current FieldStruct with the data of fStruct. Ghost update is automatically done for mirror fields. */
            void mirrorFieldStructure(Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief Mirror field dof of the current FieldStruct to field fStruct_dof of fStruct. Ghost update is automatically done for mirror fields. */
            void mirrorField(int dof, int fStruc_dof, Teuchos::RCP<FieldStruct> fStruc);
            /*! \brief Mirror field dof of the current FieldStruct to field dof of fStruct. Ghost update is automatically done for mirror fields. */
            inline void mirrorField(int dof, Teuchos::RCP<FieldStruct> fStruc){mirrorField(dof, dof, fStruc);};
            /*! \brief Mirror field dof_tag of the current FieldStruct to field dof_tag of fStruct. Ghost update is automatically done for mirror fields. */
            inline void mirrorField(std::string dof_tag, Teuchos::RCP<FieldStruct> fStruc){mirrorField(index(dof_tag), fStruc->index(dof_tag), fStruc);};
            /*! \brief Mirror field dof_tag of the current FieldStruct to field fStruct_dof_tag of fStruct. Ghost update is automatically done for mirror fields. */
            inline void mirrorField(std::string dof_tag, std::string fStruc_dof_tag, Teuchos::RCP<FieldStruct> fStruc){mirrorField(index(dof_tag), fStruc->index(fStruc_dof_tag), fStruc);};


            /** @} */ // end of modifiers


            /** @name Getters
            *  @{
            */
            /*! \brief Get the value of dof field of index idx. */
            inline int numFlds() const {return _tags.size();}

            double getValue(int dof, int idx, IndexType idxtype = IndexType::Global) const;
            /*! \brief Get the value of tag field of index idx. */
            double getValue(std::string tag, int idx, IndexType idxtype = IndexType::Global) const {return getValue(index(tag), idx, idxtype);};

            /*! \brief Compute the L2 norm of dof field.  */
            double norm2(int dof) const;
            /*! \brief Compute the L2 norm of dof field and set it to result.  */
            inline void norm2(double &result, int dof) {result = norm2(dof);};
            /*! \brief Compute the L2 norm of tag field.  */
            inline double norm2(std::string tag) {return norm2(index(tag));};
            /*! \brief Compute the L2 norm of tag field and set it to result.  */
            inline void norm2(double &result, std::string tag) {result = norm2(index(tag));};
            /** @} */ // end of modifiers

            /** @name I/O
            *  @{
            */
            void outFullData(std::ostream& os, OutputMode mode) const;
            /** @} */ // end of I/O

            /** @name Ghosts Management
            *  @{
            */
            /*! \brief Updates the information of the ghosts points. */
            void UpdateGhosts() override {_updateGhosts();}
            /*! \brief Generates the information of ghost points. */
            int UpdateGhosts(std::vector<int> listGhosts) override
            {return DistributedSrcData::UpdateGhosts(listGhosts);}
            /** @} */ // end of Ghost Management



            /** @name Expert Users and Developers Only
            *  @{ */
            // Public Data - Should be used only for debug
            Teuchos::RCP<Epetra_FEVector> _data    = Teuchos::null;
            Teuchos::RCP<Epetra_FEVector> _ghostsData  = Teuchos::null;
            /** @} */ // end of expert users



        protected:
            Teuchos::RCP<Epetra_FEVector> _tmp_fields;
            double *_tmp_globFields{nullptr};
            double *_tmp_distFields{nullptr};
            std::istream* _tmp_istream{nullptr};
            OutputMode _tmp_outputmode = OutputMode::Undefined;
            std::vector<FieldStruct*> _mirroredFieldStruct{};

            int _allocGhosts() override;
            int _updateGhosts();
            void _createDistribFields(double *&fields);
            void _setDistribFields(double *&fields, int numGhosts = 0);
            void _destroyTmpPtrs();
            void _update_disIStream();
    };

    std::ostream& operator<<(std::ostream& os, const FieldStruct& field);

}
#endif // FIELDSTRUCT_H
