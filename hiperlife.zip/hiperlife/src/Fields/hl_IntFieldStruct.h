/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef INTFIELDSTRUCT_H
#define INTFIELDSTRUCT_H

#include <string>

#include <Teuchos_RCP.hpp>
#include <Epetra_IntVector.h>
#include <Epetra_IntSerialDenseVector.h>

#include "hl_TypeDefs.h"
#include "hl_DistributedSrcData.h"
#include "hl_TagClass.h"

namespace hiperlife
{

    /*!
     * \class IntFieldStruct
     * \brief Data structure prepared for storing integer fields
     *
     * FieldStruct is a data structure prepared for storing real fields. It assumes a unique distribution among
     * different ranks shared for a finite number of fields.
     *
    */
    class IntFieldStruct : public DistributedSrcData, public TagClass
    {
        public:

            /** @name Constructor / Destructor / Operator
            Copy constructors are deleted for memory safety but objects can be created from
            temporal objects through move constructors
            *  @{ */
            IntFieldStruct(std::string tag ="IntFieldStruct", MPI_Comm comm = MPI_COMM_WORLD) : DistributedSrcData(tag, comm) {}
            IntFieldStruct(IntFieldStruct &&other) = default;
            virtual ~IntFieldStruct() = default;
            IntFieldStruct& operator=(IntFieldStruct&& other) = default;

            IntFieldStruct& operator=(const IntFieldStruct& other) = delete;
            IntFieldStruct(const IntFieldStruct& other) = delete;
            /** @} */ // end of constructors

            /** @name Object Creation Management
            *  @{
            */
            /*! \brief Method check all the parameters and creates the object. */
            void Update() override;

            /*! \brief Set the number of fields. Tags will be created automatically as 'Field_i' with i from 0 to nflds-1. */
            void setNFlds(int nflds);
            /*! \brief Set the tags for the fields. The number of fields will set as the number of tags,
             * ignoring anything setted before. */
            void setNFlds(std::vector<std::string> tags);
            /*! \brief Set the BlockMap that defines the distribution of the nodes in different ranks. This is common
             * for all the fields stores here. */
            void setBlockMap(Epetra_BlockMap map)
            {_tmp_map = Teuchos::rcp(new Epetra_BlockMap(map));}
            /*! \brief Create the FieldStruct with data stored in POD array. The data is supposed to
             * be in only in rank 0 and it will be distributed according to the map introduced when the Update is called.
             * Warning! This method is only here for small simulations and its use is not adviced. */
            void setGlobFields(int*& fields)
            {_tmp_globFields = fields;}
            /*! \brief Create the FieldStruct with data stored in POD array. The data is supposed to
             * be distributed according to the map introduced. */
            void setDistFields(int*& fields)
            {_tmp_distFields = fields;}
            /*! \brief Create the FieldStruct with data stored in a file with hplfe data format. */
            void setIStream(std::istream &in, OutputMode mode)
            {_tmp_istream = &in; _tmp_outputmode = mode;}
            /** @} */ // end of object creation management


            /** @name Modifiers
            *  @{
            */
            /*! \brief Set all the fields with a given value. */
            void setValue(int value);
            /*! \brief Set all the fields with the data of another IntFieldStruct. It checks that both
             * FieldStruct have the same same data distribution and number of fields. */
            void setValue(Teuchos::RCP<IntFieldStruct> iFStruc);


            /*! \brief Set the idxFld field with a given value. */
            void setValue(int idxFld, int value);
            /*! \brief Set the dof field with a given value in only one node. */
            void setValue(int idxFld, int idx, IndexType idxtype, int value);
            /*! \brief Set the idxFld fields with the data stored in a Epetra_IntVector.*/
            void setValue(int idxFld, Epetra_IntVector iVec);


            /*! \brief Set the tag field with a given value. */
            inline void setValue(std::string tag, int value) { setValue(index(tag), value); };
            /*! \brief Set the tag field with a given value in only one node. */
            inline void setValue(std::string tag, int idx, IndexType idxtype, int value)  { setValue(index(tag), idx, idxtype, value); };
            /*! \brief Set the tag fields with the data stored in a Epetra_IntVector.*/
            inline void setValue(std::string tag, Epetra_IntVector iVec)  { setValue(index(tag), iVec); };
            /** @} */ // end of modifiers

            /** @name Getter
            *  @{
            */
            /*! \brief Get the value of iFld field of index idx. */
            int getValue(int iFld, int idx, IndexType idxtype = IndexType::Global) const;
            /*! \brief Get the value of tag field of index idx. */
            inline int getValue(std::string tag, int idx, IndexType idxtype = IndexType::Global) const { return getValue(index(tag), idx, idxtype); };
            /*! \brief Get the number of fields */
            inline int numFlds() const {return _tags.size();}
            /** @} */ // end of getter

            /** @name I/O
            *  @{
            */
            void outFullData(std::ostream& os, OutputMode mode) const;
            /** @} */ // end of I/O

            /** @name Ghosts Management
            *  @{
            */
            void UpdateGhosts() override {_updateGhosts();}
            int UpdateGhosts(std::vector<int> listGhosts) override {   return DistributedSrcData::UpdateGhosts(listGhosts);}
            /** @} */ // end of Ghost Management



            /** @name Expert Users and Developers Only
            *  @{ */
            // Public Data - Should be used only for debug
            std::vector<Teuchos::RCP<Epetra_IntVector>> _data;
            std::vector<Teuchos::RCP<Epetra_IntVector>> _ghostsData;
            /** @} */ // end of expert users



        protected:
            Teuchos::RCP<Epetra_BlockMap> _tmp_map = Teuchos::null;
            int *_tmp_globFields{nullptr};
            int *_tmp_distFields{nullptr};
            std::istream* _tmp_istream{nullptr};
            OutputMode _tmp_outputmode = OutputMode::Undefined;

            int _allocGhosts() override;
            int _updateGhosts();
            void _createDistribFields(int *&fields);
            void _setDistribFields(int *&fields);

            void _destroyTmpPtrs();

            void _update_disIStream();
   };

    std::ostream& operator<<(std::ostream& os, const IntFieldStruct& field);

}
#endif // INTFIELDSTRUCT_H
