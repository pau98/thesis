/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <vector>

#include <Teuchos_RCP.hpp>
#include <Teuchos_Array.hpp>

#include <Epetra_FEVector.h>
#include <Epetra_Import.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_TypeDefs.h"
#include "hl_IntFieldStruct.h"
#include <hl_Checks.h>




using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::arcp;
using Teuchos::Array;
using Teuchos::null;


namespace hiperlife
{

    void IntFieldStruct::Update()
    {
        bool distPODReady{};
        bool globPODReady{};
        bool emptyReady{};
        bool iStreamReady{};


        _classTag = "IntFieldStruct";
        if (_nameTag == "DistributedClass")
            _nameTag = "IntFieldStruct";

        if (_tmp_distFields != nullptr && _tmp_map  != null && numFlds() != 0)
            distPODReady = true;

        if (_tmp_globFields != nullptr && _tmp_map  != null && numFlds() != 0)
            globPODReady = true;

        if (_tmp_map  != null && numFlds() != 0 && _tmp_globFields == nullptr
            && _tmp_distFields == nullptr)
            emptyReady = true;

        if (_tmp_istream != nullptr && _tmp_outputmode != OutputMode::Undefined)
            iStreamReady = true;

        int check = checkUpdates({distPODReady, globPODReady, emptyReady, iStreamReady});

        if (check == 2)
            throw runtime_error("IntFieldStruct::Update: It can not choose between modes.");

        if (check == 0)
            throw runtime_error("IntFieldStruct::Update: There is no ready update method.");


        if (iStreamReady)
        {
            _update_disIStream();
        }
        else if(globPODReady)
        {
            _nItem = _tmp_map->NumGlobalElements();
            _loc_nItem = _tmp_map->NumMyElements();

            _createDistribFields(_tmp_globFields);
        }
        else if(distPODReady)
        {
            _nItem = _tmp_map->NumGlobalElements();
            _loc_nItem = _tmp_map->NumMyElements();

            _setDistribFields(_tmp_distFields);
        }
        else if(emptyReady)
        {
            _data.resize(numFlds());
            for(int i = 0; i < numFlds(); i++)
                _data[i] = rcp(new Epetra_IntVector(*_tmp_map));


            _nItem = _data[0]->GlobalLength();
            _loc_nItem = _data[0]->MyLength();
        }

        UpdateDistData();
        _destroyTmpPtrs();
    }

    void IntFieldStruct::setNFlds(int nflds)
    {
        genDefaultTags(*this, nflds, "IntField");
    }

    void IntFieldStruct::setNFlds(vector<string> tags)
    {
        createTags(*this, tags);
    }

    int IntFieldStruct::_allocGhosts()
    {
        if (numFlds() == 0)
            return 1;

        _ghostsData.resize(numFlds());
        for(int i = 0; i < numFlds(); i++)
            _ghostsData[i] = rcp(new Epetra_IntVector(_ghostsImporter->TargetMap()));

        if(_data.size() != null)
            _updateGhosts();

        return 0;
    }

    int IntFieldStruct::_updateGhosts()
    {
        for(int i = 0; i < numFlds(); i++)
            _ghostsData[i]->Import(*_data[i], *_ghostsImporter, Insert);

        return 0;
    }


    int IntFieldStruct::getValue(int iFld, int idx, IndexType idxtype) const
    {
        if (idxtype == IndexType::Local)
            return (*_data[iFld])[idx];
        else
        {
            if(isItemInPart(idx))
                return (*_data[iFld])[locIdx(idx)];
            else if(isItemInPartGhosts(idx))
            {
                ptrdiff_t idx_ghosts = find(_ghosts.begin(), _ghosts.end(), idx) - _ghosts.begin();
                return (*_ghostsData[iFld])[idx_ghosts];
            }
            else
            {
                throw runtime_error("IntFieldStruct::getValue: Not Here in Rank: " + to_string(_myRank) +
                " !! \n dof: " + to_string(iFld) +  "  idx: " + to_string(idx) + " (" +
                    str(idxtype) +") ");
            }

            return 0;
        }

    }

    void IntFieldStruct::_createDistribFields(int *&fields)
    {

        RCP<Epetra_FEVector> douFlds = rcp(new Epetra_FEVector(*_tmp_map, numFlds()));

        if (_myRank == 0)
        {
            for(int i = 0; i < _nItem; i++)
            {
                for(int n = 0; n < numFlds(); n++)
                {
                    double dFld;
                    if (fields[numFlds()*i+n] >= 0)
                        dFld = (double) fields[numFlds()*i+n] + 0.1;
                    else
                        dFld = (double) fields[numFlds()*i+n] - 0.1;

                    //FIXME: double dFld = (double) fields[numFlds()*n+i] + 0.1;
                    douFlds->ReplaceGlobalValues(1, &i, &dFld, n);
                }
            }
        }


        douFlds->GlobalAssemble();
        Barrier();


        _data.resize(numFlds());
        for(int i = 0; i < numFlds(); i++)
            _data[i] = rcp(new Epetra_IntVector(*_tmp_map));

        for(int i = 0; i < _loc_nItem; i++)
            for(int n = 0; n < numFlds(); n++)
                (*_data[n])[i] = (*douFlds)[n][i];

        Barrier();

    }


    void IntFieldStruct::_setDistribFields(int *&fields)
    {

        _data.resize(numFlds());
        for(int i = 0; i < numFlds(); i++)
                _data[i] = rcp(new Epetra_IntVector(*_tmp_map));

        for(int n = 0; n < numFlds(); n++)
            for(int i = 0; i < _loc_nItem; i++)
                (*_data[n])[i] = fields[n*_loc_nItem + i];

        Barrier();
    }



    void IntFieldStruct::_destroyTmpPtrs()
    {
        _tmp_map    = null;

        _tmp_globFields = nullptr;
        _tmp_distFields = nullptr;

        _tmp_istream    = nullptr;
        _tmp_outputmode = OutputMode::Undefined;
    }


    void IntFieldStruct::setValue(int value)
    {
        for(int n = 0; n < numFlds(); n++)
            _data[n]->PutValue(value);
    }


    void IntFieldStruct::setValue(int idxFld, int idx, IndexType idxtype, int value)
    {
        if (idxtype == IndexType::Local)
            (*_data[idxFld])[idx] = value;
        else
            (*_data[idxFld])[locIdx(idx)] = value;
    }

    void IntFieldStruct::setValue(Teuchos::RCP<IntFieldStruct> iFStruc)
    {

        if (numFlds() != iFStruc->numFlds() or _loc_nItem != iFStruc->loc_nItem())
        {
            throw runtime_error("IntFieldStruct::setValue: IntFieldStruct is not compatible.");
        }

        for (int i = 0; i < _loc_nItem; i++)
        {
            for (int d = 0; d < numFlds(); d++)
            {
                (*_data[d])[i] = iFStruc->getValue(d, i, IndexType::Local);
            }
        }
    }

    void IntFieldStruct::setValue(int idxFld, Epetra_IntVector iVec)
    {
        for (int i = 0; i < _loc_nItem; i++)
        {
            (*_data[idxFld])[i] = iVec[i];
        }

    }

    void IntFieldStruct::setValue(int dof, int value)
    {
        for (int i = 0; i < _loc_nItem; i++)
            setValue(dof, i, IndexType::Local, value);
    }

}
