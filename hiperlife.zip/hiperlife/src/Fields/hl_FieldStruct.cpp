/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#include <vector>

#include <Teuchos_RCP.hpp>
#include <Epetra_FEVector.h>
#include <Epetra_Import.h>
#include <Epetra_IntSerialDenseMatrix.h>

#include "hl_TypeDefs.h"
#include "hl_Checks.h"
#include "hl_FieldStruct.h"




using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;


namespace hiperlife
{

    void FieldStruct::Update()
    {
        bool distHPLFEReady{};
        bool distPODReady{};
        bool globPODReady{};
        bool emptyReady{};
        bool iStreamReady{};


        _classTag = "FieldStruct";
        if (_nameTag == "DistributedClass")
            _nameTag = "FieldStruct";

        if (_tmp_fields != null)
            distHPLFEReady = true;

        if (_tmp_distFields != nullptr && _map  != null && numFlds() != 0)
            distPODReady = true;

        if (_tmp_globFields != nullptr && _map  != null && numFlds() != 0)
            globPODReady = true;

        if (_map  != null && numFlds() != 0 && _tmp_globFields == nullptr
            && _tmp_distFields == nullptr)
            emptyReady = true;

        if (_tmp_istream != nullptr && _tmp_outputmode != OutputMode::Undefined)
            iStreamReady = true;

        int check = checkUpdates({distHPLFEReady, distPODReady, globPODReady, emptyReady, iStreamReady});

        if (check == 2)
            throw runtime_error("FieldStruct::Update: It can not choose between modes.");

        if (check == 0)
            throw runtime_error("FieldStruct::Update: There is no ready update method.");


        if (iStreamReady)
        {
            _update_disIStream();
        }
        else if(globPODReady)
        {
            _nItem = _map->NumGlobalElements();
            _createDistribFields(_tmp_globFields);

            _loc_nItem = _data->MyLength();
        }
        else if(distPODReady)
        {
            _nItem = _map->NumGlobalElements();
            _loc_nItem = _map->NumMyElements();

            UpdateDistData();

            _setDistribFields(_tmp_distFields);
        }
        else if(distHPLFEReady)
        {
            _nItem = _tmp_fields->GlobalLength();
            _loc_nItem = _tmp_fields->MyLength();
            setNFlds(_tmp_fields->NumVectors());

            _data = rcp(new Epetra_FEVector(*_tmp_fields));
        }
        else if(emptyReady)
        {
            _data = rcp(new Epetra_FEVector(*_map, numFlds()));

            _nItem = _data->GlobalLength();
            _loc_nItem = _data->MyLength();
        }

        UpdateDistData();
        _destroyTmpPtrs();
    }

    void FieldStruct::setNFlds(int nflds)
    {
        genDefaultTags(*this, nflds, "Field");
    }

    void FieldStruct::setNFlds(vector<string> tags)
    {
        createTags(*this, tags);
    }



    int FieldStruct::_allocGhosts()
    {
        if (numFlds() == 0)
            return 1;

        _ghostsData = rcp(new Epetra_FEVector(_ghostsImporter->TargetMap(), numFlds()));
        if (_data != null)
            _updateGhosts();

        return 0;
    }

    int FieldStruct::_updateGhosts()
    {
        // Update ghosts
        _ghostsData->Import(*_data, *_ghostsImporter, Insert);

        // Update ghosts of mirror fieldStructs
        for (auto f: _mirroredFieldStruct)
            f->_updateGhosts();

        return 0;
    }

    double FieldStruct::getValue(int dof, int idx, IndexType idxtype) const
    {
        if (idxtype == IndexType::Local)
            return (*_data)[dof][idx];
        else
        {
            if(isItemInPart(idx))
                return (*_data)[dof][locIdx(idx)];
            else if(isItemInPartGhosts(idx))
            {
                ptrdiff_t idx_ghosts = find(_ghosts.begin(), _ghosts.end(), idx) - _ghosts.begin();
                return (*_ghostsData)[dof][idx_ghosts];
            }
            else
                throw runtime_error("FieldStruct::getValue: Not Here!! \n \
                   dof: " + to_string(dof) +  "  idx: " + to_string(idx));

            return 0;
        }

    }


    void FieldStruct::_createDistribFields(double *&fields)
    {
        _data = rcp(new Epetra_FEVector(*_map, numFlds()));

        if (_myRank == 0)
        {
            for(int i = 0; i < _nItem; i++)
            {
                for(int n = 0; n < numFlds(); n++)
                    _data->ReplaceGlobalValues(1, &i, &fields[numFlds()*i+n], n);
                //FIXME: _data->ReplaceGlobalValues(1, &i, &fields[numFlds()*n+i], n);
            }
        }

        _data->GlobalAssemble();
        Barrier();
    }

    void hiperlife::FieldStruct::_setDistribFields(double*& fields, int numGhosts)
    {

        _data = rcp(new Epetra_FEVector(*_map, numFlds()));

        for(int n = 0; n < numFlds(); n++)
            for(int i = 0; i < _loc_nItem; i++)
                (*_data)[n][i] = fields[n*(_loc_nItem+numGhosts) + i];

        Barrier();
    }

    void FieldStruct::_destroyTmpPtrs()
    {
        _tmp_fields = null;

        _tmp_globFields = nullptr;
        _tmp_distFields = nullptr;

        _tmp_istream    = nullptr;
        _tmp_outputmode = OutputMode::Undefined;

    }

    double FieldStruct::norm2(int dof) const
    {
        double locNorm = 0.0;
        double gloNorm = 0.0;
        for (int i = 0; i < _loc_nItem; i++)
        {
            locNorm += (*_data)[dof][i] * (*_data)[dof][i];
        }

        MPI_Allreduce(&locNorm, &gloNorm, 1, MPI_DOUBLE, MPI_SUM, _comm);

        return sqrt(gloNorm);
    }

}
