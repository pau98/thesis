/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <fstream>
#include <stdexcept>


#include <Teuchos_RCP.hpp>

#include <Epetra_CrsGraph.h>
#include <Epetra_IntVector.h>
#include <Epetra_IntSerialDenseVector.h>
#include <Epetra_FECrsMatrix.h>


#include "hl_TypeDefs.h"
#include "hl_IO_Aux.h"
#include "hl_IntFieldStruct.h"

using namespace std;

using Teuchos::RCP;
using Teuchos::rcp;
using Teuchos::null;



namespace hiperlife
{


    void IntFieldStruct::outFullData(std::ostream& os, OutputMode mode) const
    {
        outDisData(os, mode);

        vector<int> ibuff;

        ibuff = {numFlds(), numFlds()*_loc_nItem, numFlds()*_nItem};

        IO::printData(os, ibuff.data(), ibuff.size(), mode);
        IO::printData(os, _tags.data(), _tags.size(), mode);

        for (int f = 0; f < numFlds(); f++)
            IO::printData(os, _data[f]->Values(), _loc_nItem, mode);
    }


    void IntFieldStruct::_update_disIStream()
    {
        istream& in = *_tmp_istream;
        OutputMode mode = _tmp_outputmode;
        UpdateDistData(in, mode);

        _tmp_map = _map;

        vector<int> buff(3);
        IO::fillData(buff.data(), in, 3, mode);
        auto nFlds = buff[0];
        vector<string> strBuff(nFlds);
        IO::fillData(strBuff.data(), in, nFlds, mode);
        createTags(*this, strBuff);

        if(nFlds * _loc_nItem != buff[1])
            throw runtime_error("IntFieldStruct::Update: Read local size incompatible.");

        if(nFlds * _nItem != buff[2])
            throw runtime_error("IntFieldStruct::Update: Read total size incompatible.");

        _tmp_distFields = new int[nFlds * _loc_nItem];

        IO::fillData(_tmp_distFields, in, nFlds * _loc_nItem, mode);


        _setDistribFields(_tmp_distFields);

        // This creates the ghosts infrastructure
        UpdateGhosts(_ghosts);
        // This comunicate the relevant information
        _updateGhosts();

        delete[] _tmp_distFields;
    }




    ostream& operator<<(ostream& os, const IntFieldStruct& field)
    {

        if (field.myRank() == 0)
        {
            cout << field.nameTag() << " - " << field.classTag() << endl;
            cout << "Tags:";
            for (int i = 0; i < field.numFlds(); i++)
                cout << " " << field.tag(i);
            cout << endl;
        }


        for (int p = 0; p < field.numProcs(); p++)
        {

            if (p == field.myRank())
            {
                os << "Rank: " << p << endl;


                for(int n=0; n < field.nItem(); n++)
                {


                    if (field.isItemInPart(n) or field.isItemInPartGhosts(n))
                    {
                        if (field.isItemInPart(n))
                            os << n  << " - ";
                        else if (field.isItemInPartGhosts(n))
                            os << "*" << n  << " - ";

                        for (int i = 0; i < field.numFlds(); i++)
                            os << field.getValue(i ,n, IndexType::Global) << " " ;

                        os << endl;
                    }

                }
                os << endl;
            }

            field.Barrier();
        }

        return os;
    }


}
