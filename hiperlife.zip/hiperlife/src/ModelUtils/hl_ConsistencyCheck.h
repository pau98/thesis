/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CONSCHECK_H
#define CONSCHECK_H

#include "Teuchos_RCP.hpp"

#include "hl_FillStructure.h"


namespace hiperlife
{
    template<void(*LS)(hiperlife::FillStructure&)>
    void ConsistencyCheck(hiperlife::FillStructure& fillStr)
    {
        using namespace std;
        using namespace hiperlife;

        // Jacobian of the transformation (parent element to parameter space) in BSplines and Nurbs
        SubFillStructure &subFill = fillStr[0];
        double jac = subFill._jacobianParentElementToParameterSpace(subFill.loc_elemID);

        // Initialize
        int nDofHand = fillStr.numDOFsHands();

        // Get parameters of the consistency check
        ConsistencyCheckType ccType = fillStr._consCheckType;
        double tol   = fillStr._consCheckTol / jac;
        double delta = fillStr._consCheckDelta;

        // Get dofshandlers and DOFs to be analyzed
        vector<int> consDOFsHandlers = fillStr._consDOFsHandlers;
        vector<vector<int>> consDOFs = fillStr._consDOFs;

        // Save global integrals
        vector<double> savedGI(fillStr._globInteg.size());
        for (size_t i = 0; i < fillStr._globInteg.size(); i++)
            savedGI[i] = fillStr._globInteg[i];

        // Consistency check of the Jacobian
        if (ccType == ConsistencyCheckType::Jacobian or ccType == ConsistencyCheckType::Both)
        {
            // Pointer to energy
            double& Ek = fillStr._globInteg[fillStr._consCheckGlobInteg];

            // Loop over DOFsHandlers
            for (auto N: consDOFsHandlers)
            {
                // Initialize
                SubFillStructure &subFill_N = fillStr[N];
                int eNN_N = subFill_N.eNN;
                int numDOFs_N = subFill_N.numDOFs;
                double wk = subFill_N.wk_sample;

                // Fill linear system
                LS(fillStr);

                // Save RHS
                vector<double> Bk_N = fillStr.Bk(N);
                vector<double> Bk_N_num(Bk_N.size(), 0.0);
                vector<double>& nborDOFs_N = subFill_N.nborDOFs;
                for (int i = 0; i < eNN_N; i++)
                {
                    for (int n = 0; n < numDOFs_N; n++)
                    {
                        // delta +
                        nborDOFs_N[numDOFs_N*i+n] += delta;
                        Ek = 0.0;
                        LS(fillStr);
                        Bk_N_num[numDOFs_N * i + n] = Ek;

                        // delta -
                        nborDOFs_N[numDOFs_N*i+n] -= 2.0 * delta;
                        Ek = 0.0;
                        LS(fillStr);
                        Bk_N_num[numDOFs_N * i + n] -= Ek;

                        // 2*delta
                        Bk_N_num[numDOFs_N * i + n] /= (2.0*delta * jac * wk);

                        // Restore delta
                        nborDOFs_N[numDOFs_N*i+n] += delta;
                    }
                }

                // Compute error
                for (int i = 0; i < eNN_N; i++)
                {
                    for (auto n: consDOFs[N])
                    {
                        double B_N_I     = Bk_N[numDOFs_N*i+n];
                        double B_N_I_num = Bk_N_num[numDOFs_N*i+n];
                        if (abs(B_N_I-B_N_I_num) > tol)
                        {
                            cout << "ConsistencyCheck::Jacobian: ERROR in mesh element ";
                            cout << subFill_N.elemID;
                            cout << " at vector element [dofHand1=" << N << "](node1=" << i << ", dof1=" << n << ").";
                            cout << std::scientific << std::setprecision(16) << endl;
                            cout << "   Vector value: " << B_N_I << ". Finite differences value: " << B_N_I_num << endl;
                        }
                    }
                }

                // Initialize Bk and Ak to zeros
                for (int K = 0; K < nDofHand; K++)
                {
                    std::fill(fillStr.Bk(K).begin(),fillStr.Bk(K).end(),0.0);

                    for (int L = 0; L < nDofHand; L++)
                        std::fill(fillStr.Ak(K, L).begin(),fillStr.Ak(K, L).end(),0.0);
                }
            }
        }

        // Consistency check for Hessian
        if (ccType == ConsistencyCheckType::Hessian or ccType == ConsistencyCheckType::Both)
        {
            for (int N = 0; N < nDofHand; N++)
            {
                SubFillStructure &subFill_N = fillStr[N];
                int eNN_N = subFill_N.eNN;
                int numDOFs_N = subFill_N.numDOFs;

                for (int M = 0; M < nDofHand; M++)
                {
                    SubFillStructure &subFill_M = fillStr[M];
                    int eNN_M = subFill_M.eNN;
                    int numDOFs_M = subFill_M.numDOFs;
                    int sizeRow = eNN_M * numDOFs_M;

                    LS(fillStr);
                    vector<double>  Ak_NM;
                    vector<double>& Bk_N = fillStr.Bk(N);

                    Ak_NM = fillStr.Ak(N, M);
                    vector<double>  Ak_NM_num(Ak_NM.size(),0.0);

                    vector<double>& nborDOFs_M = subFill_M.nborDOFs;

                    for (int j = 0; j < eNN_M; j++)
                    {
                        for (int m = 0; m < numDOFs_M; m++)
                        {
                            nborDOFs_M[numDOFs_M*j+m] += delta;

                            std::fill(Bk_N.begin(),Bk_N.end(),0.0);
                            LS(fillStr);

                            for (int i = 0; i < eNN_N; i++)
                                for (int n = 0; n < numDOFs_N; n++)
                                    Ak_NM_num[(i * numDOFs_N + n) * sizeRow + j * numDOFs_M + m] = Bk_N[numDOFs_N * i + n];

                            nborDOFs_M[numDOFs_M*j+m] -= 2.0 * delta;

                            std::fill(Bk_N.begin(),Bk_N.end(),0.0);
                            LS(fillStr);

                            for (int i = 0; i < eNN_N; i++)
                            {
                                for (int n = 0; n < numDOFs_N; n++)
                                {
                                    Ak_NM_num[(i * numDOFs_N + n) * sizeRow + j * numDOFs_M + m] -= Bk_N[numDOFs_N * i + n];
                                    Ak_NM_num[(i * numDOFs_N + n) * sizeRow + j * numDOFs_M + m] /= (2.0 * delta);
                                }
                            }

                            nborDOFs_M[numDOFs_M*j+m] += delta;
                        }
                    }

                    // Compute error
                    for (int i = 0; i < eNN_N; i++)
                    {
                        for (int n = 0; n < numDOFs_N; n++)
                        {
                            for (int j = 0; j < eNN_M; j++)
                            {
                                for (int m = 0; m < numDOFs_M; m++)
                                {
                                    double A_NM_IJ_NM = Ak_NM[(i*numDOFs_N+n)*sizeRow + j*numDOFs_M+m];
                                    double A_NM_IJ_NM_num = Ak_NM_num[(i*numDOFs_N+n)*sizeRow + j*numDOFs_M+m];
                                    if (abs(A_NM_IJ_NM-A_NM_IJ_NM_num) > tol)
                                    {
                                        cout << "ConsistencyCheck::Hessian: ERROR in mesh element ";
                                        cout << subFill_N.elemID;
                                        cout << " at matrix element [dofHand1=" << N << ", dofHand2=" << M << "](node1=" << i << ", dof1=" << n << ", node2=" << j << ", dof2=" << m << ").";
                                        cout << std::scientific << std::setprecision(16) << endl;
                                        cout << "   Matrix value: " << A_NM_IJ_NM << ". Finite differences value: " << A_NM_IJ_NM_num << endl;
                                    }
                                }
                            }
                        }
                    }

                    // Initialize Bk and Ak to zeros
                    for (int K = 0; K < nDofHand; K++)
                    {
                        std::fill(fillStr.Bk(K).begin(),fillStr.Bk(K).end(),0.0);

                        for (int L = 0; L < nDofHand; L++)
                            std::fill(fillStr.Ak(K, L).begin(),fillStr.Ak(K, L).end(),0.0);
                    }
                }
            }
        }

        // Restore global integrals
        for (size_t i = 0; i < fillStr._globInteg.size(); i++)
            fillStr._globInteg[i] = savedGI[i];

        // Fill the linear system to get the correct filling
        LS(fillStr);
    }
}

#endif //CONSCHECK_H
