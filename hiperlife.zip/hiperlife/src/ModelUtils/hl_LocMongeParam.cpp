/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_LocMongeParam.h"
#include "hl_SurfLagrParam.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{
    namespace LocMongeParam
    {
        void computeLocal3DBasis(RCP<DistributedMesh> mesh, RCP<FieldStruct> field)
        {
            int loc_nPts = mesh->loc_nPts();
            auto adjcyEN = mesh->_adjcyEN;

            if (mesh->_basisFunctions->orderDers() >= 2)
            {
                for (int i = 0; i < loc_nPts; i++)
                {

                double g1e[3]={};
                double g2e[3]={};
                double normal[3]={};


                    int ii = i + mesh->_nodeData->offs_nItem();

                    vector<int> nbors = vector<int>(mesh->_adjcyNE->getNborList(i, IndexType::Local));

                    int elem = -1;

                        for (auto ee: nbors)
                        {
                            if (adjcyEN->isItemInPart(ee))
                            {
                                elem = ee;
                                break;
                            }
                        }


                    int eNN = adjcyEN->getNumNbors(elem, IndexType::Global);

                    std::vector<double> xe_nodes;
                    xe_nodes.resize(0);
                    for (int j = 0; j < eNN; j++)
                    {
                        int jj = adjcyEN->getNbor(elem, j, IndexType::Global);

                        xe_nodes.push_back(mesh->nodeCoord(jj, 0));
                        xe_nodes.push_back(mesh->nodeCoord(jj, 1));
                        xe_nodes.push_back(mesh->nodeCoord(jj, 2));

                    }


                    vector<double> xi_samples = {0.0, 0.0};

                    if (ii == mesh->_connec->getNbor(elem, 1))
                        xi_samples[0] = 1.0;
                    else if (ii == mesh->_connec->getNbor(elem, 2))
                        xi_samples[1] = 1.0;

                    vector<vector<double>> BF;
                    BF.resize(3);
                    mesh->_basisFunctions->computeBasisFunctionsReference(BF, xi_samples, mesh->_basisFunctions->getTag(elem,IndexType::Global));


                    double Ip[4];
                    SurfLagrParam::Normal(normal,Ip,g1e,g2e,eNN,xe_nodes.data(),BF[1].data());

                    if(mesh->nodeCrease(i,IndexType::Local)>0)
                    {
                        Math::AXPY(g1e,3,-1.0,g2e);
                    }

                    Math::AX(g1e, 3, 1.0 / Math::Norm3D(g1e));
                    Math::AXPY(g2e, 3, -Math::Dot3D(g2e, g1e), g1e);
                    Math::AX(g2e, 3, 1.0 / Math::Norm3D(g2e));

                    for (int n = 0; n < 3; n++)
                    {
                        field->setValue(0 + n, i, IndexType::Local, g1e[n]);
                        field->setValue(3 + n, i, IndexType::Local, g2e[n]);
                        field->setValue(6 + n, i, IndexType::Local, normal[n]);
                    }
                }
            }
            else
            {
                auto connec = mesh->_connec;
                vector<double> xe_nodes;

                int loc_nElem = mesh->loc_nElem();

                Epetra_Map vec_map(-1, mesh->loc_nPts()*3, 0, mesh->epComm());
                Teuchos::RCP<Epetra_FEVector> sol = rcp(new Epetra_FEVector(vec_map));

                sol->PutScalar(0.0);
                for (int e = 0; e < loc_nElem; e++)
                {
                    int n0e = mesh->_connec->getNbor(e, 0, IndexType::Local);
                    int n1e = mesh->_connec->getNbor(e, 1, IndexType::Local);
                    int n2e = mesh->_connec->getNbor(e, 2, IndexType::Local);

                    vector<double> x0e = mesh->nodeCoords(n0e);
                    vector<double> x1e = mesh->nodeCoords(n1e);
                    vector<double> x2e = mesh->nodeCoords(n2e);

                    double g1e[3]={};
                    double g2e[3]={};
                    double normal[3]={};

                    Array::Copy(g1e, 3, x1e.data());
                    Math::AXPY(g1e, 3, -1.0, x0e.data());
                    Array::Copy(g2e, 3, x2e.data());
                    Math::AXPY(g2e, 3, -1.0, x0e.data());

                    Math::Cross(normal, g1e, g2e);
                    Math::AX(normal,3,1.0/Math::Norm3D(normal));

                    for ( int k = 0; k < 3; k++ )
                    {
                        int n = connec->getNbor(e,k,IndexType::Local);

                        for (int l = 0; l < 3; l++)
                        {
                            int nl = 3 * n + l;
                            sol->SumIntoGlobalValues(1, &nl, &normal[l]);
                        }
                    }
                }

                sol->GlobalAssemble();

                for (int i = 0; i < loc_nPts; i++)
                {
                    double g1e[3] = {};
                    double g2e[3] = {};
                    double normal[3] = {};

                    int e = -1;
                    vector<int> &nbors = mesh->_adjcyNE->getNborList(i, IndexType::Local);

                    for (auto ee: nbors)
                    {
                        if (mesh->_connec->isItemInPart(ee))
                        {
                            e = ee;
                            break;
                        }
                    }

                    int n0e = mesh->_connec->getNbor(e, 0, IndexType::Global);
                    int n1e = mesh->_connec->getNbor(e, 1, IndexType::Global);
                    int n2e = mesh->_connec->getNbor(e, 2, IndexType::Global);

                    vector<double> x0e = mesh->nodeCoords(n0e);
                    vector<double> x1e = mesh->nodeCoords(n1e);
                    vector<double> x2e = mesh->nodeCoords(n2e);

                    Array::Copy(g1e, 3, x1e.data());
                    Math::AXPY(g1e, 3, -1.0, x0e.data());
                    Array::Copy(g2e, 3, x2e.data());
                    Math::AXPY(g2e, 3, -1.0, x0e.data());

                    Array::Copy(normal, 3, &(*sol)[0][3 * i]);
                    Math::AX(normal, 3, 1.0 / Math::Norm3D(normal));

                    Math::AXPY(g1e, 3, -Math::Dot3D(g1e, normal), g1e);
                    Math::AX(g1e, 3, 1.0 / Math::Norm3D(g1e));

                    Math::AXPY(g2e, 3, -Math::Dot3D(g2e, normal), g2e);
                    Math::AXPY(g2e, 3, -Math::Dot3D(g2e, g1e), g1e);
                    Math::AX(g2e, 3, 1.0 / Math::Norm3D(g2e));

                    Math::Cross(normal, g1e, g2e);


                    for (int n = 0; n < 3; n++)
                    {
                        field->setValue(0 + n, i, IndexType::Local, g1e[n]);
                        field->setValue(3 + n, i, IndexType::Local, g2e[n]);
                        field->setValue(6 + n, i, IndexType::Local, normal[n]);
                    }

                }
            }

            field->UpdateGhosts();
        }



    }
}
