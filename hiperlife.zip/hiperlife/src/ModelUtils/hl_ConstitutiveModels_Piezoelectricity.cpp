/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_ConstitutiveModels_Piezoelectricity.h"

namespace hiperlife
{
    namespace ConstitutiveModels
    {
        namespace Piezoelectricity
        {
            void dielectricTensor(tensor<double, 2> &K, const double kappa_L, const int pDim)
            {
                // Reset to zero
                K(all, all) = 0.0;

                // Fill tensor<double,6,false> H (nDim , nDim , nDim , nDim , nDim , nDim);
                for (int i = 0; i < pDim; ++i)
                    K(i, i) = kappa_L;
            }

            void dielectricTensor(std::vector<double> &K, const double kappa_L, const int pDim)
            {
                K.resize(pDim * pDim);
                for (int i = 0; i < pDim; ++i)
                    K[i * 2 + i] = kappa_L;
            }

            void piezoelectricTensor(tensor<double, 3> &E, const double piezo_L, const double piezo_T, const double piezo_S, const int pDim)
            {
                // Reset to zero
                E(all, all, all) = 0.0;

                // Fill tensor<double,3,false> E (nDim , nDim);
                E(0, 0, 0) = piezo_L;
                for (int i = 1; i < pDim; ++i)
                {
                    E(0, i, i) = piezo_T;
                    E(i, 0, i) = piezo_S;
                    E(i, i, 0) = piezo_S;
                }
                /// FIXME: Need to implement rotation!
            }

            void piezoelectricTensor(std::vector<double> &E, const double piezo_L, const double piezo_T, const double piezo_S, const int pDim)
            {
                E.resize(pDim * pDim * pDim);
                E[0 * 4 + 0 * 2 + 0] = piezo_L;
                for (int i = 1; i < pDim; ++i)
                {
                    E[0 * 4 + i * 2 + i] = piezo_T;
                    E[i * 4 + 0 * 2 + i] = piezo_S;
                    E[i * 4 + i * 2 + 0] = piezo_S;
                }
            }

            void electricFieldTensor(tensor<double, 2> &eField, tensor<double, 2> globDBF, const int pDim)
            {
                eField(all, all) = 0.0;
                for (int i = 0; i < pDim; ++i)
                    eField(i, all) = -globDBF(all, i);
            }

            void gradElectricField(tensor<double, 3> &gradEfield, tensor<double, 3> globHBF, const int pDim)
            {
                gradEfield(all, all, all) = 0.0;
                for (int i = 0; i < pDim; i++)
                    for (int j = 0; j < pDim; j++)
                        gradEfield(i, j, all) = -globHBF(all, i, j);
            }

            void hessElectricField(tensor<double, 4> &hessEField, tensor<double, 4> golbTBF, const int pDim)
            {
                hessEField(all, all, all, all) = 0.0;
                for (int i = 0; i < pDim; i++)
                    for (int j = 0; j < pDim; j++)
                        for (int k = 0; k < pDim; k++)
                            hessEField(i, j, k, all) = -golbTBF(all, i, j, k);
            }

        } // namespace Piezoelectricity
    }     // namespace ConstitutiveModels
} // namespace hiperlife
