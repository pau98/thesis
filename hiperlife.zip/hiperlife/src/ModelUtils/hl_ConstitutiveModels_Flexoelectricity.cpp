/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_ConstitutiveModels_Flexoelectricity.h"

namespace hiperlife
{
    namespace ConstitutiveModels
    {
        namespace Flexoelectricity
        {
            void flexoelectricityTensor(tensor<double, 4> &Mu, const double flexo_L, const double flexo_T, const double flexo_S, const int pDim)
            {
                // Reset to zero
                Mu(all, all, all, all) = 0.0;

                // Fill tensor<double,4,false> Mu (pDim , pDim , pDim , pDim);
                for (int i = 0; i < pDim; ++i)
                {
                    Mu(i, i, i, i) = flexo_L;
                    for (int j = 0; j < pDim; ++j)
                    {
                        if (i != j)
                        {
                            Mu(i, j, j, i) = flexo_T;
                            Mu(i, i, j, j) = flexo_S;
                            Mu(i, j, i, j) = flexo_S;
                        }
                    }
                }
                /// FIXME: Need to implement rotation!
            }

            void flexoelectricityTensor(std::vector<double> &Mu, const double flexo_L, const double flexo_T, const double flexo_S, const int pDim)
            {
                Mu.resize(pDim * pDim * pDim * pDim);
                for (int i = 0; i < pDim; ++i)
                {
                    Mu[i * 8 + i * 4 + i * 2 + i] = flexo_L;
                    for (int j = 0; j < pDim; ++j)
                    {
                        if (i != j)
                        {
                            Mu[i * 8 + j * 4 + j * 2 + i] = flexo_T;
                            Mu[i * 8 + i * 4 + j * 2 + j] = flexo_S;
                            Mu[i * 8 + j * 4 + i * 2 + j] = flexo_S;
                        }
                    }
                }
            }

            void gradDielectricity(tensor<double, 4> &M, const double kappa_L, const double lElec, const int pDim)
            {
                // Reset to zero
                M(all, all, all, all) = 0.0;

                // Fill tensor<double,4,false> M (pDim , pDim , pDim , pDim);
                for (int i = 0; i < pDim; i++)
                    for (int j = 0; j < pDim; j++)
                        M(i, j, i, j) = lElec * lElec * kappa_L;
            }

            void gradDielectricity(std::vector<double> &M, const double kappa_L, const double lElec, const int pDim)
            {
                M.resize(pDim * pDim * pDim * pDim);
                for (int i = 0; i < pDim; i++)
                    for (int j = 0; j < pDim; j++)
                        M[i * 8 + j * 4 + i * 2 + j] = lElec * lElec * kappa_L;
            }

            namespace Direct
            {
                void stress(tensor<double, 4> &sigHat, tensor<double, 4> C, tensor<double, 4> strain, tensor<double, 3> E, tensor<double, 2> eField, const int numDOFs, const int pDim)
                {
                    sigHat(all, all, all, all) = 0.0;
                    // Stress_ijQR = C_ijkl Strain_klQR - E_lij EField_lR
                    for (int i = 0; i < pDim; ++i)
                        sigHat(all, all, i, all) += product(C, strain(all, all, i, all), {{2, 0}, {3, 1}});
                    sigHat(all, all, numDOFs - 1, all) -= product(E, eField, {{0, 0}});
                }

                void doubleStress(tensor<double, 5> &sigTilde, tensor<double, 6> H, tensor<double, 5> gradStrain, tensor<double, 2> eField, tensor<double, 4> Mu, const int numDOFs, const int pDim)
                {
                    sigTilde(all, all, all, all, all) = 0.0;
                    // sigTilde Tensor: H_ijklmn GradStrain_lm,nQR - Mu_lijk EField_lR
                    for (int i = 0; i < pDim; ++i)
                        sigTilde(all, all, all, i, all) += product(H, gradStrain(all, all, all, i, all), {{3, 0}, {4, 1}, {5, 2}});
                    sigTilde(all, all, all, numDOFs - 1, all) -= product(Mu, eField, {{0, 0}});
                }

                void gradDoubleStress(tensor<double, 6> &gradSigTilde, tensor<double, 6> H, tensor<double, 6> hessStrain, tensor<double, 4> Mu, tensor<double, 3> gradEField, const int numDOFs, const int pDim)
                {
                    gradSigTilde(all, all, all, all, all, all) = 0.0;
                    // gradSigTilde tensor: sigmaTilde_ijk,pQR = h_ijklmn * eps_lm,npQR -  mu_lijk E_l,pR
                    for (int i = 0; i < pDim; ++i)
                        gradSigTilde(all, all, all, all, i, all) += product(H, hessStrain(all, all, all, all, i, all), {{3, 0}, {4, 1}, {5, 2}});
                    gradSigTilde(all, all, all, all, numDOFs - 1, all) -= product(Mu, gradEField, {{0, 0}});
                }

                void electricDisplacement(tensor<double, 3> &DHat, tensor<double, 2> eField, tensor<double, 4> strain, tensor<double, 5> gradStrain, tensor<double, 4> Mu, tensor<double, 2> K, tensor<double, 3> E, const int numDOFs, const int pDim)
                {
                    DHat(all, all, all) = 0.0;
                    DHat(all, numDOFs - 1, all) += product(K, eField, {{1, 0}}); //K_lm Efield_mR
                    for (int i = 0; i < pDim; ++i)
                    {
                        DHat(all, i, all) += product(E, strain(all, all, i, all), {{1, 0}, {2, 1}});                   // E_lij Strain_ijQR
                        DHat(all, i, all) += product(Mu, gradStrain(all, all, all, i, all), {{1, 0}, {2, 1}, {3, 2}}); // Mu_lijk GradStrain_ij,kQR
                    }
                }

                void doubleElectricDisplacement(tensor<double, 4> &DTilde, tensor<double, 3> gradEField, tensor<double, 4> strain, tensor<double, 4> G, tensor<double, 4> Mu, const int numDOFs, const int pDim)
                {
                    DTilde(all, all, all, all) = 0.0;
                    // ElecDisp_lQR = K_lm Efield_mR + E_lij Strain_ijQR + 0.5 Mu_lijk GradStrain_ij,kQR
                    DTilde(all, all, numDOFs - 1, all) += product(G, gradEField, {{0, 0}, {1, 1}}); // G_ijlk GradEfield_i,jR
                    for (int Q = 0; Q < pDim; Q++)
                        DTilde(all, all, Q, all) += -0.5 * product(Mu, strain(all, all, Q, all), {{1, 0}, {2, 1}});
                }

                void traction(tensor<double, 3> &Ti, tensor<double, 4> sigHat, tensor<double, 5> sigTilde, tensor<double, 6> gradSigTilde, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim)
                {
                    Ti(all, all, all) = 0.0;
                    // Traction_iQR: (Stress_ijQR - GradDoubleStress_ijk,kQR - GradDoubleStress_ikj,lQR * PMat_lk) * normal_j + DoubleStress_ijkQR NMat_jk
                    for (int j = 0; j < pDim; ++j)
                    {
                        Ti(all, all, all) += sigHat(all, j, all, all) * normal[j]; // Stress_ijQR * normal_j
                        for (int k = 0; k < pDim; ++k)
                        {
                            Ti(all, all, all) -= gradSigTilde(all, j, k, k, all, all) * normal[j]; // - GradDoubleStress_ijk,kQR * normal_j
                            for (int l = 0; l < pDim; ++l)
                                Ti(all, all, all) -= gradSigTilde(all, k, j, l, all, all) * PMat(l, k) * normal[j]; // - GradDoubleStress_ikj,lQR * PMat_lk * normal_j
                            Ti(all, all, all) += sigTilde(all, j, k, all, all) * NMat(j, k);                        // DoubleStress_ijk NMat_jk
                        }
                    }
                }

                void doubleTraction(tensor<double, 3> &ri, tensor<double, 5> sigTilde, const double normal[], const int pDim)
                {
                    ri(all, all, all) = 0.0;
                    // ri: DoubleStress_ijkQR normal_j normal_k
                    for (int j = 0; j < pDim; ++j)
                        for (int k = 0; k < pDim; ++k)
                            ri(all, all, all) += sigTilde(all, j, k, all, all) * normal[j] * normal[k];
                }

                void surfaceChargeDensity(tensor<double, 2> &W, tensor<double, 3> DHat, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim)
                {
                    (void) PMat;
                    (void) NMat;

                    W(all, all) = 0.0;
                    for (int l = 0; l < pDim; ++l)
                        W(all, all) -= DHat(l, all, all) * normal[l];
                }
            } // namespace Direct

            namespace Lifshitz
            {
                void stress(tensor<double, 4> &sigHat, tensor<double, 4> C, tensor<double, 4> strain, tensor<double, 3> E, tensor<double, 2> eField, tensor<double, 4> Mu, tensor<double, 3> gradEField, const int numDOFs, const int pDim)
                {
                    sigHat(all, all, all, all) = 0.0;
                    // Stress_ijQR = C_ijkl Strain_klQR - E_lij EField_lR + 0.5 mu_lijk GradEField_l,kR
                    for (int i = 0; i < pDim; ++i)
                        sigHat(all, all, i, all) += product(C, strain(all, all, i, all), {{2, 0}, {3, 1}});
                    sigHat(all, all, numDOFs - 1, all) += -product(E, eField, {{0, 0}});
                    sigHat(all, all, numDOFs - 1, all) += 0.5 * product(Mu, gradEField, {{0, 0}, {3, 1}});
                }

                void doubleStress(tensor<double, 5> &sigTilde, tensor<double, 6> H, tensor<double, 5> gradStrain, tensor<double, 2> eField, tensor<double, 4> Mu, const int numDOFs, const int pDim)
                {
                    sigTilde(all, all, all, all, all) = 0.0;
                    // sigTilde Tensor: H_ijklmn GradStrain_lm,nQR - 0.5 Mu_lijk EField_lR
                    for (int i = 0; i < pDim; ++i)
                        sigTilde(all, all, all, i, all) += product(H, gradStrain(all, all, all, i, all), {{3, 0}, {4, 1}, {5, 2}});
                    sigTilde(all, all, all, numDOFs - 1, all) += -0.5 * product(Mu, eField, {{0, 0}});
                }

                void gradDoubleStress(tensor<double, 6> &gradSigTilde, tensor<double, 6> H, tensor<double, 6> hessStrain, tensor<double, 4> Mu, tensor<double, 3> gradEField, const int numDOFs, const int pDim)
                {
                    gradSigTilde(all, all, all, all, all, all) = 0.0;
                    // gradSigTilde tensor: sigmaTilde_ijk,pQR = h_ijklmn * eps_lm,npQR - 0.5 * mu_lijk E_l,pR
                    for (int i = 0; i < pDim; ++i)
                        gradSigTilde(all, all, all, all, i, all) += product(H, hessStrain(all, all, all, all, i, all), {{3, 0}, {4, 1}, {5, 2}});
                    gradSigTilde(all, all, all, all, numDOFs - 1, all) += -0.5 * product(Mu, gradEField, {{0, 0}});
                }

                void electricDisplacement(tensor<double, 3> &DHat, tensor<double, 2> eField, tensor<double, 4> strain, tensor<double, 5> gradStrain, tensor<double, 4> Mu, tensor<double, 2> K, tensor<double, 3> E, const int numDOFs, const int pDim)
                {
                    DHat(all, all, all) = 0.0;
                    DHat(all, numDOFs - 1, all) += product(K, eField, {{1, 0}}); //K_lm Efield_mR
                    for (int i = 0; i < pDim; ++i)
                    {
                        DHat(all, i, all) += product(E, strain(all, all, i, all), {{1, 0}, {2, 1}});                         //E_lij Strain_ijQR
                        DHat(all, i, all) += 0.5 * product(Mu, gradStrain(all, all, all, i, all), {{1, 0}, {2, 1}, {3, 2}}); //0.5 Mu_lijk GradStrain_ij,kQR
                    }
                }

                void doubleElectricDisplacement(tensor<double, 4> &DTilde, tensor<double, 3> gradEField, tensor<double, 4> strain, tensor<double, 4> G, tensor<double, 4> Mu, const int numDOFs, const int pDim)
                {
                    DTilde(all, all, all, all) = 0.0;
                    // ElecDisp_lQR = K_lm Efield_mR + E_lij Strain_ijQR + 0.5 Mu_lijk GradStrain_ij,kQR
                    DTilde(all, all, numDOFs - 1, all) += product(G, gradEField, {{0, 0}, {1, 1}}); // G_ijlk GradEfield_i,jR
                    for (int Q = 0; Q < pDim; Q++)
                        DTilde(all, all, Q, all) += -0.5 * product(Mu, strain(all, all, Q, all), {{1, 0}, {2, 1}});
                }

                void gradDoubleElectricDisplacement(tensor<double, 5> &gradDTilde, tensor<double, 5> gradStrain, tensor<double, 4> hessEField, tensor<double, 4> G, tensor<double, 4> Mu, const int numDOFs, const int pDim)
                {
                    gradDTilde(all, all, all, all, all) = 0.0;
                    // Gradient of Double Electric Displacement: GradDTilde_lkpQR = G_ijlk HessEfield_i,jpR - 0.5 Mu_lijk GradStrain_ijpQR
                    gradDTilde(all, all, all, numDOFs - 1, all) += product(G, hessEField, {{0, 0}, {1, 1}});
                    for (int Q = 0; Q < pDim; Q++)
                        gradDTilde(all, all, all, Q, all) -= 0.5 * product(Mu, gradStrain(all, all, all, Q, all), {{1, 0}, {2, 1}});
                }

                void traction(tensor<double, 3> &Ti, tensor<double, 4> sigHat, tensor<double, 5> sigTilde, tensor<double, 6> gradSigTilde, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim)
                {
                    Ti(all, all, all) = 0.0;
                    // Traction_iQR: (Stress_ijQR - GradDoubleStress_ijk,kQR - GradDoubleStress_ikj,lQR * PMat_lk) * normal_j + DoubleStress_ijk NMat_jk
                    for (int j = 0; j < pDim; ++j)
                    {
                        Ti(all, all, all) += sigHat(all, j, all, all) * normal[j]; // Stress_ijQR * normal_j
                        for (int k = 0; k < pDim; ++k)
                        {
                            Ti(all, all, all) -= gradSigTilde(all, j, k, k, all, all) * normal[j]; // - GradDoubleStress_ijk,kQR * normal_j
                            for (int l = 0; l < pDim; ++l)
                                Ti(all, all, all) -= gradSigTilde(all, k, j, l, all, all) * PMat(l, k) * normal[j]; // - GradDoubleStress_ikj,lQR * PMat_lk * normal_j
                            Ti(all, all, all) += sigTilde(all, j, k, all, all) * NMat(j, k);                        // DoubleStress_ijk NMat_jk
                        }
                    }
                }

                void doubleTraction(tensor<double, 3> &ri, tensor<double, 5> sigTilde, const double normal[], const int pDim)
                {
                    ri(all, all, all) = 0.0;
                    // ri: DoubleStress_ijkQR normal_j normal_k
                    for (int j = 0; j < pDim; ++j)
                        for (int k = 0; k < pDim; ++k)
                            ri(all, all, all) += sigTilde(all, j, k, all, all) * normal[j] * normal[k];
                }

                void surfaceChargeDensity(tensor<double, 2> &W, tensor<double, 3> DHat, tensor<double, 4> DTilde, tensor<double, 5> gradDTilde, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim)
                {
                    W(all, all) = 0.0;
                    // w_QR = (-DHat_lQR + GradDTilde_lk,kQR + GradDoubleElecDisp_kl,mQR Pmat_mk) normal_l - DoubleElecDisp_lkQR Nmat_lk
                    for (int l = 0; l < pDim; l++)
                    {
                        W(all, all) -= DHat(l, all, all) * normal[l]; // - DHat_lQR * normal_l
                        for (int k = 0; k < pDim; k++)
                        {
                            W(all, all) += gradDTilde(l, k, k, all, all) * normal[l]; // + GradDoubleElecDisp_lk,kQR * normal_l
                            for (int m = 0; m < pDim; m++)                            // + GradDoubleElecDisp_kl,mQR Pmat_mk * normal_l
                                W(all, all) += gradDTilde(k, l, m, all, all) * PMat(m, k) * normal[l];
                            W(all, all) -= DTilde(l, k, all, all) * NMat(l, k); // - DoubleElecDisp_lkQR Nmat_lk
                        }
                    }
                }

                void doubleSurfaceChargeDensity(tensor<double, 2> &Tau, tensor<double, 4> DTilde, const double normal[], const int pDim)
                {
                    Tau(all, all) = 0.0;
                    // tau_QR = -DoubleElecDisp_jkQR n_j n_k
                    for (int i = 0; i < pDim; i++)
                        for (int j = 0; j < pDim; j++)
                            Tau(all, all) += -DTilde(i, j, all, all) * normal[i] * normal[j];
                }

            } // namespace Lifshitz
        }     // namespace Flexoelectricity
    }         // namespace ConstitutiveModels
} // namespace hiperlife
