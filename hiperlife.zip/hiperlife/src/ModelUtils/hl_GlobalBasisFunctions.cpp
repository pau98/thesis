/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Manyer
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "Teuchos_RCP.hpp"

#include "hl_GlobalBasisFunctions.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{
    namespace GlobalBasisFunctions
    {
        void _deformationGradient(double *G, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl)
        {
            // This function computes the derivative of global coordinate WRT local coordinate of reference element
            Array::Fill(G, pDim*pDim, 0.0);
            for (int i = 0; i < eNN; i++)
            {
                for (int dI = 0; dI < pDim; dI++)
                {
                    for (int dJ = 0; dJ < pDim; dJ++)
                    {
                        G[dI*pDim+dJ] += x_nodes[nDim*i+dI] * shgradl[pDim*i+dJ];
                    }
                }
            }

            return;
        }

        void _inverseOfDeformationGradient(double *iG, double &jac, int pDim, double *G)
        {
            if (pDim == 1)
            {
                iG[0] = 1.0 / G[0];
                jac = G[0];
            }
            else if (pDim == 2)
            {
                Math::Invert2x2(iG, G);
                jac = Math::DetMat2x2(G);
            }
            else if (pDim == 3)
            {
                Math::Invert3x3(iG, G);
                jac = Math::DetMat3x3(G);
            }
            else
            {
                throw std::runtime_error("GlobalBasisFunctions::_inverseOfDeformationGradient: pDim has to be 1, 2 or 3.");
            }

            return;
        }

        void _inverseOfDeformationGradient(double *iG, double &jac, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl)
        {
            //Compute deformation gradient
            vector<double> G(pDim*pDim);
            _deformationGradient(G.data(), eNN, pDim, nDim, x_nodes, shgradl);

            //Compute inverse and jacobian
            _inverseOfDeformationGradient(iG, jac, pDim, G.data());

            return;
        }

        void _deformationHessian(double *H, int eNN, int pDim, int nDim, double *x_nodes, double *shhessl)
        {
            Array::Fill(H, pDim*pDim*pDim, 0.0);
            for (int i = 0; i < eNN; i++)
            {
                for (int dI = 0; dI < pDim; dI++)
                {
                    for (int dJ = 0; dJ < pDim; dJ++)
                    {
                        for (int dK = 0; dK < pDim; dK++)
                        {
                            H[dI*pDim*pDim+dJ*pDim+dK] += x_nodes[nDim*i+dI] * shhessl[pDim*pDim*i+pDim*dJ+dK];
                        }
                    }
                }
            }

            return;
        }

        void _deformationThirdDerivs(double *T, int eNN, int pDim, int nDim, double *x_nodes, double *shthirdl)
        {
            Array::Fill(T, pDim*pDim*pDim*pDim, 0.0);
            for (int i = 0; i < eNN; i++)
            {
                for (int dI = 0; dI < pDim; dI++)
                {
                    for (int dJ = 0; dJ < pDim; dJ++)
                    {
                        for (int dK = 0; dK < pDim; dK++)
                        {
                            for (int dL = 0; dL < pDim; dL++)
                            {
                                T[dI*pDim*pDim*pDim+dJ*pDim*pDim+dK*pDim+dL] += x_nodes[nDim*i+dI] * shthirdl[pDim*pDim*pDim*i+pDim*pDim*dJ+pDim*dK+dL];
                            }
                        }
                    }
                }
            }

            return;
        }

        void _jacobian(double &jac, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl)
        {
            // Compute inverse of the deformation gradient and jacobian
            vector<double> iG(pDim*pDim);
            _inverseOfDeformationGradient(iG.data(), jac, eNN, pDim, nDim, x_nodes, shgradl);

            return;
        }

        void _gradients(double *shgrad, int eNN, int pDim, double *iG, double *shgradl)
        {
            //Compute global gradient
            Array::Fill(shgrad, eNN*pDim, 0.0);
            for (int i = 0; i < eNN; i++)
            {
                for (int dI = 0; dI < pDim; dI++)
                {
                    for (int dJ = 0; dJ < pDim; dJ++)
                    {
                        shgrad[pDim*i+dI] += shgradl[pDim*i+dJ] * iG[pDim*dJ+dI];
                    }
                }
            }

            return;
        }

        void _gradients(double *shgrad, double &jac, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl)
        {
            //Compute inverse of the deformation gradient and jacobian
            vector<double> iG(pDim*pDim);
            _inverseOfDeformationGradient(iG.data(), jac, eNN, pDim, nDim, x_nodes, shgradl);

            //Compute basis function gradient
            _gradients(shgrad, eNN, pDim, iG.data(), shgradl);

            return;
        }

        void _hessians(double *shgrad, double &jac, double *shhess, double *shlap, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl, double *shhessl)
        {
            //Compute inverse of the deformation gradient and jacobian
            vector<double> iG(pDim*pDim);
            _inverseOfDeformationGradient(iG.data(), jac, eNN, pDim, nDim, x_nodes, shgradl);

            //Compute deformation hessian
            vector<double> H(pDim*pDim*pDim);
            _deformationHessian(H.data(), eNN, pDim, nDim, x_nodes, shhessl);

            //Compute basis function gradient
            _gradients(shgrad, eNN, pDim, iG.data(), shgradl);

            //Compute global hessian and laplacian
            Array::Fill(shhess, eNN*pDim*pDim, 0.0);
            Array::Fill(shlap, eNN, 0.0);
            for (int i = 0; i < eNN; i++)
            {
                vector<double> hlI(pDim*pDim), hgI(pDim*pDim), Maux(pDim*pDim);
                Array::Copy(hlI.data(), pDim*pDim, &shhessl[pDim*pDim*i]);
                for (int dI = 0; dI < pDim; dI++)
                    Math::AXPY(hlI.data(), pDim*pDim, -shgrad[pDim*i+dI], &H[pDim*pDim*dI]);
                Math::MatProduct(Maux.data(), pDim, pDim, pDim, hlI.data(), iG.data());
                Math::MatTMult(hgI.data(), pDim, pDim, pDim, iG.data(), Maux.data());

                for (int dI = 0; dI < pDim; dI++)
                {
                    for (int dJ = 0; dJ < pDim; dJ++)
                    {
                        shhess[pDim*pDim*i+pDim*dI+dJ] = hgI[pDim*dI+dJ];
                    }
                }

                for (int dI = 0; dI < pDim; dI++)
                    shlap[i] += shhess[pDim*pDim*i+pDim*dI+dI];
            }

            return;
        }


        void _thirdGlobalDerivs(double *shgrad, double &jac, double *shhess, double *shlap, double* shthird, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl, double *shhessl, double *shthirdl)
        {
            //Compute deformation gradient
            vector<double> G(pDim*pDim);
            GlobalBasisFunctions::_deformationGradient(G.data(), eNN, pDim, nDim, x_nodes, shgradl);

            //Compute inverse of the deformation gradient and jacobian
            vector<double> iG(pDim*pDim);
            GlobalBasisFunctions::_inverseOfDeformationGradient(iG.data(), jac, eNN, pDim, nDim, x_nodes, shgradl);

            //Compute deformation hessian
            vector<double> H(pDim*pDim*pDim);
            GlobalBasisFunctions::_deformationHessian(H.data(), eNN, pDim, nDim, x_nodes, shhessl);

            //Compute deformation third derivatives
            vector<double> T(pDim*pDim*pDim*pDim);
            _deformationThirdDerivs(T.data(), eNN, pDim, nDim, x_nodes, shthirdl);

            //Compute global basis function gradient, hessian, jacobian and laplacian
            GlobalBasisFunctions::_hessians(shgrad, jac, shhess, shlap, eNN, pDim, nDim, x_nodes, shgradl, shhessl);

            //Compute global third derivatives
            Array::Fill(shthird, eNN*pDim*pDim*pDim, 0.0);
            for (int i = 0; i < eNN; i++)
            {

                // Maux = (d^3N/dxi^3) - (d^2N/dx^2) (dx/dxi) (d^2x/dxi^2) - (dN/dx) (d^3x/dxi^3)
                vector<double> Maux(pDim*pDim*pDim);
                Array::Copy(Maux.data(), pDim*pDim*pDim, &shthirdl[pDim*pDim*pDim*i]); // (d^3N/dxi^3)

                for (int dL = 0; dL < pDim; dL++)
                {
                    for (int dM = 0; dM < pDim; dM++)
                    {
                        for (int dI = 0; dI < pDim; dI++)
                        {
                            for (int dJ = 0; dJ < pDim; dJ++)
                            {
                                for (int dK = 0; dK < pDim; dK++)
                                {
                                    Maux[pDim*pDim*dI+pDim*dJ+dK] -= shhess[pDim*pDim*i+pDim*dL+dM] * G[pDim*dL+dI] * H[pDim*pDim*dM+pDim*dJ+dK];
                                    Maux[pDim*pDim*dI+pDim*dJ+dK] -= shhess[pDim*pDim*i+pDim*dL+dM] * G[pDim*dL+dJ] * H[pDim*pDim*dM+pDim*dI+dK];
                                    Maux[pDim*pDim*dI+pDim*dJ+dK] -= shhess[pDim*pDim*i+pDim*dL+dM] * G[pDim*dL+dK] * H[pDim*pDim*dM+pDim*dI+dJ];
                                }
                            }
                        }
                    }
                }

                for (int dI = 0; dI < pDim; dI++)
                    Math::AXPY(Maux.data(), pDim*pDim, -shgrad[pDim*i+dI], &T[pDim*pDim*pDim*dI]);

                // d^3N/dx^3 = Maux * (dx/dxi)^-3
                for (int dI = 0; dI < pDim; dI++)
                {
                    for (int dJ = 0; dJ < pDim; dJ++)
                    {
                        for (int dK = 0; dK < pDim; dK++)
                        {
                            for (int dL = 0; dL < pDim; dL++)
                            {
                                for (int dM = 0; dM < pDim; dM++)
                                {
                                    for (int dN = 0; dN < pDim; dN++)
                                    {
                                        shthird[pDim*pDim*pDim*i+pDim*pDim*dI+pDim*dJ+dK] +=
                                                Maux[pDim*pDim*dL+pDim*dM+dN] * iG[pDim*dL+dI] * iG[pDim*dM+dJ] * iG[pDim*dN+dK];
                                    }
                                }
                            }
                        }
                    }
                }

            }

            return;
        }

    }
}
