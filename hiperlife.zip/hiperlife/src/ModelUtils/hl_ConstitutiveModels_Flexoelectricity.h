/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HL_FLEXOELECTRICITY_H
#define HL_FLEXOELECTRICITY_H

#include "hl_Tensor.h"

using namespace hiperlife::Tensor;

namespace hiperlife
{
    namespace ConstitutiveModels
    {
        namespace Flexoelectricity
        {
            /*! \brief Computes linear Flexoelectric tensor Mu_ijkl
            * @param Mu Flexoelectric tensor
            * @param flexo_L Longitudinal piezo parameter
            * @param flexo_T Transverse piezo parameter
            * @param flexo_S Shear piezo parameter
            * @param pDim Parametric dimension
            */
            void flexoelectricityTensor(tensor<double, 4> &Mu, const double flexo_L, const double flexo_T, const double flexo_S, const int pDim);
            void flexoelectricityTensor(std::vector<double> &Mu, const double flexo_L, const double flexo_T, const double flexo_S, const int pDim);

            /*! \brief Computes linear gradient dielectricity tensor Mu_ijkl
            * @param M linear gradient dielectricity
            * @param kappa_L longitudinal dielectric parameter
            * @param pDim Parametric dimension
            */
            void gradDielectricity(tensor<double, 4> &M, const double kappa_L, const double lElec, const int pDim);
            void gradDielectricity(std::vector<double> &M, const double kappa_L, const double lElec, const int pDim);

            namespace Direct
            {
                /*! \brief Computes stress tensor
                * @param sigHat stress tensor
                * @param C elasticity tensor
                * @param strain strain 4th order tensor
                * @param E Piezoelectric tensor
                * @param eField electric field tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void stress(tensor<double, 4> &sigHat, tensor<double, 4> C, tensor<double, 4> strain, tensor<double, 3> E, tensor<double, 2> eField, const int numDOFs, const int pDim);

                /*! \brief Computes double stress tensor
                * @param sigTilde double stress tensor
                * @param H gradient elasticity tensor
                * @param gradStrain strain gradient
                * @param eField electric field tensor
                * @param Mu Flexoelectric tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void doubleStress(tensor<double, 5> &sigTilde, tensor<double, 6> H, tensor<double, 5> gradStrain, tensor<double, 2> eField, tensor<double, 4> Mu, const int numDOFs, const int pDim);

                /*! \brief Computes gradient of double stress tensor
                * @param gradSigTilde Gradient of double stress tensor
                * @param H gradient elasticity tensor
                * @param hessStrain strain hessian
                * @param Mu Flexoelectric tensor
                * @param gradEField gradient of electric field tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void gradDoubleStress(tensor<double, 6> &gradSigTilde, tensor<double, 6> H, tensor<double, 6> hessStrain, tensor<double, 4> Mu, tensor<double, 3> gradEField, const int numDOFs, const int pDim);

                /*! \brief Computes electric displacement tensor
                * @param DHat electric displacement tensor
                * @param eField electric field tensor
                * @param strain strain 4th order tensor
                * @param gradStrain strain gradient
                * @param gradEField gradient of electric field tensor
                * @param Mu Flexoelectric tensor
                * @param K dielectric tensor
                * @param E Piezoelectric tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void electricDisplacement(tensor<double, 3> &DHat, tensor<double, 2> eField, tensor<double, 4> strain, tensor<double, 5> gradStrain, tensor<double, 4> Mu, tensor<double, 2> K, tensor<double, 3> E, const int numDOFs, const int pDim);

                /*! \brief Computes traction tensor
                * @param Ti traction tensor
                * @param sigHat stress tensor
                * @param sigTilde double stress tensor
                * @param gradSigTilde Gradient of double stress tensor
                * @param PMat projection operator
                * @param NMat second-order geometry tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void traction(tensor<double, 3> &Ti, tensor<double, 4> sigHat, tensor<double, 5> sigTilde, tensor<double, 6> gradSigTilde, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim);

                /*! \brief Computes double traction tensor
                * @param ri double traction tensor
                * @param sigTilde double stress tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void doubleTraction(tensor<double, 3> &ri, tensor<double, 5> sigTilde, const double normal[], const int pDim);

                /*! \brief Computes surface charge density
                * @param W surface charge density tensor
                * @param DHat electric displacement tensor
                * @param PMat projection operator
                * @param NMat second-order geometry tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void surfaceChargeDensity(tensor<double, 2> &W, tensor<double, 3> DHat, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim);

                /*! \brief Computes double surface charge density
                * @param Tau double surface charge density tensor
                * @param DTilde double electric displacement tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void doubleSurfaceChargeDensity(tensor<double, 2> &Tau, tensor<double, 4> DTilde, const double normal[], const int pDim);
            } // namespace Direct

            namespace Lifshitz
            {
                /*! \brief Computes stress tensor
                * @param sigHat stress tensor
                * @param C elasticity tensor
                * @param strain strain 4th order tensor
                * @param E Piezoelectric tensor
                * @param eField electric field tensor
                * @param Mu Flexoelectric tensor
                * @param gradEField gradient of electric field tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void stress(tensor<double, 4> &sigHat, tensor<double, 4> C, tensor<double, 4> strain, tensor<double, 3> E, tensor<double, 2> eField, tensor<double, 4> Mu, tensor<double, 3> gradEField, const int numDOFs, const int pDim);

                /*! \brief Computes double stress tensor
                * @param sigTilde double stress tensor
                * @param H gradient elasticity tensor
                * @param gradStrain strain gradient
                * @param eField electric field tensor
                * @param Mu Flexoelectric tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void doubleStress(tensor<double, 5> &sigTilde, tensor<double, 6> H, tensor<double, 5> gradStrain, tensor<double, 2> eField, tensor<double, 4> Mu, const int numDOFs, const int pDim);

                /*! \brief Computes gradient of double stress tensor
                * @param gradSigTilde Gradient of double stress tensor
                * @param H gradient elasticity tensor
                * @param hessStrain strain hessian
                * @param Mu Flexoelectric tensor
                * @param gradEField gradient of electric field tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void gradDoubleStress(tensor<double, 6> &gradSigTilde, tensor<double, 6> H, tensor<double, 6> hessStrain, tensor<double, 4> Mu, tensor<double, 3> gradEField, const int numDOFs, const int pDim);

                /*! \brief Computes electric displacement tensor
                * @param DHat electric displacement tensor
                * @param eField electric field tensor
                * @param strain strain 4th order tensor
                * @param gradStrain strain gradient
                * @param gradEField gradient of electric field tensor
                * @param Mu Flexoelectric tensor
                * @param K dielectric tensor
                * @param E Piezoelectric tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void electricDisplacement(tensor<double, 3> &DHat, tensor<double, 2> eField, tensor<double, 4> strain, tensor<double, 5> gradStrain, tensor<double, 4> Mu, tensor<double, 2> K, tensor<double, 3> E, const int numDOFs, const int pDim);

                /*! \brief Computes double electric displacement tensor
                * @param DTilde double electric displacement tensor
                * @param gradEField gradient of electric field tensor
                * @param strain strain 4th order tensor
                * @param G gradient dielectric tensor
                * @param Mu Flexoelectric tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void doubleElectricDisplacement(tensor<double, 4> &DTilde, tensor<double, 3> gradEField, tensor<double, 4> strain, tensor<double, 4> G, tensor<double, 4> Mu, const int numDOFs, const int pDim);

                /*! \brief Computes double electric displacement tensor
                * @param gradDTilde gradient of double electric displacement tensor
                * @param gradStrain strain gradient
                * @param hessEField hessian of electric displacement field
                * @param G gradient dielectric tensor
                * @param Mu Flexoelectric tensor
                * @param numDOFs number of degree of freedoms
                * @param pDim Parametric dimension
                */
                void gradDoubleElectricDisplacement(tensor<double, 5> &gradDTilde, tensor<double, 5> gradStrain, tensor<double, 4> hessEField, tensor<double, 4> G, tensor<double, 4> Mu, const int numDOFs, const int pDim);

                /*! \brief Computes traction tensor
                * @param Ti traction tensor
                * @param sigHat stress tensor
                * @param sigTilde double stress tensor
                * @param gradSigTilde Gradient of double stress tensor
                * @param PMat projection operator
                * @param NMat second-order geometry tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void traction(tensor<double, 3> &Ti, tensor<double, 4> sigHat, tensor<double, 5> sigTilde, tensor<double, 6> gradSigTilde, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim);

                /*! \brief Computes double traction tensor
                * @param ri double traction tensor
                * @param sigTilde double stress tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void doubleTraction(tensor<double, 3> &ri, tensor<double, 5> sigTilde, const double normal[], const int pDim);

                /*! \brief Computes surface charge density
                * @param W surface charge density tensor
                * @param DHat electric displacement tensor
                * @param DTilde double electric displacement tensor
                * @param gradDTilde gradient of double electric displacement tensor
                * @param PMat projection operator
                * @param NMat second-order geometry tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void surfaceChargeDensity(tensor<double, 2> &W, tensor<double, 3> DHat, tensor<double, 4> DTilde, tensor<double, 5> gradDTilde, tensor<double, 2> PMat, tensor<double, 2> NMat, const double normal[], const int pDim);

                /*! \brief Computes double surface charge density
                * @param Tau double surface charge density tensor
                * @param DTilde double electric displacement tensor
                * @param normal Normal vector
                * @param pDim Parametric dimension
                */
                void doubleSurfaceChargeDensity(tensor<double, 2> &Tau, tensor<double, 4> DTilde, const double normal[], const int pDim);
            } // namespace Lifshitz
        }     // namespace Flexoelectricity
    }         // namespace ConstitutiveModels
} // namespace hiperlife

#endif
