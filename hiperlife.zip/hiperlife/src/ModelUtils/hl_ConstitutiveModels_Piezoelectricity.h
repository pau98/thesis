/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HL_PIEZOELECTRICITY_H
#define HL_PIEZOELECTRICITY_H

#include "hl_Tensor.h"

using namespace hiperlife::Tensor;

namespace hiperlife
{
    namespace ConstitutiveModels
    {
        namespace Piezoelectricity
        {
            /*! \brief Computes linear isotropic dielectric tensor K_ij
            * @param K dielectric tensor
            * @param kappa_L longitudinal dielectric parameter
            * @param pDim Parametric dimension
            */
            void dielectricTensor(tensor<double, 2> &K, const double kappa_L, const int pDim);
            void dielectricTensor(std::vector<double> &K, const double kappa_L, const int pDim);

            /*! \brief Computes linear Piezoelectric tensor E_ijk
            * @param E Piezoelectric tensor
            * @param piezo_L Longitudinal piezo parameter
            * @param piezo_T Transverse piezo parameter
            * @param piezo_S Shear piezo parameter
            * @param pDim Parametric dimension
            */
            void piezoelectricTensor(tensor<double, 3> &E, const double piezo_L, const double piezo_T, const double piezo_S, const int pDim);
            void piezoelectricTensor(std::vector<double> &E, const double piezo_L, const double piezo_T, const double piezo_S, const int pDim);

            /*! \brief Computes electric field tensor
            * @param eField electric field tensor (pDim, eNN)
            * @param globDBF Global derivative of basis functions
            * @param pDim Parametric dimension
            */
            void electricFieldTensor(tensor<double, 2> &eField, tensor<double, 2> globDBF, const int pDim);

            /*! \brief Computes gradient of electric field tensor
            * @param gradEfield gradient of electric field tensor (pDim, pDim, eNN)
            * @param globHBF Global Hessian of basis functions
            * @param pDim Parametric dimension
            */
            void gradElectricField(tensor<double, 3> &gradEfield, tensor<double, 3> globHBF, const int pDim);

            /*! \brief Computes hessian of electric field tensor
            * @param hessEField gradient of electric field tensor (pDim, pDim, pDim, eNN)
            * @param globTBF Global third derivative of basis functions
            * @param pDim Parametric dimension
            */
            void hessElectricField(tensor<double, 4> &hessEField, tensor<double, 4> golbTBF, const int pDim);
        } // namespace Piezoelectricity
    } // namespace ConstitutiveModels
} // namespace hiperlife
#endif
