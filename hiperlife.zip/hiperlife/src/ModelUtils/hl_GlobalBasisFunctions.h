/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Jordi Manyer
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HPLFE_GLOBALBASISFUNCTIONS_H
#define HPLFE_GLOBALBASISFUNCTIONS_H

#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_Tensor.h"
#include "hl_SubFillStructure.h"

namespace hiperlife
{
    namespace GlobalBasisFunctions
    {
        //Deformation gradient
        void _deformationGradient(double *G, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl);
        inline void deformationGradient(double *G, SubFillStructure& subFill)
        {
            _deformationGradient(G, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1));
        }


        //Inverse of the deformation gradient
        void _inverseOfDeformationGradient(double *iG, double &jac, int pDim, double *G);
        void _inverseOfDeformationGradient(double *iG, double &jac, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl);
        inline void inverseOfDeformationGradient(double *iG, double &jac, SubFillStructure& subFill)
        {
            _inverseOfDeformationGradient(iG, jac, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1));
        }


        //Deformation Hessian
        void _deformationHessian(double *H, int eNN, int pDim, int nDim, double *x_nodes, double *shhessl);
        inline void deformationHessian(double *H, SubFillStructure& subFill)
        {
            _deformationHessian(H, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(2));
        }


        // Deformation 3rd order derivatives
        void _deformationThirdDerivs(double *T, int eNN, int pDim, int nDim, double *x_nodes, double *shthirdl);
        inline void deformationThirdDerivs(double *T, SubFillStructure& subFill)
        {
            _deformationThirdDerivs(T, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(3));
        }


        // Jacobian
        void _jacobian(double &jac, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl);
        inline void jacobian(double &jac, SubFillStructure& subFill)
        {
            _jacobian(jac, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1));
        }

        //Global gradients of the basis functions
        void _gradients(double *shgrad, int eNN, int pDim, double *iG, double *shgradl);
        void _gradients(double *shgrad, double &jac, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl);
        inline void _gradients(Tensor::tensor<double,2,false>& shgrad, double &jac, Tensor::tensor<double,2,false>& x_nodes, Tensor::tensor<double,2,false>& shgradl)
        {
            _gradients(shgrad.data(), jac, shgradl.shape()[0], shgradl.shape()[1], x_nodes.shape()[1], x_nodes.data(), shgradl.data());
        }
        inline void gradients(double *shgrad, double &jac, SubFillStructure& subFill)
        {
            _gradients(shgrad, jac, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1));
        }
        inline void gradients(Tensor::tensor<double,2,false>& shgrad, double &jac, SubFillStructure& subFill)
        {
            _gradients(shgrad.data(), jac, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1));
        }


        //Global Hessians of the basis functions
        void _hessians(double *shgrad, double &jac, double *shhess, double *shlap, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl, double *shhessl);
        inline void _hessians(Tensor::tensor<double,2,false>& shgrad, double &jac, Tensor::tensor<double,3,false>& shhess, Tensor::tensor<double,1,false>& shlap, Tensor::tensor<double,2,false>& x_nodes, Tensor::tensor<double,2,false>& shgradl, Tensor::tensor<double,3,false>& shhessl)
        {
            _hessians(shgrad.data(), jac, shhess.data(), shlap.data(), shgradl.shape()[0], shgradl.shape()[1], x_nodes.shape()[1], x_nodes.data(), shgradl.data(), shhessl.data());
        }
        inline void hessians(double *shgrad, double &jac, double *shhess, double *shlap, SubFillStructure& subFill)
        {
            _hessians(shgrad, jac, shhess, shlap, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1), subFill.nborBFsDers(2));
        }
        inline void hessians(Tensor::tensor<double,2,false>& shgrad, double &jac, Tensor::tensor<double,3,false>& shhess, Tensor::tensor<double,1,false>& shlap, SubFillStructure& subFill)
        {
            _hessians(shgrad.data(), jac, shhess.data(), shlap.data(), subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1), subFill.nborBFsDers(2));
        }


        // Global third derivatives of the basis functions
        void _thirdGlobalDerivs(double *shgrad, double &jac, double *shhess, double *shlap, double* shthird, int eNN, int pDim, int nDim, double *x_nodes, double *shgradl, double *shhessl, double *shthirdl);
        inline void thirdGlobalDerivs(double *shgrad, double &jac, double *shhess, double *shlap, double* shthird, SubFillStructure& subFill)
        {
            _thirdGlobalDerivs(shgrad, jac, shhess, shlap, shthird, subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1), subFill.nborBFsDers(2), subFill.nborBFsDers(3));
        }
        inline void thirdGlobalDerivs(Tensor::tensor<double,2,false>& shgrad, double &jac, Tensor::tensor<double,3,false>& shhess, Tensor::tensor<double,1,false>& shlap, Tensor::tensor<double,4,false>& shthird, SubFillStructure& subFill)
        {
            _thirdGlobalDerivs(shgrad.data(), jac, shhess.data(), shlap.data(), shthird.data(), subFill.eNN, subFill.pDim, subFill.nDim, subFill.nborCoords.data(), subFill.nborBFsDers(1), subFill.nborBFsDers(2), subFill.nborBFsDers(3));
        }
    }
}

#endif //HPLFE_GLOBALBASISFUNCTIONS_H
