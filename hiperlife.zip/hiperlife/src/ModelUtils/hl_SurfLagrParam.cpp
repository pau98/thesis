/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <tuple>
#include <array>

#include "hl_SurfLagrParam.h"


namespace hiperlife
{
    namespace SurfLagrParam
    {

        void MetricTensor ( double *Ip, double *xu, double *xv, int kNN, double *x_nears, double *dp_s )
        {
            int i, j, iD;
            double dp_u, dp_v;

            Array::Fill3D(xu,0.0);
            Array::Fill3D(xv,0.0);

            for ( i=0; i<kNN; i++ )
            {
                iD   = i*3;
                dp_u = dp_s[2*i  ];
                dp_v = dp_s[2*i+1];
                for ( j=0; j<3; j++ )
                {
                    xu[j] += dp_u * x_nears[iD+j];
                    xv[j] += dp_v * x_nears[iD+j];
                }
            }

            // First fundamental form
            //      | I0   I1 |
            //  I = |         |
            //      | I2   I3 |
            Ip[0] = Math::Dot3D(xu, xu);
            Ip[1] = Math::Dot3D(xu, xv);
            Ip[2] = Ip[1];
            Ip[3] = Math::Dot3D(xv, xv);

            return;
        }

        void Normal ( double *normal, double *Ip, double *xu, double *xv, int kNN, double *x_nears, double *dp_s )
        {
            int i, j, iD;
            double dp_u, dp_v;
            double inorm;

            Array::Fill3D(xu, 0.0);
            Array::Fill3D(xv, 0.0);

            for ( i=0; i<kNN; i++ )
            {
                iD   = i*3;
                dp_u = dp_s[2*i  ];
                dp_v = dp_s[2*i+1];

                for ( j=0; j<3; j++ )
                {
                    xu[j] += dp_u * x_nears[iD+j];
                    xv[j] += dp_v * x_nears[iD+j];
                }

            }

            // First fundamental form
            //      | I0   I1 |
            //  I = |         |
            //      | I2   I3 |
            Ip[0] = Math::Dot3D(xu, xu);
            Ip[1] = Math::Dot3D(xu, xv);
            Ip[2] = Ip[1];
            Ip[3] = Math::Dot3D(xv, xv);

            // now the normal to the surface is computed
            Math::Cross(normal,xu, xv);
            inorm = Math::Norm3D( normal );
#ifdef DEBUG
            if (inorm < 1.0e-15)
                std::cout << "ERROR::Geometry: Normal(3) - fails - norm|n|=0" << std::endl;
            else
#endif
            {
                inorm = 1.0/inorm;
                for ( i=0; i<3; i++ )
                    normal[i] *= inorm;
            }

        }

        void Curvatures ( double *IIp, double *Ip, double *normal,
                                     double *xu, double *xv, double *xuu, double *xvv, double *xuv,
                                     int kNN, double *x_nears, double *dp_s, double *hp_s)
        {
            int i, j, iD, iD2;
            double hp_uu, hp_uv, hp_vv;

            Normal ( normal, Ip, xu, xv, kNN, x_nears, dp_s );

            Array::Fill3D(xuu, 0.0);
            Array::Fill3D(xuv, 0.0);
            Array::Fill3D(xvv, 0.0);

            for ( i=0; i<kNN; i++ )
            {
                iD  = i*3;
                iD2 = i*4;
                hp_uu = hp_s[iD2  ];
                hp_uv = hp_s[iD2+1];
                hp_vv = hp_s[iD2+3];

                for ( j=0; j<3; j++ )
                {
                    xuu[j] += hp_uu * x_nears[iD+j];
                    xuv[j] += hp_uv * x_nears[iD+j];
                    xvv[j] += hp_vv * x_nears[iD+j];
                }
            }

            // Second fundamental form
            //       | II0   II1 |
            //  II = |           |
            //       | II2   II3 |
            IIp[0] = -Math::Dot3D(normal, xuu);   // -t.phi_11
            IIp[1] = -Math::Dot3D(normal, xuv);   // -t.phi_12
            IIp[2] =  IIp[1];
            IIp[3] = -Math::Dot3D(normal, xvv);   // -t.phi_22
        }


        void ChristoffelSymbols ( double *CS, double *DIp, double *IIp,  double *Ip, double *normal,
                                             double *xu, double *xv, double *xuu, double *xvv, double *xuv,
                                             int kNN, double *x_nears, double *dp_s, double *hp_s)
        {
            double idet, iIp[4];

            Curvatures( IIp, Ip, normal, xu, xv, xuu, xvv, xuv, kNN, x_nears, dp_s, hp_s );

            // Derivative of the metric (necessary for the Chrystoffel symbols)
            DIp[0]  = 2.0*Math::Dot3D(xuu, xu);                      //g_{00,0}
            DIp[1]  = 2.0*Math::Dot3D(xuv, xu);                      //g_{00,1}
            DIp[2]  = Math::Dot3D(xuu, xv)+Math::Dot3D(xu, xuv);  //g_{01,0}
            DIp[3]  = Math::Dot3D(xuv, xv)+Math::Dot3D(xu, xvv);  //g_{01,1}


            DIp[4]  = Math::Dot3D(xuv, xu)+Math::Dot3D(xv, xuu);  //g_{10,0}
            DIp[5]  = Math::Dot3D(xvv, xu)+Math::Dot3D(xv, xuv);  //g_{10,1}
            DIp[6]  = 2.0*Math::Dot3D(xv, xuv);                      //g_{11,0}
            DIp[7]  = 2.0*Math::Dot3D(xvv, xv);                      //g_{11,1}

            idet   = 1.0/(Ip[0]*Ip[3]-Ip[1]*Ip[2]);
            iIp[0] = Ip[3]*idet;    iIp[1] = -Ip[2]*idet;
            iIp[2] = iIp[1];        iIp[3] = Ip[0]*idet;

            Array::Fill  (CS, 8, 0.0);
            //
            //CS = 1/2[g^{ad}*(g_{bd,c}+g_{cd,b}-g_{bc,d})]
            // g^{ad}*(g_{bd,c}
            CS[0] = iIp[0] * DIp[0] + iIp[1] * DIp[2];
            CS[1] = iIp[0] * DIp[1] + iIp[1] * DIp[3];
            CS[2] = iIp[0] * DIp[4] + iIp[1] * DIp[6];
            CS[3] = iIp[0] * DIp[5] + iIp[1] * DIp[7];

            CS[4] = iIp[2] * DIp[0] + iIp[3] * DIp[2];
            CS[5] = iIp[2] * DIp[1] + iIp[3] * DIp[3];
            CS[6] = iIp[2] * DIp[4] + iIp[3] * DIp[6];
            CS[7] = iIp[2] * DIp[5] + iIp[3] * DIp[7];

            // + g^{ad} g_{cd,b}
            CS[0] += iIp[0] * DIp[0] + iIp[1] * DIp[2];
            CS[1] += iIp[0] * DIp[4] + iIp[1] * DIp[6];
            CS[2] += iIp[0] * DIp[1] + iIp[1] * DIp[3];
            CS[3] += iIp[0] * DIp[5] + iIp[1] * DIp[7];

            CS[4] += iIp[2] * DIp[0] + iIp[3] * DIp[2];
            CS[5] += iIp[2] * DIp[4] + iIp[3] * DIp[6];
            CS[6] += iIp[2] * DIp[1] + iIp[3] * DIp[3];
            CS[7] += iIp[2] * DIp[5] + iIp[3] * DIp[7];

            // - g^{ad} g_{bc,d}
            CS[0] -= iIp[0] * DIp[0] + iIp[1] * DIp[1];
            CS[1] -= iIp[0] * DIp[2] + iIp[1] * DIp[3];
            CS[2] -= iIp[0] * DIp[4] + iIp[1] * DIp[5];
            CS[3] -= iIp[0] * DIp[6] + iIp[1] * DIp[7];

            CS[4] -= iIp[2] * DIp[0] + iIp[3] * DIp[1];
            CS[5] -= iIp[2] * DIp[2] + iIp[3] * DIp[3];
            CS[6] -= iIp[2] * DIp[4] + iIp[3] * DIp[5];
            CS[7] -= iIp[2] * DIp[6] + iIp[3] * DIp[7];

            for ( int i = 0; i < 8; i++ )
                CS[i] *= 0.5;
        }

        void d_Jac (double *dJ, double *dp_k, double *phi_1, double *phi_2, double *normal)
        {
            double cross1[3], cross2[3];

            //cross1 = x_{,1} x n  (3D vector)
            Math::Cross(cross1, phi_1, normal);
            //cross2 = x_{,2} x n (3D vector)
            Math::Cross(cross2, phi_2, normal);


            // dJ = p_{,1}(x_{,2} x n) - p_{,2}(x_{,1} x n)
            Array::Fill3D(dJ, 0.0);
            Math::AXPY(dJ, 3, dp_k[0], cross2);
            Math::AXPY(dJ, 3, -dp_k[1], cross1);

            return;
        }

        void dd_Jac(double *ddJ, double *dp_kI, double *dp_kJ, double *phi_1, double *phi_2, double *normal,
                             double *dnormalJ)
        {
            double aux[3];
            double Inormal[9];
            double cross1[9], cross2[9];

            Array::Fill(ddJ, 9, 0.0);

            Inormal[0] = 0.0;
            Inormal[1] = -normal[2];
            Inormal[2] = normal[1];

            Inormal[3] = normal[2];
            Inormal[4] = 0.0;
            Inormal[5] = -normal[0];

            Inormal[6] = -normal[1];
            Inormal[7] = normal[0];
            Inormal[8] = 0.0;

            Math::AXPY(ddJ, 9, dp_kI[1] * dp_kJ[0] - dp_kI[0] * dp_kJ[1], Inormal);

            aux[0] = dnormalJ[0];
            aux[1] = dnormalJ[1];
            aux[2] = dnormalJ[2];
            Math::Cross(&cross1[0], phi_1, aux);
            Math::Cross(&cross2[0], phi_2, aux);
            aux[0] = dnormalJ[3];
            aux[1] = dnormalJ[4];
            aux[2] = dnormalJ[5];
            Math::Cross(&cross1[3], phi_1, aux);
            Math::Cross(&cross2[3], phi_2, aux);
            aux[0] = dnormalJ[6];
            aux[1] = dnormalJ[7];
            aux[2] = dnormalJ[8];
            Math::Cross(&cross1[6], phi_1, aux);
            Math::Cross(&cross2[6], phi_2, aux);

            Math::AXPY(ddJ, 9, dp_kI[0], cross2);
            Math::AXPY(ddJ, 9, -dp_kI[1], cross1);

        }

        void d_Normal (double *dnormal, double *dp_k, double *phi_1, double *phi_2, double *normal, double J, double *dJ)
        {
            double Iphi_1[9], Iphi_2[9];

            for ( int n = 0; n < 3; n++ )
            {
                for ( int m = 0; m < 3; m++ )
                    dnormal[3*n+m] = - normal[m] / J * dJ[n];
            }

            Iphi_1[0] = 0.0;
            Iphi_1[3] = -phi_1[2];
            Iphi_1[6] = phi_1[1];

            Iphi_1[1] = phi_1[2];
            Iphi_1[4] = 0.0;
            Iphi_1[7] = -phi_1[0];

            Iphi_1[2] = -phi_1[1];
            Iphi_1[5] = phi_1[0];
            Iphi_1[8] = 0.0;

            Iphi_2[0] = 0.0;
            Iphi_2[3] = -phi_2[2];
            Iphi_2[6] = phi_2[1];

            Iphi_2[1] = phi_2[2];
            Iphi_2[4] = 0.0;
            Iphi_2[7] = -phi_2[0];

            Iphi_2[2] = -phi_2[1];
            Iphi_2[5] = phi_2[0];
            Iphi_2[8] = 0.0;

            Math::AXPY(dnormal, 9, -dp_k[0] / J, Iphi_2);
            Math::AXPY(dnormal, 9, dp_k[1] / J, Iphi_1);
        }

        void dd_Normal(double *ddnormal, double *dp_kI, double *dp_kJ, double J, double *dJI, double *dJJ, double *ddJ,
                      double *normal, double *dnormalI, double *dnormalJ)
        {
            double aux;

            for ( int n = 0; n < 3; n++ )
            {
                for ( int m = 0; m < 3; m++ )
                {
                    for ( int p = 0; p < 3; p++ )
                    {
                        ddnormal[9*n+3*m+p] = -normal[p] / J * ddJ[3*n+m];
                        ddnormal[9*n+3*m+p] -= dnormalI[3*n+p] / J * dJJ[m];
                        ddnormal[9*n+3*m+p] -= dnormalJ[3*m+p] / J * dJI[n];
                    }
                }
            }
            aux = 1.0 / J * (dp_kI[0] * dp_kJ[1] - dp_kI[1] * dp_kJ[0]);
            ddnormal[19] += aux; //(2*9)+(0*3)+(1*1)
            ddnormal[11] -= aux; //(1*9)+(0*9)+(2*1)
            ddnormal[21] -= aux; //(2*9)+(1*3)+(0*1)
            ddnormal[5]  += aux; //(0*9)+(1*3)+(2*1)
            ddnormal[15] += aux; //(1*9)+(2*3)+(0*1)
            ddnormal[7]  -= aux; //(0*9)+(2*3)+(1*1)
        }

        void d_Curva(double* dcurva_i, double* ddbf_i, double *xuu, double *xuv, double *xvv, double* normal, double* dnormal_i)
        {
            for (int n = 0; n < 3; n++)
            {
                dcurva_i[4*n+0]  = -Math::Dot3D(&dnormal_i[3*n],xuu);
                dcurva_i[4*n+0] += -normal[n] * ddbf_i[0];
                dcurva_i[4*n+1]  = -Math::Dot3D(&dnormal_i[3*n],xuv);
                dcurva_i[4*n+1] += -normal[n] * ddbf_i[1];
                dcurva_i[4*n+2]  = dcurva_i[4*n+1];
                dcurva_i[4*n+3]  = -Math::Dot3D(&dnormal_i[3*n],xvv);
                dcurva_i[4*n+3] += -normal[n] * ddbf_i[3];
            }
        }

        void dd_Curva(double* dcurva_ij, double* ddbf_i, double* ddbf_j, double *xuu, double *xuv, double *xvv, double* dnormal_i, double *dnormal_j, double *ddnormal)
        {
            for (int n = 0; n < 3; n++)
            {
                for (int m = 0; m < 3; m++ )
                {
                    dcurva_ij[12*n+m*4+0]  = -Math::Dot3D(&ddnormal[9*n+m*3],xuu);
                    dcurva_ij[12*n+m*4+0] += -dnormal_i[3*n+m] * ddbf_j[0];
                    dcurva_ij[12*n+m*4+0] += -dnormal_j[3*m+n] * ddbf_i[0];
                    dcurva_ij[12*n+m*4+1]  = -Math::Dot3D(&ddnormal[9*n+m*3],xuv);
                    dcurva_ij[12*n+m*4+1] += -dnormal_i[3*n+m] * ddbf_j[1];
                    dcurva_ij[12*n+m*4+1] += -dnormal_j[3*m+n] * ddbf_i[1];
                    dcurva_ij[12*n+m*4+2]  = dcurva_ij[12*n+m*4+1];
                    dcurva_ij[12*n+m*4+3]  = -Math::Dot3D(&ddnormal[9*n+m*3],xvv);
                    dcurva_ij[12*n+m*4+3] += -dnormal_i[3*n+m] * ddbf_j[3];
                    dcurva_ij[12*n+m*4+3] += -dnormal_j[3*m+n] * ddbf_i[3];
                }
            }
        }

        // Calculate the product of dN with a vector u: dN.u
        void
        NormalGradientU(double *udn, double *dp_k, double *phi_1, double *phi_2, double *normal, double iJac, double *u)
        {
            double dJ[3];
            double cross1[3], cross2[3];

            Array::Fill3D(udn, 0.0);

            d_Jac(dJ, dp_k, phi_1, phi_2, normal);

            // cross1 = x_{,1} x u
            Math::Cross(cross1, phi_1, u);
            // cross2 = x_{,2} x u
            Math::Cross(cross2, phi_2, u);

            // udn = -iJac * ( u·n·dJ - ( p_{,1} x_{,2} x u - p_{,2} x_{,1} x u) )
            Math::AXPY(udn, 3, -iJac * Math::Dot3D(u, normal), dJ);
            Math::AXPY(udn, 3, iJac * dp_k[0], cross2);
            Math::AXPY(udn, 3, -iJac * dp_k[1], cross1);

        }

        // Calculate the derivative of the metric tensor with respect to a node coordinates
        void d_Metric  (double *dg, double *dp_k, double *phi_1, double *phi_2)
        {
            // dg_{ab} = p_{,a} x_{,b} + p_{,b} x_{,a} (12 components, 2x2 tensor and 3 spatial components)
            for (int j = 0; j < 3; j++)
            {
                dg[4 * j + 0] = 2.0 * dp_k[0] * phi_1[j];
                double aux = dp_k[0] * phi_2[j] + dp_k[1] * phi_1[j];
                dg[4 * j + 1] = aux;
                dg[4 * j + 2] = aux;
                dg[4 * j + 3] = 2.0 * dp_k[1] * phi_2[j];
            }

        }
        void dd_Metric(double *ddg, double *dp_kI, double *dp_kJ)
        {

            Array::Fill(ddg, 36, 0.0);

            double t_ddg[4];

            // dg_{ab} = p_{,a} p_{,b} + p_{,b} p_{,a} (should have 3*3*4 components but they are 3 diagonal blocks that are equal + 0's)
            t_ddg[0] = 2.0 * dp_kI[0] * dp_kJ[0];
            double aux = dp_kI[0] * dp_kJ[1] + dp_kI[1] * dp_kJ[0];
            t_ddg[1] = aux;
            t_ddg[2] = aux;
            t_ddg[3] = 2.0 * dp_kI[1] * dp_kJ[1];


            for (int i = 0; i < 3; i++)
            {
                int k_ij = (i * 3 + i) * 4;

                ddg[k_ij + 0] = t_ddg[0];
                ddg[k_ij + 1] = t_ddg[1];
                ddg[k_ij + 2] = t_ddg[2];
                ddg[k_ij + 3] = t_ddg[3];
            }


        }
    }
}
