/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LAGRANPARAM_H
#define LAGRANPARAM_H


#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_Tensor.h"
namespace hiperlife
{
    namespace SurfLagrParam
    {

        /** @name Auxiliary functions
        * The following functions are provided to compute the First and Second fundamental
        * forms, normal, gradient, Hessian of the mapping at a given sample (Gauss) point
        * in the parametrical space
        */
        //@{
        /**
        * This function computes the First fundamental form
        *
        * Input:
        * \param kNN     : number of the closest neighbors to the sample point xi (2D)
        * \param x_nears : node coordinates for the neighbors of xi, length kNN*3  (3D)
        * \param dp_s    : gradient of the ME basis functions, length kNN*2
        *
        * Output:
        * \param xu, xv  : auxiliary arrays of dimension 3 (gradient of the mapping on the surface)
        * \param Gmat    : metric tensor 2x2 symmetric matrix. Also it is knows as the first
        *                  fundamental form I, commonly denoted as g. Ip = [ E  F ; F  G ]
        *
        * \return an error value is returned: 0 means all finished successfully, 1: normal was not computed */
        void MetricTensor ( double *Ip, double *xu, double *xv, int kNN, double *x_nears, double *dp_s );
        inline void MetricTensor ( hiperlife::Tensor::tensor<double,2,false>& Ip, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv, int kNN, hiperlife::Tensor::tensor<double,2,false>& x_nears, hiperlife::Tensor::tensor<double,2,false>& dp_s )
        {
            MetricTensor ( Ip.data(), xu.data(), xv.data(), kNN, x_nears.data(), dp_s.data() );
        }


        /**
         * This function computes at a given sample point the gradient of the mapping,
         * the first fundamental form, and surface normal
         *
         * Input:
         * \param kNN      number of the closest neighbors to the sample point xi (2D)
         * \param x_nears  node coordinates for the neighbors of xi, length nNN*3 (nNN>kNN)
         * \param dp_s     gradient of the ME basis functions, length kNN*2
         *
         * Output:
         * \param normal  normal vector to the surface
         * \param xu         auxiliary 3D array, gradient in the u-direction of the mapping on the surface
         * \param xv         auxiliary 3D array, gradient in the v-direction of the mapping on the surface
         * \param Ip      Metric tensor, commonly denoted as g. Ip = [ E  F ; F  G ]
         *
         * \return an error value is returned: 0 means all finished successfully, 1: normal was not computed
         */
        void Normal ( double *normal, double *Ip, double *xu, double *xv, int kNN, double *x_nears, double *dp_s );
        inline void Normal ( hiperlife::Tensor::tensor<double,1,false>& normal, hiperlife::Tensor::tensor<double,2,false>& Ip, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv, int kNN, hiperlife::Tensor::tensor<double,2,false>& x_nears, hiperlife::Tensor::tensor<double,2,false>& dp_s )
        {
            Normal ( normal.data(), Ip.data(), xu.data(), xv.data(), kNN, x_nears.data(), dp_s.data() );
        }
        /**
        * This function computes at each Gauss or sample point the first fundamental form,
        * normal, gradient and hessian of the mapping
        *
        * Input:
        * \param kNN      number of the closest neighbors to the sample point xi (2D)
        * \param x_nears  node coordinates for the neighbors of xi, length nNN*3 (nNN>kNN)
        * \param dp_s     gradient of the ME basis functions, length kNN*2
        * \param hp_s     hessians of the ME basis functions, length kNN*4
        *
        * Output:
        * \param normal  normal vector to the surface
        * \param Ip      Metric tensor, commonly denoted as g. Ip = [ E  F ; F  G ]
        * \param IIp     second fundamental form
        * \param xu      gradient of the mapping on the surface in the direction u (phi_1)
        * \param xv      gradient of the mapping on the surface in the direction v (phi_2)
        * \param xuu     Hessian of the mapping on the surface in the direction uu (phi_11)
        * \param xvv     Hessian of the mapping on the surface in the direction vv (phi_22)
        * \param xuv     Hessian of the mapping on the surface in the direction uv (phi_12)
        *
        * \return an error value is returned: 0 means all finished successfully, 1: normal was not computed
        */
        void Curvatures ( double *IIp, double *Ip, double *normal,
                          double *xu, double *xv, double *xuu, double *xvv, double *xuv,
                          int kNN, double *x_nears, double *dp_s, double *hp_s);

        /**
        * This function computes at each Gauss or sample point the first fundamental form,
        * normal, gradient and hessian of the mapping
        *
        * Input:
        * \param kNN      number of the closest neighbors to the sample point xi (2D)
        * \param x_nears  node coordinates for the neighbors of xi, length nNN*3 (nNN>kNN)
        * \param dp_s     gradient of the ME basis functions, length kNN*2
        * \param hp_s     hessians of the ME basis functions, length kNN*4
        *
        * Output:
        * \param normal  normal vector to the surface
        * \param Ip      Metric tensor, commonly denoted as g. Ip = [ E  F ; F  G ]
        * \param IIp     second fundamental form
        * \param xu      gradient of the mapping on the surface in the direction u (phi_1)
        * \param xv      gradient of the mapping on the surface in the direction v (phi_2)
        * \param xuu     Hessian of the mapping on the surface in the direction uu (phi_11)
        * \param xvv     Hessian of the mapping on the surface in the direction vv (phi_22)
        * \param xuv     Hessian of the mapping on the surface in the direction uv (phi_12)
        * \param CS      Christoffel symbols
        * \return an error value is returned: 0 means all finished successfully, 1: normal was not computed
        */
        void ChristoffelSymbols ( double *CS, double *DIp, double *IIp,  double *Ip, double *normal,
                                  double *xu, double *xv, double *xuu, double *xvv, double *xuv,
                                  int kNN, double *x_nears, double *dp_s, double *hp_s);
        inline void ChristoffelSymbols ( double *CS, double *IIp,  double *Ip, double *normal,
                                         double *xu, double *xv, double *xuu, double *xvv, double *xuv,
                                         int kNN, double *x_nears, double *dp_s, double *hp_s)
        {
            double DIp[8];
            ChristoffelSymbols ( CS, DIp, IIp,  Ip, normal, xu, xv, xuu, xvv, xuv, kNN, x_nears, dp_s, hp_s);
        }
        inline void ChristoffelSymbols ( hiperlife::Tensor::tensor<double,3,false>& CS, hiperlife::Tensor::tensor<double,2,false>& IIp, hiperlife::Tensor::tensor<double,2,false>& Ip, hiperlife::Tensor::tensor<double,1,false>& normal, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv, hiperlife::Tensor::tensor<double,1,false>& xuu, hiperlife::Tensor::tensor<double,1,false>& xvv,hiperlife::Tensor::tensor<double,1,false>& xuv, int kNN, hiperlife::Tensor::tensor<double,2,false>& x_nears, hiperlife::Tensor::tensor<double,2,false>& dp_s, hiperlife::Tensor::tensor<double,3,false>& hp_s  )
        {
            ChristoffelSymbols ( CS.data(), IIp.data(),  Ip.data(), normal.data(),
                                 xu.data(), xv.data(), xuu.data(), xvv.data(), xuv.data(),
                                 kNN, x_nears.data(), dp_s.data(), hp_s.data());
        }
        inline void ChristoffelSymbols ( hiperlife::Tensor::tensor<double,3,false>& CS, hiperlife::Tensor::tensor<double,3,false>& DIp, hiperlife::Tensor::tensor<double,2,false>& IIp, hiperlife::Tensor::tensor<double,2,false>& Ip, hiperlife::Tensor::tensor<double,1,false>& normal, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv, hiperlife::Tensor::tensor<double,1,false>& xuu, hiperlife::Tensor::tensor<double,1,false>& xvv,hiperlife::Tensor::tensor<double,1,false>& xuv, int kNN, hiperlife::Tensor::tensor<double,2,false>& x_nears, hiperlife::Tensor::tensor<double,2,false>& dp_s, hiperlife::Tensor::tensor<double,3,false>& hp_s  )
        {
            ChristoffelSymbols ( CS.data(), DIp.data(), IIp.data(),  Ip.data(), normal.data(),
                                 xu.data(), xv.data(), xuu.data(), xvv.data(), xuv.data(),
                                 kNN, x_nears.data(), dp_s.data(), hp_s.data());
        }

        void d_Metric  (double *dg, double *dp_kI, double *xu, double *xv);
        inline void d_Metric  (Tensor::tensor<double,4,false>& dg, hiperlife::Tensor::tensor<double,2,false>& dp_k, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv)
        {
            using namespace Tensor;
            for ( int i = 0; i < dp_k.shape()[0]; i++ )
            {
                d_Metric(dg(i,all,all,all).data(), dp_k(i,all).data(), xu.data(), xv.data());
            }
        }
        void dd_Metric(double *ddg, double *dp_kI, double *dp_kJ);
        inline void dd_Metric(Tensor::tensor<double,6,false>& ddg, hiperlife::Tensor::tensor<double,2,false>& dbf)
        {
            using namespace Tensor;

            tensor<double,4> ddg_ij(3,3,2,2);
            for ( int i = 0; i < dbf.shape()[0]; i++ )
            {
                for (int j = 0; j < dbf.shape()[0]; j++)
                {
                    dd_Metric(ddg_ij.data(), dbf(i, all).data(), dbf(j, all).data());
                    ddg(i,all,j,all,all,all) = ddg_ij;
                }
            }
        }



        void d_Jac (double *dJ, double *dp_kI, double *phi_1, double *phi_2, double *normal);
        inline void d_Jac (Tensor::tensor<double,2,false>& dJ, hiperlife::Tensor::tensor<double,2,false>& dbf, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv, hiperlife::Tensor::tensor<double,1,false>& normal)
        {
            using namespace Tensor;
            for ( int i = 0; i < dbf.shape()[0]; i++ )
            {
                d_Jac(dJ(i,all).data(), dbf(i,all).data(), xu.data(), xv.data(), normal.data());
            }
        }

        void dd_Jac (double *ddJ, double *dp_kI, double *dp_kJ, double *phi_1, double *phi_2, double *normal, double *dnormalJ);
        inline void dd_Jac (Tensor::tensor<double,4,false>& ddJ, hiperlife::Tensor::tensor<double,2,false>& dbf, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv, hiperlife::Tensor::tensor<double,1,false>& normal, hiperlife::Tensor::tensor<double,3,false>& dnormal)
        {
            using namespace Tensor;

            tensor<double,2> ddJ_ij(3,3);
            for ( int i = 0; i < dbf.shape()[0]; i++ )
            {
                for (int j = 0; j < dbf.shape()[0]; j++)
                {
                    dd_Jac(ddJ_ij.data(), dbf(i, all).data(), dbf(j, all).data(), xu.data(), xv.data(), normal.data(),dnormal(j,all,all).data());
                    ddJ(i,all,j,all) = ddJ_ij;
                }
            }
        }

        void d_Normal (double *dnormal, double *dp_kI, double *phi_1, double *phi_2, double *normal, double J, double *dJ);
        inline void d_Normal (hiperlife::Tensor::tensor<double,3,false>& dnormal, hiperlife::Tensor::tensor<double,2,false>& dbf, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv, hiperlife::Tensor::tensor<double,1,false>& normal, double J, Tensor::tensor<double,2,false>& dJ)
        {
            using namespace Tensor;
            for ( int i = 0; i < dbf.shape()[0]; i++ )
            {
                d_Normal(dnormal(i,all,all).data(), dbf(i,all).data(), xu.data(), xv.data(),normal.data(), J, dJ(i,all).data());
            }
        }
        void dd_Normal (double *ddnormal, double *dp_kI, double *dp_kJ, double J, double *dJI, double *dJJ, double *ddJ, double *normal, double *dnormalI, double *dnormalJ );
        inline void dd_Normal (hiperlife::Tensor::tensor<double,5,false>& ddnormal, hiperlife::Tensor::tensor<double,2,false>& dbf, double J, Tensor::tensor<double,2,false>& dJ, Tensor::tensor<double,4,false>& ddJ, hiperlife::Tensor::tensor<double,1,false>& normal, hiperlife::Tensor::tensor<double,3,false>& dnormal)
        {
            using namespace Tensor;

            tensor<double,3> ddnormal_ij(3,3,3);
            tensor<double,2> ddJ_ij(3,3);
            for ( int i = 0; i < dbf.shape()[0]; i++ )
            {
                for (int j = 0; j < dbf.shape()[0]; j++)
                {
                    ddJ_ij = ddJ(i,all,j,all);
                    dd_Normal(ddnormal_ij.data(), dbf(i, all).data(), dbf(j, all).data(), J, dJ(i,all).data(), dJ(j,all).data(),ddJ_ij.data(),normal.data(),dnormal(i,all,all).data(),dnormal(j,all,all).data());
                    ddnormal(i,all,j,all,all) = ddnormal_ij;
                }
            }
        }

        void d_Curva(double* dcurva_i, double* ddbf_i, double *xuu, double *xuv, double *xvv, double* normal, double* dnormal_i);
        inline void d_Curva  (Tensor::tensor<double,4,false>& dcurva, hiperlife::Tensor::tensor<double,3,false>& ddbf, hiperlife::Tensor::tensor<double,1,false>& xuu, hiperlife::Tensor::tensor<double,1,false>& xuv, hiperlife::Tensor::tensor<double,1,false>& xvv, hiperlife::Tensor::tensor<double,1,false>& normal, hiperlife::Tensor::tensor<double,3,false>& dnormal)
        {
            using namespace Tensor;
            for ( int i = 0; i < ddbf.shape()[0]; i++ )
            {
                d_Curva(dcurva(i,all,all,all).data(), ddbf(i,all,all).data(), xuu.data(), xuv.data(),xvv.data(),normal.data(),dnormal(i,all,all).data());
            }
        }

        void dd_Curva(double* dcurva_ij, double* ddbf_i, double* ddbf_j, double *xuu, double *xuv, double *xvv, double* dnormal_i, double *dnormal_j, double *ddnormal);
        inline void dd_Curva(Tensor::tensor<double,6,false>& ddcurva, Tensor::tensor<double,3,false>& ddbf, Tensor::tensor<double,1,false>& xuu, Tensor::tensor<double,1,false>& xuv, Tensor::tensor<double,1,false>& xvv, Tensor::tensor<double,3,false>& dnormal, Tensor::tensor<double,5,false>& ddnormal)
        {
            using namespace Tensor;

            tensor<double,3> ddnormal_ij(3,3,3);
            tensor<double,4> ddcurva_ij(3,3,2,2);
            for ( int i = 0; i < ddbf.shape()[0]; i++ )
            {
                for (int j = 0; j < ddbf.shape()[0]; j++)
                {
                    ddnormal_ij = ddnormal(i,all,j,all,all);
                    dd_Curva(ddcurva_ij.data(), ddbf(i, all,all).data(), ddbf(j, all,all).data(), xuu.data(), xuv.data(),xvv.data(),dnormal(i,all,all).data(),dnormal(j,all,all).data(),ddnormal_ij.data());
                    ddcurva(i,all,j,all,all,all) = ddcurva_ij;
                }
            }
        }




        void NormalGradientU (double *udn, double *dp_k, double *phi_1, double *phi_2, double *normal, double iJac, double *u);
        void MetricHessian(double *ddg, double *dp_kI, double *dp_kJ);

        void CurvatTensorGradient(double *dkabdxi, double *dbf_i, double *d2bf_i, double jac, double *xu, double *xv, double *xuu, double *xvv, double *xuv, double *normal);
        void CurvatTensorHessian(double *d2kabdxixj, double *d2bf_i, double *d2bf_j, double *xuu, double *xvv, double *xuv, double *dNdxi, double *dNdxj, double *d2Ndxidxj, double *xu, double *xv, double *normal, double *dbf_i, double *dbf_j, double *CS, double *kab, double *gAB);

        void MetricInvHessian(double *d2gAB, double *gAB, double *dgabdxi, double *dgabdxj, double *d2gab);

        void MeanCurvHessian(double* d2H, double *gAB, double* dgABdxi, double* dgABdxj, double* d2gAB, double *kab, double* dkabdxi, double* dkabdxj, double* d2kab);


        void DummyMeanCurvGradient(double *dH, double *d2bf_i, double *gab, double *gAB, double *kab, double *dgdI, double *xuu, double *xvv, double *xuv, double *normal, double *dnormalI);
        void CopyMeanCurvGradient(double *dH, double *d2bf_i, double *gAB, double *kab, double *dgdI, double *xuu, double *xvv, double *xuv, double *normal, double *dnormalI);

        void NewCurvatTensorGradient(double *dkabdxi, double *dbf_i, double *d2bf_i, double *normal, double *CS);

        void MetricInvGradient(double *dgAB, double *gAB, double *dgab);

        void NewMeanCurvGradient(double *dH, double *gAB, double *dgABdxi, double *kab, double *dkabdxi);

    }
}


#endif //LAGRANPARAM_H
