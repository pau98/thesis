/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_OffsetParam.h"

using namespace std;

namespace hiperlife
{
    namespace OffsetParam
    {



        void Parametrization(double *x, double *Dx, double *n, double *Dn,
                             double *u, int eNN, int DOF, int nDim, int auxIni, int nAux,
                             double *xe_nodes, double *ne_nodes, double *ue_nodes,
                             double *p_k, double *dp_k)
        {

            Math::MatProduct(x, 1, eNN, nDim, p_k, xe_nodes);
            Math::MatProduct(u, 1, eNN, DOF, p_k, ue_nodes);

            Array::Fill3D(n,0.0);
            for ( int i = 0; i < eNN; i++ )
                Math::AXPY(n,nDim,p_k[i],&ne_nodes[nAux*i+auxIni]);

            Math::AXPY(x, nDim,  u[0], n);

            Array::Fill(Dx, nDim * 2, 0.0);
            Array::Fill(Dn, nDim * 2, 0.0);
            for ( int i=0; i< eNN; i++ )
            {
                int iD    = i * nDim;
                int iiD   = i * nAux + auxIni;
                double dp_u  = dp_k[2*i  ];
                double dp_v  = dp_k[2*i+1];
                for ( int j=0; j<nDim; j++ )
                {
                    Dx[0*nDim+j] += dp_u * (xe_nodes[iD+j] + ue_nodes[DOF*i+0] * n[j] + u[0] * ne_nodes[iiD+j] );
                    Dx[1*nDim+j] += dp_v * (xe_nodes[iD+j] + ue_nodes[DOF*i+0] * n[j] + u[0] * ne_nodes[iiD+j] );
                    Dn[0*nDim+j] += dp_u * ne_nodes[iiD+j];
                    Dn[1*nDim+j] += dp_v * ne_nodes[iiD+j];
                }

            }


        }

        void Parametrization(double *x, double *Dx, double *DDx,
                             double *n, double *Dn, double *DDn,
                             double *u, int eNN, int DOF, int nDim, int auxIni, int nAux,
                             double *xe_nodes, double *ne_nodes, double *ue_nodes,
                             double *p_k, double *dp_k, double *hp_k)
        {

            Parametrization(x, Dx, n, Dn, u, eNN, DOF, nDim, auxIni, nAux, xe_nodes, ne_nodes, ue_nodes, p_k, dp_k);


            double Du[2];// = {0.0, 0.0};
            Array::Fill2D(Du,0.0);
            for (int i=0; i< eNN; i++)
            {
                double dp_u  = dp_k[2*i  ];
                double dp_v  = dp_k[2*i+1];

                Du[0] += dp_u * ue_nodes[DOF*i+0];
                Du[1] += dp_v * ue_nodes[DOF*i+0];
            }


            Array::Fill(DDx, 4*nDim, 0.0);
            Array::Fill(DDn, 4*nDim, 0.0);
            for (int i = 0; i < eNN; i++)
            {
                int iD    = i * nDim;
                int iiD   = i * nAux + auxIni;
                double hp_uu = hp_k[i*4  ];
                double hp_uv = hp_k[i*4+1];
                double hp_vv = hp_k[i*4+3];

                for (int j = 0; j < nDim; j++)
                {
                    DDx[       j] += hp_uu * (xe_nodes[iD+j] + ue_nodes[DOF*i+0] * n[j] + u[0] * ne_nodes[iiD+j] );
                    DDx[  nDim+j] += hp_uv * (xe_nodes[iD+j] + ue_nodes[DOF*i+0] * n[j] + u[0] * ne_nodes[iiD+j] );
                    DDx[3*nDim+j] += hp_vv * (xe_nodes[iD+j] + ue_nodes[DOF*i+0] * n[j] + u[0] * ne_nodes[iiD+j] );
                    DDn[       j] += hp_uu * ne_nodes[iiD+j];
                    DDn[  nDim+j] += hp_uv * ne_nodes[iiD+j];
                    DDn[3*nDim+j] += hp_vv * ne_nodes[iiD+j];
                }
            }

            for (int j=0; j<nDim; j++)
            {
                DDx[       j] += 2.0*Du[0] * Dn[j];
                DDx[  nDim+j] += Du[0] * Dn[nDim+j] + Du[1] * Dn[j];
                DDx[3*nDim+j] += 2.0*Du[1] * Dn[nDim+j];
            }

            Array::Copy(&DDx[2*nDim], 3, &DDx[1*nDim]);
            Array::Copy(&DDn[2*nDim], 3, &DDn[1*nDim]);
        }

        void Normal ( double *normal, double *Ip, double *iIp, double &J, double *Dx )
        {
            double inorm;
            double det, idet;

            // now the normal to the surface is computed
            Math::Cross(normal, Dx, &Dx[3]);
            inorm = Math::Norm3D( normal );

#ifdef DEBUG
            if (inorm < 1.0e-15)
            {
                throw runtime_error("OffsetParam::Normal - fails - norm|n|=0\n");
            }
            else
#endif
            {
                inorm = 1.0/inorm;
                for ( int i=0; i<3; i++ )
                    normal[i] *= inorm;
            }

            // First fundamental form
            //      | I0   I1 |
            //  I = |         |
            //      | I2   I3 |
            Ip[0] = Math::Dot3D(&Dx[0], &Dx[0]);
            Ip[1] = Math::Dot3D(&Dx[0], &Dx[3]);
            Ip[2] = Ip[1];
            Ip[3] = Math::Dot3D(&Dx[3], &Dx[3]);

            det  = Ip[0] * Ip[3] - Ip[1] * Ip[2];
            idet = 1.0/det;

            J = sqrt(det);

            //Inverse of the Metric tensor
            iIp[0] =  idet * Ip[3]; iIp[1] = -idet * Ip[2];
            iIp[2] = iIp[1];        iIp[3] =  idet * Ip[0];
        }


        void Curvatures ( double *normal, double *Ip, double *IIp, double *iIp, double &J, double *Dx, double *DDx )
        {

            Normal ( normal, Ip, iIp,J, Dx );

            // Second fundamental form
            //       | II0   II1 |
            //  II = |           |
            //       | II2   II3 |
            IIp[0] = Math::Dot3D(normal, DDx    );   // t.phi_11
            IIp[1] = Math::Dot3D(normal, &DDx[3]);   // t.phi_12
            IIp[2] = IIp[1];
            IIp[3] = Math::Dot3D(normal, &DDx[3*3]);   // t.phi_22
        }

        void ChristoffelSymbols ( double *normal, double *Ip, double *IIp, double *iIp, double &J, double *DIp, double *CS, double *Dx, double *DDx )
        {

            Curvatures ( normal, Ip, IIp, iIp, J, Dx, DDx );

            // Derivative of the metric (necessary for the Chrystoffel symbols)
            DIp[0]  = 2.0*Math::Dot3D(&DDx[0], &Dx[0]);                              //g_{00,0}
            DIp[1]  = 2.0*Math::Dot3D(&DDx[3], &Dx[0]);                              //g_{00,1}
            DIp[2]  = Math::Dot3D(&DDx[0], &Dx[3])+Math::Dot3D(&Dx[0], &DDx[3]);  //g_{01,0}
            DIp[3]  = Math::Dot3D(&DDx[3], &Dx[3])+Math::Dot3D(&Dx[0], &DDx[9]);  //g_{01,1}
            DIp[4]  = Math::Dot3D(&DDx[6], &Dx[0])+Math::Dot3D(&Dx[3], &DDx[0]);  //g_{10,0}
            DIp[5]  = Math::Dot3D(&DDx[9], &Dx[0])+Math::Dot3D(&Dx[3], &DDx[3]);  //g_{10,1}
            DIp[6]  = 2.0*Math::Dot3D(&Dx[3], &DDx[6]);                              //g_{11,0}
            DIp[7]  = 2.0*Math::Dot3D(&DDx[9], &Dx[3]);                              //g_{11,1}

            //
            //CS = 1/2[g^{ad}*(g_{bd,c}+g_{cd,b}-g_{bc,d})]
            // g^{ad}*(g_{bd,c}
            CS[0] = iIp[0] * DIp[0] + iIp[1] * DIp[2];
            CS[1] = iIp[0] * DIp[1] + iIp[1] * DIp[3];
            CS[2] = iIp[0] * DIp[4] + iIp[1] * DIp[6];
            CS[3] = iIp[0] * DIp[5] + iIp[1] * DIp[7];

            CS[4] = iIp[2] * DIp[0] + iIp[3] * DIp[2];
            CS[5] = iIp[2] * DIp[1] + iIp[3] * DIp[3];
            CS[6] = iIp[2] * DIp[4] + iIp[3] * DIp[6];
            CS[7] = iIp[2] * DIp[5] + iIp[3] * DIp[7];

            // + g^{ad} g_{cd,b}
            CS[0] += iIp[0] * DIp[0] + iIp[1] * DIp[2];
            CS[1] += iIp[0] * DIp[4] + iIp[1] * DIp[6];
            CS[2] += iIp[0] * DIp[1] + iIp[1] * DIp[3];
            CS[3] += iIp[0] * DIp[5] + iIp[1] * DIp[7];

            CS[4] += iIp[2] * DIp[0] + iIp[3] * DIp[2];
            CS[5] += iIp[2] * DIp[4] + iIp[3] * DIp[6];
            CS[6] += iIp[2] * DIp[1] + iIp[3] * DIp[3];
            CS[7] += iIp[2] * DIp[5] + iIp[3] * DIp[7];

            // - g^{ad} g_{bc,d}
            CS[0] -= iIp[0] * DIp[0] + iIp[1] * DIp[1];
            CS[1] -= iIp[0] * DIp[2] + iIp[1] * DIp[3];
            CS[2] -= iIp[0] * DIp[4] + iIp[1] * DIp[5];
            CS[3] -= iIp[0] * DIp[6] + iIp[1] * DIp[7];

            CS[4] -= iIp[2] * DIp[0] + iIp[3] * DIp[1];
            CS[5] -= iIp[2] * DIp[2] + iIp[3] * DIp[3];
            CS[6] -= iIp[2] * DIp[4] + iIp[3] * DIp[5];
            CS[7] -= iIp[2] * DIp[6] + iIp[3] * DIp[7];

            for ( int i = 0; i < 8; i++ )
                CS[i] *= 0.5;
        }


        void ParametrizationHeightDerivatives(double *dx, double *dDx, double &p_kI, double *dp_kI, double *n0, double *Dn0)
        {
            int nDim = 3;
            Array::Fill(dx,nDim, 0.0);
            Math::AXPY(dx, nDim, p_kI, n0);

            Array::Fill(dDx, nDim * 2, 0.0);
            Math::AXPY( dDx,       nDim, dp_kI[0], n0);
            Math::AXPY(&dDx[nDim], nDim, dp_kI[1], n0);
            Math::AXPY( dDx,       nDim, p_kI, Dn0);
            Math::AXPY(&dDx[nDim], nDim, p_kI, &Dn0[nDim]);
        }

        void ParametrizationHeightDerivatives(double *dx, double *dDx, double *dDDx, double &p_kI,
                                              double *dp_kI, double *hp_kI, double *n0, double *Dn0, double *DDn0 )
        {
            int nDim = 3;
            ParametrizationHeightDerivatives(dx, dDx, p_kI, dp_kI, n0, Dn0);

            Array::Fill(dDDx, nDim * 4, 0.0);
            Math::AXPY(&dDDx[0 * nDim], nDim, hp_kI[0], n0);
            Math::AXPY(&dDDx[1 * nDim], nDim, hp_kI[1], n0);
            Math::AXPY(&dDDx[3 * nDim], nDim, hp_kI[3], n0);

            Math::AXPY(&dDDx[0 * nDim], nDim, 2.0 * dp_kI[0], &Dn0[nDim * 0]);
            Math::AXPY(&dDDx[1 * nDim], nDim,       dp_kI[0], &Dn0[nDim * 1]);
            Math::AXPY(&dDDx[1 * nDim], nDim,       dp_kI[1], &Dn0[nDim * 0]);
            Math::AXPY(&dDDx[3 * nDim], nDim, 2.0 * dp_kI[1], &Dn0[nDim * 1]);
            Array::Copy( &dDDx[2 * nDim], 3, &dDDx[1 * nDim]);

            Math::AXPY(dDDx, nDim * 4, p_kI, DDn0);
        }

        void NormalHeightFirstDerivatives(double *dIp, double *diIp, double &dJ, double *dcross, double *dnormal,
                                          double *Dx, double *dDx, double *normal, double *iIp, double &iJ)
        {
            int nDim = 3;

            dIp[0] = 2.0 * Math::Dot3D(&dDx[0 * nDim], &Dx[0 * nDim]);
            dIp[1] = Math::Dot3D(&dDx[0 * nDim], &Dx[1 * nDim]) + Math::Dot3D(&dDx[1 * nDim], &Dx[0 * nDim]);
            dIp[2] = dIp[1];
            dIp[3] = 2.0 * Math::Dot3D(&dDx[1 * nDim], &Dx[1 * nDim]);

            double vaux[3];
            Math::Cross(dcross, &dDx[0 * nDim], &Dx[1 * nDim]);
            Math::Cross(vaux, &Dx[0 * nDim], &dDx[1 * nDim]);
            Math::AXPY(dcross, nDim, 1.0, vaux);
            dJ = Math::Dot3D(dcross, normal);

            // First derivative of the normal
            Array::Fill3D(dnormal, 0.0);
            Math::AXPY(dnormal, 3, iJ, dcross);
            Math::AXPY(dnormal, 3, -(iJ) * (dJ), normal);

            double Maux[4];
            Math::MatProduct(Maux, 2,2,2, iIp,  dIp);
            Math::MatProduct(diIp, 2,2,2, Maux, iIp);
            Math::AX(diIp, 4, -1.0);
        }

        void CurvatureHeightFirstDerivatives(double *dIp, double *diIp, double &dJ, double *dcross, double *dnormal, double *dIIp ,
                                             double *Dx, double *DDx, double *dDx, double *dDDx, double *normal, double *iIp, double &iJ)
        {
            int nDim = 3;

            NormalHeightFirstDerivatives(dIp, diIp, dJ, dcross, dnormal, Dx, dDx, normal, iIp, iJ);

            dIIp[0] = Math::Dot3D(&dDDx[0 * nDim], normal) + Math::Dot3D(&DDx[0 * nDim], dnormal);
            dIIp[1] = Math::Dot3D(&dDDx[1 * nDim], normal) + Math::Dot3D(&DDx[1 * nDim], dnormal);
            dIIp[2] = dIIp[1];
            dIIp[3] = Math::Dot3D(&dDDx[3 * nDim], normal) + Math::Dot3D(&DDx[3 * nDim], dnormal);
        }


        void ChristoffelSymbolsHeightFirstDerivatives(double *dIp, double *diIp, double &dJ, double *dcross, double *dnormal,
                                       double *dIIp, double *dDIp, double *dCS, double *Dx, double *DDx,
                                       double *dDx, double *dDDx, double *normal, double *iIp, double *DIp, double &iJ)
        {

            CurvatureHeightFirstDerivatives(dIp, diIp, dJ, dcross, dnormal, dIIp, Dx, DDx, dDx, dDDx, normal, iIp, iJ);

            // Derivative of the metric (necessary for the Chrystoffel symbols)
            dDIp[0] = 2.0 * Math::Dot3D(&dDDx[0], &Dx[0]) +
                      2.0 * Math::Dot3D(&DDx[0], &dDx[0]);                              //g_{00,0}
            dDIp[1] = 2.0 * Math::Dot3D(&dDDx[3], &Dx[0]) +
                      2.0 * Math::Dot3D(&DDx[3], &dDx[0]);                              //g_{00,1}
            dDIp[2] = Math::Dot3D(&dDDx[0], &Dx[3]) + Math::Dot3D(&dDx[0], &DDx[3]) +
                      Math::Dot3D(&DDx[0], &dDx[3]) + Math::Dot3D(&Dx[0], &dDDx[3]);  //g_{01,0}
            dDIp[3] = Math::Dot3D(&dDDx[3], &Dx[3]) + Math::Dot3D(&dDx[0], &DDx[9]) +
                      Math::Dot3D(&DDx[3], &dDx[3]) + Math::Dot3D(&Dx[0], &dDDx[9]);  //g_{01,1}
            dDIp[4] = Math::Dot3D(&dDDx[3], &Dx[0]) + Math::Dot3D(&dDx[3], &DDx[0]) +
                      Math::Dot3D(&DDx[3], &dDx[0]) + Math::Dot3D(&Dx[3], &dDDx[0]);  //g_{10,0}
            dDIp[5] = Math::Dot3D(&dDDx[9], &Dx[0]) + Math::Dot3D(&dDx[3], &DDx[3]) +
                      Math::Dot3D(&DDx[9], &dDx[0]) + Math::Dot3D(&Dx[3], &dDDx[3]);  //g_{10,1}
            dDIp[6] = 2.0 * Math::Dot3D(&dDx[3], &DDx[3]) +
                      2.0 * Math::Dot3D(&Dx[3], &dDDx[3]);                              //g_{11,0}
            dDIp[7] = 2.0 * Math::Dot3D(&dDDx[9], &Dx[3]) +
                      2.0 * Math::Dot3D(&DDx[9], &dDx[3]);                              //g_{11,1}

            //
            //CS = 1/2[g^{ad}*(g_{bd,c}+g_{cd,b}-g_{bc,d})]
            // g^{ad}*(g_{bd,c}
            dCS[0] = diIp[0] * DIp[0] + diIp[1] * DIp[2] + iIp[0] * dDIp[0] + iIp[1] * dDIp[2];
            dCS[1] = diIp[0] * DIp[1] + diIp[1] * DIp[3] + iIp[0] * dDIp[1] + iIp[1] * dDIp[3];
            dCS[2] = diIp[0] * DIp[4] + diIp[1] * DIp[6] + iIp[0] * dDIp[4] + iIp[1] * dDIp[6];
            dCS[3] = diIp[0] * DIp[5] + diIp[1] * DIp[7] + iIp[0] * dDIp[5] + iIp[1] * dDIp[7];

            dCS[4] = diIp[2] * DIp[0] + diIp[3] * DIp[2] + iIp[2] * dDIp[0] + iIp[3] * dDIp[2];
            dCS[5] = diIp[2] * DIp[1] + diIp[3] * DIp[3] + iIp[2] * dDIp[1] + iIp[3] * dDIp[3];
            dCS[6] = diIp[2] * DIp[4] + diIp[3] * DIp[6] + iIp[2] * dDIp[4] + iIp[3] * dDIp[6];
            dCS[7] = diIp[2] * DIp[5] + diIp[3] * DIp[7] + iIp[2] * dDIp[5] + iIp[3] * dDIp[7];

            // + g^{ad} g_{cd,b}
            dCS[0] += diIp[0] * DIp[0] + diIp[1] * DIp[2] + iIp[0] * dDIp[0] + iIp[1] * dDIp[2];
            dCS[1] += diIp[0] * DIp[4] + diIp[1] * DIp[6] + iIp[0] * dDIp[4] + iIp[1] * dDIp[6];
            dCS[2] += diIp[0] * DIp[1] + diIp[1] * DIp[3] + iIp[0] * dDIp[1] + iIp[1] * dDIp[3];
            dCS[3] += diIp[0] * DIp[5] + diIp[1] * DIp[7] + iIp[0] * dDIp[5] + iIp[1] * dDIp[7];


            dCS[4] += diIp[2] * DIp[0] + diIp[3] * DIp[2] + iIp[2] * dDIp[0] + iIp[3] * dDIp[2];
            dCS[5] += diIp[2] * DIp[4] + diIp[3] * DIp[6] + iIp[2] * dDIp[4] + iIp[3] * dDIp[6];
            dCS[6] += diIp[2] * DIp[1] + diIp[3] * DIp[3] + iIp[2] * dDIp[1] + iIp[3] * dDIp[3];
            dCS[7] += diIp[2] * DIp[5] + diIp[3] * DIp[7] + iIp[2] * dDIp[5] + iIp[3] * dDIp[7];

            // - g^{ad} g_{bc,d}
            dCS[0] -= diIp[0] * DIp[0] + diIp[1] * DIp[1] + iIp[0] * dDIp[0] + iIp[1] * dDIp[1];
            dCS[1] -= diIp[0] * DIp[2] + diIp[1] * DIp[3] + iIp[0] * dDIp[2] + iIp[1] * dDIp[3];
            dCS[2] -= diIp[0] * DIp[4] + diIp[1] * DIp[5] + iIp[0] * dDIp[4] + iIp[1] * dDIp[5];
            dCS[3] -= diIp[0] * DIp[6] + diIp[1] * DIp[7] + iIp[0] * dDIp[6] + iIp[1] * dDIp[7];

            dCS[4] -= diIp[2] * DIp[0] + diIp[3] * DIp[1] + iIp[2] * dDIp[0] + iIp[3] * dDIp[1];
            dCS[5] -= diIp[2] * DIp[2] + diIp[3] * DIp[3] + iIp[2] * dDIp[2] + iIp[3] * dDIp[3];
            dCS[6] -= diIp[2] * DIp[4] + diIp[3] * DIp[5] + iIp[2] * dDIp[4] + iIp[3] * dDIp[5];
            dCS[7] -= diIp[2] * DIp[6] + diIp[3] * DIp[7] + iIp[2] * dDIp[6] + iIp[3] * dDIp[7];

            for (int i = 0; i < 8; i++)
                dCS[i] *= 0.5;
        }

        void NormalHeightSecondDerivatives( double *ddIp, double *ddiIp, double *ddcross, double *ddnormal, double &ddJ,
                                               double *dDxI, double *dDxJ, double *dIpI, double *diIpJ,  double *normal, double *dCrossI,
                                               double *dnormalI, double *dnormalJ, double *iIp, double &iJ, double &dJI, double &dJJ)
        {
            int nDim = 3;

            ddIp[0] = 2.0 * Math::Dot3D(&dDxI[0 * nDim], &dDxJ[0 * nDim]);
            ddIp[1] = Math::Dot3D(&dDxI[0 * nDim], &dDxJ[1 * nDim]) + Math::Dot3D(&dDxJ[0 * nDim], &dDxI[1 * nDim]);
            ddIp[2] = ddIp[1];
            ddIp[3] = 2.0 * Math::Dot3D(&dDxI[1 * nDim], &dDxJ[1 * nDim]);

            //Second derivative of the inverse of the metric tensor
            double Maux1[4], Maux2[4];
            Array::Fill(ddiIp, 4, 0.0);
            Math::MatProduct(Maux1, 2, 2, 2, diIpJ, dIpI);
            Math::MatProduct(Maux2, 2, 2, 2, Maux1, iIp);
            Math::AXPY(ddiIp, 4, -1.0, Maux2);
            Math::MatProduct(Maux1, 2,2,2, iIp, ddIp);
            Math::MatProduct(Maux2, 2,2,2, Maux1, iIp);
            Math::AXPY(ddiIp, 4, -1.0, Maux2);
            Math::MatProduct(Maux1, 2,2,2, iIp, dIpI);
            Math::MatProduct(Maux2, 2,2,2, Maux1, diIpJ);
            Math::AXPY(ddiIp, 4, -1.0, Maux2);

            //Second derivative of the cross product
            double vaux[3];
            Math::Cross(vaux, &dDxI[0 * nDim], &dDxJ[1 * nDim]);
            Math::Cross(ddcross, &dDxJ[0 * nDim], &dDxI[1 * nDim]);
            Math::AXPY(ddcross, nDim, 1.0, vaux);

            //Second derivative of the Jacobian
            ddJ = Math::Dot3D(ddcross, normal) + Math::Dot3D(dCrossI, dnormalJ);

            //Second derivative of the normal
            Array::Fill3D(ddnormal, 0.0);
            Math::AXPY(ddnormal, 3, iJ, ddcross);
            Math::AXPY(ddnormal, 3, -iJ * ddJ, normal);
            Math::AXPY(ddnormal, 3, -iJ * dJI, dnormalJ);
            Math::AXPY(ddnormal, 3, -iJ * dJJ, dnormalI);
        }

        void CurvatureHeightSecondDerivatives( double *ddIp, double *ddiIp, double *ddcross, double *ddnormal, double &ddJ,
                                            double *ddIIp,double *DDx,double *dDxI, double *dDDxI,
                                            double *dDxJ, double *dDDxJ, double *dIpI,
                                            double *diIpJ,  double *normal, double *dCrossI,
                                            double *dnormalI, double *dnormalJ,
                                            double *iIp, double &iJ, double &dJI, double &dJJ)
        {
            int nDim = 3;
            NormalHeightSecondDerivatives( ddIp, ddiIp, ddcross, ddnormal, ddJ,dDxI, dDxJ, dIpI, diIpJ,  normal,
                                           dCrossI, dnormalI, dnormalJ, iIp, iJ, dJI, dJJ);


            //Second derivative of the second fundamental form
            ddIIp[0] = Math::Dot3D(&dDDxI[0 * nDim], dnormalJ) + Math::Dot3D(&dDDxJ[0 * nDim], dnormalI) +
                       Math::Dot3D(&DDx[0 * nDim], ddnormal);
            ddIIp[1] = Math::Dot3D(&dDDxI[1 * nDim], dnormalJ) + Math::Dot3D(&dDDxJ[1 * nDim], dnormalI) +
                       Math::Dot3D(&DDx[1 * nDim], ddnormal);
            ddIIp[2] = Math::Dot3D(&dDDxI[2 * nDim], dnormalJ) + Math::Dot3D(&dDDxJ[2 * nDim], dnormalI) +
                       Math::Dot3D(&DDx[2 * nDim], ddnormal);
            ddIIp[3] = Math::Dot3D(&dDDxI[3 * nDim], dnormalJ) + Math::Dot3D(&dDDxJ[3 * nDim], dnormalI) +
                       Math::Dot3D(&DDx[3 * nDim], ddnormal);
        }

        void ChristoffelSymbolsHeightSecondDerivatives(double *ddIp, double *ddiIp, double *ddcross, double *ddnormal, double &ddJ,
                                                       double *ddIIp, double *ddDIp, double *ddCS,
                                                       double *DDx, double *DIp,
                                                       double *dDxI, double *dDDxI, double *dDxJ, double *dDDxJ,
                                                       double *dIpI, double *diIpI, double *diIpJ,
                                                       double *dDIpI, double *dDIpJ,
                                                       double *normal, double *dCrossI, double *dnormalI,
                                                       double *dnormalJ,
                                                       double *iIp, double &iJ, double &dJI, double &dJJ)
        {
            CurvatureHeightSecondDerivatives( ddIp, ddiIp, ddcross, ddnormal, ddJ, ddIIp,DDx, dDxI, dDDxI, dDxJ, dDDxJ, dIpI,
                                              diIpJ,  normal, dCrossI, dnormalI, dnormalJ, iIp, iJ, dJI, dJJ);

            // Derivative of the metric (necessary for the Chrystoffel symbols)
            ddDIp[0] = 2.0 * Math::Dot3D(&dDDxI[0], &dDxJ[0]) +
                       2.0 * Math::Dot3D(&dDDxJ[0], &dDxI[0]);                              //g_{00,0}
            ddDIp[1] = 2.0 * Math::Dot3D(&dDDxI[3], &dDxJ[0]) +
                       2.0 * Math::Dot3D(&dDDxJ[3], &dDxI[0]);                              //g_{00,1}
            ddDIp[2] = Math::Dot3D(&dDDxI[0], &dDxJ[3]) + Math::Dot3D(&dDxI[0], &dDDxJ[3]) +
                       Math::Dot3D(&dDDxJ[0], &dDxI[3]) + Math::Dot3D(&dDxJ[0], &dDDxI[3]);  //g_{01,0}
            ddDIp[3] = Math::Dot3D(&dDDxI[3], &dDxJ[3]) + Math::Dot3D(&dDxI[0], &dDDxJ[9]) +
                       Math::Dot3D(&dDDxJ[3], &dDxI[3]) + Math::Dot3D(&dDxJ[0], &dDDxI[9]);  //g_{01,1}
            ddDIp[4] = Math::Dot3D(&dDDxI[3], &dDxJ[0]) + Math::Dot3D(&dDxI[3], &dDDxJ[0]) +
                       Math::Dot3D(&dDDxJ[3], &dDxI[0]) + Math::Dot3D(&dDxJ[3], &dDDxI[0]);  //g_{10,0}
            ddDIp[5] = Math::Dot3D(&dDDxI[9], &dDxJ[0]) + Math::Dot3D(&dDxI[3], &dDDxJ[3]) +
                       Math::Dot3D(&dDDxJ[9], &dDxI[0]) + Math::Dot3D(&dDxJ[3], &dDDxI[3]);  //g_{10,1}
            ddDIp[6] = 2.0 * Math::Dot3D(&dDxJ[3], &dDDxI[3]) +
                       2.0 * Math::Dot3D(&dDDxJ[3], &dDxI[3]);                              //g_{11,0}
            ddDIp[7] = 2.0 * Math::Dot3D(&dDDxI[9], &dDxJ[3]) +
                       2.0 * Math::Dot3D(&dDDxJ[9], &dDxI[3]);                              //g_{11,1}

            //
            //CS = 1/2[g^{ad}*(g_{bd,c}+g_{cd,b}-g_{bc,d})]
            // g^{ad}*(g_{bd,c}
            ddCS[0] = ddiIp[0] * DIp[0] + ddiIp[1] * DIp[2] + diIpI[0] * dDIpJ[0] + diIpI[1] * dDIpJ[2] +
                      diIpJ[0] * dDIpI[0] + diIpJ[1] * dDIpI[2] + iIp[0] * ddDIp[0] + iIp[1] * ddDIp[2];
            ddCS[1] = ddiIp[0] * DIp[1] + ddiIp[1] * DIp[3] + diIpI[0] * dDIpJ[1] + diIpI[1] * dDIpJ[3] +
                      diIpJ[0] * dDIpI[1] + diIpJ[1] * dDIpI[3] + iIp[0] * ddDIp[1] + iIp[1] * ddDIp[3];
            ddCS[2] = ddiIp[0] * DIp[4] + ddiIp[1] * DIp[6] + diIpI[0] * dDIpJ[4] + diIpI[1] * dDIpJ[6] +
                      diIpJ[0] * dDIpI[4] + diIpJ[1] * dDIpI[6] + iIp[0] * ddDIp[4] + iIp[1] * ddDIp[6];
            ddCS[3] = ddiIp[0] * DIp[5] + ddiIp[1] * DIp[7] + diIpI[0] * dDIpJ[5] + diIpI[1] * dDIpJ[7] +
                      diIpJ[0] * dDIpI[5] + diIpJ[1] * dDIpI[7] + iIp[0] * ddDIp[5] + iIp[1] * ddDIp[7];

            ddCS[4] = ddiIp[2] * DIp[0] + ddiIp[3] * DIp[2] + diIpI[2] * dDIpJ[0] + diIpI[3] * dDIpJ[2] +
                      diIpJ[2] * dDIpI[0] + diIpJ[3] * dDIpI[2] + iIp[2] * ddDIp[0] + iIp[3] * ddDIp[2];
            ddCS[5] = ddiIp[2] * DIp[1] + ddiIp[3] * DIp[3] + diIpI[2] * dDIpJ[1] + diIpI[3] * dDIpJ[3] +
                      diIpJ[2] * dDIpI[1] + diIpJ[3] * dDIpI[3] + iIp[2] * ddDIp[1] + iIp[3] * ddDIp[3];
            ddCS[6] = ddiIp[2] * DIp[4] + ddiIp[3] * DIp[6] + diIpI[2] * dDIpJ[4] + diIpI[3] * dDIpJ[6] +
                      diIpJ[2] * dDIpI[4] + diIpJ[3] * dDIpI[6] + iIp[2] * ddDIp[4] + iIp[3] * ddDIp[6];
            ddCS[7] = ddiIp[2] * DIp[5] + ddiIp[3] * DIp[7] + diIpI[2] * dDIpJ[5] + diIpI[3] * dDIpJ[7] +
                      diIpJ[2] * dDIpI[5] + diIpJ[3] * dDIpI[7] + iIp[2] * ddDIp[5] + iIp[3] * ddDIp[7];

            // + g^{ad} g_{cd,b}
            ddCS[0] += ddiIp[0] * DIp[0] + ddiIp[1] * DIp[2] + diIpI[0] * dDIpJ[0] + diIpI[1] * dDIpJ[2] +
                       diIpJ[0] * dDIpI[0] + diIpJ[1] * dDIpI[2] + iIp[0] * ddDIp[0] + iIp[1] * ddDIp[2];
            ddCS[1] += ddiIp[0] * DIp[4] + ddiIp[1] * DIp[6] + diIpI[0] * dDIpJ[4] + diIpI[1] * dDIpJ[6] +
                       diIpJ[0] * dDIpI[4] + diIpJ[1] * dDIpI[6] + iIp[0] * ddDIp[4] + iIp[1] * ddDIp[6];
            ddCS[2] += ddiIp[0] * DIp[1] + ddiIp[1] * DIp[3] + diIpI[0] * dDIpJ[1] + diIpI[1] * dDIpJ[3] +
                       diIpJ[0] * dDIpI[1] + diIpJ[1] * dDIpI[3] + iIp[0] * ddDIp[1] + iIp[1] * ddDIp[3];
            ddCS[3] += ddiIp[0] * DIp[5] + ddiIp[1] * DIp[7] + diIpI[0] * dDIpJ[5] + diIpI[1] * dDIpJ[7] +
                       diIpJ[0] * dDIpI[5] + diIpJ[1] * dDIpI[7] + iIp[0] * ddDIp[5] + iIp[1] * ddDIp[7];

            ddCS[4] += ddiIp[2] * DIp[0] + ddiIp[3] * DIp[2] + diIpI[2] * dDIpJ[0] + diIpI[3] * dDIpJ[2] +
                       diIpJ[2] * dDIpI[0] + diIpJ[3] * dDIpI[2] + iIp[2] * ddDIp[0] + iIp[3] * ddDIp[2];
            ddCS[5] += ddiIp[2] * DIp[4] + ddiIp[3] * DIp[6] + diIpI[2] * dDIpJ[4] + diIpI[3] * dDIpJ[6] +
                       diIpJ[2] * dDIpI[4] + diIpJ[3] * dDIpI[6] + iIp[2] * ddDIp[4] + iIp[3] * ddDIp[6];
            ddCS[6] += ddiIp[2] * DIp[1] + ddiIp[3] * DIp[3] + diIpI[2] * dDIpJ[1] + diIpI[3] * dDIpJ[3] +
                       diIpJ[2] * dDIpI[1] + diIpJ[3] * dDIpI[3] + iIp[2] * ddDIp[1] + iIp[3] * ddDIp[3];
            ddCS[7] += ddiIp[2] * DIp[5] + ddiIp[3] * DIp[7] + diIpI[2] * dDIpJ[5] + diIpI[3] * dDIpJ[7] +
                       diIpJ[2] * dDIpI[5] + diIpJ[3] * dDIpI[7] + iIp[2] * ddDIp[5] + iIp[3] * ddDIp[7];

            // - g^{ad} g_{bc,d}
            ddCS[0] -= ddiIp[0] * DIp[0] + ddiIp[1] * DIp[1] + diIpI[0] * dDIpJ[0] + diIpI[1] * dDIpJ[1] +
                       diIpJ[0] * dDIpI[0] + diIpJ[1] * dDIpI[1] + iIp[0] * ddDIp[0] + iIp[1] * ddDIp[1];
            ddCS[1] -= ddiIp[0] * DIp[2] + ddiIp[1] * DIp[3] + diIpI[0] * dDIpJ[2] + diIpI[1] * dDIpJ[3] +
                       diIpJ[0] * dDIpI[2] + diIpJ[1] * dDIpI[3] + iIp[0] * ddDIp[2] + iIp[1] * ddDIp[3];
            ddCS[2] -= ddiIp[0] * DIp[4] + ddiIp[1] * DIp[5] + diIpI[0] * dDIpJ[4] + diIpI[1] * dDIpJ[5] +
                       diIpJ[0] * dDIpI[4] + diIpJ[1] * dDIpI[5] + iIp[0] * ddDIp[4] + iIp[1] * ddDIp[5];
            ddCS[3] -= ddiIp[0] * DIp[6] + ddiIp[1] * DIp[7] + diIpI[0] * dDIpJ[6] + diIpI[1] * dDIpJ[7] +
                       diIpJ[0] * dDIpI[6] + diIpJ[1] * dDIpI[7] + iIp[0] * ddDIp[6] + iIp[1] * ddDIp[7];

            ddCS[4] -= ddiIp[2] * DIp[0] + ddiIp[3] * DIp[1] + diIpI[2] * dDIpJ[0] + diIpI[3] * dDIpJ[1] +
                       diIpJ[2] * dDIpI[0] + diIpJ[3] * dDIpI[1] + iIp[2] * ddDIp[0] + iIp[3] * ddDIp[1];
            ddCS[5] -= ddiIp[2] * DIp[2] + ddiIp[3] * DIp[3] + diIpI[2] * dDIpJ[2] + diIpI[3] * dDIpJ[3] +
                       diIpJ[2] * dDIpI[2] + diIpJ[3] * dDIpI[3] + iIp[2] * ddDIp[2] + iIp[3] * ddDIp[3];
            ddCS[6] -= ddiIp[2] * DIp[4] + ddiIp[3] * DIp[5] + diIpI[2] * dDIpJ[4] + diIpI[3] * dDIpJ[5] +
                       diIpJ[2] * dDIpI[4] + diIpJ[3] * dDIpI[5] + iIp[2] * ddDIp[4] + iIp[3] * ddDIp[5];
            ddCS[7] -= ddiIp[2] * DIp[6] + ddiIp[3] * DIp[7] + diIpI[2] * dDIpJ[6] + diIpI[3] * dDIpJ[7] +
                       diIpJ[2] * dDIpI[6] + diIpJ[3] * dDIpI[7] + iIp[2] * ddDIp[6] + iIp[3] * ddDIp[7];

            for (int i = 0; i < 8; i++)
                ddCS[i] *= 0.5;

        }
    }
}
