/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include "hl_ConstitutiveModels_Elasticity.h"

namespace hiperlife
{
    namespace ConstitutiveModels
    {
        namespace LinearElasticity
        {
            void elasticityTensor(tensor<double, 4> &C, const double C_L, const double C_T, const double C_S, const int pDim) //FIXME: functions start with lower case letters
            {
                // Reset to zero
                C(all, all, all, all) = 0.0;

                // Fill tensor<double,4,false> C (nDim , nDim , nDim , nDim);
                for (int i = 0; i < pDim; ++i)
                {
                    C(i, i, i, i) = C_L;
                    for (int j = 0; j < pDim; ++j)
                    {
                        if (i != j)
                        {
                            C(i, i, j, j) = C_T;
                            C(i, j, i, j) = C_S;
                            C(i, j, j, i) = C_S;
                        }
                    }
                }
            }

            void elasticityTensor(std::vector<double> &C, const double C_L, const double C_T, const double C_S, const int pDim)
            {
                C.resize(pDim * pDim * pDim * pDim);
                for (int i = 0; i < pDim; ++i)
                {
                    C[i * 8 + i * 4 + i * pDim + i] = C_L;
                    for (int j = 0; j < pDim; ++j)
                        if (i != j)
                        {
                            C[i * 8 + i * 4 + j * 2 + j] = C_T;
                            C[i * 8 + j * 4 + i * 2 + j] = C_S;
                            C[i * 8 + j * 4 + j * 2 + i] = C_S;
                        }
                }
            }

            void gradElasticityTensor(tensor<double, 6> &H, const double C_L, const double C_T, const double C_S, const double lMech, const int pDim)
            {
                // Reset to zero
                H(all, all, all, all, all, all) = 0.0;

                // Fill tensor<double,6,false> H (nDim , nDim , nDim , nDim , nDim , nDim);
                for (int i = 0; i < pDim; ++i)
                {
                    for (int k = 0; k < pDim; ++k)
                    {
                        H(i, i, k, i, i, k) = lMech * lMech * C_L;
                        for (int j = 0; j < pDim; ++j)
                        {
                            if (i != j)
                            {
                                H(i, i, k, j, j, k) = lMech * lMech * C_T;
                                H(i, j, k, i, j, k) = lMech * lMech * C_S;
                                H(i, j, k, j, i, k) = lMech * lMech * C_S;
                            }
                        }
                    }
                }
            }

            void gradElasticityTensor(std::vector<double> &H, const double C_L, const double C_T, const double C_S, const double lMech, const int pDim)
            {
                H.resize(pDim * pDim * pDim * pDim * pDim * pDim);
                for (int i = 0; i < pDim; ++i)
                {
                    for (int k = 0; k < pDim; ++k)
                    {
                        H[i * 32 + i * 16 + k * 8 + i * 4 + i * 2 + k] = lMech * lMech * C_L;
                        for (int j = 0; j < pDim; ++j)
                        {
                            if (i != j)
                            {
                                H[i * 32 + i * 16 + k * 8 + j * 4 + j * 2 + k] = lMech * lMech * C_T;
                                H[i * 32 + j * 16 + k * 8 + i * 4 + j * 2 + k] = lMech * lMech * C_S;
                                H[i * 32 + j * 16 + k * 8 + j * 4 + i * 2 + k] = lMech * lMech * C_S;
                            }
                        }
                    }
                }
            }

            void strain(tensor<double, 4> &strn, tensor<double, 2> globDBF, const int pDim)
            {
                strn(all, all, all, all) = 0.0;
                for (int i = 0; i < pDim; ++i)
                {
                    strn(i, i, i, all) = globDBF(all, i);
                    for (int j = 0; j < pDim; ++j)
                        if (j != i)
                        {
                            strn(i, j, j, all) += 0.5 * globDBF(all, i);
                            strn(j, i, j, all) += 0.5 * globDBF(all, i);
                        }
                }
            }

            void gradStrain(tensor<double, 5> &gradStrn, tensor<double, 3> globHBF, const int pDim)
            {
                gradStrn(all, all, all, all, all) = 0.0;
                for (int i = 0; i < pDim; ++i)
                {
                    gradStrn(i, i, i, i, all) += globHBF(all, i, i);
                    for (int j = 0; j < pDim; ++j)
                        if (j != i)
                        {
                            gradStrn(i, j, i, j, all) += 0.5 * globHBF(all, i, i);
                            gradStrn(j, i, i, j, all) += 0.5 * globHBF(all, i, i);

                            gradStrn(i, i, j, i, all) += globHBF(all, i, j);
                            gradStrn(i, j, i, i, all) += 0.5 * globHBF(all, j, i);
                            gradStrn(j, i, i, i, all) += 0.5 * globHBF(all, j, i);
                            for (int k = 0; k < pDim; ++k)
                                if (k != i and k != j)
                                {
                                    gradStrn(i, k, j, k, all) += 0.5 * globHBF(all, i, j);
                                    gradStrn(k, i, j, k, all) += 0.5 * globHBF(all, i, j);
                                }
                        }
                }
            }

            void hessStrain(tensor<double, 6> &hessStrn, tensor<double, 4> globTBF, const int pDim)
            {
                hessStrn(all, all, all, all, all, all) = 0.0;
                for (int i = 0; i < pDim; ++i)
                {
                    hessStrn(i, i, i, i, i, all) += globTBF(all, i, i, i);
                    for (int j = 0; j < pDim; ++j)
                        if (j != i)
                        {
                            hessStrn(i, j, i, i, j, all) += 0.5 * globTBF(all, i, i, i);
                            hessStrn(j, i, i, i, j, all) += 0.5 * globTBF(all, i, i, i);

                            hessStrn(i, i, i, j, i, all) += globTBF(all, i, i, j);
                            hessStrn(i, j, i, j, j, all) += 0.5 * globTBF(all, i, i, j);
                            hessStrn(j, i, i, j, j, all) += 0.5 * globTBF(all, i, i, j);

                            hessStrn(i, i, j, i, i, all) += globTBF(all, i, j, i);
                            hessStrn(i, i, j, j, i, all) += globTBF(all, i, j, j);

                            hessStrn(i, j, i, i, i, all) += 0.5 * globTBF(all, i, j, i);
                            hessStrn(i, j, i, j, i, all) += 0.5 * globTBF(all, i, j, j);

                            hessStrn(j, i, i, i, i, all) += 0.5 * globTBF(all, i, j, i);
                            hessStrn(j, i, i, j, i, all) += 0.5 * globTBF(all, i, j, j);

                            for (int k = 0; k < pDim; ++k)
                                if (k != i and k != j)
                                {
                                    hessStrn(i, j, i, k, j, all) += 0.5 * globTBF(all, i, i, k);
                                    hessStrn(j, i, i, k, j, all) += 0.5 * globTBF(all, i, i, k);
                                    hessStrn(i, i, j, k, i, all) += globTBF(all, i, j, k);
                                    hessStrn(i, j, i, k, i, all) += 0.5 * globTBF(all, i, j, k);
                                    hessStrn(j, i, i, k, i, all) += 0.5 * globTBF(all, i, j, k);

                                    hessStrn(i, k, j, i, k, all) += 0.5 * globTBF(all, i, j, i);
                                    hessStrn(i, k, j, j, k, all) += 0.5 * globTBF(all, i, j, j);
                                    hessStrn(i, k, j, k, k, all) += 0.5 * globTBF(all, i, j, k);

                                    hessStrn(k, i, j, i, k, all) += 0.5 * globTBF(all, i, j, i);
                                    hessStrn(k, i, j, j, k, all) += 0.5 * globTBF(all, i, j, j);
                                    hessStrn(k, i, j, k, k, all) += 0.5 * globTBF(all, i, j, k);
                                }
                        }
                }
            }
        } // namespace LinearElasticity
    } // namespace ConstitutiveModels
} // namespace hiperlife
