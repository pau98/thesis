/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HPLFE_OFFSETPARAM_H
#define HPLFE_OFFSETPARAM_H

#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_DistributedMesh.h"
#include "hl_Tensor.h"

namespace hiperlife
{

    /*!
    *
    *
   */
    namespace OffsetParam
    {

        // x has dimension   3
        // Dx has dimension  2x3
        // DDx has dimension 2x2x3
        void Parametrization(double *x, double *Dx, double *n, double *Dn,
                             double *u, int eNN, int DOF, int nDim, int auxIni, int nAux, double *xe_nodes, double *ne_nodes,
                             double *ue_nodes, double *p_k, double *dp_k);
        inline void Parametrization(Tensor::tensor<double,1,false>& x, Tensor::tensor<double,2,false>& Dx, Tensor::tensor<double,1,false>& n, Tensor::tensor<double,2,false>& Dn, Tensor::tensor<double,1,false>& u, int eNN, int DOF, int nDim, int auxInit, int nAux, Tensor::tensor<double,2,false>& xe_nodes, Tensor::tensor<double,2,false>& ne_nodes, Tensor::tensor<double,2,false>& ue_nodes, Tensor::tensor<double,1,false>& p_k, Tensor::tensor<double,2,false>& dp_k)
        {
            Parametrization(x.data(), Dx.data(), n.data(), Dn.data(),u.data(), eNN, DOF, nDim, auxInit, nAux, xe_nodes.data(), ne_nodes.data(), ue_nodes.data(), p_k.data(), dp_k.data());
        }

        void Parametrization(double *x, double *Dx,
                             double *DDx, double *n, double *Dn, double *DDn, double *u, int eNN, int DOF, int nDim,
                             int auxIni, int nAux, double *xe_nodes, double *ne_nodes,
                             double *ue_nodes, double *p_k, double *dp_k, double *hp_k);
        inline void Parametrization(Tensor::tensor<double,1,false>& x, Tensor::tensor<double,2,false>& Dx, Tensor::tensor<double,3,false>& DDx, Tensor::tensor<double,1,false>& n, Tensor::tensor<double,2,false>& Dn, Tensor::tensor<double,3,false>& DDn, Tensor::tensor<double,1,false>& u, int eNN, int DOF, int nDim, int auxInit, int nAux, Tensor::tensor<double,2,false>& xe_nodes, Tensor::tensor<double,2,false>& ne_nodes,Tensor::tensor<double,2,false>& ue_nodes, Tensor::tensor<double,1,false>& p_k, Tensor::tensor<double,2,false>& dp_k, Tensor::tensor<double,3,false>& hp_k)
        {
            Parametrization(x.data(), Dx.data(), DDx.data(), n.data(), Dn.data(), DDn.data(), u.data(), eNN, DOF, nDim, auxInit, nAux, xe_nodes.data(), ne_nodes.data(), ue_nodes.data(), p_k.data(), dp_k.data(), hp_k.data());
        }

        void Normal ( double *normal, double *Ip, double *iIp, double &J, double *Dx );
        inline void Normal ( Tensor::tensor<double,1,false>& normal, Tensor::tensor<double,2,false>& Ip, Tensor::tensor<double,2,false>& iIp, double& J, Tensor::tensor<double,2,false>& Dx )
        {
            Normal ( normal.data(), Ip.data(), iIp.data(), J, Dx.data() );
        }

        void Curvatures ( double *normal, double *Ip, double *IIp, double *iIp, double &J, double *Dx, double *DDx );
        inline void Curvatures ( Tensor::tensor<double,1,false>& normal, Tensor::tensor<double,2,false>& Ip, Tensor::tensor<double,2,false>& IIp, Tensor::tensor<double,2,false>& iIp, double& J, Tensor::tensor<double,2,false>& Dx, Tensor::tensor<double,3,false>& DDx )
        {
            Curvatures ( normal.data(), Ip.data(), IIp.data(), iIp.data(), J, Dx.data(), DDx.data() );
        }
        void ChristoffelSymbols ( double *normal, double *Ip, double *IIp, double *iIp, double &J, double *DIp,
                                  double *CS, double *Dx, double *DDx );
        inline void ChristoffelSymbols ( Tensor::tensor<double,1,false>& normal, Tensor::tensor<double,2,false>& Ip, Tensor::tensor<double,2,false>& IIp, Tensor::tensor<double,2,false>& iIp, double& J, Tensor::tensor<double,3,false>& DIp, Tensor::tensor<double,3,false>& CS, Tensor::tensor<double,2,false>& Dx, Tensor::tensor<double,3,false>& DDx )
        {
            ChristoffelSymbols ( normal.data(), Ip.data(), IIp.data(), iIp.data(), J, DIp.data(), CS.data(), Dx.data(), DDx.data() );
        }

        void ParametrizationHeightDerivatives(double *dx, double *dDx, double &p_kI, double *dp_kI, double *n0, double *Dn0);
        inline void ParametrizationHeightDerivatives(Tensor::tensor<double,2,false>& dx, Tensor::tensor<double,3,false>& dDx, Tensor::tensor<double,1,false>& p_k, Tensor::tensor<double,2,false>& dp_k, Tensor::tensor<double,1,false>& n0, Tensor::tensor<double,2,false>& Dn0)
        {
            using namespace Tensor;
            for ( int i = 0; i < p_k.shape()[0]; i++ )
                ParametrizationHeightDerivatives(dx(i,all).data(), dDx(i,all,all).data(), p_k(i), dp_k(i,all).data(), n0.data(), Dn0.data());
        }

        void ParametrizationHeightDerivatives(double *dx, double *dDx, double *dDDx, double &p_kI,
                                              double *dp_kI, double *hp_kI, double *n0, double *Dn0, double *DDn0 );
        inline void ParametrizationHeightDerivatives(Tensor::tensor<double,2,false>& dx, Tensor::tensor<double,3,false>& dDx, Tensor::tensor<double,4,false>& dDDx, Tensor::tensor<double,1,false>& p_k, Tensor::tensor<double,2,false>& dp_k, Tensor::tensor<double,3,false>& hp_k, Tensor::tensor<double,1,false>& n0, Tensor::tensor<double,2,false>& Dn0, Tensor::tensor<double,3,false>& DDn0)
        {
            using namespace Tensor;
            for ( int i = 0; i < p_k.shape()[0]; i++ )
                ParametrizationHeightDerivatives(dx(i,all).data(), dDx(i,all,all).data(), dDDx(i,all,all,all).data(), p_k(i), dp_k(i,all).data(), hp_k(i,all,all).data(), n0.data(), Dn0.data(), DDn0.data());
        }

        void NormalHeightFirstDerivatives(double *dIp, double *diIp, double &dJ, double *dcross, double *dnormal,
                                          double *Dx, double *dDx, double *normal, double *iIp, double &iJ);
        inline void NormalHeightFirstDerivatives(Tensor::tensor<double,3,false>& dIp, Tensor::tensor<double,3,false>& diIp, Tensor::tensor<double,1,false>& dJ, Tensor::tensor<double,2,false>& dcross, Tensor::tensor<double,2,false>& dnormal, Tensor::tensor<double,2,false>& Dx, Tensor::tensor<double,3,false>& dDx, Tensor::tensor<double,1,false>& normal, Tensor::tensor<double,2,false>& iIp, double &iJ)
        {
            using namespace Tensor;
            for ( int i = 0; i < dDx.shape()[0]; i++ )
            {
                NormalHeightFirstDerivatives(dIp(i,all,all).data(), diIp(i,all,all).data(), dJ(i), dcross(i,all).data(), dnormal(i,all).data(),
                                             Dx.data(), dDx(i,all,all).data(), normal.data(), iIp.data(), iJ);
            }

        }

        void CurvatureHeightFirstDerivatives(double *dIp, double *diIp, double &dJ, double *dcross, double *dnormal, double *dIIp ,
                                             double *Dx, double *DDx, double *dDx, double *dDDx, double *normal, double *iIp, double &iJ);
        inline void CurvatureHeightFirstDerivatives(Tensor::tensor<double,3,false>& dIp, Tensor::tensor<double,3,false>& diIp, Tensor::tensor<double,1,false>& dJ, Tensor::tensor<double,2,false>& dcross, Tensor::tensor<double,2,false>& dnormal, Tensor::tensor<double,3,false>& dIIp, Tensor::tensor<double,2,false>& Dx, Tensor::tensor<double,3,false>& DDx, Tensor::tensor<double,3,false>& dDx, Tensor::tensor<double,4,false>& dDDx, Tensor::tensor<double,1,false>& normal, Tensor::tensor<double,2,false>& iIp, double &iJ)
        {
            using namespace Tensor;
            for ( int i = 0; i < dDx.shape()[0]; i++ )
            {
                CurvatureHeightFirstDerivatives(dIp(i,all,all).data(), diIp(i,all,all).data(), dJ(i), dcross(i,all).data(), dnormal(i,all).data(), dIIp(i,all,all).data(), Dx.data(), DDx.data(), dDx(i,all,all).data(), dDDx(i,all,all,all).data(), normal.data(), iIp.data(), iJ);
            }

        }
        void ChristoffelSymbolsHeightFirstDerivatives(double *dIp, double *diIp, double *dJ, double *dcross, double *dnormal,
                                       double *dIIp, double *dDIp, double *dCS, double *Dx, double *DDx,
                                       double *dDx, double *dDDx, double *normal, double *iIp, double *DIp, double &iJ);

        void NormalHeightSecondDerivatives( double *ddIp, double *ddiIp, double *ddcross, double *ddnormal, double &ddJ,
                                            double *dDxI, double *dDxJ, double *dIpI, double *diIpJ,  double *normal, double *dCrossI,
                                            double *dnormalI, double *dnormalJ, double *iIp, double &iJ, double &dJI, double &dJJ);
        inline void NormalHeightSecondDerivatives( Tensor::tensor<double,4,false>& ddIp, Tensor::tensor<double,4,false>& ddiIp, Tensor::tensor<double,3,false>& ddcross,  Tensor::tensor<double,3,false>& ddnormal, Tensor::tensor<double,2,false>& ddJ, Tensor::tensor<double,3,false>& dDx, Tensor::tensor<double,3,false>& dIp, Tensor::tensor<double,3,false>& diIp, Tensor::tensor<double,1,false>& normal, Tensor::tensor<double,2,false>& dCross,  Tensor::tensor<double,2,false>& dnormal, Tensor::tensor<double,2,false>& iIp, double& iJ, Tensor::tensor<double,1,false>& dJ)
        {
            using namespace Tensor;
            for ( int i = 0; i < dDx.shape()[0]; i++ )
            {
                for ( int j = 0; j < dDx.shape()[0]; j++ ) //FIXME: since the matrices are symmetric, this can be simplified
                {
                    NormalHeightSecondDerivatives(ddIp(i,j,all,all).data(), ddiIp(i,j,all,all).data(), ddcross(i,j,all).data(), ddnormal(i,j,all).data(), ddJ(i,j),
                                                  dDx(i,all,all).data(), dDx(j,all,all).data(), dIp(i,all,all).data(), diIp(j,all,all).data(),
                                                  normal.data(), dCross(i,all).data(), dnormal(i,all).data(), dnormal(j,all).data(),
                                                  iIp.data(), iJ, dJ(i), dJ(j));
                }
            }

        }

        void CurvatureHeightSecondDerivatives( double *ddIp, double *ddiIp, double *ddcross, double *ddnormal, double &ddJ,
                                               double *ddIIp,double *DDx,double *dDxI, double *dDDxI,
                                               double *dDxJ, double *dDDxJ, double *dIpI,
                                               double *diIpJ,  double *normal, double *dCrossI,
                                               double *dnormalI, double *dnormalJ,
                                               double *iIp, double &iJ, double &dJI, double &dJJ);
    inline void CurvatureHeightSecondDerivatives( Tensor::tensor<double,4,false>& ddIp, Tensor::tensor<double,4,false>& ddiIp, Tensor::tensor<double,3,false>& ddcross,  Tensor::tensor<double,3,false>& ddnormal, Tensor::tensor<double,2,false>& ddJ,  Tensor::tensor<double,4,false>& ddIIp, Tensor::tensor<double,3,false>& DDx, Tensor::tensor<double,3,false>& dDx, Tensor::tensor<double,4,false>& dDDx, Tensor::tensor<double,3,false>& dIp, Tensor::tensor<double,3,false>& diIp, Tensor::tensor<double,1,false>& normal, Tensor::tensor<double,2,false>& dCross,  Tensor::tensor<double,2,false>& dnormal, Tensor::tensor<double,2,false>& iIp, double& iJ, Tensor::tensor<double,1,false>& dJ)
    {
        using namespace Tensor;
        for ( int i = 0; i < dDx.shape()[0]; i++ )
        {
            for ( int j = 0; j < dDx.shape()[0]; j++ ) //FIXME: since the matrices are symmetric, this can be simplified
            {
                CurvatureHeightSecondDerivatives(ddIp(i,j,all,all).data(), ddiIp(i,j,all,all).data(), ddcross(i,j,all).data(), ddnormal(i,j,all).data(), ddJ(i,j), ddIIp(i,j,all,all).data(), DDx.data(), dDx(i,all,all).data(), dDDx(i,all,all,all).data(), dDx(j,all,all).data(), dDDx(j,all,all,all).data() , dIp(i,all,all).data(), diIp(j,all,all).data(), normal.data(), dCross(i,all).data(), dnormal(i,all).data(), dnormal(j,all).data(), iIp.data(), iJ, dJ(i), dJ(j));
            }
        }

    }
        void ChristoffelSymbolsHeightSecondDerivatives(double *ddIp, double *ddiIp, double *ddcross, double *ddnormal, double &ddJ,
                                                       double *ddIIp, double *ddDIp, double *ddCS,
                                                       double *DDx, double *DIp,
                                                       double *dDxI, double *dDDxI, double *dDxJ, double *dDDxJ,
                                                       double *dIpI, double *diIpI, double *diIpJ,
                                                       double *dDIpI, double *dDIpJ,
                                                       double *normal, double *dCrossI, double *dnormalI,
                                                       double *dnormalJ,
                                                       double *iIp, double &iJ, double &dJI, double &dJJ);
    }
}

#endif //HPLFE_OFFSETPARAM_H
