/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HPLFE_LOCMONGEPARAM_H
#define HPLFE_LOCMONGEPARAM_H

#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_Tensor.h"
#include "hl_DistributedMesh.h"


namespace hiperlife
{
    namespace LocMongeParam
    {
        void computeLocal3DBasis(Teuchos::RCP<hiperlife::DistributedMesh> mesh, Teuchos::RCP<hiperlife::FieldStruct> field);

        inline void matChangeBasis(double *TI, double *g1eI, double *g2eI, double *xu, double *xv)
        {
            TI[0] = Math::Dot3D(xu, g1eI);
            TI[1] = Math::Dot3D(xv, g1eI);
            TI[2] = Math::Dot3D(xu, g2eI);
            TI[3] = Math::Dot3D(xv, g2eI);
        }

        inline hiperlife::Tensor::tensor<double,2,false> changeBasisMat(hiperlife::Tensor::tensor<double,1,false>& g1eI, hiperlife::Tensor::tensor<double,1,false>& g2eI, hiperlife::Tensor::tensor<double,1,false>& xu, hiperlife::Tensor::tensor<double,1,false>& xv)
        {
            hiperlife::Tensor::tensor<double,2> TI(2,2);
            TI(0,0) = xu*g1eI;
            TI(0,1) = xv*g1eI;
            TI(1,0) = xu*g2eI;
            TI(1,1) = xv*g2eI;

            return TI;
        }

        inline void derMatChangeBasis(double *DTI, double *g1eI, double *g2eI, double *xuu, double *xuv, double *xvv)
        {
            DTI[0] = Math::Dot3D(g1eI, xuu);
            DTI[1] = Math::Dot3D(g1eI, xuv);
            DTI[2] = Math::Dot3D(g1eI, xuv);
            DTI[3] = Math::Dot3D(g1eI, xvv);
            DTI[4] = Math::Dot3D(g2eI, xuu);
            DTI[5] = Math::Dot3D(g2eI, xuv);
            DTI[6] = Math::Dot3D(g2eI, xuv);
            DTI[7] = Math::Dot3D(g2eI, xvv);
        }

        inline void derInvMathChangeBasis(double *DiTI, double *DTI, double *iTI)
        {
            double Taux[8];

            Taux[0] = DTI[0] * iTI[0] + DTI[2] * iTI[2];
            Taux[1] = DTI[1] * iTI[0] + DTI[3] * iTI[2];
            Taux[2] = DTI[0] * iTI[1] + DTI[2] * iTI[3];
            Taux[3] = DTI[1] * iTI[1] + DTI[3] * iTI[3];
            Taux[4] = DTI[4] * iTI[0] + DTI[6] * iTI[2];
            Taux[5] = DTI[5] * iTI[0] + DTI[7] * iTI[2];
            Taux[6] = DTI[4] * iTI[1] + DTI[6] * iTI[3];
            Taux[7] = DTI[5] * iTI[1] + DTI[7] * iTI[3];

            DiTI[0] = -(iTI[0] * Taux[0] + iTI[1] * Taux[4]);
            DiTI[1] = -(iTI[0] * Taux[1] + iTI[1] * Taux[5]);
            DiTI[2] = -(iTI[0] * Taux[2] + iTI[1] * Taux[6]);
            DiTI[3] = -(iTI[0] * Taux[3] + iTI[1] * Taux[7]);
            DiTI[4] = -(iTI[2] * Taux[0] + iTI[3] * Taux[4]);
            DiTI[5] = -(iTI[2] * Taux[1] + iTI[3] * Taux[5]);
            DiTI[6] = -(iTI[2] * Taux[2] + iTI[3] * Taux[6]);
            DiTI[7] = -(iTI[2] * Taux[3] + iTI[3] * Taux[7]);
        }
        inline void opGradCov ( double *symGI, double *dp_kI, double p_kI, double *CS, double *TI, double *DTI)
        {
            symGI[0] = dp_kI[0] * TI[0];
            symGI[1] = dp_kI[0] * TI[2];
            symGI[2] = dp_kI[1] * TI[0];
            symGI[3] = dp_kI[1] * TI[2];
            symGI[4] = dp_kI[0] * TI[1];
            symGI[5] = dp_kI[0] * TI[3];
            symGI[6] = dp_kI[1] * TI[1];
            symGI[7] = dp_kI[1] * TI[3];


            if (CS != nullptr and DTI != nullptr)
            {
                symGI[0] += p_kI * DTI[0];
                symGI[1] += p_kI * DTI[4];
                symGI[2] += p_kI * DTI[1];
                symGI[3] += p_kI * DTI[5];
                symGI[4] += p_kI * DTI[2];
                symGI[5] += p_kI * DTI[6];
                symGI[6] += p_kI * DTI[3];
                symGI[7] += p_kI * DTI[7];

                symGI[0] -= p_kI  * ( CS[0] * TI[0] + CS[4] * TI[1] );
                symGI[1] -= p_kI  * ( CS[0] * TI[2] + CS[4] * TI[3] );
                symGI[2] -= p_kI  * ( CS[1] * TI[0] + CS[5] * TI[1] );
                symGI[3] -= p_kI  * ( CS[1] * TI[2] + CS[5] * TI[3] );
                symGI[4] -= p_kI  * ( CS[2] * TI[0] + CS[6] * TI[1] );
                symGI[5] -= p_kI  * ( CS[2] * TI[2] + CS[6] * TI[3] );
                symGI[6] -= p_kI  * ( CS[3] * TI[0] + CS[7] * TI[1] );
                symGI[7] -= p_kI  * ( CS[3] * TI[2] + CS[7] * TI[3] );
            }
        }

        inline void opSymmGradCov ( double *symGI, double *dp_kI, double p_kI, double *CS, double *TI, double *DTI)
        {
            symGI[0] = dp_kI[0] * TI[0];
            symGI[1] = dp_kI[0] * TI[2];
            symGI[2] = dp_kI[1] * TI[0];
            symGI[3] = dp_kI[1] * TI[2];
            symGI[4] = dp_kI[0] * TI[1];
            symGI[5] = dp_kI[0] * TI[3];
            symGI[6] = dp_kI[1] * TI[1];
            symGI[7] = dp_kI[1] * TI[3];


            if (CS != nullptr and DTI != nullptr)
            {
                symGI[0] += p_kI * DTI[0];
                symGI[1] += p_kI * DTI[4];
                symGI[2] += p_kI * DTI[1];
                symGI[3] += p_kI * DTI[5];
                symGI[4] += p_kI * DTI[2];
                symGI[5] += p_kI * DTI[6];
                symGI[6] += p_kI * DTI[3];
                symGI[7] += p_kI * DTI[7];

                symGI[0] -= p_kI  * ( CS[0] * TI[0] + CS[4] * TI[1] );
                symGI[1] -= p_kI  * ( CS[0] * TI[2] + CS[4] * TI[3] );
                symGI[2] -= p_kI  * ( CS[1] * TI[0] + CS[5] * TI[1] );
                symGI[3] -= p_kI  * ( CS[1] * TI[2] + CS[5] * TI[3] );
                symGI[4] -= p_kI  * ( CS[2] * TI[0] + CS[6] * TI[1] );
                symGI[5] -= p_kI  * ( CS[2] * TI[2] + CS[6] * TI[3] );
                symGI[6] -= p_kI  * ( CS[3] * TI[0] + CS[7] * TI[1] );
                symGI[7] -= p_kI  * ( CS[3] * TI[2] + CS[7] * TI[3] );
            }

            symGI[2] = 0.5*(symGI[2] + symGI[4]);
            symGI[3] = 0.5*(symGI[3] + symGI[5]);
            symGI[4] = symGI[2];
            symGI[5] = symGI[3];
        }

        inline void opDivContRank2(double *divSI, double *dp_kI, double p_kI, double *CS, double *iTI, double *DiTI)
        {

            //----------------------------
            double auxV[2];
            Math::MatProduct(auxV, 1, 2, 2, dp_kI, iTI);
            divSI[0] = iTI[0] * auxV[0];
            divSI[1] = iTI[0] * auxV[1];
            divSI[2] = iTI[1] * auxV[0];
            divSI[3] = iTI[1] * auxV[1];
            divSI[4] = iTI[2] * auxV[0];
            divSI[5] = iTI[2] * auxV[1];
            divSI[6] = iTI[3] * auxV[0];
            divSI[7] = iTI[3] * auxV[1];

            //----------------------------
            double auxT[8];
            Math::MatProduct(&auxT[0], 2, 2, 2, &DiTI[0], iTI);
            Math::MatProduct(&auxT[4], 2, 2, 2, &DiTI[4], iTI);
            Math::AXPY(divSI, 8, p_kI, auxT);

            //----------------------------
            auxV[0] = DiTI[0] + DiTI[5];
            auxV[1] = DiTI[2] + DiTI[7];

            divSI[0] += p_kI * iTI[0] * auxV[0];
            divSI[1] += p_kI * iTI[0] * auxV[1];
            divSI[2] += p_kI * iTI[1] * auxV[0];
            divSI[3] += p_kI * iTI[1] * auxV[1];
            divSI[4] += p_kI * iTI[2] * auxV[0];
            divSI[5] += p_kI * iTI[2] * auxV[1];
            divSI[6] += p_kI * iTI[3] * auxV[0];
            divSI[7] += p_kI * iTI[3] * auxV[1];

            //----------------------------
            double aux2V[2];
            aux2V[0] = CS[0] + CS[5];
            aux2V[1] = CS[2] + CS[7];

            Math::MatProduct(auxV, 1, 2, 2, aux2V, iTI);
            divSI[0] += p_kI * iTI[0] * auxV[0];
            divSI[1] += p_kI * iTI[0] * auxV[1];
            divSI[2] += p_kI * iTI[1] * auxV[0];
            divSI[3] += p_kI * iTI[1] * auxV[1];
            divSI[4] += p_kI * iTI[2] * auxV[0];
            divSI[5] += p_kI * iTI[2] * auxV[1];
            divSI[6] += p_kI * iTI[3] * auxV[0];
            divSI[7] += p_kI * iTI[3] * auxV[1];

            //----------------------------
            double aux2T[8];
            Math::MatProduct(&aux2T[0], 2, 2, 2, &CS[0], iTI);
            Math::MatProduct(&aux2T[4], 2, 2, 2, &CS[4], iTI);

            Math::MatTMult(&auxT[0], 2, 2, 2, iTI, &aux2T[0]);
            Math::MatTMult(&auxT[4], 2, 2, 2, iTI, &aux2T[4]);
            Math::AXPY(divSI, 8, p_kI, auxT);

        }
    }
}

#endif //HPLFE_LOCMONGEPARAM_H
