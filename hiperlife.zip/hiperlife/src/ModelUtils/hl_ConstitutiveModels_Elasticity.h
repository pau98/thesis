/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef HL_ELASTICITY_H
#define HL_ELASTICITY_H

#include "hl_Tensor.h"

using namespace hiperlife::Tensor;

namespace hiperlife
{
    namespace ConstitutiveModels
    {
        namespace LinearElasticity
        {
            /*! \brief Computes linear elasticity tensor C_ijkl
            * @param C elasticity tensor
            * @param C_L Longitudinal elastic parameter
            * @param C_T Transverse elastic parameter
            * @param C_S Shear elastic parameter
            * @param pDim Parametric dimension
            */
            void elasticityTensor(tensor<double, 4> &C, const double C_L, const double C_T, const double C_S, const int pDim);
            void elasticityTensor(std::vector<double> &C, const double C_L, const double C_T, const double C_S, const int pDim);

            /*! \brief Computes linear strain gradient elasticity tensor H_ijklmn
            * @param H gradient elasticity tensor
            * @param C_L Longitudinal elastic parameter
            * @param C_T Transverse elastic parameter
            * @param C_S Shear elastic parameter
            * @param l Length scale
            * @param pDim Parametric dimension
            */
            void gradElasticityTensor(tensor<double, 6> &H, const double C_L, const double C_T, const double C_S, const double lMech, const int pDim);
            void gradElasticityTensor(std::vector<double> &H, const double C_L, const double C_T, const double C_S, const double lMech, const int pDim);

            /*! \brief Computes symmetric small strain tensor Strain_ijQR
            * @param strain stain 4th order tensor
            * @param globDBF Global derivative of basis functions
            */
            void strain(tensor<double, 4> &strain, tensor<double, 2> globDBF, const int pDim);

            /*! \brief Computes strain gradient tensor
            * @param gradStrain stain gradient tensor
            * @param globHBF Global Hessian of basis functions
            * @param pDim Parametric dimension
            */
            void gradStrain(tensor<double, 5> &gradStrain, tensor<double, 3> globHBF, const int pDim);

            /*! \brief Computes strain hessian tensor
            * @param hessStrain stain hessian tensor
            * @param globTBF Global third derivative of basis functions
            * @param pDim Parametric dimension
            */
            void hessStrain(tensor<double, 6> &hessStrain, tensor<double, 4> globTBF, const int pDim);
        } // namespace LinearElasticity
    } // namespace ConstitutiveModels
} // namespace hiperlife
#endif
