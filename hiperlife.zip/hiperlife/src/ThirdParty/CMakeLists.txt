#------------------------------------------------------------
# hiperlife's third-party
#------------------------------------------------------------

add_subdirectory(magic_enum)
add_subdirectory(earcut)
