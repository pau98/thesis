/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATUREBASIC_H
#define CUBATUREBASIC_H

#include "hl_Cubature.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of a cubature using the cut cell method and a non-conforming approach
    */
    class CubatureBasic : public Cubature
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            CubatureBasic(){};
            CubatureBasic(const CubatureBasic& other) = default;
            CubatureBasic(CubatureBasic &&other) = default;
            ~CubatureBasic() = default;

            CubatureBasic& operator=(const CubatureBasic& other) = default;
            CubatureBasic& operator=(CubatureBasic&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a DOFsHandler object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the coordinates of the integration points
             *  \param intPoints: Vector with the coordinates of the integration points
             */
            void setIntegrationPoints(std::vector<double> intPoints){_xSamples = intPoints;};
            /*! \brief Sets the weights of the integration points
             *  \param intWeights: Vector with the coordinates of the integration points
             */
            void setIntegrationWeights(std::vector<double> intWeights){_wSamples = intWeights;};
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of object creation

        protected:

            //Auxiliary functions
            void _checkSettings() override;


        private:
    };
}

#endif //CUBATUREBASIC_H
