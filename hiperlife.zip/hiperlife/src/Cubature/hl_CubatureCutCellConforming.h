/*
    *******************************************************************************
    Copyright (c) 2017-2021 Universitat Politècnica de Catalunya
    Authors: Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
    *******************************************************************************
    This file is part of hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Distributed under the MIT software license, see the accompanying
    file LICENSE or http://www.opensource.org/licenses/mit-license.php.
    *******************************************************************************
*/


#ifndef CUBATURECUTCELLCONFORMING_H
#define CUBATURECUTCELLCONFORMING_H


#include <array>

#include "hl_Cubature.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of a cubature using the cut cell method and a conforming approach
     * It follows the ideas in "L. Kudela et al, Efficient and accurate numerical quadrature for
     * immersed boundary methods, Adv. Model. and Simul. in Eng. Sci. (2015) 2:10"
     * DOI: 10.1186/s40323-015-0031-y
    */
    class CubatureCutCellConforming : public Cubature
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            CubatureCutCellConforming(){};
            CubatureCutCellConforming(const CubatureCutCellConforming& other) = default;
            CubatureCutCellConforming(CubatureCutCellConforming &&other) = default;
            ~CubatureCutCellConforming() = default;

            CubatureCutCellConforming& operator=(const CubatureCutCellConforming& other) = default;
            CubatureCutCellConforming& operator=(CubatureCutCellConforming&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a DOFsHandler object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the flags of the corner nodes (interior/exterior)
             *  \param cornerFlags: Vector of flags
             */
            void setCornerFlags(std::vector<int> cornerFlags){_cornerFlags = cornerFlags;};
            /*! \brief Sets the region to integrate
             *  \param regionTag: internal tag for the region
             */
            void setRegionTag(int regionTag){_regionTag = regionTag;};
            /*! \brief Sets the geometry of the (polygonal) curve that cuts the element
             */
            void setImmersedSegments(std::vector<std::vector<std::vector<double>>> immersedSegments) {_immSegments = immersedSegments;};
            /*! \brief Sets the geometry of the (triangulated) surface that cuts the element
             */
            void setImmersedPoints(std::vector<std::vector<double>> immPts) {_immPts = immPts;};
            /*! \brief Sets the polygons of the region in the reference element, instead of the immersed segments
             *  and the corner flags. Each polygon is a list of rings (outer ring first, then its holes), each ring
             *  a list of points {r, s}. An empty list means that the region is not in the element.
             */
            void setPolygons(std::vector<std::vector<std::vector<std::vector<double>>>> polygons)
            {
                _polygons = polygons;
                _usePolygons = true;
            };
            /*! \brief Sets the integration order */
            void setIntegrationOrder(int intOrder){_intOrder = intOrder;};
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of object creation

            // // Remove
            // int _elem;

        protected:

            // Auxiliary functions
            void _checkSettings() override;


        private:

            // Main variables
            std::vector<int> _cornerFlags = {};
            int _regionTag{};
            CubatureInfo _cubaInfoGaussSquare;
            CubatureInfo _cubaInfoGaussTriang;
            int _pDim{};
            int _intOrder{};
            std::vector<std::vector<std::vector<double>>> _immSegments;
            std::vector<std::vector<double>> _immPts;
            std::vector<std::vector<std::vector<std::vector<double>>>> _polygons;
            bool _usePolygons = false;

            // Auxiliary functions
            std::vector<std::vector<std::array<double, 2>>> _segmentPolygons(); // From the immersed segments and corner flags
            // Triangles (triang, coord, node) of a polygon with holes by vertical slabs (fallback of earcut)
            std::vector<std::vector<std::vector<double>>> _slabTriangles(const std::vector<std::vector<std::array<double, 2>>>& rings);
            void _linearSquareBasisFunctions(std::vector<double> & bfs, double u, double v);
            void _linearTriangBasisFunctions(std::vector<double> & bfs, double u, double v);

    };
}

#endif //CUBATURECUTCELLCONFORMING_H
