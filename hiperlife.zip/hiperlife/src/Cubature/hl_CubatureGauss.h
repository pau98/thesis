/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATUREUNIFORM_H
#define CUBATUREUNIFORM_H

#include "hl_Cubature.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of the gaussian cubature at any type of mesh.
    */
    class CubatureGauss : public Cubature
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            CubatureGauss(){};
            CubatureGauss(const CubatureGauss& other) = default;
            CubatureGauss(CubatureGauss &&other) = default;
            ~CubatureGauss() = default;

            CubatureGauss& operator=(const CubatureGauss& other) = default;
            CubatureGauss& operator=(CubatureGauss&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a DOFsHandler object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of object creation

            //Auxiliary functions
            void _checkSettings() override;

        private:

            //Cubature rules
            void _lineRule();
            void _quadratureRule();
            void _triangularRule();
            void _symmetricRule();
            void _tetrahedralRule();
            void _quadrilateralRule();
            void _parallelepipedalRule();

    };
}

#endif // CUBATUREUNIFORM_H
