/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATUREIRREGSUBDIVSURF_H
#define CUBATUREIRREGSUBDIVSURF_H


#include "hl_Cubature.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of a cubature for elements around irregular points. Valid for triangular meshes and Subdivision Surfaces.
    */
    class CubatureIrregSubdivSurf : public Cubature
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            CubatureIrregSubdivSurf(){};
            CubatureIrregSubdivSurf(const CubatureIrregSubdivSurf& other) = default;
            CubatureIrregSubdivSurf(CubatureIrregSubdivSurf &&other) = default;
            ~CubatureIrregSubdivSurf() = default;

            CubatureIrregSubdivSurf& operator=(const CubatureIrregSubdivSurf& other) = default;
            CubatureIrregSubdivSurf& operator=(CubatureIrregSubdivSurf&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a DOFsHandler object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the maximum number of subdivisions.
             *  \param numSubdiv: Maximum number of subdivisions
             */
            void setMaxSubdiv(int numSubdiv){_numSubdiv = numSubdiv;};
            /*! \brief Sets the irregular nodes
             *  \param numSubdiv: Set of irregular nodes
             */
            void setIrregNode(int irregNode){_irregNode = irregNode;};
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of object creation

        protected:

            //Auxiliary functions
            void _checkSettings() override;


        private:

            //Main variables
            int _numSubdiv{};
            int _irregNode{};


    };
}



#endif //CUBATUREIRREGSUBDIVSURF_H
