/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#include <math.h>
#include <unistd.h> //FIXME sleep function

#include "hl_CubatureBorderGauss.h"


using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;



namespace hiperlife
{

    //Object creation management
    void CubatureBorderGauss::Update()
    {
        _checkSettings();

        _pDim = computePDim(_elemType);

        RCP<CubatureGauss> gCuba = rcp(new CubatureGauss);
        if (_elemType != ElemType::Line)
        {
            gCuba->setElemType(_elemType--);
            gCuba->setNumIntPts(_iPts);
            gCuba->Update();
            _wSamples = gCuba->_wSamples;
        }
        else
        {
            _wSamples.resize(1);
        }

        _xSamples.resize(_iPts * _pDim);

        for (int k = 0; k < _iPts; k++)
        {
            switch (static_cast<int>(_elemType))
            {
                case static_cast<int>(ElemType::Line):
                {
                    _wSamples[k] = 1.0;

                    switch (_side)
                    {
                        case 0:
                        {
                            _xSamples[k*_pDim+0] = -1.0;
                            break;
                        }
                        case 1:
                        {
                            _xSamples[k*_pDim+0] = 1.0;

                            break;
                        }

                        default:
                            throw runtime_error("Side " + to_string(_side) + "does not make sense for element" + str(_elemType) );

                    }
                    break;
                }

                case static_cast<int>(ElemType::Triang):
                {
                    _wSamples[k] *= 0.5;

                    switch (_side)
                    {
                        case 0: // y == 0
                        {
                            _xSamples[k*_pDim+0] = 0.5 + 0.5*gCuba->_xSamples[k*(_pDim-1)];
                            _xSamples[k*_pDim+1] = 0.0;

                            break;
                        }
                        case 1: // Tilted line
                        {
                            _wSamples[k] *= sqrt(2.0);
                            _xSamples[k*_pDim+0] = 0.5 - 0.5*gCuba->_xSamples[k*(_pDim-1)];
                            _xSamples[k*_pDim+1] = 0.5 + 0.5*gCuba->_xSamples[k*(_pDim-1)];

                            break;
                        }
                        case 2: // x == 0
                        {
                            _xSamples[k*_pDim+0] = 0.0;
                            _xSamples[k*_pDim+1] = 0.5 - 0.5*gCuba->_xSamples[k*(_pDim-1)];

                            break;
                        }

                        default:
                            throw runtime_error("Side " + to_string(_side) + "does not make sense for element" + str(_elemType) );

                    }

                    break;
                }

                case static_cast<int>(ElemType::Square):
                {
                    switch (_side)
                    {
                        case 0:
                        {
                            _xSamples[k*_pDim+0] = gCuba->_xSamples[k*(_pDim-1)];
                            _xSamples[k*_pDim+1] = -1.0;

                            break;
                        }
                        case 1:
                        {
                            _xSamples[k*_pDim+0] = 1.0;
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)];

                            break;
                        }
                        case 2:
                        {
                            _xSamples[k*_pDim+0] = gCuba->_xSamples[k*(_pDim-1)];
                            _xSamples[k*_pDim+1] = 1.0;

                            break;
                        }
                        case 3:
                        {
                            _xSamples[k*_pDim+0] = -1.0;
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)];

                            break;
                        }

                        default:
                            throw runtime_error("Side " + to_string(_side) + "does not make sense for element" + str(_elemType) );

                    }
                    break;
                }

                case static_cast<int>(ElemType::Tetrah):
                {
                    switch (_side)
                    {
                        case 0: // z == 0
                        {
                            _xSamples[k*_pDim+0] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)+1];
                            _xSamples[k*_pDim+2] = 0.0;

                            break;
                        }
                        case 1: // y == 0
                        {
                            _xSamples[k*_pDim+0] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+1] = 0.0;
                            _xSamples[k*_pDim+2] = gCuba->_xSamples[k*(_pDim-1)+1];

                            break;
                        }
                        case 2: // Tilted plane
                        {
                            _wSamples[k] *= 2.0;
                            _xSamples[k*_pDim+0] = 1.0-gCuba->_xSamples[k*(_pDim-1)+0]-gCuba->_xSamples[k*(_pDim-1)+1];
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+2] = gCuba->_xSamples[k*(_pDim-1)+1];

                            break;
                        }
                        case 3: // x == 0
                        {
                            _xSamples[k*_pDim+0] = 0.0;
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+2] = gCuba->_xSamples[k*(_pDim-1)+1];

                            break;
                        }

                        default:
                            throw runtime_error("Side " + to_string(_side) + "does not make sense for element" + str(_elemType) );
                    }
                    break;
                }

                case static_cast<int>(ElemType::Parallelep):
                {
                    switch (_side)
                    {
                        case 0: //Zmin
                        {
                            _xSamples[k*_pDim+0] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)+1];
                            _xSamples[k*_pDim+2] = -1.0;

                            break;
                        }
                        case 1: //Ymin
                        {
                            _xSamples[k*_pDim+0] = -gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+1] = -1.0;
                            _xSamples[k*_pDim+2] = -gCuba->_xSamples[k*(_pDim-1)+1];

                            break;
                        }
                        case 2: //Xmin
                        {
                            _xSamples[k*_pDim+0] = -1.0;
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+2] = gCuba->_xSamples[k*(_pDim-1)+1];

                            break;
                        }
                        case 3: //Ymax
                        {
                            _xSamples[k*_pDim+0] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+1] = 1.0;
                            _xSamples[k*_pDim+2] = gCuba->_xSamples[k*(_pDim-1)+1];

                            break;
                        }
                        case 4: //Xmax
                        {
                            _xSamples[k*_pDim+0] = 1.0;
                            _xSamples[k*_pDim+1] = -gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+2] = -gCuba->_xSamples[k*(_pDim-1)+1];

                            break;
                        }
                        case 5: //Zmax
                        {
                            _xSamples[k*_pDim+0] = gCuba->_xSamples[k*(_pDim-1)+0];
                            _xSamples[k*_pDim+1] = gCuba->_xSamples[k*(_pDim-1)+1];
                            _xSamples[k*_pDim+2] = 1.0;

                            break;
                        }

                        default:
                            throw runtime_error("Side " + to_string(_side) + "does not make sense for element" + str(_elemType) );

                    }
                    break;
                }

                default:
                    throw runtime_error("CubatureBorderGauss::Update: Element not implemented yet!");

            }
        }


        _cubaInfo.iPts = _iPts;
        _cubaInfo.pDim = _pDim;
        _cubaInfo.xSamples = _xSamples;
        _cubaInfo.wSamples = _wSamples;
        _cubaInfo.cubaName = "CubatureBorderGauss";
    }

    void CubatureBorderGauss::_checkSettings()
    {
        // Line quadrature rule
        if(_elemType == ElemType::Line)
        {
            if(_iPts > 1)
            {
                cout << "ERROR: I can't integrate on the border of a line with more than 1 Gauss point!... check this." << endl;
                throw runtime_error("CubatureBorderGauss: CheckSettings failed!!");
            }

        }

    }

}// end namespace
