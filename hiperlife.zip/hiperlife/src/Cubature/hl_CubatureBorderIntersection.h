/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#ifndef CUBATUREBORDERINTERSECTION_H
#define CUBATUREBORDERINTERSECTION_H

#include "hl_Cubature.h"
#include "hl_CubatureGauss.h"

namespace hiperlife
{
    /*!
     * \brief Implementation of a border intersection integration for the imposition of integrals on
     * boundaries of boundaries of geometry.
    */
    class CubatureBorderIntersection : public Cubature
    {
        public:
            /** @name Constructor / Destructor / Operator
                    Copy constructors are deleted for memory safety but objects can be created from
                    temporal objects through move constructors
                *  @{ */
            CubatureBorderIntersection(){};
            CubatureBorderIntersection(const CubatureBorderIntersection &other) = default;
            CubatureBorderIntersection(CubatureBorderIntersection &&other) = default;
            ~CubatureBorderIntersection() = default;

            CubatureBorderIntersection &operator=(const CubatureBorderIntersection &other) = default;
            CubatureBorderIntersection &operator=(CubatureBorderIntersection &&other) = default;
            /** @} */ // end of constructors

            /** @name Object creation management
                 * The parameters for the creation of the objects are set via these functions.
                 * After all is introduced the object can be created through the Update() method.
                 * Notice that not all the setters are needed for initiate a DOFsHandler object and,
                 * in fact, several can be incompatible between each other.
                 *  @{
                 */
            void setBorderIntersec(int borderIntersec) { _borderIntersec = borderIntersec; }
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of object creation

        protected:
            //Auxiliary functions
            void _checkSettings() override;

        private:
            //Main variables
            int _borderIntersec;
    };

} // namespace hiperlife

#endif // CUBATUREBORDERINTERSECTION_H
