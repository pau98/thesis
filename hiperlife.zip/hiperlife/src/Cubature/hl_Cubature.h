/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATURE_H
#define CUBATURE_H

#include <vector>
#include <iostream>

#include "hl_TypeDefs.h"
#include "hl_DistributedClass.h"
#include "hl_CubatureInfo.h"


namespace hiperlife
{
    /*!
     * \brief Virtual class for all the Cubature in <b>hiperlife</b>.
    */
    class Cubature
    {

        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            Cubature() = default;
            Cubature(const Cubature& other) = default;
            Cubature(Cubature &&other) = default;
            virtual ~Cubature() = default;

            Cubature& operator=(Cubature&& other) = default;
            Cubature& operator=(const Cubature& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             *   Main functions to set the number of integration points, element type and order.
             *  @{*/
            /*! \brief Sets the number of integration points.
             *  \param iPts Number of integration points.
             */
            void setNumIntPts(int iPts){_iPts = iPts;}; //FIXME: Change name to setNumIntPts/setNumIntgrPts and iPts
            /*! \brief Sets the element type.
             *  \param elemtype hiperlife element type.
             */
            void setElemType(ElemType elemtype){_elemType = elemtype;};
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            virtual void Update() = 0;
            /** @} */ // end of object creation management


            /** @name Information access methods
             *  @{
             */
            /*! \brief Gets CubatureInfo.*/
            CubatureInfo cubatureInfo() {return _cubaInfo;};
            /*! \brief Gets the number of integration points.*/
            int iPts(){return _iPts;}
            /*! \brief Gets the number of parametric dimensions.*/
            int pDim(){return _pDim;}
            /*! \brief Gets the element type.*/
            ElemType elemType(){return _elemType;}
            /** @} */ // end of Information access methods


            /** @name Expert users and developers only
             *  @{
             */
            /*! \brief Integration point coordinates.*/
            std::vector<double> _xSamples;
            /*! \brief Integration point weights.*/
            std::vector<double> _wSamples;
            /** @} */ // end of Expert users and Developers only


        protected:

            /** @name Expert users and developers only
             *  @{
             */
            /*! \brief Number of integration points.*/
            int _iPts;
            /*! \brief Number of parametric dimensions.*/
            int _pDim;
            /*! \brief Element type.*/
            ElemType _elemType;
            /*! \brief Cubature info.*/
            CubatureInfo _cubaInfo;
            /** @} */ // end of Expert users and Developers only

            /** @name Auxiliary functions
             *  @{
             */
            /*! \brief Check all the settings.*/
            virtual void _checkSettings() = 0;
            /** @} */ // end of Auxiliary functions

    };
}


#include "hl_CubatureBasic.h"              //FIXME: What are these guys doing here???
#include "hl_CubatureGauss.h"
#include "hl_CubatureIrregSubdivSurf.h"
#include "hl_CubatureBorderGauss.h"
#include "hl_CubatureBorderIntersection.h"
#include "hl_CubatureCutCellNonConforming.h"
#include "hl_CubatureCutCellConforming.h"

#endif // CUBATURE_H
