/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <math.h>
#include <valarray>

#include "hl_Math.h"
#include "hl_Array.h"
#include "hl_CubatureGauss.h"
#include "hl_CubatureIrregSubdivSurf.h"



using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;



namespace hiperlife
{

    void transfGauss(double *macroX, double *origX, int elem, int subdivs)
    {
        using std::array;

        valarray<double> linTransf(4);
        valarray<double> transl(2);

        double jacLine = 1.0;
        for (int i = 0; i < subdivs; i++)
            jacLine *= 0.5;

        if (elem == 0)
        {
            linTransf = {0.5, 0.0, 0.0, 0.5};
            transl    = {0.0, 0.0};
        }
        else if (elem == 1)
        {

            linTransf = {0.5, 0.0, 0.0, 0.5};
            transl   = {0.5, 0};

        }
        else if (elem == 2)
        {
            linTransf = {-0.5, -0.5, 0.5, 0.0};
            transl    = {0.5, 0.5};
        }
        else if (elem == 3)
        {
            linTransf = {0.0, -0.5, 0.5, 0.5};
            transl    = {0.5, 0.0};
        }

        linTransf *= jacLine;
        transl    *= jacLine;

        Math::MatProduct(macroX, 2, 2 ,1, &linTransf[0], origX);
        Math::AXPY(macroX , 2, 1.0, &transl[0]);
    }

    void CubatureIrregSubdivSurf::Update()
    {
        _checkSettings();

        _wSamples.resize(_iPts);

        // Perform the quadrature in the reference element
        CubatureGauss cuba;
        cuba.setElemType(ElemType::Triang);
        cuba.setNumIntPts(_iPts);
        cuba.Update();
        auto stdInfo = cuba.cubatureInfo();

        int pseudoElems = (1 + 3*_numSubdiv);
        _cubaInfo.pDim = stdInfo.pDim;
        _cubaInfo.iPts = stdInfo.iPts * pseudoElems;
        _cubaInfo.wSamples.reserve(_cubaInfo.iPts);
        _cubaInfo.xSamples.reserve(_cubaInfo.iPts*_cubaInfo.pDim);
        _cubaInfo.cubaName = "CubatureIrregSubdivSurf";

        double jac = 1.0;
        int ii = 0;

        double xBuffer[2];
        double extraTransl[2];

        Array::Fill2D(xBuffer,0.0);
        Array::Fill2D(extraTransl,0.0);

        for(int s = 0; s < _numSubdiv; s++)
        {
            jac*=0.25;
            if(_irregNode == 1 and s != 0)
                extraTransl[0] += pow(0.5, s);
            if(_irregNode == 2 and s != 0)
                extraTransl[1] += pow(0.5, s);

            for (int n = 0; n < 4; n++)
            {
                if (n == _irregNode and s != (_numSubdiv-1))
                    continue;

                for(int g = 0; g < stdInfo.iPts; g++)
                {
                    _cubaInfo.wSamples.push_back(stdInfo.wSamples[g] * jac);

                    transfGauss(xBuffer, &stdInfo.xSamples[2*g], n, s);

                    _cubaInfo.xSamples.push_back(xBuffer[0] + extraTransl[0]);
                    _cubaInfo.xSamples.push_back(xBuffer[1] + extraTransl[1]);

                    ii++;
                }
            }

        }


       // ofstream ofile("refElem.xdat");
       // for (int g = 0; g < _cubaInfo.iPts; g++)
       // {
       //     if (g%stdInfo.iPts == 0)
       //         ofile << endl;
       //     ofile << setprecision(15) << _cubaInfo.xSamples[2*g+0] << " "  << _cubaInfo.xSamples[2*g+1] << endl;
       // }

       // if (int(_cubaInfo.wSamples.size()) != _cubaInfo.iPts or int(_cubaInfo.xSamples.size()) != _cubaInfo.iPts*_cubaInfo.pDim )
       //     throw runtime_error("CubatureIrregSubdivSurf::Update: Something has gone badly generating the gauss points. Expected Size: " + to_string(_cubaInfo.iPts) + "  Current Size: " + to_string(_cubaInfo.wSamples.size()));

       // ofile.close();

    }


    //Auxiliary functions
    void CubatureIrregSubdivSurf::_checkSettings()
    {
        if (_elemType == ElemType::Triang)
        {
            if (this->_iPts == 1)
            {}
            else if (this->_iPts == 3)
            {}
            else if (this->_iPts == 4)
            {}
            else if (this->_iPts == 6)
            {}
            else if (this->_iPts == 7)
            {}
            else if (this->_iPts == 12)
            {}
            else if (this->_iPts == 13)
            {}
            else if (this->_iPts == 16)
            {}
            else if (this->_iPts == 25)
            {}
            else if (this->_iPts == 54)
            {}
            else if (this->_iPts == 85)
            {}
            else if (this->_iPts == 126)
            {}
            else if (this->_iPts == 175)
            {}
            else
            {
                printf("ERROR: the number of Gauss points (%d) is wrong (see documentation)\n",
                       this->_iPts);
                throw runtime_error("CubatureIrregSubdivSurf: CheckSettings failed!!");
            }
        }
        else
        {
            throw runtime_error("CubatureIrregSubdivSurf: This cubature is only valid for Triangle.");
        }


    }

}
