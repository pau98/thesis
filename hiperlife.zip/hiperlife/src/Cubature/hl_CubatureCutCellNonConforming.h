/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATURECUTCELLNONCONFORMING_H
#define CUBATURECUTCELLNONCONFORMING_H


#include "hl_Cubature.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of a cubature using the cut cell method and a non-conforming approach
    */
    class CubatureCutCellNonConforming : public Cubature
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            CubatureCutCellNonConforming(){};
            CubatureCutCellNonConforming(const CubatureCutCellNonConforming& other) = default;
            CubatureCutCellNonConforming(CubatureCutCellNonConforming &&other) = default;
            ~CubatureCutCellNonConforming() = default;

            CubatureCutCellNonConforming& operator=(const CubatureCutCellNonConforming& other) = default;
            CubatureCutCellNonConforming& operator=(CubatureCutCellNonConforming&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a DOFsHandler object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the maximum number of subdivisions.
             *  \param numSubdiv: Maximum number of subdivisions
             */
            void setNumSubdiv(int numSubdiv){_numSubdiv = numSubdiv;};
            /*! \brief Sets the flags of the corner nodes (interior/exterior)
             *  \param cornerFlags: Vector of flags
             */
            void setCornerFlags(std::vector<int> cornerFlags){_cornerFlags = cornerFlags;};
            /*! \brief Sets the geometry of the immersed mesh with a set of points
             *  \param gPoints: Vector of points of the geometry
             */
            void setGeometry(std::vector<std::vector<double>> geomCoords){_geomCoords = geomCoords;};
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/

            void setImmersedSegments(std::vector<std::vector<std::vector<double>>> immersedSegments) { _immSegments = immersedSegments; };
            void setImmersedPoints(std::vector<std::vector<double>> immPts) { _immPts = immPts; };

            void Update() override;
            /** @} */ // end of object creation

        protected:

            //Auxiliary functions
            void _checkSettings() override;


        private:

            //Main variables
            int _numSubdiv{};
            std::vector<int> _cornerFlags = {};
            std::vector<std::vector<double>> _geomCoords;
            CubatureInfo _cubaInfoGauss;
            int _pDim{};
            int _nSubElems;

            std::vector<std::vector<std::vector<double>>> _immSegments;
            std::vector<std::vector<double>> _immPts;

            //Auxiliary functions
            void _subdivideElem(std::vector<double> cCoords, std::vector<int> cFlags, int level);
    };
}

#endif //CUBATURECUTCELLNONCONFORMING_H
