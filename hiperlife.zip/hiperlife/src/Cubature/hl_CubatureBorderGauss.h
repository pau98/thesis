/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATUREBORDER_H
#define CUBATUREBORDER_H

#include "hl_Cubature.h"
#include "hl_CubatureGauss.h"

namespace hiperlife
{

    /*!
     * \brief Implementation of a border integration for the imposition of Neumann boundary conditions.
    */
    class CubatureBorderGauss : public Cubature
    {
        public:

            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            CubatureBorderGauss(){};
            CubatureBorderGauss(const CubatureBorderGauss& other) = default;
            CubatureBorderGauss(CubatureBorderGauss &&other) = default;
            ~CubatureBorderGauss() = default;

            CubatureBorderGauss& operator=(const CubatureBorderGauss& other) = default;
            CubatureBorderGauss& operator=(CubatureBorderGauss&& other) = default;
            /** @} */ // end of constructors


            /** @name Object creation management
             * The parameters for the creation of the objects are set via these functions.
             * After all is introduced the object can be created through the Update() method.
             * Notice that not all the setters are needed for initiate a DOFsHandler object and,
             * in fact, several can be incompatible between each other.
             *  @{
             */
            /*! \brief Sets the side of the mesh.
             *  \param side Side of the mesh.
             */
            void setSide(int side){_side = side;}
            /*! \brief Method that actually creates the object. Before calling it the behavior is not guaranteed.*/
            void Update() override;
            /** @} */ // end of object creation


        protected:

            //Auxiliary functions
            void _checkSettings() override;

        private:

            //Main variables
            int _side;

    };
}

#endif // CUBATUREBORDER_H
