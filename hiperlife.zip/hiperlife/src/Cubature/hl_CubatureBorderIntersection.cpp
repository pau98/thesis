/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include "hl_CubatureBorderIntersection.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{
    void CubatureBorderIntersection::Update()
    {
        // Perform checks
        _checkSettings();

        // Initialize
        _pDim = computePDim(_elemType);

        // Create Gauss cubature to get the weights and integration points
        RCP<CubatureGauss> CubaG = rcp(new CubatureGauss);
        if (_pDim == 3)
        {
            CubaG->setElemType(ElemType::Line);
            CubaG->setNumIntPts(_iPts);
            CubaG->Update();
            _wSamples = CubaG->_wSamples;
        }
        else
        {
            _wSamples.resize(1);  //FIXME:: Shouldn't this be initialized to 1?
        }
        _xSamples.resize(_iPts * _pDim);

        // Set integration points
        if (_pDim == 2)
        {
            switch (static_cast<int>(_elemType))
            {
                case static_cast<int>(ElemType::Triang):
                    _wSamples[0] = 1.0;
                    switch (_borderIntersec)
                    {
                        case 0:
                            _xSamples[0] = 0.0;
                            _xSamples[1] = 0.0;
                            break;
                        case 1:
                            _xSamples[0] = 1.0;
                            _xSamples[1] = 0.0;
                            break;
                        case 2:
                            _xSamples[0] = 0.0;
                            _xSamples[1] = 1.0;
                            break;
                        default:
                            throw runtime_error("Border intersection " + to_string(_borderIntersec) + " does not make sense for element" + str(_elemType));
                            break;
                    }
                    break;
                case static_cast<int>(ElemType::Square):
                    _wSamples[0] = 1.0;
                    switch (_borderIntersec)
                    {
                        case 0:
                            _xSamples[0] = -1.0;
                            _xSamples[1] = -1.0;
                            break;
                        case 1:
                            _xSamples[0] = 1.0;
                            _xSamples[1] = -1.0;
                            break;
                        case 2:
                            _xSamples[0] = -1.0;
                            _xSamples[1] = 1.0;
                            break;
                        case 3:
                            _xSamples[0] = 1.0;
                            _xSamples[1] = 1.0;
                            break;
                        default:
                            throw runtime_error("Border intersection " + to_string(_borderIntersec) + " does not make sense for element" + str(_elemType));
                            break;
                    }
                    break;
                default:
                    throw runtime_error("CubatureBorderIntersection::Update: Element not implemented yet!");
                    break;
            }
        }
        else if (_pDim == 3)
        {
            for (int k{}; k < _iPts; k++)
            {
                switch (static_cast<int>(_elemType))
                {
                    case static_cast<int>(ElemType::Tetrah):
                        switch (_borderIntersec)
                        {
                            case 0:
                                _xSamples[k * _pDim] = 0.5 + 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 1] = 0.0;
                                _xSamples[k * _pDim + 2] = 0.0;
                                break;
                            case 1:
                                _xSamples[_pDim] = 0.0;
                                _xSamples[_pDim + 1] = 0.5 + 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 2] = 0.0;
                                break;
                            case 2:
                                _xSamples[k * _pDim] = 0.0;
                                _xSamples[k * _pDim + 1] = 0.0;
                                _xSamples[k * _pDim + 2] = 0.5 + 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                break;
                            case 3:
                                _xSamples[k * _pDim] = 0.0;
                                _xSamples[k * _pDim + 1] = 0.5 + 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 2] = 0.5 - 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                break;
                            case 4:
                                _xSamples[k * _pDim] = 0.5 + 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 1] = 0.0;
                                _xSamples[k * _pDim + 2] = 0.5 - 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                break;
                            case 5:
                                _xSamples[k * _pDim] = 0.5 + 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 1] = 0.5 - 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 2] = 0.0;
                                break;
                            default:
                                throw runtime_error("Border intersection " + to_string(_borderIntersec) + "does not make sense for element" + str(_elemType));
                                break;
                        }
                        break;
                    case static_cast<int>(ElemType::Parallelep):
                        switch (_borderIntersec)
                        {
                            case 0:
                                _xSamples[k * _pDim] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 1] = -1.0;
                                _xSamples[k * _pDim + 2] = -1.0;
                                break;
                            case 1:
                                _xSamples[k * _pDim] = 1.0;
                                _xSamples[k * _pDim + 1] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 2] = -1.0;
                                break;
                            case 2:
                                _xSamples[k * _pDim] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 1] = 1.0;
                                _xSamples[k * _pDim + 2] = -1.0;
                                break;
                            case 3:
                                _xSamples[k * _pDim] = -1.0;
                                _xSamples[k * _pDim + 1] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 2] = -1.0;
                                break;
                            case 4:
                                _xSamples[k * _pDim] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 1] = -1.0;
                                _xSamples[k * _pDim + 2] = 1.0;
                                break;
                            case 5:
                                _xSamples[k * _pDim] = 1.0;
                                _xSamples[k * _pDim + 1] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 2] = 1.0;
                                break;
                            case 6:
                                _xSamples[k * _pDim] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 1] = 1.0;
                                _xSamples[k * _pDim + 2] = 1.0;
                                break;
                            case 7:
                                _xSamples[k * _pDim] = -1.0;
                                _xSamples[k * _pDim + 1] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                _xSamples[k * _pDim + 2] = 1.0;
                                break;
                            case 8:
                                _xSamples[k * _pDim] = -1.0;
                                _xSamples[k * _pDim + 1] = -1.0;
                                _xSamples[k * _pDim + 2] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                break;
                            case 9:
                                _xSamples[k * _pDim] = 1.0;
                                _xSamples[k * _pDim + 1] = -1.0;
                                _xSamples[k * _pDim + 2] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                break;
                            case 10:
                                _xSamples[k * _pDim] = 1.0;
                                _xSamples[k * _pDim + 1] = 1.0;
                                _xSamples[k * _pDim + 2] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                break;
                            case 11:
                                _xSamples[k * _pDim] = -1.0;
                                _xSamples[k * _pDim + 1] = 1.0;
                                _xSamples[k * _pDim + 2] = 0.5 * CubaG->_xSamples[k * (_pDim - 2)];
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        throw runtime_error("CubatureBorderIntersection::Update: Element not implemented yet!");
                        break;
                }
            }
        }

        // Create the cubainfo using the computed info
        _cubaInfo.iPts = _iPts;
        _cubaInfo.pDim = _pDim;
        _cubaInfo.xSamples = _xSamples;
        _cubaInfo.wSamples = _wSamples;
        _cubaInfo.cubaName = "CubatureBorderIntersection";
    }

    void CubatureBorderIntersection::_checkSettings()
    {
        if (_elemType == ElemType::Line)
            throw runtime_error("CubatureBorderIntersection:: There are no boundary intersections in 1D problems!");

        if (_pDim == 1 and _iPts > 1)
            throw runtime_error("CubatureBorderIntersection:: Only one integration point is acceptable for 2D problems.");
    }
} // namespace hiperlife
