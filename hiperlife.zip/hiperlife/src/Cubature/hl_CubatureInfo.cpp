/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <iostream>
#include <array>
#include <vector>
#include <algorithm>
#include <numeric>

#include "hl_Math.h"
#include "hl_CubatureInfo.h"


namespace hiperlife
{

    void macroPDim2N4Transf(double *macroX, double *origX, int n, int reorderTag)
    {
        std::array<double, 4> linTransf{};
        std::array<double, 2> transl{};

        if (n == 0)
        {

            if (reorderTag == 0)
            {
                linTransf = {0.5, 0.0, 0.0, 0.5};
                transl    = {0.0, 0.0};
            }
            else if (reorderTag == 1)
            {
                linTransf = {-0.5, -0.5, 0.5, 0.0};
                transl    = {0.5, 0.0};

            }
            else if (reorderTag == 2)
            {
                linTransf = {0.0, 0.5, -0.5, -0.5};
                transl    = {0.0, 0.5};
            }
        }
        else if (n == 1)
        {

            if (reorderTag == 0)
            {
                linTransf = {0.5, 0.0, 0.0, 0.5};
                transl   = {0.5, 0};
            }
            else if (reorderTag == 1)
            {
                linTransf = {-0.5, -0.5, 0.5, 0.0};
                transl    = {1.0, 0.0};

            }
            else if (reorderTag == 2)
            {
                linTransf = {0.0, 0.5, -0.5, -0.5};
                transl    = {0.5, 0.5};
            }



        }
        else if (n == 2)
        {
            if (reorderTag == 2)
            {
                linTransf = {0.5, 0.0, 0.0, 0.5};
                transl    = {0.0, 0.5};
            }
            else if (reorderTag == 0)
            {
                linTransf = {-0.5, -0.5, 0.5, 0.0};
                transl    = {0.5, 0.5};

            }
            else if (reorderTag == 1)
            {
                linTransf = {0.0, 0.5, -0.5, -0.5};
                transl    = {0.0, 1.0};
            }
        }
        else if (n == 3)
        {
            if (reorderTag == 0)
            {
                linTransf = {0.0, -0.5, 0.5, 0.5};
                transl    = {0.5, 0.0};
            }
            else if (reorderTag == 1)
            {
                linTransf = {-0.5, 0.0, 0.0, -0.5};
                transl    = {0.5, 0.5};

            }
            else if (reorderTag == 2)
            {
                linTransf = {0.5, 0.5, -0.5, 0.0};
                transl    = {0.0, 0.5};
            }

        }

        Math::MatProduct(macroX, 2, 2 ,1, linTransf.data(), origX);
        Math::AXPY(macroX , 2, 1.0, transl.data());
    }

    void macroPDim1N2Transf(double *macroX, double *origX, int n, int reorderTag)
    {
        const double xM = n==0 ? -1 : +1.0;
        macroX[0] = 0.5*(origX[0] + xM);
    }

    CubatureInfo generateMacroCubaInfo(std::vector<CubatureInfo> info, int macroFactor, int slaveRot, std::vector<int> reorderTags)
    {
        CubatureInfo macroInfo;

        std::vector<int> macroReord(macroFactor);
        std::iota (std::begin(macroReord), std::end(macroReord), 0);

        //FIXME: this is only for triangles...
        if (macroFactor == 4)
            std::rotate(macroReord.begin(),macroReord.begin()+macroFactor-1-slaveRot,macroReord.end()-1);

        if (macroFactor != 4 && macroFactor != 2)
            throw std::runtime_error("CubatureInfo::_generateCubatureLagrMultiplMacroElems: only working for triangles at the moment...");

        int macrokPts = 0;
        std::vector<int> offs(macroFactor);
        for (int n = 0; n < macroFactor; n++)
        {
            offs[n] = macrokPts;
            macrokPts += info[n].iPts;
        }

        macroInfo.iPts = macrokPts;
        macroInfo.pDim = info[0].pDim;

        macroInfo.wSamples.resize(macrokPts);
        macroInfo.xSamples.resize(macrokPts * macroInfo.pDim);


        // Setting the offsets of the MacroCubaInfo
        macroInfo.macroOffsets.resize(macroFactor);

        for (int n = 0; n < macroFactor; n++)
        {
            macroInfo.macroOffsets[n] = offs[n];
            int kF = offs[n];
            int x_kF = kF*macroInfo.pDim;

            for (int k = 0; k < info[n].iPts; k++)
            {
                macroInfo.wSamples[kF + k] = info[n].wSamples[k];
                if(macroFactor == 2)
                    macroPDim1N2Transf(&macroInfo.xSamples[x_kF + k *info[n].pDim], &info[n].xSamples[k*info[n].pDim], macroReord[n], reorderTags[n]);
                else if(macroFactor == 4)
                    macroPDim2N4Transf(&macroInfo.xSamples[x_kF + k *info[n].pDim], &info[n].xSamples[k*info[n].pDim], macroReord[n], reorderTags[n]);
            }
        }

        return macroInfo;
    }



    std::ostream& operator<<(std::ostream& os, const CubatureInfo& info)
    {
        using std::endl;

        os << "CubatureInfo:: " << info.cubaName << " " << info.cubaType << endl;
        os << "  iPts:   " << info.iPts << endl;
        os << "  iPts:   " << info.iPts << endl;
        os << "  Pdim:   " << info.pDim << endl;
        os << "  xSamples:";
        for(auto x : info.xSamples)
            os << "  "  << x;
        os << endl;
        os << "  wSamples:";
        for(auto w : info.wSamples)
            os << "  "  << w;
        os << endl;

        return os;
    }

}
