/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/



#include "hl_CubatureBasic.h"


using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    void CubatureBasic::Update()
    {
        //Initialize
        _pDim = computePDim(_elemType);
        _iPts = _wSamples.size();

        // Perform checks
        _checkSettings();

        // Initialize cubrature info
        _cubaInfo.cubaName = "CubatureBasic";
        _cubaInfo.pDim = _pDim;
        _cubaInfo.iPts = _iPts;
        _cubaInfo.xSamples = _xSamples;
        _cubaInfo.wSamples = _wSamples;
    }

    void CubatureBasic::_checkSettings()
    {
        if (_wSamples.size()*_pDim != _xSamples.size())
            throw runtime_error("CubatureBasic:: The number of integration points coordinates does not match with the number of integration weights.");
    }
}
