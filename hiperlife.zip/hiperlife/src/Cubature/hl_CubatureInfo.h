/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef CUBATUREINFO_H
#define CUBATUREINFO_H

#include <vector>
#include <iostream>

#include "hl_DistributedClass.h"

namespace hiperlife
{
    /*!
     * \class CubatureInfo
     * \brief Class that contains all the essential information of a cubature
     *
    */
    class CubatureInfo
    {
        public:
            /** @name Constructor / Destructor / Operator
                Copy constructors are deleted for memory safety but objects can be created from
                temporal objects through move constructors
            *  @{ */
            CubatureInfo() = default;
            CubatureInfo(CubatureInfo&&) = default;
            CubatureInfo(const CubatureInfo&) = default;
            ~CubatureInfo() = default;
            //Operators
            CubatureInfo& operator=(CubatureInfo&&) = default;
            CubatureInfo& operator=(const CubatureInfo&) = default;
            /** @} */ // end of constructors


            /** @name Expert users and developers only variables
             *  @{ */
            /*! \brief Parametric dimension.*/
            int pDim{};
            /*! \brief Number of integration points.*/
            int iPts{};
            /*! \brief Vector with the ref. coordinates of the integration points.*/
            std::vector<double> xSamples;
            /*! \brief Vector with the integration weights of the integration points.*/
            std::vector<double> wSamples;
            /*! \brief Name of the cubature.*/
            std::string cubaName;
            /** @} */ // end of expert users and developers only variables


            /** @name Expert users and developers only variables cuba specific
             *  @{ */
            /*! \brief Type of cubature. It is only used to get the tangents in the cubatureBorderGauss by storing the information of the element side.*/
            int cubaType{}; //FIXME:: Change name?
            /*! \brief Offsets of a cubature respect to its master.*/
            std::vector<double> macroOffsets;
            /** @} */ // end of expert users and developers only variables cuba spec.


            friend std::ostream& operator<<(std::ostream& os, const CubatureInfo& info);

    };


    CubatureInfo generateMacroCubaInfo(std::vector<CubatureInfo>, int, int, std::vector<int> = {0, 0, 0, 0});

}






#endif // CUBATUREINFO_H
