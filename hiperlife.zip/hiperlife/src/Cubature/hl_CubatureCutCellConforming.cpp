/*
    *******************************************************************************
    Copyright (c) 2017-2021 Universitat Politècnica de Catalunya
    Authors: Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
    *******************************************************************************
    This file is part of hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Distributed under the MIT software license, see the accompanying
    file LICENSE or http://www.opensource.org/licenses/mit-license.php.
    *******************************************************************************
*/

#include <algorithm> // sort, unique
#include <array>
#include <math.h>
#include <numeric> // std::accumulate
#include <vector>

#include "hl_Math.h"
#include "hl_Geometry.h"
#include "hl_CubatureGauss.h"
#include "hl_CubatureCutCellConforming.h"
#include "hl_TypeDefs.h"
#include "earcut/earcut.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{
    void CubatureCutCellConforming::_linearSquareBasisFunctions(vector<double> & bfs, double u, double v)
    {
        // Compute basis function
        bfs[0] = 0.25*(1.0-u)*(1.0-v);
        bfs[1] = 0.25*(1.0+u)*(1.0-v);
        bfs[2] = 0.25*(1.0-u)*(1.0+v);
        bfs[3] = 0.25*(1.0+u)*(1.0+v);
    }

    void CubatureCutCellConforming::_linearTriangBasisFunctions(vector<double> & bfs, double u, double v)
    {
        // Compute basis function
        bfs[0] = 1.0-u-v;
        bfs[1] =     u  ;
        bfs[2] =     v  ;
    }

    // Find the distance of point C from both the line end points A, B. If AB = AP + PB,
    // then C lies on the line segment AB.
    bool isPointOnSegment(const int N, vector<double> A, vector<double> B, vector<double> P, double tol)
    {
        double AB = Math::Dist(N, A.data(), B.data());
        double AP = Math::Dist(N, A.data(), P.data());
        double BP = Math::Dist(N, B.data(), P.data());

        if (AP < tol or BP < tol)
        {
            return true;
        }
        else if (fabs(AB - AP - BP) < tol)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    void CubatureCutCellConforming::Update()
    {
        // Checks
        if (_elemType != ElemType::Square)
            throw runtime_error("CubatureCutCellConforming::Cubature implemented only for Square for now.");

        // Perform checks
        _checkSettings();

        // Initialize
        _pDim = computePDim(_elemType);

        // Define for earcut algorithm
        using N = uint32_t;
        using Point = std::array<double, 2>;

        // --------------------------------------------------------------------
        // Polygons of the region in the reference element (rings: outer first, then holes)
        // --------------------------------------------------------------------

        vector<vector<vector<Point>>> polygons;
        if (_usePolygons)
        {
            for (auto& poly : _polygons)
            {
                polygons.push_back({});
                for (auto& ring : poly)
                {
                    polygons.back().push_back({});
                    for (auto& pt : ring)
                        polygons.back().back().push_back({pt[0], pt[1]});
                }
            }
        }
        else
        {
            for (auto& ring : _segmentPolygons())
                polygons.push_back({ring});
        }

        // --------------------------------------------------------------------
        // Create triangulation
        // --------------------------------------------------------------------

        // Create mesh
        vector<vector<vector<double>>> Triangs(0); // (triang, coord, node)
        for (auto& polygon_ear: polygons)
        {
            // Vertices of all the rings, in the order earcut numbers them
            std::vector<Point> vertices;
            for (auto& ring : polygon_ear)
                vertices.insert(vertices.end(), ring.begin(), ring.end());

            // Run tessellation
            std::vector<N> indices = mapbox::earcut<N>(polygon_ear);

            // Add each triangle
            vector<vector<vector<double>>> polyTriangs;
            double ATriangs{};
            for (size_t t = 0; t < indices.size()/3; t++)
            {
                vector<vector<double>> T(2, vector<double>(3));
                for (int n = 0; n < 3; n++)
                {
                    int id = indices[t*3+n];
                    T[0][n] = vertices[id][0];
                    T[1][n] = vertices[id][1];
                }
                polyTriangs.push_back(T);
                double p0[2] = {T[0][0], T[1][0]}, p1[2] = {T[0][1], T[1][1]}, p2[2] = {T[0][2], T[1][2]};
                ATriangs += SGeometry::AreaTriangle2D(p0, p1, p2);
            }

            // Earcut can misplace triangles in degenerate polygons (pinches, vertices on edges): if the triangles do
            // not add up to the area of the polygon, triangulate it by vertical slabs instead
            double APolygon{};
            for (size_t r = 0; r < polygon_ear.size(); r++)
            {
                double A{};
                for (size_t i = 0; i < polygon_ear[r].size(); i++)
                {
                    const Point& a = polygon_ear[r][i];
                    const Point& b = polygon_ear[r][(i+1)%polygon_ear[r].size()];
                    A += 0.5*(a[0]*b[1] - b[0]*a[1]);
                }
                APolygon += (r == 0) ? fabs(A) : -fabs(A);
            }
            if (fabs(ATriangs - APolygon) > 1e-12)
                polyTriangs = _slabTriangles(polygon_ear);

            Triangs.insert(Triangs.end(), polyTriangs.begin(), polyTriangs.end());
        }


        // --------------------------------------------------------------------
        // Get cuba infos
        // --------------------------------------------------------------------

        // Get the cubature info of a Gauss quadrature for a triang
        int _iPtsT = computeDefaultNumGPts(ElemType::Triang, _intOrder);
        // cout<< "Int triangs order:" << _intOrder << " NPTs: "<<_iPtsT<< endl;
        RCP<CubatureGauss> cubaGaussTriang = rcp(new CubatureGauss);
        cubaGaussTriang->setElemType(ElemType::Triang);
        cubaGaussTriang->setNumIntPts(_iPtsT);
        cubaGaussTriang->Update();
        _cubaInfoGaussTriang = cubaGaussTriang->cubatureInfo();

        // Save basis functions for the triang
        vector<vector<double>> BFsT(_iPtsT, vector<double>(3));
        for (int k = 0; k < _iPtsT; k++)
        {
            double u = _cubaInfoGaussTriang.xSamples[2*k+0];
            double v = _cubaInfoGaussTriang.xSamples[2*k+1];
            _linearTriangBasisFunctions(BFsT[k], u, v);
        }

        // --------------------------------------------------------------------
        // Compute xsamples and wsamples for each subelement
        // --------------------------------------------------------------------

        // // Break if the area of the polygon is smaller than a tolerance
        // double A_Triang{};
        // for (size_t t = 0; t < Triangs.size(); t++)
        // {
        //     // Compute area
        //     vector<double> p0 = {Triangs[t][0][0], Triangs[t][1][0]};
        //     vector<double> p1 = {Triangs[t][0][1], Triangs[t][1][1]};
        //     vector<double> p2 = {Triangs[t][0][2], Triangs[t][1][2]};
        //     A_Triang += SGeometry::AreaTriangle2D(p0.data(), p1.data(), p2.data());
        // }
        // if (A_Triang < -4.0/100.0)
        // {
        //     cout << "Removing integration points of element " << _elem << setprecision(16) << " A = " << A_Triang << endl;
        //     return;
        // }

        // Compute xsamples and wsamples
        for (size_t t = 0; t < Triangs.size(); t++)
        {
            // Compute area
            vector<double> p0 = {Triangs[t][0][0], Triangs[t][1][0]};
            vector<double> p1 = {Triangs[t][0][1], Triangs[t][1][1]};
            vector<double> p2 = {Triangs[t][0][2], Triangs[t][1][2]};
            double A = SGeometry::AreaTriangle2D(p0.data(), p1.data(), p2.data());

            // Compute xsamples and wsamples
            for (int k = 0; k < _iPtsT; k++)
            {
                // Compute xsamples
                double x = Math::Dot(3, Triangs[t][0].data(), BFsT[k].data());
                double y = Math::Dot(3, Triangs[t][1].data(), BFsT[k].data());
                _xSamples.push_back(x);
                _xSamples.push_back(y);

                // Compute wsamples
                _wSamples.push_back(_cubaInfoGaussTriang.wSamples[k]*A/0.5);
            }
        }


        // --------------------------------------------------------------------
        // Compute the info for the cubature
        // --------------------------------------------------------------------

        // Create cubature info
        _iPts = _wSamples.size();
        _cubaInfo.cubaName = "CubatureCutCellConforming";
        _cubaInfo.pDim = _pDim;
        _cubaInfo.iPts = _iPts;
        _cubaInfo.xSamples = _xSamples;
        _cubaInfo.wSamples = _wSamples;


        return;
    }

    vector<vector<vector<double>>> CubatureCutCellConforming::_slabTriangles(const vector<vector<array<double, 2>>>& rings)
    {
        // Between consecutive vertex abscissae the edges crossing the slab do not cross each other, and taken in
        // order of height, pairs of them bound trapezoids of the polygon (holes included). Only sorting and
        // interpolation: valid for degenerate polygons too, with more triangles than earcut
        vector<array<double, 4>> edges; // {x0, y0, x1, y1} with x0 < x1 (vertical edges do not cross any slab)
        vector<double> xs;
        for (auto& ring : rings)
        {
            for (size_t i = 0; i < ring.size(); i++)
            {
                const array<double, 2>& a = ring[i];
                const array<double, 2>& b = ring[(i+1)%ring.size()];
                xs.push_back(a[0]);
                if (a[0] < b[0])
                    edges.push_back({a[0], a[1], b[0], b[1]});
                else if (b[0] < a[0])
                    edges.push_back({b[0], b[1], a[0], a[1]});
            }
        }
        sort(xs.begin(), xs.end());
        xs.erase(unique(xs.begin(), xs.end()), xs.end());

        vector<vector<vector<double>>> triangs; // (triang, coord, node)
        for (size_t s = 0; s + 1 < xs.size(); s++)
        {
            double xa = xs[s];
            double xb = xs[s+1];
            double xm = 0.5*(xa + xb);
            vector<array<double, 3>> cross; // heights of the edges crossing the slab at xm, xa and xb
            for (auto& e : edges)
            {
                if (e[0] <= xa and e[2] >= xb)
                {
                    auto y = [&](double x) { return x == e[0] ? e[1] : (x == e[2] ? e[3] : e[1] + (x - e[0])*(e[3] - e[1])/(e[2] - e[0])); };
                    cross.push_back({y(xm), y(xa), y(xb)});
                }
            }
            sort(cross.begin(), cross.end());
            for (size_t k = 0; k + 1 < cross.size(); k += 2)
            {
                const array<double, 3>& lo = cross[k];
                const array<double, 3>& up = cross[k+1];
                triangs.push_back({{xa, xb, xb}, {lo[1], lo[2], up[2]}});
                triangs.push_back({{xa, xb, xa}, {lo[1], up[2], up[1]}});
            }
        }
        return triangs;
    }

    vector<vector<array<double, 2>>> CubatureCutCellConforming::_segmentPolygons()
    {
        // Polygons from the immersed segments and the corner flags
        // --------------------------------------------------------------------
        // Compute subelements
        // --------------------------------------------------------------------

        // Compute polygon with element corners
        vector<vector<double>> corners = referenceCoordsElemCorners(elemType());
        iter_swap(corners.begin() + 2, corners.begin() + 3);
        corners.push_back(corners[0]);
        vector<int> c = {0,1,3,2,0};

        // Create segments of the border
        vector<vector<vector<double>>> borderSegments;
        for (int b = 0; b < 4; b++)
        {
            // Compute all intersections of a border with the immersed segments
            vector<vector<double>> Intersections;
            // cout << "Size imm segments: " << _immSegments.size() << endl;
            for (size_t s = 0; s < _immSegments.size(); s++)
            {
                // cout << "Start: ("<<_immSegments[s][0][0]<< "," <<_immSegments[s][0][1]<< ")" << endl;
                // cout << "End: ("<<_immSegments[s][1][0]<< "," <<_immSegments[s][1][1]<< ")" << endl;
                vector<double> I(2);
                bool linesIntersect = SGeometry::intersect2DLines(corners[b], corners[b+1], _immSegments[s][0], _immSegments[s][1], I);
                bool isOnBorder  = isPointOnSegment(2, corners[b], corners[b+1], I, 1e-6);
                bool isOnSegment = isPointOnSegment(2, _immSegments[s][0], _immSegments[s][1], I, 1e-6);
                if (linesIntersect and isOnBorder and isOnSegment)
                {
                    Intersections.push_back(I);
                }
            }

            // Remove repeated intersections
            std::sort(Intersections.begin(), Intersections.end());
            Intersections.erase(std::unique(Intersections.begin(),
                                            Intersections.end(),
                                            [](vector<double> a, vector<double> b)
                                            {
                                                return Math::Dist2D(a.data(), b.data()) < 1e-6;
                                            }), Intersections.end() );

            
            // Split the segment if necessary
            if (Intersections.size() == 0)
            {
                if (_cornerFlags[c[b]]%_regionTag == 0 and _cornerFlags[c[b+1]]%_regionTag == 0)
                {
                    borderSegments.push_back({corners[b], corners[b+1]});
                }
                else if (_cornerFlags[c[b]]%_regionTag != 0 and _cornerFlags[c[b+1]]%_regionTag != 0)
                {
                    // Do nothing
                }
                else
                {
                    // Do nothing
                    // throw runtime_error("CubatureCutCellConforming:: Update: Case with " + to_string(Intersections.size()) + " intersections. Something is wrong.");
                }
            }
            else if (Intersections.size() == 1)
            {
                if (_cornerFlags[c[b]]%_regionTag == 0 and _cornerFlags[c[b+1]]%_regionTag != 0)
                {
                    borderSegments.push_back({corners[b], Intersections[0]});
                }
                else if (_cornerFlags[c[b]]%_regionTag != 0 and _cornerFlags[c[b+1]]%_regionTag == 0)
                {
                    borderSegments.push_back({Intersections[0], corners[b+1]});
                }
                else
                {
                    // throw runtime_error("CubatureCutCellConforming:: Update: Case with " + to_string(Intersections.size()) + " intersections. Something is wrong.");
                }
            }
            else if (Intersections.size() == 2)
            {
                if (_cornerFlags[c[b]]%_regionTag != 0 and _cornerFlags[c[b+1]]%_regionTag != 0)
                {
                    borderSegments.push_back({Intersections[0], Intersections[1]});
                }
                else if (_cornerFlags[c[b]]%_regionTag == 0 and _cornerFlags[c[b+1]]%_regionTag == 0)
                {
                    double dist0 = Math::SDist2D(corners[b].data(), Intersections[0].data());
                    double dist1 = Math::SDist2D(corners[b].data(), Intersections[1].data());
                    if (dist0 < dist1)
                    {
                        borderSegments.push_back({corners[b], Intersections[0]});
                        borderSegments.push_back({Intersections[1], corners[b+1]});
                    }
                    else
                    {
                        borderSegments.push_back({corners[b], Intersections[1]});
                        borderSegments.push_back({Intersections[0], corners[b+1]});
                    }
                }
                else
                {
                    throw runtime_error("CubatureCutCellConforming:: Update: Case with " + to_string(Intersections.size()) + " intersections. Something is wrong.");
                }
            }
            else
            {
                throw runtime_error("CubatureCutCellConforming:: Update: Case with " + to_string(Intersections.size()) + " intersections (boundary " + to_string(b) + ") not implemented (yet).");
            }
        }

        // Add third dimension // FIXME: Check if necessary
        for (size_t b = 0; b < borderSegments.size(); b++)
        {
            for (size_t n = 0; n < borderSegments[b].size(); n++)
                borderSegments[b][n].push_back(0.0);
        }

        // Put ends of immersed segments on the boundary of the square
        for (size_t s = 0; s < _immSegments.size(); s++)
        {
            vector<int> sides = {0,1,2,3};
            for (size_t n = 0; n < _immSegments[s].size(); n++)
            {
                bool nodeOutside{false};
                if (_immSegments[s][n][0] < -1.0 or _immSegments[s][n][0] > 1.0 or
                    _immSegments[s][n][1] < -1.0 or _immSegments[s][n][1] > 1.0)
                    nodeOutside = true;

                if (nodeOutside)
                {
                    double dist = numeric_limits<double>::max();
                    vector<double> Intersection(3);
                    for (size_t i = 0; i < sides.size(); i++)
                    {
                        vector<double> I(2);
                        bool linesIntersect = SGeometry::intersect2DLines(corners[sides[i]], corners[sides[i]+1], _immSegments[s][0], _immSegments[s][1], I);
                        if (linesIntersect)
                        {
                            bool segmentsIntersect0 = isPointOnSegment(2, corners[sides[i]], corners[sides[i]+1], I, 1e-13);
                            I.push_back(0.0);
                            bool segmentsIntersect1 = isPointOnSegment(2, _immSegments[s][0], _immSegments[s][1], I, 1e-13);
                            double dist2 = Math::Dist2D(_immSegments[s][n].data(), I.data());
                            if (segmentsIntersect0 and segmentsIntersect1 and dist2 < dist)
                            {
                                dist = dist2;
                                Intersection = I;
                            }
                        }
                    }
                    _immSegments[s][n] = Intersection;
                }
            }
        }

        // Add border segments to immersed segments
        _immSegments.insert(_immSegments.end(), borderSegments.begin(), borderSegments.end() );

        // Remove segments with zero length (after cutting them)
        for (int s = static_cast<int>(_immSegments.size()-1); s >= 0; s--)
        {
            double dist = SGeometry::distanceTwoPoints(_immSegments[s][0], _immSegments[s][1]);
            if (dist < 1e-6)
            {
                _immSegments.erase(_immSegments.begin()+s);
            }
        }

        // Create connectivity (between segments)
        vector<vector<int>> connec(_immSegments.size(),vector<int>(2, -1));
        for (size_t s = 0; s < _immSegments.size(); s++)
        {
            for (size_t n = 0; n < _immSegments[s].size(); n++)
            {
                vector<double> coords = _immSegments[s][n];
                for (size_t s1 = 0; s1 < _immSegments.size(); s1++)
                {
                    if (s1 != s)
                    {
                        for (size_t n1 = 0; n1 < _immSegments[s1].size(); n1++)
                        {
                            double d = Math::Dist2D(coords.data(), _immSegments[s1][n1].data());
                            if (d < 1e-6)
                            {
                                connec[s][n] = s1;
                            }
                        }
                    }
                }
            }
        }

        // Count number of -1 ids in the connectivity
        int numberOfNegIds{0};
        vector<int> segNegIds;
        vector<int> sideNegIds;
        for (size_t s = 0; s < _immSegments.size(); s++)
        {
            for (size_t n = 0; n < connec[s].size(); n++)
            {
                if (connec[s][n] == -1)
                {
                    numberOfNegIds++;
                    segNegIds.push_back(s);
                    sideNegIds.push_back(n);
                }
            }
        }

        // Fix -1 ids in the connectivity (if # is 2)
        if (numberOfNegIds == 2)
        {
            // Replace -1s in the connectivity
            for (size_t s = 0; s < _immSegments.size(); s++)
            {
                for (size_t n = 0; n < connec[s].size(); n++)
                {
                    if (connec[s][n] == -1)
                    {
                        connec[s][n] = _immSegments.size();
                    }
                }
            }

            // Add connectivity of the new segment
            connec.push_back({segNegIds[0],segNegIds[1]});

            // Add new segment
            vector<vector<double>> newSegment(2, vector<double>(3));
            newSegment[0] = _immSegments[segNegIds[0]][sideNegIds[0]];
            newSegment[1] = _immSegments[segNegIds[1]][sideNegIds[1]];
            _immSegments.push_back(newSegment);
        }
        else if (numberOfNegIds > 0)
        {
            throw runtime_error("CubatureCutCellConforming::Update: The number of -1 occurrences int the connectivity is != 2.");
        }

        // Define for earcut algorithm
        using Coord = double;
        using N = uint32_t;
        using Point = std::array<Coord, 2>;

        // Create polygons (each element in the polygon is a segment)
        vector<int> touched(_immSegments.size(), 1);
        vector<vector<Point>> polygons;
        int polID{};
        while (std::accumulate(touched.begin(), touched.end(), 0) != 0)
        {
            // FIXME: Un-elegant way to avoid errors
            if (std::accumulate(touched.begin(), touched.end(), 0) < 3)
            {
                cout << "CubatureCutCellConforming::Update: Warning: There are one or two points points hanging when creating the polygons." << endl;

                break;
            }

            // Resize polygons
            polygons.resize(polygons.size()+1);

            // Find last untouched segment
            // We are using the last so that we start from a corner node
            int id = touched.rend() - std::find(touched.rbegin(), touched.rend(), 1)-1;
            polygons[polID].push_back({_immSegments[id][0][0], _immSegments[id][0][1]});
            touched[id] = 0;

            // Loop using the connectivity until loop is closed
            int idPrev = id;
            while (true) // FIXME
            {
                int side{1};
                int nextId = connec[id][1];
                if (nextId == idPrev)
                {
                    side = 0;
                    nextId = connec[id][0];
                }
                if (touched[nextId] == 1)
                {
                    polygons[polID].push_back({_immSegments[id][side][0], _immSegments[id][side][1]});
                    touched[nextId] = 0;
                    idPrev = id;
                    id = nextId;
                }
                else
                {
                    break;
                }
            }

            // Increase polygon
            polID++;
        }

        return polygons;
    }

    void CubatureCutCellConforming::_checkSettings()
    {
        // The number of int points is already checked when creating the Gauss cubature

        // Check integration order
        if (_intOrder <= 0)
            throw runtime_error("CubatureCutCellConforming::_checkSettings: Integration order not set.");

        // Check element type
        if (_elemType != ElemType::Square and _elemType != ElemType::Parallelep)
            throw runtime_error("CubatureCutCellConforming::_checkSettings: Cubature implemented only for Square or Parallelep elements.");

        // The polygons of the region are given: no corner flags nor immersed segments needed
        if (_usePolygons)
            return;

        // Check node flags
        if (_cornerFlags.empty())
            throw runtime_error("CubatureCutCellConforming::_checkSettings: Corner flags not set.");
        else if (_elemType == ElemType::Square and _cornerFlags.size() != 4)
            throw runtime_error("CubatureCutCellConforming::_checkSettings: There must be four corner flags for Square elements.");
        else if (_elemType == ElemType::Parallelep and _cornerFlags.size() != 8)
            throw runtime_error("CubatureCutCellConforming::_checkSettings: There must be eight corner flags for Parallelep elements.");

        // Check immersed mesh points
        if (_immSegments.empty())
        {
            int myRank{};
            MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
            throw runtime_error("From CPU " + to_string(myRank) + ": CubatureCutCellConforming::_checkSettings: immersed mesh not set.");
        }
        if (_pDim == 3 and _immPts.empty())
        {
            int myRank{};
            MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
            throw runtime_error("From CPU " + to_string(myRank) + ": CubatureCutCellConforming::_checkSettings: immersed points not set.");
        }
    }
}
