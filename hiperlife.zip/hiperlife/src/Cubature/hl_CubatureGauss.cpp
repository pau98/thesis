/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <math.h>

#include "hl_CubatureGauss.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;


namespace hiperlife
{

    //Object creation management
    void CubatureGauss::Update()
    {
        _checkSettings();

        _wSamples.resize(_iPts);

        // Performing the quadrature in the reference element
        switch(static_cast<int>(_elemType))
        {
            case static_cast<int>(ElemType::Line):
                _pDim = 1;
                _xSamples.resize(_iPts * _pDim);
                // _quadratureRule();
                _lineRule();
                break;
            case static_cast<int>(ElemType::Triang):
                _pDim = 2;
                _xSamples.resize(_iPts * _pDim);
                _triangularRule();
                break;
            case static_cast<int>(ElemType::Square):
                _pDim = 2;
                _xSamples.resize(_iPts * _pDim);
                _quadrilateralRule();
                break;
            case static_cast<int>(ElemType::Tetrah):
                _pDim = 3;
                _xSamples.resize(_iPts * _pDim);
                _tetrahedralRule();
                break;
            case static_cast<int>(ElemType::Parallelep):
                _pDim = 3;
                _xSamples.resize(_iPts * _pDim);
                _parallelepipedalRule();
                break;
        }


        _cubaInfo.iPts = _iPts;
        _cubaInfo.pDim = _pDim;
        _cubaInfo.xSamples = _xSamples;
        _cubaInfo.wSamples = _wSamples;
        _cubaInfo.cubaName = "CubatureGauss";
    }

    void CubatureGauss::_checkSettings()
    {
        // Line quadrature rule
        if (_elemType == ElemType::Line)
        {
            if (this->_iPts == 1){}
            else if (this->_iPts ==  2){}
            else if (this->_iPts ==  3){}
            else if (this->_iPts ==  4){}
            else if (this->_iPts ==  5){}
            else if (this->_iPts ==  6){}
            else if (this->_iPts ==  7){}
            else if (this->_iPts ==  8){}
            else if (this->_iPts ==  9){}
            else if (this->_iPts == 10){}
            else if (this->_iPts == 15){}
            else
            {
                printf("ERROR: the number of Gauss points (%d) is wrong (see documentation)\n",
                       this->_iPts);
                throw runtime_error("CubatureGauss: CheckSettings failed!!");
            }
        }


        if (_elemType == ElemType::Triang)
        {
            if (this->_iPts == 1){}
            else if (this->_iPts  ==   3){}
            // else if (this->_iPts  ==   4){} //FIXME:: Cubature deactivated (negative weights not working)
            else if (this->_iPts  ==   6){}
            else if (this->_iPts  ==   7){}
            else if (this->_iPts  ==  12){}
            // else if (this->_iPts  ==  13){} //FIXME:: Cubature deactivated (negative weights not working)
            else if (this->_iPts  ==  16){}
            else if (this->_iPts  ==  25){}
            else if (this->_iPts  ==  54){}
            else if (this->_iPts  ==  85){}
            else if (this->_iPts  == 126){}
            else if (this->_iPts  == 175){}
            else
            {
                printf("ERROR: the number of Gauss points (%d) is wrong (see documentation)\n",
                       this->_iPts);
                throw runtime_error("CubatureGauss: CheckSettings failed!!");
            }
        }

        // Quadrilateral quadrature rule
        if (_elemType == ElemType::Square)
        {
            if (this->_iPts == 1){}
            else if (this->_iPts ==   4){}
            else if (this->_iPts ==   9){}
            else if (this->_iPts ==  16){}
            else if (this->_iPts ==  25){}
            else if (this->_iPts ==  36){}
            else if (this->_iPts ==  49){}
            else if (this->_iPts ==  64){}
            else if (this->_iPts ==  81){}
            else if (this->_iPts == 100){}
            else if (this->_iPts == 225){}
            else
            {
                printf("ERROR: the number of Gauss points (%d) is wrong (see documentation)\n",
                       this->_iPts);
                throw runtime_error("CubatureGauss: CheckSettings failed!!");
            }
        }

        if (_elemType == ElemType::Tetrah) //Tetrahedra
        {
            if (this->_iPts == 1){}
            else if (this->_iPts ==  4){}
            else if (this->_iPts ==  5){}
            else if (this->_iPts == 11){}
            else if (this->_iPts == 15){}
            else if (this->_iPts == 64){}
            else
            {
                printf("ERROR: the number of Gauss points (%d) is wrong (see documentation)\n",
                       this->_iPts);
                throw runtime_error("CubatureGauss: CheckSettings failed!!");
            }

        }


        // Parallelepipedal quadrature rule
        // NOTE: the quadrature order is not verified in this case, a full check will be necessary
        if (_elemType == ElemType::Parallelep)
        {
            if (this->_iPts == 1) {}
            else if (this->_iPts ==    8){}
            else if (this->_iPts ==   27){}
            else if (this->_iPts ==   64){}
            else if (this->_iPts ==  125){}
            else if (this->_iPts ==  216){}
            else if (this->_iPts ==  343){}
            else if (this->_iPts ==  512){}
            else if (this->_iPts ==  729){}
            else if (this->_iPts == 1000){}
            else if (this->_iPts == 3375){}
            else
            {
                printf("ERROR: the number of Gauss points (%d) is wrong (see documentation)\n",
                       this->_iPts);
                throw runtime_error("CubatureGauss: CheckSettings failed!!");
            }
        }


    }

    // Weights and canonical variables for integration on line
    void CubatureGauss::_lineRule()
    {
        int np;
        np = (int) (this->_iPts);

        double *pt = new double[np];
        double *gw = new double[np];

        if (this->_iPts == 1)
        {
            pt[0] = 0.0;
            gw[0] = 2.0;
        }
        else if (this->_iPts == 2)
        {
            pt[0] =-1.0/sqrt(3.0);
            pt[1] = 1.0/sqrt(3.0);
            gw[0] = 1.0;
            gw[1] = 1.0;
        }
        else if (this->_iPts == 3)
        {
            pt[0] =-sqrt(3.0/5.0);
            pt[1] = 0.0;
            pt[2] = sqrt(3.0/5.0);

            gw[0] = 5.0/9.0;
            gw[1] = 8.0/9.0;
            gw[2] = 5.0/9.0;
        }
        else if (this->_iPts == 4)
        {
            pt[0] =-sqrt((3.0 + 2.0*sqrt(6.0/5.0))/7.0);
            pt[1] =-sqrt((3.0 - 2.0*sqrt(6.0/5.0))/7.0);
            pt[2] = sqrt((3.0 - 2.0*sqrt(6.0/5.0))/7.0);
            pt[3] = sqrt((3.0 + 2.0*sqrt(6.0/5.0))/7.0);

            gw[0] = 1.0/2.0 - sqrt(5.0/6.0)/6.0;
            gw[1] = 1.0/2.0 + sqrt(5.0/6.0)/6.0;
            gw[2] = 1.0/2.0 + sqrt(5.0/6.0)/6.0;
            gw[3] = 1.0/2.0 - sqrt(5.0/6.0)/6.0;
        }
        else if (this->_iPts == 5)
        {
            pt[0] =-sqrt(5.0 + 2.0*sqrt(10.0/7.0))/3.0;
            pt[1] =-sqrt(5.0 - 2.0*sqrt(10.0/7.0))/3.0;
            pt[2] = 0.0;
            pt[3] = sqrt(5.0 - 2.0*sqrt(10.0/7.0))/3.0;
            pt[4] = sqrt(5.0 + 2.0*sqrt(10.0/7.0))/3.0;

            gw[0] = (322.0 - 13.0*sqrt(70.0))/900.0;
            gw[1] = (322.0 + 13.0*sqrt(70.0))/900.0;
            gw[2] = 128.0 / 225.0;
            gw[3] = (322.0 + 13.0*sqrt(70.0))/900.0;
            gw[4] = (322.0 - 13.0*sqrt(70.0))/900.0;
        }
        else if (this->_iPts == 6)
        {
            pt[0] = -0.9324695142031520;
            pt[1] = -0.6612093864662645;
            pt[2] = -0.2386191860831969;
            pt[3] = 0.2386191860831969;
            pt[4] = 0.6612093864662645;
            pt[5] = 0.9324695142031520;

            gw[0] = 0.1713244923791703;
            gw[1] = 0.3607615730481386;
            gw[2] = 0.4679139345726911;
            gw[3] = 0.4679139345726911;
            gw[4] = 0.3607615730481386;
            gw[5] = 0.1713244923791703;
        }
        else if (this->_iPts == 7)
        {
            pt[0] = -0.9491079123427585;
            pt[1] = -0.7415311855993944;
            pt[2] = -0.4058451513773972;
            pt[3] = 0e0;
            pt[4] = 0.4058451513773972;
            pt[5] = 0.7415311855993944;
            pt[6] = 0.9491079123427585;

            gw[0] = 0.1294849661688697;
            gw[1] = 0.2797053914892767;
            gw[2] = 0.3818300505051189;
            gw[3] = 0.4179591836734694;
            gw[4] = 0.3818300505051189;
            gw[5] = 0.2797053914892767;
            gw[6] = 0.1294849661688697;
        }
        else if (this->_iPts == 8)
        {
            pt[0] = -0.9602898564975362;
            pt[1] = -0.7966664774136267;
            pt[2] = -0.5255324099163290;
            pt[3] = -0.1834346424956498;
            pt[4] = 0.1834346424956498;
            pt[5] = 0.5255324099163290;
            pt[6] = 0.7966664774136267;
            pt[7] = 0.9602898564975362;

            gw[0] = 0.1012285362903763;
            gw[1] = 0.2223810344533745;
            gw[2] = 0.3137066458778873;
            gw[3] = 0.3626837833783620;
            gw[4] = 0.3626837833783620;
            gw[5] = 0.3137066458778873;
            gw[6] = 0.2223810344533745;
            gw[7] = 0.1012285362903763;
        }
        else if (this->_iPts == 9)
        {
            pt[0] = -0.9681602395076261;
            pt[1] = -0.8360311073266358;
            pt[2] = -0.6133714327005904;
            pt[3] = -0.3242534234038089;
            pt[4] = 0e0;
            pt[5] = 0.3242534234038089;
            pt[6] = 0.6133714327005904;
            pt[7] = 0.8360311073266358;
            pt[8] = 0.9681602395076261;

            gw[0] = 0.0812743883615744;
            gw[1] = 0.1806481606948574;
            gw[2] = 0.2606106964029354;
            gw[3] = 0.3123470770400029;
            gw[4] = 0.3302393550012598;
            gw[5] = 0.3123470770400028;
            gw[6] = 0.2606106964029355;
            gw[7] = 0.1806481606948574;
            gw[8] = 0.0812743883615744;
        }
        else if (this->_iPts == 10)
        {
            pt[0] = -0.9739065285171717;
            pt[1] = -0.8650633666889845;
            pt[2] = -0.6794095682990244;
            pt[3] = -0.4333953941292471;
            pt[4] = -0.1488743389816312;
            pt[5] = 0.1488743389816312;
            pt[6] = 0.4333953941292471;
            pt[7] = 0.6794095682990244;
            pt[8] = 0.8650633666889845;
            pt[9] = 0.9739065285171717;

            gw[0] = 0.0666713443086881;
            gw[1] = 0.1494513491505805;
            gw[2] = 0.2190863625159820;
            gw[3] = 0.2692667193099963;
            gw[4] = 0.2955242247147528;
            gw[5] = 0.2955242247147528;
            gw[6] = 0.2692667193099963;
            gw[7] = 0.2190863625159820;
            gw[8] = 0.1494513491505805;
            gw[9] = 0.0666713443086881;
        }
        else if (this->_iPts == 15)
        {
            pt[0] = -0.9879925180204854;
            pt[1] = -0.9372733924007059;
            pt[2] = -0.8482065834104272;
            pt[3] = -0.7244177313601700;
            pt[4] = -0.5709721726085388;
            pt[5] = -0.3941513470775634;
            pt[6] = -0.2011940939974345;
            pt[7] = 0e0;
            pt[8] = 0.2011940939974345;
            pt[9] = 0.3941513470775634;
            pt[10] = 0.5709721726085388;
            pt[11] = 0.7244177313601700;
            pt[12] = 0.8482065834104272;
            pt[13] = 0.9372733924007059;
            pt[14] = 0.9879925180204854;

            gw[0] = 0.03075324199611807;
            gw[1] = 0.07036604748811134;
            gw[2] = 0.1071592204671351;
            gw[3] = 0.1395706779261761;
            gw[4] = 0.1662692058169852;
            gw[5] = 0.1861610000155741;
            gw[6] = 0.1984314853271374;
            gw[7] = 0.2025782419255562;
            gw[8] = 0.1984314853271374;
            gw[9] = 0.1861610000155741;
            gw[10] = 0.1662692058169852;
            gw[11] = 0.1395706779261761;
            gw[12] = 0.1071592204671351;
            gw[13] = 0.07036604748811134;
            gw[14] = 0.03075324199611807;
        }

        for (int i = 0; i< np; i++)
        {
            this->_xSamples[i] = pt[i];
            this->_wSamples[i] = gw[i];
        }

        delete [] pt;
        delete [] gw;

        return;
    }

    //  Purpose:    LEGENDRE_COMPUTE computes a Gauss-Legendre quadrature rule.
    //  Discussion: The integration interval is [ -1, 1 ].
    //              The weight function is w(x) = 1.0.
    //              The integral to approximate:
    //                   Integral ( -1 <= X <= 1 ) F(X) dX
    //              The quadrature rule:
    //                  Sum ( 1 <= I <= ORDER ) WEIGHT(I) * F ( XTAB(I) )
    //  Licensing:
    //    This code is distributed under the GNU LGPL license.
    //    Original FORTRAN77 version by Philip Davis, Philip Rabinowitz
    //    Original C++ version by John Burkardt
    //
    //  Reference:
    //    Philip Davis, Philip Rabinowitz, Methods of Numerical Integration, Second Edition,
    //    Dover, 2007, ISBN: 0486453391, LC: QA299.3.D28.
    //
    //  Parameters:
    //    Input:
    //       int ORDER, the order of the rule.
    //    ORDER must be greater than 0.
    //    Output, double XTAB[ORDER], the abscissas of the rule.
    //    Output, double WEIGHT[ORDER], the weights of the rule.
    //    The weights are positive, symmetric, and should sum to 2.
    void CubatureGauss::_quadratureRule ()
    {
        int i, k, m, iback;
        int    mp1mi, ncopy, nmove, order2;
        double d1, d2pn, d3pn, d4pn;
        double dp, dpn;
        double e1, fx, h;
        double p, pk;
        double pkm1, pkp1;
        double t, u, v;
        double x0, xtemp, iorder;

        e1 = ( double ) ( this->_iPts * ( this->_iPts + 1 ) );
        m  = ( this->_iPts + 1 ) / 2;

        order2 = this->_iPts*this->_iPts;
        iorder = 1.0/((double)this->_iPts);


        for ( i = 1; i <= m; i++ )
        {
            mp1mi = m + 1 - i;
            t     = (double) ( 4 * i - 1 ) * M_PI/((double) (4 * this->_iPts + 2));
            x0    = cos(t) * ( 1.0 - (1.0 - iorder)/( (double)(8*order2) ));
            pkm1  = 1.0;
            pk    = x0;

            for ( k = 2; k <= this->_iPts; k++ )
            {
                pkp1 = 2.0*x0*pk - pkm1 - ( x0*pk - pkm1 )/( (double) k );
                pkm1 = pk;
                pk = pkp1;
            }

            d1 = ( double ) ( this->_iPts ) * ( pkm1 - x0 * pk );

            dpn  = d1 / ( 1.0-x0*x0 );
            d2pn = ( 2.0*x0*dpn  - e1 * pk ) / (1.0 - x0*x0);
            d3pn = ( 4.0*x0*d2pn + ( 2.0 - e1 ) * dpn )  / (1.0 - x0*x0);
            d4pn = ( 6.0*x0*d3pn + ( 6.0 - e1 ) * d2pn ) / (1.0 - x0*x0);

            u = pk / dpn;
            v = d2pn / dpn;
            //
            //  Initial approximation H:
            //
            h = -u * ( 1.0 + 0.5*u * ( v + u * ( v*v - d3pn/( 3.0 * dpn ) ) ) );
            //
            //  Refine H using one step of Newton's method:
            //
            p  =  pk + h * ( dpn + 0.5*h * ( d2pn + (h/3.0) * ( d3pn + 0.25*h*d4pn ) ) );
            dp = dpn + h * ( d2pn + 0.5*h * ( d3pn + h*d4pn/3.0 ) );
            h  = h - p / dp;

            xtemp = x0 + h;
            fx    = d1 - h * e1 * ( pk + 0.5 * h * ( dpn + h / 3.0
                    * ( d2pn + 0.25 * h * ( d3pn + 0.2 * h * d4pn ) ) ) );

            this->_xSamples[mp1mi-1] = xtemp;
            this->_wSamples[mp1mi-1] = 2.0 * ( 1.0 - xtemp * xtemp ) / ( fx * fx );
        }

        if ( ( this->_iPts % 2 ) == 1 )
        {
            this->_xSamples[0] = 0.0;
        }

        //  Shift the data up.
        //
        nmove = ( this->_iPts + 1 ) / 2;
        ncopy = this->_iPts - nmove;

        for ( i = 1; i <= nmove; i++ )
        {
            iback = this->_iPts + 1 - i;
            this->_xSamples[iback-1] = this->_xSamples[iback-ncopy-1];
            this->_wSamples[iback-1] = this->_wSamples[iback-ncopy-1];
        }

        //  Reflect values for the negative abscissas.
        //
        for ( i = 0; i < (this->_iPts - nmove); i++ )
        {
            this->_xSamples[i] = -(this->_xSamples[this->_iPts-i-1]);
            this->_wSamples[i] =  this->_wSamples[this->_iPts-i-1];
        }

        for (i = 0; i < this->_iPts; i++ )
        {
            this->_xSamples[i] *= 0.5;
            this->_xSamples[i] += 0.5;
            this->_wSamples[i] *= 0.5;
        }
        return;
    }

    // The Gauss weights and the coordinates for the quadrature points in the reference
    // element are computed.
    //
    // The sum of the weights is equal to 1.
    //
    // Reference:
    //      D.A. Dunavant. "High degree efficient symmetrical Gaussian quadrature rules for the
    //      triangle". International Journal of Numerical Methods in Engineering, Volume 21,
    //      pp. 1129-1148, 1985.
    void CubatureGauss::_triangularRule()
    {
        int    i;
        double a, b, c, d, e, f;
        double P1, P2, P3, P4, P5;
        double F [] = { 2.0/3.0,     0.0, -1.0/3.0, 1.0/sqrt(3.0) };
        double u [] = { 1.0/3.0, 1.0/3.0 };
        double x [2];


        switch(this->_iPts)
        {
            case 1:     //order: 1
                this->_xSamples[0] = 1.0/3.0;      this->_xSamples[1] = 1.0/3.0;
                this->_wSamples[0] = 1.0;
                break;

            case 3:     //order: 2
                this->_xSamples[0] = 2.0/3.0;      this->_xSamples[1] = 1.0/6.0;
                this->_xSamples[2] = 1.0/6.0;      this->_xSamples[3] = 2.0/3.0;
                this->_xSamples[4] = 1.0/6.0;      this->_xSamples[5] = 1.0/6.0;

                this->_wSamples[0] = 1.0/3.0;
                this->_wSamples[1] = 1.0/3.0;
                this->_wSamples[2] = 1.0/3.0;

                break;

            // FIXME:: Cubature deactivated (negative weights not working)
            // case 4:     //order: 3
            //     this->_xSamples[0] = 1.0/3.0;  this->_xSamples[1] = 1.0/3.0;
            //     this->_xSamples[2] = 0.6;      this->_xSamples[3] = 0.2;
            //     this->_xSamples[4] = 0.2;      this->_xSamples[5] = 0.6;
            //     this->_xSamples[6] = 0.2;      this->_xSamples[7] = 0.2;

            //     this->_wSamples[0] = -27.0/48.0;
            //     this->_wSamples[1] =  25.0/48.0;
            //     this->_wSamples[2] =  25.0/48.0;
            //     this->_wSamples[3] =  25.0/48.0;

            //     break;

            case 6:     //order: 4
                a = 0.816847572980459;
                b = 0.091576213509771;
                this->_xSamples[0] = a;         this->_xSamples[1] = b;
                this->_xSamples[2] = b;         this->_xSamples[3] = a;
                this->_xSamples[4] = b;         this->_xSamples[5] = b;

                a = 0.108103018168070;
                b = 0.445948490915965;
                this->_xSamples[ 6] = a;        this->_xSamples[ 7] = b;
                this->_xSamples[ 8] = b;        this->_xSamples[ 9] = a;
                this->_xSamples[10] = b;        this->_xSamples[11] = b;

                P1 = 0.109951743655322;
                P2 = 0.223381589678011;
                for (int i=0; i< 3; i++) this->_wSamples[i] = P1;
                for (int i=3; i< 6; i++) this->_wSamples[i] = P2;
                break;

            case 7:     //order: 5
                a = 0.797426985353087;
                b = 0.101286507323456;
                this->_xSamples[ 0] = a;           this->_xSamples[ 1] = b;
                this->_xSamples[ 2] = b;           this->_xSamples[ 3] = a;
                this->_xSamples[ 4] = b;           this->_xSamples[ 5] = b;

                a = 0.059715871789770;
                b = 0.470142064105115;
                this->_xSamples[ 6] = a;           this->_xSamples[ 7] = b;
                this->_xSamples[ 8] = b;           this->_xSamples[ 9] = a;
                this->_xSamples[10] = b;           this->_xSamples[11] = b;

                this->_xSamples[12] = 1.0/3.0; this->_xSamples[13] = 1.0/3.0;

                P1 = 0.125939180544827;
                P2 = 0.132394152788506;
                for (int i=0; i< 3; i++) this->_wSamples[i] = P1;
                for (int i=3; i< 6; i++) this->_wSamples[i] = P2;
                this->_wSamples[6] = 0.225;

                break;

            case 12:        //order: 6
                a = 0.873821971016996;
                b = 0.063089014491502;
                this->_xSamples[ 0] = a;           this->_xSamples[ 1] = b;
                this->_xSamples[ 2] = b;           this->_xSamples[ 3] = a;
                this->_xSamples[ 4] = b;           this->_xSamples[ 5] = b;

                a = 0.501426509658179;
                b = 0.249286745170910;
                this->_xSamples[ 6] = a;           this->_xSamples[ 7] = b;
                this->_xSamples[ 8] = b;           this->_xSamples[ 9] = a;
                this->_xSamples[10] = b;           this->_xSamples[11] = b;

                a = 0.636502499121399;
                b = 0.310352451033785;
                c = 0.053145049844816;
                this->_xSamples[12] = a;           this->_xSamples[13] = b;
                this->_xSamples[14] = b;           this->_xSamples[15] = a;
                this->_xSamples[16] = b;           this->_xSamples[17] = c;
                this->_xSamples[18] = a;           this->_xSamples[19] = c;
                this->_xSamples[20] = c;           this->_xSamples[21] = a;
                this->_xSamples[22] = c;           this->_xSamples[23] = b;

                P1 = 0.050844906370207;
                P2 = 0.116786275726379;
                P3 = 0.082851075618374;
                for (int i=0; i< 3; i++) this->_wSamples[i] = P1;
                for (int i=3; i< 6; i++) this->_wSamples[i] = P2;
                for (int i=6; i<12; i++) this->_wSamples[i] = P3;

                break;

            // FIXME:: Cubature deactivated (negative weights not working)
            // case 13:        //order: 7
            //     a = 0.479308067841923;
            //     b = 0.260345966079038;
            //     this->_xSamples[ 0] = a;           this->_xSamples[ 1] = b;
            //     this->_xSamples[ 2] = b;           this->_xSamples[ 3] = a;
            //     this->_xSamples[ 4] = b;           this->_xSamples[ 5] = b;

            //     a = 0.869739794195568;
            //     b = 0.065130102902216;
            //     this->_xSamples[ 6] = a;           this->_xSamples[ 7] = b;
            //     this->_xSamples[ 8] = b;           this->_xSamples[ 9] = a;
            //     this->_xSamples[10] = b;           this->_xSamples[11] = b;

            //     a = 0.638444188569809;
            //     b = 0.312865496004875;
            //     c = 0.048690315425316;
            //     this->_xSamples[12] = a;           this->_xSamples[13] = b;
            //     this->_xSamples[14] = b;           this->_xSamples[15] = a;
            //     this->_xSamples[16] = b;           this->_xSamples[17] = c;
            //     this->_xSamples[18] = a;           this->_xSamples[19] = c;
            //     this->_xSamples[20] = c;           this->_xSamples[21] = a;
            //     this->_xSamples[22] = c;           this->_xSamples[23] = b;

            //     this->_xSamples[24] = 1.0/3.0; this->_xSamples[25] = 1.0/3.0;

            //     P1 = 0.175615257433204;
            //     P2 = 0.053347235608839;
            //     P3 = 0.077113760890257;
            //     for (int i=0; i< 3; i++) this->_wSamples[i] = P1;
            //     for (int i=3; i< 6; i++) this->_wSamples[i] = P2;
            //     for (int i=6; i<12; i++) this->_wSamples[i] = P3;
            //     this->_wSamples[12] = -0.149570044467670;
            //     break;

            case 16:        //order: 8
                a = 0.17056930775176021;
                b = 0.05054722831703098;
                c = 0.45929258829272316;
                d = 0.72849239295540428;
                e = 0.26311282963463811;
                f = 1.0/3.0;
                this->_xSamples[ 0] = a;               this->_xSamples[ 1] = a;
                this->_xSamples[ 2] = a;               this->_xSamples[ 3] = 1.0-2.0*a;
                this->_xSamples[ 4] = 1.0-2.0*a;       this->_xSamples[ 5] = a;
                this->_xSamples[ 6] = b;               this->_xSamples[ 7] = b;
                this->_xSamples[ 8] = b;               this->_xSamples[ 9] = 1.0-2.0*b;
                this->_xSamples[10] = 1.0-2.0*b;       this->_xSamples[11] = b;
                this->_xSamples[12] = c;               this->_xSamples[13] = c;
                this->_xSamples[14] = c;               this->_xSamples[15] = 1.0-2.0*c;
                this->_xSamples[16] = 1.0-2.0*c;       this->_xSamples[17] = c;
                this->_xSamples[18] = d;               this->_xSamples[19] = e;
                this->_xSamples[20] = d;               this->_xSamples[21] = 1.0-d-e;
                this->_xSamples[22] = 1.0-d-e;         this->_xSamples[23] = d;
                this->_xSamples[24] = 1.0-d-e;         this->_xSamples[25] = e;
                this->_xSamples[26] = e;               this->_xSamples[27] = 1.0-d-e;
                this->_xSamples[28] = e;               this->_xSamples[29] = d;
                this->_xSamples[30] = f;               this->_xSamples[31] = f;

                P1 = 0.10321737053471824;
                P2 = 0.03245849762319808;
                P3 = 0.09509163426728462;
                P4 = 0.02723031417443499;
                P5 = 0.14431560767778717;
                for (int i=0; i< 3; i++) this->_wSamples[i] = P1;
                for (int i=3; i< 6; i++) this->_wSamples[i] = P2;
                for (int i=6; i< 9; i++) this->_wSamples[i] = P3;
                for (int i=9; i<15; i++) this->_wSamples[i] = P4;
                this->_wSamples[15] = P5;

                break;
            case 25:    //order: 10
            case 54:    //order: 15
            case 85:    //order: 20
            case 126:   //order: 25
            case 175:   //order: 30
                this->_symmetricRule();

                for ( int i=0; i<this->_iPts; i++ )
                {
                    x[0] = this->_xSamples[2*i+0]*F[0] + this->_xSamples[2*i+1]*F[1];
                    x[1] = this->_xSamples[2*i+0]*F[2] + this->_xSamples[2*i+1]*F[3];

                    this->_xSamples[2*i+0] = x[0] + u[0];
                    this->_xSamples[2*i+1] = x[1] + u[1];
                }
                break;
        }

        //due to the fact that the weight sum up to one we half them to mach the area of
        //a isoparametric triangle of side 1: vertices [(0,0),(1,0),(0,1)]
        for ( i=0; i<this->_iPts; i++ )
            this->_wSamples[i] *= 0.5;
        return;
    }

    // This function defines a symmetric quadrature rule on a equilateral triangle.
    // The quadrature is computed as a function of the integration order desired,
    // the posibles values are: 5, 10, 15, 20, 25, 30
    //
    // Reference:
    //      S. Wandzura and H. Xiao. "Symmetric quadrature rules on a triangle".
    //      Computers and Mathematics with Applications, Volume 45, Number 12,
    //      pp. 1829-1840, June 2003.
    void CubatureGauss::_symmetricRule()
    {
        // Equilateral Triangle coordinates in which the quadrature is defined
        // t1 = ( 1.0,  0.0 )
        // t2 = (-0.5,  0.5*sqrt(3.0) )
        // t3 = (-0.5, -0.5*sqrt(3.0) )

        // Group D3:
        // The symmetry group of an equilateral triangle-the group of all orthogonal linear
        // transformations of the plane under which the equilateral triangle is invariant
        // is a reflection group often referred to as D3. D3 has six elements
        // D3={A, B, C, D, E, E, F}, and has a two-dimensional matrix representation shown below.
        // Clearly, seen as orthogonal transformations of the plane, matrices A, B, and C correspond
        // to rotations by Pi about the corresponding three medians of the equilateral triangle,
        // and matrices D and F correspond to clockwise rotations about the center by 2Pi/3 and 4Pi/3,
        // respectively.
        double fi1 = 2.0*M_PI/3.0;
        double fi2 = 4.0*M_PI/3.0;
        double A []= { cos(fi1),  sin(fi1), -sin(fi1),  cos(fi1) };
        double B []= { cos(fi2),  sin(fi2), -sin(fi2),  cos(fi2) };
        double C []= {      1.0,       0.0,       0.0,       1.0 };
        double D []= { cos(fi1), -sin(fi1), -sin(fi1), -cos(fi1) };
        double E []= {      1.0,       0.0,       0.0,      -1.0 };
        double F []= { cos(fi2), -sin(fi2), -sin(fi2), -cos(fi2) };

        int m, *M;
        double *X, *Y, *w;

        if (this->_iPts == 7)        //order: 5
        {
            m = 3;
            M = new    int[m];
            X = new double[m];
            Y = new double[m];
            w = new double[m];

            int    Mt [] = { 1, 3, 3 };
            double Xt [] = { 0.0,  -0.4104261923153453, 0.6961404780296310 };
            double Yt [] = { 0.0, 0.0, 0.0 };
            double wt [] = { 0.225, 0.1323941527885062, 0.1259391805448271 };

            for ( int i=0; i < m; i++ )
            {
                M[i] = Mt[i];
                X[i] = Xt[i];
                Y[i] = Yt[i];
                w[i] = wt[i];
            }
        }
        else if ( this->_iPts ==  25 )       //order: 10
        {
            m = 7;
            M = new    int[m];
            X = new double[m];
            Y = new double[m];
            w = new double[m];

            int    Mt [] = { 1, 3, 3, 3, 3, 6, 6 };
            double Xt [] = { 0.0,
                             -0.4935962988634245,  -0.2840373491871686,   0.44573076177032633,
                             0.9385563442849673,  -0.4474955151540920,  -0.4436763946123360 };
            double Yt [] = { 0.0, 0.0, 0.0, 0.0, 0.0, -0.5991595522781586, -0.2571781329392130 };
            double wt [] = { 0.08352339980519638,  0.007229850592056743, 0.07449217792098051,
                             0.07864647340310853,  0.006928323087107504, 0.0295183203347794,
                             0.03957936719606124 };

            for ( int i=0; i < m; i++ )
            {
                M[i] = Mt[i];

                X[i] = Xt[i];
                Y[i] = Yt[i];
                w[i] = wt[i];
            }
        }
        else if ( this->_iPts ==  54 )       //order: 15
        {
            m = 12;
            M = new    int[m];
            X = new double[m];
            Y = new double[m];
            w = new double[m];

            int    Mt [] = { 3, 3, 3, 3, 3, 3, 6, 6, 6, 6, 6, 6 };
            double Xt [] = {-0.3748423891073751,  -0.2108313937373917,   0.1204084962609239,
                            0.5605966391716812,   0.8309113970031897,   0.9502746194248890,
                            -0.4851316950361628,  -0.4762943440546580,  -0.4922845867745440,
                            -0.4266165113705168,  -0.3968468770512212,  -0.2473933728129512 };
            double Yt [] = { 0.0,  0.0,  0.0,  0.0,  0.0,  0.0,
                             -0.4425551659467111,  -0.1510682717598242,  -0.6970224211436132,
                             -0.5642774363966393,  -0.3095105740458471,  -0.2320292030461791 };
            double wt [] = { 0.03266181884880529,  0.02741281803136436,  0.02651003659870330,
                             0.02921596213648611,  0.01058460806624399,  0.003614643064092035,
                             0.008527748101709436, 0.01391617651669193,  0.004291932940734835,
                             0.01623532928177489,  0.02560734092126239,  0.03308819553164567 };
            for ( int i=0; i < m; i++ )
            {
                M[i] = Mt[i];
                X[i] = Xt[i];
                Y[i] = Yt[i];
                w[i] = wt[i];
            }
        }
        else if ( this->_iPts ==  85 )       //order: 20
        {
            m = 19;
            M = new    int[m];
            X = new double[m];
            Y = new double[m];
            w = new double[m];

            int    Mt [] = {1, 3, 3, 3, 3, 3, 3, 3, 3, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 };
            double Xt [] = { 0.0,
                             -0.4977490260133565,  -0.3587903720915737,  -0.1932918138657104,
                             0.2064993924016380,   0.3669431077237697,   0.6767931784861860,
                             0.8827927364865920,   0.9664768608120111,  -0.4919755727189941,
                             -0.4880677744007016,  -0.4843664025781043,  -0.4835533778058150,
                             -0.4421499318718065,  -0.4466292382741727,  -0.4254937754558538,
                             -0.4122204123735024,  -0.3177533194934086,  -0.2889337325840919 };
            double Yt [] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                             -0.7513212483763635,  -0.5870191642967427,  -0.1717270984114328,
                             -0.3833898305784408,  -0.6563281974461070,  -0.06157647932662624,
                             -0.4783124082660027,  -0.2537089901614676,  -0.3996183176834929,
                             -0.1844183967233982 };
            double wt [] = { 0.02761042699769952,  0.00177902954732674,  0.02011239811396117,
                             0.02681784725933157,  0.02452313380150201,  0.01639457841069539,
                             0.01479590739864960,  0.004579282277704251, 0.001651826515576217,
                             0.002349170908575584, 0.004465925754181793, 0.006099566807907972,
                             0.006891081327188203, 0.007997475072478163, 0.007386134285336024,
                             0.01279933187864826,  0.01725807117569655,  0.01867294590293547,
                             0.02281822405839526 };
            for ( int i=0; i < m; i++ )
            {
                M[i] = Mt[i];
                X[i] = Xt[i];
                Y[i] = Yt[i];
                w[i] = wt[i];
            }
        }
        else if ( this->_iPts == 126 )       //order: 25
        {
            m = 26;
            M = new    int[m];
            X = new double[m];
            Y = new double[m];
            w = new double[m];

            int    Mt [] = { 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                             6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 };
            double Xt [] = {-0.4580802753902387,   -0.3032320980085228,   -0.1696674057318916,
                            0.1046702979405866,    0.2978674829878846,    0.5455949961729473,
                            0.6617983193620190,    0.7668529237254211,    0.8953207191571090,
                            0.9782254461372029,   -0.4980614709433367,   -0.4919004480918257,
                            -0.4904239954490375,   -0.4924576827470104,   -0.4897598620673272,
                            -0.4849757005401057,   -0.4613632802399150,   -0.4546581528201263,
                            -0.4542425148392569,   -0.4310651789561460,   -0.3988357991895837,
                            -0.3949323628761341,   -0.3741327130398251,   -0.3194366964842710,
                            -0.2778996512639500,   -0.2123422011990124 };
            double Yt [] = { 0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0,
                             -0.4713592181681879,   -0.1078887424748246,   -0.3057041948876942,
                             -0.7027546250883238,   -0.7942765584469995,   -0.5846826436376921,
                             -0.4282174042835178,   -0.2129434060653430,   -0.6948910659636692,
                             -0.5691146659505208,   -0.3161666335733065,   -0.1005941839340892,
                             -0.4571406037889341,   -0.2003599744104858,   -0.3406754571040736,
                             -0.1359589640107579 };
            double wt [] = { 0.008005581880020417,  0.01594707683239050,   0.01310914123079553,
                             0.019583000965635623,  0.01647088544153727,   0.008547279074092100,
                             0.008161885857226492,  0.006121146539983779,  0.002908498264936665,
                             0.0006922752456619963, 0.001248289199277397,  0.003404752908803022,
                             0.003359654326064051,  0.001716156539496754,  0.001480856316715606,
                             0.003511312610728685,  0.007393550149706484,  0.007983087477376558,
                             0.004355962613158041,  0.007365056701417832,  0.01096357284641955,
                             0.01174996174354112,   0.01001560071379857,   0.01330964078762868,
                             0.01415444650522614,   0.01488137956116801 };
            for ( int i=0; i < m; i++ )
            {
                M[i] = Mt[i];
                X[i] = Xt[i];
                Y[i] = Yt[i];
                w[i] = wt[i];
            }
        }
        else if (this->_iPts == 175)     //order: 30
        {
            m = 36;
            M = new    int[m];
            X = new double[m];
            Y = new double[m];
            w = new double[m];

            int    Mt [] = { 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                             3, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
                             6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6 };
            double Xt [] = { 0.0000000000000000,   -0.4890048253508517,   -0.3755064862955532,
                             -0.2735285658118844,   -0.1461412101617502,    0.1570364626117722,
                             0.3179530724378968,    0.4763226654738105,    0.6302247183956902,
                             0.7597473133234094,    0.8566765977763036,    0.9348384559595755,
                             0.9857059671536891,   -0.4986119432099803,   -0.4979211112166541,
                             -0.4944763768161339,   -0.4941451648637610,   -0.4951501277674842,
                             -0.4902988518316453,   -0.4951287867630010,   -0.4869873637898693,
                             -0.4766044602990292,   -0.4730349181194722,   -0.4743136319691660,
                             -0.4656748919801272,   -0.4508936040683500,   -0.4492684814864886,
                             -0.4466785783099771,   -0.4241903145397002,   -0.4144779276264017,
                             -0.4037707903681949,   -0.3792482775685616,   -0.3434493977982042,
                             -0.3292326583568731,   -0.2819547684267144,   -0.2150815207670319 };
            double Yt [] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                             -0.1459114994581331,   -0.7588411241269780,   -0.5772061085255766,
                             -0.8192831133859931,   -0.3331061247123685,   -0.6749680757240147,
                             -0.4649148484601980,   -0.2747479818680760,   -0.7550787344330482,
                             -0.1533908770581512,   -0.4291730489015232,   -0.5597446281020688,
                             -0.6656779209607333,   -0.3024354020045064,   -0.03733933337926417,
                             -0.4432574453491491,   -0.1598390022600824,   -0.5628520409756346,
                             -0.3048723680294163,   -0.4348816278906578,   -0.1510147586773290,
                             -0.2901177668548256,   -0.1439403370753732 };
            double wt [] = { 0.01557996020289920,   0.003177233700534134,  0.01048342663573077,
                             0.01320945957774363,   0.01497500696627150,   0.01498790444338419,
                             0.01333886474102166,   0.01088917111390201,   0.008189440660893461,
                             0.005575387588607785,  0.003191216473411976,  0.001296715144327045,
                             0.0002982628261349172, 0.0009989056850788964, 0.0004628508491732533,
                             0.001234451336382413,  0.0005707198522432062, 0.001126946125877624,
                             0.001747866949407337,  0.001182818815031657,  0.001990839294675034,
                             0.001900412795035980,  0.004498365808817451,  0.003478719460274719,
                             0.004102399036723953,  0.004021761549744162,  0.006033164660795066,
                             0.003946290302129598,  0.006644044537680268,  0.008254305856078458,
                             0.006496056633406411,  0.009252778144146602,  0.009164920726294280,
                             0.01156952462809767,   0.01176111646760917,   0.01382470218216540 };
            for ( int i=0; i < m; i++ )
            {
                M[i] = Mt[i];
                X[i] = Xt[i];
                Y[i] = Yt[i];
                w[i] = wt[i];
            }
        }
        else
        {
            printf( "ERROR::The number of Gauss points %d is not allowed\n",
                    this->_iPts );
            exit(1);
        }

        // The multiplicity points are computed > 1 ( by using the D3 transformations)
        int kp, kw;
        kp = 0;
        kw = 0;

        for (int i=0; i<m; i++)
        {
            // Se calculan los puntos de integracion a partir de los valores tabulados
            this->_xSamples[2*kp+0] = C[0]*X[i] + C[1]*Y[i];
            this->_xSamples[2*kp+1] = C[2]*X[i] + C[3]*Y[i];
            kp++;

            // Orbita de multiplicidad 3
            if ( M[i] > 1 )
            {
                this->_xSamples[2*kp+0] = A[0]*X[i] + A[1]*Y[i];
                this->_xSamples[2*kp+1] = A[2]*X[i] + A[3]*Y[i];
                kp++;

                this->_xSamples[2*kp+0] = B[0]*X[i] + B[1]*Y[i];
                this->_xSamples[2*kp+1] = B[2]*X[i] + B[3]*Y[i];
                kp++;
            }

            //  Orbita de multiplicidad 6
            if ( M[i] > 3 )
            {
                this->_xSamples[2*kp+0] = D[0]*X[i] + D[1]*Y[i];
                this->_xSamples[2*kp+1] = D[2]*X[i] + D[3]*Y[i];
                kp++;

                this->_xSamples[2*kp+0] = E[0]*X[i] + E[1]*Y[i];
                this->_xSamples[2*kp+1] = E[2]*X[i] + E[3]*Y[i];
                kp++;

                this->_xSamples[2*kp+0] = F[0]*X[i] + F[1]*Y[i];
                this->_xSamples[2*kp+1] = F[2]*X[i] + F[3]*Y[i];
                kp++;
            }
            // Se modifican los pesos (sobre XeTri)
            for (int j=0; j<M[i]; j++)
            {
                this->_wSamples[kw] = w[i];
                kw++;
            }
        }
        delete [] M;
        delete [] X;
        delete [] Y;
        delete [] w;
        return;
    }

    // Weights and canonical variables for integration on tetrahedra
    //
    // References:
    //      Y. Jinyun. "Symmetric Gaussian quadrature formulae for tetrahedronal regions".
    //          Computer Methods in Applied DOFsHandler and Engineering, Volume 43, pp. 349-353, 1984.
    //      P. Keast. "Moderate-degree tetrahedral quadrature formulas". Computer Methods
    //          in Applied DOFsHandler and Engineering, Volume 55, pp. 339-348, 1986.
    void CubatureGauss::_tetrahedralRule()
    {
        double a, b;
        double P1, P2, P3, P4;

        switch(this->_iPts)
        {
            case 1:     //order: 1
                a = 1.0/4.0;
                this->_xSamples[0] = a;        this->_xSamples[1] = a;        this->_xSamples[2] = a;
                this->_wSamples[0] = 1.0;
                break;

            case 4:     //order: 2
                a = 0.585410196624969;
                b = 0.138196601125011;
                this->_xSamples[0] = a;        this->_xSamples[ 1] = b;       this->_xSamples[ 2] = b;
                this->_xSamples[3] = b;        this->_xSamples[ 4] = a;       this->_xSamples[ 5] = b;
                this->_xSamples[6] = b;        this->_xSamples[ 7] = b;       this->_xSamples[ 8] = a;
                this->_xSamples[9] = b;        this->_xSamples[10] = b;       this->_xSamples[11] = b;

                for (int i=0; i< 4; i++) this->_wSamples[i] = 1.0/4.0;
                break;

            case 5:     //order: 3
                a = 1.0/4.0;
                this->_xSamples[0] = a;        this->_xSamples[1] = a;        this->_xSamples[2] = a;

                a = 1.0/2.0;
                b = 1.0/6.0;
                this->_xSamples[ 3] = a;       this->_xSamples[ 4] = b;       this->_xSamples[ 5] = b;
                this->_xSamples[ 6] = b;       this->_xSamples[ 7] = a;       this->_xSamples[ 8] = b;
                this->_xSamples[ 9] = b;       this->_xSamples[10] = b;       this->_xSamples[11] = a;
                this->_xSamples[12] = b;       this->_xSamples[13] = b;       this->_xSamples[14] = b;

                this->_wSamples[0] =-4.0/ 5.0;
                for (int i=1; i< 5; i++) this->_wSamples[i] = 9.0/20.0;

                break;

            case 11:        //order: 4
                a = 1.0/4.0;
                this->_xSamples[0] = a;        this->_xSamples[1] = a;        this->_xSamples[2] = a;

                a = 11.0/14.0;
                b =  1.0/14.0;
                this->_xSamples[ 3] = a;       this->_xSamples[ 4] = b;       this->_xSamples[ 5] = b;
                this->_xSamples[ 6] = b;       this->_xSamples[ 7] = a;       this->_xSamples[ 8] = b;
                this->_xSamples[ 9] = b;       this->_xSamples[10] = b;       this->_xSamples[11] = a;
                this->_xSamples[12] = b;       this->_xSamples[13] = b;       this->_xSamples[14] = b;

                a = 0.399403576166799;
                b = 0.100596423833201;
                this->_xSamples[15] = a;       this->_xSamples[16] = b;       this->_xSamples[17] = b;
                this->_xSamples[18] = b;       this->_xSamples[19] = a;       this->_xSamples[20] = b;
                this->_xSamples[21] = b;       this->_xSamples[22] = b;       this->_xSamples[23] = a;
                this->_xSamples[24] = b;       this->_xSamples[25] = a;       this->_xSamples[26] = a;
                this->_xSamples[27] = a;       this->_xSamples[28] = b;       this->_xSamples[29] = a;
                this->_xSamples[30] = a;       this->_xSamples[31] = a;       this->_xSamples[32] = b;

                P1 = -74.0/ 5625.0*6.0;
                P2 = 343.0/45000.0*6.0;
                P3 =  28.0/ 1125.0*6.0;
                this->_wSamples[0] = P1;
                for (int i=1; i< 5; i++) this->_wSamples[i] = P2;
                for (int i=5; i<11; i++) this->_wSamples[i] = P3;

                break;

            case 15:        //order: 5
                a = 1.0/4.0;
                this->_xSamples[0] = a;        this->_xSamples[1] = a;        this->_xSamples[2] = a;

                a = (13.0+3.0*sqrt(15.0))/34.0;
                b = (7.0-sqrt(15.0))/34.0;
                this->_xSamples[ 3] = a;       this->_xSamples[ 4] = b;       this->_xSamples[ 5] = b;
                this->_xSamples[ 6] = b;       this->_xSamples[ 7] = a;       this->_xSamples[ 8] = b;
                this->_xSamples[ 9] = b;       this->_xSamples[10] = b;       this->_xSamples[11] = a;
                this->_xSamples[12] = b;       this->_xSamples[13] = b;       this->_xSamples[14] = b;

                a = (13.0-3.0*sqrt(15.0))/34.0;
                b = (7.0+sqrt(15.0))/34.0;
                this->_xSamples[15] = a;       this->_xSamples[16] = b;       this->_xSamples[17] = b;
                this->_xSamples[18] = b;       this->_xSamples[19] = a;       this->_xSamples[20] = b;
                this->_xSamples[21] = b;       this->_xSamples[22] = b;       this->_xSamples[23] = a;
                this->_xSamples[24] = b;       this->_xSamples[25] = b;       this->_xSamples[26] = b;

                a = (10.0-2.0*sqrt(15.0))/40.0;
                b = (10.0+2.0*sqrt(15.0))/40.0;
                this->_xSamples[27] = a;       this->_xSamples[28] = b;       this->_xSamples[29] = b;
                this->_xSamples[30] = b;       this->_xSamples[31] = a;       this->_xSamples[32] = b;
                this->_xSamples[33] = b;       this->_xSamples[34] = b;       this->_xSamples[35] = a;
                this->_xSamples[36] = b;       this->_xSamples[37] = a;       this->_xSamples[38] = a;
                this->_xSamples[39] = a;       this->_xSamples[40] = b;       this->_xSamples[41] = a;
                this->_xSamples[42] = a;       this->_xSamples[43] = a;       this->_xSamples[44] = b;

                P1 = 16.0/135.0;
                P2 = (2665.0+14.0*sqrt(15.0))/37800.0;
                P3 = (2665.0-14.0*sqrt(15.0))/37800.0;
                P4 = 20.0/378.0;
                this->_wSamples[0] = P1;
                for (int i= 1; i< 5; i++) this->_wSamples[i] = P2;
                for (int i= 5; i< 9; i++) this->_wSamples[i] = P3;
                for (int i= 9; i<15; i++) this->_wSamples[i] = P4;

                break;

            case 27:        //order: 6
                a = 1.0/4.0;
                this->_xSamples[0] = a;        this->_xSamples[1] = a;        this->_xSamples[2] = a;

                a = 0.0;
                b = 1.0/3.0;
                this->_xSamples[ 3] = a;       this->_xSamples[ 4] = b;       this->_xSamples[ 5] = b;
                this->_xSamples[ 6] = b;       this->_xSamples[ 7] = a;       this->_xSamples[ 8] = b;
                this->_xSamples[ 9] = b;       this->_xSamples[10] = b;       this->_xSamples[11] = a;
                this->_xSamples[12] = b;       this->_xSamples[13] = b;       this->_xSamples[14] = b;

                a = 8.0/11.0;
                b = 1.0/11.0;
                this->_xSamples[15] = a;       this->_xSamples[16] = b;       this->_xSamples[17] = b;
                this->_xSamples[18] = b;       this->_xSamples[19] = a;       this->_xSamples[20] = b;
                this->_xSamples[21] = b;       this->_xSamples[22] = b;       this->_xSamples[23] = a;
                this->_xSamples[24] = b;       this->_xSamples[25] = b;       this->_xSamples[26] = b;

                a = 0.066550153573664;
                b = 0.433449846426336;
                this->_xSamples[27] = a;       this->_xSamples[28] = b;       this->_xSamples[29] = b;
                this->_xSamples[30] = b;       this->_xSamples[31] = a;       this->_xSamples[32] = b;
                this->_xSamples[33] = b;       this->_xSamples[34] = b;       this->_xSamples[35] = a;
                this->_xSamples[36] = b;       this->_xSamples[37] = a;       this->_xSamples[38] = a;
                this->_xSamples[39] = a;       this->_xSamples[40] = b;       this->_xSamples[41] = a;
                this->_xSamples[42] = a;       this->_xSamples[43] = a;       this->_xSamples[44] = b;

                P1 = 0.030283678097089*6.0;
                P2 = 0.006026785714286*6.0;
                P3 = 0.011645249086029*6.0;
                P4 = 0.010949141561386*6.0;
                this->_wSamples[0]= P1;
                for (int i= 1; i< 5; i++) this->_wSamples[i] = P2;
                for (int i= 5; i< 9; i++) this->_wSamples[i] = P3;
                for (int i= 9; i<15; i++) this->_wSamples[i] = P4;

                break;

            case 64:        //order: 7

                double r[4]={0.0694318422, 0.3300094782, 0.6699905218, 0.9305681558};
                double s[4]={0.0571041961, 0.2768430136, 0.5835904324, 0.8602401357};
                double t[4]={0.0485005494, 0.2386007376, 0.5170472951, 0.7958514179};
                double A[4]={0.1739274226, 0.3260725774, 0.3260725774, 0.1739274226};
                double B[4]={0.1355069134, 0.2034645680, 0.1298475476, 0.0311809709};
                double C[4]={0.1108884156, 0.1434587898, 0.0686338872, 0.0103522407};
                int m=0;

                for (int k=0; k<4; k++)
                    for (int i=0; i<4; i++)
                        for (int j=0; j<4; j++)
                        {
                            this->_xSamples[m*3]   = t[k];
                            this->_xSamples[m*3+1] = s[j]*(1.0-t[k]);
                            this->_xSamples[m*3+2] = r[i]*(1.0-s[j])*(1.0-t[k]);
                            this->_wSamples[m]     = 6.0*A[i]*B[j]*C[k];
                            m++;
                        }

                break;

        }

        for ( int i=0; i<this->_iPts; i++ )
            this->_wSamples[i] /=6.0 ;

        return;
    }

    // Weights and canonical variables for integration on quadrilaterals
    //
    // Reference:
    //      K-J Bathe. Finite Element Procedure. Chapter 5, pp. 460-466.
    //      Prentice Hall, Upper Saddle River, New Jersey, 1996.
    void CubatureGauss::_quadrilateralRule()
    {
        int k, np;
        np = (int) sqrt(this->_iPts);

        double *pt = new double[np];
        double *gw = new double[np];

        if (this->_iPts == 1)
        {
            pt[0] = 0.0;
            gw[0] = 2.0;
        }
        else if (this->_iPts == 4)
        {
            pt[0] =-1.0/sqrt(3.0);
            pt[1] = 1.0/sqrt(3.0);
            gw[0] = 1.0;
            gw[1] = 1.0;
        }
        else if (this->_iPts == 9)
        {
            pt[0] =-sqrt(3.0/5.0);
            pt[1] = 0.0;
            pt[2] = sqrt(3.0/5.0);

            gw[0] = 5.0/9.0;
            gw[1] = 8.0/9.0;
            gw[2] = 5.0/9.0;
        }
        else if (this->_iPts == 16)
        {
            pt[0] =-sqrt((3.0 + 2.0*sqrt(6.0/5.0))/7.0);
            pt[1] =-sqrt((3.0 - 2.0*sqrt(6.0/5.0))/7.0);
            pt[2] = sqrt((3.0 - 2.0*sqrt(6.0/5.0))/7.0);
            pt[3] = sqrt((3.0 + 2.0*sqrt(6.0/5.0))/7.0);

            gw[0] = 1.0/2.0 - sqrt(5.0/6.0)/6.0;
            gw[1] = 1.0/2.0 + sqrt(5.0/6.0)/6.0;
            gw[2] = 1.0/2.0 + sqrt(5.0/6.0)/6.0;
            gw[3] = 1.0/2.0 - sqrt(5.0/6.0)/6.0;
        }
        else if (this->_iPts == 25)
        {
            pt[0] =-sqrt(5.0 + 2.0*sqrt(10.0/7.0))/3.0;
            pt[1] =-sqrt(5.0 - 2.0*sqrt(10.0/7.0))/3.0;
            pt[2] = 0.0;
            pt[3] = sqrt(5.0 - 2.0*sqrt(10.0/7.0))/3.0;
            pt[4] = sqrt(5.0 + 2.0*sqrt(10.0/7.0))/3.0;

            gw[0] = (322.0 - 13.0*sqrt(70.0))/900.0;
            gw[1] = (322.0 + 13.0*sqrt(70.0))/900.0;
            gw[2] = 128.0 / 225.0;
            gw[3] = (322.0 + 13.0*sqrt(70.0))/900.0;
            gw[4] = (322.0 - 13.0*sqrt(70.0))/900.0;
        }
        else if (this->_iPts == 36)
        {
            pt[0] = -0.9324695142031520;
            pt[1] = -0.6612093864662645;
            pt[2] = -0.2386191860831969;
            pt[3] = 0.2386191860831969;
            pt[4] = 0.6612093864662645;
            pt[5] = 0.9324695142031520;

            gw[0] = 0.1713244923791703;
            gw[1] = 0.3607615730481386;
            gw[2] = 0.4679139345726911;
            gw[3] = 0.4679139345726911;
            gw[4] = 0.3607615730481386;
            gw[5] = 0.1713244923791703;
        }
        else if (this->_iPts == 49)
        {
            pt[0] = -0.9491079123427585;
            pt[1] = -0.7415311855993944;
            pt[2] = -0.4058451513773972;
            pt[3] = 0e0;
            pt[4] = 0.4058451513773972;
            pt[5] = 0.7415311855993944;
            pt[6] = 0.9491079123427585;

            gw[0] = 0.1294849661688697;
            gw[1] = 0.2797053914892767;
            gw[2] = 0.3818300505051189;
            gw[3] = 0.4179591836734694;
            gw[4] = 0.3818300505051189;
            gw[5] = 0.2797053914892767;
            gw[6] = 0.1294849661688697;
        }
        else if (this->_iPts == 64)
        {
            pt[0] = -0.9602898564975362;
            pt[1] = -0.7966664774136267;
            pt[2] = -0.5255324099163290;
            pt[3] = -0.1834346424956498;
            pt[4] = 0.1834346424956498;
            pt[5] = 0.5255324099163290;
            pt[6] = 0.7966664774136267;
            pt[7] = 0.9602898564975362;

            gw[0] = 0.1012285362903763;
            gw[1] = 0.2223810344533745;
            gw[2] = 0.3137066458778873;
            gw[3] = 0.3626837833783620;
            gw[4] = 0.3626837833783620;
            gw[5] = 0.3137066458778873;
            gw[6] = 0.2223810344533745;
            gw[7] = 0.1012285362903763;
        }
        else if (this->_iPts == 81)
        {
            pt[0] = -0.9681602395076261;
            pt[1] = -0.8360311073266358;
            pt[2] = -0.6133714327005904;
            pt[3] = -0.3242534234038089;
            pt[4] = 0e0;
            pt[5] = 0.3242534234038089;
            pt[6] = 0.6133714327005904;
            pt[7] = 0.8360311073266358;
            pt[8] = 0.9681602395076261;

            gw[0] = 0.0812743883615744;
            gw[1] = 0.1806481606948574;
            gw[2] = 0.2606106964029354;
            gw[3] = 0.3123470770400029;
            gw[4] = 0.3302393550012598;
            gw[5] = 0.3123470770400028;
            gw[6] = 0.2606106964029355;
            gw[7] = 0.1806481606948574;
            gw[8] = 0.0812743883615744;
        }
        else if (this->_iPts == 100)
        {
            pt[0] = -0.9739065285171717;
            pt[1] = -0.8650633666889845;
            pt[2] = -0.6794095682990244;
            pt[3] = -0.4333953941292471;
            pt[4] = -0.1488743389816312;
            pt[5] = 0.1488743389816312;
            pt[6] = 0.4333953941292471;
            pt[7] = 0.6794095682990244;
            pt[8] = 0.8650633666889845;
            pt[9] = 0.9739065285171717;

            gw[0] = 0.0666713443086881;
            gw[1] = 0.1494513491505805;
            gw[2] = 0.2190863625159820;
            gw[3] = 0.2692667193099963;
            gw[4] = 0.2955242247147528;
            gw[5] = 0.2955242247147528;
            gw[6] = 0.2692667193099963;
            gw[7] = 0.2190863625159820;
            gw[8] = 0.1494513491505805;
            gw[9] = 0.0666713443086881;
        }
        else if (this->_iPts == 225)
        {
            pt[0] = -0.9879925180204854;
            pt[1] = -0.9372733924007059;
            pt[2] = -0.8482065834104272;
            pt[3] = -0.7244177313601700;
            pt[4] = -0.5709721726085388;
            pt[5] = -0.3941513470775634;
            pt[6] = -0.2011940939974345;
            pt[7] = 0e0;
            pt[8] = 0.2011940939974345;
            pt[9] = 0.3941513470775634;
            pt[10] = 0.5709721726085388;
            pt[11] = 0.7244177313601700;
            pt[12] = 0.8482065834104272;
            pt[13] = 0.9372733924007059;
            pt[14] = 0.9879925180204854;

            gw[0] = 0.03075324199611807;
            gw[1] = 0.07036604748811134;
            gw[2] = 0.1071592204671351;
            gw[3] = 0.1395706779261761;
            gw[4] = 0.1662692058169852;
            gw[5] = 0.1861610000155741;
            gw[6] = 0.1984314853271374;
            gw[7] = 0.2025782419255562;
            gw[8] = 0.1984314853271374;
            gw[9] = 0.1861610000155741;
            gw[10] = 0.1662692058169852;
            gw[11] = 0.1395706779261761;
            gw[12] = 0.1071592204671351;
            gw[13] = 0.07036604748811134;
            gw[14] = 0.03075324199611807;
        }

        k=0;
        for (int i = 0; i < np; i++)
        {
            for (int j = 0; j < np; j++)
            {
                this->_xSamples[2*k+0] = pt[i];
                this->_xSamples[2*k+1] = pt[j];
                this->_wSamples[k] = gw[i]*gw[j];
                k++;
            }
        }

        delete [] pt;
        delete [] gw;

        return;
    }

    // Weights and canonical variables for integration on parallelepipeds
    void CubatureGauss::_parallelepipedalRule()
    {
        int m, np;
        np = int(cbrt(this->_iPts));

        vector<double> pt(np);
        vector<double> gw(np);

        if (this->_iPts == 1)
        {
            pt[0] = 0.0;
            gw[0] = 2.0;
        }
        else if (this->_iPts == 8)
        {
            pt[0] =-1.0/sqrt(3.0);
            pt[1] = 1.0/sqrt(3.0);
            gw[0] = 1.0;
            gw[1] = 1.0;
        }
        else if (this->_iPts == 27)
        {
            pt[0] =-sqrt(3.0/5.0);
            pt[1] = 0.0;
            pt[2] = sqrt(3.0/5.0);

            gw[0] = 5.0/9.0;
            gw[1] = 8.0/9.0;
            gw[2] = 5.0/9.0;
        }
        else if (this->_iPts == 64)
        {
            pt[0] = -sqrt((3.0 + 2.0*sqrt(6.0/5.0))/7.0);
            pt[1] = -sqrt((3.0 - 2.0*sqrt(6.0/5.0))/7.0);
            pt[2] =  sqrt((3.0 - 2.0*sqrt(6.0/5.0))/7.0);
            pt[3] =  sqrt((3.0 + 2.0*sqrt(6.0/5.0))/7.0);

            gw[0] = (18.0 - sqrt(30.0))/36.0;
            gw[1] = (18.0 + sqrt(30.0))/36.0;
            gw[2] = (18.0 + sqrt(30.0))/36.0;
            gw[3] = (18.0 - sqrt(30.0))/36.0;
        }
        else if (this->_iPts == 125)
        {
            pt[0] = -sqrt(5.0 + 2.0*sqrt(10.0/7.0))/3.0;
            pt[1] = -sqrt(5.0 - 2.0*sqrt(10.0/7.0))/3.0;
            pt[2] =  0.0;
            pt[3] =  sqrt(5.0 - 2.0*sqrt(10.0/7.0))/3.0;
            pt[4] =  sqrt(5.0 + 2.0*sqrt(10.0/7.0))/3.0;

            gw[0] = (322.0 - 13.0*sqrt(70.0))/900.0;
            gw[1] = (322.0 + 13.0*sqrt(70.0))/900.0;
            gw[2] = 128.0 / 225.0;
            gw[3] = (322.0 + 13.0*sqrt(70.0))/900.0;
            gw[4] = (322.0 - 13.0*sqrt(70.0))/900.0;
        }
        else if (this->_iPts == 216)
        {
            pt[0] = -0.9324695142031520;
            pt[1] = -0.6612093864662645;
            pt[2] = -0.2386191860831969;
            pt[3] = 0.2386191860831969;
            pt[4] = 0.6612093864662645;
            pt[5] = 0.9324695142031520;

            gw[0] = 0.1713244923791703;
            gw[1] = 0.3607615730481386;
            gw[2] = 0.4679139345726911;
            gw[3] = 0.4679139345726911;
            gw[4] = 0.3607615730481386;
            gw[5] = 0.1713244923791703;
        }
        else if (this->_iPts == 343)
        {
            pt[0] = -0.9491079123427585;
            pt[1] = -0.7415311855993944;
            pt[2] = -0.4058451513773972;
            pt[3] = 0e0;
            pt[4] = 0.4058451513773972;
            pt[5] = 0.7415311855993944;
            pt[6] = 0.9491079123427585;

            gw[0] = 0.1294849661688697;
            gw[1] = 0.2797053914892767;
            gw[2] = 0.3818300505051189;
            gw[3] = 0.4179591836734694;
            gw[4] = 0.3818300505051189;
            gw[5] = 0.2797053914892767;
            gw[6] = 0.1294849661688697;
        }
        else if (this->_iPts == 512)
        {
            pt[0] = -0.9602898564975362;
            pt[1] = -0.7966664774136267;
            pt[2] = -0.5255324099163290;
            pt[3] = -0.1834346424956498;
            pt[4] = 0.1834346424956498;
            pt[5] = 0.5255324099163290;
            pt[6] = 0.7966664774136267;
            pt[7] = 0.9602898564975362;

            gw[0] = 0.1012285362903763;
            gw[1] = 0.2223810344533745;
            gw[2] = 0.3137066458778873;
            gw[3] = 0.3626837833783620;
            gw[4] = 0.3626837833783620;
            gw[5] = 0.3137066458778873;
            gw[6] = 0.2223810344533745;
            gw[7] = 0.1012285362903763;
        }
        else if (this->_iPts == 729)
        {
            pt[0] = -0.9681602395076261;
            pt[1] = -0.8360311073266358;
            pt[2] = -0.6133714327005904;
            pt[3] = -0.3242534234038089;
            pt[4] = 0e0;
            pt[5] = 0.3242534234038089;
            pt[6] = 0.6133714327005904;
            pt[7] = 0.8360311073266358;
            pt[8] = 0.9681602395076261;

            gw[0] = 0.0812743883615744;
            gw[1] = 0.1806481606948574;
            gw[2] = 0.2606106964029354;
            gw[3] = 0.3123470770400029;
            gw[4] = 0.3302393550012598;
            gw[5] = 0.3123470770400028;
            gw[6] = 0.2606106964029355;
            gw[7] = 0.1806481606948574;
            gw[8] = 0.0812743883615744;
        }
        else if (this->_iPts == 1000)
        {
            pt[0] = -0.9739065285171717;
            pt[1] = -0.8650633666889845;
            pt[2] = -0.6794095682990244;
            pt[3] = -0.4333953941292471;
            pt[4] = -0.1488743389816312;
            pt[5] = 0.1488743389816312;
            pt[6] = 0.4333953941292471;
            pt[7] = 0.6794095682990244;
            pt[8] = 0.8650633666889845;
            pt[9] = 0.9739065285171717;

            gw[0] = 0.0666713443086881;
            gw[1] = 0.1494513491505805;
            gw[2] = 0.2190863625159820;
            gw[3] = 0.2692667193099963;
            gw[4] = 0.2955242247147528;
            gw[5] = 0.2955242247147528;
            gw[6] = 0.2692667193099963;
            gw[7] = 0.2190863625159820;
            gw[8] = 0.1494513491505805;
            gw[9] = 0.0666713443086881;
        }
        else if (this->_iPts == 3375)
        {
            pt[0] = -0.9879925180204854;
            pt[1] = -0.9372733924007059;
            pt[2] = -0.8482065834104272;
            pt[3] = -0.7244177313601700;
            pt[4] = -0.5709721726085388;
            pt[5] = -0.3941513470775634;
            pt[6] = -0.2011940939974345;
            pt[7] = 0e0;
            pt[8] = 0.2011940939974345;
            pt[9] = 0.3941513470775634;
            pt[10] = 0.5709721726085388;
            pt[11] = 0.7244177313601700;
            pt[12] = 0.8482065834104272;
            pt[13] = 0.9372733924007059;
            pt[14] = 0.9879925180204854;

            gw[0] = 0.03075324199611807;
            gw[1] = 0.07036604748811134;
            gw[2] = 0.1071592204671351;
            gw[3] = 0.1395706779261761;
            gw[4] = 0.1662692058169852;
            gw[5] = 0.1861610000155741;
            gw[6] = 0.1984314853271374;
            gw[7] = 0.2025782419255562;
            gw[8] = 0.1984314853271374;
            gw[9] = 0.1861610000155741;
            gw[10] = 0.1662692058169852;
            gw[11] = 0.1395706779261761;
            gw[12] = 0.1071592204671351;
            gw[13] = 0.07036604748811134;
            gw[14] = 0.03075324199611807;
        }
        m=0;
        for (int i = 0; i < np; i++)
        {
            for (int j = 0; j < np; j++)
            {
                for (int k = 0; k < np; k++)
                {
                    this->_xSamples[3*m+0] = pt[k];
                    this->_xSamples[3*m+1] = pt[j];
                    this->_xSamples[3*m+2] = pt[i];
                    this->_wSamples[m] = gw[i]*gw[j]*gw[k];
                    m++;
                }
            }
        }

        //  // The volume of the reference element is 8
        //  for (int i=0; i<this->_iPts; i++)
        //      this->_wSamples[i] = this->_wSamples[i] / 8.0;


        return;
    }


}// end namespace
