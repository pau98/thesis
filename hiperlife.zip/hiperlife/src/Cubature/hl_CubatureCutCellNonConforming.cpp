/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors: Mohammad Reza Bayat
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/

#include <math.h>
#include <numeric> // std::accumulate

#include "hl_Math.h"
#include "hl_CubatureGauss.h"
#include "hl_CubatureCutCellNonConforming.h"
#include "hl_Geometry.h"

using namespace std;
using Teuchos::RCP;
using Teuchos::rcp;

namespace hiperlife
{
    void rotateMatrix(std::vector<std::vector<int>> &matrix)
    {
        int n = matrix.size();
        int x = n / 2;
        int y = n - 1;
        for (int i = 0; i < x; i++)
        {
            for (int j = i; j < y - i; j++)
            {
                int k = matrix[i][j];
                matrix[i][j] = matrix[y - j][i];
                matrix[y - j][i] = matrix[y - i][y - j];
                matrix[y - i][y - j] = matrix[j][y - i];
                matrix[j][y - i] = k;
            }
        }
    }

    void CubatureCutCellNonConforming::_subdivideElem(vector<double> blCorner, vector<int> cFlags, int level)
    {
        // In this function we work on the reference coordinate of the element
        // blCorner is the xMin yMin zMin corner
        using namespace SGeometry;

        // Compute jac and side of the subelements
        double jac = pow(1.0 / static_cast<double>(_nSubElems), level);
        double side = 2.0 / static_cast<double>(pow(2, level));

        vector<int> flags;
        vector<int> cutSubElem;
        vector<vector<double>> backPoints;

        if (this->_pDim == 2)
        {
            /*
                Fig. 1 2D subdivision numbering:
                o--------o--------o
                |        |        |
                |    2   |    3   |
                |        |        |
                o--------o--------o
                |        |        |
                |    0   |    1   |
                |        |        |
                o--------o--------o

                Fig. 2 2D flags numbering:
                6        7        8
                o--------o--------o
                |        |        |
                |        |        |
                |        | 4      |
              3 o--------o--------o 5
                |        |        |
                |        |        |
                |        |        |
                o--------o--------o
                0        1        2
            */
            // Create points of the back element
            backPoints.resize(9, vector<double>(3));
            for (int k{}; k < 9; ++k)
            {
                backPoints[k] = {blCorner[0] + (k % 3) * side, blCorner[1] + (k / 3) * side, 0.};
            }

            // Create a map which gives the corner numbers (in Fig. 2) for any subelements in Fig. 1
            map<int, vector<int>> subElementCorners;
            subElementCorners[0] = {0, 1, 4, 3, 0};
            subElementCorners[1] = {1, 2, 5, 4, 1};
            subElementCorners[2] = {3, 4, 7, 6, 3};
            subElementCorners[3] = {4, 5, 8, 7, 4};

            // Create corner flags
            //  meaning of values:
            //  -1: unknown,
            //   0: outside, and
            //   1: inside
            //   2: on the boundary of geometry
            flags.resize(9, -1);
            flags[0] = cFlags[0];
            flags[2] = cFlags[1];
            flags[6] = cFlags[2];
            flags[8] = cFlags[3];

            if (cFlags[0] == 2 and cFlags[1] == 2 and cFlags[2] == 2 and cFlags[3] == 2)
                throw runtime_error("CubatureCutCellNonConforming::_subdivideElem: Special case all corners of the elements are on the boundary of immersed geometry!");

            vector<int> unknownPoints = {1, 3, 4, 5, 7};

            // Check if the corner of the subelement lies on the boundary of geometry
            for (size_t i = 0; i < unknownPoints.size(); ++i)
            {
                for (auto segment : _immSegments)
                {
                    if (tripletOrientation2D(segment[0], backPoints[unknownPoints[i]], segment[1]) == 0)
                    {
                        if (isOnSegment(segment[0], backPoints[unknownPoints[i]], segment[1]) or
                            distanceTwoPoints(segment[0], backPoints[unknownPoints[i]]) < 1.e-12 or
                            distanceTwoPoints(segment[1], backPoints[unknownPoints[i]]) < 1.e-12)
                        {
                            flags[unknownPoints[i]] = 2;
                        }
                    }
                }
            }

            // Determine the direction of immersed segments
            // 0: the first point of each segment is the same as the last point of the next segment
            // 1: the last point of each segment is the same as the first point of the next segment
            int immersedSegmentDirection = 0;
            if (_immSegments.size() > 1)
            {
                if ((_immSegments[0][1][0] == _immSegments[1][0][0] and
                     _immSegments[0][1][1] == _immSegments[1][0][1] and
                     _immSegments[0][1][2] == _immSegments[1][0][2]))
                {
                    immersedSegmentDirection = 1;
                }
            }

            // Loop over all unknown flags and draw a line from each point with unknown flag to a point
            // with known flag (testline). Check the intersection of the testline with immersed meshes.
            for (int i : unknownPoints)
            {
                if (flags[i] == -1)
                {
                    // Create a test line if the cFlags[j] is not on the boundary
                    int knownPoint{};
                    for (int j = 0; j < 9; ++j)
                    {
                        if (j != i and flags[j] != 2 and flags[j] != -1)
                        {
                            knownPoint = j;
                            break;
                        }
                    }
                    vector<vector<double>> testLine = {backPoints[i], backPoints[knownPoint]};

                    // Initialize flag
                    flags[i] = flags[knownPoint];

                    // Checking the intersection of the test line with the immersed mesh
                    for (size_t k = 0; k < _immSegments.size(); ++k)
                    {
                        auto segment = _immSegments[k];
                        bool onSegment0 = false;
                        bool onSegment1 = false;

                        if (k == 0)
                        {
                            // Check if the first point of the immersed mesh (geometry) lies on the edge of the subelement
                            bool isColinear0 = !(tripletOrientation2D(backPoints[knownPoint], segment[0], backPoints[i]));
                            if (isColinear0)
                            {
                                onSegment0 = isOnSegment(backPoints[knownPoint], segment[0], backPoints[i]);
                            }

                            // Check if the last point of the immersed mesh (geometry) lies on the edge of the subelement
                            bool isColinear1 = !(tripletOrientation2D(backPoints[knownPoint], segment[1], backPoints[i]));
                            if (isColinear1)
                            {
                                onSegment1 = isOnSegment(backPoints[knownPoint], segment[1], backPoints[i]);
                            }
                        }
                        else if (k != 0 and immersedSegmentDirection == 0)
                        {
                            // Check if the first point of the immersed mesh (geometry) lies on the edge of the subelement
                            bool isColinear0 = !(tripletOrientation2D(backPoints[knownPoint], segment[0], backPoints[i]));
                            if (isColinear0)
                            {
                                onSegment0 = isOnSegment(backPoints[knownPoint], segment[0], backPoints[i]);
                            }
                        }
                        else if (k != 0 and immersedSegmentDirection == 1)
                        {
                            // Check if the last point of the immersed mesh (geometry) lies on the edge of the subelement
                            bool isColinear1 = !(tripletOrientation2D(backPoints[knownPoint], segment[1], backPoints[i]));
                            if (isColinear1)
                            {
                                onSegment1 = isOnSegment(backPoints[knownPoint], segment[1], backPoints[i]);
                            }
                        }
                        // If testLine intersects with the immersed segment or the first/last point of the immersed segment
                        // lies on the testLine then the value of the coresponding flag will be reversed
                        if (doesIntersect(testLine, segment) or onSegment0 or onSegment1)
                        {
                            // Change flag
                            if (flags[i] == 0)
                                flags[i] = 1;
                            else if (flags[i] == 1)
                                flags[i] = 0;
                            if (onSegment0 or onSegment1)
                                break;
                        }
                    }
                }
            }

            // Check if the immersed curve goes through each subelement
            // If any edge of the subelement intersect with any elements of immersed mesh the subelement will be tagged
            cutSubElem.resize(_nSubElems, 0);
            for (int s = 0; s < _nSubElems; s++)
            {
                vector<int> subCorners = subElementCorners[s];
                bool keepChecking = true;
                size_t i = 0;
                while (keepChecking and i < subCorners.size() - 1)
                {
                    vector<vector<double>> L1 = {backPoints[subCorners[i]], backPoints[subCorners[i + 1]]};
                    for (auto segment : _immSegments)
                    {
                        if (doesIntersect(L1, segment))
                        {
                            cutSubElem[s] = 1;
                            keepChecking = false;
                        }
                    }
                    i++;
                }

                if ((flags[subCorners[1]] == 2 and flags[subCorners[3]] == 2 and flags[subCorners[0]] != 2 and flags[subCorners[2]] != 2) or
                    (flags[subCorners[0]] == 2 and flags[subCorners[2]] == 2 and flags[subCorners[1]] != 2 and flags[subCorners[3]] != 2))
                {
                    cutSubElem[s] = 1;
                }
            }

            // Subdivide
            vector<int> myidx = {0, 1, 3, 4};
            for (int s = 0; s < _nSubElems; s++)
            {
                // Extract corner flags
                vector<int> cF(4);
                for (int c = 0; c < _nSubElems; c++)
                    cF[c] = flags[myidx[s] + myidx[c]];

                // Subdivide or add integration points
                if (cutSubElem[s] and level < _numSubdiv)
                {
                    _subdivideElem(backPoints[myidx[s]], cF, level + 1);
                }
                else if (any_of(cF.begin(), cF.end(), [](int f)
                                { return f == 1; }) or
                         (level == _numSubdiv and cutSubElem[s] == 1))
                {
                    for (int g = 0; g < _cubaInfoGauss.iPts; g++)
                    {
                        _wSamples.push_back(_cubaInfoGauss.wSamples[g] * jac);
                        for (int p = 0; p < _pDim; p++)
                            _xSamples.push_back(_cubaInfoGauss.xSamples[_pDim * g + p] * 0.5 * side + backPoints[myidx[s]][p] + 0.5 * side);
                    }
                }
            }
        }
        else if (this->_pDim == 3)
        {
            // Create points of the back element
            backPoints.resize(27, vector<double>(3));
            for (int k{}; k < 27; ++k)
            {
                backPoints[k] = {(k % 3) * side + blCorner[0],
                                 ((k - 9 * (k / 9)) / 3) * side + blCorner[1],
                                 (k / 9) * side + blCorner[2]};
            }

            // Create corner flags
            //  meaning of values:
            //  -1: unknown,
            //   0: outside, and
            //   1: inside
            //   2: on the boundary of geometry
            flags.resize(27, -1);
            flags[0] = cFlags[0];
            flags[2] = cFlags[1];
            flags[6] = cFlags[2];
            flags[8] = cFlags[3];
            flags[18] = cFlags[4];
            flags[20] = cFlags[5];
            flags[24] = cFlags[6];
            flags[26] = cFlags[7];

            if (all_of(cFlags.begin(), cFlags.end(), [](int cf)
                       { return cf == 2; }))
                throw runtime_error("CubatureCutCellNonConforming::_subdivideElem: Special case all corners of the elements are on the boundary of immersed geometry!");

            vector<int> unknownPoints = {1, 3, 4, 5, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 21, 22, 23, 25};

            // Check if the unknown corner of the subelement lies on the boundary of geometry
            for (auto segment : _immSegments) // each segment is a vector of three points
            {
                for (size_t i = 0; i < unknownPoints.size(); ++i)
                {
                    // check if the unknown point lies on any vertices
                    if (distanceTwoPoints(segment[0], backPoints[unknownPoints[i]]) < 1.e-12 or
                        distanceTwoPoints(segment[1], backPoints[unknownPoints[i]]) < 1.e-12 or
                        distanceTwoPoints(segment[2], backPoints[unknownPoints[i]]) < 1.e-12)
                    {
                        flags[unknownPoints[i]] = 2;
                        continue;
                    }

                    // check if the unknown point lies on any edges
                    if (isOnSegment(segment[0], backPoints[unknownPoints[i]], segment[1]) or
                        isOnSegment(segment[1], backPoints[unknownPoints[i]], segment[2]) or
                        isOnSegment(segment[2], backPoints[unknownPoints[i]], segment[0]))
                    {
                        flags[unknownPoints[i]] = 2;
                        continue;
                    }

                    // check if the unknown point lies on any faces
                    if (isOnPlane(backPoints[unknownPoints[i]], segment[0], segment[1], segment[2]))
                    {
                        if (isPointInside3DTriangle(backPoints[unknownPoints[i]], segment[0], segment[1], segment[2]))
                        {
                            flags[unknownPoints[i]] = 2;
                        }
                    }
                }
            }

            cutSubElem.resize(_nSubElems, 0);
            vector<int> indMin = {0, 1, 3, 4, 9, 10, 12, 13};      // index of xMin-yMin-zMin corner of each subelements
            vector<int> indMax = {13, 14, 16, 17, 22, 23, 25, 26}; // index of xMax-yMax-zMax corner of each subelements

            for (size_t i{}; i < _immPts.size(); ++i) // loop over all points that are distributed on teh imm elements
            {
                for (int j{}; j < _nSubElems; ++j) // check if imm. point is inside the subelement
                {
                    if (isPointInCuboid(_immPts[i], backPoints[indMin[j]], backPoints[indMax[j]]))
                    {
                        cutSubElem[j] = 1;
                        break;
                    }
                }
            }

            if (accumulate(cutSubElem.begin(), cutSubElem.end(), 0) == 0)
                throw runtime_error("CubatureCutCellNonConforming::_subdivideElem: No cut element detected. Probably the geometry concides with the back mesh. Move or change the geometry.");

            // Corner numbers of each subelement
            vector<int> myidx = { 0, 1, 3, 4, 9, 10, 12, 13 };

            // loop through all non-cut subelements and compute their corner flags
            for (int se{}; se < _nSubElems; ++se)
            {
                if (cutSubElem[se] == 0)
                {
                    // Extract corner flags
                    vector<int> cF(8);
                    for (int c{}; c < _nSubElems; ++c)
                    {
                        cF[c] = flags[myidx[se] + myidx[c]];
                    }
                    // if any of corners of the subelement is inside change all the others as inside
                    if (any_of(cF.begin(), cF.end(), [](int f) { return (f == 1); }))
                    {
                        for (int c{}; c < _nSubElems; ++c)
                        {
                            if (flags[myidx[se] + myidx[c]] == -1)
                                flags[myidx[se] + myidx[c]] = 1;
                        }
                    }
                    else // change all the other corners as outside
                    {
                        for (int c{}; c < _nSubElems; ++c)
                        {
                            if (flags[myidx[se] + myidx[c]] == -1)
                                flags[myidx[se] + myidx[c]] = 0;
                        }
                    }
                }
            }

            
            // Subdivide
            for (int se{}; se < _nSubElems; ++se)
            {
                // Extract corner flags
                vector<int> cF(8);
                for (int c{}; c < _nSubElems; ++c)
                {
                    cF[c] = flags[myidx[se] + myidx[c]];
                }
                // Subdivide or add integration points
                if (cutSubElem[se] == 1 and level < _numSubdiv)
                {
                    _subdivideElem(backPoints[indMin[se]], cF, level + 1);
                }
                else if (all_of(cF.begin(), cF.end(), [](int f) { return (f == 1); }) or
                    (level == _numSubdiv and cutSubElem[se] == 1))
                    // else if ((level == _numSubdiv and cutSubElem[se] == 1))
                {
                    for (int g = 0; g < _cubaInfoGauss.iPts; g++)
                    {
                        _wSamples.push_back(_cubaInfoGauss.wSamples[g] * jac);
                        for (int p = 0; p < _pDim; p++)
                        {
                            _xSamples.push_back(_cubaInfoGauss.xSamples[_pDim * g + p] * 0.5 * side + backPoints[indMin[se]][p] + 0.5 * side);
                        }
                    }
                }
            }
        }
    }

    void CubatureCutCellNonConforming::Update()
    {
        // Perform checks
        _checkSettings();

        // Initialize
        _pDim = computePDim(_elemType);
        if (_elemType == ElemType::Square)
            _nSubElems = 4;
        else if (_elemType == ElemType::Parallelep)
            _nSubElems = 8;

        // Get the cubature info of a Gauss quadrature
        RCP<CubatureGauss> cubaGauss = rcp(new CubatureGauss);
        cubaGauss->setElemType(_elemType);
        cubaGauss->setNumIntPts(_iPts);
        cubaGauss->Update();
        _cubaInfoGauss = cubaGauss->cubatureInfo();

        // Subdivide element and create integration points
        if (_pDim == 2)
        {
            _subdivideElem({-1.0, -1.0}, _cornerFlags, 1);
        }
        else if (_pDim == 3)
        {

            _subdivideElem({-1.0, -1.0, -1.0}, _cornerFlags, 1);
        }
        _iPts = _wSamples.size();

        // Create cubature info
        _cubaInfo.cubaName = "CubatureCutCellNonConforming";
        _cubaInfo.pDim = _pDim;
        _cubaInfo.iPts = _iPts;
        _cubaInfo.xSamples = _xSamples;
        _cubaInfo.wSamples = _wSamples;
    }

    void CubatureCutCellNonConforming::_checkSettings()
    {
        // The number of int points is already checked when creating the Gauss cubature

        // Check element type
        if (_elemType != ElemType::Square and _elemType != ElemType::Parallelep)
            throw runtime_error("CubatureCutCellNonConforming::_checkSettings: Cubature implemented only for Square or Parallelep elements.");

        // Check number of subdivisions
        if (_numSubdiv <= 0)
            throw runtime_error("CubatureCutCellNonConforming::_checkSettings: The number of subdivisions has to be greater than zero.");

        // Check node flags
        if (_cornerFlags.empty())
            throw runtime_error("CubatureCutCellNonConforming::_checkSettings: Corner flags not set.");
        else if (_elemType == ElemType::Square and _cornerFlags.size() != 4)
            throw runtime_error("CubatureCutCellNonConforming::_checkSettings: There must be four corner flags for Square elements.");
        else if (_elemType == ElemType::Parallelep and _cornerFlags.size() != 8)
            throw runtime_error("CubatureCutCellNonConforming::_checkSettings: There must be eight corner flags for Parallelep elements.");

        // Check immersed mesh points
        if (_immSegments.empty())
        {
            int myRank{};
            MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
            throw runtime_error("From CPU " + to_string(myRank) + ": CubatureCutCellNonConforming::_checkSettings: immersed mesh not set.");
        }
        if (_pDim == 3 and _immPts.empty())
        {
            int myRank{};
            MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
            throw runtime_error("From CPU " + to_string(myRank) + ": CubatureCutCellNonConforming::_checkSettings: immersed points not set.");
        }
    }
}
