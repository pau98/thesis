/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <iterator>
#include <stdexcept>

#include "hl_LoadDOFsHandler.h"
#include "hl_legIOAux.h"

#include <iostream>

using namespace std;

namespace hiperlife
{

    DOFsHandlerParameters::DOFsHandlerParameters(std::string fileName)
    {

        string ext = fileName.substr(fileName.find_last_of(".") + 1);

        // Reading from Legacy Vtk
        if (ext == "vtk")
        {
            if(myRank() == 0)
            {
                readPars_legacyVtk(fileName);
                checkParameters();
            }

            Barrier();

            BcastParamters();
            checkParameters();


        }
        else
        {
            throw runtime_error("DOFsHandlerParameters: Not known file format: " + fileName + ".");
        }
    }


    void DOFsHandlerParameters::checkParameters()
    {
        if(nPts == -1)
            throw runtime_error("DOFsHandlerParameters: Wrong nPts.");
        if(nElem == -1)
            throw runtime_error("DOFsHandlerParameters: Wrong nElem.");
        if(nVert == -1)
            throw runtime_error("DOFsHandlerParameters: Wrong nVert.");
        if(numDOFs == -1)
            throw runtime_error("DOFsHandlerParameters: Wrong numDOFs.");
        if(nDim == -1)
            throw runtime_error("DOFsHandlerParameters: Wrong nDim.");
        if(vtkElType == -1)
            throw runtime_error("DOFsHandlerParameters: Wrong vtkElType.");
        if(int(proc_nPts.size()) != _numProcs)
            throw runtime_error("DOFsHandlerParameters: Wrong proc_nPts.");
        if(int(proc_nElem.size()) != _numProcs)
            throw runtime_error("DOFsHandlerParameters: Wrong proc_nElem.");

        int sum{};
        for(auto e : proc_nPts)
            sum += e;
        if (sum != nPts)
            throw runtime_error("DOFsHandlerParameters: Wrong proc_nPts.");

        sum = 0;
        for(auto e : proc_nElem)
            sum += e;
        if (sum != nElem)
            throw runtime_error("DOFsHandlerParameters: Wrong proc_nElem.");
    }

    void DOFsHandlerParameters::BcastParamters(int root)
    {
        if(_myRank != 0)
        {
            proc_nPts.resize(_numProcs);
            proc_nElem.resize(_numProcs);
        }

        MPI_Bcast(&nPts, 1, MPI_INT, root, _comm);
        MPI_Bcast(&nElem, 1, MPI_INT, root, _comm);
        MPI_Bcast(&nVert, 1, MPI_INT, root, _comm);
        MPI_Bcast(&numDOFs, 1, MPI_INT, root, _comm);
        MPI_Bcast(&nDim, 1, MPI_INT, root, _comm);
        MPI_Bcast(&vtkElType, 1, MPI_INT, root, _comm);
        MPI_Bcast(proc_nPts.data(), _numProcs, MPI_INT, root, _comm);
        MPI_Bcast(proc_nElem.data(), _numProcs, MPI_INT, root, _comm);
    }


    int DOFsHandlerParameters::readPars_legacyVtk(std::string fileName)
    {

        ifstream infile(fileName);
        string line;

        vector<int> nPtsRead;
        vector<int> nElemRead;
        vector<string> dofsReaded;




        while (getline(infile, line))
        {

            if (line.empty())
                continue;

            if (line.find_first_not_of(' ') == string::npos)
                continue;

            std::istringstream iss(line);

            vector<string> tokens{istream_iterator<string>{iss},
                        istream_iterator<string>{}};

            if (tokens[0] == "POINTS")
            {
                nPtsRead.push_back(stoi(tokens[1]));
                nDim = 3;
                continue;
            }

            if (tokens[0] == "POLYGONS" || tokens[0] ==  "CELLS")
            {
                int tempNElem = stoi(tokens[1]);

                nElemRead.push_back(tempNElem);
                int total = stoi(tokens[2]);

                if (total % tempNElem != 0)
                    throw runtime_error("DOFsHandlerParameters::readPars_legacyVtk: There is something wrong in the CELLS \
                    of the input file. nElem: " + to_string(tempNElem) + " -  \
                    Total: " + to_string(total) + ".");

                nVert = total / tempNElem - 1;

                continue;
            }

            if (tokens[0] == "CELL_TYPES")
            {
                nElemRead.push_back(stoi(tokens[1]));
                infile >> vtkElType;
                continue;
            }

            if (tokens[0] == "CELL_DATA")
            {
                int tempNElem = stoi(tokens[1]);
                nElemRead.push_back(tempNElem);
                getline(infile, line);
                std::istringstream iss2(line);
                vector<string> tokens2{istream_iterator<string>{iss2}, istream_iterator<string>{}};

                if (tokens2[1] == "Partition")
                {
                    getline(infile, line);
                    loadProcNElem(infile, tempNElem);
                }

                continue;
            }

            if (tokens[0] == "POINT_DATA")
            {
                int tempNPts = stoi(tokens[1]);
                nPtsRead.push_back(tempNPts);
                getline(infile, line);
                std::istringstream iss2(line);
                vector<string> tokens2{istream_iterator<string>{iss2}, istream_iterator<string>{}};

                if (tokens2[1] == "PartitionPts")
                {
                    getline(infile, line);
                    loadProcNPts(infile, tempNPts);
                }

                continue;
            }

            if (tokens[0].substr(0, 4) == "DOF_")
            {
                dofsReaded.push_back(tokens[0]);
                nPtsRead.push_back(stoi(tokens[2]));
            }


        }

        infile.close();


        // Checking the read values:
        // DOFs:
        std::sort(dofsReaded.begin(), dofsReaded.end());
        for (int i = 0; i < int(dofsReaded.size()); i++)
        {
            if (dofsReaded[i] != "DOF_" + to_string(i))
                throw runtime_error("DOFsHandlerParameters::readPars_legacyVtk: Wrong labels of DOFs (1).");
        }
        numDOFs = dofsReaded.size();

        // nPts
        if (int(nPtsRead.size()) != (numDOFs+2))
            throw runtime_error("DOFsHandlerParameters::readPars_legacyVtk: There is something wrong in the readed nPts (1).");

        if (!std::equal(nPtsRead.begin() + 1, nPtsRead.end(), nPtsRead.begin()))
            throw runtime_error("DOFsHandlerParameters::readPars_legacyVtk: There is something wrong in the readed nPts (2).");

        nPts = nPtsRead[0];

        // nElem
        if (nElemRead.empty())
            throw runtime_error("DOFsHandlerParameters::readPars_legacyVtk: There is something wrong in the readed nElem (1).");
        if (!std::equal(nElemRead.begin() + 1, nElemRead.end(), nElemRead.begin()))
            throw runtime_error("DOFsHandlerParameters::readPars_legacyVtk: There is something wrong in the readed nElem.(2).");

        nElem = nElemRead[0];

        return 0;

    }


    void DOFsHandlerParameters::loadProcNElem(ifstream& infile, int nElem)
    {
        int buff{-1};
        proc_nElem.resize(_numProcs, 0);

        for (int i = 0; i < nElem; i++)
        {
            infile >> buff;

            if (buff >= _numProcs)
                throw runtime_error("DOFsHandlerParameters::loadProcNElem: The partition value (" + to_string(buff) + ") "
                + "is not valid for element " + to_string(i) + ". The file can only be loaded if it was generated with"
                + "the same number of MPI ranks that it is currently running. \n Please check the input file. Goodbye!");

            proc_nElem[buff]++;
        }



        if (std::find(proc_nElem.begin(), proc_nElem.end(), 0) != proc_nElem.end())
                throw runtime_error("DOFsHandlerParameters::loadProcNElem: Some of the partitions do not contained any elements. \
                \nPlease check the input file. Goodbye!");

        int sum{};
        for(auto e : proc_nElem)
            sum += e;

        if (sum != nElem)
                throw runtime_error("DOFsHandlerParameters::loadProcNElem: The number of partition values (" + to_string(sum)
                + ") does not correspond with the expected ones: " + to_string(nElem) + ". \n"
                + "Please check the input file. Goodbye!");
    }

    void DOFsHandlerParameters::loadProcNPts(ifstream& infile, int npts)
    {
        int buff{-1};
        proc_nPts.resize(_numProcs, 0);

        for (int i = 0; i < npts; i++)
        {
            infile >> buff;

            if (buff >= _numProcs)
                throw runtime_error("DOFsHandlerParameters::loadProcNPts: The partition value (" + to_string(buff) + ") "
                + "is not valid for element " + to_string(i) + ". The file can only be loaded if it was generated with"
                + "the same number of MPI ranks that it is currently running. \n Please check the input file. Goodbye!");

            proc_nPts[buff]++;

        }



        if (std::find(proc_nPts.begin(), proc_nPts.end(), 0) != proc_nPts.end())
                throw runtime_error("DOFsHandlerParameters::loadProcNPts: Some of the partitions do not contained any nodes. \
                \nPlease check the input file. Goodbye!");


        int sum{};
        for(auto e : proc_nPts)
            sum += e;

        if (sum != npts)
                throw runtime_error("DOFsHandlerParameters::loadProcNPts: The number of partition values (" + to_string(sum)
                + ") does not correspond with the expected ones: " + to_string(npts) + ". \n"
                + "Please check the input file. Goodbye!");
    }



    void loadFields(double*& fields, vector<string> tags, int& nPts, string fileName, string option)
    {
        MPI_Comm comm = MPI_COMM_WORLD;
        int myRank;
        MPI_Comm_rank(comm, &myRank);

        if (option == "legacyVtk")
        {

            if(myRank == 0)
            {
                loadFields_legacyVtk(fields, tags, nPts, fileName);
            }
            else
            {
                fields = new double[10];
            }

            MPI_Barrier(comm);
        }
        else
        {
            throw runtime_error("loadFields: Unknown option for input file. Introduced option: " + option);
        }

    }

    void loadFields_legacyVtk(double*& fields, vector<string> tags, int& nPts, string fileName)
    {

        ifstream infile(fileName);
        if(!infile.is_open())
        {
            throw runtime_error("loadFields_legacyVtk: The input file (" + fileName + ") does not exist.\n\
            Please check it and rerun. Goodbye!");
        }

        int nFlds = tags.size();

        if (nFlds == 0)
            throw runtime_error("loadFields_legacyVtk: There is no tags to read.\n\
            Please check it and rerun. Goodbye!");

        fields = new double[nPts * nFlds];
        vector<bool> checkRead(nFlds, false);


        string line;


        while (getline(infile, line))
        {
            if (line.empty())
                continue;

            if (line.find_first_not_of(' ') == string::npos)
                continue;

            std::istringstream iss(line);

            vector<string> tokens{istream_iterator<string>{iss},
                        istream_iterator<string>{}};

            auto it = find(tags.begin(), tags.end(), tokens[0]);

            if (it != tags.end())
            {
                auto posIdx = distance(tags.begin(), it);

                if (nPts != stoi(tokens[2]))
                    throw runtime_error("loadFields_legacyVtk: Error in nPts of the field: " + tokens[0] + ".\n\
                    Please check it and rerun. Goodbye!");

                fillField<double>(fields, infile, nPts, nFlds, posIdx);
                checkRead[posIdx] = true;
                continue;
            }
        }

        auto it = find(checkRead.begin(), checkRead.end(), false);
        if (it != checkRead.end())
        {
            auto posIdx = distance(checkRead.begin(), it);
            throw runtime_error("loadFields_legacyVtk: The field: " + tags[posIdx] + ".\n\
                Please check it and rerun. Goodbye!");
        }





    }


}
