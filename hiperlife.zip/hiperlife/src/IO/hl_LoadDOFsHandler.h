/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LOADDOFSHANDLER_H
#define LOADDOFSHANDLER_H

#include <string>
#include <vector>

#include "hl_DistributedClass.h"

namespace hiperlife
{
    class DOFsHandlerParameters : public DistributedClass
    {
        public:
            DOFsHandlerParameters() = default;
            DOFsHandlerParameters(DOFsHandlerParameters&& other) = default;
            DOFsHandlerParameters(const DOFsHandlerParameters& other) = delete;
            ~DOFsHandlerParameters() = default;

            DOFsHandlerParameters(std::string fileName);


            int nPts{-1};
            int nElem{-1};
            int nVert{-1};
            int nDim{-1};
            int vtkElType{-1};
            int numDOFs{-1};
            std::string fileName;

            std::vector<int> proc_nPts;
            std::vector<int> proc_nElem;

            int readPars_legacyVtk(std::string fileName);
            void checkParameters();
            void BcastParamters(int root = 0);
            void loadProcNElem(std::ifstream& infile, int nElem);
            void loadProcNPts(std::ifstream& infile, int nPts);

    };

    void loadFields(double*& fields, std::vector<std::string> tags, int& nPts, std::string fileName, std::string option);
    void loadFields_legacyVtk(double*& fields, std::vector<std::string> tags, int& nPts, std::string fileName);

}

#endif // LOADDOFSHANDLER_H
