/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef IOAUX_H
#define IOAUX_H

#include <string>
#include <sstream>
#include <stdexcept>

#include <Teuchos_RCP.hpp>

#include "hl_FieldStruct.h"
#include "hl_DistributedMesh.h"


namespace hiperlife
{

    inline std::string str(int i)
    {
        std::ostringstream ss;
        ss << std::setw(5) << std::setfill('0') << i;
        return ss.str();
    }



    template<typename T> void fillArrayData(T*& outData, std::ifstream& infile, int numItms, int dataPerItem = 1, int ignoreV = 0)
    {

        outData = new T[numItms * (dataPerItem-ignoreV)];

        int n = 0;
        T buff;

        for (int i = 0; i < numItms; i++)
        {
            for (int v = 0; v < dataPerItem; v++)
            {
                infile >> buff;

                if (v >= ignoreV)
                {
                    outData[n] = buff;
                    n++;
                }
            }
        }
    }

    template<typename T, typename A> void fillVectorData(std::vector<T,A> &outData, std::ifstream& infile, int numItms, int dataPerItem = 1, int ignoreV = 0, int ignoreIn = 0, int afterV = 0, bool resize = true)
    {
        if (resize)
            outData.resize(afterV + numItms* (dataPerItem-ignoreV));

        int n = afterV;
        T buff;

        for (int i = 0; i < ignoreIn*dataPerItem; i++)
            infile >> buff;

        for (int i = 0; i < numItms; i++)
        {
            for (int v = 0; v < dataPerItem; v++)
            {
                infile >> buff;

                if (v >= ignoreV)
                {
                    outData[n] = buff;
                    n++;
                }
            }
        }
    }

    template<typename T> void fillField(T*& outData, std::ifstream& infile, int numItms, int nFlds = 1, int idxFld = 0)
    {
        T buff;

        for (int i = 0; i < numItms; i++)
        {
            int  iD  = i * nFlds + idxFld;

            infile >> buff;

            outData[iD] = buff;
        }
    }


}




#endif
