/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#include <mpi.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <iterator>

#include "hl_LoadMesh.h"
#include "hl_legIOAux.h"

using namespace std;



namespace hiperlife
{


    void loadMesh(int &nPts, int &nElem, int nVert ,int*& connec, double*& xNodes, int*& iCreases, string name, string option)
    {
        MPI_Comm comm = MPI_COMM_WORLD;
        int myRank;
        MPI_Comm_rank(comm, &myRank);

        if (option == "legacyVtk")
        {

            if(myRank == 0)
            {
                loadMesh_legacyVtk(nPts, nElem, nVert, connec, xNodes, iCreases, name);
            }
            else
            {
                connec = new int[10];
                xNodes = new double[10];
                iCreases = new int[10];
            }

            MPI_Barrier(comm);

            MPI_Bcast(&nPts, 1, MPI_INT, 0, comm);
            MPI_Bcast(&nElem, 1, MPI_INT, 0, comm);
        }
        else
        {
            throw runtime_error("loadMesh: Unknown option for input file. Introduced option: " + option);
        }

    }


    void loadMesh_legacyVtk(int &nPts, int &nElem, int nVert ,int*& connec, double*& xNodes, int*& iCreases, string name)
    {

        int nDim = 3;

        ifstream infile(name);
        if(!infile.is_open())
        {
            throw runtime_error("loadMesh_legacyVtk: The input file (" + name + ") does not exist.\n Please check it and rerun. Goodbye!");
        }



        string line;

        bool loadPoints = false;
        bool loadCells = false;
        bool loadCreases = false;

        while (getline(infile, line))
        {

            if (line.empty())
                continue;

            if (line.find_first_not_of(' ') == string::npos)
                continue;

            std::istringstream iss(line);

            vector<string> tokens{istream_iterator<string>{iss},
                        istream_iterator<string>{}};

            if (tokens[0] == "POINTS")
            {
                nPts = stoi(tokens[1]);
                fillArrayData<double>(xNodes, infile, nPts*nDim);
                loadPoints = true;
                continue;
            }
            if (tokens[0] == "POLYGONS" || tokens[0] ==  "CELLS")
            {
                nElem = stoi(tokens[1]);
                int total = stoi(tokens[2]);
                if (total / nElem != (nVert + 1))
                    throw runtime_error("legacyVtkIn: Only triangles have been implemented. Please check that.");

                fillArrayData<int>(connec, infile, nElem, nVert+1, 1);
                loadCells = true;
                continue;
            }

            if (tokens[0] == "CreasesId")
            {
                int loc_nPts = stoi(tokens[2]);

                int *tempCreases;

                fillArrayData<int>(tempCreases, infile, loc_nPts);

                // FIXME This will change if we change _nCreases
                iCreases = new int[loc_nPts * 2];
                for (int i = 0; i < loc_nPts; i++)
                {
                    iCreases[2*i + 0] = tempCreases[i];
                    iCreases[2*i + 1] = 0;
                }

                loadCreases = true;
                delete [] tempCreases;

                continue;
            }


        }


        if(!loadCells || !loadPoints)
        {
            throw runtime_error("legacyVtkIn: There was a problem loading the mesh information.");
        }



        if (loadCreases == false)
        {
            iCreases = new int[2*nPts];
            for (int i = 0; i < 2*nPts; i++)
                iCreases[i] = 0;
        }

    }


}
