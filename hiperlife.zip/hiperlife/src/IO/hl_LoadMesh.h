/*
    *******************************************************************************
    Copyright (c) 2017-2023 Team hiperlife
    Authors: Daniel Santos-Oliván, Alejandro Torres-Sánchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife
    Project homepage: https://hiperlife.gitlab.io/hiperlife
    Distributed under the GNU General Public License, see the accompanying
    file LICENSE or https://opensource.org/license/gpl-3-0.
    *******************************************************************************
*/


#ifndef LOADMESH_H
#define LOADMESH_H

#include <string>


namespace hiperlife
{
    void loadMesh_legacyVtk(int& nPts, int& nElem, int nVert, int*& connec, double*& xNodes, int*& iCreases, std::string name);

    void loadMesh(int& nPts, int& nElem, int nVert, int*& connec, double*& xNodes, int*& iCreases, std::string name, std::string option);
}

#endif // LOADMESH_H
