<div align="right">
Version 5.0.0-beta - [Changelog](./CHANGELOG.md)
</div>

<div align="center">
![hiperlife logo](doc/img/logo_wtitle_white.svg "hiperlife")
</div>

<br>

hiperlife is a high performance parallel library for finite elements. The aim of this library is to provide a computational framework to address problems of cell and tissue mechanobiology for a wide range of cases and users, with special focus on curved surfaces (the cell membrane, the cell cortex, epithelial monolayers,etc.). It is designed to handle the multiphysic nature of problems in mechanobiology, to manage unstructured grids that deal with complex geometries and to allow arbitrary higher-order basis functions that describe the curvature of interfaces.

hiperlife is written in C++, uses the Message Passage Interface (MPI) paradigm for parallelism, and is built on top of several packages of [the Trilinos Project](https://trilinos.org/). These particular choices set the basis for the main features of the library, namely, parallelism, flexibility, user-centered design and sustainability.
<!--
- **Parallelism:** hiperlife was designed to take advantage of different computer architectures. It can be installed and executed in personal workstations, which may be enough for some studies. However, because hiperlife uses MPI, we can go beyond the computational power of a single workstation exploiting the parallel architecture of computer clusters and drastically reducing the computational times to reasonable periods for large systems. The parallel distribution of the data for the simulations in the library is done in a transparent way so that the user can seamlessly change between architectures.
- **Flexibility:** As the computational algorithms change from problem to problem, we have built the library in a modular way to be able to handle these differences. These modules can be combined in many different ways. These combinations increase the flexibility of hiperlife in such a way that, although it has been designed for fluid interfaces in biological systems, its intrinsic flexibility provides the potential to easily extend it to address problems from other fields, such as computational fluid dynamics, immersed methods or fluid-structure interaction.
- **User-centered design:** Potential users of hiperlife can have different programming expertise, modeling needs, and backgrounds. hiperlife includes a graphical user interface (GUI) that allows users with no programming knowledge to implement applications from a high-level perspective. At the same time, advanced users have fine-grain control of all the algorithms. The library includes documentation and a diverse set of tutorials with increasing complexity.
- **Sustainability:** We have designed hiperlife to be developed, maintained and extended by the community of users. This system grants full control to develop, review, test and distribute the library. In addition, the modularity of hiperlife allows us to easily extend and add new features with minimal knowledge of its structure.
-->

## Documentation
The documentation of hiperlife can be found at [here](https://hiperlife.gitlab.io/hiperlife).

## Installation
The installation instructions can be found in [INSTALL.md](./INSTALL.md) as well as in the [documentation](https://hiperlife.gitlab.io/hiperlife/Installation).

In summary, after you have downloaded or cloned the library in `/path/to/hiperlife`, you can configure, build and install the hiperlife with:

```bash
cd </path/to/hiperlife>
mkdir build
cd build
cmake -DCMAKE_INSTALL_PREFIX=</path/to/install/hiperlife> ..
make -j<X> dependencies
cmake ..
make -j<X> install
```
where you have to replace `<path/to/..>` with the corresponding paths and `<X>` with the number of processors you want to use to build the library.

## Build your own application
To build your C++ application with hiperlife you can create a new project following [these instructions](https://hiperlife.gitlab.io/hiperlife/QuickStart/) in the repository [hl-base-project](https://gitlab.com/hiperlife/hl-base-project).

## Contributing
You can contribute to hiperlife in many ways, from suggesting a new feature or posing a question, to reporting a bug, solving an issue or implementing a new feature! Please, see the [contributing guidelines](./CONTRIBUTING.md) to see how to do it.

## License
See the [LICENSE](./LICENSE) file for details.

## Authors
hiperlife has been created as a group effort. See the [authors](./AUTHORS) file for details.

<!--
## TODO list and roadmap
You
-->

## Contact and further information
All questions, suggestions, bugs, etc, are now handled through GitLab. Please, take a look at [Contributing](#Contributing) to learn how.

**Contact:** [hiperlife@proton.me](mailto:hiperlife@proton.me)

Further information can be found at https://hiperlife.gitlab.io/hiperlife.
