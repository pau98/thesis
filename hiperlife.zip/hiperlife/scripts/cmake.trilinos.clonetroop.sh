#!/bin/bash

#############################################################
##  Set paths
#############################################################

## Load mumps (it already includes openblas scalapack metis/5.1.0 parmetis/4.0.3 ptscotch/6.0.9)
module load mumps/5.3.0

## Set installation path
INSTALL="$HOME/local/trilinos"

## Output info
echo $MUMPS_LIB
echo $MUMPS_INC
echo $PTSCOTCH_INC
echo $PTSCOTCH_LIB
echo $INCLUDE
echo $LD_LIBRARY_PATH
module ls

#############################################################
##  Configure
#############################################################

## Move to the build directory and delete
# rm -rf I <path/to/trilinos>/build/*
# cd <path/to/trilinos>/build

## Configure
cmake \
    -D BUILD_SHARED_LIBS:BOOL=YES                                \
    -D CMAKE_EXE_LINKER_FLAGS:STRING="-fPIC -lbz2"               \
    -D CMAKE_INSTALL_PREFIX=$INSTALL                             \
    -D CMAKE_C_FLAGS="-O3 -march=skylake-avx512 "                \
    -D CMAKE_CXX_FLAGS="-O3 -march=skylake-avx512"               \
    -D CMAKE_FORTRAN_FLAGS="-O3 -march=skylake-avx512"           \
    -D CMAKE_BUILD_TYPE:STRING=RELEASE                           \
    -D CMAKE_SKIP_INSTALL_RPATH:BOOL=ON                          \
    -D CMAKE_SKIP_RPATH:BOOL=ON                                  \
    -D TPL_ENABLE_MPI:BOOL=YES                                   \
    -D MPI_C_COMPILER:FILEPATH=mpicc                             \
    -D MPI_CXX_COMPILER:FILEPATH=mpicxx                          \
    -D MPI_FORTRAN_COMPILER:FILEPATH=mpif90                      \
    -D Trilinos_ENABLE_OpenMP:BOOL=OFF                           \
    -D Trilinos_ENABLE_ALL_PACKAGES=ON                           \
    -D Trilinos_ENABLE_TESTS=OFF                                 \
    \
    -D TPL_ENABLE_BLAS:BOOL=ON                                   \
    -D BLAS_LIBRARY_DIRS:PATH="${OPENBLAS_LIB}"                  \
    -D BLAS_LIBRARY_NAMES:STRING="openblas"                      \
    \
    -D TPL_ENABLE_LAPACK:BOOL=ON                                 \
    -D LAPACK_LIBRARY_DIRS:PATH="${OPENBLAS_LIB}"                \
    -D LAPACK_LIBRARY_NAMES:STRING="openblas"                    \
    \
    -D TPL_ENABLE_METIS:BOOL=YES                                 \
    -D METIS_LIBRARY_DIRS:PATH="${METIS_LIB}"                    \
    \
    -D TPL_ENABLE_ParMETIS:BOOL=YES                              \
    -D ParMETIS_LIBRARY_DIRS:PATH="${PARMETIS_LIB};${METIS_LIB}" \
    \
    -D TPL_ENABLE_Scotch:BOOL=YES                                \
    -D Scotch_LIBRARY_DIRS:PATH="${PTSCOTCH_LIB}"                \
    \
    -D TPL_ENABLE_MUMPS:BOOL=YES                                 \
    -D MUMPS_LIBRARY_NAMES='dmumps;mumps_common;scalapack;lapack;pord;metis;parmetis;scotch;scotcherr;ptscotch;ptscotcherr;ptesmumps' \
    -D MUMPS_LIBRARY_DIRS="${MUMPS_LIB};${SCALAPACK_LIB};${METIS_LIB};${PARMETIS_LIB};${PTSCOTCH_LIB};/opt/ohpc/pub/libs/gnu7/openmpi3/;/usr/lib64/openmpi/lib/" \
    -D Amesos2_ENABLE_MUMPS:BOOL=YES                             \
    \
    -D TPL_ENABLE_Netcdf=OFF \
    -D TPL_ENABLE_Boost=OFF \
    -D Trilinos_ENABLE_Panzer=OFF \
    -D Trilinos_ENABLE_Teko=OFF \
    -D Trilinos_ENABLE_ML=OFF \
    -D Trilinos_ENABLE_Pliris=OFF \
    -D Trilinos_ENABLE_Komplex=OFF \
    -D Trilinos_ENABLE_NOX=OFF \
    -D Trilinos_ENABLE_LOCA=OFF \
    -D Trilinos_ENABLE_ROL=OFF \
    -D Trilinos_ENABLE_MOOCHO=OFF \
    -D Trilinos_ENABLE_Piro=OFF \
    -D Trilinos_ENABLE_Rythmos=OFF \
    -D Trilinos_ENABLE_TriKota=OFF \
    -D Trilinos_ENABLE_OptiPack=OFF \
    -D Trilinos_ENABLE_GlobiPack=OFF \
    -D Trilinos_ENABLE_Anasazi=OFF \
    -D Trilinos_ENABLE_Sacado=OFF \
    -D Trilinos_ENABLE_Stokhos=OFF \
    -D Trilinos_ENABLE_Claps=OFF \
    -D Trilinos_ENABLE_Moertel=OFF \
    -D Trilinos_ENABLE_PyTrilinos=OFF \
    -D Trilinos_ENABLE_ForTrilinos=OFF \
    -D Trilinos_ENABLE_WebTrilinos=OFF \
    -D Trilinos_ENABLE_Stratimikos=OFF \
    -D Trilinos_ENABLE_FEI=OFF \
    -D Trilinos_ENABLE_Mesquite=OFF \
    -D Trilinos_ENABLE_PAMGEN=OFF \
    -D Trilinos_ENABLE_Intrepid=OFF \
    -D Trilinos_ENABLE_Intrepid2=OFF \
    -D Trilinos_ENABLE_STK=OFF \
    -D Trilinos_ENABLE_Galeri=OFF \
    -D Trilinos_ENABLE_Optika=OFF \
    -D Trilinos_ENABLE_SEACAS=OFF \
    -D Trilinos_ENABLE_Phalanx=OFF \
    -D Trilinos_ENABLE_Shards=OFF \
    -D Trilinos_ENABLE_Tempus=OFF \
    -D Trilinos_ENABLE_MueLu=OFF \
    ..
