#!/bin/bash

#############################################################
##  Set paths - Modify to fit to your installation
#############################################################

## Load necessary modules
module load trilinos/12.18-mumps
module load vtk/8.2.0
#module load gmsh/4.5.5
module ls

## Set installation path
INSTALL_PATH=/opt/ohpc/pub/libs/gnu7/openmpi3/hiperlife/devel # <- Modify


#############################################################
##  Configure
#############################################################

## Move to the build directory and delete
# rm -rf -I <path/to/hiperlife>/build/* # <------------------ Modify
# cd <path/to/hiperlife>/build # <--------------------------- Modify

## Configure
cmake \
    -D CMAKE_INSTALL_PREFIX=$INSTALL_PATH           \
    -D CMAKE_EXE_LINKER_FLAGS:STRING="-lbz2"        \
    -D CMAKE_C_FLAGS="-march=native -O3"            \
    -D CMAKE_CXX_FLAGS="-march=native -O3"          \
    -D MPI_BASE_PATH=$MPI_DIR                       \
    -D TRI_BASE_PATH=$TRILINOS_DIR                  \
    -D VTK_BASE_PATH=$VTK_DIR                       \
    -D GMSH_BASE_PATH=$GMSH_DIR                     \
    -D CMAKE_BUILD_TYPE=Release                     \
    -D COMPILE_TESTS=ON                             \
    -D COMPILE_TUTORIALS=OFF                        \
    -D COMPILE_GUI=OFF                              \
    -D EXTRAE_PROFILING=OFF                         \
    -D CMAKE_EXPORT_COMPILE_COMMANDS=NO             \
    ..
