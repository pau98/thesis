#!/bin/bash

#############################################################
##  Set paths - Modify to fit to your installation
#############################################################

## Load necessary modules
module purge
# module load gcc EXTRAE # <--------------------------------- Modify
# module unload gcc # <-------------------------------------- Modify
module load cmake/3.15.4 intel impi mkl
module load python/2.7.13 boost/1.64.0_py2 vtk/8.2.0
module load mumps/5.3.3
module load trilinos/12.18.1
module ls

## Set path
TRI_DIR=/apps/TRILINOS/12.18.1/INTEL/IMPI/
SCOTCH_DIR=/apps/SCOTCH/6.0.4-64bits/INTEL/IMPI/
EXTRAE_DIR=$EXTRAE_HOME

## Set installation path
INSTALL_PATH=$HOME/local/hiperlife # <----------------------- Modify


#############################################################
##  Configure
#############################################################

## Move to the build directory and delete
# rm -rf -I <path/to/hiperlife>/build/* # <------------------ Modify
# cd <path/to/hiperlife>/build # <--------------------------- Modify

## Configure
cmake \
    -D CMAKE_INSTALL_PREFIX=$INSTALL_PATH \
    -D BUILD_SHARED_LIBS=OFF \
    -D CMAKE_C_COMPILER=mpiicc                      \
    -D CMAKE_CXX_COMPILER=mpiicpc                   \
    -D CMAKE_EXE_LINKER_FLAGS:STRING="-lbz2 -L$MKLROOT -lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core -lmkl_scalapack_lp64 -lmkl_blacs_intelmpi_lp64"     \
    -D CMAKE_C_FLAGS="-march=native -O3"            \
    -D CMAKE_CXX_FLAGS="-march=native -O3"          \    
    -D MPI_BASE_PATH=$MPI_ROOT                      \
    -D TRI_BASE_PATH=$TRILINOS_DIR                  \
    -D VTK_BASE_PATH=$VTK_DIR                       \
    -D GMSH_BASE_PATH=$GMSH_DIR                     \
    -D MUMPS_BASE_PATH=$MUMPS                       \
    -D SCOTCH_BASE_PATH=$SCOTCH_DIR                 \
    -D EXTRAE_BASE_PATH=$EXTRAE_DIR                 \
    -D CMAKE_BUILD_TYPE=Release                     \
    -D COMPILE_TESTS=OFF                            \
    -D COMPILE_TUTORIALS=ON                         \
    -D COMPILE_GUI=OFF                              \
    -D EXTRAE_PROFILING=OFF                         \
    -D CMAKE_EXPORT_COMPILE_COMMANDS=NO             \
    ..
