#!/bin/bash

#############################################################
##  Set paths - Modify to fit to your installation
#############################################################

## Set hiperlife source directory 
SRC=./ # <--------------------------------------------------- Modify with <path/to/hiperlife>

## Set main path to libraries installation
LIB_DIR=$HOME/local # <-------------------------------------- Modify

## Set paths
TRILINOS_DIR=$LIB_DIR/trilinos
VTK_DIR=$LIB_DIR/vtk
GMSH_DIR=$LIB_DIR/gmsh

## Set installation path
INSTALL_PATH=$LIB_DIR/hiperlife


#############################################################
##  Configure
#############################################################

## Remove previous installation
if false ; then # <------------------------------------------ Modify (true to remove)
    echo "You are about to remove all the contents of  
     $(cd $INSTALL_PATH/; pwd) \n Please, check that 
     the path is correct (y/n)."
    rm -rf $INSTALL_PATH/* 
fi

## Remove previous compilation
mkdir $SRC/build
if false ; then # <------------------------------------------ Modify (true to remove)
    echo "You are about to remove all the contents of 
     $(cd $SRC/build/; pwd) \n Please, check that the 
      path is correct (y/n)."                         
    rm -rf -I $SRC/build/* 
fi

## Move to build directory
cd $SRC/build 

## Configure
cmake \
    -D CMAKE_C_FLAGS="-march=native -O3"   \
    -D CMAKE_CXX_FLAGS="-march=native -O3" \
    -D CMAKE_INSTALL_PREFIX=$INSTALL_PATH  \
    -D TRI_BASE_PATH=$TRILINOS_DIR         \
    -D VTK_BASE_PATH=$VTK_DIR              \
    -D GMSH_BASE_PATH=$GMSH_DIR            \
    -D CMAKE_BUILD_TYPE=Release            \
    -D COMPILE_TESTS=OFF                   \
    -D COMPILE_TUTORIALS=ON                \
    -D COMPILE_GUI=OFF                     \
    ..
