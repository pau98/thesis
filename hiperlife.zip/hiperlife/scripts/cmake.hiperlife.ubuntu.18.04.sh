#!/bin/bash

#############################################################
##  Set paths - Modify to fit to your installation
#############################################################

## Set main path to libraries installation
LIB_DIR=$HOME/local # <-------------------------------------- Modify

## Set paths
MPI_DIR=$LIB_DIR/openmpi
TRILINOS_DIR=$LIB_DIR/trilinos
VTK_DIR=$LIB_DIR/vtk
GMSH_DIR=$LIB_DIR/gmsh

## Set installation path
INSTALL_PATH=$LIB_DIR/hiperlife


#############################################################
##  Configure
#############################################################

## Move to the build directory and delete
# rm -rf -I <path/to/hiperlife>/build/* # <------------------ Modify
# cd <path/to/hiperlife>/build # <--------------------------- Modify

## Configure
cmake \
    -D CMAKE_C_FLAGS="-march=native -O3"   \
    -D CMAKE_CXX_FLAGS="-march=native -O3" \
    -D CMAKE_INSTALL_PREFIX=$INSTALL_PATH  \
    -D MPI_BASE_PATH=$MPI_DIR              \
    -D TRI_BASE_PATH=$TRILINOS_DIR         \
    -D VTK_BASE_PATH=$VTK_DIR              \
    -D GMSH_BASE_PATH=$GMSH_DIR            \
    -D CMAKE_BUILD_TYPE=Release            \
    -D COMPILE_TESTS=OFF                   \
    -D COMPILE_TUTORIALS=ON                \
    -D COMPILE_GUI=OFF                     \
    ..
