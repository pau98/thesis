#!/bin/bash

#############################################################
##  Set paths - Modify to fit to your installation
#############################################################

## Set hiperlife source directory
SRC=./ # <--------------------------------------------------- Modify

## Load necessary modules
module load CMake
module load Trilinos/13.4-mumps
module load VTK/9.1.0-foss-2021b
#module load gmsh/4.5.5
module load Boost/1.79.0-GCC-11.2.0
module ls

## Set installation path
INSTALL_PATH=$HOME/local/trilinos # <------------------------ Modify


#############################################################
##  Configure
#############################################################

## Move to the build directory and delete
mkdir $SRC/build
echo "You are about to remove all the contents of
 $(cd $SRC/build/; pwd) \n Please, check that the path is correct."
rm -rf -I $SRC/build/*
cd $SRC/build

## Configure
cmake \
    -D CMAKE_INSTALL_PREFIX=$INSTALL_PATH           \
    -D CMAKE_EXE_LINKER_FLAGS:STRING="-lbz2"        \
    -D CMAKE_CXX_COMPILER:STRING="mpicxx"           \
    -D CMAKE_C_COMPILER:STRING="mpicc"              \
    -D CMAKE_C_FLAGS:STRING="-O3 -march=native"     \
    -D CMAKE_CXX_FLAGS:STRING="-O3 -march=native -std=c++14"   \
    -D MPI_BASE_PATH=${EBROOTOPENMPI}               \
    -D TRI_BASE_PATH=${EBROOTTRILINOS}              \
    -D VTK_BASE_PATH=${EBROOTVTK}                   \
    -D GMSH_BASE_PATH=$GMSH_DIR                     \
    -D CMAKE_BUILD_TYPE=Release                     \
    -D COMPILE_TESTS=ON                             \
    -D COMPILE_TUTORIALS=OFF                        \
    -D COMPILE_GUI=OFF                              \
    -D EXTRAE_PROFILING=OFF                         \
    -D CMAKE_EXPORT_COMPILE_COMMANDS=YES            \
    ..
