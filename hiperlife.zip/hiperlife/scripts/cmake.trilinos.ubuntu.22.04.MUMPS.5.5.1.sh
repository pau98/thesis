#!/bin/bash

#############################################################
##  Install requirements and optional dependencies
#############################################################
# sudo apt install cmake git g++ gfortran libblas-dev liblapack-dev libopenmpi-dev libscalapack-mpi-dev libparmetis-dev libscotch-dev libptscotch-dev


#############################################################
##  Set paths
#############################################################

## Set trilinos source directory
SRC=./ # <--------------------------------------------------- Modify with <path/to/trilinos>

## Set gfortran path
GFORTRAN_LIB=/usr/lib/gcc/x86_64-linux-gnu/11/ # <----------- Modify version number (9 -> ?)

## Set pt-scotch path
PTSCOTCH_INC=/usr/include/scotch
PTSCOTCH_LIB=/usr/lib
export INCLUDE=$PTSCOTCH_INC:$INCLUDE
export LD_LIBRARY_PATH=$PTSCOTCH_LIB:$LD_LIBRARY_PATH

## Set MUMPS path
MUMPS_DIR=$HOME/local/mumps # <------------------------------ Modify
MUMPS_LIB="$MUMPS_DIR/lib"
MUMPS_INC="$MUMPS_DIR/include"
export INCLUDE=$MUMPS_INC:$INCLUDE
export LD_LIBRARY_PATH=$MUMPS_LIB:$LD_LIBRARY_PATH

## Set installation path
INSTALL_PATH=$HOME/local/trilinos # <------------------------ Modify


#############################################################
##  Configure
#############################################################

## Remove previous installation
if true ; then # <------------------------------------------- Modify (true to remove)
    echo "You are about to remove all the contents of
     $(cd $INSTALL_PATH/; pwd) \n Please, check that
     the path is correct (y/n)."
    echo "$INSTALL_PATH"
    rm -rf -I $INSTALL_PATH/*
fi

## Remove previous compilation
mkdir $SRC/build
if true ; then # <------------------------------------------- Modify (true to remove)
    echo "You are about to remove all the contents of
     $(cd $SRC/build/; pwd) \n Please, check that the
      path is correct (y/n)."
    rm -rf -I $SRC/build/*
fi

## Move to build directory
cd $SRC/build

## Configure
cmake \
    -D BUILD_SHARED_LIBS:BOOL=YES                      \
    -D CMAKE_INSTALL_PREFIX=$INSTALL_PATH              \
    -D CMAKE_BUILD_TYPE:STRING=RELEASE                 \
    -D CMAKE_C_FLAGS="-march=native -O3"               \
    -D CMAKE_CXX_FLAGS="-march=native -O3"             \
    -D CMAKE_FORTRAN_FLAGS="-march=native -O3"         \
    -D TPL_ENABLE_MPI=ON                               \
    -D MPI_BASE_DIR=$MPI_DIR                           \
    -D MPI_C_COMPILER:FILEPATH=mpicc                   \
    -D MPI_CXX_COMPILER:FILEPATH=mpicxx                \
    -D MPI_FORTRAN_COMPILER:FILEPATH=mpif90            \
    -D Trilinos_ENABLE_OpenMP:BOOL=OFF                 \
    -D Trilinos_ENABLE_TESTS=OFF                       \
    \
    -D Trilinos_ENABLE_Epetra:BOOL=YES    \
    -D Trilinos_ENABLE_Isorropia:BOOL=YES \
    -D Trilinos_ENABLE_Amesos:BOOL=YES    \
    -D Trilinos_ENABLE_AztecOO:BOOL=YES   \
    -D Trilinos_ENABLE_Belos:BOOL=YES     \
    \
    -D TPL_ENABLE_BLAS:BOOL=ON                         \
    -D TPL_ENABLE_LAPACK:BOOL=ON                       \
    -D TPL_ENABLE_METIS:BOOL=YES                       \
    -D TPL_ENABLE_ParMETIS:BOOL=YES                    \
    -D TPL_ENABLE_Scotch:BOOL=YES                      \
    -D Scotch_LIBRARY_DIRS:PATH="${PTSCOTCH_LIB}"      \
    -D TPL_ENABLE_MUMPS:BOOL=YES                       \
    \
    -D Trilinos_ENABLE_Amesos2:BOOL=YES   \
    -D Amesos2_ENABLE_MUMPS:BOOL=YES      \
    -D Amesos2_ENABLE_TESTS:BOOL=YES      \
    -D TPL_ENABLE_MUMPS:BOOL=YES          \
    -D MUMPS_LIBRARY_NAMES='dmumps;mumps_common;lapack;scalapack-openmpi;pord;metis;parmetis;scotch;scotcherr;ptscotch;ptscotcherr;ptesmumps;mpi;mpi_mpifh;gfortran' \
    -D MUMPS_LIBRARY_DIRS="${GFORTRAN_LIB};${MUMPS_LIB};${METIS_LIB};${PARMETIS_LIB};${PTSCOTCH_LIB}" \
    -D Tpetra_INST_INT_INT=ON             \
    \
    -D TPL_ENABLE_Netcdf=OFF              \
    -D Trilinos_ENABLE_PyTrilinos=OFF     \
    -D Trilinos_ENABLE_STK:BOOL=OFF       \
    ..
