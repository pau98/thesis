#!/bin/bash

#############################################################
##  Install requirements and optional dependencies
#############################################################
# sudo apt install cmake git g++ gfortran libblas-dev liblapack-dev libopenmpi-dev libscalapack-mpi-dev libparmetis-dev libscotch-dev libptscotch-dev libblacs-mpi-dev libmumps-ptscotch-dev

#############################################################
##  Set paths -> Modify MPI_DIR and INSTALL_PATH
#############################################################

## Set MPI path
MPI_DIR=$HOME/local/openmpi # <------------------------------ Modify
MPI_LIB="$MPI_DIR/lib"
MPI_INC="$MPI_DIR/include"
export INCLUDE=$MPI_INC:$INCLUDE
export LD_LIBRARY_PATH=$MPI_LIB:$LD_LIBRARY_PATH

## Set installation path
INSTALL_PATH=$HOME/local/trilinos # <------------------------ Modify


#############################################################
##  Configure
#############################################################

## Move to the build directory and delete
# rm -rf -I <path/to/trilinos>/build/* # <------------------- Modify
# cd <path/to/trilinos>/build # <---------------------------- Modify

## Configure
cmake \
    -D BUILD_SHARED_LIBS:BOOL=YES                      \
    -D CMAKE_INSTALL_PREFIX=$INSTALL_PATH              \
    -D CMAKE_BUILD_TYPE:STRING=RELEASE                 \
    -D CMAKE_C_FLAGS="-march=native -O3"               \
    -D CMAKE_CXX_FLAGS="-march=native -O3"             \
    -D CMAKE_FORTRAN_FLAGS="-march=native -O3"         \
    -D TPL_ENABLE_MPI=ON                               \
    -D MPI_BASE_DIR=$MPI_DIR                           \
    -D MPI_C_COMPILER:FILEPATH=mpicc                   \
    -D MPI_CXX_COMPILER:FILEPATH=mpicxx                \
    -D MPI_FORTRAN_COMPILER:FILEPATH=mpif90            \
    -D Trilinos_ENABLE_OpenMP:BOOL=OFF                 \
    -D Trilinos_ENABLE_ALL_PACKAGES=ON                 \
    -D Trilinos_ENABLE_TESTS=OFF                       \
    \
    -D TPL_ENABLE_METIS:BOOL=YES                       \
    -D TPL_ENABLE_ParMETIS:BOOL=YES                    \
    -D TPL_ENABLE_Scotch:BOOL=YES                      \
    -D Scotch_LIBRARY_DIRS:PATH="/usr/include/scotch/" \
    -D TPL_ENABLE_MUMPS:BOOL=YES                       \
    -D MUMPS_LIBRARY_NAMES='dmumps_ptscotch;mumps_common_ptscotch;lapack;scalapack-openmpi;metis;parmetis;ptscotch;scotch;scotcherr;ptesmumps;esmumps;pord;'\
    \
    -D Amesos2_ENABLE_MUMPS:BOOL=YES                   \
    \
    -D TPL_ENABLE_Netcdf=OFF                           \
    -D TPL_ENABLE_Boost=OFF                            \
    -D Trilinos_ENABLE_Panzer=OFF                      \
    -D Trilinos_ENABLE_Teko=OFF                        \
    -D Trilinos_ENABLE_ML=OFF                          \
    -D Trilinos_ENABLE_Pliris=OFF                      \
    -D Trilinos_ENABLE_Komplex=OFF                     \
    -D Trilinos_ENABLE_NOX=OFF                         \
    -D Trilinos_ENABLE_LOCA=OFF                        \
    -D Trilinos_ENABLE_ROL=OFF                         \
    -D Trilinos_ENABLE_MOOCHO=OFF                      \
    -D Trilinos_ENABLE_Piro=OFF                        \
    -D Trilinos_ENABLE_Rythmos=OFF                     \
    -D Trilinos_ENABLE_TriKota=OFF                     \
    -D Trilinos_ENABLE_OptiPack=OFF                    \
    -D Trilinos_ENABLE_GlobiPack=OFF                   \
    -D Trilinos_ENABLE_Anasazi=OFF                     \
    -D Trilinos_ENABLE_Sacado=OFF                      \
    -D Trilinos_ENABLE_Stokhos=OFF                     \
    -D Trilinos_ENABLE_Claps=OFF                       \
    -D Trilinos_ENABLE_Moertel=OFF                     \
    -D Trilinos_ENABLE_PyTrilinos=OFF                  \
    -D Trilinos_ENABLE_ForTrilinos=OFF                 \
    -D Trilinos_ENABLE_WebTrilinos=OFF                 \
    -D Trilinos_ENABLE_Stratimikos=OFF                 \
    -D Trilinos_ENABLE_FEI=OFF                         \
    -D Trilinos_ENABLE_Mesquite=OFF                    \
    -D Trilinos_ENABLE_PAMGEN=OFF                      \
    -D Trilinos_ENABLE_Intrepid=OFF                    \
    -D Trilinos_ENABLE_Intrepid2=OFF                   \
    -D Trilinos_ENABLE_STK=OFF                         \
    -D Trilinos_ENABLE_Galeri=OFF                      \
    -D Trilinos_ENABLE_Optika=OFF                      \
    -D Trilinos_ENABLE_SEACAS=OFF                      \
    -D Trilinos_ENABLE_Phalanx=OFF                     \
    -D Trilinos_ENABLE_Shards=OFF                      \
    -D Trilinos_ENABLE_Tempus=OFF                      \
    -D Trilinos_ENABLE_MueLu=OFF                       \
    ..
