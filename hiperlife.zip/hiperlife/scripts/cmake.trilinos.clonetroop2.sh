#!/bin/bash

#############################################################
##  Set paths
#############################################################

## Load mumps (includes metis, parmetis, scotch, ptscotch, scalapack, flexiblas)
module load CMake
module load MUMPS/5.5.1

## Set installation path
INSTALL="$HOME/local/trilinos"

## Output info
module ls

#############################################################
##  Configure
#############################################################

## Move to the build directory and delete
# rm -rf I <path/to/trilinos>/build/*
# cd <path/to/trilinos>/build

## Configure
cmake \
     -D BUILD_SHARED_LIBS:BOOL=YES                                \
     -D CMAKE_EXE_LINKER_FLAGS:STRING="-fPIC -lbz2"               \
     -D CMAKE_INSTALL_PREFIX=$INSTALL                             \
     -D CMAKE_C_FLAGS="-O3 -march=native"                         \
     -D CMAKE_CXX_FLAGS="-O3 -march=native -std=c++14"            \
     -D CMAKE_FORTRAN_FLAGS="-O3 -march=native"                   \
     -D CMAKE_BUILD_TYPE:STRING=RELEASE                           \
     -D BUILD_SHARED_LIBS=ON                                      \
     -D CMAKE_SKIP_INSTALL_RPATH:BOOL=ON                          \
     -D CMAKE_SKIP_RPATH:BOOL=ON                                  \
     -D TPL_ENABLE_MPI:BOOL=YES                                   \
     -D MPI_BASE_DIR="${EBROOTOPENMPI}"                           \
     -DMPI_C_COMPILER:FILEPATH=mpicc                              \
     -DMPI_CXX_COMPILER:FILEPATH=mpicxx                           \
     -DMPI_FORTRAN_COMPILER:FILEPATH=mpif90                       \
     -D Trilinos_ENABLE_OpenMP:BOOL=OFF                           \
     -D Trilinos_ENABLE_TESTS=OFF                                 \
     \
     -D Trilinos_ENABLE_Epetra:BOOL=YES    \
     -D Trilinos_ENABLE_Isorropia:BOOL=YES \
     -D Trilinos_ENABLE_Amesos:BOOL=YES    \
     -D Trilinos_ENABLE_AztecOO:BOOL=YES   \
     -D Trilinos_ENABLE_Belos:BOOL=YES     \
     \
     -D Trilinos_ENABLE_Amesos2:BOOL=YES   \
     -D Amesos2_ENABLE_MUMPS:BOOL=YES      \
     -D Amesos2_ENABLE_TESTS:BOOL=YES      \
     -D TPL_ENABLE_MUMPS:BOOL=YES          \
     -DMUMPS_LIBRARY_NAMES='dmumps;mumps_common;scalapack;flexiblas;pord;metis;parmetis;scotch;scotcherr;ptscotch;ptscotcherr;ptesmumps;mpi;gfortran;mpi_usempif08;mpi_mpifh;mpi_usempi_ignore_tkr' \
     -DMUMPS_LIBRARY_DIRS="${EBROOTMUMPS};${EBROOTSCALAPACK};${EBROOTMETIS};${EBROOTPARMETIS};${EBROOTSCOTCH};${EBROOTOPENMPI};${EBROOTFLEXIBLAS};" \
     -D Tpetra_INST_INT_INT=ON             \
     \
     -D TPL_ENABLE_Netcdf=OFF              \
     -D Trilinos_ENABLE_PyTrilinos=OFF     \
     -D Trilinos_ENABLE_STK:BOOL=OFF       \
     \
     -D TPL_ENABLE_BLAS:BOOL=ON                                      \
     -D BLAS_LIBRARY_DIRS:PATH="${EBROOTFLEXIBLAS}"                  \
     -D BLAS_LIBRARY_NAMES:STRING="flexiblas"                        \
     \
     -D TPL_ENABLE_LAPACK:BOOL=ON                                    \
     -D LAPACK_LIBRARY_DIRS:PATH="${EBROOTFLEXIBLAS}"                \
     -D LAPACK_LIBRARY_NAMES:STRING="flexiblas"                      \
     \
     -DTPL_ENABLE_METIS:BOOL=YES                                     \
     -DMETIS_LIBRARY_DIRS:PATH="${EBROOTMETIS}"                      \
     \
     -DTPL_ENABLE_Scotch:BOOL=YES                                    \
     -DScotch_LIBRARY_DIRS:PATH="${EBROOTSCOTCH}"                    \
     \
     -DTPL_ENABLE_ParMETIS:BOOL=YES                                  \
     -DParMETIS_LIBRARY_DIRS:PATH="${EBROOTPARMETIS};${EBROOTMETIS}" \
     ..
