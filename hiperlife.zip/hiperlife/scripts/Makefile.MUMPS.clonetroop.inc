#
#  This file is part of MUMPS 5.0.0, released
#  on Fri Feb 20 08:19:56 UTC 2015
#
#Begin orderings

# NOTE that PORD is distributed within MUMPS by default. If you would like to
# use other orderings, you need to obtain the corresponding package and modify
# the variables below accordingly.
# For example, to have Metis available within MUMPS:
#          1/ download Metis and compile it
#          2/ uncomment (suppress # in first column) lines
#             starting with LMETISDIR,  LMETIS
#          3/ add -Dmetis in line ORDERINGSF
#             ORDERINGSF  = -Dpord -Dmetis
#          4/ Compile and install MUMPS
#             make clean; make   (to clean up previous installation)
#
#          Metis/ParMetis and SCOTCH/PT-SCOTCH (ver 6.0 and later) orderings are now available for MUMPS.
#

#SCOTCHDIR  = ${HOME}/.local/ptscotch
SCOTCHDIR  = ${PTSCOTCH_DIR}
ISCOTCH    = -I$(SCOTCHDIR)/include  # Should be provided for pt-scotch (not needed for Scotch)
#ISCOTCH    = -I${SCOTCH_INC} -I/usr/lib64
#ISCOTCH    = -I${PTSCOTCH_INC}
#
# You have to choose one among the following two lines depending on
# the type of analysis you want to perform. If you want to perform only
# sequential analysis choose the first (remember to add -Dscotch in the ORDERINGSF
# variable below); for both parallel and sequential analysis choose the second
# line (remember to add -Dptscotch in the ORDERINGSF variable below)

#LSCOTCH    = -L$(SCOTCHDIR)/lib -lesmumps -lscotch -lscotcherr
#LSCOTCH    = -L$(SCOTCHDIR)/lib -lptesmumps -lptscotch -lptscotcherr -lscotch
#LSCOTCH    = -L/usr/lib64 -L${SCOTCH_LIB} -lesmumps -lscotch -lscotcherr
#LSCOTCH    = -L${PTSCOTCH_LIB} -lptesmumps -lptscotch -lptscotcherr
LSCOTCH    = -L$(SCOTCHDIR)/lib -lptesmumps -lptscotch -lptscotcherr -lscotch

LPORDDIR = $(topdir)/PORD/lib/
IPORD    = -I$(topdir)/PORD/include/
LPORD    = -L$(LPORDDIR) -lpord

# LMETISDIR = $(METIS_DIR) #/local/metis/
# IMETIS    = $(PARMETIS_LIB) # should be provided if you use parmetis, to access parmetis.h
LMETISDIR = ${METIS_LIB} -L${PARMETIS_LIB} #/opt/metis-5.1.0/build/Linux-x86_64/libmetis
IMETIS    = -I${METIS_INC} -I${PARMETIS_INC} #/opt/metis-5.1.0/include

# You have to choose one among the following two lines depending on
# the type of analysis you want to perform. If you want to perform only
# sequential analysis choose the first (remember to add -Dmetis in the ORDERINGSF
# variable below); for both parallel and sequential analysis choose the second
# line (remember to add -Dparmetis in the ORDERINGSF variable below)

#LMETIS    = -L$(LMETISDIR) -lmetis
LMETIS    = -L$(LMETISDIR) -lparmetis -lmetis

# The following variables will be used in the compilation process.
# Please note that -Dptscotch and -Dparmetis imply -Dscotch and -Dmetis respectively.
#ORDERINGSF = -Dscotch -Dmetis -Dpord -Dptscotch -Dparmetis
#ORDERINGSF  = -Dpord
#ORDERINGSF = -Dmetis -Dpord -Dparmetis
#ORDERINGSF = -Dscotch -Dmetis -Dpord -Dparmetis
#ORDERINGSF = -Dscotch -Dmetis -Dpord -Dptscotch -Dparmetis
ORDERINGSF = -Dpord -Dptscotch -Dparmetis
ORDERINGSC  = $(ORDERINGSF)

LORDERINGS = $(LMETIS) $(LPORD) $(LSCOTCH)
IORDERINGSF = $(ISCOTCH)
IORDERINGSC = $(IMETIS) $(IPORD) $(ISCOTCH)

#End orderings
########################################################################
################################################################################

PLAT    =
LIBEXT  = .a
OUTC    = -o #
OUTF    = -o #
RM = /bin/rm -f
CC = mpicc
FC = mpif90
FL = mpif90
AR = ar vr #
RANLIB = ranlib
#RANLIB  = echo
SCALAP  = -L$(SCALAPACK_LIB) -L$(OPENBLAS_LIB) -lscalapack -lopenblas

INCPAR = -I$(MPI_DIR)/include
# LIBPAR = $(SCALAP)  -L/usr/local/lib/ -llamf77mpi -lmpi -llam
LIBPAR = $(SCALAP)  -L$(MPI_DIR)/lib -lmpi_mpifh -lmpi #
#LIBPAR = -lmpi++ -lmpi -ltstdio -ltrillium -largs -lt

INCSEQ = -I$(topdir)/libseq
LIBSEQ  =  -L$(topdir)/libseq -lmpiseq

LIBBLAS = -lopenblas
LIBOTHERS = -lpthread #-lgomp
#Preprocessor defs for calling Fortran from C (-DAdd_ or -DAdd__ or -DUPPER)
CDEFS   = -DAdd_

#Begin Optimized options
#OPTF    = -O  -DALLOW_NON_INIT -nofor_main
#OPTL    = -O -nofor_main
OPTF    = -O3 -march=skylake-avx512 -DALLOW_NON_INIT -fPIC #
OPTL    = -O3 -march=skylake-avx512 -fPIC #
OPTC    = -O3 -march=skylake-avx512 -fPIC #
#End Optimized options
INCS = $(INCPAR)
LIBS = $(LIBPAR)
LIBSEQNEEDED =
