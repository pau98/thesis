Developer's guide
=================

.. warning::
   This document is intended only for local use. It will be overwritten on compilation of the documents.
