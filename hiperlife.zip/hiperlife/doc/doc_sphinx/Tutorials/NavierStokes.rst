Navier-Stokes tutorial
======================
