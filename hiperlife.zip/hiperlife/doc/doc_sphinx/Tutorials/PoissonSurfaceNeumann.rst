.. role:: cpp(code)
   :language: cpp

Poisson Surface Neumann tutorial
================

In this second Chapter we solve again the scalar Poisson equation,
but now we will also apply Neumann boundary conditions, meaning that
two integrations are going to be applied.

.. math:: \Delta u = f,

where :math:`\Delta = \nabla^2 = \nabla \cdot \nabla` is the Laplace
operator. In our problem :math:`u` will be the unknown variables and
:math:`f` a given parameter chosen to be zero for this particular case.

Code before declaring the main function
---------------------------------------

Headers inclusion
~~~~~~~~~~~~~~~~~

The code starts again with the inclusion of headers

.. code-block:: cpp

   // C++ headers
   #include <iostream>
   #include <fstream>

   // hiperlife headers
   #include "hl_Core.h"
   #include "hl_ParamStructure.h"
   #include "hl_Parser.h"
   #include "hl_TypeDefs.h"
   #include "hl_MeshLoader.h"
   #include "hl_StructMeshGenerator.h"
   #include "hl_DistributedMesh.h"
   #include "hl_FillStructure.h"
   #include "hl_DOFsHandler.h"
   #include "hl_HiPerProblem.h"
   #include "hl_SurfLagrParam.h"
   #include "hl_LinearSolver_Iterative_AztecOO.h"

where we use all the headers that have been used in the previous tutorial
plus another one:

-  **hl** :math:`\_`\ **SurfLagrParam.h** defines
   the Lagrangian parameters for the surface.


Parameters declaration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Now the main parameters of the problem are declared,
we again declare the force, but now we also declare the filemesh.

.. code-block:: cpp

    struct PoissonParams
    {
        enum RealParameters
        {
            strength
        };

        enum StringParameters
        {
            filemesh
        };

        HL_PARAMETER_LIST DefaultValues{
                {"filemesh", ""},
                {"strength", 1.0},
        };
    };


Elemental linear functions declaration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Now we declare the functions which fill the elemental linear
system of the problem in the inside of the elements and on the
borders. Despite being declared here, the implementation
takes place at the bottom of the code.

::

   void ElementFilling(hiperlife::FillStructure& fillStr);
   void RHS_Border(hiperlife::FillStructure& fillStr);

Main function
-------------

Everything is implemented inside the main
function.

::

   int main(int argc, char** argv)
   {
       using namespace std;
       using namespace hiperlife;
       \\ ALL CODE
   }

where in ALL CODE we include the rest of the code detailed in this
section.

Initialization
~~~~~~~~~~~~~~

We initialize the MPI execution environment

::

   hiperlife::Init(argc, argv);


We also create the ParamStructure object

::

   SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();


Mesh creation
~~~~~~~~~~~~~

We now generate an structured mesh

::

   SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();
   structMesh->setElemType(ElemType::Triang);
   structMesh->setBasisFuncType(BasisFuncType::Lagrangian);
   structMesh->setBasisFuncOrder(2);
   structMesh->genSquare(4,1.0);

And we also create the distributed mesh object

   ::

    SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
    disMesh->setMesh(mesh);
    disMesh->setBalanceMesh(true);
    disMesh->Update();

DOFsHandler creation
~~~~~~~~~~~~~~~~~~~~

At this point, the DOFHandler is created:

::

   SmartPtr<DOFsHandler> dofHand = Create<DOFsHandler>(disMesh);
   dofHand->setNameTag("dofHand");
   dofHand->setNumDOFs(1);
   dofHand->setNumElemAuxF(1);
   dofHand->Update();

Boundary conditions
^^^^^^^^^^^^^^^^^^^

Here we set the constraints of the problem, in this case we check if
the bool hasBorder is false

::

   if (!disMesh->hasBorder())
   {
       if (disMesh->myRank() == 0)
           dofHand->setConstraint(0, 0, IndexType::Local, 0.0);
   }
   else
   {
       for (int i = 0; i < disMesh->loc_nPts(); i++)
       {
           if (disMesh->nodeCrease(i, IndexType::Local) > 0 and
               disMesh->nodeCoord(i, 1, IndexType::Local) > 0)
               dofHand->setConstraint(0,i,IndexType::Local, 0.0);
       }
   }
       dofHand->UpdateGhosts();


HiPerProblem creation
~~~~~~~~~~~~~~~~~~~~~

We create the hiperproblem

::

   SmartPtr<HiPerProblem> hiperProbl = Create<HiPerProblem>();

We set the ParameterStructure and the DOFsHandlers:

::

   hiperProbl->setParameterStructure(paramStr);
   hiperProbl->setDOFsHandlers({dofHand});

We set the integration in the bulk:

::

    hiperProbl->setIntegration("Integ", {"dofHand"});
    hiperProbl->setCubatureGauss("Integ",3);
    hiperProbl->setElementFillings("Integ", LS);

We also set the integration on the border, which is one of the novelties
of this second tutorial.

::

   hiperProbl->setIntegration("BorderInteg", {"dofHand"});
   hiperProbl->setCubatureBorderGauss("BorderInteg",2,{MAxis::Xmax,MAxis::Ymin});
   hiperProbl->setElementFillings("BorderInteg", nullptr, nullptr, RHS_Border);

And we also integrate the domain border length:

::

   hiperProbl->setGlobalIntegrals({"BorderLength"});

Finally we update the hiperproblem:

::

   hiperProbl->Update();


Set solver
^^^^^^^^^^

Now we set the solver, in this case we are going to use the aztec00 iterative solver

::

   SmartPtr<AztecOOIterativeLinearSolver> solver = Create<AztecOOIterativeLinearSolver>();
   solver->setHiPerProblem(hiperProbl);
   solver->setTolerance(1.E-8);
   solver->setMaxNumIterations(500);
   solver->setSolver(AztecOOIterativeLinearSolver::Solver::Gmres);
   solver->setPreconditioner(AztecOOIterativeLinearSolver::Preconditioner::Neumann);
   solver->setDefaultParameters();
   solver->setVerbosity(AztecOOIterativeLinearSolver::Verbosity::High);
   solver->Update();

And we solve the hiperProbl

::

    solver->solve();
    hiperProbl->UpdateSolution();

The results are printed to a file either in vtk format

::

    dofHand->printFileLegacyVtk("PoissonSurface");

With the global integral

::

   if (dofHand->myRank() == 0)
   cout << std::scientific << std::setprecision(5) << "Border Length = " << hiperProbl->globalIntegral("BorderLength");

Moreover, the solution of the problem can also be printed as a txt, as
well as the system matrix or the rhs of the problem.

::

   ofstream rhsFile;
   rhsFile.open(paramStr->getStringParameter(PoissonParams::filemesh)+to_string(dofHand->myRank())+".txt");
   hiperProbl->sol->Print(rhsFile);
   rhsFile.close();

Finalize
~~~~~~~~

::

    hiperlife::Finalize();
    return 0;


.. _ElementFilling:

Left hand side and right hand side
----------------------------------

Here we define the ElementFilling function:

::

   void ElementFilling(hiperlife::FillStructure& fillStr)
   {
       using namespace std;
       using namespace hiperlife;
       using ttl::tensor, ttl::wrapper;
       using ttl::index::i;
       using ttl::index::I, ttl::index::J;
       \\ ALL CODE

where in ALL CODE we include the rest of the code detailed in this
section.

Initialize variables
~~~~~~~~~~~~~~~~~~~~

First, we get the model parameters from the UserStructure

::

   double force = fillStr.getRealParameter(PoissonParams::force);

Then, we get the SubFillStructure for the dofHand from ourfillStr as
follows

::

   SubFillStructure& subFill = fillStr["dofHand"];

which we use to declare the number of neighbor nodes and number of
parametric dimension,

::

   int eNN  = subFill.eNN;
   int pDim = subFill.pDim;

the coordinates of the nodes in the element,

::

   tensor<double,2> nborCoords(subFill.nborCoords.data(),eNN,nDim);

the basis functions evaluated at the Gauss point, which
are a vector (tensor of order 1) of size eNN,

::

    wrapper<double,1>  bf(subFill.nborBFs(), eNN);

and the jacobian (differential of line/area/volume):

::

    double jac;

To make the calculations, we transform the local basis functions
(more precisely, their derivatives) from local coordinates to cartesian
(global) coordinates. The derivatives of the basis functions
in global coordinates are a matrix of size eNN*pDim.

::

    tensor<double,2> Dbf_g(eNN,pDim);

To calculate the global basis functions and the jacobian we call the
function gradients from the namespace GlobalBasisFunctions

::

    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

We are going to fill the matrix and the right hand side. Here, we define
the matrix Ak (eNN*eNN) and the vector Bk (eNN).

::

    wrapper<double,2> Ak(fillStr.Ak(0, 0).data(),eNN,eNN);
    wrapper<double,1> Bk(fillStr.Bk(0).data(),eNN);


Fill linear system
~~~~~~~~~~~~~~~~~~

We loop through the neighboring nodes to fill both the matrix and the
right-hand side at the same time using the tensor library ttl, where it
is defined that when and index is repeated (I,J and i) we loop through them.

::

   Bk(I) = jac * bf(I) * force;
   Ak(I, J) = jac * Dbf(I, i) * Dbf(J, i);

Finally, we finish the ALL CODE with a return command

::

   return;
