Allen-Cahn tutorial
===================
