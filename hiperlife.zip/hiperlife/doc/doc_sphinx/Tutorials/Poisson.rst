.. role:: cpp(code)
   :language: cpp

Poisson tutorial
================

In this first Chapter we show the main structure of a program developed in
hiperlife. We have chosen the scalar Poisson equation, meaning

.. math:: \Delta u = f,

where :math:`\Delta = \nabla^2 = \nabla \cdot \nabla` is the Laplace
operator. In our problem :math:`u` will be the unknown variables and
:math:`f` a given parameter chosen to be zero for this particular case.

Code before declaring the main function
---------------------------------------

Headers inclusion
~~~~~~~~~~~~~~~~~

The code starts with the inclusion of headers

.. code-block:: cpp

   // C++ headers
   #include <iostream>
   #include <fstream>

   // hiperlife headers
   #include "hl_Core.h"
   #include "hl_ParamStructure.h"
   #include "hl_Parser.h"

   #include "hl_TypeDefs.h"
   #include "hl_GlobalBasisFunctions.h"
   #include "hl_StructMeshGenerator.h"
   #include "hl_DistributedMesh.h"
   #include "hl_FillStructure.h"
   #include "hl_DOFsHandler.h"
   #include "hl_HiPerProblem.h"

   #include "hl_LinearSolver_Direct_MUMPS.h"

where

-  **hl** :math:`\_`\ **Core.h** defines
   the MPI objects and the Trilinos header that defines RCP objects
   (Smart reference counting pointer class for automatic garbage collection).

-  **hl** :math:`\_`\ **ParamStructure.h** defines the structure of the parameters.

-  **hl** :math:`\_`\ **Parser.h** defines
   the parser that that allows to define the structure of the parameters in hl.

-  **hl** :math:`\_`\ **TypeDefs.h** defines
   different data types used throughout the library.

-  **hl** :math:`\_`\ **StructMeshGenerator.h**
   defines structured mesh objects.

-  **hl** :math:`\_`\ **DistributedMesh.h** defines
   distributed mesh objects.

-  **hl** :math:`\_`\ **FillStructure.h** defines
   objects to fill the matrix and vector of the problem.

-  **hl** :math:`\_`\ **DOFsHandler.h** defines
   DOFHandler objects.

-  **hl** :math:`\_`\ **HiPerProblem.h** defines
   HiPerProblem objects.

-  **hl** :math:`\_`\ **hl_LinearSolver_Direct_MUMPS.h** defines
   the direct solver.


Parameters declaration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Now the main parameters of the problem are declared,
in the case of the Poisson equation we declare the force.

.. code-block:: cpp

    struct PoissonParams
    {
        enum RealParameters
        {
            force
        };

        HL_PARAMETER_LIST DefaultValues
        {
            {"force", 0.0},
        };
    };


Elemental linear functions declaration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Now we declare the functions which fill the elemental linear
system of the problem. Despite being declared here, the implementation
takes place at the bottom of the code; see Section `3.3 <#PoissonLS>`__.

::

   void ElementFilling(hiperlife::FillStructure& fillStr);


Main function
-------------

In this first tutorial, everything is implemented inside the main
function.

::

   int main(int argc, char** argv)
   {
   	  using namespace std;
      using namespace hiperlife;
       \\ ALL CODE
   }

where in ALL CODE we include the rest of the code detailed in this
section.

Initialization
~~~~~~~~~~~~~~

In this first part of the code we initialize several objects and/or
variables that will be used later. In our case, we initialize the MPI
and the parameters of the model. Note that the MPI code must be
initialized here at the beginning. Other objects/variables
like the parameters of the model could be initialized later on.


Initialize the MPI execution environment
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This function has two input parameters which we do not need, so we pass
null pointers (nullptr):

::

   hiperlife::Init(argc, argv);

Note that MPI must be initialized before calling any other object, so a
good practice is to always do it at the beginning of the main function.


Creation of ParamStructure object
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Now we create a new hiperlife object called ParamStructure. This is a
container of user-defined parameters that can be easily accessed at
different points of the code (eg. when filling the elemental matrix or
vector)

The creation of an ParamStructure object is as follows (note that the
creation of every object of hiperlife follows the same structure)

::

   SmartPtr<ParamStructure> paramStr = CreateParamStructure<PoissonParams>();

where

-  SmartPtr<ParamStructure> is the pointer to data type ParamStructure.

-  CreateParamStructure is the object type ParamStructure.

-  paramStr is the name of the object.

-  SmartPtr is the smart pointer.

This ParamStructure allows a number of data types such as doubles or
integers (see documentation for available data types). Any user variable
can be stored into predefined vectors.

Our ParamStr object will be later given to the hiperProblem object, which
handles all the problem; see subsection
`3.2.4 <#PoissonhiperProblem>`__.

Mesh creation
~~~~~~~~~~~~~

It is time now to create a mesh for our computational domain. This process has
two steps: mesh generation and mesh distribution. In the first step, we
generate a mesh either in serial or in parallel, depending on the chosen
method. In the second one, we generate all the structures related to the
mesh and distribute them among the processors.

Mesh generation
^^^^^^^^^^^^^^^

Currently, hiperlife can generate a mesh in three different ways:

-  Loading a vtk file.

-  Using vtk libraries.

-  Using hiperlife own libraries for structured meshes.

In this tutorial we will show hiperlife’s own libraries (the two other
ways are covered in other tutorials). The first step is to declare a new
"StructMeshGenerator" object which we name "structMesh".

::

   SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();

Once created, we have to go through three steps:

#. Set variables:

   In this step we have to set the spatial dimensions of the mesh, the
   type of basis function and its order (if applicable), and the type of
   elements. This four sets have to be done for every type of mesh
   created through the StructMeshGenerator object.

   hiperlife works with spatial dimensions so, even if the computational
   domain is two-dimensional, we start by setting the number of spatial
   dimensions to three.

   ::

      structMesh->setNDim(3);


   Next, we set the type of basis function that we want to use to
   discretize. At this moment, there are five different basis functions
   implemented in hiperlife:

   -  Linear (LinElems)

   -  Lagrangian (LagrElems)

   -  Subdivision Surfaces (SubdivSurf)

   -  BSplines (BSplineElems)

   -  Nurbs (NurbsElems)

   In this tutorial we are going to use Lagrange basis functions.

   ::

      structMesh->setBasisFuncType(BasisFuncType::Lagrangian);

   We have to set an order for the basis functions. This is not always
   the case as shown in other tutorials (eg. subdivision surfaces are
   always of second order). In addition, some basis functions can have
   different order per direction (eg. BSplines). Here we set the order
   to one. Note that this is equivalent to use linear basis functions.

   ::

      structMesh->setBasisFuncOrder(1);


   Now we set the type of element of our mesh. Currently, there are six
   types of elements available:

   -  Points (Point)

   -  Lines (Line)

   -  Triangles (Triang)

   -  Squares (Square)

   -  Tetrahedra (Tetrah)

   -  Parallelepipeds (Parallelep)

   In this tutorial we are going to use triangles:

   ::

      structMesh->setElemType(ElemType::Triang);


#. Generate a particular geometry:

   Once we have performed the sets, we can proceed with the generation
   of the mesh. We can either use a predefined generator or a free
   generator. Some examples of predefined generators are lines
   (genLine), squares (genSquare), annular sectors (genAnnularSector),
   or quarter torus (genQuarterTorusSolid). You can find many more in
   the documentation. In general, all generators have at least n
   parameters (being n the spatial dimension of the geometry) that
   specify the number of elements per spatial dimension. Here, we are
   going to use the rectangle generator which has 4 arguments:

   -  The number of elements per direction.

   -  The length of the sides.

   -  The bottom-left corner of the generated rectangle will be at
      :math:`(0,0)`.

   ::

      structMesh->genRectangle(500, 500, 1.0, 0.5);


#. Transform the geometry (if needed):

   Finally, we can apply transformations to the geometry. As with the
   generators, there are both predefined transformations and free
   transformations. The predefined transformation include affine
   transformations, order elevation, element stretch, mesh skew/shear
   and many others (you can find them in the documentation). In our
   problem we are going to translate in Y direction.

   ::

      structMesh->translateY(0.5);


**Remark:** As you will see later, all the objects of hiperlife have
setters followed by an update. The StructMeshGenerator object is
different, as it has setters, generators and transformations, and they
have to be done in this order. In any case, if the order is altered, the
code will through an exception/error and will stop.


Mesh distribution
^^^^^^^^^^^^^^^^^

This object takes a mesh and creates all the necessary structures for
solving the problem, such as connectivity, graphs, adjacencies, and
contains all the information of the mesh. The input mesh can be either
serial or distributed, so it has a method to balance/distribute the
elements between processors.

First, we create the object, which we call disMesh:

::

   SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();

Then, we set the object with the generated mesh

::

   disMesh->setMesh(structMesh);

and we distribute the mesh using the default algorithm

::

   disMesh->setBalanceMesh(true);

This algorithm accepts a tolerance as a second argument. By not
specifying it we are using the default one, namely 0.05. The smaller the
tolerance the more balanced the mesh is going to be.

Finally, we update the DistributedMesh. This update is going to perform
the actual calculation of the object and all its structures.

::

   disMesh->Update();

fields creation
~~~~~~~~~~~~~~~~~~~~

Now, we create a class that contains our distributed mesh and includes
the degrees of freedom and auxiliary variables. We also set the boundary
conditions of our problem.

Create DOFHandler
^^^^^^^^^^^^^^^^^

The object is created using the regular procedure, but now we construct
it with the distributed mesh "disMesh":

::

   SmartPtr<DOFsHandler> fields = Create<DOFsHandler>(disMesh);

Then, we set a name for the fields ("fields"), which will be
useful later in the code,

::

   fields->setNameTag("fields");

and we set the number of degrees of freedom (fieldss of unknowns). In our
case, as we are solving a scalar PDE, this number is one.

::

   fields->setNumDOFs(1);

Finally, we update the object (recall that the actual computation is
performed through this instruction).

::

   fields->Update();

Note that a DOFsHandler can contain several degrees of freedom, as in a
reaction-diffusion system. Also, we can have several DOFsHandlers for
the same problem, for instance in Stokes flow we need one DOFsHandler
with two degrees of freedom for the velocities and another one with just
on degree of freedom for the pressure, each one of them with a different
mesh (see tutorial).

Boundary conditions
^^^^^^^^^^^^^^^^^^^

Boundary conditions (BC) can be added in a number of different ways in
hiperlife. Here, we are going to use the function setBoundaryCondition
in three different ways. Other ways of imposing BC are shown in other
tutorials.

First, we are going to initialize all boundary condition to zero. To do
this, we can use setBoundaryCondition with two arguments:

-  The number of degree of freedom to which we are a applying the
   condition (in this case we only have one).

-  The value at the boundary.

::

   fields->setBoundaryCondition(0, 0.0);

Then, we are going to fix the value at the right-hand side of our domain
to one. This may be achieved using the same function, but this time with
three arguments:

-  The number of degree of freedom.

-  The edge.

-  The value.

To specify the edge we use the enum class MAxis. In our case, as we want
to impose the BC at those nodes whose :math:`x` coordinate is maximum,
we use Xmax:

::

   fields->setBoundaryCondition(0, MAxis::Xmax, 1.0);

A third way of imposing boundary conditions with the same function is
through lambda functions. In this case we have three arguments which
are:

-  The number of degree of freedom.

-  The edge.

-  The lambda function.

To show how it works we are going to impose a linear and a quadratic
boundary condition from zero to one on the bottom and top edges
respectively.

::

   fields->setBoundaryCondition(0, MAxis::Ymin,[](double x){return x;});
   fields->setBoundaryCondition(0, MAxis::Ymax,[](double x){return x*x;});

Finally, after changing the information at the nodes, we need to update
the ghost nodes so that all the neighbor processors now the changes.
This is done with the function:

::

   fields->UpdateGhosts();

.. _PoissonHiPerProblem:


HiPerProblem creation
~~~~~~~~~~~~~~~~~~~~~

The last object we are going to create is the HiPerProblem object. It
contains the ParamStructure and the DOFHandlers (in the present case just
one) and includes, among other things, the integration rules and
structures for every DOFHandler and the solver.

We initialize the object and name it “problem", give it the
UserStructure and the DOFHandler. Note that the last one is given as a
vector of one component, as this function can receive several
DOFHandlers

::

   SmartPtr<HiPerProblem> problem = Create<HiPerProblem>();
   problem->setParameterStructure(paramStr);
   problem->setDOFsHandlers({fields});

Set integration
^^^^^^^^^^^^^^^

The next step is to set the integrations. This includes setting the type
of integration, the cubature and the elemental matrices and vectors for
each integration (only one integration in our case).

In short, in hiperlife setting the integration type means to establish
the relation between different DOFHandlers. For instance, one DOFHandler
may be a "Master" and a second one its Lagrange multiplier. Their use is
shown in other tutorials. Here, as we only have one DOFHandler, its
integration type can only be "Master". We set it through the function
setIntegration, which has three arguments:

-  A name for the integration (useful when there are more than one).

-  A vector of DOFHandlers (one in our case).

-  The integration type (Master).

::

   problem->setIntegration("Integ", {"fields"});

Then we set the type of curvature through the function
setCubatureGauss. It takes two arguments:

-  A name for the integration.

-  The number of points per element.

If the number of integration points is not given, it will use a default
number (see documentation). Here, we use a 4-point Gaussian curvature.
We refer the user to the documentation for other curvature types.

Note that there are other possible cubatures that we can apply, such
as setCubatureBorderGauss, setCubatureBorderImmersed, etc.

::

   problem->setCubatureGauss("Integ", 4);

The last set of the integration is to specify the name of the
function(s) for the elemental filling of the matrices and vectors. This
is performed through the function setElementFillings, which takes two arguments:

-  The name of the integration.

-  The name of a function that fills both the matrix and the vector of
   the linear problem (ElementFilling in this case).

::

   problem->setElementFillings("Integ", ElementFilling);

Note that the filling of the linear system can be also given through two
separate functions, the matrix (M) and the right-hand side vector (RHS).
In this case the same function may be used with a null pointer in the
second argument and two extra arguments with the function names, eg:

::

   problem->setElementFillings("Integ", nullptr, M, RHS);

Update
^^^^^^^^^^^^^^^

Now we have to update the problem

::

    problem->Update();


Set solver
^^^^^^^^^^

Currently, hiperlife works with all linear and non-linear solvers of
Trilinos. A number of them can be set directly in the HiPerProblem,
while the remaining can be easily included indirectly (as shown in other
tutorials). In this case we are going to use MUMPS,
which we set through the following instructions:

::

   SmartPtr<MUMPSDirectLinearSolver> solver = Create<MUMPSDirectLinearSolver>();
   solver->setHiPerProblem(problem);
   solver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::Extreme);
   solver->setDefaultParameters();
   solver->Update();

Now we solve the problem, inside this solve there is the call to the
ElementFilling function, where the RHS and LHS matrices are filled.

::

    solver->solve();

And we update the values of the nodes through the instruction:ç

::

    problem->UpdateSolution();

The results can be printed to a file either in hiperlife's own format

::

    fields->printFile("Poisson");

or/and as vtk, for visualization purposes.

::

    fields->printFileLegacyVtk("Poisson");

Finalize
~~~~~~~~

The only thing that lasts is to finalize our problem.

::

    hiperlife::Finalize();
    return 0;


.. _ElementFilling:

Left hand side and right hand side
----------------------------------

This function fills the elemental matrix and right-hand side vector at a
given integration point. All the necessary information is in the
FillStructure object fillStr that we passed as argument to this
function, such as the elemental matrix (K), the right-hand side vector
(rhs\ :math:`\_`\ k), the UserStructure, and the SubFillStructures. In
turn, the SubFillStructures include all the necessary variables at an
integration point (eg. spatial coordinates, basis functions and
derivatives).

Note that there are as many SubFillStructures as DOFHandlers.

::

   void ElementFilling(hiperlife::FillStructure& fillStr)
   {
       using namespace std;
       using namespace hiperlife;
       using ttl::tensor, ttl::wrapper;
       using ttl::index::i;
       using ttl::index::I, ttl::index::J;
       \\ ALL CODE

where in ALL CODE we include the rest of the code detailed in this
section.

Initialize variables
~~~~~~~~~~~~~~~~~~~~

First, we get the model parameters from the UserStructure

::

   double force = fillStr.getRealParameter(PoissonParams::force);

Then, we get the SubFillStructure for the dofHand from ourfillStr as
follows

::

   SubFillStructure& subFill = fillStr[0];

which we use to declare the number of neighbor nodes and number of
parametric dimension,

::

   int eNN  = subFill.eNN;
   int pDim = subFill.pDim;

the coordinates of the nodes in the element,

::

   tensor<double,2> nborCoords(subFill.nborCoords.data(),eNN,pDim);

the basis functions evaluated at the Gauss point, which
are a vector (tensor of order 1) of size eNN,

::

    wrapper<double,1>  bf(subFill.nborBFs(), eNN);

and the jacobian (differential of line/area/volume):

::

    double jac;

To make the calculations, we transform the local basis functions
(more precisely, their derivatives) from local coordinates to cartesian
(global) coordinates. The derivatives of the basis functions
in global coordinates are a matrix of size eNN*pDim.

::

    tensor<double,2> Dbf_g(eNN,pDim);

To calculate the global basis functions and the jacobian we call the
function gradients from the namespace GlobalBasisFunctions

::

    GlobalBasisFunctions::gradients(Dbf_g, jac, subFill);

We are going to fill the matrix and the right hand side. Here, we define
the matrix Ak (eNN*eNN) and the vector Bk (eNN).

::

    wrapper<double,2> Ak(fillStr.Ak(0, 0).data(),eNN,eNN);
    wrapper<double,1> Bk(fillStr.Bk(0).data(),eNN);


Fill linear system
~~~~~~~~~~~~~~~~~~

We loop through the neighboring nodes to fill both the matrix and the
right-hand side at the same time using the tensor library ttl, where it
is defined that when and index is repeated (I,J and i) we loop through them.

Note that the index notation employs uppercase letters to signify sums through the
nodes and lowercase letters for sums associated with coordinates.

::

   Bk(I) = jac * bf(I) * force;
   Ak(I, J) = jac * Dbf_g(I, i) * Dbf_g(J, i);

Finally, we finish the ALL CODE with a return command

::

   return;
