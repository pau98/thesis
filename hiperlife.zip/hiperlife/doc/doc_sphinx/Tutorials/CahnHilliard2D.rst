Cahn-Hilliard tutorial
===================

.. role:: cpp(code)
   :language: cpp

In this second Chapter we will solve the Cahn-Hilliard equation in 2D, which
describe the process of phase separation, by which two components of a binary
fluid spontaneously separate and form domains pure in each component.

.. math:: \dfrac{\partial c}{\partial t}=D \nabla ^2 (\dfrac{df}{dc}-\gamma \nabla^2c),

where :math:`f=c^2 (1-c)/4`, :math:`c` is the concentration of the fluid (with
:math:`c=\pm 1` indicating domains), :math:`D` is a diffusion
coefficient, :math:`\sqrt{\gamma}` gives the
length of the transition regions between the domains,
:math:`\dfrac{\partial}{\partial t}` is the partial time derivative,
:math:`\nabla ^2` is the laplacian in two dimensions and the quantity
:math:`\dfrac{df}{dc}` is identified as a chemical potential.

The parts of the program that have already been
explained in the first tutorial won't be specifically explained.

Code before declaring the main function
---------------------------------------

Headers inclusion
~~~~~~~~~~~~~~~~~

The code starts again with the inclusion of headers

.. code-block:: cpp

    // C++ headers
    #include <iostream>
    #include <random>
    // hiperlife headers
    #include "hl_Core.h"
    #include "hl_Parser.h"
    #include "hl_TypeDefs.h"
    #include "hl_StructMeshGenerator.h"
    #include "hl_DistributedMesh.h"
    #include "hl_FillStructure.h"
    #include "hl_DOFsHandler.h"
    #include "hl_HiPerProblem.h"
    #include "hl_LinearSolver_Direct_MUMPS.h"
    #include "hl_NonlinearSolver_NewtonRaphson.h"
    #include "hl_GlobalBasisFunctions.h"

Parameters declaration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Now the main parameters of the problem are declared, "deltat" correspond
to :math:`\partial t` , "mobility" correspond to :math:`D` and epsilon2
correspond to :math:`\gamma`.

.. code-block:: cpp

    struct CahnHilliardParams
    {
        enum RealParameters
        {
            deltat,
            mobility,
            epsilon2
        };

        HL_PARAMETER_LIST DefaultValues
        {
            {"deltat", 1.E-7},
            {"mobility", 1.0},
            {"epsilon2", 0.00005},
        };
    };


.. _ElementFilling:

Left hand side and right hand side
----------------------------------

In this case, we start by defining the function which will fill the element linear system
of the Cahn Hilliard problem inside the elements. Here we need to define the parameters,
the shape functions and the values at the integration points, as well as the
gradients and the hessians.

For this part we use again the tensor library, remember
that our index notation employs uppercase letters to signify sums through the nodes
and lowercase letters for sums associated with coordinates.

::

    void ElementFillingCahnHilliard(hiperlife::FillStructure& fillStr)
    {
        using namespace hiperlife;
        using ttl::tensor, ttl::wrapper;
        using ttl::index::I, ttl::index::J;
        using ttl::index::n, ttl::index::i;

        // Parameters
        const double deltat   = fillStr.getRealParameter(CahnHilliardParams::deltat);
        const double mobility = fillStr.getRealParameter(CahnHilliardParams::mobility);
        const double epsilon2 = fillStr.getRealParameter(CahnHilliardParams::epsilon2);

        // Rename variables
        SubFillStructure& subFill = fillStr["dhand"];
        int DOF   = subFill.numDOFs;
        int eNN   = subFill.eNN;
        int nDim  = subFill.nDim;
        int pDim  = subFill.pDim;
        wrapper<double, 2> nborCoords(subFill.nborCoords.data(), eNN, nDim);
        wrapper<double, 2> nborDOFs(subFill.nborDOFs.data(), eNN, DOF);
        wrapper<double, 2> nborDOFs0(subFill.nborDOFs0.data(), eNN, DOF);

        // Shape functions and derivatives at Gauss points
        double jac;
        wrapper<double, 1> bf(subFill.nborBFs(), eNN);
        tensor<double, 2> dbf(eNN, pDim);
        tensor<double, 3> d2bf(eNN, pDim, pDim);
        tensor<double, 1> lapbf(eNN);
        GlobalBasisFunctions::hessians(dbf, jac, d2bf, lapbf, subFill);

        // Values at integration points
        tensor<double, 1> x = nborCoords(I, i) * bf(I);
        tensor<double, 1> gphi = nborDOFs(I, 0) * dbf(I, i);
        double phi = nborDOFs(I, 0) * bf(I);
        double phin= nborDOFs0(I, 0) * bf(I);
        double lapphi = nborDOFs(I, 0) * d2bf(I, i, i);

Moreover, we define the function :math:`f`, which correspond to the double well function W:

::

    double   W = (phi*phi)*(1.0-phi)*(1.0-phi)/4.0;
    double  dW = phi*(1.0-phi)*(1.0-2.0*phi)/2.0;
    double d2W = (1.0-6.0*phi+6.0*phi*phi)/2.0;
    double d3W = (-1.0+2.0*phi)*3.0;

Fill linear system
~~~~~~~~~~~~~~~~~~

Now we loop through the neighboring nodes to fill both the matrix and the right-hand side
using the index notation of the tensor library.

::

   wrapper<double, 2> Bk(fillStr.Bk(0).data(), eNN, DOF);
   Bk(I, 0) = jac * (bf(I) * (phi-phin) / deltat + mobility * d2W * dbf(I, i) * gphi(i) + mobility * epsilon2 * lapbf(I) * lapphi);

   wrapper<double, 4> Ak(fillStr.Ak(0, 0).data(), eNN, DOF, eNN, DOF);
   Ak(I, 0, J, 0) = jac * (bf(I) * bf(J) / deltat + mobility * d3W * bf(J) * dbf(I, i) * gphi(i) + mobility * d2W * dbf(I, i) * dbf(J, i)
                   + mobility * epsilon2 * lapbf(I) * lapbf(J)) ;


As a final step, we add some magnitudes to the global integral:

::

    fillStr.addToGlobalIntegral("ChemicalFreeEnergy", jac*W);
    fillStr.addToGlobalIntegral("SurfaceFreeEnergy", jac*0.5*epsilon2*Math::SNorm(pDim, gphi.data()));
    fillStr.addToGlobalIntegral("GinzburgLandauFreeEnergy", jac*(W + 0.5*epsilon2*Math::SNorm(pDim, gphi.data())));
    fillStr.addToGlobalIntegral("Mass", jac*phi);



Main function
-------------

Everything is implemented inside the main function. Now we need to initialize
the MPI, to create the structure of our problem and to define the time-related
and mesh-related parameters.

::

   int main(int argc, char *argv[])
   {
       using namespace std;
       using namespace hiperlife;

       // Initialize MPI
       hiperlife::Init(argc, argv);
       const int myRank = hiperlife::MyRank();

       // Model parameters
       SmartPtr<ParamStructure> userStr = CreateParamStructure<CahnHilliardParams>();

       // Mesh-related parameters
       BasisFuncType bfType = BasisFuncType::BSplines;
       ElemType eType = ElemType::Line;
       int bfOrder = 2;
       int gPts = pow(bfOrder+1, computePDim(eType));
       int nEl = 200;

       // Time-related parameters
       string oname = "CahnHilliard.";
       double maxTime  = 10000000;
       double maxNStep = 10000000;
       double maxDelt  = 10000000;
       double stepFactor = 0.95;
       int nSave = 20;


Mesh creation
~~~~~~~~~~~~~

At this point, the mesh is generated, distributed and printed. In this example,
we have used exception error handling to check if the mesh has been correctly
created and to finalize the problem if not.

::

   // Generate mesh
   SmartPtr<StructMeshGenerator> structMesh = Create<StructMeshGenerator>();
   try
   {
       structMesh->setMesh(eType, bfType, bfOrder);
       structMesh->setPeriodicBoundaryCondition({Axis::Xaxis});
       structMesh->genStructMesh(nEl);
   }
   catch (runtime_error& err)
   {
       std::cout << "Error: Mesh could not be generated.";
       hiperlife::Finalize();
       return 1;
   }

   // Create distributed mesh
   SmartPtr<DistributedMesh> disMesh = Create<DistributedMesh>();
   try
   {
       disMesh->setMesh(structMesh);
       disMesh->Update();

       cout << disMesh->myRank() << ":   Distributed Mesh successfully created. " << endl;
   }
   catch (runtime_error& err)
   {
       cout << disMesh->myRank() << ":   Distributed Mesh could not be created. " << err.what() << endl;

       hiperlife::Finalize();
       return 1;
   }

   // Print mesh
   disMesh->printFileLegacyVtk("Mesh");


DOFsHandler creation
~~~~~~~~~~~~~~~~~~~~

The DOFHandler is now created and named fields, remember that inside the DOFsHandler we can have different
fields, but in this case we just want to calculate the concentration of the fluid.

::

    SmartPtr<DOFsHandler> fields = Create<DOFsHandler>(disMesh);
    try
    {
        fields->setNameTag("fields");
        fields->setDOFs({"rho"});
        fields->Update();

        cout << fields->myRank() << ":   DOFsHandler successfully created. " << endl;
    }
    catch (runtime_error& err)
    {
        cout << fields->myRank() << ":   DOFsHandler could not be created. " << err.what() << endl;

        hiperlife::Finalize();
        return 1;
    }

Initial conditions
^^^^^^^^^^^^^^^^^^^

Here we set the initial conditions of the temporal problem. In this
case we use a random function to generate a random initial distribution.

::

    for (int i = 0; i < fields->mesh->loc_nPts(); i++)
        {
        double r = ((double) rand() / (RAND_MAX))*2.0-1.0;
        fields->nodeDOFs0->setValue(0, i, IndexType::Local, 0.6+0.3*r);
        }
    fields->UpdateGhosts();


HiPerProblem creation
~~~~~~~~~~~~~~~~~~~~~

We create the hiperproblem, which is the structure that contains the
"usrStr" and the "fields", we will name it "problem".

::

    SmartPtr<HiPerProblem> problem = Create<HiPerProblem>();
    try
    {
        // Set UserStructure
        problem->setParameterStructure(userStr);

        // Set DOFHandler
        problem->setDOFsHandlers({fields});

        // Set Integration
        problem->setIntegration("Integ", {"fields"});
        problem->setCubatureGauss("Integ", gPts);
        problem->setElementFillings("Integ", LS);

        // Set global integral
        problem->setGlobalIntegrals({"ChemicalFreeEnergy", "SurfaceFreeEnergy", "GinzburgLandauFreeEnergy", "Mass"});

        // Update
        problem->Update();
    }
    catch (runtime_error& err)
    {
        cout << myRank << ": HiPerProblem could not be created " << err.what() << endl;
        MPI_Finalize();
        return 1;
    }

Set solver
^^^^^^^^^^

Now we set the solver, in this case we need to use a nonlinear solver in order
to solve our equation, so we are going to use the Newton-Raphson solver. This
method basically consist on calculating the residual :math:`\Delta x` of our
solution after assuming an initial guess in this way:

.. math:: K\Delta x=-f,

where :math:`K_{ab}=\dfrac{\partial f_a}{\partial x_b}` is the hessian and
:math:`f_n` are the set of nonlinear equations that form the system.

Knowing this, we see that a complementary linear solver will also be needed so as
to calculate this residual, and this is why we are going to use the MUMPS direct
linear solver.

::

    // Create linear solver
    SmartPtr<MUMPSDirectLinearSolver> linSolver = Create<MUMPSDirectLinearSolver>();
    linSolver->setHiPerProblem(problem);
    linSolver->setVerbosity(MUMPSDirectLinearSolver::Verbosity::Extreme);
    linSolver->setDefaultParameters();
    linSolver->Update();

    // Create nonlinear solver
    SmartPtr<NewtonRaphsonNonlinearSolver> nonlinSolver = Create<NewtonRaphsonNonlinearSolver>();
    nonlinSolver->setLinearSolver(linSolver);
    nonlinSolver->setMaxNumIterations(10);
    nonlinSolver->setResTolerance(1.E-4);
    nonlinSolver->setSolTolerance(1.E-4);
    nonlinSolver->setLineSearch(false);
    nonlinSolver->setConvRelTolerance(true);
    nonlinSolver->setPrintIntermInfo(true);
    nonlinSolver->setPrintSummary(false);
    nonlinSolver->Update();


Time loop
^^^^^^^^^^

We first print the initial condition in a VTK file in order to be able to
visualize the initial state of the problem.

::

    fields->nodeDOFs->setValue(fields->nodeDOFs0);
    fields->printFileLegacyVtk(oname + to_string(0), false);
    fields->printFile(oname + to_string(0), OutputMode::Text, true, 0.0, problem->globalIntegrals());


We will also open a file to write global integrals and the headers

::

    ofstream gIntegFile;
    gIntegFile.open ("globalIntegrals.csv");
    gIntegFile << "TS time deltat";
    for (auto g: problem->globalIntegralNames())
        gIntegFile << " " << g;
    gIntegFile << endl;


And now it is time to do the loop over the time steps of our problem. We first
declare some variables that we will need

::

    double time{0.0};
    int timeStep{0};
    double ener_prev{1.E8};
    double& deltat = userStr->getRealParameter(CahnHilliardParams::deltat);
    fields->nodeDOFs0->setValue(fields->nodeDOFs);


And we set the loop to be finished when the number of time steps reach the
maximum "maxNStep" or when the time reaches the maximum "maxTime".

::

    while ((timeStep < maxNStep) and (time < maxTime))
        {

The time step, current time and delta t are printed now:

::

    if (fields->myRank() == 0)
        cout << endl << " TS: " << to_string(timeStep) << " Time " << time <<  " Delta " << deltat << endl;


And we set the initial condition as the initial guess:

::

    fields->nodeDOFs->setValue(fields->nodeDOFs0);
    problem->UpdateGhosts();


The convergence of the method is checked now by seeing if it has converged and
if the energy has decreased with respect to the previous time step. If the
nonlinear problem is converged we execute //TIME CODE//, which will be now explained,
but if the nonlinear problem does not converge we decrease the deltat.

::

    if (nonlinSolver->converged() and problem->globalIntegral("GinzburgLandauFreeEnergy") <= ener_prev)
    {
        //TIME CODE//
    }
    else
    {
        deltat *= stepFactor;
    }


Inside //TIME CODE// we save the solution, update the temporal variables,
write the results and write the global integrals.

::

    // Save solution
    fields->nodeDOFs0->setValue(fields->nodeDOFs);

    // Update variables
    timeStep ++;
    if (deltat > maxDelt)
        deltat = maxDelt;
    deltat /= stepFactor;
    if (deltat >= maxDelt)
        deltat = maxDelt;
    time += deltat;
    ener_prev = problem->globalIntegral(2);

    // Write results
    if (timeStep % nSave == 0)
    {
        string solName = oname + to_string(timeStep);
        fields->printFileLegacyVtk(solName, false);
        fields->printFile(solName, OutputMode::Text, true, time, problem->globalIntegrals());
    }

    // Write global integrals
    if(VerboseRank())
    {
        gIntegFile << timeStep << " " << time << " " << deltat;
        for (auto g: problem->globalIntegrals())
            gIntegFile  << " " << g;
        gIntegFile << endl;
    }

Note that "if(VerboseRank())" is equivalent to "if(myRank==0)" in hiperlife.

The last step of the time loop is to check the steady-state.

::

    if (deltat < 1.e-14)
    break;

Finalize
~~~~~~~~

To finalize the problem we close the file and finalize our hiperlife problem.

::

    // Close file
    gIntegFile.close();

    // Finalize
    hiperlife::Finalize();
    return 0;
