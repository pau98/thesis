Viscous Inextensible membrane tutorial
======================================
