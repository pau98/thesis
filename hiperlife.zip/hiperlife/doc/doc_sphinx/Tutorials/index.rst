.. GitLab Pages with Sphinx documentation master file, created by
   sphinx-quickstart on Thu Jan  9 10:28:38 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Tutorials
=========

We have to write here (or in the intro?) something about creating your own app using the hl_project. At least just create a link

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Poisson
   AllenCahn
   NavierStokes
   ViscousInex
