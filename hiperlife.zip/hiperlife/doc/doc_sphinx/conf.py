# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#
# import os
# import sys
# sys.path.insert(0, os.path.abspath('.'))



# -- Get md files -----------------------------------------------------------
with open(r"../../CONTRIBUTING.md", 'r+') as fp:
    with open("../../CONTRIBUTING_tmp.md", "w") as output:
        lines = fp.readlines()
        output.writelines(lines[8:])
with open(r"../../INSTALL.md", 'r+') as fp:
    with open("../../INSTALL_tmp.md", "w") as output:
        lines = fp.readlines()
        output.writelines(lines[8:])


# -- Project information -----------------------------------------------------

project = "hiperlife's documentation"
copyright = '2023, hiperlife'
author = 'The hiperlife team'

# The full version, including alpha/beta/rc tags
# version = '5.0'
release = '5.0.0'


# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    # 'sphinx_mdinclude',
    # 'myst_parser',
    'm2r2',
    'sphinx_fontawesome',
]
# source_suffix = ['.rst', '.md']


# Add any paths that contain templates here, relative to this directory.
templates_path = ['_templates']

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store', 'README.md']


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
# html_theme = 'basic'
#html_theme = 'pyramid'
# html_theme = 'press'
html_theme = 'sphinx_rtd_theme'
# html_theme = 'sphinxdoc'

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = ['_static']


html_css_files = ["css/custom.css"]

# The name of an image file (relative to this directory) to place at the top
# of the sidebar.
# html_logo = None
#html_logo = 'img/logo_wtitle_white.png'
html_logo = 'img/logo_wtitle_black.png'

# The name of an image file (relative to this directory) to use as a favicon 
# of the docs.  This file should be a Windows icon file (.ico) being 16x16
# or 32x32 pixels large.
html_favicon = 'favicons/favicon.ico'

html_theme_options = {
    'display_version': True,
    'prev_next_buttons_location': 'bottom',
    'style_external_links': False,
    'vcs_pageview_mode': '',
    # Toc options
    'collapse_navigation': True,
    'sticky_navigation': True,
    'navigation_depth': 2,
    'includehidden': True,
    'titles_only': False,
    'logo_only': True
}


# If true, links to the reST sources are added to the pages.
html_show_sourcelink = False

# If true, "Created using Sphinx" is shown in the HTML footer. Default True.
# html_show_sphinx = True

# If true, "(C) Copyright ..." is shown in the HTML footer. Default is True.
# html_show_copyright = True

