Introduction
============


Write about

- namespaces
- General structure of a code (main, LS) ...
- hiperlife::Init and hiperlife::Finalize
- Smart pointers
- Error/exceptions
- ??
