HiperProblem
============

Integration
-----------

### DOFs and their relations ###

### Cubatures ###

### Element fillings ###


Global integrals
----------------

User structure
--------------
