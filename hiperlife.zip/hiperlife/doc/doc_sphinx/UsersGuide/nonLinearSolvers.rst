Non-linear solvers
==================

Newton raphson

Line search
