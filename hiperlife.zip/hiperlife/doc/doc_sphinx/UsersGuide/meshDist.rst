Mesh distribution
=================


Load balance
------------

Mesh relations
--------------

1. h-refinement
2. p-refinement
3. Global constraint
4. Immersed mesh
