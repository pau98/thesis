.. GitLab Pages with Sphinx documentation master file, created by
   sphinx-quickstart on Thu Jan  9 10:28:38 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

User's guide
============

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   Introduction
   meshGen
   meshDist
   DOFsHandler
   hiperProbl
   linearSolvers
   nonLinearSolvers
   optimizers
   IO
   elemFill
