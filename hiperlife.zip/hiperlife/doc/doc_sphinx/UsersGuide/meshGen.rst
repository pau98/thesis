Mesh generation
===============

.. role:: cpp(code)
   :language: cpp

hiperlife can generate meshes in three different ways:

    1. Using hiperlife's own libraries for structured meshes,
    2. using third-party libraries, such as vtk or gmsh,
    3. loading files, and
    4. joining existing meshes.

.. warning::
   Although mesh generation is done in parallel with hiperlife's own generation, when using third-party libraries the generation may be done in serial (we cannot control this). This may translate in high memory usage for large meshes. We strongly recommend to use hiperlife's own format.


All this methods share a common pattern as shown in the code below: declaration of the object (line 1), setting the mesh (line 2), generating a particular geometry (line 3), and transforming it if needed (line 4). For instance, the following code generates a structured mesh:

.. code-block:: cpp
   :linenos:

   SmartPtr<StructMeshGenerator> mesh = Create<StructMeshGenerator>();
   mesh->setMesh(ElemType::Square, BasisFuncType::Lagrangian, 1);
   mesh->genRectangle(80, 40, 0.0, 0.0);
   mesh->translateY(0.5);

.. note::
   As explained in the introduction, all hiperlife's objects of have setters followed by an update method :cpp:`object->Update()`. The mesh generator objects are different in that they lack an update method. They have setters, generators and transformations, and they have to be done in this order. In any case, if the order is altered, the code will through an exception/error and will stop.

Element types, basis functions and order
----------------------------------------
Next, we set the type of basis function that we want to use to discretize. At this moment, there are five different basis functions implemented in hiperlife: linear (LinElems), Lagrangian (LagrElems), subdivision surfaces (SubdivSurf), BSplines (BSplineElems), and Nurbs (NurbsElems).

In this tutorial we are going to use Lagrange basis functions.

.. code-block:: cpp

   mesh->setBasisFuncType(BasisFuncType::Lagrangian);


We have to set an order for the basis functions. This is not always the case as shown in other tutorials (eg. subdivision surfaces are always second order). In addition, some basis functions can have different order per direction (eg. BSplines).

.. code-block:: cpp

   mesh->setBasisFuncOrder(1);

Now we set the type of element of our mesh. Currently, there are six types of elements available: points (Point), lines (Line), triangles (Triang), squares (Square), tetrahedra (Tetrah), and parallelepipeds (Parallelep).

.. code-block:: cpp

   mesh->setElemType(ElemType::Square);



Types of mesh creation
----------------------

Structured mesh generation
~~~~~~~~~~~~~~~~~~~~~~~~~~

Unstructured mesh generation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. VTK
2. CSV

Mesh loader
~~~~~~~~~~~~

1. VTK
2. CSV
3. hiperlife???

Multi-patch meshes
~~~~~~~~~~~~~~~~~~
Working in progress


Basic mesh generation
~~~~~~~~~~~~~~~~~~~~~


Transformations
---------------
