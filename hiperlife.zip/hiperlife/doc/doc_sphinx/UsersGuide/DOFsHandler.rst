Degree of freedom handler
=========================

Fields
------
1. DOF
2. Auxiliary node field
3. Auxiliary element field

Number and tags


Restart
-------

Initial and boundary conditions
-------------------------------

Constraints
-----------
