.. GitLab Pages with Sphinx documentation master file, created by
   sphinx-quickstart on Thu Jan  9 10:28:38 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

..
   Welcome to hiperlife documentation!
   ====================================================

.. toctree::
   :maxdepth: 2
   :caption: Table of contents
   :hidden:

   Home <self>
   QuickStart/index
   Installation/index
   Tutorials/index
   UsersGuide/index
   dox/index
   Contributing/index
   About/index

.. DevelopersGuide/index


..
   Logo here


   Write here:

   *  Overview
   *  Features
   *  Philosophy of hl
   *  Quick start: sudo apt install hiperlife + Poisson?

..
   Overview
   ========

.. image:: img/logo_wtitle_white.png
   :align: center
   :width: 30%

hiperlife is a high performance parallel library for finite elements. The aim of this library is to provide a computational framework to address problems of cell and tissue mechanobiology for a wide range of cases and users, with special focus on curved surfaces (the cell membrane, the cell cortex, epithelial monolayers,etc.). It is designed to handle the multiphysic nature of problems in mechanobiology, to manage unstructured grids that deal with complex geometries and to allow arbitrary higher-order basis functions that describe the curvature of interfaces.

hiperlife is written in C++, uses the Message Passage Interface (MPI) paradigm for parallelism, and is built on top of several packages of the Trilinos Project. These particular choices set the basis for the main features of the library, namely, parallelism, flexibility, user-centered design and sustainability.

Contents
~~~~~~~~
* :doc:`QuickStart/index`
* :doc:`Installation/index`
* :doc:`Tutorials/index`
* :doc:`UsersGuide/index`
* `Developer's guide <dox>`_
* :doc:`Contributing/index`
* :doc:`About/index`
